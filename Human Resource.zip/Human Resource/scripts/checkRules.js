import { spawn } from "node:child_process";

const commands = [
  "npx ast-grep scan -r .rules/SelectItem.yml",
  "npx ast-grep scan -r .rules/contrast.yml",
  "npx ast-grep scan -r .rules/supabase-google-sso.yml",
  "npx ast-grep scan -r .rules/toast-hook.yml",
  "npx ast-grep scan -r .rules/slot-nesting.yml",
  "npx ast-grep scan -r .rules/require-button-interaction.yml",
  "npx ast-grep scan -r .rules/supabase-edge-function-get-body.yml",
];

function runCommand(command) {
  return new Promise((resolve) => {
    const child = spawn(command, { shell: true, stdio: ["ignore", "pipe", "pipe"] });
    let output = "";

    child.stdout.on("data", (chunk) => {
      output += chunk.toString();
    });
    child.stderr.on("data", (chunk) => {
      output += chunk.toString();
    });

    child.on("close", (code) => {
      resolve({ code, output });
    });
  });
}

async function main() {
  for (const command of commands) {
    const { code } = await runCommand(command);
    if (code !== 0) {
      process.exitCode = code;
      return;
    }
  }

  const useauthResult = await runCommand("npx ast-grep scan -r .rules/useAuth.yml");
  const useauthOutput = useauthResult.output.trim();

  if (!useauthOutput) {
    process.exitCode = 0;
    return;
  }

  const authproviderResult = await runCommand("npx ast-grep scan -r .rules/authProvider.yml");
  const authproviderOutput = authproviderResult.output.trim();

  if (authproviderOutput) {
    process.exitCode = 0;
    return;
  }

  console.log("=== ast-grep scan -r .rules/useAuth.yml output ===");
  console.log(useauthOutput);
  console.log("");
  console.log("=== ast-grep scan -r .rules/authProvider.yml output ===");
  console.log(authproviderOutput);
  console.log("");
  console.log("⚠️  Issue detected:");
  console.log("The code uses useAuth Hook but does not have AuthProvider component wrapping the components.");
  console.log("Please ensure that components using useAuth are wrapped with AuthProvider to provide proper authentication context.");
  console.log("");
  console.log("Suggested fixes:");
  console.log("1. Add AuthProvider wrapper in app.tsx or corresponding root component");
  console.log("2. Ensure all components using useAuth are within AuthProvider scope");
  process.exitCode = 1;
}

main();
