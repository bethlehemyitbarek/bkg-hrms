import { spawn } from "node:child_process";
import { existsSync, unlinkSync, mkdirSync, lstatSync } from "node:fs";
import { resolve } from "node:path";

const VITE_TEMP = resolve("node_modules/.vite-temp");

try {
  if (existsSync(VITE_TEMP)) {
    const stats = lstatSync(VITE_TEMP);
    if (stats.isSymbolicLink()) {
      unlinkSync(VITE_TEMP);
      mkdirSync(VITE_TEMP, { recursive: true });
    }
  } else {
    mkdirSync(VITE_TEMP, { recursive: true });
  }
} catch (error) {
  console.error(error);
  process.exit(1);
}

const command = "npx vite build --minify false --logLevel error --outDir node_modules/.vite-temp/.dist";
const child = spawn(command, { shell: true, stdio: ["ignore", "pipe", "pipe"] });

let output = "";
child.stdout.on("data", (chunk) => { output += chunk.toString(); });
child.stderr.on("data", (chunk) => { output += chunk.toString(); });
child.on("close", (code) => {
  if (code !== 0) {
    console.log(output);
  }
  process.exit(code ?? 1);
});
