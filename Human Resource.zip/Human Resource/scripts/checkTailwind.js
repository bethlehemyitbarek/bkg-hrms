import { spawn } from "node:child_process";
import { platform } from "node:os";

const outputChunks = [];
const nullFile = platform() === "win32" ? "NUL" : "/dev/null";
const command = `npx tailwindcss -i ./src/index.css -o ${nullFile}`;

const child = spawn(command, {
  shell: true,
  stdio: ["ignore", "pipe", "pipe"],
});

child.stdout.on("data", (chunk) => outputChunks.push(chunk.toString()));
child.stderr.on("data", (chunk) => outputChunks.push(chunk.toString()));

child.on("close", () => {
  const output = outputChunks.join("");
  const lines = output.split(/\r?\n/);
  const filtered = lines.filter((line) => /^(CssSyntaxError|Error):.*$/.test(line));

  for (const line of filtered) {
    console.log(line);
  }

  process.exit(0);
});
