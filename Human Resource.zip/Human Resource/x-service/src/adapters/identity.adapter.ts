import { BaseAdapter } from './base.adapter';
import { adapterConfigs } from '../../config/adapters';

export class IdentityAdapter extends BaseAdapter {
  constructor() {
    super({
      baseURL: adapterConfigs.identity.baseUrl,
      timeout: adapterConfigs.identity.timeout,
      circuitBreaker: adapterConfigs.identity.circuitBreaker,
    });
  }
}
