import { BaseAdapter } from './base.adapter';
import { adapterConfigs } from '../../config/adapters';

export class WorkflowAdapter extends BaseAdapter {
  constructor() {
    super({
      baseURL: adapterConfigs.workflow.baseUrl,
      timeout: adapterConfigs.workflow.timeout,
      circuitBreaker: adapterConfigs.workflow.circuitBreaker,
    });
  }
}
