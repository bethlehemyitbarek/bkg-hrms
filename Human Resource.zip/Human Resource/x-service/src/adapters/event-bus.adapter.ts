import { BaseAdapter } from './base.adapter';
import { adapterConfigs } from '../../config/adapters';

export class EventBusAdapter extends BaseAdapter {
  constructor() {
    super({
      baseURL: adapterConfigs.eventBus.baseUrl,
      timeout: adapterConfigs.eventBus.timeout,
      circuitBreaker: adapterConfigs.eventBus.circuitBreaker,
    });
  }
}
