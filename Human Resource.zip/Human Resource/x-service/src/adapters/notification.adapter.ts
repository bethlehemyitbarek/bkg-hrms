import { BaseAdapter } from './base.adapter';
import { adapterConfigs } from '../../config/adapters';

export class NotificationAdapter extends BaseAdapter {
  constructor() {
    super({
      baseURL: adapterConfigs.notification.baseUrl,
      timeout: adapterConfigs.notification.timeout,
      circuitBreaker: adapterConfigs.notification.circuitBreaker,
    });
  }
}
