import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import { CircuitBreaker } from '../utils/circuit-breaker.util';
import { logger } from '../utils/logger';
import { generateServiceToken } from '../utils/serviceToken.util';
import { config } from '../../config/index';

export interface AdapterConfig {
  baseURL: string;
  timeout?: number;
  circuitBreaker?: {
    failureThreshold?: number;
    successThreshold?: number;
    timeout?: number;
    resetTimeout?: number;
  };
}

export abstract class BaseAdapter {
  protected client: AxiosInstance;
  protected circuitBreaker: CircuitBreaker;

  constructor(adapterConfig: AdapterConfig) {
    this.client = axios.create({
      baseURL: adapterConfig.baseURL,
      timeout: adapterConfig.timeout || 5000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.client.interceptors.request.use((req) => {
      req.headers['X-Service-Token'] = generateServiceToken('x-service');
      req.headers['X-Correlation-Id'] = req.headers['X-Correlation-Id'] || crypto.randomUUID();
      return req;
    });

    this.client.interceptors.response.use(
      (res) => res,
      (err) => {
        logger.warn({ adapter: this.constructor.name, error: err.message }, 'Adapter request failed');
        return Promise.reject(err);
      }
    );

    this.circuitBreaker = new CircuitBreaker(
      adapterConfig.circuitBreaker?.failureThreshold,
      adapterConfig.circuitBreaker?.successThreshold,
      adapterConfig.circuitBreaker?.timeout,
      adapterConfig.circuitBreaker?.resetTimeout
    );
  }

  protected async request<T>(config: AxiosRequestConfig): Promise<T> {
    return this.circuitBreaker.execute(async () => {
      const response = await this.client.request<T>(config);
      return response.data;
    });
  }

  protected async get<T>(url: string, params?: Record<string, unknown>): Promise<T> {
    return this.request<T>({ method: 'GET', url, params });
  }

  protected async post<T>(url: string, data?: unknown): Promise<T> {
    return this.request<T>({ method: 'POST', url, data });
  }

  protected async put<T>(url: string, data?: unknown): Promise<T> {
    return this.request<T>({ method: 'PUT', url, data });
  }

  protected async patch<T>(url: string, data?: unknown): Promise<T> {
    return this.request<T>({ method: 'PATCH', url, data });
  }

  protected async delete<T>(url: string): Promise<T> {
    return this.request<T>({ method: 'DELETE', url });
  }
}
