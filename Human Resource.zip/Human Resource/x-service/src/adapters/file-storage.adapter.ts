import { BaseAdapter } from './base.adapter';
import { adapterConfigs } from '../../config/adapters';

export class FileStorageAdapter extends BaseAdapter {
  constructor() {
    super({
      baseURL: adapterConfigs.fileStorage.baseUrl,
      timeout: adapterConfigs.fileStorage.timeout,
      circuitBreaker: adapterConfigs.fileStorage.circuitBreaker,
    });
  }
}
