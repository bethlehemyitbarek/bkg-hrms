import { BaseAdapter } from './base.adapter';
import { adapterConfigs } from '../../config/adapters';

export class TenantAdapter extends BaseAdapter {
  constructor() {
    super({
      baseURL: adapterConfigs.tenant.baseUrl,
      timeout: adapterConfigs.tenant.timeout,
      circuitBreaker: adapterConfigs.tenant.circuitBreaker,
    });
  }
}
