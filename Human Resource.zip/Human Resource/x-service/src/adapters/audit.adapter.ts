import { BaseAdapter } from './base.adapter';
import { adapterConfigs } from '../../config/adapters';

export class AuditAdapter extends BaseAdapter {
  constructor() {
    super({
      baseURL: adapterConfigs.audit.baseUrl,
      timeout: adapterConfigs.audit.timeout,
      circuitBreaker: adapterConfigs.audit.circuitBreaker,
    });
  }
}
