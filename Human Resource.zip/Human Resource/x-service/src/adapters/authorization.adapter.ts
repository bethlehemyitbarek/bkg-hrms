import { BaseAdapter } from './base.adapter';
import { adapterConfigs } from '../../config/adapters';

export class AuthorizationAdapter extends BaseAdapter {
  constructor() {
    super({
      baseURL: adapterConfigs.authorization.baseUrl,
      timeout: adapterConfigs.authorization.timeout,
      circuitBreaker: adapterConfigs.authorization.circuitBreaker,
    });
  }
}
