import { cacheService } from './cache.service';

const PREFIX = 'session';

export async function getSessionCache(sessionId: string) {
  return cacheService.get<Record<string, unknown>>(`${PREFIX}:${sessionId}`);
}

export async function setSessionCache(sessionId: string, data: Record<string, unknown>, ttl = 3600) {
  await cacheService.set(`${PREFIX}:${sessionId}`, data, ttl);
}
