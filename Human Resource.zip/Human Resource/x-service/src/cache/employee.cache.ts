import { cacheService } from './cache.service';

const PREFIX = 'employee';

export async function getEmployeeCache(employeeId: string) {
  return cacheService.get<Record<string, unknown>>(`${PREFIX}:${employeeId}`);
}

export async function setEmployeeCache(employeeId: string, data: Record<string, unknown>, ttl = 300) {
  await cacheService.set(`${PREFIX}:${employeeId}`, data, ttl);
}

export async function invalidateEmployeeCache(employeeId: string) {
  await cacheService.delete(`${PREFIX}:${employeeId}`);
}
