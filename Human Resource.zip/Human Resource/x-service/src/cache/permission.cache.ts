import { cacheService } from './cache.service';

const PREFIX = 'permissions';

export async function getPermissionCache(userId: string) {
  return cacheService.get<string[]>(`${PREFIX}:${userId}`);
}

export async function setPermissionCache(userId: string, permissions: string[], ttl = 600) {
  await cacheService.set(`${PREFIX}:${userId}`, permissions, ttl);
}
