import { cacheService } from './cache.service';

const PREFIX = 'tenant_config';

export async function getTenantConfigCache(tenantId: string) {
  return cacheService.get<Record<string, unknown>>(`${PREFIX}:${tenantId}`);
}

export async function setTenantConfigCache(tenantId: string, data: Record<string, unknown>, ttl = 600) {
  await cacheService.set(`${PREFIX}:${tenantId}`, data, ttl);
}
