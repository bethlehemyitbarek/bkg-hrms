import { redisClient } from '../../config/redis';
import { logger } from '../utils/logger';

export class CacheService {
  async get<T>(key: string): Promise<T | null> {
    try {
      const value = await redisClient.get(key);
      return value ? JSON.parse(value) : null;
    } catch (err) {
      logger.warn({ key, err }, 'Cache get failed');
      return null;
    }
  }

  async set<T>(key: string, value: T, ttlSeconds = 300): Promise<void> {
    try {
      await redisClient.setex(key, ttlSeconds, JSON.stringify(value));
    } catch (err) {
      logger.warn({ key, err }, 'Cache set failed');
    }
  }

  async delete(key: string): Promise<void> {
    try {
      await redisClient.del(key);
    } catch (err) {
      logger.warn({ key, err }, 'Cache delete failed');
    }
  }

  async invalidatePattern(pattern: string): Promise<void> {
    try {
      const keys = await redisClient.keys(pattern);
      if (keys.length > 0) {
        await redisClient.del(...keys);
      }
    } catch (err) {
      logger.warn({ pattern, err }, 'Cache pattern invalidate failed');
    }
  }
}

export const cacheService = new CacheService();
