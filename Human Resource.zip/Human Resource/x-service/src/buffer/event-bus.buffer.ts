import { bufferService } from './buffer.service';

export function bufferEventBusEvent(event: Record<string, unknown>) {
  bufferService.add('event-bus', event);
}
