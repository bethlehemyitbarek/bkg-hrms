import { bufferService } from './buffer.service';

export function bufferNotificationEvent(event: Record<string, unknown>) {
  bufferService.add('notification', event);
}
