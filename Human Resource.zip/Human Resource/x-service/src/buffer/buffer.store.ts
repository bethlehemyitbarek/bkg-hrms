import { bufferService } from './buffer.service';

export const bufferStore = bufferService;
