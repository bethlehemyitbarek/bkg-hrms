import { bufferService } from './buffer.service';

export function bufferAuditEvent(event: Record<string, unknown>) {
  bufferService.add('audit', event);
}
