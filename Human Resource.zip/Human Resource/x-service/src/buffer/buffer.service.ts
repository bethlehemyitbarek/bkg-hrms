export class BufferService {
  private buffers = new Map<string, unknown[]>();

  add(key: string, item: unknown) {
    if (!this.buffers.has(key)) {
      this.buffers.set(key, []);
    }
    this.buffers.get(key)!.push(item);
  }

  flush(key: string): unknown[] {
    const items = this.buffers.get(key) || [];
    this.buffers.set(key, []);
    return items;
  }

  size(key: string): number {
    return this.buffers.get(key)?.length || 0;
  }
}

export const bufferService = new BufferService();
