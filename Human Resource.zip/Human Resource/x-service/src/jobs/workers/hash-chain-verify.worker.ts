import { Worker } from 'bullmq';
import { auditVerifyQueue } from '../queues/audit-verify.queue';
import { redisClient } from '../../../config/redis';

new Worker(auditVerifyQueue.name, async (job) => {
  console.log('Processing hash chain verify job', job.id);
}, { connection: redisClient });
