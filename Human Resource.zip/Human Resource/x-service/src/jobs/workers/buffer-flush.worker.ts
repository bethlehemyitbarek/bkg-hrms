import { Worker } from 'bullmq';
import { bufferFlushQueue } from '../queues/buffer-flush.queue';
import { redisClient } from '../../../config/redis';

new Worker(bufferFlushQueue.name, async (job) => {
  console.log('Processing buffer flush job', job.id);
}, { connection: redisClient });
