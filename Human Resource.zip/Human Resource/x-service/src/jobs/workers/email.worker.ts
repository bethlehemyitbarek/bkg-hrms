import { Worker } from 'bullmq';
import { notificationQueue } from '../queues/notification.queue';
import { redisClient } from '../../../config/redis';

new Worker(notificationQueue.name, async (job) => {
  console.log('Processing email job', job.id, job.data);
}, { connection: redisClient });
