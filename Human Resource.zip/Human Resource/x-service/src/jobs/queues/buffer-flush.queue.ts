import { Queue } from 'bullmq';
import { redisClient } from '../../../config/redis';

export const bufferFlushQueue = new Queue('buffer-flush', {
  connection: redisClient,
});
