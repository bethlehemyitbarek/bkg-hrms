import { Queue } from 'bullmq';
import { redisClient } from '../../../config/redis';

export const notificationQueue = new Queue('notification', {
  connection: redisClient,
});
