import { Queue } from 'bullmq';
import { redisClient } from '../../../config/redis';

export const auditVerifyQueue = new Queue('audit-verify', {
  connection: redisClient,
});
