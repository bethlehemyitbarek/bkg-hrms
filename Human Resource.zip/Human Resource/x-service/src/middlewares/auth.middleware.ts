import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../../config/index';
import { ApiError } from '../utils/ApiError';
import { HEADERS } from '../constants/headers';
import { ERROR_CODES } from '../constants/errors';

export function authMiddleware(req: Request, _res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next(ApiError.unauthorized(ERROR_CODES.AUTHENTICATION_ERROR, 'Missing or invalid authorization header'));
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, config.jwt.secret) as {
      sub: string;
      roles: string[];
      tenantId: string;
    };
    req.context = {
      ...req.context,
      userId: decoded.sub,
      userRoles: decoded.roles || [],
      tenantId: decoded.tenantId || req.context?.tenantId,
    };
    req.headers[HEADERS.USER_ID.toLowerCase()] = decoded.sub;
    req.headers[HEADERS.USER_ROLES.toLowerCase()] = (decoded.roles || []).join(',');
    next();
  } catch {
    next(ApiError.unauthorized(ERROR_CODES.AUTHENTICATION_ERROR, 'Invalid or expired token'));
  }
}
