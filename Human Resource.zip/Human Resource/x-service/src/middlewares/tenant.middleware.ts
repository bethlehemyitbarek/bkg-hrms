import { Request, Response, NextFunction } from 'express';
import { ApiError } from '../utils/ApiError';
import { HEADERS } from '../constants/headers';
import { ERROR_CODES } from '../constants/errors';

export function tenantMiddleware(req: Request, _res: Response, next: NextFunction) {
  const tenantId = req.headers[HEADERS.TENANT_ID.toLowerCase()] as string | undefined;
  if (!tenantId) {
    return next(ApiError.badRequest(ERROR_CODES.TENANT_NOT_FOUND, 'Tenant ID is required'));
  }
  if (req.context) {
    req.context.tenantId = tenantId;
  }
  next();
}
