import { Request, Response, NextFunction } from "express";
import { HEADERS } from "../constants/headers";

export interface RequestContext {
  correlationId: string;
  requestId: string;
  tenantId: string;
}

export function contextMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
) {
  req.context = {
    correlationId:
      (req.headers[HEADERS.CORRELATION_ID.toLowerCase()] as string) || "",

    requestId:
      (req.headers[HEADERS.REQUEST_ID.toLowerCase()] as string) || "",

    tenantId:
      (req.headers[HEADERS.TENANT_ID.toLowerCase()] as string) || "",
  };

  next();
}