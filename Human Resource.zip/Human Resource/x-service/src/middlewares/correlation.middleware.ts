import { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { HEADERS } from '../constants/headers';

export function correlationMiddleware(req: Request, res: Response, next: NextFunction) {
  const correlationId = (req.headers[HEADERS.CORRELATION_ID.toLowerCase()] as string) || uuidv4();
  req.headers[HEADERS.CORRELATION_ID.toLowerCase()] = correlationId;
  res.setHeader(HEADERS.CORRELATION_ID, correlationId);
  next();
}
