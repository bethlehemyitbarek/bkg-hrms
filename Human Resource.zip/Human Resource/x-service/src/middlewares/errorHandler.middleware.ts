import { Request, Response, NextFunction } from 'express';
import { errorHandler } from '../utils/errorHandler';

export function errorHandlerMiddleware(err: Error, req: Request, res: Response, _next: NextFunction) {
  errorHandler(err, req, res);
}
    