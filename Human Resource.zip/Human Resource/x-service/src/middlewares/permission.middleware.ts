import { Request, Response, NextFunction } from 'express';
import { ApiError } from '../utils/ApiError';
import { ERROR_CODES } from '../constants/errors';

export function requirePermission(...permissions: string[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    const userRoles = req.context?.userRoles || [];
    const hasPermission = permissions.some((p) => userRoles.includes(p) || userRoles.includes('admin:full_access'));
    if (!hasPermission) {
      return next(ApiError.forbidden(ERROR_CODES.AUTHORIZATION_ERROR, 'Insufficient permissions'));
    }
    next();
  };
}
