import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

export function auditMiddleware(req: Request, res: Response, next: NextFunction) {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    logger.info({
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      duration,
      tenantId: req.context?.tenantId,
      userId: req.context?.userId,
      correlationId: req.context?.correlationId,
    }, 'Audit log');
  });
  next();
}
    