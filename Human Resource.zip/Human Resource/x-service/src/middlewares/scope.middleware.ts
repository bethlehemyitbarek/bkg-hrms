import { Request, Response, NextFunction } from 'express';

export function scopeMiddleware(req: Request, _res: Response, next: NextFunction) {
  const scope = (req.headers['x-scope'] as string) || 'default';
  if (req.context) {
    req.context.scope = scope;
  }
  next();
}
