import rateLimit from 'express-rate-limit';
import { config } from '../../config/index';
import { ApiError } from '../utils/ApiError';
import { ERROR_CODES } from '../constants/errors';

export const rateLimiterMiddleware = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.maxRequests,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, _res, next) => {
    next(ApiError.tooManyRequests(ERROR_CODES.RATE_LIMITED, 'Rate limit exceeded'));
  },
  keyGenerator: (req) => {
    return (req.headers['x-tenant-id'] as string) || req.ip || 'anonymous';
  },
});
    