import { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { HEADERS } from '../constants/headers';

export function requestIdMiddleware(req: Request, res: Response, next: NextFunction) {
  const requestId = (req.headers[HEADERS.REQUEST_ID.toLowerCase()] as string) || uuidv4();
  req.headers[HEADERS.REQUEST_ID.toLowerCase()] = requestId;
  res.setHeader(HEADERS.REQUEST_ID, requestId);
  next();
}
