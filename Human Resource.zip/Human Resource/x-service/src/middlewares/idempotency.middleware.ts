import { Request, Response, NextFunction } from 'express';
import { ApiError } from '../utils/ApiError';
import { getIdempotencyResponse, setIdempotencyResponse } from '../utils/idempotency.util';
import { HEADERS } from '../constants/headers';
import { ERROR_CODES } from '../constants/errors';

export function idempotencyMiddleware(req: Request, res: Response, next: NextFunction) {
  const key = req.headers[HEADERS.IDEMPOTENCY_KEY.toLowerCase()] as string | undefined;
  if (!key || req.method === 'GET' || req.method === 'DELETE') {
    return next();
  }

  getIdempotencyResponse(key).then((cached) => {
    if (cached) {
      res.setHeader('X-Idempotency-Replay', 'true');
      return res.status(200).json(JSON.parse(cached));
    }

    const originalJson = res.json.bind(res);
    res.json = (body: unknown) => {
      setIdempotencyResponse(key, JSON.stringify(body), 86400).catch(() => {});
      return originalJson(body);
    };
    next();
  }).catch((err) => {
    next(ApiError.internal(ERROR_CODES.IDEMPOTENCY_ERROR, err.message));
  });
}
