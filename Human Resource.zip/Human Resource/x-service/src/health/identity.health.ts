export async function checkIdentityHealth() {
  return { status: 'up' };
}
