import { Request, Response } from 'express';
import { checkDatabaseHealth } from './database.health';
import { checkRedisHealth } from './redis.health';

export async function readinessHandler(_req: Request, res: Response) {
  try {
    await checkDatabaseHealth();
    await checkRedisHealth();
    res.status(200).json({ status: 'ready' });
  } catch {
    res.status(503).json({ status: 'not_ready' });
  }
}

