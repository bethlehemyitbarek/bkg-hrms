import { redisClient } from '../../config/redis';

export async function checkRedisHealth() {
  await redisClient.ping();
  return { status: 'up' };
}
