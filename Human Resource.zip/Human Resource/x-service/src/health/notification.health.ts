export async function checkNotificationHealth() {
  return { status: 'up' };
}
