export async function checkAuthorizationHealth() {
  return { status: 'up' };
}
