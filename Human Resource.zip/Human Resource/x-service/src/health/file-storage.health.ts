export async function checkFileStorageHealth() {
  return { status: 'up' };
}

