export async function checkEventBusHealth() {
  return { status: 'up' };
}
