export async function checkWorkflowHealth() {
  return { status: 'up' };
}
