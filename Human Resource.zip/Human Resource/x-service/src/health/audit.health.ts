export async function checkAuditHealth() {
  return { status: 'up' };
}
