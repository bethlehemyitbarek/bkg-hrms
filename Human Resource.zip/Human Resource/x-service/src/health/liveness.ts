import { Request, Response } from 'express';

export async function livenessHandler(_req: Request, res: Response) {
  res.status(200).json({ status: 'alive' });
}
