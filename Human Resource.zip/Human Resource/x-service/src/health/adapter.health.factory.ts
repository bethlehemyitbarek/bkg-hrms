export function createAdapterHealthCheck(name: string) {
  return async () => ({ status: 'up', adapter: name });
}
