export async function checkTenantHealth() {
  return { status: 'up' };
}
