import { sequelize } from '../../config/database';

export async function checkDatabaseHealth() {
  await sequelize.authenticate();
  return { status: 'up' };
}
