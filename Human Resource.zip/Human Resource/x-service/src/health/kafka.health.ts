import { kafkaProducer } from '../../config/kafka';

export async function checkKafkaHealth() {
  await kafkaProducer.connect();
  return { status: 'up' };
}
