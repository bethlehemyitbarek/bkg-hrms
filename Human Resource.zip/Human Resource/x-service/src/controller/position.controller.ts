import { Request, Response } from 'express';
import { PositionService } from '../services/position.service';
import { asyncHandler } from '../utils/asyncHandler';
import { ApiError } from '../utils/ApiError';

const service = new PositionService();

export const positionController = {
  getAll: asyncHandler(async (req: Request, res: Response) => {
    const tenantId = req.context?.tenantId;
    const data = await service.findAll({ where: { tenantId } });
    res.status(200).json({ success: true, data });
  }),

  getById: asyncHandler(async (req: Request, res: Response) => {
    const data = await service.findById(req.params.id);
    if (!data) throw ApiError.notFound('NOT_FOUND', 'position not found');
    res.status(200).json({ success: true, data });
  }),

  create: asyncHandler(async (req: Request, res: Response) => {
    const data = await service.create({ ...req.body, tenantId: req.context?.tenantId });
    res.status(201).json({ success: true, data });
  }),

  update: asyncHandler(async (req: Request, res: Response) => {
    const data = await service.update(req.params.id, req.body);
    if (!data) throw ApiError.notFound('NOT_FOUND', 'position not found');
    res.status(200).json({ success: true, data });
  }),

  remove: asyncHandler(async (req: Request, res: Response) => {
    const deleted = await service.delete(req.params.id);
    if (!deleted) throw ApiError.notFound('NOT_FOUND', 'position not found');
    res.status(204).send();
  }),
};

