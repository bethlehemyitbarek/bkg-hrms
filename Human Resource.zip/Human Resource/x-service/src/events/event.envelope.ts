export interface EventEnvelope {
  eventId: string;
  eventType: string;
  timestamp: string;
  version: string;
  payload: Record<string, unknown>;
  metadata: {
    correlationId: string;
    tenantId?: string;
    userId?: string;
  };
}
