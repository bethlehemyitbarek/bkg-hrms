import { BasePublisher, DomainEvent } from './base.publisher';

export class OffboardingPublisher extends BasePublisher {
  protected topic = 'offboarding-events';

  async offboardingCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'offboarding.created',
      aggregateId,
      aggregateType: 'offboarding',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async offboardingUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'offboarding.updated',
      aggregateId,
      aggregateType: 'offboarding',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
