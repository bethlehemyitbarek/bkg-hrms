import { BasePublisher, DomainEvent } from './base.publisher';

export class SeparationPublisher extends BasePublisher {
  protected topic = 'separation-events';

  async separationCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'separation.created',
      aggregateId,
      aggregateType: 'separation',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async separationUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'separation.updated',
      aggregateId,
      aggregateType: 'separation',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
