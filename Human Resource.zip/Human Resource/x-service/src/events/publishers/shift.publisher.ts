import { BasePublisher, DomainEvent } from './base.publisher';

export class ShiftPublisher extends BasePublisher {
  protected topic = 'shift-events';

  async shiftCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'shift.created',
      aggregateId,
      aggregateType: 'shift',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async shiftUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'shift.updated',
      aggregateId,
      aggregateType: 'shift',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
