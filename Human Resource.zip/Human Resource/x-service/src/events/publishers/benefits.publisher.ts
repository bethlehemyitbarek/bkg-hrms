import { BasePublisher, DomainEvent } from './base.publisher';

export class BenefitsPublisher extends BasePublisher {
  protected topic = 'benefits-events';

  async benefitsCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'benefits.created',
      aggregateId,
      aggregateType: 'benefits',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async benefitsUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'benefits.updated',
      aggregateId,
      aggregateType: 'benefits',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
