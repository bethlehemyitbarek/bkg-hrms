import { kafkaProducer } from '../../../config/kafka';
import { logger } from '../../utils/logger';

export interface DomainEvent {
  type: string;
  aggregateId: string;
  aggregateType: string;
  timestamp: string;
  payload: Record<string, unknown>;
  metadata: Record<string, unknown>;
}

export abstract class BasePublisher {
  protected abstract topic: string;

  async publish(event: DomainEvent): Promise<void> {
    try {
      await kafkaProducer.send({
        topic: this.topic,
        messages: [
          {
            key: event.aggregateId,
            value: JSON.stringify(event),
            headers: {
              'event-type': event.type,
              'event-timestamp': event.timestamp,
            },
          },
        ],
      });
      logger.info({ topic: this.topic, eventType: event.type }, 'Event published');
    } catch (err) {
      logger.error({ err, topic: this.topic }, 'Failed to publish event');
      throw err;
    }
  }
}
