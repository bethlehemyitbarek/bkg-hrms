import { BasePublisher, DomainEvent } from './base.publisher';

export class TimesheetPublisher extends BasePublisher {
  protected topic = 'timesheet-events';

  async timesheetCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'timesheet.created',
      aggregateId,
      aggregateType: 'timesheet',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async timesheetUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'timesheet.updated',
      aggregateId,
      aggregateType: 'timesheet',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
