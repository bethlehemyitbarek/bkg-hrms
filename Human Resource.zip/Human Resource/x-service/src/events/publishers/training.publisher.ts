import { BasePublisher, DomainEvent } from './base.publisher';

export class TrainingPublisher extends BasePublisher {
  protected topic = 'training-events';

  async trainingCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'training.created',
      aggregateId,
      aggregateType: 'training',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async trainingUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'training.updated',
      aggregateId,
      aggregateType: 'training',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
