import { BasePublisher, DomainEvent } from './base.publisher';

export class PerformancePublisher extends BasePublisher {
  protected topic = 'performance-events';

  async performanceCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'performance.created',
      aggregateId,
      aggregateType: 'performance',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async performanceUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'performance.updated',
      aggregateId,
      aggregateType: 'performance',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
