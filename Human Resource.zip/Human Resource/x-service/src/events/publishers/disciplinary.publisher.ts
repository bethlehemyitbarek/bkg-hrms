import { BasePublisher, DomainEvent } from './base.publisher';

export class DisciplinaryPublisher extends BasePublisher {
  protected topic = 'disciplinary-events';

  async disciplinaryCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'disciplinary.created',
      aggregateId,
      aggregateType: 'disciplinary',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async disciplinaryUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'disciplinary.updated',
      aggregateId,
      aggregateType: 'disciplinary',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
