import { BasePublisher, DomainEvent } from './base.publisher';

export class PositionPublisher extends BasePublisher {
  protected topic = 'position-events';

  async positionCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'position.created',
      aggregateId,
      aggregateType: 'position',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async positionUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'position.updated',
      aggregateId,
      aggregateType: 'position',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
