import { BasePublisher, DomainEvent } from './base.publisher';

export class GrievancePublisher extends BasePublisher {
  protected topic = 'grievance-events';

  async grievanceCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'grievance.created',
      aggregateId,
      aggregateType: 'grievance',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async grievanceUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'grievance.updated',
      aggregateId,
      aggregateType: 'grievance',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
