import { BasePublisher, DomainEvent } from './base.publisher';

export class ExpensePublisher extends BasePublisher {
  protected topic = 'expense-events';

  async expenseCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'expense.created',
      aggregateId,
      aggregateType: 'expense',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async expenseUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'expense.updated',
      aggregateId,
      aggregateType: 'expense',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
