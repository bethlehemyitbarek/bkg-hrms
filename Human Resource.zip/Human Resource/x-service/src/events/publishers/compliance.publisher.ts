import { BasePublisher, DomainEvent } from './base.publisher';

export class CompliancePublisher extends BasePublisher {
  protected topic = 'compliance-events';

  async complianceCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'compliance.created',
      aggregateId,
      aggregateType: 'compliance',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async complianceUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'compliance.updated',
      aggregateId,
      aggregateType: 'compliance',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
