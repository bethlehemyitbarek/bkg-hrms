import { BasePublisher, DomainEvent } from './base.publisher';

export class TransferPublisher extends BasePublisher {
  protected topic = 'transfer-events';

  async transferCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'transfer.created',
      aggregateId,
      aggregateType: 'transfer',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async transferUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'transfer.updated',
      aggregateId,
      aggregateType: 'transfer',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
