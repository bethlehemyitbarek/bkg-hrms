import { BasePublisher, DomainEvent } from './base.publisher';

export class LoanPublisher extends BasePublisher {
  protected topic = 'loan-events';

  async loanCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'loan.created',
      aggregateId,
      aggregateType: 'loan',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async loanUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'loan.updated',
      aggregateId,
      aggregateType: 'loan',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
