import { BasePublisher, DomainEvent } from './base.publisher';

export class AttendancePublisher extends BasePublisher {
  protected topic = 'attendance-events';

  async attendanceCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'attendance.created',
      aggregateId,
      aggregateType: 'attendance',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async attendanceUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'attendance.updated',
      aggregateId,
      aggregateType: 'attendance',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
