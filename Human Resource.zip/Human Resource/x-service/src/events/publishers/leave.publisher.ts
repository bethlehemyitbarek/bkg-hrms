import { BasePublisher, DomainEvent } from './base.publisher';

export class LeavePublisher extends BasePublisher {
  protected topic = 'leave-events';

  async leaveCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'leave.created',
      aggregateId,
      aggregateType: 'leave',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async leaveUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'leave.updated',
      aggregateId,
      aggregateType: 'leave',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
