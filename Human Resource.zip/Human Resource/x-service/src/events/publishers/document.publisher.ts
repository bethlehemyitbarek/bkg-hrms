import { BasePublisher, DomainEvent } from './base.publisher';

export class DocumentPublisher extends BasePublisher {
  protected topic = 'document-events';

  async documentCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'document.created',
      aggregateId,
      aggregateType: 'document',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async documentUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'document.updated',
      aggregateId,
      aggregateType: 'document',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
