import { BasePublisher, DomainEvent } from './base.publisher';

export class RecruitmentPublisher extends BasePublisher {
  protected topic = 'recruitment-events';

  async recruitmentCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'recruitment.created',
      aggregateId,
      aggregateType: 'recruitment',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async recruitmentUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'recruitment.updated',
      aggregateId,
      aggregateType: 'recruitment',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
