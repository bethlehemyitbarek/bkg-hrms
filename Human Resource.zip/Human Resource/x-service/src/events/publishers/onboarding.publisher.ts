import { BasePublisher, DomainEvent } from './base.publisher';

export class OnboardingPublisher extends BasePublisher {
  protected topic = 'onboarding-events';

  async onboardingCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'onboarding.created',
      aggregateId,
      aggregateType: 'onboarding',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async onboardingUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'onboarding.updated',
      aggregateId,
      aggregateType: 'onboarding',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
