import { BasePublisher, DomainEvent } from './base.publisher';

export class PayrollPublisher extends BasePublisher {
  protected topic = 'payroll-events';

  async payrollCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'payroll.created',
      aggregateId,
      aggregateType: 'payroll',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async payrollUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'payroll.updated',
      aggregateId,
      aggregateType: 'payroll',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
