import { BasePublisher, DomainEvent } from './base.publisher';

export class DepartmentPublisher extends BasePublisher {
  protected topic = 'department-events';

  async departmentCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'department.created',
      aggregateId,
      aggregateType: 'department',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async departmentUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'department.updated',
      aggregateId,
      aggregateType: 'department',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
