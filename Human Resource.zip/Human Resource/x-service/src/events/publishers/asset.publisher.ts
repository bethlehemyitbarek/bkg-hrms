import { BasePublisher, DomainEvent } from './base.publisher';

export class AssetPublisher extends BasePublisher {
  protected topic = 'asset-events';

  async assetCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'asset.created',
      aggregateId,
      aggregateType: 'asset',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async assetUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'asset.updated',
      aggregateId,
      aggregateType: 'asset',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
