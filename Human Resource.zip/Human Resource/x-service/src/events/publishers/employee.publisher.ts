import { BasePublisher, DomainEvent } from './base.publisher';

export class EmployeePublisher extends BasePublisher {
  protected topic = 'employee-events';

  async employeeCreated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'employee.created',
      aggregateId,
      aggregateType: 'employee',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }

  async employeeUpdated(aggregateId: string, payload: Record<string, unknown>) {
    const event: DomainEvent = {
      type: 'employee.updated',
      aggregateId,
      aggregateType: 'employee',
      timestamp: new Date().toISOString(),
      payload,
      metadata: {},
    };
    await this.publish(event);
  }
}
