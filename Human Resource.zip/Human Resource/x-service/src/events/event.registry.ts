const eventRegistry = new Map<string, { topic: string; schema?: unknown }>();

export function registerEvent(type: string, topic: string, schema?: unknown) {
  eventRegistry.set(type, { topic, schema });
}

export function getEventConfig(type: string) {
  return eventRegistry.get(type);
}
