import { logger } from '../utils/logger';

export async function handleDLQ(message: { key: string | null; value: string | null; headers?: Record<string, unknown> }) {
  logger.error({ message }, 'Message moved to DLQ');
}
