import { logger } from '../../utils/logger';

export async function handleTmsEvent(event: Record<string, unknown>) {
  logger.info({ event }, 'TMS event received');
}
