import { logger } from '../../utils/logger';

export async function handleAuthorizationEvent(event: Record<string, unknown>) {
  logger.info({ event }, 'Authorization event received');
}
