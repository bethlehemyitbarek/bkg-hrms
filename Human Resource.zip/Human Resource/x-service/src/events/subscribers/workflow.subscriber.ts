import { logger } from '../../utils/logger';

export async function handleWorkflowEvent(event: Record<string, unknown>) {
  logger.info({ event }, 'Workflow event received');
}
