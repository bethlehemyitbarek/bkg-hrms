import { logger } from '../../utils/logger';

export async function handleIdentityEvent(event: Record<string, unknown>) {
  logger.info({ event }, 'Identity event received');
}
