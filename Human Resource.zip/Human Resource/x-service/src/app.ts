import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import { config } from '../config/index';
import { logger } from './utils/logger';
import { metricsRegistry } from './utils/metrics.util';
import {
  requestIdMiddleware,
  correlationMiddleware,
  contextMiddleware,
  rateLimiterMiddleware,
  metricsMiddleware,
  auditMiddleware,
  errorHandlerMiddleware,
} from './middlewares';
import routes from './routes';

export function createApp() {
  const app = express();

  app.use(helmet());
  app.use(cors({ origin: true, credentials: true }));
  app.use(compression());
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  app.use(requestIdMiddleware);
  app.use(correlationMiddleware);
  app.use(contextMiddleware);
  app.use(rateLimiterMiddleware);
  app.use(metricsMiddleware);
  app.use(auditMiddleware);

  app.get('/health', (_req: Request, res: Response) => res.status(200).json({ status: 'ok' }));
  app.get('/ready', (_req: Request, res: Response) => res.status(200).json({ status: 'ready' }));
  app.get('/metrics', async (_req: Request, res: Response) => {
    res.set('Content-Type', metricsRegistry.contentType);
    res.end(await metricsRegistry.metrics());
  });

  app.use('/api/v1', routes);

  app.use((_req: Request, res: Response) => {
    res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Endpoint not found' } });
  });

  app.use(errorHandlerMiddleware);

  return app;
}

export default createApp;
