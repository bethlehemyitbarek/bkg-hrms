import { config } from './index';
import { defaultCircuitBreakerOptions } from './circuit-breaker';

export const adapterConfigs = {
  identity: {
    baseUrl: config.adapters.identityUrl,
    timeout: config.adapters.timeout,
    circuitBreaker: defaultCircuitBreakerOptions,
  },
  authorization: {
    baseUrl: config.adapters.authorizationUrl,
    timeout: config.adapters.timeout,
    circuitBreaker: defaultCircuitBreakerOptions,
  },
  notification: {
    baseUrl: config.adapters.notificationUrl,
    timeout: config.adapters.timeout,
    circuitBreaker: defaultCircuitBreakerOptions,
  },
  workflow: {
    baseUrl: config.adapters.workflowUrl,
    timeout: config.adapters.timeout,
    circuitBreaker: defaultCircuitBreakerOptions,
  },
  audit: {
    baseUrl: config.adapters.auditUrl,
    timeout: config.adapters.timeout,
    circuitBreaker: defaultCircuitBreakerOptions,
  },
  tenant: {
    baseUrl: config.adapters.tenantUrl,
    timeout: config.adapters.timeout,
    circuitBreaker: defaultCircuitBreakerOptions,
  },
  fileStorage: {
    baseUrl: config.adapters.fileStorageUrl,
    timeout: config.adapters.timeout,
    circuitBreaker: defaultCircuitBreakerOptions,
  },
  eventBus: {
    baseUrl: config.adapters.eventBusUrl,
    timeout: config.adapters.timeout,
    circuitBreaker: defaultCircuitBreakerOptions,
  },
};
