import { Sequelize } from '@sequelize/core';
import { MySqlDialect } from '@sequelize/mysql';
import { config } from './index';

export const sequelize = new Sequelize({
  dialect: MySqlDialect,
  host: config.database.host,
  port: config.database.port,
  user: config.database.username,
  password: config.database.password,
  database: config.database.database,
  pool: {
    min: config.database.poolMin,
    max: config.database.poolMax,
  },
  logging: config.env === 'development' ? console.log : false,
});
