import { Kafka, Producer, Consumer } from 'kafkajs';
import { config } from './index';

export const kafka = new Kafka({
  clientId: config.kafka.clientId,
  brokers: config.kafka.brokers,
});

export const kafkaProducer: Producer = kafka.producer();
export const kafkaConsumer: Consumer = kafka.consumer({ groupId: config.kafka.groupId });
