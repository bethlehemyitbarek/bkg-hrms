import dotenv from 'dotenv';

dotenv.config();

function getEnv(key: string, defaultValue?: string): string {
  const value = process.env[key];
  if (!value && !defaultValue) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value || defaultValue || '';
}

function getEnvInt(key: string, defaultValue: number): number {
  const value = process.env[key];
  return value ? parseInt(value, 10) : defaultValue;
}

export const config = {
  env: getEnv('NODE_ENV', 'development'),
  port: getEnvInt('PORT', 3000),
  host: getEnv('HOST', '0.0.0.0'),
  database: {
    host: getEnv('DB_HOST', 'localhost'),
    port: getEnvInt('DB_PORT', 3306),
    username: getEnv('DB_USER', 'root'),
    password: getEnv('DB_PASSWORD', ''),
    database: getEnv('DB_NAME', 'hrms'),
    poolMin: getEnvInt('DB_POOL_MIN', 2),
    poolMax: getEnvInt('DB_POOL_MAX', 10),
  },
  redis: {
    host: getEnv('REDIS_HOST', 'localhost'),
    port: getEnvInt('REDIS_PORT', 6379),
    password: getEnv('REDIS_PASSWORD', ''),
    db: getEnvInt('REDIS_DB', 0),
  },
  kafka: {
    brokers: getEnv('KAFKA_BROKERS', 'localhost:9092').split(','),
    clientId: getEnv('KAFKA_CLIENT_ID', 'x-service'),
    groupId: getEnv('KAFKA_GROUP_ID', 'x-service-group'),
  },
  jwt: {
    secret: getEnv('JWT_SECRET', 'change-me'),
    expiresIn: getEnv('JWT_EXPIRES_IN', '1h'),
    refreshSecret: getEnv('JWT_REFRESH_SECRET', 'change-me-refresh'),
    refreshExpiresIn: getEnv('JWT_REFRESH_EXPIRES_IN', '7d'),
  },
  adapters: {
    identityUrl: getEnv('IDENTITY_SERVICE_URL', 'http://localhost:3001'),
    authorizationUrl: getEnv('AUTHORIZATION_SERVICE_URL', 'http://localhost:3002'),
    notificationUrl: getEnv('NOTIFICATION_SERVICE_URL', 'http://localhost:3003'),
    workflowUrl: getEnv('WORKFLOW_SERVICE_URL', 'http://localhost:3004'),
    auditUrl: getEnv('AUDIT_SERVICE_URL', 'http://localhost:3005'),
    tenantUrl: getEnv('TENANT_SERVICE_URL', 'http://localhost:3006'),
    fileStorageUrl: getEnv('FILE_STORAGE_URL', 'http://localhost:3007'),
    eventBusUrl: getEnv('EVENT_BUS_URL', 'http://localhost:3008'),
    timeout: getEnvInt('ADAPTER_TIMEOUT', 5000),
  },
  rateLimit: {
    windowMs: getEnvInt('RATE_LIMIT_WINDOW_MS', 60000),
    maxRequests: getEnvInt('RATE_LIMIT_MAX_REQUESTS', 100),
  },
  logging: {
    level: getEnv('LOG_LEVEL', 'info'),
    prettyPrint: getEnv('NODE_ENV', 'development') === 'development',
  },
};
