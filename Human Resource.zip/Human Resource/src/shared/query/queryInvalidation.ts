import { queryClient } from './queryClient';

export function invalidateQueries(keys: unknown[][]) {
  keys.forEach((key) => queryClient.invalidateQueries({ queryKey: key }));
}
