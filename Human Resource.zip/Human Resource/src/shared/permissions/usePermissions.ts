import { useSelector } from 'react-redux';
import { RootState } from '../../app/store';

export function usePermissions() {
  const userRoles = useSelector((state: RootState) => state.auth.user?.roles || []);

  const hasPermission = (permission: string) => {
    return userRoles.includes(permission) || userRoles.includes('admin:full_access');
  };

  const hasAnyPermission = (...permissions: string[]) => {
    return permissions.some((p) => hasPermission(p));
  };

  const hasAllPermissions = (...permissions: string[]) => {
    return permissions.every((p) => hasPermission(p));
  };

  return { hasPermission, hasAnyPermission, hasAllPermissions, userRoles };
}
