import { format, parseISO, addDays, subDays, startOfMonth, endOfMonth } from 'date-fns';

export { format, parseISO, addDays, subDays, startOfMonth, endOfMonth };

export function today(): string {
  return format(new Date(), 'yyyy-MM-dd');
}

export function toISODate(date: Date | string): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  return format(d, 'yyyy-MM-dd');
}
