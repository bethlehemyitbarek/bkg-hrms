export function formatDate(date: string | Date | null, options?: Intl.DateTimeFormatOptions): string {
  if (!date) return '-';
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('en-US', options || { year: 'numeric', month: 'short', day: 'numeric' });
}

/** Format a monetary value in Ethiopian Birr (ETB). Symbol: ብር */
export function formatBirr(amount: number, decimals = 0): string {
  return `ብር ${Number(amount || 0).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
}

export function formatCurrency(amount: number, currency = 'ETB'): string {
  if (currency === 'ETB' || currency === 'ብር') return formatBirr(amount);
  return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(amount);
}

export function formatNumber(num: number, decimals = 0): string {
  return num.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}
