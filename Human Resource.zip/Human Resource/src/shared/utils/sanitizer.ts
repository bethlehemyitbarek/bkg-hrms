import DOMPurify from 'dompurify';

export function sanitizeHtml(html: string): string {
  return DOMPurify.sanitize(html);
}

export function sanitizeInput(input: string): string {
  return input.trim().replace(/[<>]/g, '');
}
