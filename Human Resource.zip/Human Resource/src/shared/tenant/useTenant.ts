import { useSelector } from 'react-redux';
import { RootState } from '../../app/store';

export function useTenant() {
  const tenant = useSelector((state: RootState) => state.tenant);
  return {
    tenantId: tenant.tenantId,
    tenantName: tenant.tenantName,
    isLoaded: tenant.isLoaded,
  };
}
