import { cn } from '@/lib/utils';
import { ReactNode } from 'react';

interface SidebarProps {
  children: ReactNode;
  className?: string;
}

export function Sidebar({ children, className }: SidebarProps) {
  return (
    <aside className={cn('w-64 h-screen bg-background border-r flex flex-col', className)}>
      {children}
    </aside>
  );
}
