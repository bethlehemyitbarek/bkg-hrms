import { Card } from '../Card/Card';

interface StatCardProps {
  title: string;
  value: string | number;
  description?: string;
  trend?: 'up' | 'down' | 'neutral';
}

export function StatCard({ title, value, description }: StatCardProps) {
  return (
    <Card title={title}>
      <div className="text-3xl font-bold">{value}</div>
      {description && <p className="text-sm text-muted-foreground">{description}</p>}
    </Card>
  );
}
