import { Button as ShadcnButton } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { ReactNode } from 'react';

interface ButtonProps {
  children: ReactNode;
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  className?: string;
  onClick?: () => void;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
}

export function Button({ children, variant = 'default', size = 'default', className, ...props }: ButtonProps) {
  return (
    <ShadcnButton variant={variant} size={size} className={cn(className)} {...props}>
      {children}
    </ShadcnButton>
  );
}
