import { useMutation, UseMutationOptions } from '@tanstack/react-query';

export function useApiMutation<TData, TVariables = unknown>(
  mutationFn: (variables: TVariables) => Promise<TData>,
  options?: Omit<UseMutationOptions<TData, Error, TVariables>, 'mutationFn'>
) {
  return useMutation({
    mutationFn,
    ...options,
  });
}
