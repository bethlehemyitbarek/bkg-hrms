import { useState, useCallback } from 'react';
import { httpClient } from '../api/httpClient';

export function useFileUpload() {
  const [progress, setProgress] = useState(0);

  const upload = useCallback(async (file: File, url: string) => {
    const formData = new FormData();
    formData.append('file', file);
    const response = await httpClient.post(url, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (e) => {
        if (e.total) setProgress(Math.round((e.loaded * 100) / e.total));
      },
    });
    return response.data;
  }, []);

  return { upload, progress };
}
