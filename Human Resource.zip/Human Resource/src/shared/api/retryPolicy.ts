import { AxiosError } from 'axios';

export const retryPolicy = {
  retries: 3,
  retryDelay: (retryCount: number) => retryCount * 1000,
  retryCondition: (error: AxiosError) => {
    return !!(
      error.response?.status &&
      (error.response.status >= 500 || error.response.status === 429)
    );
  },
};
