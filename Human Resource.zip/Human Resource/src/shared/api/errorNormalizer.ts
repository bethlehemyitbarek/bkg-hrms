export interface ApiErrorResponse {
  success: false;
  error: {
    code: string;
    message: string;
    details?: Record<string, unknown>;
  };
}

export function normalizeError(error: unknown): { code: string; message: string; status?: number } {
  if (error && typeof error === 'object' && 'response' in error) {
    const axiosError = error as { response?: { status?: number; data?: ApiErrorResponse } };
    const data = axiosError.response?.data;
    return {
      code: data?.error?.code || 'UNKNOWN_ERROR',
      message: data?.error?.message || 'An unexpected error occurred',
      status: axiosError.response?.status,
    };
  }
  if (error instanceof Error) {
    return { code: 'UNKNOWN_ERROR', message: error.message };
  }
  return { code: 'UNKNOWN_ERROR', message: 'An unexpected error occurred' };
}
