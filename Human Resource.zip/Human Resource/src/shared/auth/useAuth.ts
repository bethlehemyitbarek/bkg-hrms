import { useCallback, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../app/store';
import { loginSuccess, logout as logoutAction, setUser } from '../../app/store/slices/authSlice';
import { supabase } from '@/db/supabase';

export function useAuth() {
  const dispatch = useDispatch();
  const auth = useSelector((state: RootState) => state.auth);
  const [loading, setLoading] = useState(false);

  // Sync Supabase session to Redux on mount
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        const user = {
          id: session.user.id,
          username: session.user.email?.split('@')[0] || '',
          email: session.user.email || '',
          roles: (session.user.user_metadata?.roles as string[]) || ['employee'],
        };
        dispatch(loginSuccess({ token: session.access_token, user }));
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        const user = {
          id: session.user.id,
          username: session.user.email?.split('@')[0] || '',
          email: session.user.email || '',
          roles: (session.user.user_metadata?.roles as string[]) || ['employee'],
        };
        dispatch(loginSuccess({ token: session.access_token, user }));
      } else {
        dispatch(logoutAction());
      }
    });

    return () => subscription.unsubscribe();
  }, [dispatch]);

  const login = useCallback(
    async (email: string, password: string) => {
      setLoading(true);
      try {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        const user = {
          id: data.user.id,
          username: data.user.email?.split('@')[0] || '',
          email: data.user.email || '',
          roles: (data.user.user_metadata?.roles as string[]) || ['employee'],
        };
        dispatch(loginSuccess({ token: data.session.access_token, user }));
        return user;
      } finally {
        setLoading(false);
      }
    },
    [dispatch]
  );

  const logout = useCallback(async () => {
    await supabase.auth.signOut();
    dispatch(logoutAction());
    window.location.href = '/login';
  }, [dispatch]);

  return {
    isAuthenticated: auth.isAuthenticated,
    user: auth.user,
    token: auth.token,
    login,
    logout,
    loading,
    setUser: (user: Parameters<typeof setUser>[0]) => dispatch(setUser(user)),
  };
}
