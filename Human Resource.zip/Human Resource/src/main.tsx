import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./app/App.tsx";
import { Toaster } from "@/components/ui/sonner";

createRoot(document.getElementById("root")!).render(
  <>
    <App />
    <Toaster position="top-right" richColors />
  </>
);
