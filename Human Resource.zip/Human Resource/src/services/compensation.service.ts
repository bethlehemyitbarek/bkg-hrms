import { supabase } from '@/db/supabase';
import type {
  AllowanceType,
  CompensationStructure,
  CompensationComponent,
  EmployeeCompensation,
} from '@/types/database.types';

const DEFAULT_TENANT = '00000000-0000-0000-0000-000000000001';

// ── AllowanceType ─────────────────────────────────────────────────────

export const allowanceTypeService = {
  async list(filters: { category?: string; is_active?: number } = {}): Promise<AllowanceType[]> {
    let q = supabase
      .from('allowance_types')
      .select('*')
      .eq('is_deleted', 0)
      .order('allowance_name');
    if (filters.category) q = q.eq('allowance_category', filters.category);
    if (filters.is_active !== undefined) q = q.eq('is_active', filters.is_active);
    const { data, error } = await q;
    if (error) throw error;
    return (data || []) as AllowanceType[];
  },

  async getById(allowance_type_id: string): Promise<AllowanceType | null> {
    const { data, error } = await supabase
      .from('allowance_types')
      .select('*')
      .eq('allowance_type_id', allowance_type_id)
      .maybeSingle();
    if (error) throw error;
    return data as AllowanceType | null;
  },

  async create(payload: Omit<AllowanceType, 'row_id' | 'allowance_type_id' | 'created_at' | 'updated_at'>): Promise<void> {
    const { error } = await supabase.from('allowance_types').insert({
      ...payload,
      tenant_id: payload.tenant_id || DEFAULT_TENANT,
    });
    if (error) throw error;
  },

  async update(allowance_type_id: string, payload: Partial<AllowanceType>): Promise<void> {
    const { error } = await supabase
      .from('allowance_types')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('allowance_type_id', allowance_type_id);
    if (error) throw error;
  },

  async softDelete(allowance_type_id: string): Promise<void> {
    const { error } = await supabase
      .from('allowance_types')
      .update({ is_deleted: 1, is_active: 0, updated_at: new Date().toISOString() })
      .eq('allowance_type_id', allowance_type_id);
    if (error) throw error;
  },
};

// ── CompensationStructure ─────────────────────────────────────────────

export const compensationStructureService = {
  async list(filters: { structure_type?: string; is_active?: number } = {}): Promise<CompensationStructure[]> {
    let q = supabase
      .from('compensation_structures')
      .select('*')
      .eq('is_deleted', 0)
      .order('structure_name');
    if (filters.structure_type) q = q.eq('structure_type', filters.structure_type);
    if (filters.is_active !== undefined) q = q.eq('is_active', filters.is_active);
    const { data, error } = await q;
    if (error) throw error;
    return (data || []) as CompensationStructure[];
  },

  async getById(structure_id: string): Promise<CompensationStructure | null> {
    const { data, error } = await supabase
      .from('compensation_structures')
      .select('*, components:compensation_components(*)')
      .eq('structure_id', structure_id)
      .maybeSingle();
    if (error) throw error;
    return data as CompensationStructure | null;
  },

  async create(payload: Omit<CompensationStructure, 'row_id' | 'structure_id' | 'created_at' | 'updated_at' | 'components'>): Promise<void> {
    const { error } = await supabase.from('compensation_structures').insert({
      ...payload,
      tenant_id: payload.tenant_id || DEFAULT_TENANT,
    });
    if (error) throw error;
  },

  async update(structure_id: string, payload: Partial<Omit<CompensationStructure, 'components'>>): Promise<void> {
    const { error } = await supabase
      .from('compensation_structures')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('structure_id', structure_id);
    if (error) throw error;
  },

  async softDelete(structure_id: string): Promise<void> {
    const { error } = await supabase
      .from('compensation_structures')
      .update({ is_deleted: 1, is_active: 0, updated_at: new Date().toISOString() })
      .eq('structure_id', structure_id);
    if (error) throw error;
  },
};

// ── CompensationComponent ─────────────────────────────────────────────

export const compensationComponentService = {
  async listByStructure(structure_id: string): Promise<CompensationComponent[]> {
    const { data, error } = await supabase
      .from('compensation_components')
      .select('*')
      .eq('structure_id', structure_id)
      .eq('is_deleted', 0)
      .order('display_order', { ascending: true })
      .order('component_name');
    if (error) throw error;
    return (data || []) as CompensationComponent[];
  },

  async create(payload: Omit<CompensationComponent, 'row_id' | 'component_id' | 'created_at' | 'updated_at'>): Promise<void> {
    const { error } = await supabase.from('compensation_components').insert({
      ...payload,
      tenant_id: payload.tenant_id || DEFAULT_TENANT,
    });
    if (error) throw error;
  },

  async update(component_id: string, payload: Partial<CompensationComponent>): Promise<void> {
    const { error } = await supabase
      .from('compensation_components')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('component_id', component_id);
    if (error) throw error;
  },

  async softDelete(component_id: string): Promise<void> {
    const { error } = await supabase
      .from('compensation_components')
      .update({ is_deleted: 1, is_active: 0, updated_at: new Date().toISOString() })
      .eq('component_id', component_id);
    if (error) throw error;
  },
};

// ── EmployeeCompensation ──────────────────────────────────────────────

export const employeeCompensationService = {
  async listByEmployee(employee_id: string): Promise<EmployeeCompensation[]> {
    const { data, error } = await supabase
      .from('employee_compensations')
      .select('*, employee:employees!employee_compensations_employee_id_fkey(id,first_name,last_name,employee_no), structure:compensation_structures(structure_id,structure_name,structure_code)')
      .eq('employee_id', employee_id)
      .eq('is_deleted', 0)
      .order('effective_from', { ascending: false });
    if (error) throw error;
    return (data || []) as EmployeeCompensation[];
  },

  async listAll(filters: { is_active?: number; is_current?: number } = {}): Promise<EmployeeCompensation[]> {
    let q = supabase
      .from('employee_compensations')
      .select('*, employee:employees!employee_compensations_employee_id_fkey(id,first_name,last_name,employee_no), structure:compensation_structures(structure_id,structure_name,structure_code)')
      .eq('is_deleted', 0)
      .order('effective_from', { ascending: false });
    if (filters.is_active !== undefined) q = q.eq('is_active', filters.is_active);
    if (filters.is_current !== undefined) q = q.eq('is_current', filters.is_current);
    const { data, error } = await q;
    if (error) throw error;
    return (data || []) as EmployeeCompensation[];
  },

  async assign(payload: Omit<EmployeeCompensation, 'row_id' | 'compensation_id' | 'created_at' | 'updated_at' | 'employee' | 'structure'>): Promise<void> {
    // Expire previous active record for this employee
    await supabase
      .from('employee_compensations')
      .update({ is_current: 0, is_active: 0, effective_to: payload.effective_from, updated_at: new Date().toISOString() })
      .eq('employee_id', payload.employee_id)
      .eq('is_current', 1)
      .eq('is_deleted', 0);

    const { error } = await supabase.from('employee_compensations').insert({
      ...payload,
      tenant_id: payload.tenant_id || DEFAULT_TENANT,
      is_current: 1,
      is_active: 1,
    });
    if (error) throw error;
  },

  async update(compensation_id: string, payload: Partial<EmployeeCompensation>): Promise<void> {
    const { error } = await supabase
      .from('employee_compensations')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('compensation_id', compensation_id);
    if (error) throw error;
  },

  async softDelete(compensation_id: string): Promise<void> {
    const { error } = await supabase
      .from('employee_compensations')
      .update({ is_deleted: 1, is_active: 0, updated_at: new Date().toISOString() })
      .eq('compensation_id', compensation_id);
    if (error) throw error;
  },
};
