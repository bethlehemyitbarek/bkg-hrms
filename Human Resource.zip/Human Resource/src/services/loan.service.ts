import { supabase } from '@/db/supabase';
import type { LoanPolicy, LoanRequest, LoanRepaymentSchedule } from '@/types/database.types';

const TENANT_ID = '00000000-0000-0000-0000-000000000001';

// ── LoanPolicy ─────────────────────────────────────────────────────────────────

export const loanPolicyService = {
  async list(filters: { loan_type?: string; is_active?: number } = {}): Promise<LoanPolicy[]> {
    let q = supabase
      .from('loan_policies')
      .select('*')
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('policy_name', { ascending: true });
    if (filters.loan_type) q = q.eq('loan_type', filters.loan_type);
    if (filters.is_active !== undefined) q = q.eq('is_active', filters.is_active);
    const { data, error } = await q;
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(payload: Omit<LoanPolicy, 'row_id' | 'loan_policy_id' | 'created_at' | 'updated_at'>): Promise<LoanPolicy> {
    const { data, error } = await supabase
      .from('loan_policies')
      .insert({ ...payload, tenant_id: TENANT_ID })
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as LoanPolicy;
  },

  async update(id: string, payload: Partial<LoanPolicy>): Promise<LoanPolicy> {
    const { data, error } = await supabase
      .from('loan_policies')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('loan_policy_id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as LoanPolicy;
  },

  async softDelete(id: string): Promise<void> {
    const { error } = await supabase
      .from('loan_policies')
      .update({ is_deleted: 1, is_active: 0, updated_at: new Date().toISOString() })
      .eq('loan_policy_id', id);
    if (error) throw error;
  },
};

// ── LoanRequest ────────────────────────────────────────────────────────────────

type LoanRequestFilters = {
  employee_id?: string;
  loan_status?: string;
  request_type?: string;
  page?: number;
  pageSize?: number;
};

export const loanRequestService = {
  async list(filters: LoanRequestFilters = {}): Promise<{ data: LoanRequest[]; total: number }> {
    const { employee_id, loan_status, request_type, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let q = supabase
      .from('loan_requests')
      .select('*', { count: 'exact' })
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false })
      .range(from, to);
    if (employee_id) q = q.eq('employee_id', employee_id);
    if (loan_status) q = q.eq('loan_status', loan_status);
    if (request_type) q = q.eq('request_type', request_type);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async getById(id: string): Promise<LoanRequest | null> {
    const { data, error } = await supabase
      .from('loan_requests')
      .select('*')
      .eq('loan_request_id', id)
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async create(payload: Omit<LoanRequest, 'row_id' | 'loan_request_id' | 'created_at' | 'updated_at'>): Promise<LoanRequest> {
    const { data, error } = await supabase
      .from('loan_requests')
      .insert({ ...payload, tenant_id: TENANT_ID })
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as LoanRequest;
  },

  async update(id: string, payload: Partial<LoanRequest>): Promise<LoanRequest> {
    const { data, error } = await supabase
      .from('loan_requests')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('loan_request_id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as LoanRequest;
  },

  async updateStatus(id: string, loan_status: string, extra?: Partial<LoanRequest>): Promise<LoanRequest> {
    return loanRequestService.update(id, { loan_status: loan_status as LoanRequest['loan_status'], ...extra });
  },

  async softDelete(id: string): Promise<void> {
    const { error } = await supabase
      .from('loan_requests')
      .update({ is_deleted: 1, is_active: 0, updated_at: new Date().toISOString() })
      .eq('loan_request_id', id);
    if (error) throw error;
  },
};

// ── LoanRepaymentSchedule ──────────────────────────────────────────────────────

export const loanRepaymentService = {
  async listByLoan(loanRequestId: string): Promise<LoanRepaymentSchedule[]> {
    const { data, error } = await supabase
      .from('loan_repayment_schedules')
      .select('*')
      .eq('loan_request_id', loanRequestId)
      .eq('is_deleted', 0)
      .order('installment_number', { ascending: true });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(payload: Omit<LoanRepaymentSchedule, 'row_id' | 'schedule_id' | 'created_at' | 'updated_at'>): Promise<LoanRepaymentSchedule> {
    const { data, error } = await supabase
      .from('loan_repayment_schedules')
      .insert({ ...payload, tenant_id: TENANT_ID })
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as LoanRepaymentSchedule;
  },

  async bulkCreate(schedules: Omit<LoanRepaymentSchedule, 'row_id' | 'schedule_id' | 'created_at' | 'updated_at'>[]): Promise<void> {
    const rows = schedules.map(s => ({ ...s, tenant_id: TENANT_ID }));
    const { error } = await supabase.from('loan_repayment_schedules').insert(rows);
    if (error) throw error;
  },

  async update(id: string, payload: Partial<LoanRepaymentSchedule>): Promise<LoanRepaymentSchedule> {
    const { data, error } = await supabase
      .from('loan_repayment_schedules')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('schedule_id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as LoanRepaymentSchedule;
  },

  async markPaid(id: string, paid_amount: number, paid_date: string): Promise<LoanRepaymentSchedule> {
    return loanRepaymentService.update(id, {
      payment_status: 'PAID',
      paid_amount,
      paid_date,
    });
  },
};
