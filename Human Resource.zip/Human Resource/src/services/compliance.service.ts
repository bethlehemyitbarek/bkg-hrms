import { supabase as _supabase } from '@/db/supabase';
import { notificationEngine } from './notification-engine.service';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = _supabase as any;

const TENANT_ID = '00000000-0000-0000-0000-000000000001';
const NOW       = () => new Date().toISOString();

// ── HR Policies ────────────────────────────────────────────────────────────────
export const hrPolicyService = {
  async list(filters: { distribution_status?: string; category?: string; page?: number; pageSize?: number } = {}) {
    const { distribution_status, category, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    let q = db.from('hr_policies')
      .select('*', { count: 'exact' })
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false })
      .range(from, from + pageSize - 1);
    if (distribution_status && distribution_status !== 'all') q = q.eq('distribution_status', distribution_status);
    if (category) q = q.eq('policy_category', category);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await db.from('hr_policies')
      .insert({ ...payload, tenant_id: TENANT_ID, created_at: NOW(), updated_at: NOW() })
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(policy_id: string, payload: Record<string, unknown>) {
    const { data, error } = await db.from('hr_policies')
      .update({ ...payload, updated_at: NOW() })
      .eq('policy_id', policy_id)
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  /** Publish a policy and fire notification engine */
  async publish(policy_id: string) {
    const { data, error } = await db.from('hr_policies')
      .update({ distribution_status: 'PUBLISHED', updated_at: NOW() })
      .eq('policy_id', policy_id)
      .select('*').maybeSingle();
    if (error) throw error;
    if (data) {
      notificationEngine.onPolicyPublished({
        policy_id: data.policy_id,
        policy_title: data.policy_title,
        distribution_scope: data.distribution_scope ?? 'ALL_EMPLOYEES',
        target_criteria: data.target_criteria ?? null,
      });
    }
    return data;
  },

  async delete(policy_id: string) {
    const { error } = await db.from('hr_policies')
      .update({ is_deleted: 1, updated_at: NOW() })
      .eq('policy_id', policy_id);
    if (error) throw error;
  },
};

// ── Policy Acknowledgments ─────────────────────────────────────────────────────
export const policyAckService = {
  async list(policy_id: string) {
    const { data, error } = await db.from('policy_acknowledgments')
      .select('*, employee:employees(id, first_name, last_name, employee_no)')
      .eq('tenant_id', TENANT_ID)
      .eq('policy_id', policy_id)
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async upsert(policy_id: string, employee_id: string) {
    const { data, error } = await db.from('policy_acknowledgments')
      .upsert({
        tenant_id: TENANT_ID, policy_id, employee_id,
        acknowledgment_status: 'ACKNOWLEDGED',
        acknowledged_at: NOW(),
        updated_at: NOW(),
      }, { onConflict: 'tenant_id,policy_id,employee_id' })
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// ── Disciplinary Cases ─────────────────────────────────────────────────────────
export const disciplinaryCaseService = {
  async list(filters: { employee_id?: string; page?: number; pageSize?: number } = {}) {
    const { employee_id, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    let q = db.from('disciplinary_cases')
      .select('*, employee:employees(id, first_name, last_name, employee_no)', { count: 'exact' })
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false })
      .range(from, from + pageSize - 1);
    if (employee_id) q = q.eq('employee_id', employee_id);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await db.from('disciplinary_cases')
      .insert({ ...payload, tenant_id: TENANT_ID, created_at: NOW(), updated_at: NOW() })
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async delete(disciplinary_case_id: string) {
    const { error } = await db.from('disciplinary_cases')
      .update({ is_deleted: 1, updated_at: NOW() })
      .eq('disciplinary_case_id', disciplinary_case_id);
    if (error) throw error;
  },
};

// ── Disciplinary Actions ───────────────────────────────────────────────────────
export const disciplinaryActionService = {
  async list(filters: { case_id?: string; employee_id?: string; case_status?: string; page?: number; pageSize?: number } = {}) {
    const { case_id, employee_id, case_status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    let q = db.from('disciplinary_actions')
      .select('*, employee:employees(id, first_name, last_name, employee_no)', { count: 'exact' })
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('action_date', { ascending: false })
      .range(from, from + pageSize - 1);
    if (case_id)    q = q.eq('discipline_case_id', case_id);
    if (employee_id) q = q.eq('employee_id', employee_id);
    if (case_status && case_status !== 'all') q = q.eq('case_status', case_status);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await db.from('disciplinary_actions')
      .insert({ ...payload, tenant_id: TENANT_ID, created_at: NOW(), updated_at: NOW() })
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(disciplinary_action_id: string, payload: Record<string, unknown>) {
    const { data, error } = await db.from('disciplinary_actions')
      .update({ ...payload, updated_at: NOW() })
      .eq('disciplinary_action_id', disciplinary_action_id)
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async delete(disciplinary_action_id: string) {
    const { error } = await db.from('disciplinary_actions')
      .update({ is_deleted: 1, updated_at: NOW() })
      .eq('disciplinary_action_id', disciplinary_action_id);
    if (error) throw error;
  },
};

// ── Grievance Cases ────────────────────────────────────────────────────────────
export const grievanceCaseService = {
  async list(filters: { workflow_stage?: string; employee_id?: string; page?: number; pageSize?: number } = {}) {
    const { workflow_stage, employee_id, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    let q = db.from('grievance_cases')
      .select('*, employee:employees(id, first_name, last_name, employee_no)', { count: 'exact' })
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('submission_date', { ascending: false })
      .range(from, from + pageSize - 1);
    if (workflow_stage && workflow_stage !== 'all') q = q.eq('workflow_stage', workflow_stage);
    if (employee_id) q = q.eq('employee_id', employee_id);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await db.from('grievance_cases')
      .insert({ ...payload, tenant_id: TENANT_ID, created_at: NOW(), updated_at: NOW() })
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(grievance_id: string, payload: Record<string, unknown>) {
    const { data, error } = await db.from('grievance_cases')
      .update({ ...payload, updated_at: NOW() })
      .eq('grievance_id', grievance_id)
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async delete(grievance_id: string) {
    const { error } = await db.from('grievance_cases')
      .update({ is_deleted: 1, updated_at: NOW() })
      .eq('grievance_id', grievance_id);
    if (error) throw error;
  },
};

// ── Data Retention Policies ────────────────────────────────────────────────────
export const dataRetentionService = {
  async list(filters: { execution_status?: string; page?: number; pageSize?: number } = {}) {
    const { execution_status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    let q = db.from('data_retention_policies')
      .select('*', { count: 'exact' })
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false })
      .range(from, from + pageSize - 1);
    if (execution_status && execution_status !== 'all') q = q.eq('execution_status', execution_status);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await db.from('data_retention_policies')
      .insert({ ...payload, tenant_id: TENANT_ID, created_at: NOW(), updated_at: NOW() })
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(retention_period_id: string, payload: Record<string, unknown>) {
    const { data, error } = await db.from('data_retention_policies')
      .update({ ...payload, updated_at: NOW() })
      .eq('retention_period_id', retention_period_id)
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async delete(retention_period_id: string) {
    const { error } = await db.from('data_retention_policies')
      .update({ is_deleted: 1, updated_at: NOW() })
      .eq('retention_period_id', retention_period_id);
    if (error) throw error;
  },
};

// ── DSAR (Data Subject Access Requests) ───────────────────────────────────────
export const dsarService = {
  async list(filters: { request_status?: string; employee_id?: string; page?: number; pageSize?: number } = {}) {
    const { request_status, employee_id, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    let q = db.from('data_subject_access_requests')
      .select('*, employee:employees(id, first_name, last_name, employee_no)', { count: 'exact' })
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('request_date', { ascending: false })
      .range(from, from + pageSize - 1);
    if (request_status && request_status !== 'all') q = q.eq('request_status', request_status);
    if (employee_id) q = q.eq('employee_id', employee_id);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await db.from('data_subject_access_requests')
      .insert({ ...payload, tenant_id: TENANT_ID, created_at: NOW(), updated_at: NOW() })
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(dsar_id: string, payload: Record<string, unknown>) {
    const { data, error } = await db.from('data_subject_access_requests')
      .update({ ...payload, updated_at: NOW() })
      .eq('dsar_id', dsar_id)
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async delete(dsar_id: string) {
    const { error } = await db.from('data_subject_access_requests')
      .update({ is_deleted: 1, updated_at: NOW() })
      .eq('dsar_id', dsar_id);
    if (error) throw error;
  },

  /** HR Admin: update DSAR status with optional response notes */
  async adminUpdateStatus(
    dsar_id: string,
    new_status: string,
    opts: { response_notes?: string; completion_date?: string } = {}
  ) {
    const patch: Record<string, unknown> = { request_status: new_status, updated_at: NOW() };
    if (opts.response_notes !== undefined) patch.response_notes = opts.response_notes;
    if (new_status === 'COMPLETED') patch.completion_date = opts.completion_date ?? new Date().toISOString().split('T')[0];
    const { data, error } = await db.from('data_subject_access_requests')
      .update(patch)
      .eq('dsar_id', dsar_id)
      .select('*, employee:employees(id, first_name, last_name, email)')
      .maybeSingle();
    if (error) throw error;
    // Fire notification engine
    if (data) {
      notificationEngine.onDsarStatusUpdated({
        dsar_id: data.dsar_id,
        employee_id: data.employee_id,
        request_status: new_status,
        request_type: data.request_type,
      });
    }
    return data;
  },

  /** HR Admin: add/update response notes without changing status */
  async adminSaveNotes(dsar_id: string, response_notes: string) {
    const { data, error } = await db.from('data_subject_access_requests')
      .update({ response_notes, updated_at: NOW() })
      .eq('dsar_id', dsar_id)
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};
