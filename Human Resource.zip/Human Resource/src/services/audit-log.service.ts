import { supabase as _supabase } from '@/db/supabase';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = _supabase as any;

const TENANT_ID = '00000000-0000-0000-0000-000000000001';

export const auditLogService = {
  async list(filters: {
    module?: string;
    action_type?: string;
    entity_type?: string;
    performed_by?: string;
    date_from?: string;
    date_to?: string;
    page?: number;
    pageSize?: number;
  } = {}) {
    const { module, action_type, entity_type, performed_by, date_from, date_to, page = 1, pageSize = 50 } = filters;
    const from = (page - 1) * pageSize;
    let q = db.from('audit_logs')
      .select(
        '*, performer:profiles(id,full_name,email)',
        { count: 'exact' }
      )
      .eq('tenant_id', TENANT_ID)
      .order('event_timestamp', { ascending: false })
      .range(from, from + pageSize - 1);
    if (module && module !== 'all') q = q.eq('module', module);
    if (action_type && action_type !== 'all') q = q.eq('action_type', action_type);
    if (entity_type) q = q.ilike('entity_type', `%${entity_type}%`);
    if (performed_by) q = q.eq('performed_by', performed_by);
    if (date_from) q = q.gte('event_timestamp', date_from);
    if (date_to) q = q.lte('event_timestamp', date_to + 'T23:59:59Z');
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async log(payload: {
    module: string;
    entity_type: string;
    entity_id?: string;
    employee_id?: string;
    action_type: string;
    old_value?: unknown;
    new_value?: unknown;
    performed_by?: string;
    reason?: string;
  }) {
    const { error } = await db.from('audit_logs').insert({
      ...payload,
      tenant_id: TENANT_ID,
      event_timestamp: new Date().toISOString(),
      created_at: new Date().toISOString(),
    });
    if (error) console.warn('Audit log write failed:', error.message);
  },
};
