import { supabase as _supabase } from '@/db/supabase';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = _supabase as any;

const TENANT_ID = '00000000-0000-0000-0000-000000000001';
const NOW = () => new Date().toISOString();

// ── Document Categories ────────────────────────────────────────────────────────
export const documentCategoryService = {
  async list() {
    const { data, error } = await db
      .from('document_categories')
      .select('*')
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('category_name');
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await db
      .from('document_categories')
      .insert({ ...payload, tenant_id: TENANT_ID, created_at: NOW(), updated_at: NOW() })
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(category_id: string, payload: Record<string, unknown>) {
    const { data, error } = await db
      .from('document_categories')
      .update({ ...payload, updated_at: NOW() })
      .eq('category_id', category_id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async delete(category_id: string) {
    const { error } = await db
      .from('document_categories')
      .update({ is_deleted: 1, updated_at: NOW() })
      .eq('category_id', category_id);
    if (error) throw error;
  },
};

// ── Document Type Configs ──────────────────────────────────────────────────────
export const documentTypeConfigService = {
  async list(filters: { page?: number; pageSize?: number } = {}) {
    const { page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const { data, error, count } = await db
      .from('document_type_configs')
      .select('*', { count: 'exact' })
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('type_name')
      .range(from, from + pageSize - 1);
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await db
      .from('document_type_configs')
      .insert({ ...payload, tenant_id: TENANT_ID, created_at: NOW(), updated_at: NOW() })
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(document_type_id: string, payload: Record<string, unknown>) {
    const { data, error } = await db
      .from('document_type_configs')
      .update({ ...payload, updated_at: NOW() })
      .eq('document_type_id', document_type_id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async delete(document_type_id: string) {
    const { error } = await db
      .from('document_type_configs')
      .update({ is_deleted: 1, updated_at: NOW() })
      .eq('document_type_id', document_type_id);
    if (error) throw error;
  },
};

// ── HR Documents (unified document store) ─────────────────────────────────────
export const hrDocumentService = {
  async list(filters: {
    owner_type?: string;
    owner_id?: string;
    category_id?: string;
    review_status?: string;
    page?: number;
    pageSize?: number;
  } = {}) {
    const { owner_type, owner_id, category_id, review_status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    let q = db
      .from('documents')
      .select(
        '*, category:document_categories(category_id, category_name), doc_type:document_type_configs(document_type_id, type_name)',
        { count: 'exact' }
      )
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false })
      .range(from, from + pageSize - 1);
    if (owner_type && owner_type !== 'all') q = q.eq('owner_type', owner_type);
    if (owner_id) q = q.eq('owner_id', owner_id);
    if (category_id && category_id !== 'all') q = q.eq('category_id', category_id);
    if (review_status && review_status !== 'all') q = q.eq('review_status', review_status);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async listVersions(document_id: string) {
    const { data, error } = await db
      .from('documents')
      .select('*')
      .eq('tenant_id', TENANT_ID)
      .or(`document_id.eq.${document_id},previous_version.eq.${document_id}`)
      .order('version_no', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await db
      .from('documents')
      .insert({ ...payload, tenant_id: TENANT_ID, created_at: NOW(), updated_at: NOW() })
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(document_id: string, payload: Record<string, unknown>) {
    const { data, error } = await db
      .from('documents')
      .update({ ...payload, updated_at: NOW() })
      .eq('document_id', document_id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async delete(document_id: string) {
    const { error } = await db
      .from('documents')
      .update({ is_deleted: 1, updated_at: NOW() })
      .eq('document_id', document_id);
    if (error) throw error;
  },
};
