import { supabase as _sb } from '@/db/supabase';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = _sb as any;

export type NotifPref = {
  id: string;
  user_id: string;
  module: string;
  enabled: boolean;
  updated_at: string;
};

/** All modules users can toggle — must match `module` values used in notifications table */
export const ALL_NOTIF_MODULES = [
  { key: 'dsar',        label: 'DSAR / Compliance',         description: 'Notifications about your data access requests and status changes.' },
  { key: 'timesheet',   label: 'Timesheets',                description: 'Timesheet approvals, rejections, and unlock alerts.' },
  { key: 'leave',       label: 'Leave Requests',            description: 'Leave approvals, rejections, and balance updates.' },
  { key: 'payroll',     label: 'Payroll',                   description: 'Payslip availability and payroll processing updates.' },
  { key: 'performance', label: 'Performance Reviews',       description: 'Performance cycle reminders and review submissions.' },
  { key: 'training',    label: 'Training & Enrollments',    description: 'Training session reminders and enrollment confirmations.' },
  { key: 'documents',   label: 'Documents & Policies',      description: 'New policies published and document expiry reminders.' },
  { key: 'expense',     label: 'Expense Claims',            description: 'Expense claim approvals and rejections.' },
] as const;

export type NotifModuleKey = typeof ALL_NOTIF_MODULES[number]['key'];

export const notifPrefsService = {
  /** Load current user's preferences. Missing rows default to enabled=true. */
  async list(): Promise<Record<NotifModuleKey, boolean>> {
    try {
      const { data: authData } = await db.auth.getUser();
      const uid = authData?.user?.id;
      if (!uid) throw new Error('Not authenticated');

      const { data, error } = await db
        .from('notification_preferences')
        .select('module, enabled')
        .eq('user_id', uid);
      if (error) throw error;

      // Build map: module → enabled; anything not in DB defaults to true
      const map: Record<string, boolean> = {};
      for (const row of (data || [])) map[row.module as string] = row.enabled as boolean;

      const result = {} as Record<NotifModuleKey, boolean>;
      for (const m of ALL_NOTIF_MODULES) {
        result[m.key] = map[m.key] !== undefined ? map[m.key] : true;
      }
      return result;
    } catch {
      // On error, return all enabled
      const result = {} as Record<NotifModuleKey, boolean>;
      for (const m of ALL_NOTIF_MODULES) result[m.key] = true;
      return result;
    }
  },

  /** Upsert a single preference toggle */
  async set(module: string, enabled: boolean): Promise<void> {
    const { data: authData } = await db.auth.getUser();
    const uid = authData?.user?.id;
    if (!uid) throw new Error('Not authenticated');

    const { error } = await db.from('notification_preferences').upsert(
      { user_id: uid, module, enabled, updated_at: new Date().toISOString() },
      { onConflict: 'user_id,module' }
    );
    if (error) throw error;
  },

  /** Save all preferences at once */
  async saveAll(prefs: Record<string, boolean>): Promise<void> {
    const { data: authData } = await db.auth.getUser();
    const uid = authData?.user?.id;
    if (!uid) throw new Error('Not authenticated');

    const rows = Object.entries(prefs).map(([module, enabled]) => ({
      user_id: uid, module, enabled, updated_at: new Date().toISOString(),
    }));
    const { error } = await db.from('notification_preferences')
      .upsert(rows, { onConflict: 'user_id,module' });
    if (error) throw error;
  },
};
