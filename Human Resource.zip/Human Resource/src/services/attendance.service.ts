/* eslint-disable @typescript-eslint/no-explicit-any */
import { supabase as _supabase } from "@/db/supabase";
const supabase = _supabase as any;
import type { AttendanceRecord, LeaveRequest, LeaveType, LeaveBalance } from '@/types/database.types';

// --- Attendance ---
export const attendanceService = {
  async list(filters: { employee_id?: string; start_date?: string; end_date?: string; status?: string; page?: number; pageSize?: number } = {}) {
    const { employee_id, start_date, end_date, status, page = 1, pageSize = 30 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase
      .from('attendance_records')
      .select('*, employee:employees!attendance_records_employee_id_fkey(id, first_name, last_name, employee_no)', { count: 'exact' });

    if (employee_id) query = query.eq('employee_id', employee_id);
    if (start_date) query = query.gte('attendance_date', start_date);
    if (end_date) query = query.lte('attendance_date', end_date);
    if (status) query = query.eq('status', status);

    const { data, error, count } = await query.order('attendance_date', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: (data as AttendanceRecord[]) || [], total: count || 0, page, pageSize };
  },

  async checkIn(employee_id: string, location?: string): Promise<AttendanceRecord> {
    const today = new Date().toISOString().split('T')[0];
    const { data: existing } = await supabase
      .from('attendance_records')
      .select('*')
      .eq('employee_id', employee_id)
      .eq('attendance_date', today)
      .maybeSingle();

    if (existing) {
      const { data, error } = await supabase
        .from('attendance_records')
        .update({ check_in: new Date().toISOString(), status: 'present', location, updated_at: new Date().toISOString() })
        .eq('id', existing.id)
        .select('*')
        .maybeSingle();
      if (error) throw error;
      return data as AttendanceRecord;
    }

    const { data, error } = await supabase
      .from('attendance_records')
      .insert({ employee_id, attendance_date: today, check_in: new Date().toISOString(), status: 'present', location })
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as AttendanceRecord;
  },

  async checkOut(employee_id: string): Promise<AttendanceRecord> {
    const today = new Date().toISOString().split('T')[0];
    const { data: existing, error: fetchError } = await supabase
      .from('attendance_records')
      .select('*')
      .eq('employee_id', employee_id)
      .eq('attendance_date', today)
      .maybeSingle();
    if (fetchError) throw fetchError;
    if (!existing) throw new Error('No check-in record found for today');

    const checkOut = new Date().toISOString();
    const checkIn = existing.check_in ? new Date(existing.check_in) : new Date();
    const workMinutes = Math.floor((new Date(checkOut).getTime() - checkIn.getTime()) / 60000);

    const { data, error } = await supabase
      .from('attendance_records')
      .update({ check_out: checkOut, work_minutes: workMinutes, updated_at: new Date().toISOString() })
      .eq('id', existing.id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as AttendanceRecord;
  },

  async create(payload: Partial<AttendanceRecord>): Promise<AttendanceRecord> {
    const { data, error } = await supabase.from('attendance_records').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as AttendanceRecord;
  },

  async update(id: string, payload: Partial<AttendanceRecord>): Promise<AttendanceRecord> {
    const { data, error } = await supabase
      .from('attendance_records')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as AttendanceRecord;
  },

  async getStats(start_date?: string, end_date?: string) {
    let query = supabase.from('attendance_records').select('status');
    if (start_date) query = query.gte('attendance_date', start_date);
    if (end_date) query = query.lte('attendance_date', end_date);
    const { data, error } = await query;
    if (error) throw error;
    const rows = data || [];
    return {
      total: rows.length,
      present: rows.filter((r: any) => r.status === 'present').length,
      absent: rows.filter((r: any) => r.status === 'absent').length,
      late: rows.filter((r: any) => r.status === 'late').length,
      on_leave: rows.filter((r: any) => r.status === 'on_leave').length,
      remote: rows.filter((r: any) => r.status === 'remote').length,
    };
  },
};

// --- Leave ---
export const leaveService = {
  async listTypes(): Promise<LeaveType[]> {
    const { data, error } = await supabase.from('leave_types').select('*').eq('is_active', true).order('name');
    if (error) throw error;
    return (data as LeaveType[]) || [];
  },

  async listRequests(filters: { employee_id?: string; status?: string; year?: number; page?: number; pageSize?: number } = {}) {
    const { employee_id, status, year, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase
      .from('leave_requests')
      .select('*, employee:employees!leave_requests_employee_id_fkey(id, first_name, last_name, employee_no), leave_type:leave_types(id, code, name)', { count: 'exact' });

    if (employee_id) query = query.eq('employee_id', employee_id);
    if (status) query = query.eq('status', status);
    if (year) {
      query = query.gte('start_date', `${year}-01-01`).lte('start_date', `${year}-12-31`);
    }

    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: (data as LeaveRequest[]) || [], total: count || 0, page, pageSize };
  },

  async getBalances(employee_id: string, year?: number): Promise<LeaveBalance[]> {
    const currentYear = year || new Date().getFullYear();
    const { data, error } = await supabase
      .from('leave_balances')
      .select('*, leave_type:leave_types(id, code, name, is_paid)')
      .eq('employee_id', employee_id)
      .eq('year', currentYear);
    if (error) throw error;
    return (data as LeaveBalance[]) || [];
  },

  async createRequest(payload: Partial<LeaveRequest>): Promise<LeaveRequest> {
    const { data, error } = await supabase.from('leave_requests').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as LeaveRequest;
  },

  async approveRequest(id: string): Promise<LeaveRequest> {
    const { data: { user } } = await (supabase as any).auth.getUser();
    const payload: Record<string, unknown> = {
      status: 'approved',
      approved_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    if (user?.id) payload.approved_by = user.id;
    const { data, error } = await supabase
      .from('leave_requests')
      .update(payload)
      .eq('id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as LeaveRequest;
  },

  async rejectRequest(id: string, rejection_reason: string): Promise<LeaveRequest> {
    const { data, error } = await supabase
      .from('leave_requests')
      .update({ status: 'rejected', rejection_reason, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as LeaveRequest;
  },

  async cancelRequest(id: string): Promise<void> {
    const { error } = await supabase
      .from('leave_requests')
      .update({ status: 'cancelled', updated_at: new Date().toISOString() })
      .eq('id', id);
    if (error) throw error;
  },

  async updateRequest(id: string, payload: Record<string, unknown>) {
    const { data, error } = await supabase
      .from('leave_requests')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async getStats() {
    const { data, error } = await supabase.from('leave_requests').select('status');
    if (error) throw error;
    const rows = data || [];
    return {
      total: rows.length,
      pending: rows.filter((r: any) => r.status === 'pending').length,
      approved: rows.filter((r: any) => r.status === 'approved').length,
      rejected: rows.filter((r: any) => r.status === 'rejected').length,
    };
  },
};

// Convenience method used by MSS / manager approval flows
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function patchLeaveRequest(id: string, payload: Record<string, any>) {
  const { data, error } = await supabase
    .from('leave_requests')
    .update({ ...payload, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select('*')
    .maybeSingle();
  if (error) throw error;
  return data;
}
