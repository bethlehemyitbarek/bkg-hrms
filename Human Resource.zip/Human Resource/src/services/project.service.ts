import { supabase as _supabase } from '@/db/supabase';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = _supabase as any;

const TENANT_ID = '00000000-0000-0000-0000-000000000001';
const NOW = () => new Date().toISOString();

export const projectService = {
  async list(filters: { project_status?: string; page?: number; pageSize?: number } = {}) {
    const { project_status, page = 1, pageSize = 50 } = filters;
    const from = (page - 1) * pageSize;
    let q = db.from('projects')
      .select('*, manager:employees!projects_manager_id_fkey(id,first_name,last_name), department:departments!projects_department_id_fkey(id,name)', { count: 'exact' })
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false })
      .range(from, from + pageSize - 1);
    if (project_status && project_status !== 'all') q = q.eq('project_status', project_status);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async listAll() {
    const { data, error } = await db.from('projects')
      .select('id, project_id, project_name, project_code, project_status')
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('project_name', { ascending: true });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(payload: Record<string, unknown>) {
    const { error } = await db.from('projects')
      .insert({ ...payload, tenant_id: TENANT_ID, created_at: NOW(), updated_at: NOW() });
    if (error) throw error;
  },

  async update(id: string, payload: Record<string, unknown>) {
    const { error } = await db.from('projects')
      .update({ ...payload, updated_at: NOW() })
      .eq('id', id);
    if (error) throw error;
  },

  async delete(id: string) {
    const { error } = await db.from('projects')
      .update({ is_deleted: 1, updated_at: NOW() })
      .eq('id', id);
    if (error) throw error;
  },
};

export const projectTaskService = {
  async listByProject(project_id: string) {
    const { data, error } = await db.from('project_tasks')
      .select('*, assigned_employee:employees!project_tasks_assigned_employee_id_fkey(id,first_name,last_name)')
      .eq('tenant_id', TENANT_ID)
      .eq('project_id', project_id)
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async listByEmployee(employee_id: string) {
    const { data, error } = await db.from('project_tasks')
      .select('*, project:projects!project_tasks_project_id_fkey(id,project_name,project_code)')
      .eq('tenant_id', TENANT_ID)
      .eq('assigned_employee_id', employee_id)
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(payload: Record<string, unknown>) {
    const { error } = await db.from('project_tasks')
      .insert({ ...payload, tenant_id: TENANT_ID, created_at: NOW(), updated_at: NOW() });
    if (error) throw error;
  },

  async update(id: string, payload: Record<string, unknown>) {
    const { error } = await db.from('project_tasks')
      .update({ ...payload, updated_at: NOW() })
      .eq('id', id);
    if (error) throw error;
  },

  async delete(id: string) {
    const { error } = await db.from('project_tasks')
      .update({ is_deleted: 1, updated_at: NOW() })
      .eq('id', id);
    if (error) throw error;
  },
};

