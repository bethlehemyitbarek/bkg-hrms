/* eslint-disable @typescript-eslint/no-explicit-any */
import { supabase as _supabase } from "@/db/supabase";
const supabase = _supabase as any;
import type { Employee } from '@/types/database.types';

export interface EmployeeFilters {
  search?: string;
  department_id?: string;
  employment_status?: string;
  employment_type?: string;
  location_id?: string;
  page?: number;
  pageSize?: number;
}

export interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

const EMPLOYEE_SELECT = `
  *,
  department:departments(id, code, name),
  position:positions(id, code, title),
  location:locations(id, code, name),
  job_grade:job_grades(id, code, name, level),
  manager:employees!manager_id(id, first_name, last_name, employee_no),
  employment_details(id, base_salary, salary_currency, overtime_eligible, work_hours_per_day)
`;

export const employeeService = {
  async list(filters: EmployeeFilters = {}): Promise<PaginatedResult<Employee>> {
    const { search, department_id, employment_status, employment_type, location_id, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase.from('employees').select(EMPLOYEE_SELECT, { count: 'exact' });

    if (search) {
      query = query.or(`first_name.ilike.%${search}%,last_name.ilike.%${search}%,employee_no.ilike.%${search}%,email.ilike.%${search}%`);
    }
    if (department_id) query = query.eq('department_id', department_id);
    if (employment_status) query = query.eq('employment_status', employment_status);
    if (employment_type) query = query.eq('employment_type', employment_type);
    if (location_id) query = query.eq('location_id', location_id);

    const { data, error, count } = await query
      .order('created_at', { ascending: false })
      .range(from, to);

    if (error) throw error;

    return {
      data: (data as Employee[]) || [],
      total: count || 0,
      page,
      pageSize,
      totalPages: Math.ceil((count || 0) / pageSize),
    };
  },

  async getById(id: string): Promise<Employee> {
    const { data, error } = await supabase
      .from('employees')
      .select(EMPLOYEE_SELECT)
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('Employee not found');
    return data as Employee;
  },

  async create(payload: Partial<Employee>): Promise<Employee> {
    // Auto-generate employee_no if not provided
    if (!payload.employee_no) {
      const { count } = await supabase.from('employees').select('*', { count: 'exact', head: true });
      payload.employee_no = `EMP-${String((count || 0) + 1).padStart(3, '0')}`;
    }
    const { data, error } = await supabase.from('employees').insert(payload).select(EMPLOYEE_SELECT).maybeSingle();
    if (error) throw error;
    return data as Employee;
  },

  async update(id: string, payload: Partial<Employee>): Promise<Employee> {
    const { data, error } = await supabase
      .from('employees')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select(EMPLOYEE_SELECT)
      .maybeSingle();
    if (error) throw error;
    return data as Employee;
  },

  async deactivate(id: string): Promise<void> {
    const { error } = await supabase
      .from('employees')
      .update({ is_active: false, employment_status: 'inactive', updated_at: new Date().toISOString() })
      .eq('id', id);
    if (error) throw error;
  },

  async getStats() {
    const { data, error } = await supabase
      .from('employees')
      .select('employment_status, employment_type, department_id');
    if (error) throw error;
    const rows = data || [];
    return {
      total: rows.length,
      active: rows.filter((e: any) => e.employment_status === 'active').length,
      probation: rows.filter((e: any) => e.employment_status === 'probation').length,
      on_leave: rows.filter((e: any) => e.employment_status === 'on_leave').length,
      full_time: rows.filter((e: any) => e.employment_type === 'full_time').length,
      contract: rows.filter((e: any) => e.employment_type === 'contract').length,
    };
  },
};
