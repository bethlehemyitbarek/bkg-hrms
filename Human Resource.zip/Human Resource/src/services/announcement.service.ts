import { supabase as _supabase } from '@/db/supabase';
import { notificationEngine } from './notification-engine.service';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = _supabase as any;

const TENANT_ID = '00000000-0000-0000-0000-000000000001';
const NOW = () => new Date().toISOString();

export const announcementService = {
  async list(filters: {
    announcement_status?: string;
    type?: string;
    priority?: string;
    page?: number;
    pageSize?: number;
  } = {}) {
    const { announcement_status, type, priority, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    let q = db.from('announcements')
      .select('*', { count: 'exact' })
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false })
      .range(from, from + pageSize - 1);
    if (announcement_status && announcement_status !== 'all') q = q.eq('announcement_status', announcement_status);
    if (type && type !== 'all') q = q.eq('type', type);
    if (priority && priority !== 'all') q = q.eq('priority', priority);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async listPublished() {
    const now = NOW();
    const { data, error } = await db.from('announcements')
      .select('*')
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .eq('announcement_status', 'PUBLISHED')
      .or(`expiry_date.is.null,expiry_date.gt.${now}`)
      .order('priority', { ascending: false })
      .order('published_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(payload: Record<string, unknown>) {
    const { error } = await db.from('announcements')
      .insert({ ...payload, tenant_id: TENANT_ID, created_at: NOW(), updated_at: NOW() });
    if (error) throw error;
  },

  async update(id: string, payload: Record<string, unknown>) {
    const { error } = await db.from('announcements')
      .update({ ...payload, updated_at: NOW() })
      .eq('id', id);
    if (error) throw error;
  },

  async publish(id: string) {
    const { data, error } = await db.from('announcements')
      .update({ announcement_status: 'PUBLISHED', published_at: NOW(), updated_at: NOW() })
      .eq('id', id)
      .select('*').maybeSingle();
    if (error) throw error;
    // Trigger notification engine — fire and forget
    if (data) {
      notificationEngine.onAnnouncementPublished({
        id: data.id,
        title: data.title,
        targets: data.targets ?? 'ALL',
        target_criteria: data.target_criteria,
        priority: data.priority,
      });
    }
  },

  async archive(id: string) {
    const { error } = await db.from('announcements')
      .update({ announcement_status: 'ARCHIVED', updated_at: NOW() })
      .eq('id', id);
    if (error) throw error;
  },

  async delete(id: string) {
    const { error } = await db.from('announcements')
      .update({ is_deleted: 1, updated_at: NOW() })
      .eq('id', id);
    if (error) throw error;
  },
};
