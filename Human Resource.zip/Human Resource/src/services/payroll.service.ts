/* eslint-disable @typescript-eslint/no-explicit-any */
import { supabase as _supabase } from "@/db/supabase";
const supabase = _supabase as any;
import type { PayrollPeriod, PayrollRecord } from '@/types/database.types';

export const payrollService = {
  async listPeriods(filters: { status?: string; page?: number; pageSize?: number } = {}) {
    const { status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase.from('payroll_periods').select('*', { count: 'exact' });
    if (status) query = query.eq('status', status);

    const { data, error, count } = await query.order('start_date', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: (data as PayrollPeriod[]) || [], total: count || 0, page, pageSize };
  },

  async getPeriod(id: string): Promise<PayrollPeriod> {
    const { data, error } = await supabase.from('payroll_periods').select('*').eq('id', id).maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('Payroll period not found');
    return data as PayrollPeriod;
  },

  async createPeriod(payload: Partial<PayrollPeriod>): Promise<PayrollPeriod> {
    const { data, error } = await supabase.from('payroll_periods').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as PayrollPeriod;
  },

  async updatePeriodStatus(id: string, status: PayrollPeriod['status']): Promise<PayrollPeriod> {
    const { data, error } = await supabase
      .from('payroll_periods')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as PayrollPeriod;
  },

  async updatePeriod(id: string, payload: Partial<PayrollPeriod>): Promise<PayrollPeriod> {
    const { data, error } = await supabase
      .from('payroll_periods')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as PayrollPeriod;
  },

  async listRecords(filters: { period_id?: string; employee_id?: string; payment_status?: string; page?: number; pageSize?: number } = {}) {
    const { period_id, employee_id, payment_status, page = 1, pageSize = 30 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase
      .from('payroll_records')
      .select(
        '*, employee:employees!payroll_records_employee_id_fkey(id, first_name, last_name, employee_no), payroll_period:payroll_periods(id, name, period_code)',
        { count: 'exact' }
      );

    if (period_id) query = query.eq('payroll_period_id', period_id);
    if (employee_id) query = query.eq('employee_id', employee_id);
    if (payment_status) query = query.eq('payment_status', payment_status);

    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: (data as PayrollRecord[]) || [], total: count || 0, page, pageSize };
  },

  async createRecord(payload: Partial<PayrollRecord>): Promise<PayrollRecord> {
    const { data, error } = await supabase.from('payroll_records').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as PayrollRecord;
  },

  async updateRecord(id: string, payload: Partial<PayrollRecord>): Promise<PayrollRecord> {
    const { data, error } = await supabase
      .from('payroll_records')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as PayrollRecord;
  },

  async getPayrollSummary(period_id?: string) {
    let query = supabase.from('payroll_records').select('gross_pay, net_pay, total_deductions, payment_status');
    if (period_id) query = query.eq('payroll_period_id', period_id);
    const { data, error } = await query;
    if (error) throw error;
    const rows = data || [];
    return {
      total_records: rows.length,
      total_gross: rows.reduce((s: any, r: any) => s + (r.gross_pay || 0), 0),
      total_net: rows.reduce((s: any, r: any) => s + (r.net_pay || 0), 0),
      total_deductions: rows.reduce((s: any, r: any) => s + (r.total_deductions || 0), 0),
      paid_count: rows.filter((r: any) => r.payment_status === 'paid').length,
      pending_count: rows.filter((r: any) => r.payment_status === 'pending').length,
    };
  },
};

// ── Payroll Components ──────────────────────────────────────────────
export const payrollComponentService = {
  async list() {
    const { data, error } = await supabase
      .from('payroll_components')
      .select('*')
      .order('component_type', { ascending: true })
      .order('name', { ascending: true });
    if (error) throw error;
    return (data || []) as PayrollComponent[];
  },
  async create(payload: Partial<PayrollComponent>): Promise<PayrollComponent> {
    const { data, error } = await supabase.from('payroll_components').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as PayrollComponent;
  },
  async update(id: string, payload: Partial<PayrollComponent>): Promise<PayrollComponent> {
    const { data, error } = await supabase.from('payroll_components').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data as PayrollComponent;
  },
  async remove(id: string) {
    const { error } = await supabase.from('payroll_components').delete().eq('id', id);
    if (error) throw error;
  },
};

// ── Salary Structures ────────────────────────────────────────────────
export const salaryStructureService = {
  async list() {
    const { data, error } = await supabase
      .from('salary_structures')
      .select('*, salary_structure_components(*, payroll_component:payroll_components(id, name, component_type))')
      .order('name', { ascending: true });
    if (error) throw error;
    return (data || []) as SalaryStructure[];
  },
  async create(payload: Partial<SalaryStructure>): Promise<SalaryStructure> {
    const { data, error } = await supabase.from('salary_structures').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as SalaryStructure;
  },
  async update(id: string, payload: Partial<SalaryStructure>): Promise<SalaryStructure> {
    const { data, error } = await supabase.from('salary_structures').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data as SalaryStructure;
  },
  async remove(id: string) {
    const { error } = await supabase.from('salary_structures').delete().eq('id', id);
    if (error) throw error;
  },
  async addComponent(structure_id: string, component_id: string, amount?: number, rate?: number) {
    const { error } = await supabase.from('salary_structure_components').insert({ salary_structure_id: structure_id, payroll_component_id: component_id, amount: amount ?? null, rate: rate ?? null });
    if (error) throw error;
  },
  async removeComponent(structure_id: string, component_id: string) {
    const { error } = await supabase.from('salary_structure_components').delete().eq('salary_structure_id', structure_id).eq('payroll_component_id', component_id);
    if (error) throw error;
  },
  async listAssignments(structure_id?: string) {
    let q = supabase.from('employee_salary_structures').select('*, employee:employees!employee_salary_structures_employee_id_fkey(id, first_name, last_name, employee_no), salary_structure:salary_structures(id, name)');
    if (structure_id) q = q.eq('salary_structure_id', structure_id);
    const { data, error } = await q.order('effective_date', { ascending: false });
    if (error) throw error;
    return (data || []) as EmployeeSalaryStructure[];
  },
  async assign(employee_id: string, salary_structure_id: string, effective_date: string) {
    const { error } = await supabase.from('employee_salary_structures').upsert({ employee_id, salary_structure_id, effective_date }, { onConflict: 'employee_id' });
    if (error) throw error;
  },
};

// ── Payroll Settings ─────────────────────────────────────────────────
export const payrollSettingsService = {
  async get() {
    const { data, error } = await supabase.from('payroll_settings').select('*').maybeSingle();
    if (error) throw error;
    return data as PayrollSettings | null;
  },
  async upsert(payload: Partial<PayrollSettings>) {
    const existing = await payrollSettingsService.get();
    if (existing) {
      const { error } = await supabase.from('payroll_settings').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', existing.id);
      if (error) throw error;
    } else {
      const { error } = await supabase.from('payroll_settings').insert(payload);
      if (error) throw error;
    }
  },
  async listStatutoryDeductions() {
    const { data, error } = await supabase.from('statutory_deductions').select('*').order('deduction_type', { ascending: true });
    if (error) throw error;
    return (data || []) as StatutoryDeduction[];
  },
  async createDeduction(payload: Partial<StatutoryDeduction>): Promise<StatutoryDeduction> {
    const { data, error } = await supabase.from('statutory_deductions').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as StatutoryDeduction;
  },
  async updateDeduction(id: string, payload: Partial<StatutoryDeduction>): Promise<StatutoryDeduction> {
    const { data, error } = await supabase.from('statutory_deductions').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data as StatutoryDeduction;
  },
  async removeDeduction(id: string) {
    const { error } = await supabase.from('statutory_deductions').delete().eq('id', id);
    if (error) throw error;
  },
};

// Types for the extended payroll domain
export interface PayrollComponent {
  id: string;
  name: string;
  component_type: 'earning' | 'deduction' | 'benefit';
  calculation_method: 'fixed' | 'percentage' | 'formula';
  is_taxable: boolean;
  is_active: boolean;
  description?: string;
  created_at: string;
  updated_at: string;
}

export interface SalaryStructure {
  id: string;
  name: string;
  description?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  salary_structure_components?: SalaryStructureComponent[];
}

export interface SalaryStructureComponent {
  id: string;
  salary_structure_id: string;
  payroll_component_id: string;
  amount?: number;
  rate?: number;
  payroll_component?: Pick<PayrollComponent, 'id' | 'name' | 'component_type'>;
}

export interface EmployeeSalaryStructure {
  id: string;
  employee_id: string;
  salary_structure_id: string;
  effective_date: string;
  employee?: { id: string; first_name: string; last_name: string; employee_no: string };
  salary_structure?: { id: string; name: string };
}

export interface PayrollSettings {
  id: string;
  pay_frequency: 'weekly' | 'bi_weekly' | 'monthly';
  currency: string;
  cut_off_day: number;
  payment_day: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface StatutoryDeduction {
  id: string;
  deduction_type: 'income_tax' | 'social_insurance' | 'provident_fund' | 'other';
  name: string;
  rate?: number;
  threshold?: number;
  max_amount?: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}
