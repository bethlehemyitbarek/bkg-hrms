/* eslint-disable @typescript-eslint/no-explicit-any */
import { supabase as _supabase } from "@/db/supabase";
const supabase = _supabase as any;
import type { PerformanceReview } from '@/types/database.types';

export const performanceService = {
  async listCycles() {
    const { data, error } = await supabase.from('performance_cycles').select('*').order('start_date', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async createCycle(payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('performance_cycles').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async listGoals(filters: { employee_id?: string; cycle_id?: string; status?: string } = {}) {
    let query = supabase.from('performance_goals').select('*, employee:employees!performance_goals_employee_id_fkey(id, first_name, last_name, employee_no)');
    if (filters.employee_id) query = query.eq('employee_id', filters.employee_id);
    if (filters.cycle_id) query = query.eq('cycle_id', filters.cycle_id);
    if (filters.status) query = query.eq('status', filters.status);
    const { data, error } = await query.order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async createGoal(payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('performance_goals').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async updateGoal(id: string, payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('performance_goals').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async listReviews(filters: { employee_id?: string; cycle_id?: string; status?: string; page?: number; pageSize?: number } = {}) {
    const { employee_id, cycle_id, status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase
      .from('performance_reviews')
      .select('*, employee:employees!performance_reviews_employee_id_fkey(id, first_name, last_name, employee_no)', { count: 'exact' });
    if (employee_id) query = query.eq('employee_id', employee_id);
    if (cycle_id) query = query.eq('cycle_id', cycle_id);
    if (status) query = query.eq('status', status);

    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: (data as PerformanceReview[]) || [], total: count || 0, page, pageSize };
  },

  async createReview(payload: Partial<PerformanceReview>): Promise<PerformanceReview> {
    const { data, error } = await supabase.from('performance_reviews').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as PerformanceReview;
  },

  async updateReview(id: string, payload: Partial<PerformanceReview>): Promise<PerformanceReview> {
    const { data, error } = await supabase.from('performance_reviews').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data as PerformanceReview;
  },

  async getStats() {
    const { data } = await supabase.from('performance_reviews').select('status, final_rating');
    const rows = data || [];
    const rated = rows.filter((r: any) => r.final_rating != null);
    const avgRating = rated.length > 0 ? rated.reduce((s: any, r: any) => s + (r.final_rating || 0), 0) / rated.length : 0;
    return {
      total: rows.length,
      pending: rows.filter((r: any) => r.status === 'pending').length,
      completed: rows.filter((r: any) => r.status === 'completed').length,
      avg_rating: Math.round(avgRating * 10) / 10,
    };
  },
};
