import { supabase } from '@/db/supabase';
import type { TransferRequest, PromotionRequest } from '@/types/database.types';

const TENANT_ID = '00000000-0000-0000-0000-000000000001';

// ── TransferRequest ────────────────────────────────────────────────────────────

type TransferFilters = {
  employee_id?: string;
  transfer_status?: string;
  transfer_type?: string;
  page?: number;
  pageSize?: number;
};

export const transferRequestService = {
  async list(filters: TransferFilters = {}): Promise<{ data: TransferRequest[]; total: number }> {
    const { employee_id, transfer_status, transfer_type, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let q = supabase
      .from('transfer_requests')
      .select('*', { count: 'exact' })
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false })
      .range(from, to);
    if (employee_id) q = q.eq('employee_id', employee_id);
    if (transfer_status) q = q.eq('transfer_status', transfer_status);
    if (transfer_type) q = q.eq('transfer_type', transfer_type);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async create(payload: Omit<TransferRequest, 'row_id' | 'transfer_id' | 'created_at' | 'updated_at' | 'initiated_at'>): Promise<TransferRequest> {
    const { data, error } = await supabase
      .from('transfer_requests')
      .insert({ ...payload, tenant_id: TENANT_ID })
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as TransferRequest;
  },

  async update(id: string, payload: Partial<TransferRequest>): Promise<TransferRequest> {
    const { data, error } = await supabase
      .from('transfer_requests')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('transfer_id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as TransferRequest;
  },

  async updateStatus(id: string, transfer_status: TransferRequest['transfer_status'], extra?: Partial<TransferRequest>): Promise<TransferRequest> {
    return transferRequestService.update(id, { transfer_status, ...extra });
  },

  async softDelete(id: string): Promise<void> {
    const { error } = await supabase
      .from('transfer_requests')
      .update({ is_deleted: 1, is_active: 0, updated_at: new Date().toISOString() })
      .eq('transfer_id', id);
    if (error) throw error;
  },
};

// ── PromotionRequest ───────────────────────────────────────────────────────────

type PromotionFilters = {
  employee_id?: string;
  promotion_status?: string;
  page?: number;
  pageSize?: number;
};

export const promotionRequestService = {
  async list(filters: PromotionFilters = {}): Promise<{ data: PromotionRequest[]; total: number }> {
    const { employee_id, promotion_status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let q = supabase
      .from('promotion_requests')
      .select('*', { count: 'exact' })
      .eq('tenant_id', TENANT_ID)
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false })
      .range(from, to);
    if (employee_id) q = q.eq('employee_id', employee_id);
    if (promotion_status) q = q.eq('promotion_status', promotion_status);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: Array.isArray(data) ? data : [], total: count ?? 0 };
  },

  async create(payload: Omit<PromotionRequest, 'row_id' | 'promotion_id' | 'created_at' | 'updated_at' | 'initiated_at'>): Promise<PromotionRequest> {
    const { data, error } = await supabase
      .from('promotion_requests')
      .insert({ ...payload, tenant_id: TENANT_ID })
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as PromotionRequest;
  },

  async update(id: string, payload: Partial<PromotionRequest>): Promise<PromotionRequest> {
    const { data, error } = await supabase
      .from('promotion_requests')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('promotion_id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as PromotionRequest;
  },

  async updateStatus(id: string, promotion_status: PromotionRequest['promotion_status'], extra?: Partial<PromotionRequest>): Promise<PromotionRequest> {
    return promotionRequestService.update(id, { promotion_status, ...extra });
  },

  async softDelete(id: string): Promise<void> {
    const { error } = await supabase
      .from('promotion_requests')
      .update({ is_deleted: 1, is_active: 0, updated_at: new Date().toISOString() })
      .eq('promotion_id', id);
    if (error) throw error;
  },
};
