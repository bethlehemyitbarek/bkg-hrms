/* eslint-disable @typescript-eslint/no-explicit-any */
import { supabase as _supabase } from "@/db/supabase";
const supabase = _supabase as any;
import type { Department, Division, BusinessUnit, Position, Location, JobGrade } from '@/types/database.types';

// --- Departments ---
export const departmentService = {
  async list() {
    const { data, error } = await supabase
      .from('departments')
      .select('*, division:divisions(id, code, name), manager:employees!manager_id(id, first_name, last_name)')
      .order('name');
    if (error) throw error;
    return (data as Department[]) || [];
  },

  async getById(id: string) {
    const { data, error } = await supabase
      .from('departments')
      .select('*, division:divisions(id, code, name, business_unit_id), manager:employees!manager_id(id, first_name, last_name)')
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    return data as Department;
  },

  async create(payload: Partial<Department>) {
    const { data, error } = await supabase.from('departments').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as Department;
  },

  async update(id: string, payload: Partial<Department>) {
    const { data, error } = await supabase
      .from('departments')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as Department;
  },

  async delete(id: string) {
    const { error } = await supabase.from('departments').delete().eq('id', id);
    if (error) throw error;
  },

  async getStats() {
    const [deptRes, empRes] = await Promise.all([
      supabase.from('departments').select('id, name, is_active'),
      supabase.from('employees').select('department_id, employment_status'),
    ]);
    if (deptRes.error) throw deptRes.error;
    const departments = deptRes.data || [];
    const employees = empRes.data || [];
    return departments.map((dept: any) => ({
      ...dept,
      headcount: employees.filter((e: any) => e.department_id === dept.id && e.employment_status === 'active').length,
    }));
  },
};

// --- Divisions ---
export const divisionService = {
  async list() {
    const { data, error } = await supabase
      .from('divisions')
      .select('*, business_unit:business_units(id, code, name)')
      .order('name');
    if (error) throw error;
    return (data as Division[]) || [];
  },

  async create(payload: Partial<Division>) {
    const { data, error } = await supabase.from('divisions').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as Division;
  },

  async update(id: string, payload: Partial<Division>) {
    const { data, error } = await supabase.from('divisions').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data as Division;
  },

  async delete(id: string) {
    const { error } = await supabase.from('divisions').delete().eq('id', id);
    if (error) throw error;
  },
};

// --- Business Units ---
export const businessUnitService = {
  async list() {
    const { data, error } = await supabase.from('business_units').select('*').order('name');
    if (error) throw error;
    return (data as BusinessUnit[]) || [];
  },

  async create(payload: Partial<BusinessUnit>) {
    const { data, error } = await supabase.from('business_units').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as BusinessUnit;
  },

  async update(id: string, payload: Partial<BusinessUnit>) {
    const { data, error } = await supabase.from('business_units').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data as BusinessUnit;
  },

  async delete(id: string) {
    const { error } = await supabase.from('business_units').delete().eq('id', id);
    if (error) throw error;
  },
};

// --- Positions ---
export const positionService = {
  async list() {
    const { data, error } = await supabase
      .from('positions')
      .select('*, department:departments(id, code, name), job_grade:job_grades(id, code, name)')
      .order('title');
    if (error) throw error;
    return (data as Position[]) || [];
  },

  async getById(id: string) {
    const { data, error } = await supabase
      .from('positions')
      .select('*, department:departments(id, code, name), job_grade:job_grades(id, code, name)')
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    return data as Position;
  },

  async create(payload: Partial<Position>) {
    const { data, error } = await supabase.from('positions').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as Position;
  },

  async update(id: string, payload: Partial<Position>) {
    const { data, error } = await supabase.from('positions').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data as Position;
  },

  async delete(id: string) {
    const { error } = await supabase.from('positions').delete().eq('id', id);
    if (error) throw error;
  },
};

// --- Locations ---
export const locationService = {
  async list() {
    const { data, error } = await supabase.from('locations').select('*').order('name');
    if (error) throw error;
    return (data as Location[]) || [];
  },

  async create(payload: Partial<Location>) {
    const { data, error } = await supabase.from('locations').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as Location;
  },

  async update(id: string, payload: Partial<Location>) {
    const { data, error } = await supabase.from('locations').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data as Location;
  },

  async delete(id: string) {
    const { error } = await supabase.from('locations').delete().eq('id', id);
    if (error) throw error;
  },
};

// --- Job Grades ---
export const jobGradeService = {
  async list() {
    const { data, error } = await supabase.from('job_grades').select('*').order('level');
    if (error) throw error;
    return (data as JobGrade[]) || [];
  },

  async create(payload: Partial<JobGrade>) {
    const { data, error } = await supabase.from('job_grades').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as JobGrade;
  },

  async update(id: string, payload: Partial<JobGrade>) {
    const { data, error } = await supabase.from('job_grades').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data as JobGrade;
  },
};
