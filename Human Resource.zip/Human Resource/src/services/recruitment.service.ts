/* eslint-disable @typescript-eslint/no-explicit-any */
import { supabase as _supabase } from "@/db/supabase";
const supabase = _supabase as any;
import type { JobPosting, Candidate } from '@/types/database.types';

export const recruitmentService = {
  async listPostings(filters: { status?: string; department_id?: string; page?: number; pageSize?: number } = {}) {
    const { status, department_id, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase
      .from('job_postings')
      .select('*, department:departments(id, name), location:locations(id, name)', { count: 'exact' });

    if (status) query = query.eq('status', status);
    if (department_id) query = query.eq('department_id', department_id);

    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: (data as JobPosting[]) || [], total: count || 0, page, pageSize };
  },

  async createPosting(payload: Partial<JobPosting>): Promise<JobPosting> {
    const { data, error } = await supabase.from('job_postings').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as JobPosting;
  },

  async updatePosting(id: string, payload: Partial<JobPosting>): Promise<JobPosting> {
    const { data, error } = await supabase.from('job_postings').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data as JobPosting;
  },

  async listCandidates(filters: { job_posting_id?: string; status?: string; page?: number; pageSize?: number } = {}) {
    const { job_posting_id, status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase
      .from('candidates')
      .select('*, job_posting:job_postings(id, title)', { count: 'exact' });

    if (job_posting_id) query = query.eq('job_posting_id', job_posting_id);
    if (status) query = query.eq('status', status);

    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: (data as Candidate[]) || [], total: count || 0, page, pageSize };
  },

  async createCandidate(payload: Partial<Candidate>): Promise<Candidate> {
    const { data, error } = await supabase.from('candidates').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data as Candidate;
  },

  async updateCandidateStatus(id: string, status: Candidate['status']): Promise<Candidate> {
    const { data, error } = await supabase.from('candidates').update({ status, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data as Candidate;
  },

  async getStats() {
    const [postingsRes, candidatesRes] = await Promise.all([
      supabase.from('job_postings').select('status'),
      supabase.from('candidates').select('status'),
    ]);
    const postings = postingsRes.data || [];
    const candidates = candidatesRes.data || [];
    return {
      open_postings: postings.filter((p: any) => p.status === 'open').length,
      total_candidates: candidates.length,
      in_process: candidates.filter((c: any) => ['screening', 'interview', 'assessment'].includes(c.status)).length,
      hired: candidates.filter((c: any) => c.status === 'hired').length,
    };
  },
};
