/* eslint-disable @typescript-eslint/no-explicit-any */
import { supabase as _supabase } from "@/db/supabase";
const supabase = _supabase as any;

// --- Training ---
export const trainingService = {
  async listPrograms(filters: { is_mandatory?: boolean; is_active?: boolean; page?: number; pageSize?: number } = {}) {
    const { is_mandatory, is_active = true, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let query = supabase.from('training_programs').select('*', { count: 'exact' });
    if (is_active !== undefined) query = query.eq('is_active', is_active);
    if (is_mandatory !== undefined) query = query.eq('is_mandatory', is_mandatory);
    const { data, error, count } = await query.order('title').range(from, to);
    if (error) throw error;
    return { data: data || [], total: count || 0, page, pageSize };
  },

  async createProgram(payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('training_programs').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async listSessions(filters: { program_id?: string; status?: string; page?: number; pageSize?: number } = {}) {
    const { program_id, status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let query = supabase.from('training_sessions').select('*, program:training_programs(id, code, title)', { count: 'exact' });
    if (program_id) query = query.eq('program_id', program_id);
    if (status) query = query.eq('status', status);
    const { data, error, count } = await query.order('start_date', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: data || [], total: count || 0, page, pageSize };
  },

  async listEnrollments(filters: { employee_id?: string; session_id?: string; status?: string; page?: number; pageSize?: number } = {}) {
    const { employee_id, session_id, status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let query = supabase.from('training_enrollments').select(
      '*, employee:employees!training_enrollments_employee_id_fkey(id, first_name, last_name, employee_no), session:training_sessions(id, session_name, start_date)',
      { count: 'exact' }
    );
    if (employee_id) query = query.eq('employee_id', employee_id);
    if (session_id) query = query.eq('session_id', session_id);
    if (status) query = query.eq('status', status);
    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: data || [], total: count || 0, page, pageSize };
  },

  async enroll(session_id: string, employee_id: string) {
    const { data, error } = await supabase.from('training_enrollments').insert({ session_id, employee_id, enrollment_date: new Date().toISOString().split('T')[0] }).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async updateEnrollment(id: string, payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('training_enrollments').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// --- Loan ---
export const loanService = {
  async list(filters: { employee_id?: string; status?: string; page?: number; pageSize?: number } = {}) {
    const { employee_id, status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let query = supabase.from('loan_applications').select('*, employee:employees!loan_applications_employee_id_fkey(id, first_name, last_name, employee_no)', { count: 'exact' });
    if (employee_id) query = query.eq('employee_id', employee_id);
    if (status) query = query.eq('status', status);
    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: data || [], total: count || 0, page, pageSize };
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('loan_applications').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(id: string, payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('loan_applications').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async approve(id: string, approved_by: string, amount_approved: number) {
    const { data, error } = await supabase.from('loan_applications').update({
      status: 'approved', approved_by, amount_approved, approved_date: new Date().toISOString().split('T')[0], updated_at: new Date().toISOString()
    }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// --- Transfer & Promotion ---
export const transferPromotionService = {
  async list(filters: { employee_id?: string; status?: string; transaction_type?: string; page?: number; pageSize?: number } = {}) {
    const { employee_id, status, transaction_type, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let query = supabase.from('transfer_promotions').select(
      '*, employee:employees!transfer_promotions_employee_id_fkey(id, first_name, last_name, employee_no), from_department:departments!transfer_promotions_from_department_id_fkey(id, name), to_department:departments!transfer_promotions_to_department_id_fkey(id, name)',
      { count: 'exact' }
    );
    if (employee_id) query = query.eq('employee_id', employee_id);
    if (status) query = query.eq('status', status);
    if (transaction_type) query = query.eq('transaction_type', transaction_type);
    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: data || [], total: count || 0, page, pageSize };
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('transfer_promotions').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async approve(id: string, approved_by: string) {
    const { data, error } = await supabase.from('transfer_promotions').update({
      status: 'approved', approved_by, approved_at: new Date().toISOString(), updated_at: new Date().toISOString()
    }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// --- Disciplinary ---
export const disciplinaryService = {
  async list(filters: { employee_id?: string; status?: string; page?: number; pageSize?: number } = {}) {
    const { employee_id, status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let query = supabase.from('disciplinary_cases').select('*, employee:employees!disciplinary_cases_employee_id_fkey(id, first_name, last_name, employee_no)', { count: 'exact' });
    if (employee_id) query = query.eq('employee_id', employee_id);
    if (status) query = query.eq('status', status);
    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: data || [], total: count || 0, page, pageSize };
  },

  async create(payload: Record<string, unknown>) {
    // Auto-generate case_number
    const { count } = await supabase.from('disciplinary_cases').select('*', { count: 'exact', head: true });
    const case_number = `DISC-${new Date().getFullYear()}-${String((count || 0) + 1).padStart(4, '0')}`;
    const { data, error } = await supabase.from('disciplinary_cases').insert({ ...payload, case_number }).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(id: string, payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('disciplinary_cases').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// --- Grievance ---
export const grievanceService = {
  async list(filters: { employee_id?: string; status?: string; priority?: string; page?: number; pageSize?: number } = {}) {
    const { employee_id, status, priority, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let query = supabase.from('grievance_cases').select('*, employee:employees!grievance_cases_employee_id_fkey(id, first_name, last_name, employee_no)', { count: 'exact' });
    if (employee_id) query = query.eq('employee_id', employee_id);
    if (status) query = query.eq('status', status);
    if (priority) query = query.eq('priority', priority);
    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: data || [], total: count || 0, page, pageSize };
  },

  async create(payload: Record<string, unknown>) {
    const { count } = await supabase.from('grievance_cases').select('*', { count: 'exact', head: true });
    const case_number = `GRIEV-${new Date().getFullYear()}-${String((count || 0) + 1).padStart(4, '0')}`;
    const { data, error } = await supabase.from('grievance_cases').insert({ ...payload, case_number, filed_date: new Date().toISOString().split('T')[0] }).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(id: string, payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('grievance_cases').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// --- Separation ---
export const separationService = {
  async list(filters: { employee_id?: string; status?: string; page?: number; pageSize?: number } = {}) {
    const { employee_id, status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let query = supabase.from('separation_requests').select('*, employee:employees!separation_requests_employee_id_fkey(id, first_name, last_name, employee_no)', { count: 'exact' });
    if (employee_id) query = query.eq('employee_id', employee_id);
    if (status) query = query.eq('status', status);
    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: data || [], total: count || 0, page, pageSize };
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('separation_requests').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(id: string, payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('separation_requests').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// --- Timesheets ---
export const timesheetService = {
  async list(filters: { employee_id?: string; status?: string; page?: number; pageSize?: number } = {}) {
    const { employee_id, status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let query = supabase.from('timesheets').select('*, employee:employees!timesheets_employee_id_fkey(id, first_name, last_name, employee_no)', { count: 'exact' });
    if (employee_id) query = query.eq('employee_id', employee_id);
    if (status) query = query.eq('status', status);
    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: data || [], total: count || 0, page, pageSize };
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('timesheets').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async submit(id: string) {
    const { data, error } = await supabase.from('timesheets').update({ status: 'submitted', updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async approve(id: string, approved_by: string) {
    const now = new Date().toISOString();
    const { data, error } = await supabase.from('timesheets')
      .update({
        status: 'approved',
        approved_by,
        approved_at: now,
        is_locked: 1,
        locked_at: now,
        updated_at: now,
      })
      .eq('id', id)
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async reject(id: string, approved_by: string, rejection_reason: string) {
    const { data, error } = await supabase.from('timesheets')
      .update({
        status: 'rejected',
        approved_by,
        rejection_reason,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  /** HR Admin: unlock an approved/locked timesheet to allow corrections */
  async unlock(id: string, unlocked_by: string) {
    const { data, error } = await supabase.from('timesheets')
      .update({
        status: 'draft',
        is_locked: 0,
        locked_at: null,
        approved_by: null,
        approved_at: null,
        rejection_reason: null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select('*').maybeSingle();
    if (error) throw error;
    console.info(`[timesheetService] Timesheet ${id} unlocked by ${unlocked_by}`);
    return data;
  },

  /** MSS: list team timesheets for approval (all employees or by manager filter) */
  async listForApproval(filters: {
    status?: string;
    employee_id?: string;
    page?: number;
    pageSize?: number;
  } = {}) {
    const { status, employee_id, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    let q = supabase
      .from('timesheets')
      .select(
        `*, employee:employees!timesheets_employee_id_fkey(id, first_name, last_name, employee_no, department_id)`,
        { count: 'exact' }
      )
      .order('created_at', { ascending: false })
      .range(from, from + pageSize - 1);
    if (status && status !== 'all') q = q.eq('status', status);
    if (employee_id) q = q.eq('employee_id', employee_id);
    const { data, error, count } = await q;
    if (error) throw error;
    return { data: data || [], total: count || 0 };
  },

  /** Get timesheet entries for a given timesheet */
  async getEntries(timesheet_id: string) {
    const { data, error } = await supabase
      .from('timesheet_entries')
      .select('*')
      .eq('timesheet_id', timesheet_id)
      .order('work_date', { ascending: true });
    if (error) throw error;
    return data || [];
  },
};

// --- Expenses ---
export const expenseService = {
  async list(filters: { employee_id?: string; status?: string; page?: number; pageSize?: number } = {}) {
    const { employee_id, status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let query = supabase.from('expense_claims').select('*, employee:employees!expense_claims_employee_id_fkey(id, first_name, last_name, employee_no)', { count: 'exact' });
    if (employee_id) query = query.eq('employee_id', employee_id);
    if (status) query = query.eq('status', status);
    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: data || [], total: count || 0, page, pageSize };
  },

  async create(payload: Record<string, unknown>) {
    const { count } = await supabase.from('expense_claims').select('*', { count: 'exact', head: true });
    const claim_no = `EXP-${new Date().getFullYear()}-${String((count || 0) + 1).padStart(4, '0')}`;
    const { data, error } = await supabase.from('expense_claims').insert({ ...payload, claim_no, claim_date: new Date().toISOString().split('T')[0] }).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(id: string, payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('expense_claims').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async approve(id: string, approved_by: string) {
    const { data, error } = await supabase.from('expense_claims').update({ status: 'approved', approved_by, approved_at: new Date().toISOString(), updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// --- Documents ---
export const documentService = {
  async list(filters: { employee_id?: string; document_type?: string; status?: string; page?: number; pageSize?: number } = {}) {
    const { employee_id, document_type, status, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let query = supabase.from('documents').select('*, employee:employees!documents_employee_id_fkey(id, first_name, last_name, employee_no)', { count: 'exact' });
    if (employee_id) query = query.eq('employee_id', employee_id);
    if (document_type) query = query.eq('document_type', document_type);
    if (status) query = query.eq('status', status);
    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: data || [], total: count || 0, page, pageSize };
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('documents').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async archive(id: string) {
    const { data, error } = await supabase.from('documents').update({ status: 'archived', updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// --- Notifications ---
export const notificationService = {
  async listForRecipient(recipient_id: string, unread_only = false) {
    let query = supabase.from('notifications').select('*').eq('recipient_id', recipient_id);
    if (unread_only) query = query.eq('is_read', false);
    const { data, error } = await query.order('created_at', { ascending: false }).limit(50);
    if (error) throw error;
    return data || [];
  },

  async markRead(id: string) {
    const { error } = await supabase.from('notifications').update({ is_read: true, read_at: new Date().toISOString() }).eq('id', id);
    if (error) throw error;
  },

  async markAllRead(recipient_id: string) {
    const { error } = await supabase.from('notifications').update({ is_read: true, read_at: new Date().toISOString() }).eq('recipient_id', recipient_id).eq('is_read', false);
    if (error) throw error;
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('notifications').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// --- Compliance ---
export const complianceService = {
  async listPolicies(filters: { status?: string; category?: string; page?: number; pageSize?: number } = {}) {
    const { status, category, page = 1, pageSize = 20 } = filters;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    let query = supabase.from('compliance_policies').select('*', { count: 'exact' });
    if (status) query = query.eq('status', status);
    if (category) query = query.eq('category', category);
    const { data, error, count } = await query.order('created_at', { ascending: false }).range(from, to);
    if (error) throw error;
    return { data: data || [], total: count || 0, page, pageSize };
  },

  async createPolicy(payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('compliance_policies').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async updatePolicy(id: string, payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('compliance_policies').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async acknowledge(policy_id: string, employee_id: string) {
    const { data, error } = await supabase.from('policy_acknowledgements').upsert({ policy_id, employee_id, acknowledged_at: new Date().toISOString() }, { onConflict: 'policy_id,employee_id' }).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// --- Shifts ---
export const shiftService = {
  async list() {
    const { data, error } = await supabase.from('shifts').select('*').eq('is_active', true).order('name');
    if (error) throw error;
    return data || [];
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('shifts').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(id: string, payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('shifts').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// --- Benefits ---
export const benefitsService = {
  async listPlans() {
    // benefit_plans uses plan_name (not name) and is_active is smallint (1/0)
    const { data, error } = await (supabase as unknown as any)
      .from('benefit_plans')
      .select('*')
      .eq('is_active', 1)
      .order('plan_name');
    if (error) throw error;
    return data || [];
  },

  async listEmployeeBenefits(employee_id: string) {
    // Use correct table + columns for benefit_enrollments
    const { data, error } = await (supabase as unknown as any)
      .from('benefit_enrollments')
      .select('*, benefit_plan:benefit_plans(benefit_plan_id,plan_name,plan_code,plan_type)')
      .eq('employee_id', employee_id)
      .eq('is_deleted', 0);
    if (error) throw error;
    return data || [];
  },

  async enroll(employee_id: string, benefit_plan_id: string) {
    const { data, error } = await (supabase as unknown as any)
      .from('benefit_enrollments')
      .insert({
        employee_id,
        benefit_plan_id,
        enrollment_date: new Date().toISOString().split('T')[0],
        enrollment_status: 'ACTIVE',
        tenant_id: '00000000-0000-0000-0000-000000000001',
      })
      .select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};

// --- Onboarding ---
export const onboardingService = {
  async listChecklists() {
    const { data, error } = await supabase.from('onboarding_checklists').select('*, tasks:onboarding_tasks(*)').eq('is_active', true);
    if (error) throw error;
    return data || [];
  },

  async getEmployeeOnboarding(employee_id: string) {
    const { data, error } = await supabase.from('employee_onboarding').select('*, checklist:onboarding_checklists(*, tasks:onboarding_tasks(*))').eq('employee_id', employee_id).maybeSingle();
    if (error) throw error;
    return data;
  },

  async create(payload: Record<string, unknown>) {
    const { data, error } = await supabase.from('employee_onboarding').insert(payload).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },

  async updateProgress(id: string, progress_percentage: number, status: string) {
    const { data, error } = await supabase.from('employee_onboarding').update({ progress_percentage, status, updated_at: new Date().toISOString() }).eq('id', id).select('*').maybeSingle();
    if (error) throw error;
    return data;
  },
};
