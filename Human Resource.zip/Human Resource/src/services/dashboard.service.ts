/* eslint-disable @typescript-eslint/no-explicit-any */
import { supabase as _supabase } from "@/db/supabase";
const supabase = _supabase as any;

export interface DashboardStats {
  employees: { total: number; active: number; probation: number; on_leave: number; new_this_month: number };
  attendance: { present_today: number; absent_today: number; late_today: number; on_leave_today: number; attendance_rate: number };
  leave: { pending_requests: number; approved_today: number };
  payroll: { current_period_status: string | null; total_net_pay: number; period_name: string };
  recruitment: { open_postings: number; total_candidates: number; in_pipeline: number };
  performance: { pending_reviews: number; avg_rating: number };
  training: { total_programs: number; enrollments_this_month: number; completed_this_month: number };
  loans: { pending_count: number; active_count: number };
  expenses: { pending_count: number; pending_amount: number };
  organization: { total_departments: number; total_divisions: number; total_business_units: number };
  incidents: { active_count: number; total_count: number; resolved_count: number };
}

export interface HeadcountByDept { department: string; count: number }
export interface PayrollTrend { month: string; net_pay: number; gross_pay: number }
export interface AttendanceTrend { day: string; present: number; absent: number; late: number }
export interface RecruitmentFunnel { stage: string; count: number }
export interface IncidentStatusChart { name: string; value: number; fill: string }

export const dashboardService = {
  async getStats(): Promise<DashboardStats> {
    const today = new Date().toISOString().split('T')[0];
    const firstOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];

    const [empRes, attRes, leaveRes, payRes, postRes, candRes, revRes, trainRes, loanRes, expRes, deptRes, divRes, buRes, incidentRes] = await Promise.all([
      supabase.from('employees').select('employment_status, hire_date, department_id'),
      supabase.from('daily_attendance_summaries').select('attendance_status, late_minutes').eq('attendance_date', today),
      supabase.from('leave_requests').select('status').eq('status', 'pending'),
      supabase.from('payroll_periods').select('id, status, name').neq('status', 'cancelled').order('created_at', { ascending: false }).limit(1),
      supabase.from('job_postings').select('status'),
      supabase.from('candidates').select('stage'),
      supabase.from('performance_reviews').select('status, overall_rating'),
      supabase.from('training_enrollments').select('status, enrollment_date').gte('enrollment_date', firstOfMonth),
      supabase.from('loan_applications').select('status'),
      supabase.from('expense_claims').select('status, total_amount').eq('status', 'submitted'),
      supabase.from('departments').select('id'),
      supabase.from('divisions').select('id'),
      supabase.from('business_units').select('id'),
      supabase.from('progressive_discipline').select('status'),
    ]);

    const employees  = empRes.data  || [];
    const attendance = (attRes.data || []) as { attendance_status: string; late_minutes: number }[];
    const leaveReqs  = leaveRes.data || [];
    const payPeriods = payRes.data  || [];
    const postings   = postRes.data || [];
    const candidates = candRes.data || [];
    const reviews    = revRes.data  || [];
    const trainEnrol = trainRes.data || [];
    const loans      = loanRes.data || [];
    const expenses   = expRes.data  || [];    const departments = deptRes.data || [];
    const divisions = divRes.data || [];
    const businessUnits = buRes.data || [];
    const incidents = (incidentRes.data || []) as { status?: string }[];
    const totalActive = employees.filter((e: any) => e.employment_status === 'active').length;

    const presentToday  = attendance.filter((a) => a.attendance_status === 'PRESENT').length;
    const absentToday   = attendance.filter((a) => a.attendance_status === 'ABSENT').length;
    const lateToday     = attendance.filter((a) => (a.late_minutes ?? 0) > 0).length;
    const onLeaveToday  = attendance.filter((a) => a.attendance_status === 'ON_LEAVE').length;
    const attendanceRate = totalActive > 0 ? Math.round((presentToday / totalActive) * 100) : 0;

    const rated  = reviews.filter((r: any) => r.overall_rating != null);
    const avgRating = rated.length > 0 ? rated.reduce((s: any, r: any) => s + (r.overall_rating || 0), 0) / rated.length : 0;

    const latestPeriod = payPeriods[0];
    let totalNetPay = 0;
    if (latestPeriod?.id) {
      const { data: pr } = await supabase.from('payroll_records').select('net_pay, gross_pay').eq('payroll_period_id', latestPeriod.id);
      totalNetPay = (pr || []).reduce((s: any, r: any) => s + (Number(r.net_pay) || 0), 0);
    }

    const activeIncidentCount = incidents.filter((item) => ['active', 'open', 'pending', 'investigating'].includes((item.status || '').toString().toLowerCase())).length;
    const resolvedIncidentCount = incidents.filter((item) => ['resolved', 'closed', 'completed', 'done'].includes((item.status || '').toString().toLowerCase())).length;

    return {
      employees: {
        total: employees.length,
        active: totalActive,
        probation: employees.filter((e: any) => e.employment_status === 'probation').length,
        on_leave: employees.filter((e: any) => e.employment_status === 'on_leave').length,
        new_this_month: employees.filter((e: any) => e.hire_date && e.hire_date >= firstOfMonth).length,
      },
      attendance: { present_today: presentToday, absent_today: absentToday, late_today: lateToday, on_leave_today: onLeaveToday, attendance_rate: attendanceRate },
      leave: { pending_requests: leaveReqs.length, approved_today: 0 },
      payroll: { current_period_status: latestPeriod?.status ?? null, total_net_pay: totalNetPay, period_name: latestPeriod?.name ?? '' },
      recruitment: {
        open_postings: postings.filter((p: any) => p.status === 'open').length,
        total_candidates: candidates.length,
        in_pipeline: candidates.filter((c: any) => ['screening', 'interview', 'assessment'].includes(c.stage)).length,
      },
      performance: { pending_reviews: reviews.filter((r: any) => r.status === 'pending').length, avg_rating: Math.round(avgRating * 10) / 10 },
      training: {
        total_programs: 0,
        enrollments_this_month: trainEnrol.length,
        completed_this_month: trainEnrol.filter((e: any) => e.status === 'completed').length,
      },
      loans: {
        pending_count: loans.filter((l: any) => l.status === 'pending').length,
        active_count: loans.filter((l: any) => ['approved', 'disbursed', 'repaying'].includes(l.status)).length,
      },
      expenses: {
        pending_count: expenses.length,
        pending_amount: expenses.reduce((s: any, e: any) => s + (Number(e.total_amount) || 0), 0),
      },
      organization: {
        total_departments: departments.length,
        total_divisions: divisions.length,
        total_business_units: businessUnits.length,
      },
      incidents: {
        active_count: activeIncidentCount,
        total_count: incidents.length,
        resolved_count: resolvedIncidentCount,
      },
    };
  },

  async getHeadcountByDept(): Promise<HeadcountByDept[]> {
    const { data: employees } = await supabase
      .from('employees')
      .select('department_id, departments!department_id(name)')
      .eq('employment_status', 'active');
    if (!employees) return [];
    const map: Record<string, number> = {};
    for (const e of employees) {
      const name = (e.departments as any)?.name ?? 'Unknown';
      map[name] = (map[name] || 0) + 1;
    }
    return Object.entries(map)
      .map(([department, count]) => ({ department, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);
  },

  async getPayrollTrend(): Promise<PayrollTrend[]> {
    const { data: periods } = await supabase
      .from('payroll_periods')
      .select('id, name, start_date')
      .eq('status', 'paid')
      .order('start_date', { ascending: false })
      .limit(6);
    if (!periods?.length) return [];
    const results = await Promise.all(
      periods.map(async (p: any) => {
        const { data } = await supabase.from('payroll_records').select('net_pay, gross_pay').eq('payroll_period_id', p.id);
        const net = (data || []).reduce((s: any, r: any) => s + Number(r.net_pay || 0), 0);
        const gross = (data || []).reduce((s: any, r: any) => s + Number(r.gross_pay || 0), 0);
        return { month: p.name, net_pay: net, gross_pay: gross };
      })
    );
    return results.reverse();
  },

  async getRecruitmentFunnel(): Promise<RecruitmentFunnel[]> {
    const { data } = await supabase.from('candidates').select('stage');
    if (!data) return [];
    const stages = ['applied', 'screening', 'interview', 'assessment', 'offer', 'hired'];
    const map: Record<string, number> = {};
    for (const c of data) { map[c.stage] = (map[c.stage] || 0) + 1; }
    return stages.filter(s => map[s]).map(stage => ({ stage, count: map[stage] }));
  },

  async getTrainingStatus(): Promise<{ name: string; value: number; fill: string }[]> {
    const { data } = await supabase.from('training_enrollments').select('status');
    if (!data?.length) return [];
    const map: Record<string, number> = {};
    for (const e of data) { map[e.status] = (map[e.status] || 0) + 1; }
    const colors: Record<string, string> = { completed: '#22c55e', enrolled: '#3b82f6', attended: '#8b5cf6', cancelled: '#ef4444', waitlisted: '#f59e0b' };
    return Object.entries(map).map(([name, value]) => ({ name, value, fill: colors[name] ?? '#94a3b8' }));
  },

  async getIncidentStatusChart(): Promise<IncidentStatusChart[]> {
    const { data } = await supabase.from('progressive_discipline').select('status');
    if (!data?.length) return [];
    const map: Record<string, number> = {};
    for (const item of data as { status?: string }[]) {
      const status = (item.status || 'unknown').toString().toLowerCase();
      map[status] = (map[status] || 0) + 1;
    }
    const colors: Record<string, string> = {
      active: '#ef4444',
      open: '#f59e0b',
      pending: '#f59e0b',
      investigating: '#8b5cf6',
      resolved: '#22c55e',
      closed: '#6366f1',
      completed: '#22c55e',
      done: '#22c55e',
      unknown: '#94a3b8',
    };
    return Object.entries(map).map(([name, value]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      value,
      fill: colors[name] ?? '#94a3b8',
    }));
  },
};
