import { supabase } from '@/db/supabase';
import type {
  BonusConfiguration,
  BenefitPlan,
  CoverageTier,
  BenefitEnrollment,
} from '@/types/database.types';

const DEFAULT_TENANT = '00000000-0000-0000-0000-000000000001';

// ── BonusConfiguration ────────────────────────────────────────────────

export const bonusConfigService = {
  async list(filters: { bonus_type?: string; is_active?: number } = {}): Promise<BonusConfiguration[]> {
    let q = supabase
      .from('bonus_configurations')
      .select('*')
      .eq('is_deleted', 0)
      .order('bonus_name');
    if (filters.bonus_type) q = q.eq('bonus_type', filters.bonus_type);
    if (filters.is_active !== undefined) q = q.eq('is_active', filters.is_active);
    const { data, error } = await q;
    if (error) throw error;
    return (data || []) as BonusConfiguration[];
  },

  async getById(bonus_config_id: string): Promise<BonusConfiguration | null> {
    const { data, error } = await supabase
      .from('bonus_configurations')
      .select('*')
      .eq('bonus_config_id', bonus_config_id)
      .maybeSingle();
    if (error) throw error;
    return data as BonusConfiguration | null;
  },

  async create(payload: Omit<BonusConfiguration, 'bonus_config_id' | 'created_at' | 'updated_at'>): Promise<void> {
    const { error } = await supabase.from('bonus_configurations').insert({
      ...payload,
      tenant_id: payload.tenant_id || DEFAULT_TENANT,
    });
    if (error) throw error;
  },

  async update(bonus_config_id: string, payload: Partial<BonusConfiguration>): Promise<void> {
    const { error } = await supabase
      .from('bonus_configurations')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('bonus_config_id', bonus_config_id);
    if (error) throw error;
  },

  async softDelete(bonus_config_id: string): Promise<void> {
    const { error } = await supabase
      .from('bonus_configurations')
      .update({ is_deleted: 1, is_active: 0, updated_at: new Date().toISOString() })
      .eq('bonus_config_id', bonus_config_id);
    if (error) throw error;
  },
};

// ── BenefitPlan ───────────────────────────────────────────────────────

export const benefitPlanService = {
  async list(filters: { plan_type?: string; is_active?: number } = {}): Promise<BenefitPlan[]> {
    let q = supabase
      .from('benefit_plans')
      .select('*, tiers:coverage_tiers(*)')
      .eq('is_deleted', 0)
      .order('plan_name');
    if (filters.plan_type) q = q.eq('plan_type', filters.plan_type);
    if (filters.is_active !== undefined) q = q.eq('is_active', filters.is_active);
    const { data, error } = await q;
    if (error) throw error;
    return (data || []) as BenefitPlan[];
  },

  async getById(benefit_plan_id: string): Promise<BenefitPlan | null> {
    const { data, error } = await supabase
      .from('benefit_plans')
      .select('*, tiers:coverage_tiers(*)')
      .eq('benefit_plan_id', benefit_plan_id)
      .maybeSingle();
    if (error) throw error;
    return data as BenefitPlan | null;
  },

  async create(payload: Omit<BenefitPlan, 'row_id' | 'benefit_plan_id' | 'created_at' | 'updated_at' | 'tiers'>): Promise<void> {
    const { error } = await supabase.from('benefit_plans').insert({
      ...payload,
      tenant_id: payload.tenant_id || DEFAULT_TENANT,
    });
    if (error) throw error;
  },

  async update(benefit_plan_id: string, payload: Partial<Omit<BenefitPlan, 'tiers'>>): Promise<void> {
    const { error } = await supabase
      .from('benefit_plans')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('benefit_plan_id', benefit_plan_id);
    if (error) throw error;
  },

  async softDelete(benefit_plan_id: string): Promise<void> {
    const { error } = await supabase
      .from('benefit_plans')
      .update({ is_deleted: 1, is_active: 0, updated_at: new Date().toISOString() })
      .eq('benefit_plan_id', benefit_plan_id);
    if (error) throw error;
  },
};

// ── CoverageTier ──────────────────────────────────────────────────────

export const coverageTierService = {
  async listByPlan(benefit_plan_id: string): Promise<CoverageTier[]> {
    const { data, error } = await supabase
      .from('coverage_tiers')
      .select('*')
      .eq('benefit_plan_id', benefit_plan_id)
      .eq('is_deleted', 0)
      .order('tier_name');
    if (error) throw error;
    return (data || []) as CoverageTier[];
  },

  async create(payload: Omit<CoverageTier, 'row_id' | 'coverage_tier_id' | 'created_at' | 'updated_at'>): Promise<void> {
    const { error } = await supabase.from('coverage_tiers').insert({
      ...payload,
      tenant_id: payload.tenant_id || DEFAULT_TENANT,
    });
    if (error) throw error;
  },

  async update(coverage_tier_id: string, payload: Partial<CoverageTier>): Promise<void> {
    const { error } = await supabase
      .from('coverage_tiers')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('coverage_tier_id', coverage_tier_id);
    if (error) throw error;
  },

  async softDelete(coverage_tier_id: string): Promise<void> {
    const { error } = await supabase
      .from('coverage_tiers')
      .update({ is_deleted: 1, is_active: 0, updated_at: new Date().toISOString() })
      .eq('coverage_tier_id', coverage_tier_id);
    if (error) throw error;
  },
};

// ── BenefitEnrollment ─────────────────────────────────────────────────

export const benefitEnrollmentService = {
  async list(filters: { employee_id?: string; benefit_plan_id?: string; enrollment_status?: string } = {}): Promise<BenefitEnrollment[]> {
    let q = supabase
      .from('benefit_enrollments')
      .select(`
        *,
        employee:employees!benefit_enrollments_employee_id_fkey(id,first_name,last_name,employee_no),
        benefit_plan:benefit_plans!benefit_enrollments_benefit_plan_id_fkey(benefit_plan_id,plan_name,plan_code,plan_type),
        coverage_tier:coverage_tiers!benefit_enrollments_coverage_tier_id_fkey(coverage_tier_id,tier_name,premium_amount)
      `)
      .eq('is_deleted', 0)
      .order('enrollment_date', { ascending: false });    if (filters.employee_id)      q = q.eq('employee_id', filters.employee_id);
    if (filters.benefit_plan_id)  q = q.eq('benefit_plan_id', filters.benefit_plan_id);
    if (filters.enrollment_status) q = q.eq('enrollment_status', filters.enrollment_status);
    const { data, error } = await q;
    if (error) throw error;
    return (data || []) as BenefitEnrollment[];
  },

  async getById(benefit_enrollment_id: string): Promise<BenefitEnrollment | null> {
    const { data, error } = await supabase
      .from('benefit_enrollments')
      .select(`
        *,
        employee:employees!benefit_enrollments_employee_id_fkey(id,first_name,last_name,employee_no),
        benefit_plan:benefit_plans!benefit_enrollments_benefit_plan_id_fkey(benefit_plan_id,plan_name,plan_code,plan_type),
        coverage_tier:coverage_tiers!benefit_enrollments_coverage_tier_id_fkey(coverage_tier_id,tier_name,premium_amount)
      `)
      .eq('benefit_enrollment_id', benefit_enrollment_id)
      .maybeSingle();
    if (error) throw error;
    return data as BenefitEnrollment | null;
  },

  async enroll(payload: Omit<BenefitEnrollment, 'row_id' | 'benefit_enrollment_id' | 'created_at' | 'updated_at' | 'employee' | 'benefit_plan' | 'coverage_tier'>): Promise<void> {
    const { error } = await supabase.from('benefit_enrollments').insert({
      ...payload,
      tenant_id: payload.tenant_id || DEFAULT_TENANT,
    });
    if (error) throw error;
  },

  async updateStatus(benefit_enrollment_id: string, enrollment_status: BenefitEnrollment['enrollment_status'], termination_date?: string): Promise<void> {
    const { error } = await supabase
      .from('benefit_enrollments')
      .update({
        enrollment_status,
        ...(termination_date ? { termination_date } : {}),
        updated_at: new Date().toISOString(),
      })
      .eq('benefit_enrollment_id', benefit_enrollment_id);
    if (error) throw error;
  },

  async update(benefit_enrollment_id: string, payload: Partial<BenefitEnrollment>): Promise<void> {
    const { error } = await supabase
      .from('benefit_enrollments')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('benefit_enrollment_id', benefit_enrollment_id);
    if (error) throw error;
  },

  async softDelete(benefit_enrollment_id: string): Promise<void> {
    const { error } = await supabase
      .from('benefit_enrollments')
      .update({ is_deleted: 1, is_active: 0, updated_at: new Date().toISOString() })
      .eq('benefit_enrollment_id', benefit_enrollment_id);
    if (error) throw error;
  },
};
