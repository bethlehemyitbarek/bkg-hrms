/**
 * Notification Engine Service
 * Auto-generates in-app notification records for:
 *   - Policy published  → all employees in distribution scope
 *   - Announcement published → all employees matching targets
 *   - Timesheet approved/rejected → the timesheet owner
 *   - DSAR status updated → the requesting employee
 */

import { supabase as _db } from '@/db/supabase';

const db = _db as any; // eslint-disable-line @typescript-eslint/no-explicit-any

const TENANT_ID = '00000000-0000-0000-0000-000000000001';

/* ─── Helpers ────────────────────────────────────────────────────────────── */

async function getAllActiveEmployeeIds(): Promise<string[]> {
  const { data } = await db
    .from('employees')
    .select('id')
    .eq('employment_status', 'active')
    .eq('is_deleted', 0);
  return (data || []).map((e: { id: string }) => e.id);
}

async function getEmployeeIdsByDept(dept_id: string): Promise<string[]> {
  const { data } = await db
    .from('employees')
    .select('id')
    .eq('department_id', dept_id)
    .eq('employment_status', 'active')
    .eq('is_deleted', 0);
  return (data || []).map((e: { id: string }) => e.id);
}

async function insertNotifications(
  rows: {
    recipient_id: string;
    title: string;
    message: string;
    notification_type: string;
    entity_type?: string;
    entity_id?: string;
    action_url?: string;
  }[]
) {
  if (!rows.length) return;
  // Insert in batches of 100
  for (let i = 0; i < rows.length; i += 100) {
    const batch = rows.slice(i, i + 100);
    await db.from('notifications').insert(batch);
  }
}

/* ─── Public API ─────────────────────────────────────────────────────────── */

export const notificationEngine = {

  /** Called after a policy is published */
  async onPolicyPublished(policy: {
    policy_id: string;
    policy_title: string;
    distribution_scope: string;
    target_criteria?: Record<string, unknown> | null;
  }) {
    try {
      let recipientIds: string[] = [];

      if (policy.distribution_scope === 'ALL_EMPLOYEES' || policy.distribution_scope === 'ALL') {
        recipientIds = await getAllActiveEmployeeIds();
      } else if (policy.distribution_scope === 'DEPARTMENT' && policy.target_criteria?.department_id) {
        recipientIds = await getEmployeeIdsByDept(policy.target_criteria.department_id as string);
      } else {
        // CUSTOM / ROLE — fall back to all employees for now
        recipientIds = await getAllActiveEmployeeIds();
      }

      const rows = recipientIds.map(rid => ({
        recipient_id: rid,
        title: `New Policy Published: ${policy.policy_title}`,
        message: `A new HR policy "${policy.policy_title}" has been published. Please review and acknowledge it.`,
        notification_type: 'POLICY_PUBLISHED',
        entity_type: 'hr_policy',
        entity_id: policy.policy_id,
        action_url: '/ess',
      }));

      await insertNotifications(rows);
    } catch (err) {
      console.error('[NotificationEngine] onPolicyPublished error:', err);
    }
  },

  /** Called after an announcement is published */
  async onAnnouncementPublished(announcement: {
    id: string;
    title: string;
    targets: string;
    target_criteria?: Record<string, unknown> | null;
    priority?: string;
  }) {
    try {
      let recipientIds: string[] = [];

      if (announcement.targets === 'ALL') {
        recipientIds = await getAllActiveEmployeeIds();
      } else if (announcement.targets === 'DEPARTMENT' && announcement.target_criteria?.department_id) {
        recipientIds = await getEmployeeIdsByDept(announcement.target_criteria.department_id as string);
      } else {
        recipientIds = await getAllActiveEmployeeIds();
      }

      const priorityLabel = announcement.priority && announcement.priority !== 'NORMAL'
        ? ` [${announcement.priority}]` : '';

      const rows = recipientIds.map(rid => ({
        recipient_id: rid,
        title: `Announcement${priorityLabel}: ${announcement.title}`,
        message: `A new announcement "${announcement.title}" has been posted. Check the ESS portal for details.`,
        notification_type: 'ANNOUNCEMENT_PUBLISHED',
        entity_type: 'announcement',
        entity_id: announcement.id,
        action_url: '/ess',
      }));

      await insertNotifications(rows);
    } catch (err) {
      console.error('[NotificationEngine] onAnnouncementPublished error:', err);
    }
  },

  /** Called after a timesheet is approved */
  async onTimesheetApproved(timesheet: {
    id: string;
    employee_id: string;
    period_start?: string;
    period_end?: string;
  }) {
    try {
      const period = timesheet.period_start
        ? ` (${timesheet.period_start} – ${timesheet.period_end})`
        : '';
      await insertNotifications([{
        recipient_id: timesheet.employee_id,
        title: 'Timesheet Approved',
        message: `Your timesheet${period} has been approved by your manager.`,
        notification_type: 'TIMESHEET_APPROVED',
        entity_type: 'timesheet',
        entity_id: timesheet.id,
        action_url: '/timesheets',
      }]);
    } catch (err) {
      console.error('[NotificationEngine] onTimesheetApproved error:', err);
    }
  },

  /** Called after a timesheet is rejected */
  async onTimesheetRejected(timesheet: {
    id: string;
    employee_id: string;
    period_start?: string;
    period_end?: string;
    rejection_reason?: string;
  }) {
    try {
      const period = timesheet.period_start
        ? ` (${timesheet.period_start} – ${timesheet.period_end})`
        : '';
      await insertNotifications([{
        recipient_id: timesheet.employee_id,
        title: 'Timesheet Rejected',
        message: `Your timesheet${period} was rejected.${timesheet.rejection_reason ? ` Reason: ${timesheet.rejection_reason}` : ''} Please revise and resubmit.`,
        notification_type: 'TIMESHEET_REJECTED',
        entity_type: 'timesheet',
        entity_id: timesheet.id,
        action_url: '/timesheets',
      }]);
    } catch (err) {
      console.error('[NotificationEngine] onTimesheetRejected error:', err);
    }
  },

  /** Called after a DSAR status is updated by HR admin */
  async onDsarStatusUpdated(dsar: {
    dsar_id: string;
    employee_id: string;
    request_status: string;
    request_type?: string;
  }) {
    try {
      const statusMsg: Record<string, string> = {
        IN_REVIEW:  'is now under review',
        COMPLETED:  'has been completed',
        REJECTED:   'has been rejected',
        OVERDUE:    'is now overdue',
      };
      const msg = statusMsg[dsar.request_status] ?? `status changed to ${dsar.request_status}`;
      await insertNotifications([{
        recipient_id: dsar.employee_id,
        title: `DSAR Request Update`,
        message: `Your ${dsar.request_type ?? 'data'} request ${msg}. Visit the ESS portal for details.`,
        notification_type: 'DSAR_STATUS_UPDATED',
        entity_type: 'dsar',
        entity_id: dsar.dsar_id,
        action_url: '/ess',
      }]);
    } catch (err) {
      console.error('[NotificationEngine] onDsarStatusUpdated error:', err);
    }
  },

  /** Get unread count for a recipient (used by bell badge). Omit recipient_id to use current auth user. */
  async getUnreadCount(recipient_id?: string): Promise<number> {
    try {
      let rid = recipient_id;
      if (!rid) {
        const { data } = await db.auth.getUser();
        rid = data?.user?.id;
      }
      if (!rid) return 0;
      const { count } = await db
        .from('notifications')
        .select('id', { count: 'exact', head: true })
        .eq('recipient_id', rid)
        .eq('is_read', false);
      return count ?? 0;
    } catch {
      return 0;
    }
  },

  /** Mark single notification read */
  async markRead(id: string) {
    await db.from('notifications')
      .update({ is_read: true, read_at: new Date().toISOString() })
      .eq('id', id);
  },

  /** Mark all notifications read for a recipient */
  async markAllRead(recipient_id?: string) {
    try {
      let rid = recipient_id;
      if (!rid) {
        const { data } = await db.auth.getUser();
        rid = data?.user?.id;
      }
      if (!rid) return;
      await db.from('notifications')
        .update({ is_read: true, read_at: new Date().toISOString() })
        .eq('recipient_id', rid)
        .eq('is_read', false);
    } catch { /* silent */ }
  },

  /** Fetch recent notifications for dropdown (limit 10) */
  async getRecent(recipient_id?: string, limit = 10) {
    try {
      let rid = recipient_id;
      if (!rid) {
        const { data } = await db.auth.getUser();
        rid = data?.user?.id;
      }
      if (!rid) return [];
      const { data } = await db
        .from('notifications')
        .select('*')
        .eq('recipient_id', rid)
        .order('created_at', { ascending: false })
        .range(0, limit - 1);
      return (data || []) as Record<string, unknown>[];
    } catch {
      return [];
    }
  },

  async getFiltered(
    opts: { unread_only?: boolean; module?: string; limit?: number; recipient_id?: string } = {}
  ) {
    try {
      let rid = opts.recipient_id;
      if (!rid) {
        const { data } = await db.auth.getUser();
        rid = data?.user?.id;
      }
      if (!rid) return [];
      let q = db
        .from('notifications')
        .select('*')
        .eq('recipient_id', rid)
        .order('created_at', { ascending: false })
        .range(0, (opts.limit ?? 30) - 1);
      if (opts.unread_only) q = q.eq('is_read', false);
      if (opts.module)      q = q.eq('module', opts.module);
      const { data } = await q;
      return (data || []) as Record<string, unknown>[];
    } catch {
      return [];
    }
  },

  /** Send a single notification to a specific user */
  async sendToUser(payload: {
    recipient_id: string;
    title: string;
    message: string;
    notification_type: string;
    module: string;
    reference_id?: string;
    action_url?: string;
    entity_type?: string;
    entity_id?: string;
  }) {
    try {
      const { error } = await db.from('notifications').insert({
        recipient_id:      payload.recipient_id,
        title:             payload.title,
        message:           payload.message,
        notification_type: payload.notification_type,
        module:            payload.module,
        reference_id:      payload.reference_id ?? null,
        action_url:        payload.action_url ?? null,
        entity_type:       payload.entity_type ?? null,
        entity_id:         payload.entity_id ?? null,
        is_read:           false,
        created_at:        new Date().toISOString(),
      });
      if (error) throw error;
    } catch (e) {
      console.warn('[notificationEngine.sendToUser] failed:', e);
    }
  },
};

// Re-export TENANT_ID for DSAR admin service
export { TENANT_ID };

