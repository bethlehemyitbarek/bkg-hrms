import { Suspense } from 'react';
import type { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { MainLayout } from '@/app/layouts/MainLayout';

// ── Auth (default exports) ────────────────────────────────────────────────────
import LoginPage         from '@/features/auth/pages/LoginPage';
import MfaVerifyPage     from '@/features/auth/pages/MfaVerifyPage';
import PasswordChangePage from '@/features/auth/pages/PasswordChangePage';
import UnauthorizedPage  from '@/features/auth/pages/UnauthorizedPage';

// ── Core (named exports) ──────────────────────────────────────────────────────
import { DashboardPage }             from '@/features/dashboard/pages/DashboardPage';
import { OrganizationStructurePage } from '@/features/organization-structure/pages/OrganizationStructurePage';
import { EmployeeListPage }          from '@/features/employee-manageme/employee/pages/EmployeeListPage';
import { EmployeeProfilePage }       from '@/features/employee-manageme/employee/pages/EmployeeProfilePage';
import { PositionPage }              from '@/features/position/pages/PositionPage';

// ── Time ──────────────────────────────────────────────────────────────────────
import { AttendancePage }            from '@/features/attendance/pages/AttendancePage';
import { AttendanceDashboardPage }   from '@/features/attendance/pages/AttendanceDashboardPage';
import { WorkCalendarPage }          from '@/features/attendance/pages/WorkCalendarPage';
import { AttendanceCorrectionPage }  from '@/features/attendance/pages/AttendanceCorrectionPage';
import { AttendanceAutoComputePage } from '@/features/attendance/pages/AttendanceAutoComputePage';
import { LeavePage }                 from '@/features/leave/pages/LeavePage';
import { LeaveReportPage }           from '@/features/leave/pages/LeaveReportPage';
import { LeaveManagementConfigPage } from '@/features/leave/pages/LeaveManagementConfigPage';
import { LeaveBalanceRequestPage }   from '@/features/leave/pages/LeaveBalanceRequestPage';
import { TimesheetsPage }            from '@/features/timesheets/pages/TimesheetsPage';
import ProjectsPage                  from '@/features/projects/pages/ProjectsPage';
import { ShiftPage }                 from '@/features/shift/pages/ShiftPage';
import { ShiftManagementPage }       from '@/features/shift/pages/ShiftManagementPage';
import { OvertimePage }              from '@/features/overtime/pages/OvertimePage';

// ── Finance ───────────────────────────────────────────────────────────────────
import { PayrollPage }               from '@/features/payroll/pages/PayrollPage';
import { PayrollRunsPage }           from '@/features/payroll/pages/PayrollRunsPage';
import { PayrollRunDetailPage }      from '@/features/payroll/pages/PayrollRunDetailPage';
import { PayrollComponentsPage }     from '@/features/payroll/pages/PayrollComponentsPage';
import { PayrollApprovalPage }       from '@/features/payroll/pages/PayrollApprovalPage';
import { PayrollReportsPage }        from '@/features/payroll/pages/PayrollReportsPage';
import { PayrollSettingsPage }       from '@/features/payroll/pages/PayrollSettingsPage';
import { SalaryAssignmentPage }      from '@/features/payroll/pages/SalaryAssignmentPage';
import { PayrollComputationPage }    from '@/features/payroll/pages/PayrollComputationPage';
import { ExpensePage }               from '@/features/expense/pages/ExpensePage';
import { BenefitsPage }              from '@/features/benefits/pages/BenefitsPage';
import { AllowanceTypesPage }        from '@/features/benefits/pages/AllowanceTypesPage';
import { CompensationStructurePage } from '@/features/benefits/pages/CompensationStructurePage';
import { CompensationHubPage }       from '@/features/benefits/pages/CompensationHubPage';
import { EmployeeCompensationPage }  from '@/features/benefits/pages/EmployeeCompensationPage';
// ── Pay & Benefits ────────────────────────────────────────────────────────────
import { BenefitPlansPage }          from '@/features/benefits/pages/BenefitPlansPage';
import { BenefitEnrollmentPage }     from '@/features/benefits/pages/BenefitEnrollmentPage';
import { BonusConfigPage }           from '@/features/benefits/pages/BonusConfigPage';
import { LoanPage }                  from '@/features/loan/pages/LoanPage';
import { LoanPolicyPage }            from '@/features/loan/pages/LoanPolicyPage';
import { LoanRequestPage }           from '@/features/loan/pages/LoanRequestPage';

// ── Talent ────────────────────────────────────────────────────────────────────
import { PerformancePage }           from '@/features/performance/pages/PerformancePage';
import { RecruitmentPage }           from '@/features/recruitment/pages/RecruitmentPage';
import { CandidatesPage }            from '@/features/recruitment/pages/CandidatesPage';
import { ExamsPage }                 from '@/features/recruitment/pages/ExamsPage';
import { InterviewsPage }            from '@/features/recruitment/pages/InterviewsPage';
import { OffersPage }                from '@/features/recruitment/pages/OffersPage';
import { VacancyDetailPage }         from '@/features/recruitment/pages/VacancyDetailPage';
import { TrainingPage }              from '@/features/training/pages/TrainingPage';
import { TrainingProgramsPage }      from '@/features/training/pages/TrainingProgramsPage';
import { TransferPromotionPage }     from '@/features/transfer-promotion/pages/TransferPromotionPage';
import { TransferRequestPage }       from '@/features/transfer-promotion/pages/TransferRequestPage';
import { PromotionRequestPage }      from '@/features/transfer-promotion/pages/PromotionRequestPage';

// ── Lifecycle ─────────────────────────────────────────────────────────────────
import { OnboardingPage }            from '@/features/onboarding/pages/OnboardingPage';
import { ProbationPage }             from '@/features/onboarding/pages/ProbationPage';
import { OffboardingPage }           from '@/features/offboarding/pages/OffboardingPage';
import { SeparationPage }            from '@/features/separation/pages/SeparationPage';

// ── Governance ────────────────────────────────────────────────────────────────
import { GrievancePage }             from '@/features/grievance/pages/GrievancePage';
import { ComplianceHubPage }         from '@/features/compliance/pages/ComplianceHubPage';
import { DsarAdminPage }             from '@/features/compliance/pages/DsarAdminPage';
import { DocumentManagementPage }    from '@/features/document/pages/DocumentManagementPage';
import { AssetPage }                 from '@/features/asset/pages/AssetPage';
import AnnouncementPage              from '@/features/announcements/pages/AnnouncementPage';
import AuditLogPage                  from '@/features/audit-log/pages/AuditLogPage';

// ── Self Service ──────────────────────────────────────────────────────────────
import { EssPage }                   from '@/features/ess/pages/EssPage';
import { EssLeaveWorkflowPage }      from '@/features/ess/pages/EssLeaveWorkflowPage';
import { MssPage }                   from '@/features/mss/pages/MssPage';
import { NotificationsPage }         from '@/features/notifications/pages/NotificationsPage';
import { NotificationPreferencesPage } from '@/features/notifications/pages/NotificationPreferencesPage';
import { WorkflowPage }              from '@/features/workflow/pages/WorkflowPage';

// ── System ────────────────────────────────────────────────────────────────────
import { SettingsPage }              from '@/features/settings/pages/SettingsPage';
import { LookupsPage }               from '@/features/lookups/pages/LookupsPage';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  /** Accessible without login. Has no effect when RouteGuard is not active. */
  public?: boolean;
}

// ── Standalone routes (rendered without MainLayout) ───────────────────────────
export const routes: RouteConfig[] = [
  { name: 'Login',           path: '/login',        element: <LoginPage />,          public: true },
  { name: 'MFA Verify',      path: '/mfa-verify',   element: <MfaVerifyPage />,      public: true },
  { name: 'Password Change', path: '/password',     element: <PasswordChangePage />, public: true },
  { name: 'Unauthorized',    path: '/unauthorized', element: <UnauthorizedPage />,   public: true },
];

// ── Layout routes (rendered inside MainLayout via <Outlet />) ─────────────────
export const layoutRoutes: RouteConfig[] = [
  // Core
  { name: 'Dashboard',        path: '/',               element: <DashboardPage />,             public: false },
  { name: 'Organization',     path: '/organization',   element: <OrganizationStructurePage />, public: false },
  { name: 'Employees',        path: '/employees',      element: <EmployeeListPage />,          public: false },
  { name: 'Employee Profile', path: '/employees/:id',  element: <EmployeeProfilePage />,       public: false },
  { name: 'Positions',        path: '/positions',      element: <PositionPage />,              public: false },

  // Time
  { name: 'Attendance',           path: '/attendance',               element: <AttendancePage />,            public: false },
  { name: 'Attendance Dashboard', path: '/attendance/dashboard',     element: <AttendanceDashboardPage />,   public: false },
  { name: 'Work Calendar',        path: '/attendance/work-calendar', element: <WorkCalendarPage />,          public: false },
  { name: 'Corrections',          path: '/attendance/corrections',   element: <AttendanceCorrectionPage />,  public: false },
  { name: 'Auto Compute',         path: '/attendance/auto-compute',  element: <AttendanceAutoComputePage />, public: false },
  { name: 'Leave',                path: '/leave',                    element: <LeavePage />,                 public: false },
  { name: 'Leave Report',         path: '/leave/report',             element: <LeaveReportPage />,           public: false },
  { name: 'Leave Config',         path: '/leave/config',             element: <LeaveManagementConfigPage />, public: false },
  { name: 'Leave Balances',       path: '/leave/balances',           element: <LeaveBalanceRequestPage />,   public: false },
  { name: 'Timesheets',           path: '/timesheets',               element: <TimesheetsPage />,            public: false },
  { name: 'Projects',             path: '/timesheets/projects',      element: <ProjectsPage />,              public: false },
  { name: 'Shifts',               path: '/shifts',                   element: <ShiftPage />,                 public: false },
  { name: 'Shift Management',     path: '/shifts/management',        element: <ShiftManagementPage />,       public: false },
  { name: 'Overtime',             path: '/overtime',                 element: <OvertimePage />,              public: false },

  // Finance
  { name: 'Payroll',           path: '/payroll',                       element: <PayrollPage />,            public: false },
  { name: 'Payroll Runs',      path: '/payroll/runs',                  element: <PayrollRunsPage />,        public: false },
  { name: 'Payroll Run Detail',path: '/payroll/runs/:id',              element: <PayrollRunDetailPage />,   public: false },
  { name: 'Pay Components',    path: '/payroll/components',            element: <PayrollComponentsPage />,  public: false },
  { name: 'Payroll Approval',  path: '/payroll/approval',              element: <PayrollApprovalPage />,    public: false },
  { name: 'Payroll Reports',   path: '/payroll/reports',               element: <PayrollReportsPage />,     public: false },
  { name: 'Payroll Settings',  path: '/payroll/settings',              element: <PayrollSettingsPage />,    public: false },
  { name: 'Salary Assignment', path: '/payroll/salary-assignment',     element: <SalaryAssignmentPage />,   public: false },
  { name: 'Computation',       path: '/payroll/computation',           element: <PayrollComputationPage />, public: false },
  { name: 'Expenses',          path: '/expenses',                      element: <ExpensePage />,            public: false },
  { name: 'Benefits',                  path: '/benefits',                         element: <BenefitsPage />,              public: false },
  { name: 'Allowance Types',           path: '/benefits/allowance-types',         element: <AllowanceTypesPage />,        public: false },
  { name: 'Comp Structures',           path: '/benefits/compensation-structures', element: <CompensationStructurePage />, public: false },
  { name: 'Compensation Hub',          path: '/compensation',                     element: <CompensationHubPage />,       public: false },
  { name: 'Employee Compensation',     path: '/benefits/employee-compensation',   element: <EmployeeCompensationPage />,  public: false },
  { name: 'Benefit Plans',             path: '/benefits/benefit-plans',           element: <BenefitPlansPage />,          public: false },
  { name: 'Benefit Enrollments',       path: '/benefits/enrollments',             element: <BenefitEnrollmentPage />,     public: false },
  { name: 'Bonus Config',              path: '/benefits/bonus-config',            element: <BonusConfigPage />,           public: false },
  { name: 'Loans',             path: '/loans',          element: <LoanPage />,        public: false },
  { name: 'Loan Policies',     path: '/loans/policy',   element: <LoanPolicyPage />,  public: false },
  { name: 'Loan Requests',     path: '/loans/requests', element: <LoanRequestPage />, public: false },

  // Talent
  { name: 'Performance',   path: '/performance',               element: <PerformancePage />,      public: false },
  { name: 'Recruitment',   path: '/recruitment',               element: <RecruitmentPage />,      public: false },
  { name: 'Candidates',    path: '/recruitment/candidates',    element: <CandidatesPage />,       public: false },
  { name: 'Exams',         path: '/recruitment/exams',         element: <ExamsPage />,            public: false },
  { name: 'Interviews',    path: '/recruitment/interviews',    element: <InterviewsPage />,       public: false },
  { name: 'Offers',        path: '/recruitment/offers',        element: <OffersPage />,           public: false },
  { name: 'Vacancy',       path: '/recruitment/vacancies/:id', element: <VacancyDetailPage />,   public: false },
  { name: 'Training',          path: '/training',           element: <TrainingPage />,                          public: false },
  { name: 'Training Programs', path: '/training/programs',  element: <TrainingProgramsPage />,                  public: false },
  { name: 'Transfers',              path: '/transfers',                    element: <TransferPromotionPage />,      public: false },
  { name: 'Transfer Requests',     path: '/transfers/requests',           element: <TransferRequestPage />,        public: false },
  { name: 'Promotions',       path: '/promotions/requests', element: <PromotionRequestPage />,  public: false },

  // Lifecycle
  { name: 'Onboarding',  path: '/onboarding',          element: <OnboardingPage />,   public: false },
  { name: 'Probation',   path: '/onboarding/probation', element: <ProbationPage />,    public: false },
  { name: 'Offboarding', path: '/offboarding',          element: <OffboardingPage />,  public: false },
  { name: 'Separations', path: '/separations',          element: <SeparationPage />,   public: false },

  // Governance
  { name: 'Grievances',     path: '/grievances',            element: <GrievancePage />,           public: false },
  { name: 'Compliance Hub', path: '/governance/compliance', element: <ComplianceHubPage />,       public: false },
  { name: 'DSAR Admin',    path: '/compliance/dsar-admin', element: <DsarAdminPage />,             public: false },
  { name: 'Document Mgmt',  path: '/governance/documents',  element: <DocumentManagementPage />,  public: false },
  { name: 'Assets',         path: '/assets',                element: <AssetPage />,               public: false },
  { name: 'Announcements',  path: '/announcements',         element: <AnnouncementPage />,        public: false },
  { name: 'Audit Log',      path: '/audit-log',             element: <AuditLogPage />,            public: false },

  // Self Service
  { name: 'ESS',               path: '/ess',               element: <EssPage />,              public: false },
  { name: 'ESS Leave Workflow', path: '/ess/leave-workflow', element: <EssLeaveWorkflowPage />, public: false },
  { name: 'MSS',               path: '/mss',               element: <MssPage />,              public: false },
  { name: 'Notifications',              path: '/notifications',             element: <NotificationsPage />,             public: false },
  { name: 'Notification Preferences',  path: '/notifications/preferences',  element: <NotificationPreferencesPage />,   public: false },
  { name: 'Workflow',          path: '/workflow',          element: <WorkflowPage />,         public: false },

  // System
  { name: 'Lookups',  path: '/lookups',  element: <LookupsPage />,  public: false },
  { name: 'Settings', path: '/settings', element: <SettingsPage />, public: false },
];
