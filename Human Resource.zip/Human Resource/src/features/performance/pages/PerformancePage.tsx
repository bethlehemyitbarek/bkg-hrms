import { useState, useEffect, useCallback } from 'react';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { performanceService } from '@/services/performance.service';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { RefreshCw, Plus, BarChart3, Target, Sliders, Settings2, MessageSquare, TrendingUp, BookOpen, Grid3x3, GitMerge, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/db/supabase';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  self_assessment: 'bg-blue-100 text-blue-800',
  manager_review: 'bg-purple-100 text-purple-800',
  completed: 'bg-green-100 text-green-800',
  acknowledged: 'bg-teal-100 text-teal-800',
};

export function PerformancePage() {
  const [reviews, setReviews] = useState<Record<string, unknown>[]>([]);
  const [goals, setGoals] = useState<Record<string, unknown>[]>([]);
  const [cycles, setCycles] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [reviewDialog, setReviewDialog] = useState(false);
  const [goalDialog, setGoalDialog] = useState(false);
  const [saving, setSaving] = useState(false);
  const [reviewForm, setReviewForm] = useState({ employee_id: '', review_type: 'annual', status: 'pending', self_comments: '' });
  const [goalForm, setGoalForm] = useState({ employee_id: '', title: '', description: '', target_value: '', due_date: '', status: 'not_started' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [rev, g, c] = await Promise.all([
        performanceService.listReviews({ page: 1, pageSize: 20 }),
        performanceService.listGoals({}),
        performanceService.listCycles(),
      ]);
      setReviews((rev.data as unknown) as Record<string, unknown>[]);
      setTotal(rev.total);
      setGoals(g as Record<string, unknown>[]);
      setCycles(c as Record<string, unknown>[]);
    } catch { toast.error('Failed to load performance data'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleCreateReview = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (!reviewForm.employee_id || reviewForm.employee_id === 'none') { toast.error('Please select an employee'); setSaving(false); return; }
      await performanceService.createReview(reviewForm as any);
      toast.success('Review created');
      setReviewDialog(false);
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };

  const handleCreateGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (!goalForm.employee_id || goalForm.employee_id === 'none') { toast.error('Please select an employee'); setSaving(false); return; }
      await performanceService.createGoal({ ...goalForm, target_value: goalForm.target_value || null } as any);
      toast.success('Goal created');
      setGoalDialog(false);
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Performance Management</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} reviews · {cycles.length} cycles</p>
        </div>
        <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
      </div>
      <Tabs defaultValue="reviews">
        <TabsList className="h-9 flex-wrap gap-1">
          <TabsTrigger value="reviews"><BarChart3 className="h-3.5 w-3.5 mr-1.5" />Reviews</TabsTrigger>
          <TabsTrigger value="goals"><Target className="h-3.5 w-3.5 mr-1.5" />Goals</TabsTrigger>
          <TabsTrigger value="kpi"><Sliders className="h-3.5 w-3.5 mr-1.5" />KPI / OKR</TabsTrigger>
          <TabsTrigger value="cycles"><Settings2 className="h-3.5 w-3.5 mr-1.5" />Appraisal Cycles</TabsTrigger>
          <TabsTrigger value="feedback"><MessageSquare className="h-3.5 w-3.5 mr-1.5" />360° Feedback</TabsTrigger>
          <TabsTrigger value="pip"><TrendingUp className="h-3.5 w-3.5 mr-1.5" />PIP</TabsTrigger>
          <TabsTrigger value="rating"><BookOpen className="h-3.5 w-3.5 mr-1.5" />Rating Scales</TabsTrigger>
          <TabsTrigger value="ninebox"><Grid3x3 className="h-3.5 w-3.5 mr-1.5" />9-Box Matrix</TabsTrigger>
          <TabsTrigger value="calibration"><GitMerge className="h-3.5 w-3.5 mr-1.5" />Calibration</TabsTrigger>
        </TabsList>
        <TabsContent value="reviews" className="mt-4">
          <div className="flex justify-end mb-3">
            <Dialog open={reviewDialog} onOpenChange={setReviewDialog}>
              <DialogTrigger asChild><Button size="sm"><Plus className="h-4 w-4 mr-1.5" />New Review</Button></DialogTrigger>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                <DialogHeader><DialogTitle>Create Performance Review</DialogTitle></DialogHeader>
                <form onSubmit={handleCreateReview} className="space-y-4 mt-2">
                  <EmployeeSelect value={reviewForm.employee_id} onChange={v => setReviewForm(p => ({ ...p, employee_id: v }))} required />
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Review Type</Label>
                      <Select value={reviewForm.review_type} onValueChange={v => setReviewForm(p => ({ ...p, review_type: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="annual">Annual</SelectItem>
                          <SelectItem value="mid_year">Mid-Year</SelectItem>
                          <SelectItem value="probation">Probation</SelectItem>
                          <SelectItem value="quarterly">Quarterly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label>Status</Label>
                      <Select value={reviewForm.status} onValueChange={v => setReviewForm(p => ({ ...p, status: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="self_assessment">Self-Assessment</SelectItem>
                          <SelectItem value="manager_review">Manager Review</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Comments</Label>
                    <Textarea value={reviewForm.self_comments} onChange={e => setReviewForm(p => ({ ...p, self_comments: e.target.value }))} rows={3} />
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setReviewDialog(false)}>Cancel</Button>
                    <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Create'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Type</TableHead>
                    <TableHead className="whitespace-nowrap">Self Rating</TableHead>
                    <TableHead className="whitespace-nowrap">Manager Rating</TableHead>
                    <TableHead className="whitespace-nowrap">Final Rating</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 7 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                  : reviews.length === 0 ? <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">No reviews found</TableCell></TableRow>
                  : reviews.map((r, i) => {
                    const emp = r.employee as { first_name?: string; last_name?: string } | undefined;
                    return (
                      <TableRow key={String(r.id ?? i)}>
                        <TableCell className="whitespace-nowrap text-sm">{emp ? `${emp.first_name} ${emp.last_name}` : String(r.employee_id ?? '').slice(0, 8)}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm capitalize">{String(r.review_type ?? '').replace('_', ' ')}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{r.self_rating != null ? String(r.self_rating) : '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{r.manager_rating != null ? String(r.manager_rating) : '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm font-medium">{r.final_rating != null ? `${String(r.final_rating)} / 5` : '—'}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${STATUS_COLORS[String(r.status ?? '')] ?? 'bg-muted text-muted-foreground'}`}>
                            {String(r.status ?? '').replace('_', ' ')}
                          </span>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{new Date(String(r.created_at ?? '')).toLocaleDateString()}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>
        <TabsContent value="goals" className="mt-4">
          <div className="flex justify-end mb-3">
            <Dialog open={goalDialog} onOpenChange={setGoalDialog}>
              <DialogTrigger asChild><Button size="sm"><Plus className="h-4 w-4 mr-1.5" />Add Goal</Button></DialogTrigger>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                <DialogHeader><DialogTitle>Create Goal</DialogTitle></DialogHeader>
                <form onSubmit={handleCreateGoal} className="space-y-4 mt-2">
                  <EmployeeSelect value={goalForm.employee_id} onChange={v => setGoalForm(p => ({ ...p, employee_id: v }))} required />
                  <div className="space-y-1.5"><Label>Goal Title *</Label><Input value={goalForm.title} onChange={e => setGoalForm(p => ({ ...p, title: e.target.value }))} required /></div>
                  <div className="space-y-1.5"><Label>Description</Label><Textarea value={goalForm.description} onChange={e => setGoalForm(p => ({ ...p, description: e.target.value }))} rows={2} /></div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5"><Label>Due Date</Label><Input type="date" value={goalForm.due_date} onChange={e => setGoalForm(p => ({ ...p, due_date: e.target.value }))} /></div>
                    <div className="space-y-1.5">
                      <Label>Status</Label>
                      <Select value={goalForm.status} onValueChange={v => setGoalForm(p => ({ ...p, status: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="not_started">Not Started</SelectItem>
                          <SelectItem value="in_progress">In Progress</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setGoalDialog(false)}>Cancel</Button>
                    <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Create'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Title</TableHead>
                    <TableHead className="whitespace-nowrap">Due Date</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 3 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 4 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                  : goals.length === 0 ? <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No goals found</TableCell></TableRow>
                  : goals.map((g, i) => {
                    const emp = g.employee as { first_name?: string; last_name?: string } | undefined;
                    return (
                      <TableRow key={String(g.id ?? i)}>
                        <TableCell className="whitespace-nowrap text-sm">{emp ? `${emp.first_name} ${emp.last_name}` : String(g.employee_id ?? '').slice(0, 8)}</TableCell>
                        <TableCell className="whitespace-nowrap font-medium">{String(g.title ?? '')}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{g.due_date ? String(g.due_date) : '—'}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${g.status === 'completed' ? 'bg-green-100 text-green-800' : g.status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 'bg-muted text-muted-foreground'}`}>
                            {String(g.status ?? '').replace('_', ' ')}
                          </span>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── FR-Per-02: KPI & OKR ── */}
        <TabsContent value="kpi" className="mt-4"><KpiOkrTab /></TabsContent>
        {/* ── FR-Per-03: Appraisal Cycles ── */}
        <TabsContent value="cycles" className="mt-4"><AppraisalCycleTab /></TabsContent>
        {/* ── FR-Per-06/07: 360 Feedback ── */}
        <TabsContent value="feedback" className="mt-4"><FeedbackTab /></TabsContent>
        {/* ── FR-Per-11: PIP ── */}
        <TabsContent value="pip" className="mt-4"><PipTab /></TabsContent>
        {/* ── FR-Per-08/09: Rating Scales ── */}
        <TabsContent value="rating" className="mt-4"><RatingScaleTab /></TabsContent>
        {/* ── FR-Per-13: 9-Box Matrix ── */}
        <TabsContent value="ninebox" className="mt-4"><NineBoxTab /></TabsContent>
        {/* ── FR-Per-10: Calibration ── */}
        <TabsContent value="calibration" className="mt-4"><CalibrationTab /></TabsContent>

      </Tabs>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-Per-02 – KPI / OKR Definition
   ───────────────────────────────────────────────────────────────────────── */
type KpiRow = { kpi_id: string; title: string; kpi_type: string; unit?: string; target_value?: number; weight?: number; description?: string };

function KpiOkrTab() {
  const [rows, setRows] = useState<KpiRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ title: '', kpi_type: 'KPI', unit: '', target_value: '', weight: '', description: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('kpi_definitions').select('*').order('title').limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.title.trim()) { toast.error('Title required'); return; }
    setSaving(true);
    const { error } = await sb.from('kpi_definitions').insert({
      title: form.title, kpi_type: form.kpi_type, unit: form.unit || null,
      target_value: form.target_value ? Number(form.target_value) : null,
      weight: form.weight ? Number(form.weight) : null, description: form.description || null,
    });
    if (error) toast.error(error.message); else { toast.success('KPI/OKR added'); setOpen(false); setForm({ title: '', kpi_type: 'KPI', unit: '', target_value: '', weight: '', description: '' }); load(); }
    setSaving(false);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">KPI & OKR Definitions (FR-Per-02)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add KPI/OKR</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Title</TableHead><TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">Unit</TableHead><TableHead className="whitespace-nowrap">Target</TableHead>
                <TableHead className="whitespace-nowrap">Weight %</TableHead><TableHead>Description</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-6 text-sm">No KPIs/OKRs defined</TableCell></TableRow>}
                {rows.map(r => (
                  <TableRow key={r.kpi_id}>
                    <TableCell className="whitespace-nowrap font-medium">{r.title}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge variant="outline">{r.kpi_type}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap">{r.unit || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.target_value ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.weight ?? '—'}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{r.description || '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add KPI / OKR</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-2">
            <div className="col-span-2 space-y-1.5"><Label>Title *</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Type</Label>
              <Select value={form.kpi_type} onValueChange={v => setForm(p => ({ ...p, kpi_type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="KPI">KPI</SelectItem><SelectItem value="OKR">OKR</SelectItem><SelectItem value="OBJECTIVE">Objective</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Unit</Label><Input value={form.unit} onChange={e => setForm(p => ({ ...p, unit: e.target.value }))} placeholder="%, ETB, count…" /></div>
            <div className="space-y-1.5"><Label>Target Value</Label><Input type="number" value={form.target_value} onChange={e => setForm(p => ({ ...p, target_value: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Weight (%)</Label><Input type="number" min="0" max="100" value={form.weight} onChange={e => setForm(p => ({ ...p, weight: e.target.value }))} /></div>
            <div className="col-span-2 space-y-1.5"><Label>Description</Label><Textarea rows={2} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-Per-03 – Appraisal Cycle Management
   ───────────────────────────────────────────────────────────────────────── */
type CycleRow = { cycle_id: string; cycle_name: string; cycle_type: string; start_date?: string; end_date?: string; status?: string; year?: number };

function AppraisalCycleTab() {
  const [rows, setRows] = useState<CycleRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ cycle_name: '', cycle_type: 'ANNUAL', start_date: '', end_date: '', status: 'DRAFT', year: new Date().getFullYear().toString() });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('performance_cycles').select('*').order('start_date', { ascending: false }).limit(50);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.cycle_name.trim()) { toast.error('Name required'); return; }
    setSaving(true);
    const { error } = await sb.from('performance_cycles').insert({
      cycle_name: form.cycle_name, cycle_type: form.cycle_type, start_date: form.start_date || null,
      end_date: form.end_date || null, status: form.status, year: Number(form.year),
    });
    if (error) toast.error(error.message); else { toast.success('Cycle created'); setOpen(false); load(); }
    setSaving(false);
  };

  const statusColor = (s?: string) => s === 'ACTIVE' ? 'bg-green-100 text-green-800' : s === 'CLOSED' ? 'bg-muted text-muted-foreground' : 'bg-yellow-100 text-yellow-800';

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">Appraisal Cycle Management (FR-Per-03)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />New Cycle</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Cycle Name</TableHead><TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">Year</TableHead><TableHead className="whitespace-nowrap">Start</TableHead>
                <TableHead className="whitespace-nowrap">End</TableHead><TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-6 text-sm">No appraisal cycles defined</TableCell></TableRow>}
                {rows.map(r => (
                  <TableRow key={r.cycle_id}>
                    <TableCell className="whitespace-nowrap font-medium">{r.cycle_name}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge variant="outline">{r.cycle_type}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap">{r.year || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.start_date || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.end_date || '—'}</TableCell>
                    <TableCell><Badge className={statusColor(r.status)}>{r.status || 'DRAFT'}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Create Appraisal Cycle</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-2">
            <div className="col-span-2 space-y-1.5"><Label>Cycle Name *</Label><Input value={form.cycle_name} onChange={e => setForm(p => ({ ...p, cycle_name: e.target.value }))} placeholder="e.g. FY2026 Annual Review" /></div>
            <div className="space-y-1.5"><Label>Type</Label>
              <Select value={form.cycle_type} onValueChange={v => setForm(p => ({ ...p, cycle_type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="ANNUAL">Annual</SelectItem><SelectItem value="MID_YEAR">Mid-Year</SelectItem><SelectItem value="QUARTERLY">Quarterly</SelectItem><SelectItem value="PROBATION">Probation</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Status</Label>
              <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="DRAFT">Draft</SelectItem><SelectItem value="ACTIVE">Active</SelectItem><SelectItem value="CLOSED">Closed</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Start Date</Label><Input type="date" value={form.start_date} onChange={e => setForm(p => ({ ...p, start_date: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>End Date</Label><Input type="date" value={form.end_date} onChange={e => setForm(p => ({ ...p, end_date: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Year</Label><Input type="number" value={form.year} onChange={e => setForm(p => ({ ...p, year: e.target.value }))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-Per-06/07 – 360° Feedback
   ───────────────────────────────────────────────────────────────────────── */
type FeedbackRow = { feedback_request_id: string; reviewee_id: string; relationship_type?: string; is_anonymous?: boolean; status?: string; due_date?: string };

function FeedbackTab() {
  const [rows, setRows] = useState<FeedbackRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ reviewee_id: '', relationship_type: 'PEER', is_anonymous: 'true', due_date: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('feedback_requests').select('*').order('due_date', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.reviewee_id) { toast.error('Select reviewee'); return; }
    setSaving(true);
    const { error } = await sb.from('feedback_requests').insert({
      reviewee_id: form.reviewee_id, relationship_type: form.relationship_type,
      is_anonymous: form.is_anonymous === 'true', due_date: form.due_date || null, status: 'PENDING',
    });
    if (error) toast.error(error.message); else { toast.success('Feedback request created'); setOpen(false); load(); }
    setSaving(false);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">360° Feedback Collection (FR-Per-06/07)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Request Feedback</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Reviewee ID</TableHead><TableHead className="whitespace-nowrap">Relationship</TableHead>
                <TableHead className="whitespace-nowrap">Anonymous</TableHead><TableHead className="whitespace-nowrap">Due Date</TableHead><TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6 text-sm">No feedback requests</TableCell></TableRow>}
                {rows.map(r => (
                  <TableRow key={r.feedback_request_id}>
                    <TableCell className="whitespace-nowrap text-xs">{String(r.reviewee_id).slice(0, 8)}…</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge variant="outline">{r.relationship_type}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap">{r.is_anonymous ? 'Yes' : 'No'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.due_date || '—'}</TableCell>
                    <TableCell><Badge className={r.status === 'COMPLETED' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>{r.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Request 360° Feedback</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Reviewee (Employee) *</Label><EmployeeSelect value={form.reviewee_id} onChange={v => setForm(p => ({ ...p, reviewee_id: v }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Relationship</Label>
                <Select value={form.relationship_type} onValueChange={v => setForm(p => ({ ...p, relationship_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="PEER">Peer</SelectItem><SelectItem value="SUBORDINATE">Subordinate</SelectItem><SelectItem value="MANAGER">Manager</SelectItem><SelectItem value="CROSS_TEAM">Cross-Team</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Anonymous</Label>
                <Select value={form.is_anonymous} onValueChange={v => setForm(p => ({ ...p, is_anonymous: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="true">Yes</SelectItem><SelectItem value="false">No</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5"><Label>Due Date</Label><Input type="date" value={form.due_date} onChange={e => setForm(p => ({ ...p, due_date: e.target.value }))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Submit</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-Per-11 – Performance Improvement Plan (PIP)
   ───────────────────────────────────────────────────────────────────────── */
type PipRow = { pip_id: string; employee_id: string; start_date?: string; end_date?: string; status?: string; objective?: string; support_provided?: string };

function PipTab() {
  const [rows, setRows] = useState<PipRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ employee_id: '', start_date: '', end_date: '', objective: '', support_provided: '', status: 'ACTIVE' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('performance_improvement_plans').select('*').order('start_date', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.employee_id) { toast.error('Select employee'); return; }
    setSaving(true);
    const { error } = await sb.from('performance_improvement_plans').insert({
      employee_id: form.employee_id, start_date: form.start_date || null, end_date: form.end_date || null,
      objective: form.objective || null, support_provided: form.support_provided || null, status: form.status,
    });
    if (error) toast.error(error.message); else { toast.success('PIP created'); setOpen(false); load(); }
    setSaving(false);
  };

  const statusColor = (s?: string) => s === 'COMPLETED' ? 'bg-green-100 text-green-800' : s === 'FAILED' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800';

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">Performance Improvement Plans (FR-Per-11)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />New PIP</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead><TableHead className="whitespace-nowrap">Start</TableHead>
                <TableHead className="whitespace-nowrap">End</TableHead><TableHead className="whitespace-nowrap">Status</TableHead><TableHead>Objective</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6 text-sm">No PIPs on record</TableCell></TableRow>}
                {rows.map(r => (
                  <TableRow key={r.pip_id}>
                    <TableCell className="whitespace-nowrap text-xs">{String(r.employee_id).slice(0, 8)}…</TableCell>
                    <TableCell className="whitespace-nowrap">{r.start_date || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.end_date || '—'}</TableCell>
                    <TableCell><Badge className={statusColor(r.status)}>{r.status}</Badge></TableCell>
                    <TableCell className="text-sm">{r.objective || '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Create PIP</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Employee *</Label><EmployeeSelect value={form.employee_id} onChange={v => setForm(p => ({ ...p, employee_id: v }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Start Date</Label><Input type="date" value={form.start_date} onChange={e => setForm(p => ({ ...p, start_date: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>End Date</Label><Input type="date" value={form.end_date} onChange={e => setForm(p => ({ ...p, end_date: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Objective</Label><Textarea rows={2} value={form.objective} onChange={e => setForm(p => ({ ...p, objective: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Support Provided</Label><Textarea rows={2} value={form.support_provided} onChange={e => setForm(p => ({ ...p, support_provided: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Status</Label>
              <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="ACTIVE">Active</SelectItem><SelectItem value="COMPLETED">Completed</SelectItem><SelectItem value="FAILED">Failed</SelectItem></SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-Per-08/09 – Rating Scale Definition
   ───────────────────────────────────────────────────────────────────────── */
type ScaleRow = { scale_id: string; scale_name: string; min_score?: number; max_score?: number; description?: string };

function RatingScaleTab() {
  const [rows, setRows] = useState<ScaleRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ scale_name: '', min_score: '1', max_score: '5', description: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('rating_scales').select('*').order('scale_name').limit(50);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.scale_name.trim()) { toast.error('Name required'); return; }
    setSaving(true);
    const { error } = await sb.from('rating_scales').insert({ scale_name: form.scale_name, min_score: Number(form.min_score), max_score: Number(form.max_score), description: form.description || null });
    if (error) toast.error(error.message); else { toast.success('Rating scale created'); setOpen(false); load(); }
    setSaving(false);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">Rating Scales (FR-Per-08/09)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />New Scale</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Scale Name</TableHead><TableHead className="whitespace-nowrap">Min</TableHead>
                <TableHead className="whitespace-nowrap">Max</TableHead><TableHead>Description</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-6 text-sm">No rating scales defined</TableCell></TableRow>}
                {rows.map(r => (
                  <TableRow key={r.scale_id}>
                    <TableCell className="whitespace-nowrap font-medium">{r.scale_name}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.min_score ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.max_score ?? '—'}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{r.description || '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Rating Scale</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-2">
            <div className="col-span-2 space-y-1.5"><Label>Scale Name *</Label><Input value={form.scale_name} onChange={e => setForm(p => ({ ...p, scale_name: e.target.value }))} placeholder="e.g. 5-Point Rating Scale" /></div>
            <div className="space-y-1.5"><Label>Min Score</Label><Input type="number" value={form.min_score} onChange={e => setForm(p => ({ ...p, min_score: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Max Score</Label><Input type="number" value={form.max_score} onChange={e => setForm(p => ({ ...p, max_score: e.target.value }))} /></div>
            <div className="col-span-2 space-y-1.5"><Label>Description</Label><Textarea rows={2} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-Per-13 – 9-Box Talent Matrix
   ───────────────────────────────────────────────────────────────────────── */
const NINE_BOX: Record<string, { label: string; color: string }> = {
  '3-1': { label: 'Rough Diamond', color: 'bg-green-50 border-green-200 text-green-900' },
  '3-2': { label: 'High Potential', color: 'bg-green-100 border-green-300 text-green-900' },
  '3-3': { label: 'Star / Top Talent', color: 'bg-emerald-100 border-emerald-300 text-emerald-900' },
  '2-1': { label: 'Core Player / Low', color: 'bg-yellow-50 border-yellow-200 text-yellow-900' },
  '2-2': { label: 'Core Player', color: 'bg-blue-50 border-blue-200 text-blue-900' },
  '2-3': { label: 'Growth Employee', color: 'bg-blue-100 border-blue-300 text-blue-900' },
  '1-1': { label: 'Under-performer', color: 'bg-red-50 border-red-200 text-red-900' },
  '1-2': { label: 'Inconsistent', color: 'bg-orange-50 border-orange-200 text-orange-900' },
  '1-3': { label: 'Risk / Enigma', color: 'bg-yellow-100 border-yellow-300 text-yellow-900' },
};

function NineBoxTab() {
  const [matrix, setMatrix] = useState<Record<string, string[]>>({});
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('performance_reviews')
      .select('employee_id, rating_score, employees!employee_id(first_name,last_name)')
      .not('rating_score', 'is', null).limit(300);
    if (data) {
      const m: Record<string, string[]> = {};
      for (const r of data as Record<string,unknown>[]) {
        const score = Number(r.rating_score) || 0;
        const emp = r.employees as Record<string,unknown>;
        const name = emp ? `${emp.first_name} ${emp.last_name}` : String(r.employee_id).slice(0,8);
        const perf = score >= 4.5 ? 3 : score >= 3 ? 2 : 1;
        const pot = score >= 4 ? 3 : score >= 2.5 ? 2 : 1;
        const key = `${perf}-${pot}`;
        if (!m[key]) m[key] = [];
        m[key].push(name);
      }
      setMatrix(m);
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  if (loading) return <Skeleton className="h-64 bg-muted m-4" />;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">9-Box Talent Matrix (FR-Per-13)</CardTitle>
          <Button size="sm" variant="outline" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-2 flex items-center justify-between text-xs text-muted-foreground px-1">
          <span>← Low Potential | High Potential →</span>
          <span>Performance ↑</span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[3, 2, 1].flatMap(perf => [1, 2, 3].map(pot => {
            const key = `${perf}-${pot}`;
            const info = NINE_BOX[key];
            const names = matrix[key] || [];
            return (
              <div key={key} className={`border rounded-lg p-3 min-h-24 ${info.color}`}>
                <p className="text-xs font-semibold mb-1 text-balance">{info.label}</p>
                <p className="text-[10px] opacity-60 mb-2">P{perf}·P{pot} ({names.length})</p>
                {names.slice(0, 4).map((n, i) => <p key={i} className="text-xs truncate leading-relaxed">{n}</p>)}
                {names.length > 4 && <p className="text-[10px] opacity-60">+{names.length - 4} more</p>}
                {names.length === 0 && <p className="text-xs opacity-40 italic">No employees</p>}
              </div>
            );
          }))}
        </div>
      </CardContent>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-Per-10 – Performance Calibration
   ───────────────────────────────────────────────────────────────────────── */
type CalibRow = { review_id: string; employee_id: string; name: string; original: number; calibrated?: number; cycle: string };

function CalibrationTab() {
  const [rows, setRows] = useState<CalibRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [calibScore, setCalibScore] = useState('');
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('performance_reviews')
      .select('review_id, employee_id, rating_score, calibrated_score, review_type, employees!employee_id(first_name,last_name)')
      .not('rating_score', 'is', null).order('rating_score', { ascending: false }).limit(100);
    if (data) {
      setRows((data as Record<string,unknown>[]).map(r => {
        const emp = r.employees as Record<string,unknown>;
        return { review_id: String(r.review_id), employee_id: String(r.employee_id), name: emp ? `${emp.first_name} ${emp.last_name}` : String(r.employee_id).slice(0,8), original: Number(r.rating_score), calibrated: r.calibrated_score != null ? Number(r.calibrated_score) : undefined, cycle: String(r.review_type) };
      }));
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const saveCalibration = async (reviewId: string) => {
    setSaving(true);
    const { error } = await sb.from('performance_reviews').update({ calibrated_score: Number(calibScore) }).eq('review_id', reviewId);
    if (error) toast.error(error.message); else { toast.success('Score calibrated'); setEditId(null); load(); }
    setSaving(false);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">Performance Calibration (FR-Per-10)</CardTitle>
          <Button size="sm" variant="outline" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead><TableHead className="whitespace-nowrap">Cycle</TableHead>
                <TableHead className="whitespace-nowrap">Original</TableHead><TableHead className="whitespace-nowrap">Calibrated</TableHead><TableHead className="whitespace-nowrap">Action</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6 text-sm">No scores to calibrate</TableCell></TableRow>}
                {rows.map(r => (
                  <TableRow key={r.review_id}>
                    <TableCell className="whitespace-nowrap font-medium">{r.name}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge variant="outline">{r.cycle}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap">{r.original.toFixed(1)}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      {editId === r.review_id ? (
                        <div className="flex gap-2 items-center">
                          <Input type="number" step="0.1" min="0" max="5" value={calibScore} onChange={e => setCalibScore(e.target.value)} className="h-7 w-20 text-sm" />
                          <Button size="sm" className="h-7 text-xs" onClick={() => saveCalibration(r.review_id)} disabled={saving}>Save</Button>
                          <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => setEditId(null)}>✕</Button>
                        </div>
                      ) : (
                        <span className={r.calibrated != null ? 'font-medium text-primary' : 'text-muted-foreground'}>
                          {r.calibrated != null ? r.calibrated.toFixed(1) : 'Not calibrated'}
                        </span>
                      )}
                    </TableCell>
                    <TableCell>
                      {editId !== r.review_id && (
                        <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => { setEditId(r.review_id); setCalibScore(String(r.calibrated ?? r.original)); }}>Calibrate</Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
