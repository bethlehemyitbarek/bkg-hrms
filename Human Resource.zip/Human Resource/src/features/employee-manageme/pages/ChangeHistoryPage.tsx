import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { History, RefreshCw, Search } from 'lucide-react';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = _sb as any;

type ChangeRow = {
  change_id?: string;
  employee_id?: string;
  full_name?: string;
  changed_by?: string;
  change_type?: string;
  field_name?: string;
  old_value?: string;
  new_value?: string;
  change_date?: string;
  reason?: string;
};

const CHANGE_TYPES = ['ALL', 'PROFILE', 'POSITION', 'SALARY', 'STATUS', 'DEPARTMENT', 'TRANSFER', 'MASS_UPDATE'];

export function ChangeHistoryPage() {
  const [rows, setRows] = useState<ChangeRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [total, setTotal] = useState(0);

  const load = useCallback(async () => {
    setLoading(true);
    let query = sb.from('employee_change_history').select('*', { count: 'exact' });
    if (typeFilter !== 'ALL') query = query.eq('change_type', typeFilter);
    if (dateFrom) query = query.gte('change_date', dateFrom);
    if (dateTo) query = query.lte('change_date', dateTo);
    query = query.order('change_date', { ascending: false }).limit(200);
    const { data, count, error } = await query;
    if (error) { toast.error(error.message); setLoading(false); return; }
    setRows(data || []);
    setTotal(count || 0);
    setLoading(false);
  }, [typeFilter, dateFrom, dateTo]);

  useEffect(() => { load(); }, [load]);

  const filtered = rows.filter(r => {
    if (!search) return true;
    const s = search.toLowerCase();
    return (r.full_name || '').toLowerCase().includes(s)
      || (r.field_name || '').toLowerCase().includes(s)
      || (r.changed_by || '').toLowerCase().includes(s)
      || String(r.employee_id || '').includes(s);
  });

  const TYPE_BADGE: Record<string, string> = {
    PROFILE: 'bg-blue-100 text-blue-800',
    POSITION: 'bg-purple-100 text-purple-800',
    SALARY: 'bg-green-100 text-green-800',
    STATUS: 'bg-yellow-100 text-yellow-800',
    DEPARTMENT: 'bg-orange-100 text-orange-800',
    TRANSFER: 'bg-cyan-100 text-cyan-800',
    MASS_UPDATE: 'bg-red-100 text-red-800',
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2"><History className="h-6 w-6 text-primary" />Employee Change History (FR-EM-024)</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} total change records</p>
        </div>
        <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-4 pb-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="space-y-1.5">
              <Label>Search</Label>
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input className="pl-8" placeholder="Name, field, changed by…" value={search} onChange={e => setSearch(e.target.value)} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Change Type</Label>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CHANGE_TYPES.map(t => <SelectItem key={t} value={t}>{t === 'ALL' ? 'All Types' : t.replace(/_/g, ' ')}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>From Date</Label><Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} /></div>
            <div className="space-y-1.5"><Label>To Date</Label><Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} /></div>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">{filtered.length} change records</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? <Skeleton className="h-40 bg-muted" /> : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Change Type</TableHead>
                  <TableHead className="whitespace-nowrap">Field</TableHead>
                  <TableHead className="whitespace-nowrap">Old Value</TableHead>
                  <TableHead className="whitespace-nowrap">New Value</TableHead>
                  <TableHead className="whitespace-nowrap">Changed By</TableHead>
                  <TableHead className="whitespace-nowrap">Date</TableHead>
                  <TableHead className="whitespace-nowrap">Reason</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {filtered.length === 0 && (
                    <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground py-8 text-sm">No change history records found</TableCell></TableRow>
                  )}
                  {filtered.map((r, i) => (
                    <TableRow key={r.change_id || i}>
                      <TableCell className="whitespace-nowrap font-medium">{r.full_name || String(r.employee_id || '').slice(0, 8)}</TableCell>
                      <TableCell><Badge className={TYPE_BADGE[r.change_type || ''] || 'bg-muted text-muted-foreground'}>{r.change_type || '—'}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.field_name || '—'}</TableCell>
                      <TableCell className="max-w-[120px] truncate text-sm text-muted-foreground line-through">{r.old_value || '—'}</TableCell>
                      <TableCell className="max-w-[120px] truncate text-sm font-medium">{r.new_value || '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.changed_by || '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.change_date ? new Date(r.change_date).toLocaleDateString() : '—'}</TableCell>
                      <TableCell className="max-w-[160px] truncate text-sm text-muted-foreground">{r.reason || '—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default ChangeHistoryPage;
