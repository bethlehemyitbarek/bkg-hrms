import { useCallback, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import {
  FileText, Users, UserCheck, AlertTriangle, Globe, Heart,
  Building2, Briefcase, Archive, ClipboardCheck, TrendingUp,
  Download, RefreshCw, Filter,
} from 'lucide-react';
import { supabase } from '@/db/supabase';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

type ReportRow = Record<string, unknown>;

/* ── shared date-range filter ─────────────────────────────────────────── */
function DateRangeFilter({ from, to, onFrom, onTo, onRun, loading }: {
  from: string; to: string; onFrom: (v: string) => void; onTo: (v: string) => void;
  onRun: () => void; loading: boolean;
}) {
  return (
    <div className="flex flex-wrap items-end gap-3 mb-4">
      <div className="space-y-1"><Label className="text-xs">From</Label><Input type="date" value={from} onChange={e => onFrom(e.target.value)} className="h-8 text-sm w-36" /></div>
      <div className="space-y-1"><Label className="text-xs">To</Label><Input type="date" value={to} onChange={e => onTo(e.target.value)} className="h-8 text-sm w-36" /></div>
      <Button size="sm" onClick={onRun} disabled={loading} className="h-8">
        {loading ? <RefreshCw className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Filter className="h-3.5 w-3.5 mr-1.5" />}Run Report
      </Button>
      <Button size="sm" variant="outline" className="h-8" onClick={() => toast.info('Export to Excel/PDF — requires backend integration')}>
        <Download className="h-3.5 w-3.5 mr-1.5" />Export
      </Button>
    </div>
  );
}

function ReportTable({ rows, columns, loading }: { rows: ReportRow[]; columns: { key: string; label: string }[]; loading: boolean }) {
  if (loading) return <div className="space-y-2">{[1,2,3].map(i=><Skeleton key={i} className="h-10 bg-muted"/>)}</div>;
  if (rows.length === 0) return <div className="py-10 text-center text-muted-foreground text-sm">No data found for selected criteria</div>;
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader><TableRow>{columns.map(c=><TableHead key={c.key} className="whitespace-nowrap text-xs">{c.label}</TableHead>)}</TableRow></TableHeader>
        <TableBody>
          {rows.map((r,i)=>(
            <TableRow key={i}>
              {columns.map(c=><TableCell key={c.key} className="whitespace-nowrap text-sm">{String(r[c.key]??'—')}</TableCell>)}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

/* ── FR-REP-001: Acting Assignment Report ───────────────────────────────── */
function ActingAssignmentReport() {
  const [rows, setRows] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');

  const run = useCallback(async () => {
    setLoading(true);
    try {
      let q = sb.from('acting_assignments').select('acting_position, department, start_date, end_date, approval_status, reason, employee_id');
      if (from) q = q.gte('start_date', from);
      if (to) q = q.lte('start_date', to);
      const { data } = await q.order('start_date', { ascending: false }).limit(200);
      setRows(data || []);
    } catch { toast.error('Failed to load report'); } finally { setLoading(false); }
  }, [from, to]);

  const cols = [
    { key: 'acting_position', label: 'Acting Position' }, { key: 'department', label: 'Department' },
    { key: 'start_date', label: 'Start Date' }, { key: 'end_date', label: 'End Date' },
    { key: 'approval_status', label: 'Status' }, { key: 'reason', label: 'Reason' },
  ];
  return (
    <div>
      <DateRangeFilter from={from} to={to} onFrom={setFrom} onTo={setTo} onRun={run} loading={loading} />
      <ReportTable rows={rows} columns={cols} loading={loading} />
    </div>
  );
}

/* ── FR-REP-002: Temporary Assignment Report ────────────────────────────── */
function TempAssignmentReport() {
  const [rows, setRows] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');

  const run = useCallback(async () => {
    setLoading(true);
    try {
      let q = sb.from('work_assignments').select('employee_id, assignment_type, start_date, end_date, location, reason, status');
      if (from) q = q.gte('start_date', from);
      if (to) q = q.lte('start_date', to);
      const { data } = await q.order('start_date', { ascending: false }).limit(200);
      setRows(data || []);
    } catch { toast.error('Failed to load'); } finally { setLoading(false); }
  }, [from, to]);

  const cols = [
    { key: 'employee_id', label: 'Employee ID' }, { key: 'assignment_type', label: 'Type' },
    { key: 'start_date', label: 'Start' }, { key: 'end_date', label: 'End' },
    { key: 'location', label: 'Location' }, { key: 'reason', label: 'Reason' }, { key: 'status', label: 'Status' },
  ];
  return (
    <div>
      <DateRangeFilter from={from} to={to} onFrom={setFrom} onTo={setTo} onRun={run} loading={loading} />
      <ReportTable rows={rows} columns={cols} loading={loading} />
    </div>
  );
}

/* ── FR-REP-003: Document Expiry Report ─────────────────────────────────── */
function DocumentExpiryReport() {
  const [rows, setRows] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [days, setDays] = useState('60');

  const run = useCallback(async () => {
    setLoading(true);
    try {
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() + Number(days));
      const { data } = await sb.from('documents')
        .select('document_id, document_name, document_type, expiry_date, owner_id, status')
        .lte('expiry_date', cutoff.toISOString().slice(0, 10))
        .order('expiry_date', { ascending: true }).limit(200);
      setRows(data || []);
    } catch { toast.error('Failed to load'); } finally { setLoading(false); }
  }, [days]);

  const cols = [
    { key: 'document_name', label: 'Document' }, { key: 'document_type', label: 'Type' },
    { key: 'expiry_date', label: 'Expiry Date' }, { key: 'owner_id', label: 'Owner' },
    { key: 'status', label: 'Status' },
  ];
  return (
    <div>
      <div className="flex flex-wrap items-end gap-3 mb-4">
        <div className="space-y-1">
          <Label className="text-xs">Expiring Within (days)</Label>
          <Select value={days} onValueChange={setDays}>
            <SelectTrigger className="h-8 w-28 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="30">30 days</SelectItem>
              <SelectItem value="60">60 days</SelectItem>
              <SelectItem value="90">90 days</SelectItem>
              <SelectItem value="180">180 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button size="sm" onClick={run} disabled={loading} className="h-8">
          {loading ? <RefreshCw className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Filter className="h-3.5 w-3.5 mr-1.5" />}Run
        </Button>
        <Button size="sm" variant="outline" className="h-8" onClick={() => toast.info('Export functionality')}><Download className="h-3.5 w-3.5 mr-1.5" />Export</Button>
      </div>
      <ReportTable rows={rows} columns={cols} loading={loading} />
    </div>
  );
}

/* ── FR-REP-004: Demographic Diversity Report ───────────────────────────── */
function DemographicDiversityReport() {
  const [rows, setRows] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(false);

  const run = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await sb.from('employees')
        .select('gender, nationality, marital_status, blood_group, disability_status, employment_status')
        .eq('employment_status', 'active').limit(500);
      if (!data) { setRows([]); return; }
      // Aggregate by gender
      const agg: Record<string, { gender: string; count: number }> = {};
      for (const e of data) {
        const g = String(e.gender || 'Unknown');
        if (!agg[g]) agg[g] = { gender: g, count: 0 };
        agg[g].count++;
      }
      setRows(Object.values(agg));
    } catch { toast.error('Failed to load'); } finally { setLoading(false); }
  }, []);

  const cols = [{ key: 'gender', label: 'Gender' }, { key: 'count', label: 'Count' }];
  return (
    <div>
      <div className="flex gap-3 mb-4">
        <Button size="sm" onClick={run} disabled={loading} className="h-8">
          {loading ? <RefreshCw className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Filter className="h-3.5 w-3.5 mr-1.5" />}Generate Report
        </Button>
        <Button size="sm" variant="outline" className="h-8" onClick={() => toast.info('Export')}><Download className="h-3.5 w-3.5 mr-1.5" />Export</Button>
      </div>
      <ReportTable rows={rows} columns={cols} loading={loading} />
    </div>
  );
}

/* ── FR-REP-005: Disability and Inclusion Report ────────────────────────── */
function DisabilityInclusionReport() {
  const [rows, setRows] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(false);

  const run = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await sb.from('employees')
        .select('employee_number, first_name, last_name, disability_status, department_id, employment_status')
        .not('disability_status', 'is', null)
        .neq('disability_status', '')
        .limit(200);
      setRows(data || []);
    } catch { toast.error('Failed to load'); } finally { setLoading(false); }
  }, []);

  const cols = [
    { key: 'employee_number', label: 'Emp #' }, { key: 'first_name', label: 'First' },
    { key: 'last_name', label: 'Last' }, { key: 'disability_status', label: 'Disability Status' },
    { key: 'employment_status', label: 'Status' },
  ];
  return (
    <div>
      <div className="flex gap-3 mb-4">
        <Button size="sm" onClick={run} disabled={loading} className="h-8">
          {loading ? <RefreshCw className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Filter className="h-3.5 w-3.5 mr-1.5" />}Generate
        </Button>
        <Button size="sm" variant="outline" className="h-8" onClick={() => toast.info('Export')}><Download className="h-3.5 w-3.5 mr-1.5" />Export</Button>
      </div>
      <ReportTable rows={rows} columns={cols} loading={loading} />
    </div>
  );
}

/* ── FR-REP-006: Headcount by Cost Center ───────────────────────────────── */
function HeadcountByCostCenterReport() {
  const [rows, setRows] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(false);

  const run = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await sb.from('employees')
        .select('cost_center_id, employment_status')
        .eq('employment_status', 'active').limit(500);
      if (!data) { setRows([]); return; }
      const agg: Record<string, { cost_center: string; headcount: number }> = {};
      for (const e of data) {
        const cc = String(e.cost_center_id || 'Unassigned');
        if (!agg[cc]) agg[cc] = { cost_center: cc, headcount: 0 };
        agg[cc].headcount++;
      }
      setRows(Object.values(agg).sort((a, b) => b.headcount - a.headcount));
    } catch { toast.error('Failed to load'); } finally { setLoading(false); }
  }, []);

  const cols = [{ key: 'cost_center', label: 'Cost Center' }, { key: 'headcount', label: 'Headcount' }];
  return (
    <div>
      <div className="flex gap-3 mb-4">
        <Button size="sm" onClick={run} disabled={loading} className="h-8">
          {loading ? <RefreshCw className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Filter className="h-3.5 w-3.5 mr-1.5" />}Generate
        </Button>
        <Button size="sm" variant="outline" className="h-8" onClick={() => toast.info('Export')}><Download className="h-3.5 w-3.5 mr-1.5" />Export</Button>
      </div>
      <ReportTable rows={rows} columns={cols} loading={loading} />
    </div>
  );
}

/* ── FR-REP-007: Headcount by Contract Type ─────────────────────────────── */
function HeadcountByContractReport() {
  const [rows, setRows] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(false);

  const run = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await sb.from('employees')
        .select('employment_type, employment_status')
        .eq('employment_status', 'active').limit(500);
      if (!data) { setRows([]); return; }
      const agg: Record<string, { contract_type: string; headcount: number }> = {};
      for (const e of data) {
        const ct = String(e.employment_type || 'Unknown');
        if (!agg[ct]) agg[ct] = { contract_type: ct, headcount: 0 };
        agg[ct].headcount++;
      }
      setRows(Object.values(agg).sort((a, b) => b.headcount - a.headcount));
    } catch { toast.error('Failed to load'); } finally { setLoading(false); }
  }, []);

  const cols = [{ key: 'contract_type', label: 'Contract Type' }, { key: 'headcount', label: 'Headcount' }];
  return (
    <div>
      <div className="flex gap-3 mb-4">
        <Button size="sm" onClick={run} disabled={loading} className="h-8">
          {loading ? <RefreshCw className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Filter className="h-3.5 w-3.5 mr-1.5" />}Generate
        </Button>
        <Button size="sm" variant="outline" className="h-8" onClick={() => toast.info('Export')}><Download className="h-3.5 w-3.5 mr-1.5" />Export</Button>
      </div>
      <ReportTable rows={rows} columns={cols} loading={loading} />
    </div>
  );
}

/* ── FR-REP-008: Inactive Employee Archive ──────────────────────────────── */
function InactiveArchiveReport() {
  const [rows, setRows] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(false);

  const run = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await sb.from('employees')
        .select('employee_number, first_name, last_name, employment_status, termination_date, department_id')
        .in('employment_status', ['inactive','terminated'])
        .order('termination_date', { ascending: false }).limit(200);
      setRows(data || []);
    } catch { toast.error('Failed to load'); } finally { setLoading(false); }
  }, []);

  const cols = [
    { key: 'employee_number', label: 'Emp #' }, { key: 'first_name', label: 'First' },
    { key: 'last_name', label: 'Last' }, { key: 'employment_status', label: 'Status' },
    { key: 'termination_date', label: 'Termination Date' },
  ];
  return (
    <div>
      <div className="flex gap-3 mb-4">
        <Button size="sm" onClick={run} disabled={loading} className="h-8">
          {loading ? <RefreshCw className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Filter className="h-3.5 w-3.5 mr-1.5" />}Generate
        </Button>
        <Button size="sm" variant="outline" className="h-8" onClick={() => toast.info('Export')}><Download className="h-3.5 w-3.5 mr-1.5" />Export</Button>
      </div>
      <ReportTable rows={rows} columns={cols} loading={loading} />
    </div>
  );
}

/* ── FR-REP-009: Data Completeness Report ───────────────────────────────── */
function DataCompletenessReport() {
  const [rows, setRows] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(false);

  const run = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await sb.from('employees')
        .select('employee_number, first_name, last_name, email, phone, date_of_birth, national_id, department_id, employment_status')
        .eq('employment_status', 'active').limit(300);
      if (!data) { setRows([]); return; }
      const checked = data.map((e: Record<string,unknown>) => {
        const fields = ['email','phone','date_of_birth','national_id','department_id'];
        const missing = fields.filter(f => !e[f]).map(f => f.replace('_',' '));
        const pct = Math.round(((fields.length - missing.length) / fields.length) * 100);
        return { ...e, completeness: `${pct}%`, missing_fields: missing.join(', ') || 'Complete' };
      });
      setRows(checked);
    } catch { toast.error('Failed to load'); } finally { setLoading(false); }
  }, []);

  const cols = [
    { key: 'employee_number', label: 'Emp #' }, { key: 'first_name', label: 'First' },
    { key: 'last_name', label: 'Last' }, { key: 'completeness', label: 'Completeness %' },
    { key: 'missing_fields', label: 'Missing Fields' },
  ];
  return (
    <div>
      <div className="flex gap-3 mb-4">
        <Button size="sm" onClick={run} disabled={loading} className="h-8">
          {loading ? <RefreshCw className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Filter className="h-3.5 w-3.5 mr-1.5" />}Analyse
        </Button>
        <Button size="sm" variant="outline" className="h-8" onClick={() => toast.info('Export')}><Download className="h-3.5 w-3.5 mr-1.5" />Export</Button>
      </div>
      <ReportTable rows={rows} columns={cols} loading={loading} />
    </div>
  );
}

/* ── FR-REP-010: Employee Movement Report by Period ─────────────────────── */
function MovementReport() {
  const [rows, setRows] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');

  const run = useCallback(async () => {
    setLoading(true);
    try {
      let q = sb.from('employees').select('employee_number, first_name, last_name, hire_date, termination_date, employment_status');
      if (from) q = q.or(`hire_date.gte.${from},termination_date.gte.${from}`);
      if (to) q = q.or(`hire_date.lte.${to},termination_date.lte.${to}`);
      const { data } = await q.order('hire_date', { ascending: false }).limit(200);
      const enriched = (data || []).map((e: Record<string,unknown>) => ({
        ...e,
        movement_type: e.termination_date ? 'Leaver' : 'Joiner',
        movement_date: e.termination_date || e.hire_date,
      }));
      setRows(enriched);
    } catch { toast.error('Failed to load'); } finally { setLoading(false); }
  }, [from, to]);

  const cols = [
    { key: 'employee_number', label: 'Emp #' }, { key: 'first_name', label: 'First' },
    { key: 'last_name', label: 'Last' }, { key: 'movement_type', label: 'Movement' },
    { key: 'movement_date', label: 'Date' }, { key: 'employment_status', label: 'Status' },
  ];
  return (
    <div>
      <DateRangeFilter from={from} to={to} onFrom={setFrom} onTo={setTo} onRun={run} loading={loading} />
      <ReportTable rows={rows} columns={cols} loading={loading} />
    </div>
  );
}

/* ── Report catalog definition ──────────────────────────────────────────── */
const REPORTS = [
  { id: 'acting',        label: 'Acting',       code: 'FR-REP-001', icon: UserCheck,      Comp: ActingAssignmentReport },
  { id: 'temp',          label: 'Temp Assign',  code: 'FR-REP-002', icon: TrendingUp,     Comp: TempAssignmentReport },
  { id: 'doc-expiry',    label: 'Doc Expiry',   code: 'FR-REP-003', icon: AlertTriangle,  Comp: DocumentExpiryReport },
  { id: 'diversity',     label: 'Diversity',    code: 'FR-REP-004', icon: Globe,          Comp: DemographicDiversityReport },
  { id: 'disability',    label: 'Disability',   code: 'FR-REP-005', icon: Heart,          Comp: DisabilityInclusionReport },
  { id: 'cost-center',   label: 'Cost Center',  code: 'FR-REP-006', icon: Building2,      Comp: HeadcountByCostCenterReport },
  { id: 'contract-type', label: 'Contract',     code: 'FR-REP-007', icon: Briefcase,      Comp: HeadcountByContractReport },
  { id: 'inactive',      label: 'Inactive',     code: 'FR-REP-008', icon: Archive,        Comp: InactiveArchiveReport },
  { id: 'completeness',  label: 'Completeness', code: 'FR-REP-009', icon: ClipboardCheck, Comp: DataCompletenessReport },
  { id: 'movement',      label: 'Movement',     code: 'FR-REP-010', icon: TrendingUp,     Comp: MovementReport },
];

export function EmployeeReportsPage() {
  const [activeId, setActiveId] = useState('acting');
  const active = REPORTS.find(r => r.id === activeId)!;

  return (
    <div className="space-y-4">
      {/* Page header */}
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-primary/10"><FileText className="h-5 w-5 text-primary" /></div>
        <div>
          <h1 className="text-xl font-semibold">Employee Reports</h1>
          <p className="text-sm text-muted-foreground">FR-REP-001 to FR-REP-010 — Standard HR employee reports</p>
        </div>
      </div>

      {/* Small nav cards grid — like the screenshot */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
        {REPORTS.map(r => {
          const Icon = r.icon;
          const isActive = r.id === activeId;
          return (
            <button
              key={r.id}
              onClick={() => setActiveId(r.id)}
              className={`flex flex-col items-center gap-2 p-4 rounded-xl border text-center transition-all
                ${isActive
                  ? 'border-primary bg-primary/5 shadow-sm ring-1 ring-primary/20'
                  : 'border-border bg-card hover:bg-muted/50 hover:border-primary/30'
                }`}
            >
              <Icon className={`h-5 w-5 ${isActive ? 'text-primary' : 'text-muted-foreground'}`} />
              <span className={`text-xs font-medium leading-tight ${isActive ? 'text-primary' : 'text-foreground'}`}>
                {r.label}
              </span>
              {isActive && (
                <Badge variant="outline" className="text-[9px] font-mono px-1 py-0 h-4">Active</Badge>
              )}
            </button>
          );
        })}
      </div>

      {/* Active report dashboard */}
      <Card className="w-full">
        <CardHeader className="pb-3 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-md bg-primary/10 shrink-0">
              <active.icon className="h-4 w-4 text-primary" />
            </div>
            <div className="flex items-center gap-2 flex-wrap min-w-0">
              <CardTitle className="text-base">{active.label} Report</CardTitle>
              <Badge variant="outline" className="text-[10px] font-mono shrink-0">{active.code}</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-4">
          <active.Comp />
        </CardContent>
      </Card>
    </div>
  );
}
