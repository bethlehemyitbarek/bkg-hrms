import { useState, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { RefreshCw, Users, PlayCircle, AlertTriangle, CheckCircle2, Loader2 } from 'lucide-react';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = _sb as any;

type MassUpdateField = {
  id: string;
  label: string;
  column: string;
  type: 'text' | 'select' | 'date' | 'number';
  options?: string[];
};

const UPDATABLE_FIELDS: MassUpdateField[] = [
  { id: 'department', label: 'Department', column: 'department_id', type: 'text' },
  { id: 'employment_type', label: 'Employment Type', column: 'employment_type', type: 'select', options: ['FULL_TIME', 'PART_TIME', 'CONTRACT', 'TEMPORARY', 'INTERN'] },
  { id: 'work_location', label: 'Work Location', column: 'work_location', type: 'select', options: ['ON_SITE', 'REMOTE', 'HYBRID'] },
  { id: 'status', label: 'Employee Status', column: 'status', type: 'select', options: ['ACTIVE', 'INACTIVE', 'ON_LEAVE', 'SUSPENDED'] },
  { id: 'job_grade', label: 'Job Grade', column: 'job_grade', type: 'text' },
  { id: 'cost_center', label: 'Cost Center', column: 'cost_center', type: 'text' },
  { id: 'effective_date', label: 'Effective Date', column: 'effective_date', type: 'date' },
];

type PreviewRow = { employee_id: string; full_name?: string; current_value?: string };
type ResultRow = { employee_id: string; full_name?: string; status: 'success' | 'error'; message?: string };

export function MassUpdatePage() {
  const [selectedField, setSelectedField] = useState<string>('');
  const [newValue, setNewValue] = useState('');
  const [filterDept, setFilterDept] = useState('');
  const [filterGrade, setFilterGrade] = useState('');
  const [changeReason, setChangeReason] = useState('');
  const [previewRows, setPreviewRows] = useState<PreviewRow[]>([]);
  const [results, setResults] = useState<ResultRow[]>([]);
  const [loadingPreview, setLoadingPreview] = useState(false);
  const [applying, setApplying] = useState(false);
  const [step, setStep] = useState<'configure' | 'preview' | 'done'>('configure');

  const field = UPDATABLE_FIELDS.find(f => f.id === selectedField);

  const loadPreview = useCallback(async () => {
    if (!selectedField || !newValue) { toast.error('Select field and new value'); return; }
    setLoadingPreview(true);
    let query = sb.from('employees').select('employee_id, full_name, ' + (field?.column || 'status'));
    if (filterDept) query = query.ilike('department_id', `%${filterDept}%`);
    if (filterGrade) query = query.eq('job_grade', filterGrade);
    query = query.limit(200);
    const { data, error } = await query;
    if (error) { toast.error(error.message); setLoadingPreview(false); return; }
    setPreviewRows((data || []).map((r: Record<string, unknown>) => ({ employee_id: String(r.employee_id), full_name: String(r.full_name || '—'), current_value: String(r[field?.column || ''] || '—') })));
    setStep('preview');
    setLoadingPreview(false);
  }, [selectedField, newValue, filterDept, filterGrade, field]);

  const applyUpdate = async () => {
    if (!field || previewRows.length === 0) return;
    setApplying(true);
    const ids = previewRows.map(r => r.employee_id);
    const { error } = await sb.from('employees').update({ [field.column]: newValue }).in('employee_id', ids);
    if (error) {
      toast.error(error.message);
      setResults(previewRows.map(r => ({ employee_id: r.employee_id, full_name: r.full_name, status: 'error', message: error.message })));
    } else {
      toast.success(`Updated ${ids.length} employee(s)`);
      setResults(previewRows.map(r => ({ employee_id: r.employee_id, full_name: r.full_name, status: 'success' })));
      setStep('done');
    }
    setApplying(false);
  };

  const reset = () => { setStep('configure'); setPreviewRows([]); setResults([]); setNewValue(''); setSelectedField(''); setChangeReason(''); };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2"><Users className="h-6 w-6 text-primary" />Mass Update (FR-EM-023)</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Bulk-update employee fields across a filtered set</p>
      </div>

      {/* Step 1: Configure */}
      {step === 'configure' && (
        <Card>
          <CardHeader><CardTitle className="text-base">1. Configure Update</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Field to Update *</Label>
                <Select value={selectedField} onValueChange={v => { setSelectedField(v); setNewValue(''); }}>
                  <SelectTrigger><SelectValue placeholder="Select field…" /></SelectTrigger>
                  <SelectContent>{UPDATABLE_FIELDS.map(f => <SelectItem key={f.id} value={f.id}>{f.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>New Value *</Label>
                {field?.type === 'select' ? (
                  <Select value={newValue} onValueChange={setNewValue}>
                    <SelectTrigger><SelectValue placeholder="Select value…" /></SelectTrigger>
                    <SelectContent>{field.options?.map(o => <SelectItem key={o} value={o}>{o.replace(/_/g, ' ')}</SelectItem>)}</SelectContent>
                  </Select>
                ) : field?.type === 'date' ? (
                  <Input type="date" value={newValue} onChange={e => setNewValue(e.target.value)} />
                ) : (
                  <Input value={newValue} onChange={e => setNewValue(e.target.value)} placeholder="New value…" />
                )}
              </div>
            </div>

            <div className="border border-border rounded-lg p-4 space-y-3">
              <p className="text-sm font-medium text-muted-foreground">Filters (optional — leave blank to affect all employees)</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>Department ID contains</Label><Input value={filterDept} onChange={e => setFilterDept(e.target.value)} /></div>
                <div className="space-y-1.5"><Label>Job Grade equals</Label><Input value={filterGrade} onChange={e => setFilterGrade(e.target.value)} /></div>
              </div>
            </div>

            <div className="space-y-1.5"><Label>Change Reason</Label><Textarea rows={2} value={changeReason} onChange={e => setChangeReason(e.target.value)} placeholder="Reason for mass update…" /></div>

            <div className="flex items-center gap-3 pt-1 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <AlertTriangle className="h-4 w-4 text-yellow-600 shrink-0" />
              <p className="text-xs text-yellow-800">A preview step is required before changes are applied. You can review affected employees before confirming.</p>
            </div>

            <Button onClick={loadPreview} disabled={!selectedField || !newValue || loadingPreview}>
              {loadingPreview ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
              Preview Affected Employees
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Preview */}
      {step === 'preview' && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">2. Preview — {previewRows.length} employee(s) will be updated</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-lg border border-border overflow-hidden">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader><TableRow>
                    <TableHead className="whitespace-nowrap">Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Current: {field?.label}</TableHead>
                    <TableHead className="whitespace-nowrap">New Value</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {loadingPreview ? <TableRow><TableCell colSpan={3}><Skeleton className="h-24 bg-muted" /></TableCell></TableRow>
                      : previewRows.length === 0 ? <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground py-6">No employees match the filters</TableCell></TableRow>
                      : previewRows.map(r => (
                        <TableRow key={r.employee_id}>
                          <TableCell className="whitespace-nowrap font-medium">{r.full_name}</TableCell>
                          <TableCell className="whitespace-nowrap text-muted-foreground">{r.current_value}</TableCell>
                          <TableCell><Badge className="bg-primary/10 text-primary">{newValue}</Badge></TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep('configure')}>Back</Button>
              <Button onClick={applyUpdate} disabled={applying || previewRows.length === 0} className="gap-2">
                {applying ? <Loader2 className="h-4 w-4 animate-spin" /> : <PlayCircle className="h-4 w-4" />}
                Apply to {previewRows.length} Employees
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Done */}
      {step === 'done' && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><CheckCircle2 className="h-5 w-5 text-green-600" />Update Complete</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Message</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {results.map(r => (
                    <TableRow key={r.employee_id}>
                      <TableCell className="whitespace-nowrap font-medium">{r.full_name}</TableCell>
                      <TableCell><Badge className={r.status === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>{r.status}</Badge></TableCell>
                      <TableCell className="text-sm text-muted-foreground">{r.message || 'Updated successfully'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <Button onClick={reset}>Start New Mass Update</Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default MassUpdatePage;
