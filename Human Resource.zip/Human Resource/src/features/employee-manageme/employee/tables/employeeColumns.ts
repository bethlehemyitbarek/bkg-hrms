export const employeeColumns = [
  { key: 'employeeNumber', header: 'Employee No' },
  { key: 'firstName', header: 'First Name' },
  { key: 'lastName', header: 'Last Name' },
  { key: 'email', header: 'Email' },
  { key: 'employmentStatus', header: 'Status' },
];
