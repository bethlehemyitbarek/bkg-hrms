// Module 2.2 — Emergency Contacts tab
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import type { EmergencyContact } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Pencil, Trash2, Phone, Mail, Star } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

const EMPTY: Omit<EmergencyContact, 'id' | 'contact_id' | 'employee_id' | 'created_at' | 'updated_at' | 'is_active' | 'is_deleted'> = {
  full_name: '', relationship: '', phone_number: '', email: '',
  region: '', city: '', sub_city: '', woreda: '', street_name: '', house_number: '', priority: 1,
};

export function EmergencyContactsTab({ employeeId }: { employeeId: string }) {
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<EmergencyContact | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await sb.from('employee_emergency_contacts')
      .select('*').eq('employee_id', employeeId).eq('is_deleted', 0)
      .order('priority', { ascending: true });
    if (error) toast.error(error.message);
    else setContacts(Array.isArray(data) ? data : []);
    setLoading(false);
  }, [employeeId]);

  useEffect(() => { load(); }, [load]);

  function openCreate() {
    setEditing(null);
    setForm({ ...EMPTY });
    setOpen(true);
  }

  function openEdit(c: EmergencyContact) {
    setEditing(c);
    setForm({
      full_name: c.full_name, relationship: c.relationship, phone_number: c.phone_number,
      email: c.email ?? '', region: c.region ?? '', city: c.city ?? '',
      sub_city: c.sub_city ?? '', woreda: c.woreda ?? '',
      street_name: c.street_name ?? '', house_number: c.house_number ?? '', priority: c.priority,
    });
    setOpen(true);
  }

  async function save() {
    if (!form.full_name.trim() || !form.relationship.trim() || !form.phone_number.trim()) {
      toast.error('Name, relationship and phone are required');
      return;
    }
    setSaving(true);
    try {
      const payload = { ...form, employee_id: employeeId, updated_at: new Date().toISOString() };
      const { error } = editing
        ? await sb.from('employee_emergency_contacts').update(payload).eq('id', editing.id)
        : await sb.from('employee_emergency_contacts').insert(payload);
      if (error) throw error;
      toast.success(editing ? 'Contact updated' : 'Contact added');
      setOpen(false);
      load();
    } catch (e: any) { toast.error(e.message); } finally { setSaving(false); }
  }

  async function remove(id: string) {
    const { error } = await sb.from('employee_emergency_contacts')
      .update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Contact removed'); load(); }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">Emergency contacts for this employee</p>
        <Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" />Add Contact</Button>
      </div>

      {loading ? (
        <div className="space-y-2">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-16 w-full bg-muted" />)}</div>
      ) : contacts.length === 0 ? (
        <Card className="h-full"><CardContent className="py-10 text-center text-muted-foreground text-sm">No emergency contacts on record.</CardContent></Card>
      ) : (
        <div className="border rounded-lg overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Priority</TableHead>
                <TableHead className="whitespace-nowrap">Name</TableHead>
                <TableHead className="whitespace-nowrap">Relationship</TableHead>
                <TableHead className="whitespace-nowrap">Phone</TableHead>
                <TableHead className="whitespace-nowrap">Email</TableHead>
                <TableHead className="whitespace-nowrap">City</TableHead>
                <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {contacts.map(c => (
                <TableRow key={c.id}>
                  <TableCell className="whitespace-nowrap">
                    {c.priority === 1 && <Star className="w-4 h-4 text-yellow-500 inline mr-1" />}
                    {c.priority}
                  </TableCell>
                  <TableCell className="whitespace-nowrap font-medium">{c.full_name}</TableCell>
                  <TableCell className="whitespace-nowrap text-sm">{c.relationship}</TableCell>
                  <TableCell className="whitespace-nowrap text-sm">
                    <a href={`tel:${c.phone_number}`} className="flex items-center gap-1 text-primary">
                      <Phone className="w-3 h-3" />{c.phone_number}
                    </a>
                  </TableCell>
                  <TableCell className="whitespace-nowrap text-sm">
                    {c.email ? <a href={`mailto:${c.email}`} className="flex items-center gap-1 text-primary"><Mail className="w-3 h-3" />{c.email}</a> : '—'}
                  </TableCell>
                  <TableCell className="whitespace-nowrap text-sm">{c.city || '—'}</TableCell>
                  <TableCell className="text-right whitespace-nowrap">
                    <Button size="sm" variant="ghost" onClick={() => openEdit(c)}><Pencil className="w-4 h-4" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => remove(c.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-xl">
          <DialogHeader><DialogTitle>{editing ? 'Edit' : 'Add'} Emergency Contact</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><Label>Full Name *</Label><Input value={form.full_name} onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))} /></div>
              <div><Label>Relationship *</Label><Input value={form.relationship} onChange={e => setForm(f => ({ ...f, relationship: e.target.value }))} placeholder="e.g. Spouse, Parent" /></div>
              <div><Label>Phone *</Label><Input value={form.phone_number} onChange={e => setForm(f => ({ ...f, phone_number: e.target.value }))} /></div>
              <div><Label>Email</Label><Input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} /></div>
              <div><Label>Priority (1 = Primary)</Label><Input type="number" min="1" value={form.priority} onChange={e => setForm(f => ({ ...f, priority: parseInt(e.target.value) || 1 }))} /></div>
            </div>
            <p className="text-xs font-semibold uppercase text-muted-foreground">Address</p>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Region</Label><Input value={form.region} onChange={e => setForm(f => ({ ...f, region: e.target.value }))} /></div>
              <div><Label>City</Label><Input value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} /></div>
              <div><Label>Sub-city</Label><Input value={form.sub_city} onChange={e => setForm(f => ({ ...f, sub_city: e.target.value }))} /></div>
              <div><Label>Woreda</Label><Input value={form.woreda} onChange={e => setForm(f => ({ ...f, woreda: e.target.value }))} /></div>
              <div><Label>Street</Label><Input value={form.street_name} onChange={e => setForm(f => ({ ...f, street_name: e.target.value }))} /></div>
              <div><Label>House No.</Label><Input value={form.house_number} onChange={e => setForm(f => ({ ...f, house_number: e.target.value }))} /></div>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save} disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Add Contact'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
