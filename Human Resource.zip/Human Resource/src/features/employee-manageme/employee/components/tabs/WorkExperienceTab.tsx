// Module 2.7 — Work Experience tab
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import type { WorkExperience } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Pencil, Trash2, Briefcase, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

const VERIFY_COLORS: Record<string, string> = {
  VERIFIED: 'bg-green-100 text-green-800',
  PENDING: 'bg-yellow-100 text-yellow-800',
  REJECTED: 'bg-red-100 text-red-800',
  UNVERIFIED: 'bg-muted text-muted-foreground',
};

const EMPTY = {
  company_name: '', job_title: '', employment_type: 'FULL_TIME',
  start_date: '', end_date: '', is_currently_working: '0',
  responsibilities: '', salary: '', salary_currency: 'ETB',
  supervisor_contact: '', reason_for_leaving: '', verification_status: 'UNVERIFIED',
};

export function WorkExperienceTab({ employeeId }: { employeeId: string }) {
  const [records, setRecords] = useState<WorkExperience[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<WorkExperience | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await sb.from('work_experiences')
      .select('*').eq('employee_id', employeeId).eq('is_deleted', 0)
      .order('start_date', { ascending: false, nullsFirst: false });
    if (error) toast.error(error.message);
    else setRecords(Array.isArray(data) ? data : []);
    setLoading(false);
  }, [employeeId]);

  useEffect(() => { load(); }, [load]);

  function openCreate() {
    setEditing(null);
    setForm({ ...EMPTY });
    setOpen(true);
  }

  function openEdit(r: WorkExperience) {
    setEditing(r);
    setForm({
      company_name: r.company_name,
      job_title: r.job_title,
      employment_type: r.employment_type ?? 'FULL_TIME',
      start_date: r.start_date,
      end_date: r.end_date ?? '',
      is_currently_working: String(r.is_currently_working),
      responsibilities: r.responsibilities ?? '',
      salary: String(r.salary ?? ''),
      salary_currency: r.salary_currency ?? 'ETB',
      supervisor_contact: r.supervisor_contact ?? '',
      reason_for_leaving: r.reason_for_leaving ?? '',
      verification_status: r.verification_status,
    });
    setOpen(true);
  }

  async function save() {
    if (!form.company_name.trim() || !form.job_title.trim() || !form.start_date) {
      toast.error('Company, job title and start date are required');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        employee_id: employeeId,
        company_name: form.company_name,
        job_title: form.job_title,
        employment_type: form.employment_type,
        start_date: form.start_date,
        end_date: form.end_date || null,
        is_currently_working: parseInt(form.is_currently_working),
        responsibilities: form.responsibilities || null,
        salary: form.salary ? parseFloat(form.salary) : null,
        salary_currency: form.salary_currency,
        supervisor_contact: form.supervisor_contact || null,
        reason_for_leaving: form.reason_for_leaving || null,
        verification_status: form.verification_status,
        updated_at: new Date().toISOString(),
      };
      const { error } = editing
        ? await sb.from('work_experiences').update(payload).eq('id', editing.id)
        : await sb.from('work_experiences').insert(payload);
      if (error) throw error;
      toast.success(editing ? 'Experience updated' : 'Experience added');
      setOpen(false);
      load();
    } catch (e: any) { toast.error(e.message); } finally { setSaving(false); }
  }

  async function remove(id: string) {
    const { error } = await sb.from('work_experiences')
      .update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Record removed'); load(); }
  }

  const fmtDate = (d?: string | null) => d ? new Date(d).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' }) : 'Present';

  // Total years of experience
  const totalYears = records.reduce((acc, r) => {
    const start = new Date(r.start_date);
    const end = r.end_date ? new Date(r.end_date) : new Date();
    return acc + (end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24 * 365.25);
  }, 0);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground flex items-center gap-2">
          <Briefcase className="w-4 h-4" />
          Previous employment history
          {records.length > 0 && <Badge variant="outline" className="text-xs">{totalYears.toFixed(1)} yrs total</Badge>}
        </p>
        <Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" />Add Experience</Button>
      </div>

      {loading ? (
        <div className="space-y-2">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-20 w-full bg-muted" />)}</div>
      ) : records.length === 0 ? (
        <Card className="h-full"><CardContent className="py-10 text-center text-muted-foreground text-sm">No work experience records found.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {records.map(r => (
            <Card key={r.id} className="h-full">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span className="font-medium text-sm">{r.job_title}</span>
                      <span className="text-muted-foreground text-sm">at {r.company_name}</span>
                      <Badge className={`text-xs ${VERIFY_COLORS[r.verification_status]}`}>
                        <ShieldCheck className="w-3 h-3 mr-1" />{r.verification_status}
                      </Badge>
                    </div>
                    <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                      <span>{fmtDate(r.start_date)} – {r.is_currently_working ? 'Present' : fmtDate(r.end_date)}</span>
                      {r.employment_type && <span>{r.employment_type.replace('_', ' ')}</span>}
                      {r.salary != null && r.salary > 0 && <span>Salary: {r.salary_currency} {r.salary.toLocaleString()}</span>}
                    </div>
                    {r.responsibilities && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{r.responsibilities}</p>}
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button size="sm" variant="ghost" onClick={() => openEdit(r)}><Pencil className="w-4 h-4" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => remove(r.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>{editing ? 'Edit' : 'Add'} Work Experience</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div className="col-span-2"><Label>Company Name *</Label><Input value={form.company_name} onChange={e => setForm(f => ({ ...f, company_name: e.target.value }))} /></div>
              <div>
                <Label>Employment Type</Label>
                <Select value={form.employment_type} onValueChange={v => setForm(f => ({ ...f, employment_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['FULL_TIME','PART_TIME','CONTRACT','INTERNSHIP','TEMPORARY'].map(t => <SelectItem key={t} value={t}>{t.replace('_', ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="col-span-2"><Label>Job Title *</Label><Input value={form.job_title} onChange={e => setForm(f => ({ ...f, job_title: e.target.value }))} /></div>
              <div>
                <Label>Currently Working Here</Label>
                <Select value={form.is_currently_working} onValueChange={v => setForm(f => ({ ...f, is_currently_working: v, end_date: v === '1' ? '' : f.end_date }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="0">No</SelectItem><SelectItem value="1">Yes</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label>Start Date *</Label><Input type="date" value={form.start_date} onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))} /></div>
              {form.is_currently_working === '0' && <div><Label>End Date</Label><Input type="date" value={form.end_date} onChange={e => setForm(f => ({ ...f, end_date: e.target.value }))} /></div>}
              <div><Label>Previous Salary</Label><Input type="number" min="0" step="0.01" value={form.salary} onChange={e => setForm(f => ({ ...f, salary: e.target.value }))} /></div>
              <div><Label>Currency</Label><Input value={form.salary_currency} maxLength={3} onChange={e => setForm(f => ({ ...f, salary_currency: e.target.value.toUpperCase() }))} /></div>
              <div><Label>Supervisor Contact</Label><Input value={form.supervisor_contact} onChange={e => setForm(f => ({ ...f, supervisor_contact: e.target.value }))} /></div>
              <div>
                <Label>Verification Status</Label>
                <Select value={form.verification_status} onValueChange={v => setForm(f => ({ ...f, verification_status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['UNVERIFIED','PENDING','VERIFIED','REJECTED'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Key Responsibilities</Label><Textarea value={form.responsibilities} onChange={e => setForm(f => ({ ...f, responsibilities: e.target.value }))} rows={3} /></div>
            <div><Label>Reason for Leaving</Label><Textarea value={form.reason_for_leaving} onChange={e => setForm(f => ({ ...f, reason_for_leaving: e.target.value }))} rows={2} /></div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save} disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Add'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
