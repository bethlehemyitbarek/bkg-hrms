// Module 2.8 — Professional Credentials tab
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import type { ProfessionalCredential } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Pencil, Trash2, Award, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

const TYPE_COLORS: Record<string, string> = {
  CERTIFICATION: 'bg-blue-100 text-blue-800',
  LICENSE: 'bg-purple-100 text-purple-800',
  TRAINING: 'bg-green-100 text-green-800',
  MEMBERSHIP: 'bg-yellow-100 text-yellow-800',
  OTHER: 'bg-muted text-muted-foreground',
};

const EMPTY = {
  credential_type: 'CERTIFICATION', credential_name: '',
  issuing_authority: '', issue_date: '', expiry_date: '',
  credential_number: '', verification_reference: '',
};

function isExpiringSoon(d?: string | null): boolean {
  if (!d) return false;
  const days = (new Date(d).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
  return days > 0 && days <= 90;
}

function isExpired(d?: string | null): boolean {
  if (!d) return false;
  return new Date(d) < new Date();
}

export function CredentialsTab({ employeeId }: { employeeId: string }) {
  const [records, setRecords] = useState<ProfessionalCredential[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<ProfessionalCredential | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await sb.from('professional_credentials')
      .select('*').eq('employee_id', employeeId).eq('is_deleted', 0)
      .order('expiry_date', { ascending: true, nullsFirst: false });
    if (error) toast.error(error.message);
    else setRecords(Array.isArray(data) ? data : []);
    setLoading(false);
  }, [employeeId]);

  useEffect(() => { load(); }, [load]);

  function openCreate() {
    setEditing(null);
    setForm({ ...EMPTY });
    setOpen(true);
  }

  function openEdit(r: ProfessionalCredential) {
    setEditing(r);
    setForm({
      credential_type: r.credential_type,
      credential_name: r.credential_name,
      issuing_authority: r.issuing_authority ?? '',
      issue_date: r.issue_date ?? '',
      expiry_date: r.expiry_date ?? '',
      credential_number: r.credential_number ?? '',
      verification_reference: r.verification_reference ?? '',
    });
    setOpen(true);
  }

  async function save() {
    if (!form.credential_name.trim()) { toast.error('Credential name is required'); return; }
    setSaving(true);
    try {
      const payload = {
        employee_id: employeeId,
        credential_type: form.credential_type,
        credential_name: form.credential_name,
        issuing_authority: form.issuing_authority || null,
        issue_date: form.issue_date || null,
        expiry_date: form.expiry_date || null,
        credential_number: form.credential_number || null,
        verification_reference: form.verification_reference || null,
        updated_at: new Date().toISOString(),
      };
      const { error } = editing
        ? await sb.from('professional_credentials').update(payload).eq('id', editing.id)
        : await sb.from('professional_credentials').insert(payload);
      if (error) throw error;
      toast.success(editing ? 'Credential updated' : 'Credential added');
      setOpen(false);
      load();
    } catch (e: any) { toast.error(e.message); } finally { setSaving(false); }
  }

  async function remove(id: string) {
    const { error } = await sb.from('professional_credentials')
      .update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Credential removed'); load(); }
  }

  const fmtDate = (d?: string | null) => d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

  const expiring = records.filter(r => isExpiringSoon(r.expiry_date)).length;
  const expired = records.filter(r => isExpired(r.expiry_date)).length;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <p className="text-sm text-muted-foreground flex items-center gap-2"><Award className="w-4 h-4" />Certifications, licenses and memberships</p>
          {expiring > 0 && <Badge className="text-xs bg-yellow-100 text-yellow-800"><AlertTriangle className="w-3 h-3 mr-1" />{expiring} expiring soon</Badge>}
          {expired > 0 && <Badge className="text-xs bg-red-100 text-red-800"><AlertTriangle className="w-3 h-3 mr-1" />{expired} expired</Badge>}
        </div>
        <Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" />Add Credential</Button>
      </div>

      {loading ? (
        <div className="space-y-2">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-20 w-full bg-muted" />)}</div>
      ) : records.length === 0 ? (
        <Card className="h-full"><CardContent className="py-10 text-center text-muted-foreground text-sm">No credentials on record.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {records.map(r => {
            const expired_ = isExpired(r.expiry_date);
            const soon_ = isExpiringSoon(r.expiry_date);
            return (
              <Card key={r.id} className={`h-full ${expired_ ? 'border-red-200' : soon_ ? 'border-yellow-200' : ''}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <Badge className={`text-xs ${TYPE_COLORS[r.credential_type]}`}>{r.credential_type}</Badge>
                        {expired_ && <Badge className="text-xs bg-red-100 text-red-800">Expired</Badge>}
                        {soon_ && !expired_ && <Badge className="text-xs bg-yellow-100 text-yellow-800">Expiring Soon</Badge>}
                      </div>
                      <p className="font-medium text-sm">{r.credential_name}</p>
                      <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mt-1">
                        {r.issuing_authority && <span>{r.issuing_authority}</span>}
                        {r.credential_number && <span>No: {r.credential_number}</span>}
                        <span>Issued: {fmtDate(r.issue_date)}</span>
                        {r.expiry_date && <span className={expired_ ? 'text-red-600 font-medium' : soon_ ? 'text-yellow-700 font-medium' : ''}>Expires: {fmtDate(r.expiry_date)}</span>}
                      </div>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <Button size="sm" variant="ghost" onClick={() => openEdit(r)}><Pencil className="w-4 h-4" /></Button>
                      <Button size="sm" variant="ghost" onClick={() => remove(r.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-xl">
          <DialogHeader><DialogTitle>{editing ? 'Edit' : 'Add'} Credential</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Type</Label>
                <Select value={form.credential_type} onValueChange={v => setForm(f => ({ ...f, credential_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['CERTIFICATION','LICENSE','TRAINING','MEMBERSHIP','OTHER'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="col-span-2"><Label>Credential Name *</Label><Input value={form.credential_name} onChange={e => setForm(f => ({ ...f, credential_name: e.target.value }))} /></div>
              <div className="col-span-2"><Label>Issuing Authority</Label><Input value={form.issuing_authority} onChange={e => setForm(f => ({ ...f, issuing_authority: e.target.value }))} /></div>
              <div><Label>Credential No.</Label><Input value={form.credential_number} onChange={e => setForm(f => ({ ...f, credential_number: e.target.value }))} /></div>
              <div><Label>Verification Reference</Label><Input value={form.verification_reference} onChange={e => setForm(f => ({ ...f, verification_reference: e.target.value }))} /></div>
              <div><Label>Issue Date</Label><Input type="date" value={form.issue_date} onChange={e => setForm(f => ({ ...f, issue_date: e.target.value }))} /></div>
              <div><Label>Expiry Date</Label><Input type="date" value={form.expiry_date} onChange={e => setForm(f => ({ ...f, expiry_date: e.target.value }))} /></div>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save} disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Add'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
