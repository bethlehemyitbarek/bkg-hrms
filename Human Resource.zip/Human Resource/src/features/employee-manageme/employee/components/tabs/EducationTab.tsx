// Module 2.6 — Employee Education tab
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import type { EmployeeEducation } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Pencil, Trash2, GraduationCap } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

const EDUCATION_LEVELS = ['UNATTENDED','8TH_GRADE','10TH_GRADE','12TH_GRADE','TVET','DIPLOMA','BACHELORS','MASTERS','PHD','OTHER'];

const CLEARANCE_COLORS: Record<string, string> = {
  CLEARED: 'bg-green-100 text-green-800',
  NOT_CLEARED: 'bg-red-100 text-red-800',
  IN_PROGRESS: 'bg-yellow-100 text-yellow-800',
};

const EMPTY = {
  education_level: 'BACHELORS', field_of_study: '', institution_name: '',
  country: '', start_date: '', graduation_date: '', grade_or_gpa: '',
  certificate_number: '', university_cost_sharing_status: 'PENDING',
  total_shared_cost: '', remaining_balance: '', currency_code: 'ETB',
  clearance_status: 'NOT_CLEARED',
};

export function EducationTab({ employeeId }: { employeeId: string }) {
  const [records, setRecords] = useState<EmployeeEducation[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<EmployeeEducation | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await sb.from('employee_educations')
      .select('*').eq('employee_id', employeeId).eq('is_deleted', 0)
      .order('graduation_date', { ascending: false, nullsFirst: false });
    if (error) toast.error(error.message);
    else setRecords(Array.isArray(data) ? data : []);
    setLoading(false);
  }, [employeeId]);

  useEffect(() => { load(); }, [load]);

  function openCreate() {
    setEditing(null);
    setForm({ ...EMPTY });
    setOpen(true);
  }

  function openEdit(r: EmployeeEducation) {
    setEditing(r);
    setForm({
      education_level: r.education_level,
      field_of_study: r.field_of_study ?? '',
      institution_name: r.institution_name,
      country: r.country ?? '',
      start_date: r.start_date ?? '',
      graduation_date: r.graduation_date ?? '',
      grade_or_gpa: r.grade_or_gpa ?? '',
      certificate_number: r.certificate_number ?? '',
      university_cost_sharing_status: r.university_cost_sharing_status ?? 'PENDING',
      total_shared_cost: String(r.total_shared_cost ?? ''),
      remaining_balance: String(r.remaining_balance ?? ''),
      currency_code: r.currency_code ?? 'ETB',
      clearance_status: r.clearance_status ?? 'NOT_CLEARED',
    });
    setOpen(true);
  }

  async function save() {
    if (!form.institution_name.trim()) { toast.error('Institution name is required'); return; }
    setSaving(true);
    try {
      const payload = {
        employee_id: employeeId,
        education_level: form.education_level,
        field_of_study: form.field_of_study || null,
        institution_name: form.institution_name,
        country: form.country || null,
        start_date: form.start_date || null,
        graduation_date: form.graduation_date || null,
        grade_or_gpa: form.grade_or_gpa || null,
        certificate_number: form.certificate_number || null,
        university_cost_sharing_status: form.university_cost_sharing_status,
        total_shared_cost: form.total_shared_cost ? parseFloat(form.total_shared_cost) : 0,
        remaining_balance: form.remaining_balance ? parseFloat(form.remaining_balance) : 0,
        currency_code: form.currency_code,
        clearance_status: form.clearance_status,
        updated_at: new Date().toISOString(),
      };
      const { error } = editing
        ? await sb.from('employee_educations').update(payload).eq('id', editing.id)
        : await sb.from('employee_educations').insert(payload);
      if (error) throw error;
      toast.success(editing ? 'Education updated' : 'Education record added');
      setOpen(false);
      load();
    } catch (e: any) { toast.error(e.message); } finally { setSaving(false); }
  }

  async function remove(id: string) {
    const { error } = await sb.from('employee_educations')
      .update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Record removed'); load(); }
  }

  const fmtDate = (d?: string | null) => d ? new Date(d).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' }) : '—';

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground flex items-center gap-2"><GraduationCap className="w-4 h-4" />Academic qualifications and cost-sharing details</p>
        <Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" />Add Education</Button>
      </div>

      {loading ? (
        <div className="space-y-2">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-20 w-full bg-muted" />)}</div>
      ) : records.length === 0 ? (
        <Card className="h-full"><CardContent className="py-10 text-center text-muted-foreground text-sm">No education records found.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {records.map(r => (
            <Card key={r.id} className="h-full">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <Badge variant="secondary" className="text-xs">{r.education_level.replace('_', ' ')}</Badge>
                      {r.clearance_status && <Badge className={`text-xs ${CLEARANCE_COLORS[r.clearance_status]}`}>{r.clearance_status.replace('_', ' ')}</Badge>}
                    </div>
                    <p className="font-medium text-sm">{r.institution_name}</p>
                    {r.field_of_study && <p className="text-xs text-muted-foreground">{r.field_of_study}</p>}
                    <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mt-1">
                      {r.country && <span>{r.country}</span>}
                      <span>{fmtDate(r.start_date)} – {fmtDate(r.graduation_date)}</span>
                      {r.grade_or_gpa && <span>GPA/Grade: {r.grade_or_gpa}</span>}
                      {r.certificate_number && <span>Cert#: {r.certificate_number}</span>}
                    </div>
                    {(r.total_shared_cost != null && r.total_shared_cost > 0) && (
                      <div className="mt-1 text-xs text-muted-foreground">
                        Cost Sharing: {r.currency_code} {r.total_shared_cost?.toLocaleString()} · Remaining: {r.currency_code} {r.remaining_balance?.toLocaleString()}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button size="sm" variant="ghost" onClick={() => openEdit(r)}><Pencil className="w-4 h-4" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => remove(r.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>{editing ? 'Edit' : 'Add'} Education Record</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <Label>Education Level *</Label>
                <Select value={form.education_level} onValueChange={v => setForm(f => ({ ...f, education_level: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{EDUCATION_LEVELS.map(l => <SelectItem key={l} value={l}>{l.replace('_', ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="col-span-2"><Label>Institution Name *</Label><Input value={form.institution_name} onChange={e => setForm(f => ({ ...f, institution_name: e.target.value }))} /></div>
              <div className="col-span-2"><Label>Field of Study</Label><Input value={form.field_of_study} onChange={e => setForm(f => ({ ...f, field_of_study: e.target.value }))} /></div>
              <div><Label>Country</Label><Input value={form.country} onChange={e => setForm(f => ({ ...f, country: e.target.value }))} /></div>
              <div><Label>Start Date</Label><Input type="date" value={form.start_date} onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))} /></div>
              <div><Label>Graduation Date</Label><Input type="date" value={form.graduation_date} onChange={e => setForm(f => ({ ...f, graduation_date: e.target.value }))} /></div>
              <div><Label>GPA / Grade</Label><Input value={form.grade_or_gpa} onChange={e => setForm(f => ({ ...f, grade_or_gpa: e.target.value }))} /></div>
              <div><Label>Certificate No.</Label><Input value={form.certificate_number} onChange={e => setForm(f => ({ ...f, certificate_number: e.target.value }))} /></div>
              <div>
                <Label>Clearance Status</Label>
                <Select value={form.clearance_status} onValueChange={v => setForm(f => ({ ...f, clearance_status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="CLEARED">Cleared</SelectItem><SelectItem value="NOT_CLEARED">Not Cleared</SelectItem><SelectItem value="IN_PROGRESS">In Progress</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <p className="text-xs font-semibold uppercase text-muted-foreground">Cost Sharing</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <Label>Status</Label>
                <Select value={form.university_cost_sharing_status} onValueChange={v => setForm(f => ({ ...f, university_cost_sharing_status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['PAID_FULL','ACTIVE','EXEMPT','PENDING'].map(s => <SelectItem key={s} value={s}>{s.replace('_', ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Total Cost</Label><Input type="number" min="0" step="0.01" value={form.total_shared_cost} onChange={e => setForm(f => ({ ...f, total_shared_cost: e.target.value }))} /></div>
              <div><Label>Remaining Balance</Label><Input type="number" min="0" step="0.01" value={form.remaining_balance} onChange={e => setForm(f => ({ ...f, remaining_balance: e.target.value }))} /></div>
              <div><Label>Currency</Label><Input value={form.currency_code} maxLength={3} onChange={e => setForm(f => ({ ...f, currency_code: e.target.value.toUpperCase() }))} /></div>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save} disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Add'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
