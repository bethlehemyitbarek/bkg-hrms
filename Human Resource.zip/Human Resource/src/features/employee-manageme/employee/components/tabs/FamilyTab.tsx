// Module 2.4 — Employee Family tab
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import type { EmployeeFamily } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Plus, Pencil, Trash2, Heart, Users } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

type FamilyForm = {
  dependant_relationship: string;
  full_name: string;
  dependant_date_of_birth: string;
  gender: string;
  is_tax_dependent: string;
  is_benefit_eligible: string;
  spouse_full_name: string;
  spouse_date_of_birth: string;
  marriage_date: string;
  spouse_phone_number: string;
  spouse_occupation: string;
};

const EMPTY: FamilyForm = {
  dependant_relationship: 'CHILD',
  full_name: '', dependant_date_of_birth: '', gender: 'MALE',
  is_tax_dependent: '0', is_benefit_eligible: '0',
  spouse_full_name: '', spouse_date_of_birth: '', marriage_date: '',
  spouse_phone_number: '', spouse_occupation: '',
};

const REL_COLORS: Record<string, string> = {
  CHILD: 'bg-blue-100 text-blue-800',
  SPOUSE: 'bg-pink-100 text-pink-800',
  PARENT: 'bg-green-100 text-green-800',
  OTHER: 'bg-muted text-muted-foreground',
};

export function FamilyTab({ employeeId }: { employeeId: string }) {
  const [members, setMembers] = useState<EmployeeFamily[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<EmployeeFamily | null>(null);
  const [form, setForm] = useState<FamilyForm>({ ...EMPTY });
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await sb.from('employee_families')
      .select('*').eq('employee_id', employeeId).eq('is_deleted', 0)
      .order('created_at', { ascending: true });
    if (error) toast.error(error.message);
    else setMembers(Array.isArray(data) ? data : []);
    setLoading(false);
  }, [employeeId]);

  useEffect(() => { load(); }, [load]);

  function openCreate() {
    setEditing(null);
    setForm({ ...EMPTY });
    setOpen(true);
  }

  function openEdit(m: EmployeeFamily) {
    setEditing(m);
    setForm({
      dependant_relationship: m.dependant_relationship ?? 'CHILD',
      full_name: m.full_name ?? '',
      dependant_date_of_birth: m.dependant_date_of_birth ?? '',
      gender: m.gender ?? 'MALE',
      is_tax_dependent: String(m.is_tax_dependent),
      is_benefit_eligible: String(m.is_benefit_eligible),
      spouse_full_name: m.spouse_full_name ?? '',
      spouse_date_of_birth: m.spouse_date_of_birth ?? '',
      marriage_date: m.marriage_date ?? '',
      spouse_phone_number: m.spouse_phone_number ?? '',
      spouse_occupation: m.spouse_occupation ?? '',
    });
    setOpen(true);
  }

  async function save() {
    if (!form.full_name.trim() && !form.spouse_full_name.trim()) {
      toast.error('Please fill in name fields');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        employee_id: employeeId,
        dependant_relationship: form.dependant_relationship || null,
        full_name: form.full_name || null,
        dependant_date_of_birth: form.dependant_date_of_birth || null,
        gender: form.gender || null,
        is_tax_dependent: parseInt(form.is_tax_dependent),
        is_benefit_eligible: parseInt(form.is_benefit_eligible),
        spouse_full_name: form.spouse_full_name || null,
        spouse_date_of_birth: form.spouse_date_of_birth || null,
        marriage_date: form.marriage_date || null,
        spouse_phone_number: form.spouse_phone_number || null,
        spouse_occupation: form.spouse_occupation || null,
        updated_at: new Date().toISOString(),
      };
      const { error } = editing
        ? await sb.from('employee_families').update(payload).eq('id', editing.id)
        : await sb.from('employee_families').insert(payload);
      if (error) throw error;
      toast.success(editing ? 'Family record updated' : 'Family member added');
      setOpen(false);
      load();
    } catch (e: any) { toast.error(e.message); } finally { setSaving(false); }
  }

  async function remove(id: string) {
    const { error } = await sb.from('employee_families')
      .update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Record removed'); load(); }
  }

  const isSpouse = (m: EmployeeFamily) => m.dependant_relationship === 'SPOUSE';

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground flex items-center gap-2"><Users className="w-4 h-4" />Dependants and family members</p>
        <Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" />Add Member</Button>
      </div>

      {loading ? (
        <div className="space-y-2">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-16 w-full bg-muted" />)}</div>
      ) : members.length === 0 ? (
        <Card className="h-full"><CardContent className="py-10 text-center text-muted-foreground text-sm">No family members on record.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {members.map(m => (
            <Card key={m.id} className="h-full">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge className={`text-xs ${REL_COLORS[m.dependant_relationship ?? 'OTHER']}`}>{m.dependant_relationship ?? 'OTHER'}</Badge>
                      <span className="font-medium text-sm">{m.full_name || m.spouse_full_name || '—'}</span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs text-muted-foreground">
                      {m.dependant_date_of_birth && <span>DOB: {new Date(m.dependant_date_of_birth).toLocaleDateString()}</span>}
                      {m.gender && <span>Gender: {m.gender}</span>}
                      {m.is_tax_dependent === 1 && <span className="text-primary">Tax Dependent</span>}
                      {m.is_benefit_eligible === 1 && <span className="text-primary">Benefit Eligible</span>}
                    </div>
                    {isSpouse(m) && m.spouse_full_name && (
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Heart className="w-3 h-3 text-pink-500" />
                        <span>{m.spouse_full_name}</span>
                        {m.marriage_date && <span>· Married: {new Date(m.marriage_date).toLocaleDateString()}</span>}
                        {m.spouse_occupation && <span>· {m.spouse_occupation}</span>}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button size="sm" variant="ghost" onClick={() => openEdit(m)}><Pencil className="w-4 h-4" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => remove(m.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-xl">
          <DialogHeader><DialogTitle>{editing ? 'Edit' : 'Add'} Family Member</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Relationship</Label>
                <Select value={form.dependant_relationship} onValueChange={v => setForm(f => ({ ...f, dependant_relationship: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['CHILD','SPOUSE','PARENT','OTHER'].map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Full Name</Label><Input value={form.full_name} onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))} /></div>
              <div><Label>Date of Birth</Label><Input type="date" value={form.dependant_date_of_birth} onChange={e => setForm(f => ({ ...f, dependant_date_of_birth: e.target.value }))} /></div>
              <div>
                <Label>Gender</Label>
                <Select value={form.gender} onValueChange={v => setForm(f => ({ ...f, gender: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="MALE">Male</SelectItem><SelectItem value="FEMALE">Female</SelectItem></SelectContent>
                </Select>
              </div>
              <div>
                <Label>Tax Dependent</Label>
                <Select value={form.is_tax_dependent} onValueChange={v => setForm(f => ({ ...f, is_tax_dependent: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="0">No</SelectItem><SelectItem value="1">Yes</SelectItem></SelectContent>
                </Select>
              </div>
              <div>
                <Label>Benefit Eligible</Label>
                <Select value={form.is_benefit_eligible} onValueChange={v => setForm(f => ({ ...f, is_benefit_eligible: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="0">No</SelectItem><SelectItem value="1">Yes</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            {form.dependant_relationship === 'SPOUSE' && (
              <>
                <Separator />
                <p className="text-xs font-semibold uppercase text-muted-foreground">Spouse Details</p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2"><Label>Spouse Full Name</Label><Input value={form.spouse_full_name} onChange={e => setForm(f => ({ ...f, spouse_full_name: e.target.value }))} /></div>
                  <div><Label>Spouse Date of Birth</Label><Input type="date" value={form.spouse_date_of_birth} onChange={e => setForm(f => ({ ...f, spouse_date_of_birth: e.target.value }))} /></div>
                  <div><Label>Marriage Date</Label><Input type="date" value={form.marriage_date} onChange={e => setForm(f => ({ ...f, marriage_date: e.target.value }))} /></div>
                  <div><Label>Spouse Phone</Label><Input value={form.spouse_phone_number} onChange={e => setForm(f => ({ ...f, spouse_phone_number: e.target.value }))} /></div>
                  <div><Label>Occupation</Label><Input value={form.spouse_occupation} onChange={e => setForm(f => ({ ...f, spouse_occupation: e.target.value }))} /></div>
                </div>
              </>
            )}
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save} disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Add'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
