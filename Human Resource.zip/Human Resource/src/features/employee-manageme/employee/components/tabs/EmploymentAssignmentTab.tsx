// Module 2.3 + 2.5 — Employment Details & Work Assignment tab
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import type { WorkAssignment } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Pencil, Briefcase, Building2, MapPin, Users } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

const STATUS_COLORS: Record<string, string> = {
  ACTIVE: 'bg-green-100 text-green-800',
  TRANSFERRED: 'bg-blue-100 text-blue-800',
  ENDED: 'bg-muted text-muted-foreground',
  ACTING: 'bg-yellow-100 text-yellow-800',
};

const EMPTY_ASSIGN = {
  employment_category: 'FULL_TIME' as const,
  job_title: '', union_code: '', shift_code: '', fte_ratio: '1.00',
  change_reason: '', assignment_status: 'ACTIVE' as const,
  effective_from: new Date().toISOString().split('T')[0],
  department_id: '', position_id: '', location_id: '',
  direct_manager_id: '', dotted_manager_id: '', cost_center_id: '',
};

export function EmploymentAssignmentTab({ employeeId }: { employeeId: string }) {
  const [assignments, setAssignments] = useState<WorkAssignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [departments, setDepartments] = useState<{ id: string; name: string }[]>([]);
  const [positions, setPositions] = useState<{ id: string; title: string }[]>([]);
  const [locations, setLocations] = useState<{ id: string; name: string }[]>([]);
  const [managers, setManagers] = useState<{ id: string; first_name: string; last_name: string }[]>([]);

  // Employment Details state
  const [empDetail, setEmpDetail] = useState<Record<string, any> | null>(null);
  const [edLoading, setEdLoading] = useState(true);
  const [edOpen, setEdOpen] = useState(false);
  const [edForm, setEdForm] = useState({
    worker_type: 'EMPLOYEE', employment_type_v2: 'PERMANENT', contract_type: 'PERMANENT',
    hire_reason: '', termination_reason: '', original_hire_date: '',
    employment_start_date: '', employment_end_date: '', notice_period_days: '60',
    is_rehire_eligible: '1', salary_amount: '', salary_grade: '', employment_number: '',
  });
  const [edSaving, setEdSaving] = useState(false);

  // Assignment dialog
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ ...EMPTY_ASSIGN });
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await sb.from('work_assignments')
      .select('*,department:departments(id,name),position:positions(id,title),location:locations(id,name),direct_manager:employees!work_assignments_direct_manager_id_fkey(id,first_name,last_name)')
      .eq('employee_id', employeeId).eq('is_deleted', 0)
      .order('effective_from', { ascending: false });
    if (error) toast.error(error.message);
    else setAssignments(Array.isArray(data) ? data : []);
    setLoading(false);
  }, [employeeId]);

  const loadEmpDetail = useCallback(async () => {
    setEdLoading(true);
    const { data } = await sb.from('employment_details').select('*').eq('employee_id', employeeId).order('created_at', { ascending: false }).limit(1).maybeSingle();
    setEmpDetail(data);
    if (data) {
      setEdForm({
        worker_type: data.worker_type ?? 'EMPLOYEE',
        employment_type_v2: data.employment_type_v2 ?? 'PERMANENT',
        contract_type: data.contract_type ?? 'PERMANENT',
        hire_reason: data.hire_reason ?? '',
        termination_reason: data.termination_reason ?? '',
        original_hire_date: data.original_hire_date ?? '',
        employment_start_date: data.employment_start_date ?? '',
        employment_end_date: data.employment_end_date ?? '',
        notice_period_days: String(data.notice_period_days ?? 60),
        is_rehire_eligible: String(data.is_rehire_eligible ?? 1),
        salary_amount: String(data.salary_amount ?? ''),
        salary_grade: data.salary_grade ?? '',
        employment_number: data.employment_number ?? '',
      });
    }
    setEdLoading(false);
  }, [employeeId]);

  const loadRefs = useCallback(async () => {
    const [dRes, pRes, lRes, mRes] = await Promise.all([
      sb.from('departments').select('id,name').order('name').limit(100),
      sb.from('positions').select('id,title').order('title').limit(100),
      sb.from('locations').select('id,name').order('name').limit(100),
      sb.from('employees').select('id,first_name,last_name').eq('is_active', true).order('first_name').limit(100),
    ]);
    setDepartments(Array.isArray(dRes.data) ? dRes.data : []);
    setPositions(Array.isArray(pRes.data) ? pRes.data : []);
    setLocations(Array.isArray(lRes.data) ? lRes.data : []);
    setManagers(Array.isArray(mRes.data) ? mRes.data : []);
  }, []);

  useEffect(() => { load(); loadEmpDetail(); loadRefs(); }, [load, loadEmpDetail, loadRefs]);

  async function saveEmpDetail() {
    setEdSaving(true);
    try {
      const payload = {
        employee_id: employeeId,
        worker_type: edForm.worker_type,
        employment_type_v2: edForm.employment_type_v2,
        contract_type: edForm.contract_type,
        hire_reason: edForm.hire_reason || null,
        termination_reason: edForm.termination_reason || null,
        original_hire_date: edForm.original_hire_date || null,
        employment_start_date: edForm.employment_start_date || null,
        employment_end_date: edForm.employment_end_date || null,
        notice_period_days: parseInt(edForm.notice_period_days) || 60,
        is_rehire_eligible: parseInt(edForm.is_rehire_eligible),
        salary_amount: edForm.salary_amount ? parseFloat(edForm.salary_amount) : null,
        salary_grade: edForm.salary_grade || null,
        employment_number: edForm.employment_number || null,
        updated_at: new Date().toISOString(),
      };
      const { error } = empDetail
        ? await sb.from('employment_details').update(payload).eq('id', empDetail.id)
        : await sb.from('employment_details').insert(payload);
      if (error) throw error;
      toast.success('Employment details saved');
      setEdOpen(false);
      loadEmpDetail();
    } catch (e: any) { toast.error(e.message); } finally { setEdSaving(false); }
  }

  function openCreate() {
    setEditingId(null);
    setForm({ ...EMPTY_ASSIGN });
    setOpen(true);
  }

  function openEdit(a: WorkAssignment) {
    setEditingId(a.id);
    setForm({
      employment_category: (a.employment_category as any) ?? 'FULL_TIME',
      job_title: a.job_title ?? '',
      union_code: a.union_code ?? '',
      shift_code: a.shift_code ?? '',
      fte_ratio: String(a.fte_ratio ?? 1.00),
      change_reason: a.change_reason ?? '',
      assignment_status: a.assignment_status as any,
      effective_from: a.effective_from ? a.effective_from.split('T')[0] : '',
      department_id: a.department_id ?? '',
      position_id: a.position_id ?? '',
      location_id: a.location_id ?? '',
      direct_manager_id: a.direct_manager_id ?? '',
      dotted_manager_id: a.dotted_manager_id ?? '',
      cost_center_id: a.cost_center_id ?? '',
    });
    setOpen(true);
  }

  async function save() {
    setSaving(true);
    try {
      const payload: Record<string, any> = {
        employee_id: employeeId,
        employment_category: form.employment_category,
        job_title: form.job_title || null,
        union_code: form.union_code || null,
        shift_code: form.shift_code || null,
        fte_ratio: parseFloat(form.fte_ratio) || 1.00,
        change_reason: form.change_reason || null,
        assignment_status: form.assignment_status,
        effective_from: form.effective_from || new Date().toISOString(),
        department_id: form.department_id || null,
        position_id: form.position_id || null,
        location_id: form.location_id || null,
        direct_manager_id: form.direct_manager_id || null,
        dotted_manager_id: form.dotted_manager_id || null,
        cost_center_id: form.cost_center_id || null,
        updated_at: new Date().toISOString(),
      };
      const { error } = editingId
        ? await sb.from('work_assignments').update(payload).eq('id', editingId)
        : await sb.from('work_assignments').insert(payload);
      if (error) throw error;
      toast.success(editingId ? 'Assignment updated' : 'Assignment created');
      setOpen(false);
      load();
    } catch (e: any) { toast.error(e.message); } finally { setSaving(false); }
  }

  const SEL = (v: string) => v || '__none__';
  const UNSEL = (v: string) => v === '__none__' ? '' : v;

  const InfoRow = ({ label, value }: { label: string; value: string }) => (
    <div><p className="text-xs text-muted-foreground">{label}</p><p className="text-sm font-medium">{value}</p></div>
  );

  return (
    <div className="space-y-4">
      {/* Employment Details */}
      <Card className="h-full">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm flex items-center gap-2"><Briefcase className="w-4 h-4" />Employment Details (2.3)</CardTitle>
            <Button size="sm" variant="ghost" onClick={() => setEdOpen(true)}><Pencil className="w-4 h-4" /></Button>
          </div>
        </CardHeader>
        <CardContent>
          {edLoading ? <Skeleton className="h-16 w-full bg-muted" /> : empDetail ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <InfoRow label="Worker Type" value={empDetail.worker_type ?? '—'} />
              <InfoRow label="Employment Type" value={empDetail.employment_type_v2 ?? '—'} />
              <InfoRow label="Contract Type" value={empDetail.contract_type ?? '—'} />
              <InfoRow label="Employment No." value={empDetail.employment_number ?? '—'} />
              <InfoRow label="Notice Period" value={empDetail.notice_period_days ? `${empDetail.notice_period_days} days` : '—'} />
              <InfoRow label="Rehire Eligible" value={empDetail.is_rehire_eligible ? 'Yes' : 'No'} />
              <InfoRow label="Salary Grade" value={empDetail.salary_grade ?? '—'} />
              <InfoRow label="Salary Amount" value={empDetail.salary_amount ? `ETB ${parseFloat(empDetail.salary_amount).toLocaleString()}` : '—'} />
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No employment detail record — click edit to add.</p>
          )}
        </CardContent>
      </Card>

      {/* Work Assignments */}
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium flex items-center gap-2"><Building2 className="w-4 h-4" />Work Assignments (2.5)</p>
        <Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" />New Assignment</Button>
      </div>

      {loading ? (
        <div className="space-y-2">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-16 w-full bg-muted" />)}</div>
      ) : assignments.length === 0 ? (
        <Card className="h-full"><CardContent className="py-10 text-center text-muted-foreground text-sm">No work assignments recorded.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {assignments.map(a => (
            <Card key={a.id} className="h-full">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge className={`text-xs ${STATUS_COLORS[a.assignment_status]}`}>{a.assignment_status}</Badge>
                      {a.employment_category && <Badge variant="secondary" className="text-xs">{a.employment_category.replace('_', ' ')}</Badge>}
                      {a.fte_ratio != null && a.fte_ratio !== 1 && <Badge variant="outline" className="text-xs">FTE: {a.fte_ratio}</Badge>}
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm mt-2">
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Building2 className="w-3 h-3 shrink-0" />
                        <span className="truncate">{(a.department as any)?.name ?? '—'}</span>
                      </div>
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Briefcase className="w-3 h-3 shrink-0" />
                        <span className="truncate">{(a.position as any)?.title ?? a.job_title ?? '—'}</span>
                      </div>
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <MapPin className="w-3 h-3 shrink-0" />
                        <span className="truncate">{(a.location as any)?.name ?? '—'}</span>
                      </div>
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Users className="w-3 h-3 shrink-0" />
                        <span className="truncate">
                          {(a.direct_manager as any) ? `${(a.direct_manager as any).first_name} ${(a.direct_manager as any).last_name}` : '—'}
                        </span>
                      </div>
                    </div>
                    {a.effective_from && <p className="text-xs text-muted-foreground">From: {new Date(a.effective_from).toLocaleDateString()}</p>}
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => openEdit(a)}><Pencil className="w-4 h-4" /></Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Employment Detail Dialog */}
      <Dialog open={edOpen} onOpenChange={setEdOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>Employment Details</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <Label>Worker Type</Label>
                <Select value={edForm.worker_type} onValueChange={v => setEdForm(f => ({ ...f, worker_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['EMPLOYEE','CONTRACTOR','INTERN'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Employment Type</Label>
                <Select value={edForm.employment_type_v2} onValueChange={v => setEdForm(f => ({ ...f, employment_type_v2: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['PERMANENT','TEMPORARY','FIXED_TERM'].map(t => <SelectItem key={t} value={t}>{t.replace('_', ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Contract Type</Label>
                <Select value={edForm.contract_type} onValueChange={v => setEdForm(f => ({ ...f, contract_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['PERMANENT','TEMPORARY','FIXED_TERM'].map(t => <SelectItem key={t} value={t}>{t.replace('_', ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Employment No.</Label><Input value={edForm.employment_number} onChange={e => setEdForm(f => ({ ...f, employment_number: e.target.value }))} /></div>
              <div><Label>Notice Period (days)</Label><Input type="number" min="0" value={edForm.notice_period_days} onChange={e => setEdForm(f => ({ ...f, notice_period_days: e.target.value }))} /></div>
              <div>
                <Label>Rehire Eligible</Label>
                <Select value={edForm.is_rehire_eligible} onValueChange={v => setEdForm(f => ({ ...f, is_rehire_eligible: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="1">Yes</SelectItem><SelectItem value="0">No</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label>Salary Amount (ETB)</Label><Input type="number" min="0" step="0.01" value={edForm.salary_amount} onChange={e => setEdForm(f => ({ ...f, salary_amount: e.target.value }))} /></div>
              <div><Label>Salary Grade</Label><Input value={edForm.salary_grade} onChange={e => setEdForm(f => ({ ...f, salary_grade: e.target.value }))} /></div>
              <div><Label>Original Hire Date</Label><Input type="date" value={edForm.original_hire_date} onChange={e => setEdForm(f => ({ ...f, original_hire_date: e.target.value }))} /></div>
              <div><Label>Employment Start</Label><Input type="date" value={edForm.employment_start_date} onChange={e => setEdForm(f => ({ ...f, employment_start_date: e.target.value }))} /></div>
              <div className="md:col-span-2"><Label>Employment End</Label><Input type="date" value={edForm.employment_end_date} onChange={e => setEdForm(f => ({ ...f, employment_end_date: e.target.value }))} /></div>
            </div>
            <div><Label>Hire Reason</Label><Textarea value={edForm.hire_reason} onChange={e => setEdForm(f => ({ ...f, hire_reason: e.target.value }))} rows={2} /></div>
            <div><Label>Termination Reason</Label><Textarea value={edForm.termination_reason} onChange={e => setEdForm(f => ({ ...f, termination_reason: e.target.value }))} rows={2} /></div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setEdOpen(false)}>Cancel</Button>
              <Button onClick={saveEmpDetail} disabled={edSaving}>{edSaving ? 'Saving…' : 'Save'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Assignment Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>{editingId ? 'Edit' : 'New'} Work Assignment</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <Label>Department</Label>
                <Select value={SEL(form.department_id)} onValueChange={v => setForm(f => ({ ...f, department_id: UNSEL(v) }))}>
                  <SelectTrigger><SelectValue placeholder="Select dept." /></SelectTrigger>
                  <SelectContent><SelectItem value="__none__">—</SelectItem>{departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Position</Label>
                <Select value={SEL(form.position_id)} onValueChange={v => setForm(f => ({ ...f, position_id: UNSEL(v) }))}>
                  <SelectTrigger><SelectValue placeholder="Select position" /></SelectTrigger>
                  <SelectContent><SelectItem value="__none__">—</SelectItem>{positions.map(p => <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Location</Label>
                <Select value={SEL(form.location_id)} onValueChange={v => setForm(f => ({ ...f, location_id: UNSEL(v) }))}>
                  <SelectTrigger><SelectValue placeholder="Select location" /></SelectTrigger>
                  <SelectContent><SelectItem value="__none__">—</SelectItem>{locations.map(l => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Direct Manager</Label>
                <Select value={SEL(form.direct_manager_id)} onValueChange={v => setForm(f => ({ ...f, direct_manager_id: UNSEL(v) }))}>
                  <SelectTrigger><SelectValue placeholder="Select manager" /></SelectTrigger>
                  <SelectContent><SelectItem value="__none__">—</SelectItem>{managers.map(m => <SelectItem key={m.id} value={m.id}>{m.first_name} {m.last_name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Dotted Manager</Label>
                <Select value={SEL(form.dotted_manager_id)} onValueChange={v => setForm(f => ({ ...f, dotted_manager_id: UNSEL(v) }))}>
                  <SelectTrigger><SelectValue placeholder="Select manager" /></SelectTrigger>
                  <SelectContent><SelectItem value="__none__">—</SelectItem>{managers.map(m => <SelectItem key={m.id} value={m.id}>{m.first_name} {m.last_name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Category</Label>
                <Select value={form.employment_category} onValueChange={v => setForm(f => ({ ...f, employment_category: v as any }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="FULL_TIME">Full Time</SelectItem><SelectItem value="PART_TIME">Part Time</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label>Job Title (override)</Label><Input value={form.job_title} onChange={e => setForm(f => ({ ...f, job_title: e.target.value }))} /></div>
              <div><Label>FTE Ratio</Label><Input type="number" min="0.01" max="1" step="0.01" value={form.fte_ratio} onChange={e => setForm(f => ({ ...f, fte_ratio: e.target.value }))} /></div>
              <div><Label>Shift Code</Label><Input value={form.shift_code} onChange={e => setForm(f => ({ ...f, shift_code: e.target.value }))} /></div>
              <div><Label>Union Code</Label><Input value={form.union_code} onChange={e => setForm(f => ({ ...f, union_code: e.target.value }))} /></div>
              <div>
                <Label>Status</Label>
                <Select value={form.assignment_status} onValueChange={v => setForm(f => ({ ...f, assignment_status: v as any }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['ACTIVE','TRANSFERRED','ENDED','ACTING'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Effective From</Label><Input type="date" value={form.effective_from} onChange={e => setForm(f => ({ ...f, effective_from: e.target.value }))} /></div>
            </div>
            <div><Label>Change Reason</Label><Textarea value={form.change_reason} onChange={e => setForm(f => ({ ...f, change_reason: e.target.value }))} rows={2} /></div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save} disabled={saving}>{saving ? 'Saving…' : editingId ? 'Update' : 'Create'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
