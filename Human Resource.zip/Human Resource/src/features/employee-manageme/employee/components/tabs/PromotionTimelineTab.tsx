import { useState, useEffect } from 'react';
import { promotionRequestService } from '@/services/transfer.service';
import type { PromotionRequest } from '@/types/database.types';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, User, Calendar, DollarSign, Briefcase } from 'lucide-react';

interface Props { employeeId: string }

const fmtDate = (v: string | null | undefined) =>
  v ? new Date(v).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

const fmtMoney = (v: number | null | undefined) =>
  v != null
    ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'ETB', maximumFractionDigits: 0 }).format(v)
    : '—';

const salaryDiff = (oldSal: number | undefined, newSal: number | undefined) => {
  if (oldSal == null || newSal == null) return null;
  const diff = newSal - oldSal;
  const pct = oldSal !== 0 ? ((diff / oldSal) * 100).toFixed(1) : null;
  return { diff, pct, positive: diff >= 0 };
};

export function PromotionTimelineTab({ employeeId }: Props) {
  const [promotions, setPromotions] = useState<PromotionRequest[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const { data } = await promotionRequestService.list({
          employee_id: employeeId,
          promotion_status: 'EXECUTED',
          pageSize: 100,
        });
        // sort newest first
        const sorted = [...data].sort((a, b) =>
          (b.promotion_date ?? b.initiated_at).localeCompare(a.promotion_date ?? a.initiated_at),
        );
        if (!cancelled) setPromotions(sorted);
      } catch (_) {
        // silent
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [employeeId]);

  if (loading) {
    return (
      <div className="space-y-4 py-2">
        {[1, 2, 3].map(i => (
          <div key={i} className="flex gap-4">
            <Skeleton className="h-10 w-10 rounded-full shrink-0 bg-muted" />
            <div className="flex-1 space-y-2">
              <Skeleton className="h-4 w-48 bg-muted" />
              <Skeleton className="h-3 w-64 bg-muted" />
              <Skeleton className="h-3 w-40 bg-muted" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (promotions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center gap-3">
        <div className="rounded-full bg-muted p-4">
          <TrendingUp className="h-8 w-8 text-muted-foreground" />
        </div>
        <p className="text-sm font-medium text-foreground">No promotion history</p>
        <p className="text-xs text-muted-foreground">Executed promotions for this employee will appear here.</p>
      </div>
    );
  }

  return (
    <div className="relative py-2">
      {/* vertical line */}
      <div className="absolute left-5 top-3 bottom-3 w-px bg-border" aria-hidden />

      <ol className="space-y-0">
        {promotions.map((promo, idx) => {
          const diff = salaryDiff(promo.current_salary, promo.proposed_salary);
          const isLast = idx === promotions.length - 1;

          return (
            <li key={promo.promotion_id} className={`relative flex gap-4 ${isLast ? '' : 'pb-8'}`}>
              {/* dot */}
              <div className="relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 border-2 border-primary/30">
                <TrendingUp className="h-4 w-4 text-primary" />
              </div>

              {/* card */}
              <div className="flex-1 min-w-0 rounded-lg border border-border bg-card p-4 shadow-sm">
                {/* top row: date + badge */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Calendar className="h-3.5 w-3.5 shrink-0" />
                    <span className="font-medium text-foreground">
                      {fmtDate(promo.promotion_date ?? promo.initiated_at)}
                    </span>
                  </div>
                  <Badge className="bg-emerald-100 text-emerald-700 text-xs">EXECUTED</Badge>
                </div>

                {/* grade / position transition */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
                  {/* from */}
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground font-medium flex items-center gap-1">
                      <Briefcase className="h-3 w-3" />From
                    </p>
                    <p className="text-sm font-medium text-foreground truncate">
                      {promo.snapshot_current_grade ?? '—'}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {promo.current_position_id ? `Position: ${promo.current_position_id}` : '—'}
                    </p>
                  </div>

                  {/* arrow */}
                  <div className="hidden md:flex items-center justify-center">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <span className="text-xs">→</span>
                    </div>
                  </div>

                  {/* to */}
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground font-medium flex items-center gap-1">
                      <Briefcase className="h-3 w-3" />To
                    </p>
                    <p className="text-sm font-semibold text-primary truncate">
                      {promo.snapshot_proposed_grade ?? '—'}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {promo.proposed_position_id ? `Position: ${promo.proposed_position_id}` : '—'}
                    </p>
                  </div>
                </div>

                {/* salary change */}
                <div className="flex flex-wrap items-center gap-4 text-sm border-t border-border pt-3">
                  <div className="flex items-center gap-1.5 text-muted-foreground text-xs">
                    <DollarSign className="h-3.5 w-3.5 shrink-0" />
                    <span>Salary:</span>
                    <span className="line-through text-muted-foreground">{fmtMoney(promo.current_salary)}</span>
                    <span>→</span>
                    <span className="font-semibold text-foreground">{fmtMoney(promo.proposed_salary)}</span>
                    {diff && (
                      <span className={`ml-1 font-medium ${diff.positive ? 'text-emerald-600' : 'text-red-600'}`}>
                        ({diff.positive ? '+' : ''}{fmtMoney(diff.diff)}{diff.pct ? `, ${diff.positive ? '+' : ''}${diff.pct}%` : ''})
                      </span>
                    )}
                  </div>

                  {promo.initiated_by && (
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground ml-auto">
                      <User className="h-3 w-3 shrink-0" />
                      <span>By:</span>
                      <span className="text-foreground font-medium truncate max-w-[120px]">
                        {promo.initiated_by}
                      </span>
                    </div>
                  )}
                </div>

                {/* justification */}
                {promo.justification && (
                  <p className="mt-2 text-xs text-muted-foreground border-t border-border pt-2 line-clamp-2">
                    {promo.justification}
                  </p>
                )}
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
