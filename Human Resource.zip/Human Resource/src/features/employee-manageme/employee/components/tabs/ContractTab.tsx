// Module 2.9 — Employee Contract tab
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import type { EmployeeContract } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Plus, Pencil, FileText } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

const STATUS_COLORS: Record<string, string> = {
  ACTIVE: 'bg-green-100 text-green-800',
  DRAFT: 'bg-muted text-muted-foreground',
  EXPIRED: 'bg-red-100 text-red-800',
  TERMINATED: 'bg-red-100 text-red-800',
  RENEWED: 'bg-blue-100 text-blue-800',
};

const EMPTY = {
  contract_type: 'PERMANENT', contract_date: '', contract_number: '',
  job_type: '', work_place: '', salary_amount: '', salary_currency: 'ETB',
  start_date: '', end_date: '', renewal_date: '',
  guarantor_name: '', guarantor_phone: '', guarantor_address: '',
  emergency_contact_name: '', employee_signature: '',
  contract_status: 'ACTIVE', notes: '',
};

export function ContractTab({ employeeId }: { employeeId: string }) {
  const [records, setRecords] = useState<EmployeeContract[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<EmployeeContract | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await sb.from('employee_contracts')
      .select('*').eq('employee_id', employeeId).eq('is_deleted', 0)
      .order('start_date', { ascending: false, nullsFirst: false });
    if (error) toast.error(error.message);
    else setRecords(Array.isArray(data) ? data : []);
    setLoading(false);
  }, [employeeId]);

  useEffect(() => { load(); }, [load]);

  function openCreate() {
    setEditing(null);
    setForm({ ...EMPTY });
    setOpen(true);
  }

  function openEdit(r: EmployeeContract) {
    setEditing(r);
    setForm({
      contract_type: r.contract_type,
      contract_date: r.contract_date ?? '',
      contract_number: r.contract_number ?? '',
      job_type: r.job_type ?? '',
      work_place: r.work_place ?? '',
      salary_amount: String(r.salary_amount ?? ''),
      salary_currency: r.salary_currency ?? 'ETB',
      start_date: r.start_date ?? '',
      end_date: r.end_date ?? '',
      renewal_date: r.renewal_date ?? '',
      guarantor_name: r.guarantor_name ?? '',
      guarantor_phone: r.guarantor_phone ?? '',
      guarantor_address: r.guarantor_address ?? '',
      emergency_contact_name: r.emergency_contact_name ?? '',
      employee_signature: r.employee_signature ?? '',
      contract_status: r.contract_status ?? 'ACTIVE',
      notes: r.notes ?? '',
    });
    setOpen(true);
  }

  async function save() {
    setSaving(true);
    try {
      const payload = {
        employee_id: employeeId,
        contract_type: form.contract_type,
        contract_date: form.contract_date || null,
        contract_number: form.contract_number || null,
        job_type: form.job_type || null,
        work_place: form.work_place || null,
        salary_amount: form.salary_amount ? parseFloat(form.salary_amount) : null,
        salary_currency: form.salary_currency,
        start_date: form.start_date || null,
        end_date: form.end_date || null,
        renewal_date: form.renewal_date || null,
        guarantor_name: form.guarantor_name || null,
        guarantor_phone: form.guarantor_phone || null,
        guarantor_address: form.guarantor_address || null,
        emergency_contact_name: form.emergency_contact_name || null,
        employee_signature: form.employee_signature || null,
        contract_status: form.contract_status,
        notes: form.notes || null,
        updated_at: new Date().toISOString(),
      };
      const { error } = editing
        ? await sb.from('employee_contracts').update(payload).eq('id', editing.id)
        : await sb.from('employee_contracts').insert(payload);
      if (error) throw error;
      toast.success(editing ? 'Contract updated' : 'Contract added');
      setOpen(false);
      load();
    } catch (e: any) { toast.error(e.message); } finally { setSaving(false); }
  }

  const fmtDate = (d?: string | null) => d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground flex items-center gap-2"><FileText className="w-4 h-4" />Employment contracts and agreements</p>
        <Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" />Add Contract</Button>
      </div>

      {loading ? (
        <div className="space-y-2">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-20 w-full bg-muted" />)}</div>
      ) : records.length === 0 ? (
        <Card className="h-full"><CardContent className="py-10 text-center text-muted-foreground text-sm">No contract records found.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {records.map(r => (
            <Card key={r.id} className="h-full">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge className={`text-xs ${STATUS_COLORS[r.contract_status ?? 'DRAFT']}`}>{r.contract_status ?? 'DRAFT'}</Badge>
                      <Badge variant="secondary" className="text-xs">{r.contract_type}</Badge>
                      {r.contract_number && <span className="text-xs text-muted-foreground font-mono">{r.contract_number}</span>}
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs text-muted-foreground mt-1">
                      <span>Start: {fmtDate(r.start_date)}</span>
                      {r.end_date && <span>End: {fmtDate(r.end_date)}</span>}
                      {r.renewal_date && <span>Renewal: {fmtDate(r.renewal_date)}</span>}
                      {r.salary_amount && <span>Salary: {r.salary_currency} {Number(r.salary_amount).toLocaleString()}</span>}
                    </div>
                    {r.work_place && <p className="text-xs text-muted-foreground">Location: {r.work_place}</p>}
                    {r.guarantor_name && (
                      <p className="text-xs text-muted-foreground">Guarantor: {r.guarantor_name}{r.guarantor_phone ? ` · ${r.guarantor_phone}` : ''}</p>
                    )}
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => openEdit(r)}><Pencil className="w-4 h-4" /></Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>{editing ? 'Edit' : 'Add'} Contract</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <Label>Contract Type *</Label>
                <Select value={form.contract_type} onValueChange={v => setForm(f => ({ ...f, contract_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['PERMANENT','FIXED_TERM','CONSULTANT','PROBATION','OTHER'].map(t => <SelectItem key={t} value={t}>{t.replace('_', ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Status</Label>
                <Select value={form.contract_status} onValueChange={v => setForm(f => ({ ...f, contract_status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['DRAFT','ACTIVE','EXPIRED','TERMINATED','RENEWED'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Contract No.</Label><Input value={form.contract_number} onChange={e => setForm(f => ({ ...f, contract_number: e.target.value }))} /></div>
              <div><Label>Contract Date</Label><Input type="date" value={form.contract_date} onChange={e => setForm(f => ({ ...f, contract_date: e.target.value }))} /></div>
              <div><Label>Start Date</Label><Input type="date" value={form.start_date} onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))} /></div>
              <div><Label>End Date</Label><Input type="date" value={form.end_date} onChange={e => setForm(f => ({ ...f, end_date: e.target.value }))} /></div>
              <div><Label>Renewal Date</Label><Input type="date" value={form.renewal_date} onChange={e => setForm(f => ({ ...f, renewal_date: e.target.value }))} /></div>
              <div><Label>Job Type</Label><Input value={form.job_type} onChange={e => setForm(f => ({ ...f, job_type: e.target.value }))} placeholder="e.g. Manual Worker" /></div>
              <div><Label>Work Place</Label><Input value={form.work_place} onChange={e => setForm(f => ({ ...f, work_place: e.target.value }))} /></div>
              <div><Label>Salary (ETB)</Label><Input type="number" min="0" step="0.01" value={form.salary_amount} onChange={e => setForm(f => ({ ...f, salary_amount: e.target.value }))} /></div>
              <div><Label>Currency</Label><Input value={form.salary_currency} maxLength={3} onChange={e => setForm(f => ({ ...f, salary_currency: e.target.value.toUpperCase() }))} /></div>
              <div><Label>Employee Signature</Label><Input value={form.employee_signature} onChange={e => setForm(f => ({ ...f, employee_signature: e.target.value }))} placeholder="Name or reference" /></div>
            </div>
            <Separator />
            <p className="text-xs font-semibold uppercase text-muted-foreground">Guarantor Details</p>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Guarantor Name</Label><Input value={form.guarantor_name} onChange={e => setForm(f => ({ ...f, guarantor_name: e.target.value }))} /></div>
              <div><Label>Guarantor Phone</Label><Input value={form.guarantor_phone} onChange={e => setForm(f => ({ ...f, guarantor_phone: e.target.value }))} /></div>
              <div className="col-span-2"><Label>Guarantor Address</Label><Textarea value={form.guarantor_address} onChange={e => setForm(f => ({ ...f, guarantor_address: e.target.value }))} rows={2} /></div>
              <div><Label>Emergency Contact Name</Label><Input value={form.emergency_contact_name} onChange={e => setForm(f => ({ ...f, emergency_contact_name: e.target.value }))} /></div>
            </div>
            <div><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} /></div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save} disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Add'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
