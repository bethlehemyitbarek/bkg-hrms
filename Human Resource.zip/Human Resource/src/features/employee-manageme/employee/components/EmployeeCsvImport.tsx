// @refresh reset
import { useState, useRef, useCallback } from 'react';
import Papa from 'papaparse';
import { employeeService } from '@/services/employee.service';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import {
  Upload, FileUp, AlertCircle, CheckCircle2, XCircle,
  Loader2, ChevronRight, RotateCcw, Download,
} from 'lucide-react';

/* ── DB column definitions ────────────────────────────────────────────── */
const DB_COLUMNS = [
  { key: 'first_name',       label: 'First Name',        required: true  },
  { key: 'last_name',        label: 'Last Name',          required: true  },
  { key: 'email',            label: 'Work Email',         required: true  },
  { key: 'hire_date',        label: 'Hire Date',          required: true  },
  { key: 'employment_type',  label: 'Employment Type',    required: true  },
  { key: 'employment_status',label: 'Employment Status',  required: false },
  { key: 'middle_name',      label: 'Middle Name',        required: false },
  { key: 'preferred_name',   label: 'Preferred Name',     required: false },
  { key: 'national_id',      label: 'National ID',        required: false },
  { key: 'passport_no',      label: 'Passport No.',       required: false },
  { key: 'date_of_birth',    label: 'Date of Birth',      required: false },
  { key: 'gender',           label: 'Gender',             required: false },
  { key: 'marital_status',   label: 'Marital Status',     required: false },
  { key: 'nationality',      label: 'Nationality',        required: false },
  { key: 'phone',            label: 'Phone',              required: false },
  { key: 'mobile',           label: 'Mobile',             required: false },
  { key: 'personal_email',   label: 'Personal Email',     required: false },
  { key: 'address',          label: 'Street Address',     required: false },
  { key: 'city',             label: 'City',               required: false },
  { key: 'state',            label: 'State/Province',     required: false },
  { key: 'country',          label: 'Country',            required: false },
  { key: 'postal_code',      label: 'Postal Code',        required: false },
  { key: 'employee_no',      label: 'Employee No.',       required: false },
] as const;

type DbKey = typeof DB_COLUMNS[number]['key'];

const VALID_EMP_TYPES   = ['full_time', 'part_time', 'contract', 'intern', 'temporary'];
const VALID_EMP_STATUS  = ['active', 'inactive', 'on_leave', 'terminated', 'resigned', 'retired', 'probation'];
const VALID_GENDER      = ['male', 'female', 'other', 'prefer_not_to_say'];
const VALID_MARITAL     = ['single', 'married', 'divorced', 'widowed', 'separated'];

/* ── Types ───────────────────────────────────────────────────────────── */
type Step = 'upload' | 'map' | 'preview' | 'done';
type Mapping = Partial<Record<DbKey, string>>;

interface RowError {
  row: number;
  field: string;
  message: string;
}

interface ParsedRow {
  index: number;
  data: Record<string, string>;
  errors: RowError[];
  mapped: Partial<Record<DbKey, string>>;
}

/* ── Validation ──────────────────────────────────────────────────────── */
function validateRow(mapped: Partial<Record<DbKey, string>>, rowIdx: number): RowError[] {
  const errs: RowError[] = [];
  // Required fields
  for (const col of DB_COLUMNS.filter(c => c.required)) {
    const v = mapped[col.key]?.trim();
    if (!v) errs.push({ row: rowIdx, field: col.label, message: `${col.label} is required` });
  }
  // Email format
  if (mapped.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mapped.email)) {
    errs.push({ row: rowIdx, field: 'Work Email', message: 'Invalid email format' });
  }
  if (mapped.personal_email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mapped.personal_email)) {
    errs.push({ row: rowIdx, field: 'Personal Email', message: 'Invalid personal email format' });
  }
  // Enum validations
  if (mapped.employment_type && !VALID_EMP_TYPES.includes(mapped.employment_type.toLowerCase())) {
    errs.push({ row: rowIdx, field: 'Employment Type', message: `Must be one of: ${VALID_EMP_TYPES.join(', ')}` });
  }
  if (mapped.employment_status && !VALID_EMP_STATUS.includes(mapped.employment_status.toLowerCase())) {
    errs.push({ row: rowIdx, field: 'Employment Status', message: `Must be one of: ${VALID_EMP_STATUS.join(', ')}` });
  }
  if (mapped.gender && !VALID_GENDER.includes(mapped.gender.toLowerCase())) {
    errs.push({ row: rowIdx, field: 'Gender', message: `Must be one of: ${VALID_GENDER.join(', ')}` });
  }
  if (mapped.marital_status && !VALID_MARITAL.includes(mapped.marital_status.toLowerCase())) {
    errs.push({ row: rowIdx, field: 'Marital Status', message: `Must be one of: ${VALID_MARITAL.join(', ')}` });
  }
  // Date format
  for (const dateField of ['hire_date', 'date_of_birth'] as DbKey[]) {
    const v = mapped[dateField];
    if (v && !/^\d{4}-\d{2}-\d{2}$/.test(v)) {
      errs.push({ row: rowIdx, field: dateField, message: 'Date must be YYYY-MM-DD format' });
    }
  }
  return errs;
}

/* ── Auto-map heuristic ──────────────────────────────────────────────── */
function autoMap(csvHeaders: string[]): Mapping {
  const mapping: Mapping = {};
  for (const col of DB_COLUMNS) {
    const match = csvHeaders.find(h => {
      const norm = h.toLowerCase().replace(/[\s_-]/g, '');
      const key  = col.key.replace(/_/g, '');
      const lbl  = col.label.toLowerCase().replace(/[\s_-]/g, '');
      return norm === key || norm === lbl || norm.includes(key) || key.includes(norm);
    });
    if (match) mapping[col.key] = match;
  }
  return mapping;
}

/* ── Props ───────────────────────────────────────────────────────────── */
interface EmployeeCsvImportProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImported: (count: number) => void;
}

/* ── Component ────────────────────────────────────────────────────────── */
export function EmployeeCsvImport({ open, onOpenChange, onImported }: EmployeeCsvImportProps) {
  const fileRef = useRef<HTMLInputElement>(null);

  const [step,        setStep]        = useState<Step>('upload');
  const [csvHeaders,  setCsvHeaders]  = useState<string[]>([]);
  const [rawRows,     setRawRows]     = useState<Record<string, string>[]>([]);
  const [mapping,     setMapping]     = useState<Mapping>({});
  const [parsedRows,  setParsedRows]  = useState<ParsedRow[]>([]);
  const [importing,   setImporting]   = useState(false);
  const [importedCount, setImportedCount] = useState(0);
  const [failedRows,  setFailedRows]  = useState<{ row: number; error: string }[]>([]);
  const [fileName,    setFileName]    = useState('');

  const reset = () => {
    setStep('upload');
    setCsvHeaders([]);
    setRawRows([]);
    setMapping({});
    setParsedRows([]);
    setImporting(false);
    setImportedCount(0);
    setFailedRows([]);
    setFileName('');
    if (fileRef.current) fileRef.current.value = '';
  };

  /* ── Upload + parse CSV ─────────────────────────────────────────────── */
  const handleFile = useCallback((file: File) => {
    setFileName(file.name);
    Papa.parse<Record<string, string>>(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: h => h.trim(),
      complete: (results) => {
        const headers = results.meta.fields ?? [];
        const rows    = results.data;
        setCsvHeaders(headers);
        setRawRows(rows);
        setMapping(autoMap(headers));
        setStep('map');
      },
      error: () => toast.error('Failed to parse CSV file'),
    });
  }, []);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file?.name.endsWith('.csv')) handleFile(file);
    else toast.error('Please upload a CSV file');
  };

  /* ── Build preview + validate ──────────────────────────────────────── */
  const buildPreview = useCallback(() => {
    const rows: ParsedRow[] = rawRows.slice(0, 200).map((row, i) => {
      const mapped: Partial<Record<DbKey, string>> = {};
      for (const [dbKey, csvCol] of Object.entries(mapping) as [DbKey, string][]) {
        if (csvCol && row[csvCol] !== undefined) {
          mapped[dbKey] = row[csvCol]?.trim() || '';
        }
      }
      return { index: i + 1, data: row, errors: validateRow(mapped, i + 1), mapped };
    });
    setParsedRows(rows);
    setStep('preview');
  }, [rawRows, mapping]);

  /* ── Import to Supabase ─────────────────────────────────────────────── */
  const handleImport = useCallback(async () => {
    const validRows = parsedRows.filter(r => r.errors.length === 0);
    if (validRows.length === 0) { toast.error('No valid rows to import'); return; }

    setImporting(true);
    let ok = 0;
    const failed: { row: number; error: string }[] = [];

    for (const r of validRows) {
      try {
        // Normalise enums to lowercase
        const payload: Record<string, unknown> = { ...r.mapped };
        if (payload.employment_type)   payload.employment_type   = String(payload.employment_type).toLowerCase();
        if (payload.employment_status) payload.employment_status = String(payload.employment_status).toLowerCase();
        if (payload.gender)            payload.gender            = String(payload.gender).toLowerCase();
        if (payload.marital_status)    payload.marital_status    = String(payload.marital_status).toLowerCase();
        // Set defaults
        if (!payload.employment_status) payload.employment_status = 'active';
        if (!payload.is_active) payload.is_active = true;

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        await employeeService.create(payload as any);
        ok++;
      } catch (err) {
        failed.push({ row: r.index, error: err instanceof Error ? err.message : 'Unknown error' });
      }
    }

    setImportedCount(ok);
    setFailedRows(failed);
    setStep('done');
    setImporting(false);
    if (ok > 0) {
      onImported(ok);
      toast.success(`${ok} employee${ok !== 1 ? 's' : ''} imported successfully`);
    }
  }, [parsedRows, onImported]);

  /* ── Download template ─────────────────────────────────────────────── */
  const downloadTemplate = () => {
    const headers = DB_COLUMNS.map(c => c.key).join(',');
    const example = 'John,Doe,,,,,,,,,,,,,,,,,,,,EMP-001,2025-01-15,full_time,active';
    const blob = new Blob([headers + '\n' + example], { type: 'text/csv' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = 'employee_import_template.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  const errorCount = parsedRows.filter(r => r.errors.length > 0).length;
  const validCount = parsedRows.filter(r => r.errors.length === 0).length;

  return (
    <Sheet open={open} onOpenChange={open => { if (!open) reset(); onOpenChange(open); }}>
      <SheetContent side="right" className="w-full max-w-2xl p-0 flex flex-col bg-background overflow-hidden">
        <SheetHeader className="px-6 py-4 border-b border-border shrink-0">
          <SheetTitle className="flex items-center gap-2 text-lg font-bold">
            <FileUp className="h-5 w-5" />
            Bulk Import Employees
          </SheetTitle>
          {/* Step indicator */}
          <div className="flex items-center gap-1.5 mt-2">
            {(['upload', 'map', 'preview', 'done'] as Step[]).map((s, i, arr) => (
              <div key={s} className="flex items-center gap-1.5">
                <div className={`h-5 w-5 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                  step === s ? 'bg-primary text-primary-foreground' :
                  arr.indexOf(step) > i ? 'bg-green-500 text-white' :
                  'bg-muted text-muted-foreground'
                }`}>
                  {arr.indexOf(step) > i ? <CheckCircle2 className="h-3 w-3" /> : i + 1}
                </div>
                <span className={`text-xs capitalize ${step === s ? 'font-semibold text-foreground' : 'text-muted-foreground'}`}>{s}</span>
                {i < arr.length - 1 && <ChevronRight className="h-3 w-3 text-muted-foreground" />}
              </div>
            ))}
          </div>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-6 py-5">

          {/* ── STEP: UPLOAD ── */}
          {step === 'upload' && (
            <div className="space-y-5">
              <div
                className="border-2 border-dashed border-border rounded-xl p-10 flex flex-col items-center gap-4 cursor-pointer hover:border-primary hover:bg-muted/30 transition-colors"
                onDrop={handleDrop}
                onDragOver={e => e.preventDefault()}
                onClick={() => fileRef.current?.click()}
              >
                <Upload className="h-10 w-10 text-muted-foreground" />
                <div className="text-center">
                  <p className="font-medium text-foreground">Drop a CSV file here</p>
                  <p className="text-sm text-muted-foreground mt-1">or click to browse</p>
                </div>
                <input
                  ref={fileRef}
                  type="file"
                  accept=".csv"
                  className="hidden"
                  onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
                />
              </div>
              <Button variant="outline" size="sm" onClick={downloadTemplate} className="w-full">
                <Download className="h-4 w-4 mr-2" />Download CSV Template
              </Button>
              <div className="p-4 rounded-lg bg-muted/40 text-sm text-muted-foreground space-y-1">
                <p className="font-medium text-foreground">Required columns:</p>
                {DB_COLUMNS.filter(c => c.required).map(c => (
                  <span key={c.key} className="inline-block mr-2 mb-1">
                    <Badge variant="secondary" className="text-xs">{c.label}</Badge>
                  </span>
                ))}
                <p className="mt-2 text-xs">Max 200 rows per import. Dates must be YYYY-MM-DD.</p>
              </div>
            </div>
          )}

          {/* ── STEP: MAP ── */}
          {step === 'map' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{fileName}</p>
                  <p className="text-sm text-muted-foreground">{rawRows.length} rows detected · {csvHeaders.length} columns</p>
                </div>
              </div>
              <Separator />
              <p className="text-sm text-muted-foreground">
                Map your CSV columns to employee fields. Required fields are marked with *.
              </p>
              <div className="space-y-2.5">
                {DB_COLUMNS.map(col => (
                  <div key={col.key} className="grid grid-cols-2 gap-3 items-center">
                    <label className="text-sm font-medium">
                      {col.label}{col.required && <span className="text-destructive ml-0.5">*</span>}
                    </label>
                    <Select
                      value={mapping[col.key] ?? '__skip__'}
                      onValueChange={v => setMapping(m => ({ ...m, [col.key]: v === '__skip__' ? undefined : v }))}
                    >
                      <SelectTrigger className="h-8 text-sm">
                        <SelectValue placeholder="— skip —" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__skip__">— skip —</SelectItem>
                        {csvHeaders.map(h => (
                          <SelectItem key={h} value={h}>{h}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                ))}
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={reset}>Back</Button>
                <Button onClick={buildPreview}>
                  Preview <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </div>
          )}

          {/* ── STEP: PREVIEW ── */}
          {step === 'preview' && (
            <div className="space-y-4">
              {/* Summary badges */}
              <div className="flex items-center gap-3 flex-wrap">
                <Badge variant="secondary" className="bg-green-100 text-green-800 border-0">
                  <CheckCircle2 className="h-3 w-3 mr-1" />{validCount} valid
                </Badge>
                {errorCount > 0 && (
                  <Badge variant="secondary" className="bg-red-100 text-red-800 border-0">
                    <XCircle className="h-3 w-3 mr-1" />{errorCount} with errors (will be skipped)
                  </Badge>
                )}
              </div>

              {/* Error report */}
              {errorCount > 0 && (
                <div className="rounded-lg border border-red-200 bg-red-50 p-3 max-h-48 overflow-y-auto space-y-1.5">
                  <p className="text-xs font-semibold text-red-800 flex items-center gap-1.5">
                    <AlertCircle className="h-3.5 w-3.5" />Validation Errors
                  </p>
                  {parsedRows.filter(r => r.errors.length > 0).map(r =>
                    r.errors.map((e, i) => (
                      <p key={`${r.index}-${i}`} className="text-xs text-red-700">
                        Row {r.index}: <span className="font-medium">{e.field}</span> — {e.message}
                      </p>
                    ))
                  )}
                </div>
              )}

              {/* Preview table */}
              <div className="border border-border rounded-lg overflow-hidden">
                <div className="overflow-x-auto max-h-80">
                  <table className="w-full text-xs">
                    <thead className="sticky top-0 bg-muted/80 backdrop-blur-sm">
                      <tr>
                        <th className="px-3 py-2 text-left font-medium whitespace-nowrap w-10">#</th>
                        <th className="px-3 py-2 text-left font-medium whitespace-nowrap">First Name</th>
                        <th className="px-3 py-2 text-left font-medium whitespace-nowrap">Last Name</th>
                        <th className="px-3 py-2 text-left font-medium whitespace-nowrap">Email</th>
                        <th className="px-3 py-2 text-left font-medium whitespace-nowrap">Hire Date</th>
                        <th className="px-3 py-2 text-left font-medium whitespace-nowrap">Type</th>
                        <th className="px-3 py-2 text-left font-medium whitespace-nowrap">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {parsedRows.map(r => (
                        <tr key={r.index} className={`border-t border-border ${r.errors.length > 0 ? 'bg-red-50/50' : 'hover:bg-muted/20'}`}>
                          <td className="px-3 py-1.5 font-mono text-muted-foreground">{r.index}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.mapped.first_name || <span className="text-red-500">—</span>}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.mapped.last_name  || <span className="text-red-500">—</span>}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.mapped.email       || <span className="text-red-500">—</span>}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap font-mono">{r.mapped.hire_date || '—'}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.mapped.employment_type || '—'}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">
                            {r.errors.length > 0
                              ? <span className="text-red-600 flex items-center gap-1"><XCircle className="h-3 w-3" />{r.errors.length} error{r.errors.length > 1 ? 's' : ''}</span>
                              : <span className="text-green-600 flex items-center gap-1"><CheckCircle2 className="h-3 w-3" />OK</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {validCount === 0 && (
                <p className="text-sm text-destructive font-medium">All rows have errors. Please fix your CSV and re-upload.</p>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setStep('map')}>Back</Button>
                <Button onClick={handleImport} disabled={importing || validCount === 0}>
                  {importing
                    ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Importing…</>
                    : <>Import {validCount} Employee{validCount !== 1 ? 's' : ''}</>}
                </Button>
              </div>
            </div>
          )}

          {/* ── STEP: DONE ── */}
          {step === 'done' && (
            <div className="space-y-5">
              <div className={`flex items-start gap-3 p-4 rounded-lg border ${importedCount > 0 ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                {importedCount > 0
                  ? <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0 mt-0.5" />
                  : <XCircle    className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />}
                <div>
                  <p className={`font-semibold text-sm ${importedCount > 0 ? 'text-green-800' : 'text-red-800'}`}>
                    {importedCount > 0 ? `${importedCount} employee${importedCount !== 1 ? 's' : ''} imported successfully` : 'Import failed'}
                  </p>
                  {failedRows.length > 0 && (
                    <p className="text-xs mt-0.5 text-red-700">{failedRows.length} row{failedRows.length !== 1 ? 's' : ''} failed to save</p>
                  )}
                </div>
              </div>

              {failedRows.length > 0 && (
                <div className="rounded-lg border border-red-200 bg-red-50/50 p-3 space-y-1 max-h-48 overflow-y-auto">
                  <p className="text-xs font-semibold text-red-800">Save Errors</p>
                  {failedRows.map(f => (
                    <p key={f.row} className="text-xs text-red-700">Row {f.row}: {f.error}</p>
                  ))}
                </div>
              )}

              <div className="flex gap-2">
                <Button onClick={reset}>
                  <RotateCcw className="h-4 w-4 mr-2" />Import Another File
                </Button>
                <Button variant="outline" onClick={() => { onOpenChange(false); reset(); }}>
                  Close
                </Button>
              </div>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
