// @refresh reset
import { useState, useEffect, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { employeeService } from '@/services/employee.service';
import { departmentService, positionService, locationService, jobGradeService } from '@/services/organization.service';
import type { Employee, Department, Position, Location, JobGrade } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, User, Briefcase, MapPin, Phone, X } from 'lucide-react';
import { toast } from 'sonner';

/* ── Schema ─────────────────────────────────────────────────────────────── */
const schema = z.object({
  // Personal
  first_name:               z.string().min(1, 'Required'),
  last_name:                z.string().min(1, 'Required'),
  middle_name:              z.string().optional(),
  preferred_name:           z.string().optional(),
  mother_name:              z.string().optional(),
  national_id:              z.string().optional(),
  tin_number_encrypted:     z.string().optional(),
  kebele_id:                z.string().optional(),
  passport_no:              z.string().optional(),
  date_of_birth:            z.string().optional(),
  place_of_birth:           z.string().optional(),
  gender:                   z.enum(['male', 'female', 'other', 'prefer_not_to_say']).optional(),
  marital_status:           z.enum(['single', 'married', 'divorced', 'widowed', 'separated']).optional(),
  nationality:              z.string().optional(),
  citizenship_status:       z.enum(['CITIZEN','RESIDENT','EXPAT']).optional(),
  religion:                 z.string().optional(),
  blood_group:              z.string().optional(),
  disability_status:        z.enum(['NONE','PARTIAL','FULL']).optional(),
  medical_certificate_status: z.string().optional(),
  mother_tongue:            z.string().optional(),
  profile_status:           z.enum(['DRAFT','ACTIVE','INACTIVE','OFFBOARDED']).optional(),
  retirement_age:           z.string().optional(),
  planned_retirement_date:  z.string().optional(),
  // Contact
  email:                    z.string().email('Valid email required'),
  personal_email:           z.string().email().optional().or(z.literal('')),
  phone:                    z.string().optional(),
  mobile:                   z.string().optional(),
  po_box:                   z.string().optional(),
  // Address
  address:                  z.string().optional(),
  region:                   z.string().optional(),
  city:                     z.string().optional(),
  sub_city:                 z.string().optional(),
  woreda:                   z.string().optional(),
  street_name:              z.string().optional(),
  house_number:             z.string().optional(),
  state:                    z.string().optional(),
  country:                  z.string().optional(),
  postal_code:              z.string().optional(),
  // Employment
  employment_type:          z.enum(['full_time', 'part_time', 'contract', 'intern', 'temporary']),
  employment_status:        z.enum(['active', 'inactive', 'on_leave', 'terminated', 'resigned', 'retired', 'probation']),
  hire_date:                z.string().min(1, 'Required'),
  probation_end_date:       z.string().optional(),
  confirmation_date:        z.string().optional(),
  resignation_date:         z.string().optional(),
  termination_date:         z.string().optional(),
  last_working_date:        z.string().optional(),
  // Org
  department_id:            z.string().optional(),
  position_id:              z.string().optional(),
  location_id:              z.string().optional(),
  manager_id:               z.string().optional(),
  job_grade_id:             z.string().optional(),
  employee_no:              z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

/* ── Empty select option value ───────────────────────────────────────────── */
const NONE = '__none__';
const toVal = (v: string | undefined) => v || NONE;
const fromVal = (v: string) => (v === NONE ? undefined : v);

/* ── Props ──────────────────────────────────────────────────────────────── */
interface EmployeeFormDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  employee?: Employee | null;  // null = create mode
  onSuccess: (emp: Employee) => void;
}

export function EmployeeFormDrawer({ open, onOpenChange, employee, onSuccess }: EmployeeFormDrawerProps) {
  const isEdit = !!employee;

  const [departments, setDepartments]   = useState<Department[]>([]);
  const [positions, setPositions]       = useState<Position[]>([]);
  const [locations, setLocations]       = useState<Location[]>([]);
  const [jobGrades, setJobGrades]       = useState<JobGrade[]>([]);
  const [managers, setManagers]         = useState<Pick<Employee, 'id' | 'first_name' | 'last_name' | 'employee_no'>[]>([]);
  const [loadingRef, setLoadingRef]     = useState(true);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      employment_type:   'full_time',
      employment_status: 'active',
      hire_date: new Date().toISOString().split('T')[0],
      nationality: 'Ethiopian',
      profile_status: 'DRAFT',
    },
  });

  /* Load reference data once */
  useEffect(() => {
    if (!open) return;
    setLoadingRef(true);
    Promise.all([
      departmentService.list(),
      positionService.list(),
      locationService.list(),
      jobGradeService.list(),
      // Load active employees as potential managers
      employeeService.list({ pageSize: 200 }),
    ]).then(([depts, pos, locs, jg, emps]) => {
      setDepartments(depts);
      setPositions(pos);
      setLocations(locs);
      setJobGrades(jg);
      setManagers(emps.data.map(e => ({ id: e.id, first_name: e.first_name, last_name: e.last_name, employee_no: e.employee_no })));
    }).finally(() => setLoadingRef(false));
  }, [open]);

  /* Populate form for edit mode */
  useEffect(() => {
    if (!open) return;
    if (isEdit && employee) {
      form.reset({
        first_name:        employee.first_name,
        last_name:         employee.last_name,
        middle_name:       employee.middle_name || '',
        preferred_name:    employee.preferred_name || '',
        mother_name:       employee.mother_name || '',
        national_id:       employee.national_id || '',
        tin_number_encrypted: employee.tin_number_encrypted ? '••••••••' : '',
        kebele_id:         employee.kebele_id ? '••••••••' : '',
        passport_no:       employee.passport_no || '',
        date_of_birth:     employee.date_of_birth || '',
        place_of_birth:    employee.place_of_birth || '',
        gender:            (employee.gender as any) || undefined,
        marital_status:    (employee.marital_status as any) || undefined,
        nationality:       employee.nationality || 'Ethiopian',
        citizenship_status: (employee.citizenship_status as any) || undefined,
        religion:          employee.religion || '',
        blood_group:       employee.blood_group || '',
        disability_status: (employee.disability_status as any) || undefined,
        medical_certificate_status: employee.medical_certificate_status || '',
        mother_tongue:     employee.mother_tongue || '',
        profile_status:    (employee.profile_status as any) || 'DRAFT',
        retirement_age:    employee.retirement_age ? String(employee.retirement_age) : '',
        planned_retirement_date: employee.planned_retirement_date || '',
        email:             employee.email,
        personal_email:    employee.personal_email || '',
        phone:             employee.phone || '',
        mobile:            employee.mobile || '',
        po_box:            employee.po_box || '',
        address:           employee.address || '',
        region:            employee.region || '',
        city:              employee.city || '',
        sub_city:          employee.sub_city || '',
        woreda:            employee.woreda || '',
        street_name:       employee.street_name || '',
        house_number:      employee.house_number || '',
        state:             employee.state || '',
        country:           employee.country || '',
        postal_code:       employee.postal_code || '',
        employment_type:   employee.employment_type,
        employment_status: employee.employment_status,
        hire_date:         employee.hire_date,
        probation_end_date:employee.probation_end_date || '',
        confirmation_date: employee.confirmation_date || '',
        resignation_date:  employee.resignation_date || '',
        termination_date:  employee.termination_date || '',
        last_working_date: employee.last_working_date || '',
        department_id:     employee.department_id || '',
        position_id:       employee.position_id || '',
        location_id:       employee.location_id || '',
        manager_id:        employee.manager_id || '',
        job_grade_id:      employee.job_grade_id || '',
        employee_no:       employee.employee_no,
      });
    } else {
      form.reset({
        employment_type:   'full_time',
        employment_status: 'active',
        hire_date:         new Date().toISOString().split('T')[0],
        nationality:       'Ethiopian',
        profile_status:    'DRAFT',
      });
    }
  }, [open, employee, isEdit, form]);

  const onSubmit = useCallback(async (values: FormValues) => {
    // Clean empty optional strings → undefined
    const payload: Partial<Employee> = Object.fromEntries(
      Object.entries(values).map(([k, v]) => [k, v === '' ? undefined : v])
    ) as Partial<Employee>;

    try {
      let saved: Employee;
      if (isEdit && employee) {
        saved = await employeeService.update(employee.id, payload);
        toast.success('Employee updated successfully');
      } else {
        saved = await employeeService.create(payload);
        toast.success(`Employee ${saved.employee_no} created`);
      }
      onSuccess(saved);
      onOpenChange(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save employee');
    }
  }, [isEdit, employee, onSuccess, onOpenChange]);

  /* Filter positions by selected department */
  const deptId = form.watch('department_id');
  const filteredPositions = deptId
    ? positions.filter(p => !p.department_id || p.department_id === deptId)
    : positions;

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-background overflow-hidden">
      <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
        <div>
          <h2 className="text-lg font-bold">
            {isEdit ? `Edit — ${employee?.first_name} ${employee?.last_name}` : 'Add New Employee'}
          </h2>
          {isEdit && <p className="text-xs text-muted-foreground font-mono mt-0.5">{employee?.employee_no}</p>}
        </div>
        <button onClick={() => onOpenChange(false)} className="rounded-md p-1.5 hover:bg-muted transition-colors" aria-label="Close">
          <X className="h-5 w-5" />
        </button>
      </div>

        <div className="flex-1 overflow-y-auto">
          <Form {...form}>
            <form id="emp-form" onSubmit={form.handleSubmit(onSubmit)}>
              <Tabs defaultValue="personal" className="w-full">
                <div className="sticky top-0 bg-background z-10 border-b border-border px-6 pt-4 pb-0">
                  <TabsList className="w-full justify-start rounded-none bg-transparent p-0 gap-0 border-b-0 h-auto">
                    {[
                      { value: 'personal', label: 'Personal', icon: User },
                      { value: 'contact', label: 'Contact', icon: Phone },
                      { value: 'employment', label: 'Employment', icon: Briefcase },
                      { value: 'org', label: 'Organization', icon: MapPin },
                    ].map(({ value, label, icon: Icon }) => (
                      <TabsTrigger key={value} value={value}
                        className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-4 py-2.5 text-sm font-medium shrink-0">
                        <Icon className="h-3.5 w-3.5 mr-1.5 shrink-0" />{label}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </div>

                {/* ── PERSONAL ── */}
                <TabsContent value="personal" className="px-6 py-5 space-y-4 mt-0">
                  <p className="text-xs font-semibold uppercase text-muted-foreground">Full Name</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name="first_name" render={({ field }) => (
                      <FormItem><FormLabel>First Name *</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="middle_name" render={({ field }) => (
                      <FormItem><FormLabel>Middle Name (Father's Name)</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="last_name" render={({ field }) => (
                      <FormItem><FormLabel>Last Name (Grandfather's Name) *</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="preferred_name" render={({ field }) => (
                      <FormItem><FormLabel>Preferred Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="mother_name" render={({ field }) => (
                      <FormItem><FormLabel>Mother's Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </div>
                  <Separator />
                  <p className="text-xs font-semibold uppercase text-muted-foreground">Demographics</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name="gender" render={({ field }) => (
                      <FormItem><FormLabel>Gender</FormLabel>
                        <Select value={toVal(field.value)} onValueChange={v => field.onChange(fromVal(v))}>
                          <FormControl><SelectTrigger><SelectValue placeholder="Select gender" /></SelectTrigger></FormControl>
                          <SelectContent>
                            <SelectItem value={NONE}>— Not specified —</SelectItem>
                            <SelectItem value="male">Male</SelectItem>
                            <SelectItem value="female">Female</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                            <SelectItem value="prefer_not_to_say">Prefer not to say</SelectItem>
                          </SelectContent>
                        </Select>
                      <FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="date_of_birth" render={({ field }) => (
                      <FormItem><FormLabel>Date of Birth</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="place_of_birth" render={({ field }) => (
                      <FormItem><FormLabel>Place of Birth</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="marital_status" render={({ field }) => (
                      <FormItem><FormLabel>Marital Status</FormLabel>
                        <Select value={toVal(field.value)} onValueChange={v => field.onChange(fromVal(v))}>
                          <FormControl><SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger></FormControl>
                          <SelectContent>
                            <SelectItem value={NONE}>— Not specified —</SelectItem>
                            <SelectItem value="single">Single</SelectItem>
                            <SelectItem value="married">Married</SelectItem>
                            <SelectItem value="divorced">Divorced</SelectItem>
                            <SelectItem value="widowed">Widowed</SelectItem>
                            <SelectItem value="separated">Separated</SelectItem>
                          </SelectContent>
                        </Select>
                      <FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="blood_group" render={({ field }) => (
                      <FormItem><FormLabel>Blood Group</FormLabel><FormControl><Input {...field} placeholder="e.g. A+" /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="disability_status" render={({ field }) => (
                      <FormItem><FormLabel>Disability Status</FormLabel>
                        <Select value={toVal(field.value)} onValueChange={v => field.onChange(fromVal(v))}>
                          <FormControl><SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger></FormControl>
                          <SelectContent>
                            <SelectItem value={NONE}>— Not specified —</SelectItem>
                            <SelectItem value="NONE">None</SelectItem>
                            <SelectItem value="PARTIAL">Partial</SelectItem>
                            <SelectItem value="FULL">Full</SelectItem>
                          </SelectContent>
                        </Select>
                      <FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="nationality" render={({ field }) => (
                      <FormItem><FormLabel>Nationality</FormLabel><FormControl><Input {...field} placeholder="Ethiopian" /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="citizenship_status" render={({ field }) => (
                      <FormItem><FormLabel>Citizenship Status</FormLabel>
                        <Select value={toVal(field.value)} onValueChange={v => field.onChange(fromVal(v))}>
                          <FormControl><SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger></FormControl>
                          <SelectContent>
                            <SelectItem value={NONE}>— Not specified —</SelectItem>
                            <SelectItem value="CITIZEN">Citizen</SelectItem>
                            <SelectItem value="RESIDENT">Resident</SelectItem>
                            <SelectItem value="EXPAT">Expat</SelectItem>
                          </SelectContent>
                        </Select>
                      <FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="religion" render={({ field }) => (
                      <FormItem><FormLabel>Religion</FormLabel><FormControl><Input {...field} placeholder="Optional" /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="mother_tongue" render={({ field }) => (
                      <FormItem><FormLabel>Mother Tongue</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="medical_certificate_status" render={({ field }) => (
                      <FormItem><FormLabel>Medical Certificate Status</FormLabel>
                        <Select value={toVal(field.value)} onValueChange={v => field.onChange(fromVal(v))}>
                          <FormControl><SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger></FormControl>
                          <SelectContent>
                            <SelectItem value={NONE}>— Not specified —</SelectItem>
                            <SelectItem value="Valid">Valid</SelectItem>
                            <SelectItem value="Expired">Expired</SelectItem>
                            <SelectItem value="Not Submitted">Not Submitted</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      <FormMessage /></FormItem>
                    )} />
                  </div>
                  <Separator />
                  <p className="text-xs font-semibold uppercase text-muted-foreground">Identification Documents</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name="national_id" render={({ field }) => (
                      <FormItem><FormLabel>National ID</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="passport_no" render={({ field }) => (
                      <FormItem><FormLabel>Passport Number</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="tin_number_encrypted" render={({ field }) => (
                      <FormItem><FormLabel>TIN Number</FormLabel><FormControl><Input {...field} placeholder="Tax Identification Number" /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="kebele_id" render={({ field }) => (
                      <FormItem><FormLabel>Kebele ID</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </div>
                </TabsContent>

                {/* ── CONTACT ── */}
                <TabsContent value="contact" className="px-6 py-5 space-y-4 mt-0">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name="email" render={({ field }) => (
                      <FormItem><FormLabel>Work Email *</FormLabel><FormControl><Input type="email" {...field} placeholder="name@company.com" /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="personal_email" render={({ field }) => (
                      <FormItem><FormLabel>Personal Email</FormLabel><FormControl><Input type="email" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="phone" render={({ field }) => (
                      <FormItem><FormLabel>Phone</FormLabel><FormControl><Input {...field} placeholder="+251 9xx xxx xxxx" /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="mobile" render={({ field }) => (
                      <FormItem><FormLabel>Mobile</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="po_box" render={({ field }) => (
                      <FormItem><FormLabel>P.O. Box</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </div>
                  <Separator />
                  <p className="text-sm font-medium text-foreground">Address</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name="region" render={({ field }) => (
                      <FormItem><FormLabel>Region</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="city" render={({ field }) => (
                      <FormItem><FormLabel>City</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="sub_city" render={({ field }) => (
                      <FormItem><FormLabel>Sub-City</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="woreda" render={({ field }) => (
                      <FormItem><FormLabel>Woreda</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="street_name" render={({ field }) => (
                      <FormItem><FormLabel>Street Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="house_number" render={({ field }) => (
                      <FormItem><FormLabel>House Number</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="state" render={({ field }) => (
                      <FormItem><FormLabel>State / Province</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="country" render={({ field }) => (
                      <FormItem><FormLabel>Country</FormLabel><FormControl><Input {...field} placeholder="Ethiopia" /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="postal_code" render={({ field }) => (
                      <FormItem><FormLabel>Postal Code</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </div>
                </TabsContent>

                {/* ── EMPLOYMENT ── */}
                <TabsContent value="employment" className="px-6 py-5 space-y-4 mt-0">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name="employee_no" render={({ field }) => (
                      <FormItem><FormLabel>Employee No.</FormLabel>
                        <FormControl><Input {...field} placeholder="Auto-generated if blank" /></FormControl>
                      <FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="hire_date" render={({ field }) => (
                      <FormItem><FormLabel>Hire Date *</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="employment_type" render={({ field }) => (
                      <FormItem><FormLabel>Employment Type *</FormLabel>
                        <Select value={field.value} onValueChange={field.onChange}>
                          <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                          <SelectContent>
                            <SelectItem value="full_time">Full-Time</SelectItem>
                            <SelectItem value="part_time">Part-Time</SelectItem>
                            <SelectItem value="contract">Contract</SelectItem>
                            <SelectItem value="intern">Intern</SelectItem>
                            <SelectItem value="temporary">Temporary</SelectItem>
                          </SelectContent>
                        </Select>
                      <FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="employment_status" render={({ field }) => (
                      <FormItem><FormLabel>Employment Status *</FormLabel>
                        <Select value={field.value} onValueChange={field.onChange}>
                          <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                          <SelectContent>
                            <SelectItem value="active">Active</SelectItem>
                            <SelectItem value="probation">Probation</SelectItem>
                            <SelectItem value="on_leave">On Leave</SelectItem>
                            <SelectItem value="inactive">Inactive</SelectItem>
                            <SelectItem value="terminated">Terminated</SelectItem>
                            <SelectItem value="resigned">Resigned</SelectItem>
                            <SelectItem value="retired">Retired</SelectItem>
                          </SelectContent>
                        </Select>
                      <FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="probation_end_date" render={({ field }) => (
                      <FormItem><FormLabel>Probation End Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="confirmation_date" render={({ field }) => (
                      <FormItem><FormLabel>Confirmation Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="resignation_date" render={({ field }) => (
                      <FormItem><FormLabel>Resignation Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="termination_date" render={({ field }) => (
                      <FormItem><FormLabel>Termination Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="last_working_date" render={({ field }) => (
                      <FormItem><FormLabel>Last Working Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </div>
                </TabsContent>

                {/* ── ORGANIZATION ── */}
                <TabsContent value="org" className="px-6 py-5 space-y-4 mt-0">
                  {loadingRef ? (
                    <div className="space-y-3">
                      {Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-10 rounded-md bg-muted animate-pulse" />)}
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField control={form.control} name="department_id" render={({ field }) => (
                        <FormItem><FormLabel>Department</FormLabel>
                          <Select value={toVal(field.value)} onValueChange={v => { field.onChange(fromVal(v)); form.setValue('position_id', undefined); }}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger></FormControl>
                            <SelectContent>
                              <SelectItem value={NONE}>— No department —</SelectItem>
                              {departments.filter(d => d.is_active).map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        <FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="position_id" render={({ field }) => (
                        <FormItem><FormLabel>Position</FormLabel>
                          <Select value={toVal(field.value)} onValueChange={v => field.onChange(fromVal(v))}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Select position" /></SelectTrigger></FormControl>
                            <SelectContent>
                              <SelectItem value={NONE}>— No position —</SelectItem>
                              {filteredPositions.filter(p => p.is_active).map(p => <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        <FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="location_id" render={({ field }) => (
                        <FormItem><FormLabel>Work Location</FormLabel>
                          <Select value={toVal(field.value)} onValueChange={v => field.onChange(fromVal(v))}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Select location" /></SelectTrigger></FormControl>
                            <SelectContent>
                              <SelectItem value={NONE}>— No location —</SelectItem>
                              {locations.map(l => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        <FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="job_grade_id" render={({ field }) => (
                        <FormItem><FormLabel>Job Grade</FormLabel>
                          <Select value={toVal(field.value)} onValueChange={v => field.onChange(fromVal(v))}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Select grade" /></SelectTrigger></FormControl>
                            <SelectContent>
                              <SelectItem value={NONE}>— No grade —</SelectItem>
                              {jobGrades.map(g => <SelectItem key={g.id} value={g.id}>{g.name} (L{g.level})</SelectItem>)}
                            </SelectContent>
                          </Select>
                        <FormMessage /></FormItem>
                      )} />
                      <div className="md:col-span-2">
                        <FormField control={form.control} name="manager_id" render={({ field }) => (
                          <FormItem><FormLabel>Direct Manager</FormLabel>
                            <Select value={toVal(field.value)} onValueChange={v => field.onChange(fromVal(v))}>
                              <FormControl><SelectTrigger><SelectValue placeholder="Select manager" /></SelectTrigger></FormControl>
                              <SelectContent>
                                <SelectItem value={NONE}>— No manager —</SelectItem>
                                {managers
                                  .filter(m => !employee || m.id !== employee.id)
                                  .map(m => (
                                    <SelectItem key={m.id} value={m.id}>
                                      {m.first_name} {m.last_name} · {m.employee_no}
                                    </SelectItem>
                                  ))}
                              </SelectContent>
                            </Select>
                          <FormMessage /></FormItem>
                        )} />
                      </div>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </form>
          </Form>
        </div>

        <div className="px-6 py-4 border-t border-border shrink-0 flex flex-row justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            form="emp-form"
            type="submit"
            disabled={form.formState.isSubmitting}
          >
            {form.formState.isSubmitting
              ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />{isEdit ? 'Saving…' : 'Creating…'}</>
              : isEdit ? 'Save Changes' : 'Create Employee'}
          </Button>
        </div>
    </div>
  );
}
