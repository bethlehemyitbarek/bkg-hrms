import { useApiQuery } from '@/shared/hooks/useApiQuery';
import { useApiMutation } from '@/shared/hooks/useApiMutation';
import { employeeApi } from '../api/employeeApi';
import { queryKeys } from '@/shared/query/queryKeys';

export function useEmployees() {
  return useApiQuery(queryKeys.employees, () => employeeApi.getAll());
}

export function useEmployee(id: string) {
  return useApiQuery(queryKeys.employee(id), () => employeeApi.getById(id));
}

export function useCreateEmployee() {
  return useApiMutation((data: Record<string, unknown>) => employeeApi.create(data));
}

export function useUpdateEmployee() {
  return useApiMutation(({ id, data }: { id: string; data: Record<string, unknown> }) =>
    employeeApi.update(id, data)
  );
}

export function useDeleteEmployee() {
  return useApiMutation((id: string) => employeeApi.delete(id));
}
