import { apiGet, apiPost, apiPut, apiDelete } from '@/shared/api/httpClient';
import { API_ROUTES } from '@/contracts/routes';

export const employeeApi = {
  getAll: () => apiGet<unknown[]>(API_ROUTES.EMPLOYEES),
  getById: (id: string) => apiGet<unknown>(`${API_ROUTES.EMPLOYEES}/${id}`),
  create: (data: Record<string, unknown>) => apiPost<unknown>(API_ROUTES.EMPLOYEES, data),
  update: (id: string, data: Record<string, unknown>) => apiPut<unknown>(`${API_ROUTES.EMPLOYEES}/${id}`, data),
  delete: (id: string) => apiDelete<unknown>(`${API_ROUTES.EMPLOYEES}/${id}`),
};
