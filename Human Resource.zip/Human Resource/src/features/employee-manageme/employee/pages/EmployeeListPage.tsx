import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { employeeService, type EmployeeFilters } from '@/services/employee.service';
import { departmentService } from '@/services/organization.service';
import type { Employee, Department } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { EmployeeFormDrawer } from '../components/EmployeeFormDrawer';
import { toast } from 'sonner';
import { EmployeeCsvImport } from '../components/EmployeeCsvImport';
import { Search, Plus, ChevronLeft, ChevronRight, UserCircle, RefreshCw, Pencil, Download } from 'lucide-react';
import { exportToCsv, exportToPdf } from '@/lib/exportUtils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FilePieChart, History } from 'lucide-react';
import { EmployeeReportsPage } from '../../pages/EmployeeReportsPage';
import { MassUpdatePage } from '../../pages/MassUpdatePage';
import { ChangeHistoryPage } from '../../pages/ChangeHistoryPage';

const STATUS_COLORS: Record<string, string> = {
  active:     'bg-green-100 text-green-800',
  probation:  'bg-yellow-100 text-yellow-800',
  on_leave:   'bg-blue-100 text-blue-800',
  inactive:   'bg-muted text-muted-foreground',
  terminated: 'bg-red-100 text-red-800',
  resigned:   'bg-orange-100 text-orange-800',
  retired:    'bg-purple-100 text-purple-800',
};

const EMP_TYPE_LABELS: Record<string, string> = {
  full_time:  'Full-Time',
  part_time:  'Part-Time',
  contract:   'Contract',
  intern:     'Intern',
  temporary:  'Temporary',
};

export function EmployeeListPage() {
  const navigate = useNavigate();
  const [employees,   setEmployees]   = useState<Employee[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading,     setLoading]     = useState(true);
  const [total,       setTotal]       = useState(0);
  const [page,        setPage]        = useState(1);
  const pageSize = 15;
  const totalPages = Math.ceil(total / pageSize);

  const [filters,      setFilters]      = useState<EmployeeFilters>({});
  const [search,       setSearch]       = useState('');
  const [deptFilter,   setDeptFilter]   = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Drawer state — null = create, Employee = edit
  const [drawerOpen,    setDrawerOpen]    = useState(false);
  const [editEmployee,  setEditEmployee]  = useState<Employee | null>(null);
  const [csvImportOpen,  setCsvImportOpen]  = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const result = await employeeService.list({ ...filters, page, pageSize });
      setEmployees(result.data);
      setTotal(result.total);
    } catch {
      toast.error('Failed to load employees');
    } finally {
      setLoading(false);
    }
  }, [filters, page, pageSize]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    departmentService.list().then(setDepartments).catch(() => {});
  }, []);

  const handleSearch = () => {
    setFilters({
      search: search || undefined,
      department_id:      deptFilter   !== 'all' ? deptFilter   : undefined,
      employment_status:  statusFilter !== 'all' ? statusFilter : undefined,
    });
    setPage(1);
  };

  const openCreate = () => { setEditEmployee(null); setDrawerOpen(true); };
  const openEdit   = (emp: Employee) => { setEditEmployee(emp); setDrawerOpen(true); };

  const handleSaved = (saved: Employee) => {
    setEmployees(prev => {
      const idx = prev.findIndex(e => e.id === saved.id);
      if (idx >= 0) { const next = [...prev]; next[idx] = saved; return next; }
      return [saved, ...prev];
    });
    setTotal(t => editEmployee ? t : t + 1);
  };

  const fullName = (e: Employee) => `${e.first_name} ${e.last_name}`;

  const handleExportCsv = () => {
    const exportData = employees.map(emp => ({
      ID: emp.employee_no,
      FirstName: emp.first_name,
      LastName: emp.last_name,
      Email: emp.email,
      Department: (emp.department as any)?.name ?? '',
      Position: (emp.position as any)?.title ?? '',
      Type: emp.employment_type,
      Status: emp.employment_status,
      HireDate: emp.hire_date
    }));
    exportToCsv('employees.csv', exportData);
  };

  const handleExportPdf = () => {
    exportToPdf('employees.pdf');
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground text-balance">Employees</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} total records</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Button variant="outline" size="sm" onClick={handleExportCsv}>
            <Download className="h-4 w-4 mr-1.5" /> CSV
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportPdf}>
            <Download className="h-4 w-4 mr-1.5" /> PDF
          </Button>
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1.5 ${loading ? 'animate-spin' : ''}`} />Refresh
          </Button>
          <Button size="sm" onClick={openCreate}>
            <Plus className="h-4 w-4 mr-1.5" />Add Employee
          </Button>
        </div>
      </div>

      <Tabs defaultValue="directory">
        <TabsList className="h-9">
          <TabsTrigger value="directory" className="text-xs md:text-sm gap-1.5"><UserCircle className="h-3.5 w-3.5" />Directory</TabsTrigger>
          <TabsTrigger value="reports" className="text-xs md:text-sm gap-1.5"><FilePieChart className="h-3.5 w-3.5" />Reports</TabsTrigger>
          <TabsTrigger value="mass-update" className="text-xs md:text-sm gap-1.5"><RefreshCw className="h-3.5 w-3.5" />Mass Update</TabsTrigger>
          <TabsTrigger value="change-history" className="text-xs md:text-sm gap-1.5"><History className="h-3.5 w-3.5" />Change History</TabsTrigger>
        </TabsList>

        <TabsContent value="directory" className="mt-4">

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-1 min-w-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, ID, or email…"
            className="pl-9"
            value={search}
            onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
          />
        </div>
        <Select value={deptFilter} onValueChange={v => { setDeptFilter(v); setPage(1); }}>
          <SelectTrigger className="w-full md:w-52 shrink-0">
            <SelectValue placeholder="All Departments" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Departments</SelectItem>
            {departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setPage(1); }}>
          <SelectTrigger className="w-full md:w-44 shrink-0">
            <SelectValue placeholder="All Statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="probation">Probation</SelectItem>
            <SelectItem value="on_leave">On Leave</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
            <SelectItem value="terminated">Terminated</SelectItem>
            <SelectItem value="resigned">Resigned</SelectItem>
          </SelectContent>
        </Select>
        <Button onClick={handleSearch} className="shrink-0">Search</Button>
      </div>

      {/* Table */}
      <div className="border border-border rounded-lg overflow-hidden bg-card min-w-0">
        <div className="overflow-x-auto w-full">
          <Table className="[&>div]:max-w-full">
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">ID</TableHead>
                <TableHead className="whitespace-nowrap">Department</TableHead>
                <TableHead className="whitespace-nowrap">Position</TableHead>
                <TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Hire Date</TableHead>
                <TableHead className="whitespace-nowrap w-12"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                Array.from({ length: 8 }).map((_, i) => (
                  <TableRow key={i}>
                    {Array.from({ length: 8 }).map((__, j) => (
                      <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>
                    ))}
                  </TableRow>
                ))
              ) : employees.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-14 text-muted-foreground">
                    <UserCircle className="h-10 w-10 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">No employees found</p>
                    <Button variant="outline" size="sm" className="mt-3" onClick={openCreate}>
                      <Plus className="h-3.5 w-3.5 mr-1.5" />Add First Employee
                    </Button>
                  </TableCell>
                </TableRow>
              ) : (
                employees.map(emp => (
                  <TableRow
                    key={emp.id}
                    className="hover:bg-muted/40 transition-colors cursor-pointer"
                    onClick={() => navigate(`/employees/${emp.id}`)}
                  >
                    <TableCell className="whitespace-nowrap">
                      <div className="flex items-center gap-2.5">
                        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                          <span className="text-xs font-semibold text-primary">
                            {emp.first_name[0]}{emp.last_name[0]}
                          </span>
                        </div>
                        <div className="min-w-0">
                          <p className="font-medium text-sm leading-tight">{fullName(emp)}</p>
                          <p className="text-xs text-muted-foreground truncate max-w-[160px]">{emp.email}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-xs">{emp.employee_no}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{(emp.department as Department)?.name ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{(emp.position as { title?: string })?.title ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{EMP_TYPE_LABELS[emp.employment_type] ?? emp.employment_type}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium capitalize ${STATUS_COLORS[emp.employment_status] ?? 'bg-muted text-muted-foreground'}`}>
                        {emp.employment_status.replace('_', ' ')}
                      </span>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{emp.hire_date}</TableCell>
                    <TableCell className="whitespace-nowrap" onClick={e => e.stopPropagation()}>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => openEdit(emp)}
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Showing {((page - 1) * pageSize) + 1}–{Math.min(page * pageSize, total)} of {total}
          </p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm font-medium">{page} / {totalPages}</span>
            <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Create / Edit Drawer */}
      <EmployeeCsvImport
        open={csvImportOpen}
        onOpenChange={setCsvImportOpen}
        onImported={() => { load(); }}
      />
      <EmployeeFormDrawer
        open={drawerOpen}
        onOpenChange={setDrawerOpen}
        employee={editEmployee}
        onSuccess={handleSaved}
      />
        </TabsContent>

        <TabsContent value="reports" className="mt-4">
          <EmployeeReportsPage />
        </TabsContent>

        <TabsContent value="mass-update" className="mt-4">
          <MassUpdatePage />
        </TabsContent>

        <TabsContent value="change-history" className="mt-4">
          <ChangeHistoryPage />
        </TabsContent>
      </Tabs>
    </div>
  );
}
