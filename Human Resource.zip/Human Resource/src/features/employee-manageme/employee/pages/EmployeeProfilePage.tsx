// @refresh reset
import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { employeeService } from '@/services/employee.service';
import { documentService } from '@/services/modules.service';
import type { Employee, Department, Document } from '@/types/database.types';
import { EmployeeFormDrawer } from '../components/EmployeeFormDrawer';
import { EmergencyContactsTab } from '../components/tabs/EmergencyContactsTab';
import { EmploymentAssignmentTab } from '../components/tabs/EmploymentAssignmentTab';
import { FamilyTab } from '../components/tabs/FamilyTab';
import { EducationTab } from '../components/tabs/EducationTab';
import { WorkExperienceTab } from '../components/tabs/WorkExperienceTab';
import { CredentialsTab } from '../components/tabs/CredentialsTab';
import { ContractTab } from '../components/tabs/ContractTab';
import { PromotionTimelineTab } from '../components/tabs/PromotionTimelineTab';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import {
  ArrowLeft, Pencil, User, Briefcase, FileText, GraduationCap,
  Mail, Phone, MapPin, Calendar, Building2, CreditCard, Shield,
  ExternalLink, Users, Award, HeartHandshake, BookOpen, TrendingUp,
  ShieldCheck, UserCog, Plus, Trash2, Loader2,
} from 'lucide-react';
import { supabase } from '@/db/supabase';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

/* ── helpers ─────────────────────────────────────────────────────────── */
const STATUS_COLORS: Record<string, string> = {
  active:     'bg-green-100 text-green-800',
  probation:  'bg-yellow-100 text-yellow-800',
  on_leave:   'bg-blue-100 text-blue-800',
  inactive:   'bg-muted text-muted-foreground',
  terminated: 'bg-red-100 text-red-800',
  resigned:   'bg-orange-100 text-orange-800',
  retired:    'bg-purple-100 text-purple-800',
};

const PROFILE_STATUS_COLORS: Record<string, string> = {
  ACTIVE:      'bg-green-100 text-green-800',
  DRAFT:       'bg-muted text-muted-foreground',
  INACTIVE:    'bg-orange-100 text-orange-800',
  OFFBOARDED:  'bg-red-100 text-red-800',
};

const RETIRE_FLAG_COLORS: Record<string, string> = {
  Green:  'bg-green-100 text-green-800',
  Yellow: 'bg-yellow-100 text-yellow-800',
  Red:    'bg-red-100 text-red-800',
};

const fmt = (v: string | undefined | null) => v || '—';
const fmtDate = (v: string | undefined | null) =>
  v ? new Date(v).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
const fmtCurrency = (n: number | undefined | null, currency = 'ETB') =>
  n != null ? new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n) : '—';

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-sm font-medium text-foreground break-words">{value}</span>
    </div>
  );
}

/* ── Main Component ──────────────────────────────────────────────────── */
export function EmployeeProfilePage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [employee,  setEmployee]  = useState<Employee | null>(null);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading,   setLoading]   = useState(true);
  const [editOpen,  setEditOpen]  = useState(false);

  const load = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const emp = await employeeService.getById(id);
      if (!emp) { toast.error('Employee not found'); navigate('/employees'); return; }
      setEmployee(emp);
    } catch {
      toast.error('Failed to load employee profile');
      navigate('/employees');
      setLoading(false);
      return;
    }
    const docsResult = await documentService.list({ employee_id: id, status: undefined, pageSize: 50 }).catch(() => null);
    if (docsResult) setDocuments(docsResult.data as Document[]);
    setLoading(false);
  }, [id, navigate]);

  useEffect(() => { load(); }, [load]);

  const handleSaved = (updated: Employee) => {
    setEmployee(updated);
    toast.success('Employee profile updated');
  };

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="flex items-center gap-3">
          <Skeleton className="h-9 w-20 bg-muted" />
          <Skeleton className="h-7 w-56 bg-muted" />
        </div>
        <Skeleton className="h-32 w-full bg-muted rounded-xl" />
        <Skeleton className="h-64 w-full bg-muted rounded-xl" />
      </div>
    );
  }

  if (!employee) return null;

  const dept = employee.department as Department | undefined;
  const pos  = employee.position  as { title?: string } | undefined;
  const mgr  = employee.manager   as { first_name?: string; last_name?: string } | undefined;
  const jg   = employee.job_grade as { name?: string; level?: number } | undefined;
  const ed   = employee.employment_details as Record<string, unknown> | undefined;

  // Address line
  const addressParts = [
    employee.street_name, employee.house_number && `No. ${employee.house_number}`,
    employee.woreda && `Woreda ${employee.woreda}`, employee.sub_city,
    employee.city, employee.region,
  ].filter(Boolean);
  const fullAddress = addressParts.length ? addressParts.join(', ') : employee.address ?? '—';

  return (
    <div className="space-y-5 max-w-5xl">
      {/* ── Back + Header ── */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3 min-w-0">
          <Button variant="ghost" size="icon" onClick={() => navigate('/employees')} className="shrink-0">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="min-w-0">
            <h1 className="text-2xl font-bold text-balance truncate">
              {employee.first_name} {employee.last_name}
            </h1>
            <p className="text-sm text-muted-foreground font-mono">{employee.employee_no}</p>
          </div>
        </div>
        <Button onClick={() => setEditOpen(true)} className="shrink-0">
          <Pencil className="h-4 w-4 mr-1.5" />Edit Profile
        </Button>
      </div>

      {/* ── Hero card ── */}
      <Card>
        <CardContent className="p-5">
          <div className="flex flex-col md:flex-row items-start gap-5">
            {/* Avatar / photo */}
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center shrink-0 text-xl font-bold text-primary overflow-hidden">
              {employee.employee_photo || employee.profile_photo_url
                ? <img src={employee.employee_photo ?? employee.profile_photo_url ?? ''} alt="profile" className="w-full h-full object-cover" />
                : <>{employee.first_name[0]}{employee.last_name[0]}</>
              }
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-3">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${STATUS_COLORS[employee.employment_status] ?? 'bg-muted text-muted-foreground'}`}>
                  {employee.employment_status.replace('_', ' ')}
                </span>
                <Badge variant="secondary" className="text-xs capitalize">
                  {employee.employment_type.replace('_', '-')}
                </Badge>
                {employee.profile_status && employee.profile_status !== 'ACTIVE' && (
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${PROFILE_STATUS_COLORS[employee.profile_status]}`}>
                    {employee.profile_status}
                  </span>
                )}
                {employee.retirement_eligibility_flag && (
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${RETIRE_FLAG_COLORS[employee.retirement_eligibility_flag]}`}>
                    Retirement: {employee.retirement_eligibility_flag}
                  </span>
                )}
                {!employee.is_active && (
                  <Badge variant="destructive" className="text-xs">Inactive</Badge>
                )}
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground col-span-2 md:col-span-1">
                  <Building2 className="h-3.5 w-3.5 shrink-0" />
                  <span className="truncate">{dept?.name ?? '—'}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Briefcase className="h-3.5 w-3.5 shrink-0" />
                  <span className="truncate">{pos?.title ?? '—'}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="h-3.5 w-3.5 shrink-0" />
                  <span className="truncate">{employee.email}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="h-3.5 w-3.5 shrink-0" />
                  <span>Hired {fmtDate(employee.hire_date)}</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ── Tabs ── */}
      <Tabs defaultValue="personal">
        <TabsList className="flex w-full overflow-x-auto whitespace-nowrap justify-start h-auto flex-wrap gap-1 md:flex-nowrap">
          <TabsTrigger value="personal" className="flex items-center gap-1.5"><User className="h-3.5 w-3.5" />Personal</TabsTrigger>
          <TabsTrigger value="employment" className="flex items-center gap-1.5"><Briefcase className="h-3.5 w-3.5" />Employment</TabsTrigger>
          <TabsTrigger value="emergency" className="flex items-center gap-1.5"><Phone className="h-3.5 w-3.5" />Emergency</TabsTrigger>
          <TabsTrigger value="family" className="flex items-center gap-1.5"><Users className="h-3.5 w-3.5" />Family</TabsTrigger>
          <TabsTrigger value="education" className="flex items-center gap-1.5"><GraduationCap className="h-3.5 w-3.5" />Education</TabsTrigger>
          <TabsTrigger value="experience" className="flex items-center gap-1.5"><BookOpen className="h-3.5 w-3.5" />Experience</TabsTrigger>
          <TabsTrigger value="credentials" className="flex items-center gap-1.5"><Award className="h-3.5 w-3.5" />Credentials</TabsTrigger>
          <TabsTrigger value="contracts" className="flex items-center gap-1.5"><FileText className="h-3.5 w-3.5" />Contracts</TabsTrigger>
          <TabsTrigger value="documents" className="flex items-center gap-1.5">
            <Shield className="h-3.5 w-3.5" />Documents
            {documents.length > 0 && <span className="ml-1 text-xs bg-muted px-1.5 py-0.5 rounded-full">{documents.length}</span>}
          </TabsTrigger>
          <TabsTrigger value="promotions" className="flex items-center gap-1.5">
            <TrendingUp className="h-3.5 w-3.5" />Promotions
          </TabsTrigger>
          <TabsTrigger value="guarantor" className="flex items-center gap-1.5">
            <ShieldCheck className="h-3.5 w-3.5" />Guarantor
          </TabsTrigger>
          <TabsTrigger value="acting" className="flex items-center gap-1.5">
            <UserCog className="h-3.5 w-3.5" />Acting
          </TabsTrigger>
        </TabsList>

        {/* ── 2.1 PERSONAL ── */}
        <TabsContent value="personal" className="mt-4 space-y-4">
          {/* Identity */}
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><User className="h-4 w-4" />Personal Identity</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4">
                <InfoRow label="First Name"           value={fmt(employee.first_name)} />
                <InfoRow label="Middle Name"          value={fmt(employee.middle_name)} />
                <InfoRow label="Last Name"            value={fmt(employee.last_name)} />
                <InfoRow label="Preferred Name"       value={fmt(employee.preferred_name)} />
                <InfoRow label="Mother's Name"        value={fmt(employee.mother_name)} />
                <InfoRow label="Gender"               value={fmt(employee.gender)} />
                <InfoRow label="Date of Birth"        value={fmtDate(employee.date_of_birth)} />
                <InfoRow label="Place of Birth"       value={fmt(employee.place_of_birth)} />
                <InfoRow label="Nationality"          value={fmt(employee.nationality)} />
                <InfoRow label="Citizenship Status"   value={fmt(employee.citizenship_status)} />
                <InfoRow label="Marital Status"       value={fmt(employee.marital_status)} />
                <InfoRow label="Blood Group"          value={fmt(employee.blood_group)} />
                <InfoRow label="Disability Status"    value={fmt(employee.disability_status)} />
                <InfoRow label="Mother Tongue"        value={fmt(employee.mother_tongue)} />
              </div>
            </CardContent>
          </Card>

          {/* Religion / Ethnicity */}
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><HeartHandshake className="h-4 w-4" />Cultural Information</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4">
                <InfoRow label="Religion"                    value={fmt(employee.religion)} />
                <InfoRow label="Medical Certificate Status"  value={fmt(employee.medical_certificate_status)} />
              </div>
            </CardContent>
          </Card>

          {/* Identification Documents */}
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><CreditCard className="h-4 w-4" />Identification Documents</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4">
                <InfoRow label="National ID"     value={fmt(employee.national_id)} />
                <InfoRow label="TIN Number"      value={employee.tin_number_encrypted ? '••••••••' : '—'} />
                <InfoRow label="Kebele ID"       value={employee.kebele_id ? '••••••••' : '—'} />
                <InfoRow label="Passport No."    value={fmt(employee.passport_no)} />
              </div>
            </CardContent>
          </Card>

          {/* Contact & Address */}
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Phone className="h-4 w-4" />Contact Details</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4">
                <InfoRow label="Work Email"     value={fmt(employee.email)} />
                <InfoRow label="Personal Email" value={fmt(employee.personal_email)} />
                <InfoRow label="Phone"          value={fmt(employee.phone)} />
                <InfoRow label="Mobile"         value={fmt(employee.mobile)} />
                <InfoRow label="P.O. Box"       value={fmt(employee.po_box)} />
              </div>
              <Separator className="my-4" />
              <p className="text-xs font-semibold uppercase text-muted-foreground mb-3 flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />Address</p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4">
                <div className="md:col-span-3"><InfoRow label="Full Address" value={fullAddress} /></div>
                <InfoRow label="Region"    value={fmt(employee.region)} />
                <InfoRow label="City"      value={fmt(employee.city)} />
                <InfoRow label="Sub-City"  value={fmt(employee.sub_city)} />
                <InfoRow label="Woreda"    value={fmt(employee.woreda)} />
                <InfoRow label="Street"    value={fmt(employee.street_name)} />
                <InfoRow label="House No." value={fmt(employee.house_number)} />
                <InfoRow label="Country"   value={fmt(employee.country)} />
                <InfoRow label="State"     value={fmt(employee.state)} />
                <InfoRow label="Postal Code" value={fmt(employee.postal_code)} />
              </div>
            </CardContent>
          </Card>

          {/* Retirement */}
          {(employee.retirement_age || employee.planned_retirement_date || employee.retirement_eligibility_flag) && (
            <Card>
              <CardHeader><CardTitle className="text-base flex items-center gap-2"><Calendar className="h-4 w-4" />Retirement Information</CardTitle></CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4">
                  <InfoRow label="Retirement Age"           value={employee.retirement_age ? String(employee.retirement_age) : '—'} />
                  <InfoRow label="Planned Retirement Date"  value={fmtDate(employee.planned_retirement_date)} />
                  <InfoRow label="Eligibility Flag"         value={fmt(employee.retirement_eligibility_flag)} />
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ── 2.1 EMPLOYMENT (core employment + org) ── */}
        <TabsContent value="employment" className="mt-4 space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Briefcase className="h-4 w-4" />Job &amp; Organization</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4">
                <InfoRow label="Employee No."      value={fmt(employee.employee_no)} />
                <InfoRow label="Department"        value={dept?.name ?? '—'} />
                <InfoRow label="Position"          value={pos?.title ?? '—'} />
                <InfoRow label="Job Grade"         value={jg ? `${jg.name} (L${jg.level})` : '—'} />
                <InfoRow label="Direct Manager"    value={mgr ? `${mgr.first_name} ${mgr.last_name}` : '—'} />
                <InfoRow label="Employment Type"   value={fmt(employee.employment_type?.replace('_', '-'))} />
                <InfoRow label="Employment Status" value={fmt(employee.employment_status?.replace('_', ' '))} />
                <InfoRow label="Profile Status"    value={fmt(employee.profile_status)} />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Calendar className="h-4 w-4" />Key Dates</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4">
                <InfoRow label="Hire Date"          value={fmtDate(employee.hire_date)} />
                <InfoRow label="Probation End"      value={fmtDate(employee.probation_end_date)} />
                <InfoRow label="Confirmation Date"  value={fmtDate(employee.confirmation_date)} />
                <InfoRow label="Resignation Date"   value={fmtDate(employee.resignation_date)} />
                <InfoRow label="Termination Date"   value={fmtDate(employee.termination_date)} />
                <InfoRow label="Last Working Date"  value={fmtDate(employee.last_working_date)} />
              </div>
            </CardContent>
          </Card>
          {ed && (
            <Card>
              <CardHeader><CardTitle className="text-base flex items-center gap-2"><CreditCard className="h-4 w-4" />Compensation</CardTitle></CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4">
                  <InfoRow label="Base Salary"       value={fmtCurrency(ed.base_salary as number, String(ed.salary_currency ?? 'ETB'))} />
                  <InfoRow label="Salary Frequency"  value={fmt(ed.salary_frequency as string)} />
                  <InfoRow label="Payment Method"    value={fmt(ed.payment_method as string)} />
                  <InfoRow label="Tax ID"            value={fmt(ed.tax_id as string)} />
                  <InfoRow label="Social Security No" value={fmt(ed.social_security_no as string)} />
                  <InfoRow label="Overtime Eligible" value={ed.overtime_eligible ? 'Yes' : 'No'} />
                  <InfoRow label="Work Hours/Day"    value={ed.work_hours_per_day ? `${ed.work_hours_per_day}h` : '—'} />
                  <InfoRow label="Work Days/Week"    value={ed.work_days_per_week ? `${ed.work_days_per_week}d` : '—'} />
                </div>
              </CardContent>
            </Card>
          )}
          {/* Employment Details + Work Assignments */}
          <EmploymentAssignmentTab employeeId={employee.id} />
        </TabsContent>

        {/* ── 2.2 EMERGENCY CONTACTS ── */}
        <TabsContent value="emergency" className="mt-4">
          <EmergencyContactsTab employeeId={employee.id} />
        </TabsContent>

        {/* ── 2.4 FAMILY ── */}
        <TabsContent value="family" className="mt-4">
          <FamilyTab employeeId={employee.id} />
        </TabsContent>

        {/* ── 2.6 EDUCATION ── */}
        <TabsContent value="education" className="mt-4">
          <EducationTab employeeId={employee.id} />
        </TabsContent>

        {/* ── 2.7 WORK EXPERIENCE ── */}
        <TabsContent value="experience" className="mt-4">
          <WorkExperienceTab employeeId={employee.id} />
        </TabsContent>

        {/* ── 2.8 CREDENTIALS ── */}
        <TabsContent value="credentials" className="mt-4">
          <CredentialsTab employeeId={employee.id} />
        </TabsContent>

        {/* ── 2.9 CONTRACTS ── */}
        <TabsContent value="contracts" className="mt-4">
          <ContractTab employeeId={employee.id} />
        </TabsContent>

        {/* ── DOCUMENTS (existing) ── */}
        <TabsContent value="documents" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <FileText className="h-4 w-4" />Documents
                <span className="ml-auto text-sm font-normal text-muted-foreground">{documents.length} file{documents.length !== 1 ? 's' : ''}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {documents.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground text-sm">
                  <FileText className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  No documents on file
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {documents.map(doc => (
                    <div key={doc.id} className="flex items-start justify-between gap-3 px-5 py-3 hover:bg-muted/30">
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium truncate">{doc.title}</p>
                        <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                          <span className="text-xs text-muted-foreground">{doc.document_type}</span>
                          {doc.expiry_date && (
                            <span className="text-xs text-muted-foreground">· Expires {fmtDate(doc.expiry_date)}</span>
                          )}
                          {doc.is_confidential && (
                            <span className="inline-flex items-center gap-1 text-xs text-yellow-700">
                              <Shield className="h-3 w-3" />Confidential
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${doc.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}`}>
                          {doc.status}
                        </span>
                        {doc.file_url && (
                          <a href={doc.file_url} target="_blank" rel="noopener noreferrer">
                            <Button variant="ghost" size="icon" className="h-7 w-7">
                              <ExternalLink className="h-3.5 w-3.5" />
                            </Button>
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── PROMOTIONS ── */}
        <TabsContent value="promotions" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />Promotion History
              </CardTitle>
            </CardHeader>
            <CardContent>
              {id && <PromotionTimelineTab employeeId={id} />}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── FR-EM-017/018/019: GUARANTOR ── */}
        <TabsContent value="guarantor" className="mt-4">
          {id && <GuarantorTab employeeId={id} />}
        </TabsContent>

        {/* ── FR-EM-025: ACTING POSITION ── */}
        <TabsContent value="acting" className="mt-4">
          {id && <ActingPositionTab employeeId={id} />}
        </TabsContent>
      </Tabs>

      <EmployeeFormDrawer
        open={editOpen}
        onOpenChange={setEditOpen}
        employee={employee}
        onSuccess={handleSaved}
      />
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-EM-017/018/019 – GuarantorTab
   ───────────────────────────────────────────────────────────────────────── */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

type Guarantor = {
  guarantor_id: string; full_name: string; relationship: string;
  phone?: string; email?: string; guarantor_type?: string; address?: string;
};
type Guarantee = { guarantee_id: string; guarantor_id: string; guarantee_amount: number; guarantee_date?: string; description?: string };
type Collateral = { collateral_id: string; guarantor_id: string; collateral_type?: string; description?: string; estimated_value?: number };

function GuarantorTab({ employeeId }: { employeeId: string }) {
  const [guarantors, setGuarantors] = useState<Guarantor[]>([]);
  const [guarantees, setGuarantees] = useState<Guarantee[]>([]);
  const [collaterals, setCollaterals] = useState<Collateral[]>([]);
  const [loading, setLoading] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ full_name: '', relationship: '', phone: '', email: '', guarantor_type: 'PERSONAL', address: '' });

  const load = async () => {
    setLoading(true);
    try {
      const { data: g } = await sb.from('guarantors').select('*').eq('employee_id', employeeId).order('full_name');
      const gList: Guarantor[] = g || [];
      setGuarantors(gList);
      if (gList.length > 0) {
        const ids = gList.map((x: Guarantor) => x.guarantor_id);
        const [{ data: gd }, { data: gc }] = await Promise.all([
          sb.from('guarantees').select('*').in('guarantor_id', ids),
          sb.from('guarantor_collaterals').select('*').in('guarantor_id', ids),
        ]);
        setGuarantees(gd || []);
        setCollaterals(gc || []);
      }
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [employeeId]); // eslint-disable-line react-hooks/exhaustive-deps

  const save = async () => {
    if (!form.full_name.trim()) { toast.error('Full name required'); return; }
    setSaving(true);
    const { error } = await sb.from('guarantors').insert({ ...form, employee_id: employeeId });
    if (error) { toast.error(error.message); } else { toast.success('Guarantor added'); setAddOpen(false); setForm({ full_name: '', relationship: '', phone: '', email: '', guarantor_type: 'PERSONAL', address: '' }); load(); }
    setSaving(false);
  };

  const remove = async (id: string) => {
    await sb.from('guarantors').delete().eq('guarantor_id', id);
    toast.success('Removed'); load();
  };

  if (loading) return <div className="space-y-2 p-4">{[1,2].map(i=><Skeleton key={i} className="h-16 bg-muted"/>)}</div>;

  return (
    <div className="space-y-6">
      {/* Guarantors */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2"><ShieldCheck className="h-4 w-4"/>Guarantors (FR-EM-017)</CardTitle>
            <Button size="sm" onClick={()=>setAddOpen(true)}><Plus className="h-3.5 w-3.5 mr-1"/>Add Guarantor</Button>
          </div>
        </CardHeader>
        <CardContent>
          {guarantors.length === 0 ? <p className="text-sm text-muted-foreground py-4 text-center">No guarantors recorded</p> : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Name</TableHead>
                  <TableHead className="whitespace-nowrap">Relationship</TableHead>
                  <TableHead className="whitespace-nowrap">Type</TableHead>
                  <TableHead className="whitespace-nowrap">Phone</TableHead>
                  <TableHead className="whitespace-nowrap">Email</TableHead>
                  <TableHead className="whitespace-nowrap w-10"/>
                </TableRow></TableHeader>
                <TableBody>
                  {guarantors.map(g => (
                    <TableRow key={g.guarantor_id}>
                      <TableCell className="whitespace-nowrap font-medium">{g.full_name}</TableCell>
                      <TableCell className="whitespace-nowrap">{g.relationship||'—'}</TableCell>
                      <TableCell className="whitespace-nowrap"><Badge variant="outline">{g.guarantor_type||'—'}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap">{g.phone||'—'}</TableCell>
                      <TableCell className="whitespace-nowrap">{g.email||'—'}</TableCell>
                      <TableCell><Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={()=>remove(g.guarantor_id)}><Trash2 className="h-3.5 w-3.5"/></Button></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Guarantee Details FR-EM-018 */}
      {guarantees.length > 0 && (
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-base">Guarantee Details (FR-EM-018)</CardTitle></CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Guarantor ID</TableHead>
                  <TableHead className="whitespace-nowrap">Amount</TableHead>
                  <TableHead className="whitespace-nowrap">Date</TableHead>
                  <TableHead className="whitespace-nowrap">Description</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {guarantees.map(g => (
                    <TableRow key={g.guarantee_id}>
                      <TableCell className="whitespace-nowrap text-xs text-muted-foreground">{g.guarantor_id.slice(0,8)}…</TableCell>
                      <TableCell className="whitespace-nowrap">{g.guarantee_amount?.toLocaleString()||'—'}</TableCell>
                      <TableCell className="whitespace-nowrap">{g.guarantee_date||'—'}</TableCell>
                      <TableCell>{g.description||'—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Collateral FR-EM-019 */}
      {collaterals.length > 0 && (
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-base">Guarantor Collateral (FR-EM-019)</CardTitle></CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Type</TableHead>
                  <TableHead className="whitespace-nowrap">Description</TableHead>
                  <TableHead className="whitespace-nowrap">Est. Value</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {collaterals.map(c => (
                    <TableRow key={c.collateral_id}>
                      <TableCell className="whitespace-nowrap"><Badge variant="outline">{c.collateral_type||'—'}</Badge></TableCell>
                      <TableCell>{c.description||'—'}</TableCell>
                      <TableCell className="whitespace-nowrap">{c.estimated_value?.toLocaleString()||'—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add Guarantor Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add Guarantor</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-2">
            <div className="col-span-2 space-y-1.5"><Label>Full Name *</Label><Input value={form.full_name} onChange={e=>setForm(p=>({...p,full_name:e.target.value}))} /></div>
            <div className="space-y-1.5"><Label>Relationship</Label><Input value={form.relationship} onChange={e=>setForm(p=>({...p,relationship:e.target.value}))} placeholder="e.g. Brother" /></div>
            <div className="space-y-1.5"><Label>Type</Label>
              <Select value={form.guarantor_type} onValueChange={v=>setForm(p=>({...p,guarantor_type:v}))}>
                <SelectTrigger><SelectValue/></SelectTrigger>
                <SelectContent><SelectItem value="PERSONAL">Personal</SelectItem><SelectItem value="CORPORATE">Corporate</SelectItem><SelectItem value="BANK">Bank</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Phone</Label><Input value={form.phone} onChange={e=>setForm(p=>({...p,phone:e.target.value}))} /></div>
            <div className="space-y-1.5"><Label>Email</Label><Input type="email" value={form.email} onChange={e=>setForm(p=>({...p,email:e.target.value}))} /></div>
            <div className="col-span-2 space-y-1.5"><Label>Address</Label><Input value={form.address} onChange={e=>setForm(p=>({...p,address:e.target.value}))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={()=>setAddOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving&&<Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin"/>}Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-EM-025 – ActingPositionTab
   ───────────────────────────────────────────────────────────────────────── */
type ActingAssignment = {
  acting_id: string; employee_id: string; acting_position: string;
  department?: string; start_date?: string; end_date?: string;
  approval_status?: string; reason?: string;
};

function ActingPositionTab({ employeeId }: { employeeId: string }) {
  const [rows, setRows]       = useState<ActingAssignment[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [form, setForm]       = useState({ acting_position: '', department: '', start_date: '', end_date: '', reason: '', approval_status: 'PENDING' });

  const load = async () => {
    setLoading(true);
    const { data } = await sb.from('acting_assignments').select('*').eq('employee_id', employeeId).order('start_date', { ascending: false });
    setRows(data || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, [employeeId]); // eslint-disable-line react-hooks/exhaustive-deps

  const save = async () => {
    if (!form.acting_position.trim()) { toast.error('Acting position required'); return; }
    setSaving(true);
    const { error } = await sb.from('acting_assignments').insert({ ...form, employee_id: employeeId, end_date: form.end_date || null });
    if (error) { toast.error(error.message); } else { toast.success('Acting assignment recorded'); setOpen(false); setForm({ acting_position: '', department: '', start_date: '', end_date: '', reason: '', approval_status: 'PENDING' }); load(); }
    setSaving(false);
  };

  if (loading) return <Skeleton className="h-32 bg-muted m-4" />;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><UserCog className="h-4 w-4"/>Acting Position Assignments (FR-EM-025)</CardTitle>
          <Button size="sm" onClick={()=>setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1"/>Add Assignment</Button>
        </div>
      </CardHeader>
      <CardContent>
        {rows.length === 0 ? <p className="text-sm text-muted-foreground py-4 text-center">No acting assignments recorded</p> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Acting Position</TableHead>
                <TableHead className="whitespace-nowrap">Department</TableHead>
                <TableHead className="whitespace-nowrap">Start Date</TableHead>
                <TableHead className="whitespace-nowrap">End Date</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Reason</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map(r => (
                  <TableRow key={r.acting_id}>
                    <TableCell className="whitespace-nowrap font-medium">{r.acting_position}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.department||'—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.start_date||'—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.end_date||'Ongoing'}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={r.approval_status==='APPROVED'?'bg-green-100 text-green-800':r.approval_status==='REJECTED'?'bg-red-100 text-red-800':'bg-yellow-100 text-yellow-800'}>
                        {r.approval_status||'PENDING'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">{r.reason||'—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add Acting Assignment</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-2">
            <div className="col-span-2 space-y-1.5"><Label>Acting Position *</Label><Input value={form.acting_position} onChange={e=>setForm(p=>({...p,acting_position:e.target.value}))} placeholder="e.g. Acting Head of Finance" /></div>
            <div className="space-y-1.5"><Label>Department</Label><Input value={form.department} onChange={e=>setForm(p=>({...p,department:e.target.value}))} /></div>
            <div className="space-y-1.5"><Label>Status</Label>
              <Select value={form.approval_status} onValueChange={v=>setForm(p=>({...p,approval_status:v}))}>
                <SelectTrigger><SelectValue/></SelectTrigger>
                <SelectContent><SelectItem value="PENDING">Pending</SelectItem><SelectItem value="APPROVED">Approved</SelectItem><SelectItem value="REJECTED">Rejected</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Start Date</Label><Input type="date" value={form.start_date} onChange={e=>setForm(p=>({...p,start_date:e.target.value}))} /></div>
            <div className="space-y-1.5"><Label>End Date</Label><Input type="date" value={form.end_date} onChange={e=>setForm(p=>({...p,end_date:e.target.value}))} /></div>
            <div className="col-span-2 space-y-1.5"><Label>Reason</Label><Input value={form.reason} onChange={e=>setForm(p=>({...p,reason:e.target.value}))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={()=>setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving&&<Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin"/>}Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
