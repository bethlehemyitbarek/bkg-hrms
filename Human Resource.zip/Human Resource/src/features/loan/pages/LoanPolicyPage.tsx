import { useState, useEffect, useCallback } from 'react';
import { Plus, Pencil, Trash2, ShieldCheck, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Switch } from '@/components/ui/switch';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { loanPolicyService } from '@/services/loan.service';
import type { LoanPolicy, LoanType, InterestMethod } from '@/types/database.types';

const LOAN_TYPES: LoanType[] = ['LOAN', 'ADVANCE'];
const INTEREST_METHODS: InterestMethod[] = ['FLAT_RATE', 'REDUCING_BALANCE', 'ZERO'];

const fmt = (n?: number | null) => n != null ? Number(n).toLocaleString() : '—';

// ── Form schema ─────────────────────────────────────────────────────────────────

const policySchema = z.object({
  policy_name: z.string().min(1, 'Name required').max(200),
  policy_code: z.string().min(1, 'Code required').max(50),
  loan_type: z.enum(['LOAN', 'ADVANCE']),
  max_loan_amount: z.coerce.number().min(0).optional(),
  max_salary_multiplier: z.coerce.number().min(0).optional(),
  min_service_months: z.coerce.number().min(0),
  max_concurrent_loan: z.coerce.number().min(1),
  interest_rate: z.coerce.number().min(0).max(100),
  interest_method: z.enum(['FLAT_RATE', 'REDUCING_BALANCE', 'ZERO']).optional(),
  max_repayment_months: z.coerce.number().min(1).optional(),
  max_installment_percentage: z.coerce.number().min(0).max(100).optional(),
  requires_guarantor: z.boolean(),
  requires_collateral: z.boolean(),
  effective_from: z.string().min(1, 'Effective from required'),
  effective_to: z.string().optional(),
  is_active: z.boolean(),
});
type PolicyFormValues = z.infer<typeof policySchema>;

// ── Dialog sub-component ────────────────────────────────────────────────────────

interface PolicyDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: LoanPolicy | null;
  onSaved: () => void;
}

function PolicyDialog({ open, onOpenChange, editing, onSaved }: PolicyDialogProps) {
  const [saving, setSaving] = useState(false);
  const form = useForm<PolicyFormValues>({
    resolver: zodResolver(policySchema),
    defaultValues: {
      loan_type: 'LOAN', min_service_months: 0, max_concurrent_loan: 1,
      interest_rate: 0, requires_guarantor: false, requires_collateral: false,
      is_active: true, effective_from: new Date().toISOString().slice(0, 10),
    },
  });

  useEffect(() => {
    if (!open) return;
    if (editing) {
      form.reset({
        policy_name: editing.policy_name,
        policy_code: editing.policy_code,
        loan_type: editing.loan_type,
        max_loan_amount: editing.max_loan_amount ?? undefined,
        max_salary_multiplier: editing.max_salary_multiplier ?? undefined,
        min_service_months: editing.min_service_months,
        max_concurrent_loan: editing.max_concurrent_loan,
        interest_rate: editing.interest_rate,
        interest_method: editing.interest_method ?? undefined,
        max_repayment_months: editing.max_repayment_months ?? undefined,
        max_installment_percentage: editing.max_installment_percentage ?? undefined,
        requires_guarantor: editing.requires_guarantor === 1,
        requires_collateral: editing.requires_collateral === 1,
        effective_from: editing.effective_from,
        effective_to: editing.effective_to ?? '',
        is_active: editing.is_active === 1,
      });
    } else {
      form.reset({
        loan_type: 'LOAN', min_service_months: 0, max_concurrent_loan: 1,
        interest_rate: 0, requires_guarantor: false, requires_collateral: false,
        is_active: true, effective_from: new Date().toISOString().slice(0, 10),
      });
    }
  }, [open, editing, form]);

  const onSubmit = async (vals: PolicyFormValues) => {
    setSaving(true);
    try {
      const payload = {
        ...vals,
        interest_method: (vals.interest_method ?? 'ZERO') as InterestMethod,
        requires_guarantor: vals.requires_guarantor ? 1 : 0,
        requires_collateral: vals.requires_collateral ? 1 : 0,
        is_active: vals.is_active ? 1 : 0,
        is_deleted: 0, is_current: 0,
        row_start: new Date().toISOString(),
        row_end: '9999-12-31 23:59:59+00',
      };
      if (editing) {
        await loanPolicyService.update(editing.loan_policy_id, payload);
        toast.success('Policy updated');
      } else {
        await loanPolicyService.create(payload as Parameters<typeof loanPolicyService.create>[0]);
        toast.success('Policy created');
      }
      onOpenChange(false);
      onSaved();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
        <DialogHeader><DialogTitle>{editing ? 'Edit Loan Policy' : 'New Loan Policy'}</DialogTitle></DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField control={form.control} name="policy_name" render={({ field }) => (
                <FormItem><FormLabel>Policy Name</FormLabel><FormControl><Input {...field} placeholder="e.g. Staff Personal Loan" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="policy_code" render={({ field }) => (
                <FormItem><FormLabel>Policy Code</FormLabel><FormControl><Input {...field} placeholder="e.g. SPL-001" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="loan_type" render={({ field }) => (
                <FormItem><FormLabel>Loan Type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{LOAN_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="interest_method" render={({ field }) => (
                <FormItem><FormLabel>Interest Method</FormLabel>
                  <Select value={field.value ?? 'ZERO'} onValueChange={field.onChange}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{INTEREST_METHODS.map(m => <SelectItem key={m} value={m}>{m.replace('_', ' ')}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="interest_rate" render={({ field }) => (
                <FormItem><FormLabel>Interest Rate (%)</FormLabel><FormControl><Input type="number" min={0} max={100} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="max_loan_amount" render={({ field }) => (
                <FormItem><FormLabel>Max Loan Amount</FormLabel><FormControl><Input type="number" min={0} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="max_salary_multiplier" render={({ field }) => (
                <FormItem><FormLabel>Max Salary Multiplier</FormLabel><FormControl><Input type="number" min={0} step="0.1" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="max_repayment_months" render={({ field }) => (
                <FormItem><FormLabel>Max Repayment Months</FormLabel><FormControl><Input type="number" min={1} step={1} {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="max_installment_percentage" render={({ field }) => (
                <FormItem><FormLabel>Max Installment % of Salary</FormLabel><FormControl><Input type="number" min={0} max={100} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="min_service_months" render={({ field }) => (
                <FormItem><FormLabel>Min Service Months</FormLabel><FormControl><Input type="number" min={0} step={1} {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="max_concurrent_loan" render={({ field }) => (
                <FormItem><FormLabel>Max Concurrent Loans</FormLabel><FormControl><Input type="number" min={1} step={1} {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="effective_from" render={({ field }) => (
                <FormItem><FormLabel>Effective From</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="effective_to" render={({ field }) => (
                <FormItem><FormLabel>Effective To <span className="text-xs text-muted-foreground">(optional)</span></FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            </div>
            <div className="flex flex-wrap gap-6">
              <FormField control={form.control} name="requires_guarantor" render={({ field }) => (
                <FormItem className="flex items-center gap-2"><FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl><FormLabel className="!mt-0">Requires Guarantor</FormLabel></FormItem>
              )} />
              <FormField control={form.control} name="requires_collateral" render={({ field }) => (
                <FormItem className="flex items-center gap-2"><FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl><FormLabel className="!mt-0">Requires Collateral</FormLabel></FormItem>
              )} />
              <FormField control={form.control} name="is_active" render={({ field }) => (
                <FormItem className="flex items-center gap-2"><FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl><FormLabel className="!mt-0">Active</FormLabel></FormItem>
              )} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ── Main page ───────────────────────────────────────────────────────────────────

export function LoanPolicyPage() {
  const [policies, setPolicies] = useState<LoanPolicy[]>([]);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<LoanPolicy | null>(null);
  const [deleting, setDeleting] = useState<LoanPolicy | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await loanPolicyService.list({ loan_type: typeFilter === 'all' ? undefined : typeFilter });
      setPolicies(data);
    } catch { toast.error('Failed to load loan policies'); }
    finally { setLoading(false); }
  }, [typeFilter]);

  useEffect(() => { load(); }, [load]);

  const confirmDelete = async () => {
    if (!deleting) return;
    try {
      await loanPolicyService.softDelete(deleting.loan_policy_id);
      toast.success('Policy deleted');
      setDeleting(null);
      load();
    } catch { toast.error('Delete failed'); }
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">Loan Policies</h1>
          <p className="text-sm text-muted-foreground text-pretty">Define eligibility rules, limits, and interest terms for loan programs</p>
        </div>
        <Button onClick={() => { setEditing(null); setDialogOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" /> New Policy
        </Button>
      </div>

      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-col md:flex-row gap-3">
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="md:w-48"><SelectValue placeholder="All Types" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {LOAN_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" onClick={load}><RefreshCw className="h-4 w-4" /></Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="p-4 pb-0">
          <p className="text-sm text-muted-foreground">{policies.length} {policies.length === 1 ? 'policy' : 'policies'}</p>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-3">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-10 bg-muted rounded animate-pulse" />)}</div>
          ) : policies.length === 0 ? (
            <div className="flex flex-col items-center py-14 text-muted-foreground">
              <ShieldCheck className="h-10 w-10 mb-3 opacity-30" />
              <p className="text-sm">No loan policies found</p>
              <Button variant="outline" size="sm" className="mt-4" onClick={() => { setEditing(null); setDialogOpen(true); }}>
                <Plus className="h-4 w-4 mr-2" /> Create First Policy
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Code</TableHead>
                    <TableHead className="whitespace-nowrap">Policy Name</TableHead>
                    <TableHead className="whitespace-nowrap">Type</TableHead>
                    <TableHead className="whitespace-nowrap">Interest</TableHead>
                    <TableHead className="whitespace-nowrap">Max Amount</TableHead>
                    <TableHead className="whitespace-nowrap">Max Months</TableHead>
                    <TableHead className="whitespace-nowrap">Min Service</TableHead>
                    <TableHead className="whitespace-nowrap">Guarantor</TableHead>
                    <TableHead className="whitespace-nowrap">Collateral</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {policies.map(p => (
                    <TableRow key={p.loan_policy_id}>
                      <TableCell className="whitespace-nowrap font-mono text-xs">{p.policy_code}</TableCell>
                      <TableCell className="whitespace-nowrap font-medium">{p.policy_name}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge variant={p.loan_type === 'LOAN' ? 'default' : 'secondary'} className="text-xs">{p.loan_type}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-xs">{p.interest_rate}% {p.interest_method ? `(${p.interest_method.replace('_', ' ')})` : ''}</TableCell>
                      <TableCell className="whitespace-nowrap text-xs">{fmt(p.max_loan_amount)}</TableCell>
                      <TableCell className="whitespace-nowrap text-xs">{p.max_repayment_months ?? '—'} mo</TableCell>
                      <TableCell className="whitespace-nowrap text-xs">{p.min_service_months} mo</TableCell>
                      <TableCell className="whitespace-nowrap"><Badge variant={p.requires_guarantor ? 'default' : 'secondary'} className="text-xs">{p.requires_guarantor ? 'Yes' : 'No'}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap"><Badge variant={p.requires_collateral ? 'default' : 'secondary'} className="text-xs">{p.requires_collateral ? 'Yes' : 'No'}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap"><Badge variant={p.is_active ? 'default' : 'secondary'} className="text-xs">{p.is_active ? 'Active' : 'Inactive'}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditing(p); setDialogOpen(true); }}><Pencil className="h-3.5 w-3.5" /></Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleting(p)}><Trash2 className="h-3.5 w-3.5" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <PolicyDialog open={dialogOpen} onOpenChange={setDialogOpen} editing={editing} onSaved={load} />

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Policy</AlertDialogTitle>
            <AlertDialogDescription>Delete loan policy <strong>{deleting?.policy_name}</strong>? This cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
