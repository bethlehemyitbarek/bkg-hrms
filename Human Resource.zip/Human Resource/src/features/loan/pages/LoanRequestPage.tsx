import { useState, useEffect, useCallback } from 'react';
import { Plus, Pencil, Trash2, Banknote, RefreshCw, ChevronDown, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { loanRequestService, loanRepaymentService } from '@/services/loan.service';
import type { LoanRequest, LoanStatus, LoanRepaymentSchedule, LoanType, InterestMethod, DisbursementMethod, RepaymentPaymentStatus } from '@/types/database.types';

// ── Repayment schedule calculator ──────────────────────────────────────────────
interface RepaymentRow {
  installment_number: number;
  due_date: string;
  principal_amount: number;
  interest_amount: number;
  total_installment: number;
}

function buildSchedule(
  principal: number,
  annualRate: number,
  months: number,
  method: InterestMethod,
  startDate: string,
): RepaymentRow[] {
  const rows: RepaymentRow[] = [];
  const base = new Date(startDate);

  if (method === 'ZERO' || annualRate === 0) {
    const pmt = Math.round((principal / months) * 100) / 100;
    for (let i = 1; i <= months; i++) {
      const due = new Date(base);
      due.setMonth(due.getMonth() + i);
      rows.push({
        installment_number: i,
        due_date: due.toISOString().slice(0, 10),
        principal_amount: i === months ? Math.round((principal - pmt * (months - 1)) * 100) / 100 : pmt,
        interest_amount: 0,
        total_installment: i === months ? Math.round((principal - pmt * (months - 1)) * 100) / 100 : pmt,
      });
    }
  } else if (method === 'FLAT_RATE') {
    const totalInterest = (principal * annualRate * months) / (100 * 12);
    const installment = Math.round(((principal + totalInterest) / months) * 100) / 100;
    const interestPerMonth = Math.round((totalInterest / months) * 100) / 100;
    const principalPerMonth = Math.round((installment - interestPerMonth) * 100) / 100;
    for (let i = 1; i <= months; i++) {
      const due = new Date(base);
      due.setMonth(due.getMonth() + i);
      rows.push({
        installment_number: i,
        due_date: due.toISOString().slice(0, 10),
        principal_amount: principalPerMonth,
        interest_amount: interestPerMonth,
        total_installment: installment,
      });
    }
  } else {
    // REDUCING_BALANCE — standard EMI
    const r = annualRate / (12 * 100);
    const emi = Math.round((principal * r * Math.pow(1 + r, months)) / (Math.pow(1 + r, months) - 1) * 100) / 100;
    let balance = principal;
    for (let i = 1; i <= months; i++) {
      const interest = Math.round(balance * r * 100) / 100;
      const principalPart = Math.round((emi - interest) * 100) / 100;
      const due = new Date(base);
      due.setMonth(due.getMonth() + i);
      rows.push({
        installment_number: i,
        due_date: due.toISOString().slice(0, 10),
        principal_amount: principalPart,
        interest_amount: interest,
        total_installment: emi,
      });
      balance = Math.round((balance - principalPart) * 100) / 100;
    }
  }
  return rows;
}
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';

const LOAN_STATUSES: LoanStatus[] = ['DRAFT', 'SUBMITTED', 'APPROVED', 'REJECTED', 'DISBURSED', 'REPAYING', 'SETTLED', 'CLOSED', 'DEFAULTED'];
const LOAN_TYPES: LoanType[] = ['LOAN', 'ADVANCE'];
const INTEREST_METHODS: InterestMethod[] = ['FLAT_RATE', 'REDUCING_BALANCE', 'ZERO'];
const DISBURSEMENT_METHODS: DisbursementMethod[] = ['BANK_TRANSFER', 'CASH', 'CHEQUE'];

const REPAY_STATUS_COLORS: Record<string, string> = {
  PENDING: 'bg-yellow-100 text-yellow-700',
  PAID: 'bg-green-100 text-green-700',
  OVERDUE: 'bg-red-100 text-red-700',
  WAIVED: 'bg-blue-100 text-blue-700',
  PARTIAL: 'bg-orange-100 text-orange-700',
};

const STATUS_COLORS: Record<LoanStatus, string> = {
  DRAFT: 'bg-muted text-muted-foreground',
  SUBMITTED: 'bg-blue-100 text-blue-700',
  APPROVED: 'bg-green-100 text-green-700',
  REJECTED: 'bg-red-100 text-red-700',
  DISBURSED: 'bg-cyan-100 text-cyan-700',
  REPAYING: 'bg-purple-100 text-purple-700',
  SETTLED: 'bg-emerald-100 text-emerald-700',
  CLOSED: 'bg-muted text-muted-foreground',
  DEFAULTED: 'bg-red-200 text-red-800',
};

const VALID_TRANSITIONS: Record<LoanStatus, LoanStatus[]> = {
  DRAFT: ['SUBMITTED', 'REJECTED'],
  SUBMITTED: ['APPROVED', 'REJECTED'],
  APPROVED: ['DISBURSED', 'REJECTED'],
  REJECTED: [],
  DISBURSED: ['REPAYING', 'SETTLED'],
  REPAYING: ['SETTLED', 'DEFAULTED', 'CLOSED'],
  SETTLED: ['CLOSED'],
  CLOSED: [],
  DEFAULTED: ['CLOSED'],
};

const fmt = (n?: number | null) => n != null ? Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '—';

// ── Request form ────────────────────────────────────────────────────────────────
const requestSchema = z.object({
  employee_id: z.string().min(1, 'Employee required'),
  request_type: z.enum(['LOAN', 'ADVANCE']),
  request_amount: z.coerce.number().min(1, 'Amount must be positive'),
  currency_code: z.string().length(3),
  request_date: z.string().min(1, 'Date required'),
  purpose: z.string().min(1, 'Purpose required').max(2000),
  interest_rate: z.coerce.number().min(0).max(100),
  interest_method: z.enum(['FLAT_RATE', 'REDUCING_BALANCE', 'ZERO']).optional(),
  repayment_period_months: z.coerce.number().min(1).optional(),
  disbursement_method: z.enum(['BANK_TRANSFER', 'CASH', 'CHEQUE']).optional(),
});
type RequestFormValues = z.infer<typeof requestSchema>;

interface RequestDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: LoanRequest | null;
  onSaved: () => void;
}

function RequestDialog({ open, onOpenChange, editing, onSaved }: RequestDialogProps) {
  const [saving, setSaving] = useState(false);
  const form = useForm<RequestFormValues>({
    resolver: zodResolver(requestSchema),
    defaultValues: {
      request_type: 'LOAN', currency_code: 'ETB', interest_rate: 0,
      request_date: new Date().toISOString().slice(0, 10),
      purpose: '', employee_id: '',
    },
  });

  useEffect(() => {
    if (!open) return;
    if (editing) {
      form.reset({
        employee_id: editing.employee_id,
        request_type: editing.request_type,
        request_amount: editing.request_amount,
        currency_code: editing.currency_code,
        request_date: editing.request_date,
        purpose: editing.purpose,
        interest_rate: editing.interest_rate,
        interest_method: editing.interest_method ?? undefined,
        repayment_period_months: editing.repayment_period_months ?? undefined,
        disbursement_method: editing.disbursement_method ?? undefined,
      });
    } else {
      form.reset({
        request_type: 'LOAN', currency_code: 'ETB', interest_rate: 0,
        request_date: new Date().toISOString().slice(0, 10),
        purpose: '', employee_id: '',
      });
    }
  }, [open, editing, form]);

  const onSubmit = async (vals: RequestFormValues) => {
    setSaving(true);
    try {
      const SYSTEM_USER = '00000000-0000-0000-0000-000000000001';
      const payload = {
        ...vals,
        created_by: SYSTEM_USER,
        loan_status: 'DRAFT' as LoanStatus,
        outstanding_balance: vals.request_amount,
        existing_loan_count: 0, is_active: 1, is_deleted: 0, is_current: 0,
        effective_from: new Date().toISOString(),
        effective_to: '9999-12-31 23:59:59+00',
        row_start: new Date().toISOString(),
        row_end: '9999-12-31 23:59:59+00',
      };
      if (editing) {
        await loanRequestService.update(editing.loan_request_id, vals);
        toast.success('Request updated');
      } else {
        await loanRequestService.create(payload as Parameters<typeof loanRequestService.create>[0]);
        toast.success('Loan request created');
      }
      onOpenChange(false);
      onSaved();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
        <DialogHeader><DialogTitle>{editing ? 'Edit Loan Request' : 'New Loan Request'}</DialogTitle></DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField control={form.control} name="employee_id" render={({ field }) => (
              <FormItem><FormLabel>Employee</FormLabel>
                <FormControl><EmployeeSelect value={field.value} onChange={field.onChange} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField control={form.control} name="request_type" render={({ field }) => (
                <FormItem><FormLabel>Request Type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{LOAN_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="request_date" render={({ field }) => (
                <FormItem><FormLabel>Request Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="request_amount" render={({ field }) => (
                <FormItem><FormLabel>Request Amount</FormLabel><FormControl><Input type="number" min={1} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="currency_code" render={({ field }) => (
                <FormItem><FormLabel>Currency</FormLabel><FormControl><Input {...field} maxLength={3} placeholder="ETB" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="interest_rate" render={({ field }) => (
                <FormItem><FormLabel>Interest Rate (%)</FormLabel><FormControl><Input type="number" min={0} max={100} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="interest_method" render={({ field }) => (
                <FormItem><FormLabel>Interest Method</FormLabel>
                  <Select value={field.value ?? 'ZERO'} onValueChange={field.onChange}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{INTEREST_METHODS.map(m => <SelectItem key={m} value={m}>{m.replace('_', ' ')}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="repayment_period_months" render={({ field }) => (
                <FormItem><FormLabel>Repayment Period (months)</FormLabel><FormControl><Input type="number" min={1} step={1} {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="disbursement_method" render={({ field }) => (
                <FormItem><FormLabel>Disbursement Method <span className="text-xs text-muted-foreground">(optional)</span></FormLabel>
                  <Select value={field.value ?? ''} onValueChange={field.onChange}><FormControl><SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger></FormControl>
                    <SelectContent>{DISBURSEMENT_METHODS.map(m => <SelectItem key={m} value={m}>{m.replace('_', ' ')}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
            </div>
            <FormField control={form.control} name="purpose" render={({ field }) => (
              <FormItem><FormLabel>Purpose</FormLabel>
                <FormControl><Textarea {...field} rows={3} placeholder="Describe the purpose of the loan…" /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Submit'}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ── Status transition dialog ────────────────────────────────────────────────────
interface LoanStatusDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  request: LoanRequest | null;
  onSaved: () => void;
}

function LoanStatusDialog({ open, onOpenChange, request, onSaved }: LoanStatusDialogProps) {
  const [saving, setSaving] = useState(false);
  const [nextStatus, setNextStatus] = useState<LoanStatus | ''>('');
  const [disbursementDate, setDisbursementDate] = useState('');
  const [disbursementRef, setDisbursementRef] = useState('');
  const [disbursedAmount, setDisbursedAmount] = useState('');

  useEffect(() => {
    if (open) { setNextStatus(''); setDisbursementDate(''); setDisbursementRef(''); setDisbursedAmount(''); }
  }, [open]);

  if (!request) return null;
  const available = VALID_TRANSITIONS[request.loan_status] ?? [];

  const apply = async () => {
    if (!nextStatus) return;
    setSaving(true);
    try {
      const extra: Partial<LoanRequest> = {};
      if (nextStatus === 'DISBURSED') {
        if (disbursementDate) extra.disbursement_date = disbursementDate;
        if (disbursementRef) extra.disbursement_reference = disbursementRef;
        if (disbursedAmount) extra.disbursement_amount = Number(disbursedAmount);
      }
      await loanRequestService.updateStatus(request.loan_request_id, nextStatus, extra);

      // Auto-generate repayment schedule when moving to DISBURSED
      if (nextStatus === 'DISBURSED') {
        const startDate = disbursementDate || new Date().toISOString().slice(0, 10);
        const principal = Number(disbursedAmount) || request.request_amount;
        const rows = buildSchedule(
          principal,
          request.interest_rate ?? 0,
          request.repayment_period_months ?? 12,
          request.interest_method ?? 'FLAT_RATE',
          startDate,
        );
        const scheduleRows = rows.map(r => ({
          loan_request_id: request.loan_request_id,
          tenant_id: request.tenant_id,
          installment_number: r.installment_number,
          due_date: r.due_date,
          principal_amount: r.principal_amount,
          interest_amount: r.interest_amount,
          total_installment: r.total_installment,
          payment_status: 'PENDING' as RepaymentPaymentStatus,
          paid_amount: 0,
        }));
        await loanRepaymentService.bulkCreate(scheduleRows as unknown as LoanRepaymentSchedule[]);
        toast.success(`Repayment schedule generated: ${rows.length} installments`);
      } else {
        toast.success(`Loan status updated to ${nextStatus}`);
      }

      onOpenChange(false);
      onSaved();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Update failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md max-h-[90dvh] overflow-y-auto">
        <DialogHeader><DialogTitle>Update Loan Status</DialogTitle></DialogHeader>
        <div className="space-y-4 py-2">
          <p className="text-sm text-muted-foreground">Current: <strong>{request.loan_status}</strong></p>
          {available.length === 0 ? (
            <p className="text-sm text-muted-foreground italic">No transitions available.</p>
          ) : (
            <>
              <div className="space-y-1.5">
                <label className="text-sm font-normal">New Status</label>
                <Select value={nextStatus} onValueChange={v => setNextStatus(v as LoanStatus)}>
                  <SelectTrigger><SelectValue placeholder="Select next status…" /></SelectTrigger>
                  <SelectContent>{available.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              {nextStatus === 'DISBURSED' && (
                <>
                  <div className="space-y-1.5">
                    <label className="text-sm font-normal">Disbursement Date</label>
                    <Input type="date" value={disbursementDate} onChange={e => setDisbursementDate(e.target.value)} />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-sm font-normal">Disbursed Amount</label>
                    <Input type="number" step="0.01" value={disbursedAmount} onChange={e => setDisbursedAmount(e.target.value)} />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-sm font-normal">Reference</label>
                    <Input value={disbursementRef} onChange={e => setDisbursementRef(e.target.value)} placeholder="Payment reference…" />
                  </div>
                </>
              )}
            </>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button disabled={!nextStatus || saving} onClick={apply}>{saving ? 'Updating…' : 'Apply'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Repayment schedule sub-panel ────────────────────────────────────────────────
interface RepaymentPanelProps { loanRequestId: string; }

function RepaymentPanel({ loanRequestId }: RepaymentPanelProps) {
  const [schedules, setSchedules] = useState<LoanRepaymentSchedule[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    loanRepaymentService.listByLoan(loanRequestId)
      .then(d => { if (mounted) setSchedules(d); })
      .catch(() => toast.error('Failed to load repayment schedule'))
      .finally(() => { if (mounted) setLoading(false); });
    return () => { mounted = false; };
  }, [loanRequestId]);

  if (loading) return <div className="h-8 bg-muted rounded animate-pulse mt-3" />;
  if (schedules.length === 0) return <p className="text-xs text-muted-foreground mt-3 italic">No repayment schedule generated yet.</p>;

  return (
    <div className="mt-3 overflow-x-auto">
      <p className="text-xs font-medium text-muted-foreground mb-2">Repayment Schedule</p>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="whitespace-nowrap text-xs">#</TableHead>
            <TableHead className="whitespace-nowrap text-xs">Due Date</TableHead>
            <TableHead className="whitespace-nowrap text-xs text-right">Principal</TableHead>
            <TableHead className="whitespace-nowrap text-xs text-right">Interest</TableHead>
            <TableHead className="whitespace-nowrap text-xs text-right">Total</TableHead>
            <TableHead className="whitespace-nowrap text-xs text-right">Paid</TableHead>
            <TableHead className="whitespace-nowrap text-xs">Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {schedules.map(s => (
            <TableRow key={s.schedule_id}>
              <TableCell className="whitespace-nowrap text-xs">{s.installment_number}</TableCell>
              <TableCell className="whitespace-nowrap text-xs">{s.due_date}</TableCell>
              <TableCell className="whitespace-nowrap text-xs text-right">{fmt(s.principal_amount)}</TableCell>
              <TableCell className="whitespace-nowrap text-xs text-right">{fmt(s.interest_amount)}</TableCell>
              <TableCell className="whitespace-nowrap text-xs text-right font-medium">{fmt(s.total_installment)}</TableCell>
              <TableCell className="whitespace-nowrap text-xs text-right">{fmt(s.paid_amount)}</TableCell>
              <TableCell className="whitespace-nowrap">
                <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${REPAY_STATUS_COLORS[s.payment_status] ?? ''}`}>{s.payment_status}</span>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

// ── Main page ───────────────────────────────────────────────────────────────────
export function LoanRequestPage() {
  const [requests, setRequests] = useState<LoanRequest[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 20;

  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<LoanRequest | null>(null);
  const [statusTarget, setStatusTarget] = useState<LoanRequest | null>(null);
  const [deleting, setDeleting] = useState<LoanRequest | null>(null);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const result = await loanRequestService.list({
        loan_status: statusFilter === 'all' ? undefined : statusFilter,
        request_type: typeFilter === 'all' ? undefined : typeFilter,
        page, pageSize: PAGE_SIZE,
      });
      setRequests(result.data);
      setTotal(result.total);
    } catch { toast.error('Failed to load loan requests'); }
    finally { setLoading(false); }
  }, [statusFilter, typeFilter, page]);

  useEffect(() => { load(); }, [load]);

  const confirmDelete = async () => {
    if (!deleting) return;
    try {
      await loanRequestService.softDelete(deleting.loan_request_id);
      toast.success('Request deleted');
      setDeleting(null);
      load();
    } catch { toast.error('Delete failed'); }
  };

  const toggleExpand = (id: string) => {
    setExpanded(prev => { const s = new Set(prev); s.has(id) ? s.delete(id) : s.add(id); return s; });
  };

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">Loan Requests</h1>
          <p className="text-sm text-muted-foreground text-pretty">Manage employee loan and salary advance requests through the approval lifecycle</p>
        </div>
        <Button onClick={() => { setEditing(null); setDialogOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" /> New Request
        </Button>
      </div>

      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-wrap gap-3">
            <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setPage(1); }}>
              <SelectTrigger className="w-44"><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {LOAN_STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={v => { setTypeFilter(v); setPage(1); }}>
              <SelectTrigger className="w-36"><SelectValue placeholder="All Types" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {LOAN_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" onClick={load}><RefreshCw className="h-4 w-4" /></Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {loading ? (
          Array.from({ length: 5 }).map((_, i) => <Card key={i}><CardContent className="p-4"><div className="h-10 bg-muted rounded animate-pulse" /></CardContent></Card>)
        ) : requests.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center py-14 text-muted-foreground">
              <Banknote className="h-10 w-10 mb-3 opacity-30" />
              <p className="text-sm">No loan requests found</p>
              <Button variant="outline" size="sm" className="mt-4" onClick={() => { setEditing(null); setDialogOpen(true); }}>
                <Plus className="h-4 w-4 mr-2" /> Create First Request
              </Button>
            </CardContent>
          </Card>
        ) : requests.map(r => (
          <Card key={r.loan_request_id} className="h-full">
            <CardHeader className="p-4">
              <div className="flex items-start justify-between gap-2">
                <button className="flex items-center gap-2 flex-1 min-w-0 text-left" onClick={() => toggleExpand(r.loan_request_id)}>
                  {expanded.has(r.loan_request_id) ? <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-sm truncate">#{r.loan_request_id.slice(0, 8)}</span>
                      <Badge variant={r.request_type === 'LOAN' ? 'default' : 'secondary'} className="text-xs">{r.request_type}</Badge>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLORS[r.loan_status]}`}>{r.loan_status}</span>
                    </div>
                    <div className="flex items-center gap-3 mt-1 flex-wrap text-xs text-muted-foreground">
                      <span>EMP: {r.employee_id.slice(0, 8)}…</span>
                      <span className="font-medium text-foreground">{r.currency_code} {fmt(r.request_amount)}</span>
                      <span>Date: {r.request_date}</span>
                      <span>Outstanding: {fmt(r.outstanding_balance)}</span>
                    </div>
                  </div>
                </button>
                <div className="flex gap-1 shrink-0">
                  <Button variant="ghost" size="sm" className="h-8 text-xs px-2" onClick={() => setStatusTarget(r)}>Status</Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditing(r); setDialogOpen(true); }}><Pencil className="h-3.5 w-3.5" /></Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleting(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
            </CardHeader>
            {expanded.has(r.loan_request_id) && (
              <CardContent className="pt-0 pb-4 px-4 border-t">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 text-xs">
                  <div><p className="text-muted-foreground">Interest Rate</p><p>{r.interest_rate}% {r.interest_method ? `(${r.interest_method.replace('_', ' ')})` : ''}</p></div>
                  <div><p className="text-muted-foreground">Repayment Months</p><p>{r.repayment_period_months ?? '—'}</p></div>
                  <div><p className="text-muted-foreground">Monthly Installment</p><p>{fmt(r.monthly_installment)}</p></div>
                  <div><p className="text-muted-foreground">Disbursement</p><p>{r.disbursement_date ?? '—'} {r.disbursement_method ? `(${r.disbursement_method.replace('_', ' ')})` : ''}</p></div>
                  {r.purpose && <div className="col-span-2 md:col-span-4"><p className="text-muted-foreground">Purpose</p><p className="text-pretty">{r.purpose}</p></div>}
                  {r.ineligibility_reason && <div className="col-span-2 md:col-span-4"><p className="text-muted-foreground text-destructive">Ineligibility Reason</p><p className="text-destructive">{r.ineligibility_reason}</p></div>}
                </div>
                <RepaymentPanel loanRequestId={r.loan_request_id} />
              </CardContent>
            )}
          </Card>
        ))}
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 pt-2">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
          <span className="text-sm text-muted-foreground">Page {page} of {totalPages}</span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
        </div>
      )}

      <RequestDialog open={dialogOpen} onOpenChange={setDialogOpen} editing={editing} onSaved={load} />
      <LoanStatusDialog open={!!statusTarget} onOpenChange={o => !o && setStatusTarget(null)} request={statusTarget} onSaved={load} />

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader><AlertDialogTitle>Delete Loan Request</AlertDialogTitle>
            <AlertDialogDescription>Delete loan request <strong>{deleting?.loan_request_id.slice(0, 8)}</strong>? This cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
