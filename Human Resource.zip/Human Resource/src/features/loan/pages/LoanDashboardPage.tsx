import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, Legend,
} from 'recharts';
import {
  Banknote, AlertCircle, Calendar, TrendingDown, ChevronRight,
  RefreshCw, ChevronDown, ChevronUp, Bell, BellRing,
} from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';
import { ROUTES } from '@/app/routes';
import type { LoanType } from '@/types/database.types';

const TENANT_ID = '00000000-0000-0000-0000-000000000001';

const STATUS_COLORS: Record<string, string> = {
  DISBURSED: '#3b82f6',
  REPAYING:  '#10b981',
  APPROVED:  '#f59e0b',
  DEFAULTED: '#dc2626',
  SETTLED:   '#6b7280',
  CLOSED:    '#a1a1aa',
};

const STATUS_BADGE: Record<string, string> = {
  DISBURSED: 'bg-blue-100 text-blue-700',
  REPAYING:  'bg-emerald-100 text-emerald-700',
  APPROVED:  'bg-amber-100 text-amber-700',
  DEFAULTED: 'bg-red-100 text-red-700',
  SETTLED:   'bg-muted text-muted-foreground',
  CLOSED:    'bg-muted text-muted-foreground',
};

interface OverdueInstallment {
  schedule_id: string;
  loan_request_id: string;
  employee_name: string;
  employee_code: string;
  due_date: string;
  days_overdue: number;
  total_installment: number;
  reminder_sent: boolean;
}

interface ActiveLoan {  loan_request_id: string;
  employee_name: string;
  employee_code: string;
  loan_type: LoanType;
  loan_amount: number;
  outstanding: number;
  next_due_date: string | null;
  next_installment: number | null;
  loan_status: string;
}

interface StatusSummary { status: string; total: number; count: number; }

function fmtMoney(v: number) {
  return `ብር ${Number(v||0).toLocaleString('en-US',{maximumFractionDigits:0})}`;
}

function fmtDate(d: string | null) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function LoanDashboardPage() {
  const navigate = useNavigate();
  const [typeFilter, setTypeFilter] = useState<'ALL' | LoanType>('ALL');
  const [loading, setLoading] = useState(true);

  // KPI state
  const [activeCount, setActiveCount] = useState(0);
  const [totalOutstanding, setTotalOutstanding] = useState(0);
  const [overdueCount, setOverdueCount] = useState(0);
  const [monthlyForecast, setMonthlyForecast] = useState(0);

  // Table state
  const [activeLoans, setActiveLoans] = useState<ActiveLoan[]>([]);

  // Chart state
  const [chartData, setChartData] = useState<StatusSummary[]>([]);

  // Overdue panel state
  const [overdueItems, setOverdueItems] = useState<OverdueInstallment[]>([]);
  const [overdueExpanded, setOverdueExpanded] = useState(false);
  const [selectedOverdue, setSelectedOverdue] = useState<Set<string>>(new Set());
  const [sendingReminder, setSendingReminder] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const today = new Date().toISOString().slice(0, 10);
      const monthStart = today.slice(0, 7) + '-01';
      const nextMonth  = new Date(new Date(monthStart).setMonth(new Date(monthStart).getMonth() + 1))
        .toISOString().slice(0, 10);

      // ── Fetch all active loans ────────────────────────────────────────────────
      let q = supabase
        .from('loan_requests')
        .select(`
          loan_request_id,
          loan_type,
          loan_amount,
          loan_status,
          interest_rate,
          interest_method,
          repayment_months,
          disbursement_amount,
          employee_id,
          employees!loan_requests_employee_id_fkey(first_name, last_name, employee_code)
        `)
        .eq('tenant_id', TENANT_ID)
        .is('deleted_at', null)
        .in('loan_status', ['APPROVED', 'DISBURSED', 'REPAYING', 'DEFAULTED']);

      if (typeFilter !== 'ALL') q = q.eq('loan_type', typeFilter);
      const { data: loans } = await q;
      if (!loans) { setLoading(false); return; }

      // ── Fetch repayment schedules for these loan IDs ──────────────────────────
      const ids = loans.map(l => l.loan_request_id);
      const { data: schedules } = ids.length
        ? await supabase
            .from('loan_repayment_schedules')
            .select('loan_request_id, due_date, total_installment, paid_amount, payment_status')
            .in('loan_request_id', ids)
            .is('deleted_at', null)
        : { data: [] };

      const sched = schedules ?? [];

      // ── Compute KPIs ─────────────────────────────────────────────────────────
      let outstanding = 0;
      let overdue = 0;
      let forecast = 0;

      // Outstanding per loan = sum of unpaid installments
      const outstandingMap: Record<string, number> = {};
      const nextDueMap:     Record<string, { date: string; amount: number }> = {};

      for (const s of sched) {
        if (s.payment_status !== 'PAID') {
          const remaining = (s.total_installment ?? 0) - (s.paid_amount ?? 0);
          outstandingMap[s.loan_request_id] = (outstandingMap[s.loan_request_id] ?? 0) + remaining;
          outstanding += remaining;
          // Overdue
          if (s.due_date < today && s.payment_status !== 'PAID') overdue++;
          // Monthly forecast
          if (s.due_date >= monthStart && s.due_date < nextMonth) forecast += s.total_installment ?? 0;
          // Next due
          if (!nextDueMap[s.loan_request_id] || s.due_date < nextDueMap[s.loan_request_id].date) {
            nextDueMap[s.loan_request_id] = { date: s.due_date, amount: s.total_installment ?? 0 };
          }
        }
      }

      setActiveCount(loans.length);
      setTotalOutstanding(outstanding);
      setOverdueCount(overdue);
      setMonthlyForecast(forecast);

      // ── Build active loans table ──────────────────────────────────────────────
      const rows: ActiveLoan[] = loans.map(l => {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const emp = (l.employees as any)?.[0] ?? l.employees;
        return {
          loan_request_id: l.loan_request_id,
          employee_name: emp ? `${emp.first_name ?? ''} ${emp.last_name ?? ''}`.trim() : '—',
          employee_code: emp?.employee_code ?? '—',
          loan_type:     l.loan_type as LoanType,
          loan_amount:   l.loan_amount ?? 0,
          outstanding:   outstandingMap[l.loan_request_id] ?? (l.disbursement_amount ?? l.loan_amount ?? 0),
          next_due_date: nextDueMap[l.loan_request_id]?.date ?? null,
          next_installment: nextDueMap[l.loan_request_id]?.amount ?? null,
          loan_status:   l.loan_status,
        };
      });
      setActiveLoans(rows);

      // ── Build chart data: outstanding balance by status ───────────────────────
      const byStatus: Record<string, { total: number; count: number }> = {};
      for (const loan of loans) {
        const s = loan.loan_status;
        if (!byStatus[s]) byStatus[s] = { total: 0, count: 0 };
        byStatus[s].total += outstandingMap[loan.loan_request_id] ?? 0;
        byStatus[s].count += 1;
      }
      setChartData(
        Object.entries(byStatus).map(([status, v]) => ({ status, total: v.total, count: v.count })),
      );

      // ── Fetch overdue installments ────────────────────────────────────────────
      const { data: overdueRaw } = await supabase
        .from('loan_repayment_schedules')
        .select(`
          schedule_id,
          loan_request_id,
          due_date,
          total_installment,
          reminder_sent,
          loan_requests!loan_repayment_schedules_loan_request_id_fkey(
            employee_id,
            employees!loan_requests_employee_id_fkey(first_name, last_name, employee_code)
          )
        `)
        .eq('payment_status', 'PENDING')
        .is('deleted_at', null)
        .lt('due_date', today)
        .order('due_date', { ascending: true })
        .limit(100);

      if (overdueRaw) {
        const parsed: OverdueInstallment[] = overdueRaw.map((r) => {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const lr = (r as any).loan_requests;
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const emp = lr?.employees as any;
          const empName = emp ? `${emp.first_name ?? ''} ${emp.last_name ?? ''}`.trim() : '—';
          const empCode = emp?.employee_code ?? '—';
          const daysOverdue = Math.floor(
            (new Date(today).getTime() - new Date(r.due_date).getTime()) / 86_400_000,
          );
          return {
            schedule_id: r.schedule_id,
            loan_request_id: r.loan_request_id,
            employee_name: empName,
            employee_code: empCode,
            due_date: r.due_date,
            days_overdue: daysOverdue,
            total_installment: r.total_installment ?? 0,
            reminder_sent: r.reminder_sent ?? false,
          };
        });
        setOverdueItems(parsed);
      }
    } catch (_) {
      // silent — skeleton stays
    } finally {
      setLoading(false);
    }
  }, [typeFilter]);

  useEffect(() => { load(); }, [load]);

  // ── Reminder logic ───────────────────────────────────────────────────────────
  const sendReminder = async (ids: string[]) => {
    if (ids.length === 0) return;
    setSendingReminder(true);
    try {
      const now = new Date().toISOString();
      await supabase
        .from('loan_repayment_schedules')
        .update({ reminder_sent: true, reminder_sent_at: now, updated_at: now })
        .in('schedule_id', ids);

      setOverdueItems(prev =>
        prev.map(item => ids.includes(item.schedule_id) ? { ...item, reminder_sent: true } : item),
      );
      setSelectedOverdue(new Set());
      toast.success(`Reminder sent for ${ids.length} installment${ids.length !== 1 ? 's' : ''}`);
    } catch {
      toast.error('Failed to send reminders');
    } finally {
      setSendingReminder(false);
    }
  };

  const toggleSelectOverdue = (id: string) => {
    setSelectedOverdue(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    setSelectedOverdue(prev =>
      prev.size === overdueItems.length ? new Set() : new Set(overdueItems.map(o => o.schedule_id)),
    );
  };

  // ── KPI card ─────────────────────────────────────────────────────────────────
  function KpiCard({ icon: Icon, label, value, sub, color }: {
    icon: React.ElementType; label: string; value: string; sub?: string; color: string;
  }) {
    return (
      <Card className="h-full">
        <CardContent className="pt-5 pb-4">
          <div className="flex items-start gap-3">
            <div className={`rounded-lg p-2.5 shrink-0 ${color}`}>
              <Icon className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground font-medium">{label}</p>
              <p className="text-xl font-bold text-foreground mt-0.5 truncate">{value}</p>
              {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground text-balance">Loan Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Overview of active loans, outstanding balances and upcoming repayments</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Select value={typeFilter} onValueChange={v => setTypeFilter(v as 'ALL' | LoanType)}>
            <SelectTrigger className="w-36 h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All Types</SelectItem>
              <SelectItem value="LOAN">Loan</SelectItem>
              <SelectItem value="ADVANCE">Advance</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={load} className="h-9 gap-1.5">
            <RefreshCw className="h-3.5 w-3.5" />Refresh
          </Button>
          <Button size="sm" className="h-9 gap-1.5" onClick={() => navigate(ROUTES.LOANS_REQUESTS)}>
            Manage Requests <ChevronRight className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}><CardContent className="pt-5 pb-4"><Skeleton className="h-16 w-full bg-muted" /></CardContent></Card>
          ))
        ) : (
          <>
            <KpiCard
              icon={Banknote}
              label="Active Loans"
              value={String(activeCount)}
              sub={typeFilter !== 'ALL' ? typeFilter : 'All types'}
              color="bg-blue-100 text-blue-700"
            />
            <KpiCard
              icon={TrendingDown}
              label="Total Outstanding"
              value={fmtMoney(totalOutstanding)}
              sub="Remaining principal + interest"
              color="bg-emerald-100 text-emerald-700"
            />
            <KpiCard
              icon={AlertCircle}
              label="Overdue Installments"
              value={String(overdueCount)}
              sub="Past due date, unpaid"
              color={overdueCount > 0 ? 'bg-red-100 text-red-700' : 'bg-muted text-muted-foreground'}
            />
            <KpiCard
              icon={Calendar}
              label="Monthly Forecast"
              value={fmtMoney(monthlyForecast)}
              sub="Deductions due this month"
              color="bg-amber-100 text-amber-700"
            />
          </>
        )}
      </div>

      {/* Overdue Installments Alert Panel */}
      {!loading && overdueItems.length > 0 && (
        <div className="rounded-lg border border-red-200 bg-red-50/60">
          {/* Panel header / toggle */}
          <button
            type="button"
            onClick={() => setOverdueExpanded(v => !v)}
            className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-red-100/50 transition-colors rounded-lg"
          >
            <div className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-red-600 shrink-0" />
              <span className="font-semibold text-red-700 text-sm">Overdue Installments</span>
              <Badge className="bg-red-600 text-white text-xs px-2 py-0.5">
                {overdueItems.length}
              </Badge>
              <span className="text-xs text-red-500 hidden md:inline">
                — {overdueItems.length} payment{overdueItems.length !== 1 ? 's' : ''} past due
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {overdueExpanded && selectedOverdue.size > 0 && (
                <Button
                  size="sm"
                  variant="default"
                  className="h-7 text-xs gap-1 bg-red-600 hover:bg-red-700"
                  onClick={e => { e.stopPropagation(); sendReminder(Array.from(selectedOverdue)); }}
                  disabled={sendingReminder}
                >
                  <BellRing className="h-3 w-3" />
                  Send Reminder ({selectedOverdue.size})
                </Button>
              )}
              {overdueExpanded
                ? <ChevronUp className="h-4 w-4 text-red-500" />
                : <ChevronDown className="h-4 w-4 text-red-500" />
              }
            </div>
          </button>

          {/* Expandable body */}
          {overdueExpanded && (
            <div className="border-t border-red-200">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-red-100/50">
                      <th className="px-3 py-2 text-left w-8">
                        <Checkbox
                          checked={selectedOverdue.size === overdueItems.length && overdueItems.length > 0}
                          onCheckedChange={toggleSelectAll}
                          aria-label="Select all"
                        />
                      </th>
                      <th className="px-3 py-2 text-left font-medium text-red-700 whitespace-nowrap text-xs">Employee</th>
                      <th className="px-3 py-2 text-left font-medium text-red-700 whitespace-nowrap text-xs">Due Date</th>
                      <th className="px-3 py-2 text-center font-medium text-red-700 whitespace-nowrap text-xs">Days Overdue</th>
                      <th className="px-3 py-2 text-right font-medium text-red-700 whitespace-nowrap text-xs">Amount</th>
                      <th className="px-3 py-2 text-center font-medium text-red-700 whitespace-nowrap text-xs">Reminder</th>
                      <th className="px-3 py-2 text-center font-medium text-red-700 whitespace-nowrap text-xs">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {overdueItems.map(item => (
                      <tr
                        key={item.schedule_id}
                        className="border-t border-red-100 hover:bg-red-50 transition-colors"
                      >
                        <td className="px-3 py-2.5">
                          <Checkbox
                            checked={selectedOverdue.has(item.schedule_id)}
                            onCheckedChange={() => toggleSelectOverdue(item.schedule_id)}
                            aria-label="Select row"
                          />
                        </td>
                        <td className="px-3 py-2.5 whitespace-nowrap">
                          <div className="font-medium text-foreground text-xs">{item.employee_name}</div>
                          <div className="text-xs text-muted-foreground">{item.employee_code}</div>
                        </td>
                        <td className="px-3 py-2.5 whitespace-nowrap text-xs text-muted-foreground">
                          {fmtDate(item.due_date)}
                        </td>
                        <td className="px-3 py-2.5 whitespace-nowrap text-center">
                          <Badge className={`text-xs ${item.days_overdue > 30 ? 'bg-red-600 text-white' : 'bg-orange-100 text-orange-700'}`}>
                            {item.days_overdue}d
                          </Badge>
                        </td>
                        <td className="px-3 py-2.5 whitespace-nowrap text-right text-xs font-medium text-foreground">
                          {fmtMoney(item.total_installment)}
                        </td>
                        <td className="px-3 py-2.5 whitespace-nowrap text-center">
                          {item.reminder_sent
                            ? <Badge className="bg-muted text-muted-foreground text-xs"><Bell className="h-3 w-3 mr-1 inline" />Sent</Badge>
                            : <span className="text-xs text-muted-foreground">—</span>
                          }
                        </td>
                        <td className="px-3 py-2.5 whitespace-nowrap text-center">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 text-xs gap-1 border-red-300 text-red-600 hover:bg-red-50"
                            onClick={() => sendReminder([item.schedule_id])}
                            disabled={sendingReminder}
                          >
                            <BellRing className="h-3 w-3" />Remind
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Chart + Table row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

        {/* Outstanding by Status chart */}
        <Card className="h-full">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Outstanding Balance by Status</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-52 w-full bg-muted" />
            ) : chartData.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">No data</p>
            ) : (
              <ResponsiveContainer width="100%" height={210}>
                <BarChart data={chartData} margin={{ top: 4, right: 8, left: 0, bottom: 4 }}>
                  <XAxis dataKey="status" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} tickFormatter={v => `${(v / 1000).toFixed(0)}k`} />
                  <Tooltip
                    formatter={(value: number) => [fmtMoney(value), 'Outstanding']}
                    labelFormatter={l => `Status: ${l}`}
                  />
                  <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8, fontSize: 11 }} />
                  <Bar dataKey="total" name="Outstanding (ETB)" radius={[3, 3, 0, 0]}>
                    {chartData.map(entry => (
                      <Cell key={entry.status} fill={STATUS_COLORS[entry.status] ?? '#94a3b8'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Active Loans Table */}
        <Card className="md:col-span-2 h-full">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Active &amp; Repaying Loans</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                    <th className="text-left px-4 py-2.5 font-medium text-muted-foreground whitespace-nowrap">Employee</th>
                    <th className="text-right px-4 py-2.5 font-medium text-muted-foreground whitespace-nowrap">Amount</th>
                    <th className="text-right px-4 py-2.5 font-medium text-muted-foreground whitespace-nowrap">Outstanding</th>
                    <th className="text-left px-4 py-2.5 font-medium text-muted-foreground whitespace-nowrap">Next Due</th>
                    <th className="text-right px-4 py-2.5 font-medium text-muted-foreground whitespace-nowrap">Installment</th>
                    <th className="text-left px-4 py-2.5 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <tr key={i} className="border-b border-border">
                        {Array.from({ length: 6 }).map((__, j) => (
                          <td key={j} className="px-4 py-2.5"><Skeleton className="h-4 w-full bg-muted" /></td>
                        ))}
                      </tr>
                    ))
                  ) : activeLoans.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-10 text-muted-foreground text-sm">
                        No active loans found
                      </td>
                    </tr>
                  ) : (
                    activeLoans.map(loan => (
                      <tr
                        key={loan.loan_request_id}
                        className="border-b border-border hover:bg-muted/30 transition-colors cursor-pointer"
                        onClick={() => navigate(ROUTES.LOANS_REQUESTS)}
                      >
                        <td className="px-4 py-2.5 whitespace-nowrap">
                          <div className="font-medium text-foreground">{loan.employee_name}</div>
                          <div className="text-xs text-muted-foreground">{loan.employee_code}</div>
                        </td>
                        <td className="px-4 py-2.5 text-right whitespace-nowrap font-medium">
                          {fmtMoney(loan.loan_amount)}
                        </td>
                        <td className="px-4 py-2.5 text-right whitespace-nowrap text-foreground font-semibold">
                          {fmtMoney(loan.outstanding)}
                        </td>
                        <td className="px-4 py-2.5 whitespace-nowrap text-muted-foreground">
                          {fmtDate(loan.next_due_date)}
                        </td>
                        <td className="px-4 py-2.5 text-right whitespace-nowrap">
                          {loan.next_installment != null ? fmtMoney(loan.next_installment) : '—'}
                        </td>
                        <td className="px-4 py-2.5 whitespace-nowrap">
                          <Badge className={`text-xs ${STATUS_BADGE[loan.loan_status] ?? 'bg-muted text-muted-foreground'}`}>
                            {loan.loan_status}
                          </Badge>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
