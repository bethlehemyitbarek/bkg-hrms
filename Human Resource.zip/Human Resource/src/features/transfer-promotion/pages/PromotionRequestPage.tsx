import { useState, useEffect, useCallback } from 'react';
import { Plus, Pencil, Trash2, TrendingUp, RefreshCw, ChevronDown, ChevronRight, CheckCircle, XCircle, PlayCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { promotionRequestService } from '@/services/transfer.service';
import { supabase } from '@/db/supabase';
import type { PromotionRequest, PromotionStatus } from '@/types/database.types';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';

const PROMOTION_STATUSES: PromotionStatus[] = ['DRAFT', 'SUBMITTED', 'DEPT_APPROVED', 'DEPT_REJECTED', 'APPROVED', 'REJECTED', 'EXECUTED', 'CANCELLED'];

const STATUS_COLORS: Record<PromotionStatus, string> = {
  DRAFT:         'bg-muted text-muted-foreground',
  SUBMITTED:     'bg-blue-100 text-blue-700',
  DEPT_APPROVED: 'bg-cyan-100 text-cyan-700',
  DEPT_REJECTED: 'bg-orange-100 text-orange-700',
  APPROVED:      'bg-green-100 text-green-700',
  REJECTED:      'bg-red-100 text-red-700',
  EXECUTED:      'bg-emerald-100 text-emerald-700',
  CANCELLED:     'bg-slate-100 text-slate-500',
};

const VALID_TRANSITIONS: Record<PromotionStatus, PromotionStatus[]> = {
  DRAFT:         ['SUBMITTED', 'CANCELLED'],
  SUBMITTED:     ['DEPT_APPROVED', 'DEPT_REJECTED', 'CANCELLED'],
  DEPT_APPROVED: ['APPROVED', 'REJECTED', 'CANCELLED'],
  DEPT_REJECTED: [],
  APPROVED:      ['EXECUTED', 'CANCELLED'],
  REJECTED:      [],
  EXECUTED:      [],
  CANCELLED:     [],
};

const fmt = (n?: number | null) =>
  n != null ? Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '—';

// ── Form schema ─────────────────────────────────────────────────────────────────
const promotionSchema = z.object({
  employee_id: z.string().min(1, 'Employee required'),
  proposed_position_id: z.string().min(1, 'Proposed position required'),
  current_position_id: z.string().optional(),
  snapshot_current_grade: z.string().optional(),
  current_salary: z.coerce.number().min(0).optional(),
  snapshot_proposed_grade: z.string().optional(),
  proposed_salary: z.coerce.number().min(0).optional(),
  justification: z.string().optional(),
  promotion_date: z.string().optional(),
});
type PromotionFormValues = z.infer<typeof promotionSchema>;

interface PromotionDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: PromotionRequest | null;
  onSaved: () => void;
}

function PromotionDialog({ open, onOpenChange, editing, onSaved }: PromotionDialogProps) {
  const [saving, setSaving] = useState(false);
  const form = useForm<PromotionFormValues>({
    resolver: zodResolver(promotionSchema),
    defaultValues: { employee_id: '', proposed_position_id: '' },
  });

  useEffect(() => {
    if (!open) return;
    if (editing) {
      form.reset({
        employee_id: editing.employee_id,
        proposed_position_id: editing.proposed_position_id,
        current_position_id: editing.current_position_id ?? '',
        snapshot_current_grade: editing.snapshot_current_grade ?? '',
        current_salary: editing.current_salary ?? undefined,
        snapshot_proposed_grade: editing.snapshot_proposed_grade ?? '',
        proposed_salary: editing.proposed_salary ?? undefined,
        justification: editing.justification ?? '',
        promotion_date: editing.promotion_date ?? '',
      });
    } else {
      form.reset({ employee_id: '', proposed_position_id: '' });
    }
  }, [open, editing, form]);

  const onSubmit = async (vals: PromotionFormValues) => {
    setSaving(true);
    try {
      const SYSTEM_USER = '00000000-0000-0000-0000-000000000001';
      const payload = {
        ...vals,
        initiated_by: SYSTEM_USER,
        created_by: SYSTEM_USER,
        promotion_status: 'DRAFT' as PromotionStatus,
        is_active: 1, is_deleted: 0, is_current: 0,
        effective_from: new Date().toISOString(),
        effective_to: '9999-12-31 23:59:59+00',
        row_start: new Date().toISOString(),
        row_end: '9999-12-31 23:59:59+00',
      };
      if (editing) {
        await promotionRequestService.update(editing.promotion_id, vals);
        toast.success('Promotion request updated');
      } else {
        await promotionRequestService.create(payload as Parameters<typeof promotionRequestService.create>[0]);
        toast.success('Promotion request created');
      }
      onOpenChange(false);
      onSaved();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
        <DialogHeader><DialogTitle>{editing ? 'Edit Promotion Request' : 'New Promotion Request'}</DialogTitle></DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField control={form.control} name="employee_id" render={({ field }) => (
              <FormItem><FormLabel>Employee</FormLabel>
                <FormControl><EmployeeSelect value={field.value} onChange={field.onChange} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField control={form.control} name="current_position_id" render={({ field }) => (
                <FormItem><FormLabel>Current Position ID <span className="text-xs text-muted-foreground">(optional)</span></FormLabel>
                  <FormControl><Input {...field} placeholder="UUID" /></FormControl><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="proposed_position_id" render={({ field }) => (
                <FormItem><FormLabel>Proposed Position ID</FormLabel>
                  <FormControl><Input {...field} placeholder="UUID" /></FormControl><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="snapshot_current_grade" render={({ field }) => (
                <FormItem><FormLabel>Current Grade <span className="text-xs text-muted-foreground">(snapshot)</span></FormLabel>
                  <FormControl><Input {...field} placeholder="e.g. G5" /></FormControl><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="snapshot_proposed_grade" render={({ field }) => (
                <FormItem><FormLabel>Proposed Grade <span className="text-xs text-muted-foreground">(snapshot)</span></FormLabel>
                  <FormControl><Input {...field} placeholder="e.g. G6" /></FormControl><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="current_salary" render={({ field }) => (
                <FormItem><FormLabel>Current Salary</FormLabel>
                  <FormControl><Input type="number" min={0} step="0.01" {...field} /></FormControl><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="proposed_salary" render={({ field }) => (
                <FormItem><FormLabel>Proposed Salary</FormLabel>
                  <FormControl><Input type="number" min={0} step="0.01" {...field} /></FormControl><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="promotion_date" render={({ field }) => (
                <FormItem><FormLabel>Promotion Date <span className="text-xs text-muted-foreground">(optional)</span></FormLabel>
                  <FormControl><Input type="date" {...field} /></FormControl><FormMessage />
                </FormItem>
              )} />
            </div>
            <FormField control={form.control} name="justification" render={({ field }) => (
              <FormItem><FormLabel>Justification</FormLabel>
                <FormControl><Textarea {...field} rows={4} placeholder="Describe the reason for this promotion…" /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Submit'}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ── Status transition dialog ────────────────────────────────────────────────────
interface PromStatusDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  request: PromotionRequest | null;
  onSaved: () => void;
}

function PromStatusDialog({ open, onOpenChange, request, onSaved }: PromStatusDialogProps) {
  const [saving, setSaving] = useState(false);
  const [nextStatus, setNextStatus] = useState<PromotionStatus | ''>('');
  const [promotionDate, setPromotionDate] = useState('');

  useEffect(() => { if (open) { setNextStatus(''); setPromotionDate(''); } }, [open]);

  if (!request) return null;
  const available = VALID_TRANSITIONS[request.promotion_status] ?? [];

  const apply = async () => {
    if (!nextStatus) return;
    setSaving(true);
    try {
      const extra: Partial<PromotionRequest> = {};
      if (nextStatus === 'EXECUTED' && promotionDate) extra.promotion_date = promotionDate;
      await promotionRequestService.updateStatus(request.promotion_id, nextStatus, extra);
      toast.success(`Status updated to ${nextStatus}`);
      onOpenChange(false);
      onSaved();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Update failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
        <DialogHeader><DialogTitle>Update Promotion Status</DialogTitle></DialogHeader>
        <div className="space-y-4 py-2">
          <p className="text-sm text-muted-foreground">Current: <strong>{request.promotion_status}</strong></p>
          {available.length === 0 ? (
            <p className="text-sm text-muted-foreground italic">No transitions available.</p>
          ) : (
            <>
              <div className="space-y-1.5">
                <label className="text-sm font-normal">New Status</label>
                <Select value={nextStatus} onValueChange={v => setNextStatus(v as PromotionStatus)}>
                  <SelectTrigger><SelectValue placeholder="Select next status…" /></SelectTrigger>
                  <SelectContent>{available.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              {nextStatus === 'EXECUTED' && (
                <div className="space-y-1.5">
                  <label className="text-sm font-normal">Promotion Date</label>
                  <Input type="date" value={promotionDate} onChange={e => setPromotionDate(e.target.value)} />
                </div>
              )}
            </>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button disabled={!nextStatus || saving} onClick={apply}>{saving ? 'Updating…' : 'Apply'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── ApprovalDialog ──────────────────────────────────────────────────────────────
type ApprovalLevel = 'DEPT' | 'HR';

interface ApprovalDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  request: PromotionRequest | null;
  action: 'APPROVE' | 'REJECT';
  level: ApprovalLevel;
  onSaved: () => void;
}

async function sendPromotionEmail(
  type: string,
  employeeId: string,
  comment: string,
  extra: Record<string, string> = {},
) {
  try {
    await supabase.functions.invoke('send-notification-email', {
      body: {
        notification_type: type,
        recipient_email: `employee_${employeeId.slice(0, 8)}@bkggroup.hr`,
        employee_name: `Employee ${employeeId.slice(0, 8)}`,
        data: { comment, ...extra },
      },
    });
  } catch {
    // Non-blocking — email failure must not block the action
  }
}

function ApprovalDialog({ open, onOpenChange, request, action, level, onSaved }: ApprovalDialogProps) {
  const [comment, setComment] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (open) setComment(''); }, [open]);

  if (!request) return null;

  const isApprove  = action === 'APPROVE';
  const isDept     = level === 'DEPT';
  const actor      = isDept ? 'Department Manager' : 'HR';

  const nextStatus: PromotionStatus = isDept
    ? (isApprove ? 'DEPT_APPROVED' : 'DEPT_REJECTED')
    : (isApprove ? 'APPROVED'      : 'REJECTED');

  const emailType = isDept
    ? (isApprove ? 'PROMOTION_DEPT_APPROVED' : 'PROMOTION_DEPT_REJECTED')
    : (isApprove ? 'PROMOTION_APPROVED'      : 'PROMOTION_REJECTED');

  const apply = async () => {
    if (!comment.trim()) { toast.error('Comment is required'); return; }
    setSaving(true);
    try {
      if (isDept) {
        await promotionRequestService.update(request.promotion_id, {
          promotion_status:             nextStatus,
          dept_manager_approval_status: nextStatus as 'DEPT_APPROVED' | 'DEPT_REJECTED',
          dept_manager_approved_by:     actor,
          dept_manager_comment:         comment.trim(),
          dept_manager_approved_at:     new Date().toISOString(),
        });
      } else {
        await promotionRequestService.update(request.promotion_id, {
          promotion_status: nextStatus,
          approved_by:      actor,
          approval_comment: comment.trim(),
        });
      }
      await sendPromotionEmail(emailType, request.employee_id, comment.trim());
      toast.success(
        `Promotion for employee ${request.employee_id.slice(0, 8)} has been ${isApprove ? 'approved' : 'rejected'} by ${actor}. Comment: ${comment.trim()}`,
        { duration: 6000 },
      );
      onOpenChange(false);
      onSaved();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Action failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
        <DialogHeader>
          <DialogTitle className={isApprove ? 'text-emerald-700' : 'text-red-700'}>
            {isApprove ? `Approve — ${actor}` : `Reject — ${actor}`}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          {isDept && (
            <div className="rounded-md bg-blue-50 border border-blue-200 px-3 py-2 text-xs text-blue-700">
              Step 1 of 2 — Department Manager approval
            </div>
          )}
          {!isDept && (
            <div className="rounded-md bg-emerald-50 border border-emerald-200 px-3 py-2 text-xs text-emerald-700">
              Step 2 of 2 — HR final approval
            </div>
          )}
          <div className="rounded-md bg-muted p-3 text-xs space-y-1">
            <p><span className="text-muted-foreground">Promotion ID:</span> <strong>{request.promotion_id.slice(0, 8)}…</strong></p>
            {request.snapshot_current_grade && request.snapshot_proposed_grade && (
              <p><span className="text-muted-foreground">Grade:</span> {request.snapshot_current_grade} → <strong>{request.snapshot_proposed_grade}</strong></p>
            )}
            {request.current_salary != null && request.proposed_salary != null && (
              <p><span className="text-muted-foreground">Salary:</span> {fmt(request.current_salary)} → <strong>{fmt(request.proposed_salary)}</strong></p>
            )}
            {isDept && request.dept_manager_comment && (
              <p><span className="text-muted-foreground">Dept Comment:</span> {request.dept_manager_comment}</p>
            )}
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-normal">
              Comment <span className="text-destructive">*</span>
            </label>
            <Textarea
              placeholder={isApprove ? 'Add approval notes…' : 'State reason for rejection…'}
              value={comment}
              onChange={e => setComment(e.target.value)}
              rows={3}
              className="resize-none"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            disabled={!comment.trim() || saving}
            onClick={apply}
            className={isApprove ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : 'bg-red-600 hover:bg-red-700 text-white'}
          >
            {saving ? 'Saving…' : isApprove ? `Approve (${actor})` : 'Reject'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── ExecuteDialog ───────────────────────────────────────────────────────────────
interface ExecuteDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  request: PromotionRequest | null;
  onSaved: () => void;
}

function ExecuteDialog({ open, onOpenChange, request, onSaved }: ExecuteDialogProps) {
  const [execDate, setExecDate] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) setExecDate(new Date().toISOString().slice(0, 10));
  }, [open]);

  if (!request) return null;

  const apply = async () => {
    if (!execDate) { toast.error('Execution date is required'); return; }
    setSaving(true);
    try {
      await promotionRequestService.update(request.promotion_id, {
        promotion_status: 'EXECUTED',
        execution_date:   execDate,
        promotion_date:   execDate,
      });
      await sendPromotionEmail('PROMOTION_EXECUTED', request.employee_id, '', {
        execution_date:  execDate,
        new_grade:       request.snapshot_proposed_grade ?? '',
        new_salary:      request.proposed_salary != null ? String(request.proposed_salary) : '',
      });
      toast.success(
        `Promotion for employee ${request.employee_id.slice(0, 8)} has been EXECUTED on ${execDate}`,
        { duration: 5000 },
      );
      onOpenChange(false);
      onSaved();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Execute failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
        <DialogHeader><DialogTitle>Execute Promotion</DialogTitle></DialogHeader>
        <div className="space-y-4 py-2">
          <p className="text-sm text-muted-foreground">Set the effective execution date for this promotion.</p>
          <div className="space-y-1.5">
            <label className="text-sm font-normal">Execution Date <span className="text-destructive">*</span></label>
            <input
              type="date"
              value={execDate}
              onChange={e => setExecDate(e.target.value)}
              className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button disabled={!execDate || saving} onClick={apply}>
            {saving ? 'Executing…' : 'Execute'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Main page ───────────────────────────────────────────────────────────────────
export function PromotionRequestPage() {  const [requests, setRequests] = useState<PromotionRequest[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 20;

  const [statusFilter, setStatusFilter] = useState('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<PromotionRequest | null>(null);
  const [statusTarget, setStatusTarget] = useState<PromotionRequest | null>(null);
  const [deleting, setDeleting] = useState<PromotionRequest | null>(null);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [approvalTarget, setApprovalTarget] = useState<PromotionRequest | null>(null);
  const [approvalAction, setApprovalAction] = useState<'APPROVE' | 'REJECT'>('APPROVE');
  const [approvalLevel, setApprovalLevel] = useState<'DEPT' | 'HR'>('DEPT');
  const [executeTarget, setExecuteTarget] = useState<PromotionRequest | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const result = await promotionRequestService.list({
        promotion_status: statusFilter === 'all' ? undefined : statusFilter,
        page, pageSize: PAGE_SIZE,
      });
      setRequests(result.data);
      setTotal(result.total);
    } catch { toast.error('Failed to load promotion requests'); }
    finally { setLoading(false); }
  }, [statusFilter, page]);

  useEffect(() => { load(); }, [load]);

  const confirmDelete = async () => {
    if (!deleting) return;
    try {
      await promotionRequestService.softDelete(deleting.promotion_id);
      toast.success('Request deleted');
      setDeleting(null);
      load();
    } catch { toast.error('Delete failed'); }
  };

  const toggleExpand = (id: string) => {
    setExpanded(prev => { const s = new Set(prev); s.has(id) ? s.delete(id) : s.add(id); return s; });
  };

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const submittedCount = requests.filter(r => r.promotion_status === 'SUBMITTED' || r.promotion_status === 'DEPT_APPROVED').length;

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">Promotion Requests</h1>
          <p className="text-sm text-muted-foreground text-pretty">Manage employee promotion proposals with grade, salary, and position changes</p>
        </div>
        <Button onClick={() => { setEditing(null); setDialogOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" /> New Promotion
        </Button>
      </div>

      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-wrap gap-3 items-center">
            <button
              type="button"
              onClick={() => { setStatusFilter('SUBMITTED'); setPage(1); }}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-colors border ${
                statusFilter === 'SUBMITTED'
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'bg-background border-border hover:bg-muted'
              }`}
            >
              Approvals
              {submittedCount > 0 && (
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${statusFilter === 'SUBMITTED' ? 'bg-primary-foreground/20 text-primary-foreground' : 'bg-amber-100 text-amber-700'}`}>
                  {submittedCount}
                </span>
              )}
            </button>
            <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setPage(1); }}>
              <SelectTrigger className="w-44"><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {PROMOTION_STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" onClick={load}><RefreshCw className="h-4 w-4" /></Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {loading ? (
          Array.from({ length: 5 }).map((_, i) => <Card key={i}><CardContent className="p-4"><div className="h-10 bg-muted rounded animate-pulse" /></CardContent></Card>)
        ) : requests.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center py-14 text-muted-foreground">
              <TrendingUp className="h-10 w-10 mb-3 opacity-30" />
              <p className="text-sm">No promotion requests found</p>
              <Button variant="outline" size="sm" className="mt-4" onClick={() => { setEditing(null); setDialogOpen(true); }}>
                <Plus className="h-4 w-4 mr-2" /> Create First Request
              </Button>
            </CardContent>
          </Card>
        ) : requests.map(r => (
          <Card key={r.promotion_id} className="h-full">
            <CardHeader className="p-4">
              <div className="flex items-start justify-between gap-2">
                <button className="flex items-center gap-2 flex-1 min-w-0 text-left" onClick={() => toggleExpand(r.promotion_id)}>
                  {expanded.has(r.promotion_id) ? <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-sm truncate">Promotion #{r.promotion_id.slice(0, 8)}</span>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLORS[r.promotion_status]}`}>{r.promotion_status}</span>
                    </div>
                    <div className="flex items-center gap-3 mt-1 flex-wrap text-xs text-muted-foreground">
                      <span>EMP: {r.employee_id.slice(0, 8)}…</span>
                      {r.snapshot_current_grade && r.snapshot_proposed_grade && (
                        <span>{r.snapshot_current_grade} → {r.snapshot_proposed_grade}</span>
                      )}
                      {r.current_salary != null && r.proposed_salary != null && (
                        <span>{fmt(r.current_salary)} → {fmt(r.proposed_salary)}</span>
                      )}
                      {r.promotion_date && <span>Date: {r.promotion_date}</span>}
                    </div>
                  </div>
                </button>
                <div className="flex gap-1 shrink-0 flex-wrap">
                  {r.promotion_status === 'SUBMITTED' && (
                    <>
                      <Button
                        variant="ghost" size="sm"
                        className="h-8 text-xs px-2 text-cyan-700 hover:text-cyan-800 hover:bg-cyan-50"
                        onClick={() => { setApprovalAction('APPROVE'); setApprovalLevel('DEPT'); setApprovalTarget(r); }}
                      >
                        <CheckCircle className="h-3.5 w-3.5 mr-1" />Approve (Dept)
                      </Button>
                      <Button
                        variant="ghost" size="sm"
                        className="h-8 text-xs px-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                        onClick={() => { setApprovalAction('REJECT'); setApprovalLevel('DEPT'); setApprovalTarget(r); }}
                      >
                        <XCircle className="h-3.5 w-3.5 mr-1" />Reject (Dept)
                      </Button>
                    </>
                  )}
                  {r.promotion_status === 'DEPT_APPROVED' && (
                    <>
                      <Button
                        variant="ghost" size="sm"
                        className="h-8 text-xs px-2 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                        onClick={() => { setApprovalAction('APPROVE'); setApprovalLevel('HR'); setApprovalTarget(r); }}
                      >
                        <CheckCircle className="h-3.5 w-3.5 mr-1" />Approve (HR)
                      </Button>
                      <Button
                        variant="ghost" size="sm"
                        className="h-8 text-xs px-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                        onClick={() => { setApprovalAction('REJECT'); setApprovalLevel('HR'); setApprovalTarget(r); }}
                      >
                        <XCircle className="h-3.5 w-3.5 mr-1" />Reject (HR)
                      </Button>
                    </>
                  )}
                  {r.promotion_status === 'APPROVED' && (
                    <Button
                      variant="ghost" size="sm"
                      className="h-8 text-xs px-2 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                      onClick={() => setExecuteTarget(r)}
                    >
                      <PlayCircle className="h-3.5 w-3.5 mr-1" />Execute
                    </Button>
                  )}
                  <Button variant="ghost" size="sm" className="h-8 text-xs px-2" onClick={() => setStatusTarget(r)}>Status</Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditing(r); setDialogOpen(true); }}><Pencil className="h-3.5 w-3.5" /></Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleting(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
            </CardHeader>
            {expanded.has(r.promotion_id) && (
              <CardContent className="pt-0 pb-4 px-4 border-t">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 text-xs">
                  <div><p className="text-muted-foreground">Current Position</p><p className="font-mono">{r.current_position_id ? r.current_position_id.slice(0, 8) + '…' : '—'}</p></div>
                  <div><p className="text-muted-foreground">Proposed Position</p><p className="font-mono">{r.proposed_position_id.slice(0, 8)}…</p></div>
                  <div><p className="text-muted-foreground">Current Salary</p><p>{fmt(r.current_salary)}</p></div>
                  <div><p className="text-muted-foreground">Proposed Salary</p><p className="font-medium text-primary">{fmt(r.proposed_salary)}</p></div>
                  <div><p className="text-muted-foreground">Initiated By</p><p className="font-mono">{r.initiated_by.slice(0, 8)}…</p></div>
                  <div><p className="text-muted-foreground">Initiated At</p><p>{new Date(r.initiated_at).toLocaleDateString()}</p></div>
                  {r.justification && <div className="col-span-2 md:col-span-4"><p className="text-muted-foreground">Justification</p><p className="text-pretty">{r.justification}</p></div>}
                  {r.dept_manager_approved_by && <div><p className="text-muted-foreground">Dept Manager</p><p>{r.dept_manager_approved_by}</p></div>}
                  {r.dept_manager_comment && <div className="col-span-2 md:col-span-4"><p className="text-muted-foreground">Dept Comment</p><p className="text-pretty">{r.dept_manager_comment}</p></div>}
                  {r.approved_by && <div><p className="text-muted-foreground">Approved By (HR)</p><p>{r.approved_by}</p></div>}
                  {r.execution_date && <div><p className="text-muted-foreground">Execution Date</p><p>{r.execution_date}</p></div>}
                  {r.approval_comment && <div className="col-span-2 md:col-span-4"><p className="text-muted-foreground">HR Comment</p><p className="text-pretty">{r.approval_comment}</p></div>}
                </div>
              </CardContent>
            )}
          </Card>
        ))}
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 pt-2">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
          <span className="text-sm text-muted-foreground">Page {page} of {totalPages}</span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
        </div>
      )}

      <PromotionDialog open={dialogOpen} onOpenChange={setDialogOpen} editing={editing} onSaved={load} />
      <PromStatusDialog open={!!statusTarget} onOpenChange={o => !o && setStatusTarget(null)} request={statusTarget} onSaved={load} />
      <ApprovalDialog
        open={!!approvalTarget}
        onOpenChange={o => !o && setApprovalTarget(null)}
        request={approvalTarget}
        action={approvalAction}
        level={approvalLevel}
        onSaved={load}
      />
      <ExecuteDialog
        open={!!executeTarget}
        onOpenChange={o => !o && setExecuteTarget(null)}
        request={executeTarget}
        onSaved={load}
      />

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader><AlertDialogTitle>Delete Promotion Request</AlertDialogTitle>
            <AlertDialogDescription>Delete promotion request <strong>{deleting?.promotion_id.slice(0, 8)}</strong>? This cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
