import { useState, useEffect, useCallback } from 'react';
import { transferPromotionService } from '@/services/modules.service';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, ArrowRightLeft, Building2, RefreshCw, CheckCircle2, XCircle, ClipboardList, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { supabase as _sb } from '@/db/supabase';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = _sb as any;

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  approved: 'bg-green-100 text-green-800',
  rejected: 'bg-red-100 text-red-800',
  completed: 'bg-blue-100 text-blue-800',
  cancelled: 'bg-muted text-muted-foreground',
  PENDING: 'bg-yellow-100 text-yellow-800',
  APPROVED: 'bg-green-100 text-greenald-800',
  REJECTED: 'bg-red-100 text-red-800',
  EXECUTED: 'bg-teal-100 text-teal-800',
  CANCELLED: 'bg-muted text-muted-foreground',
};

const TYPE_COLORS: Record<string, string> = {
  transfer: 'bg-blue-100 text-blue-800',
  promotion: 'bg-green-100 text-green-800',
  demotion: 'bg-orange-100 text-orange-800',
  lateral_move: 'bg-purple-100 text-purple-800',
};

/* ─────────────────────────────────────────────────────────────────── */
/*  Internal Transfers & Promotions tab                                */
/* ─────────────────────────────────────────────────────────────────── */
function InternalTransfersTab() {
  const [records, setRecords] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [typeFilter, setTypeFilter] = useState('all');
  const [dialog, setDialog] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    employee_id: '', transaction_type: 'transfer',
    effective_date: '', reason: '', status: 'pending',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await transferPromotionService.list({
        transaction_type: typeFilter !== 'all' ? typeFilter : undefined,
        page: 1, pageSize: 30,
      });
      setRecords(res.data as Record<string, unknown>[]);
      setTotal(res.total);
    } catch { toast.error('Failed to load transfers & promotions'); }
    finally { setLoading(false); }
  }, [typeFilter]);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.employee_id || form.employee_id === 'none') { toast.error('Please select an employee'); return; }
    setSaving(true);
    try {
      await transferPromotionService.create({
        employee_id: form.employee_id,
        transaction_type: form.transaction_type,
        effective_date: form.effective_date || null,
        reason: form.reason || null,
        status: form.status,
      });
      toast.success('Transfer / Promotion created');
      setDialog(false);
      setForm({ employee_id: '', transaction_type: 'transfer', effective_date: '', reason: '', status: 'pending' });
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to create record'); }
    finally { setSaving(false); }
  };

  const emp = (r: Record<string, unknown>) => {
    const e = r.employee as Record<string, unknown> | undefined;
    return e ? `${e.first_name} ${e.last_name}` : '—';
  };
  const fromDept = (r: Record<string, unknown>) => {
    const d = r.from_department as Record<string, unknown> | undefined;
    return d ? String(d.name) : '—';
  };
  const toDept = (r: Record<string, unknown>) => {
    const d = r.to_department as Record<string, unknown> | undefined;
    return d ? String(d.name) : '—';
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <p className="text-sm text-muted-foreground">{total} records</p>
        <div className="flex items-center gap-2">
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-36 h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="transfer">Transfer</SelectItem>
              <SelectItem value="promotion">Promotion</SelectItem>
              <SelectItem value="demotion">Demotion</SelectItem>
              <SelectItem value="lateral_move">Lateral Move</SelectItem>
            </SelectContent>
          </Select>
          <Dialog open={dialog} onOpenChange={setDialog}>
            <DialogTrigger asChild>
              <Button size="sm" className="h-8"><Plus className="h-3.5 w-3.5 mr-1.5" />Add</Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>Create Transfer / Promotion</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 mt-2">
                <EmployeeSelect value={form.employee_id} onChange={v => setForm(p => ({ ...p, employee_id: v }))} required />
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Transaction Type *</Label>
                    <Select value={form.transaction_type} onValueChange={v => setForm(p => ({ ...p, transaction_type: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="transfer">Transfer</SelectItem>
                        <SelectItem value="promotion">Promotion</SelectItem>
                        <SelectItem value="demotion">Demotion</SelectItem>
                        <SelectItem value="lateral_move">Lateral Move</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5"><Label>Effective Date</Label><Input type="date" value={form.effective_date} onChange={e => setForm(p => ({ ...p, effective_date: e.target.value }))} /></div>
                </div>
                <div className="space-y-1.5"><Label>Reason</Label><Textarea rows={3} value={form.reason} onChange={e => setForm(p => ({ ...p, reason: e.target.value }))} /></div>
                <div className="space-y-1.5">
                  <Label>Status</Label>
                  <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full" disabled={saving}>{saving ? 'Saving…' : 'Create Record'}</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">From Dept.</TableHead>
                <TableHead className="whitespace-nowrap">To Dept.</TableHead>
                <TableHead className="whitespace-nowrap">Effective Date</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                : records.length === 0 ? <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No records found</TableCell></TableRow>
                : records.map(r => (
                  <TableRow key={String(r.id)}>
                    <TableCell className="whitespace-nowrap font-medium">{emp(r)}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={TYPE_COLORS[String(r.transaction_type)] || 'bg-muted'}>{String(r.transaction_type).replace('_', ' ')}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fromDept(r)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{toDept(r)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.effective_date ? String(r.effective_date) : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={STATUS_COLORS[String(r.status)] || 'bg-muted'}>{String(r.status)}</Badge></TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────── */
/*  Inter-Company Transfer tab (FR-EM-INT-001~006)                     */
/* ─────────────────────────────────────────────────────────────────── */
type ICTRequest = {
  id: string; employee_id: string;
  source_entity: string; destination_entity: string;
  destination_department: string; effective_date: string;
  reason: string; status: string; created_at: string;
  employee?: { first_name: string; last_name: string; employee_no: string };
};

const ICT_STATUS: Record<string, string> = {
  DRAFT: 'bg-muted text-muted-foreground',
  SUBMITTED: 'bg-blue-100 text-blue-800',
  APPROVED: 'bg-emerald-100 text-emerald-800',
  REJECTED: 'bg-red-100 text-red-800',
  EXECUTED: 'bg-teal-100 text-teal-800',
  CANCELLED: 'bg-gray-100 text-gray-500',
};

function InterCompanyTab() {
  const [requests, setRequests] = useState<ICTRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [selected, setSelected] = useState<ICTRequest | null>(null);
  const [reviewComment, setReviewComment] = useState('');
  const [actBusy, setActBusy] = useState(false);
  const [form, setForm] = useState({
    employee_id: '', source_entity: '', destination_entity: '',
    destination_department: '', effective_date: '', reason: '',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await sb.from('inter_company_transfers')
        .select('*, employee:employees!inter_company_transfers_employee_id_fkey(first_name,last_name,employee_no)')
        .order('created_at', { ascending: false }).limit(50);
      if (error) throw error;
      setRequests(Array.isArray(data) ? data : []);
    } catch { toast.error('Failed to load inter-company transfers'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const create = async () => {
    if (!form.employee_id || !form.destination_entity || !form.effective_date || !form.reason) {
      toast.error('Employee, Destination Entity, Effective Date and Reason are required'); return;
    }
    setSaving(true);
    const { error } = await sb.from('inter_company_transfers').insert({
      employee_id: form.employee_id,
      source_entity: form.source_entity || null,
      destination_entity: form.destination_entity,
      destination_department: form.destination_department || null,
      from_entity: form.source_entity || null,
      to_entity: form.destination_entity,
      effective_date: form.effective_date,
      transfer_date: form.effective_date,
      reason: form.reason,
      status: 'SUBMITTED',
    });
    if (error) { toast.error(error.message); setSaving(false); return; }
    toast.success('Transfer request submitted');
    setCreateOpen(false);
    setForm({ employee_id: '', source_entity: '', destination_entity: '', destination_department: '', effective_date: '', reason: '' });
    load();
    setSaving(false);
  };

  const review = async (action: 'APPROVED' | 'REJECTED') => {
    if (!selected) return;
    setActBusy(true);
    const { error } = await sb.from('inter_company_transfers')
      .update({ status: action, reviewer_comments: reviewComment || null, reviewed_at: new Date().toISOString() })
      .eq('id', selected.id);
    if (error) { toast.error(error.message); setActBusy(false); return; }
    toast.success(`Transfer ${action.toLowerCase()}`);
    setReviewOpen(false); setReviewComment('');
    load();
    setActBusy(false);
  };

  const execute = async (req: ICTRequest) => {
    setActBusy(true);
    const { error } = await sb.from('inter_company_transfers')
      .update({ status: 'EXECUTED', executed_at: new Date().toISOString() }).eq('id', req.id);
    if (error) { toast.error(error.message); setActBusy(false); return; }
    toast.success('Transfer executed — employee record updated');
    load();
    setActBusy(false);
  };

  const fullName = (r: ICTRequest) => r.employee ? `${r.employee.first_name} ${r.employee.last_name}` : '—';

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <p className="text-sm text-muted-foreground">{requests.length} requests</p>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="h-8" onClick={load} disabled={loading}>
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          </Button>
          <Button size="sm" className="h-8" onClick={() => setCreateOpen(true)}>
            <Plus className="h-3.5 w-3.5 mr-1.5" />New Request
          </Button>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">From</TableHead>
                <TableHead className="whitespace-nowrap">To</TableHead>
                <TableHead className="whitespace-nowrap">Dept.</TableHead>
                <TableHead className="whitespace-nowrap">Effective</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading
                ? Array.from({ length: 4 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 7 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                : requests.length === 0
                  ? <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">No inter-company transfers yet</TableCell></TableRow>
                  : requests.map(r => (
                    <TableRow key={r.id}>
                      <TableCell className="whitespace-nowrap font-medium">{fullName(r)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.source_entity || '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.destination_entity || '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.destination_department || '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.effective_date ? new Date(r.effective_date).toLocaleDateString() : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap"><Badge className={ICT_STATUS[r.status] || 'bg-muted'}>{r.status}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap">
                        {r.status === 'SUBMITTED' && (
                          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => { setSelected(r); setReviewOpen(true); }}>
                            Review
                          </Button>
                        )}
                        {r.status === 'APPROVED' && (
                          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => execute(r)} disabled={actBusy}>
                            {actBusy ? <Loader2 className="h-3 w-3 animate-spin" /> : 'Execute'}
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Create dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Inter-Company Transfer Request</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <EmployeeSelect value={form.employee_id} onChange={v => setForm(p => ({ ...p, employee_id: v }))} required />
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Source Entity</Label><Input placeholder="Current company" value={form.source_entity} onChange={e => setForm(p => ({ ...p, source_entity: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Destination Entity *</Label><Input placeholder="Target company" value={form.destination_entity} onChange={e => setForm(p => ({ ...p, destination_entity: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Destination Dept.</Label><Input value={form.destination_department} onChange={e => setForm(p => ({ ...p, destination_department: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Effective Date *</Label><Input type="date" value={form.effective_date} onChange={e => setForm(p => ({ ...p, effective_date: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Reason *</Label><Textarea rows={3} value={form.reason} onChange={e => setForm(p => ({ ...p, reason: e.target.value }))} /></div>
            <Button className="w-full" onClick={create} disabled={saving}>{saving ? <><Loader2 className="h-3.5 w-3.5 mr-2 animate-spin" />Submitting…</> : 'Submit Request'}</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Review dialog */}
      <Dialog open={reviewOpen} onOpenChange={setReviewOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Review Transfer Request</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            {selected && (
              <Card className="bg-muted/40">
                <CardContent className="p-3 text-sm space-y-1">
                  <p><span className="font-medium">Employee:</span> {fullName(selected)}</p>
                  <p><span className="font-medium">To:</span> {selected.destination_entity}</p>
                  <p><span className="font-medium">Effective:</span> {selected.effective_date}</p>
                  <p><span className="font-medium">Reason:</span> {selected.reason}</p>
                </CardContent>
              </Card>
            )}
            <div className="space-y-1.5"><Label>Review Comments</Label><Textarea rows={3} value={reviewComment} onChange={e => setReviewComment(e.target.value)} /></div>
            <div className="flex gap-2">
              <Button className="flex-1" onClick={() => review('APPROVED')} disabled={actBusy}>
                <CheckCircle2 className="h-4 w-4 mr-1.5" />Approve
              </Button>
              <Button variant="outline" className="flex-1" onClick={() => review('REJECTED')} disabled={actBusy}>
                <XCircle className="h-4 w-4 mr-1.5" />Reject
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────── */
/*  Main page — tabbed container                                        */
/* ─────────────────────────────────────────────────────────────────── */
export function TransferPromotionPage() {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-foreground flex items-center gap-2 text-balance">
          <ArrowRightLeft className="h-5 w-5 text-primary" />Transfers &amp; Promotions
        </h1>
        <p className="text-sm text-muted-foreground mt-0.5 text-pretty">Manage internal transfers, promotions and inter-company movements</p>
      </div>

      <Tabs defaultValue="internal">
        <TabsList className="h-9">
          <TabsTrigger value="internal" className="text-xs md:text-sm gap-1.5">
            <ArrowRightLeft className="h-3.5 w-3.5" />Internal
          </TabsTrigger>
          <TabsTrigger value="inter-company" className="text-xs md:text-sm gap-1.5">
            <Building2 className="h-3.5 w-3.5" />Inter-Company
          </TabsTrigger>
          <TabsTrigger value="audit" className="text-xs md:text-sm gap-1.5">
            <ClipboardList className="h-3.5 w-3.5" />Audit Log
          </TabsTrigger>
        </TabsList>

        <TabsContent value="internal" className="mt-4">
          <InternalTransfersTab />
        </TabsContent>

        <TabsContent value="inter-company" className="mt-4">
          <InterCompanyTab />
        </TabsContent>

        <TabsContent value="audit" className="mt-4">
          <ICTAuditTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────── */
/*  ICT Audit Log tab                                                   */
/* ─────────────────────────────────────────────────────────────────── */
function ICTAuditTab() {
  const [logs, setLogs] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('ict_audit_logs')
      .select('id, action, actor_id, description, created_at, transfer_id')
      .order('created_at', { ascending: false }).limit(50);
    setLogs(Array.isArray(data) ? data : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm flex items-center gap-2"><ClipboardList className="h-4 w-4" />Inter-Company Transfer Audit Log</CardTitle>
        <Button size="sm" variant="outline" className="h-7" onClick={load} disabled={loading}>
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
        </Button>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Date</TableHead>
                <TableHead className="whitespace-nowrap">Action</TableHead>
                <TableHead>Description</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading
                ? Array.from({ length: 4 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 3 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                : logs.length === 0
                  ? <TableRow><TableCell colSpan={3} className="text-center py-8 text-muted-foreground text-sm">No audit entries yet</TableCell></TableRow>
                  : logs.map(l => (
                    <TableRow key={String(l.id)}>
                      <TableCell className="whitespace-nowrap text-sm">{l.created_at ? new Date(String(l.created_at)).toLocaleString() : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap"><Badge className="bg-muted text-muted-foreground text-xs">{String(l.action)}</Badge></TableCell>
                      <TableCell className="text-sm text-pretty">{String(l.description || '—')}</TableCell>
                    </TableRow>
                  ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}

export default TransferPromotionPage;
