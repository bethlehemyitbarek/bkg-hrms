import { useState, useEffect, useCallback } from 'react';
import { Plus, Pencil, Trash2, ArrowRightLeft, RefreshCw, ChevronDown, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { transferRequestService } from '@/services/transfer.service';
import type { TransferRequest, TransferType, TransferStatus } from '@/types/database.types';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';

const TRANSFER_TYPES: TransferType[] = ['LATERAL', 'DEPARTMENTAL', 'LOCATION', 'INTER_COMPANY'];
const TRANSFER_STATUSES: TransferStatus[] = ['DRAFT', 'SUBMITTED', 'APPROVED', 'REJECTED', 'EXECUTED', 'CANCELLED'];

const STATUS_COLORS: Record<TransferStatus, string> = {
  DRAFT: 'bg-muted text-muted-foreground',
  SUBMITTED: 'bg-blue-100 text-blue-700',
  APPROVED: 'bg-green-100 text-green-700',
  REJECTED: 'bg-red-100 text-red-700',
  EXECUTED: 'bg-emerald-100 text-emerald-700',
  CANCELLED: 'bg-orange-100 text-orange-700',
};

const TYPE_COLORS: Record<TransferType, string> = {
  LATERAL: 'bg-blue-100 text-blue-700',
  DEPARTMENTAL: 'bg-purple-100 text-purple-700',
  LOCATION: 'bg-cyan-100 text-cyan-700',
  INTER_COMPANY: 'bg-orange-100 text-orange-700',
};

// ── Status transition rules ─────────────────────────────────────────────────────
const VALID_TRANSITIONS: Record<TransferStatus, TransferStatus[]> = {
  DRAFT: ['SUBMITTED', 'CANCELLED'],
  SUBMITTED: ['APPROVED', 'REJECTED', 'CANCELLED'],
  APPROVED: ['EXECUTED', 'CANCELLED'],
  REJECTED: [],
  EXECUTED: [],
  CANCELLED: [],
};

// ── Form schema ─────────────────────────────────────────────────────────────────
const transferSchema = z.object({
  employee_id: z.string().min(1, 'Employee required'),
  transfer_type: z.enum(['LATERAL', 'DEPARTMENTAL', 'LOCATION', 'INTER_COMPANY']),
  reason: z.string().optional(),
  effective_date: z.string().optional(),
  current_department_id: z.string().optional(),
  current_position_id: z.string().optional(),
  target_department_id: z.string().optional(),
  target_position_id: z.string().optional(),
  target_location_id: z.string().optional(),
});
type TransferFormValues = z.infer<typeof transferSchema>;

interface TransferDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: TransferRequest | null;
  onSaved: () => void;
}

function TransferDialog({ open, onOpenChange, editing, onSaved }: TransferDialogProps) {
  const [saving, setSaving] = useState(false);
  const form = useForm<TransferFormValues>({
    resolver: zodResolver(transferSchema),
    defaultValues: { transfer_type: 'DEPARTMENTAL', employee_id: '' },
  });

  useEffect(() => {
    if (!open) return;
    if (editing) {
      form.reset({
        employee_id: editing.employee_id,
        transfer_type: editing.transfer_type,
        reason: editing.reason ?? '',
        effective_date: editing.effective_date ?? '',
        current_department_id: editing.current_department_id ?? '',
        current_position_id: editing.current_position_id ?? '',
        target_department_id: editing.target_department_id ?? '',
        target_position_id: editing.target_position_id ?? '',
        target_location_id: editing.target_location_id ?? '',
      });
    } else {
      form.reset({ transfer_type: 'DEPARTMENTAL', employee_id: '' });
    }
  }, [open, editing, form]);

  const onSubmit = async (vals: TransferFormValues) => {
    setSaving(true);
    try {
      const SYSTEM_USER = '00000000-0000-0000-0000-000000000001';
      const payload = {
        ...vals,
        initiated_by: SYSTEM_USER,
        created_by: SYSTEM_USER,
        transfer_status: 'DRAFT' as TransferStatus,
        is_active: 1, is_deleted: 0, is_current: 0,
        effective_from: new Date().toISOString(),
        effective_to: '9999-12-31 23:59:59+00',
        row_start: new Date().toISOString(),
        row_end: '9999-12-31 23:59:59+00',
      };
      if (editing) {
        await transferRequestService.update(editing.transfer_id, vals);
        toast.success('Transfer updated');
      } else {
        await transferRequestService.create(payload as Parameters<typeof transferRequestService.create>[0]);
        toast.success('Transfer request created');
      }
      onOpenChange(false);
      onSaved();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
        <DialogHeader><DialogTitle>{editing ? 'Edit Transfer Request' : 'New Transfer Request'}</DialogTitle></DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField control={form.control} name="employee_id" render={({ field }) => (
              <FormItem><FormLabel>Employee</FormLabel>
                <FormControl><EmployeeSelect value={field.value} onChange={field.onChange} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField control={form.control} name="transfer_type" render={({ field }) => (
                <FormItem><FormLabel>Transfer Type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{TRANSFER_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace('_', ' ')}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="effective_date" render={({ field }) => (
                <FormItem><FormLabel>Effective Date <span className="text-xs text-muted-foreground">(optional)</span></FormLabel>
                  <FormControl><Input type="date" {...field} /></FormControl><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="current_department_id" render={({ field }) => (
                <FormItem><FormLabel>Current Department ID <span className="text-xs text-muted-foreground">(optional)</span></FormLabel>
                  <FormControl><Input {...field} placeholder="UUID" /></FormControl><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="target_department_id" render={({ field }) => (
                <FormItem><FormLabel>Target Department ID <span className="text-xs text-muted-foreground">(optional)</span></FormLabel>
                  <FormControl><Input {...field} placeholder="UUID" /></FormControl><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="current_position_id" render={({ field }) => (
                <FormItem><FormLabel>Current Position ID <span className="text-xs text-muted-foreground">(optional)</span></FormLabel>
                  <FormControl><Input {...field} placeholder="UUID" /></FormControl><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="target_position_id" render={({ field }) => (
                <FormItem><FormLabel>Target Position ID <span className="text-xs text-muted-foreground">(optional)</span></FormLabel>
                  <FormControl><Input {...field} placeholder="UUID" /></FormControl><FormMessage />
                </FormItem>
              )} />
            </div>
            <FormField control={form.control} name="reason" render={({ field }) => (
              <FormItem><FormLabel>Reason</FormLabel>
                <FormControl><Textarea {...field} rows={3} placeholder="Describe the reason for this transfer…" /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Submit'}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ── Status transition dialog ────────────────────────────────────────────────────
interface StatusDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  request: TransferRequest | null;
  onSaved: () => void;
}

function StatusDialog({ open, onOpenChange, request, onSaved }: StatusDialogProps) {
  const [saving, setSaving] = useState(false);
  const [nextStatus, setNextStatus] = useState<TransferStatus | ''>('');
  const [effectiveDate, setEffectiveDate] = useState('');

  useEffect(() => {
    if (open) { setNextStatus(''); setEffectiveDate(''); }
  }, [open]);

  if (!request) return null;
  const available = VALID_TRANSITIONS[request.transfer_status] ?? [];

  const apply = async () => {
    if (!nextStatus) return;
    setSaving(true);
    try {
      await transferRequestService.updateStatus(request.transfer_id, nextStatus, effectiveDate ? { effective_date: effectiveDate } : undefined);
      toast.success(`Status updated to ${nextStatus}`);
      onOpenChange(false);
      onSaved();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Update failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
        <DialogHeader><DialogTitle>Update Transfer Status</DialogTitle></DialogHeader>
        <div className="space-y-4 py-2">
          <p className="text-sm text-muted-foreground">Current: <strong>{request.transfer_status}</strong></p>
          {available.length === 0 ? (
            <p className="text-sm text-muted-foreground italic">No transitions available from this status.</p>
          ) : (
            <>
              <div className="space-y-1.5">
                <label className="text-sm font-normal">New Status</label>
                <Select value={nextStatus} onValueChange={v => setNextStatus(v as TransferStatus)}>
                  <SelectTrigger><SelectValue placeholder="Select next status…" /></SelectTrigger>
                  <SelectContent>{available.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              {nextStatus === 'EXECUTED' && (
                <div className="space-y-1.5">
                  <label className="text-sm font-normal">Effective Date</label>
                  <Input type="date" value={effectiveDate} onChange={e => setEffectiveDate(e.target.value)} />
                </div>
              )}
            </>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button disabled={!nextStatus || saving} onClick={apply}>{saving ? 'Updating…' : 'Apply'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Main page ───────────────────────────────────────────────────────────────────
export function TransferRequestPage() {
  const [requests, setRequests] = useState<TransferRequest[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 20;

  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<TransferRequest | null>(null);
  const [statusTarget, setStatusTarget] = useState<TransferRequest | null>(null);
  const [deleting, setDeleting] = useState<TransferRequest | null>(null);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const result = await transferRequestService.list({
        transfer_status: statusFilter === 'all' ? undefined : statusFilter,
        transfer_type: typeFilter === 'all' ? undefined : typeFilter,
        page, pageSize: PAGE_SIZE,
      });
      setRequests(result.data);
      setTotal(result.total);
    } catch { toast.error('Failed to load transfer requests'); }
    finally { setLoading(false); }
  }, [statusFilter, typeFilter, page]);

  useEffect(() => { load(); }, [load]);

  const confirmDelete = async () => {
    if (!deleting) return;
    try {
      await transferRequestService.softDelete(deleting.transfer_id);
      toast.success('Request deleted');
      setDeleting(null);
      load();
    } catch { toast.error('Delete failed'); }
  };

  const toggleExpand = (id: string) => {
    setExpanded(prev => { const s = new Set(prev); s.has(id) ? s.delete(id) : s.add(id); return s; });
  };

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">Transfer Requests</h1>
          <p className="text-sm text-muted-foreground text-pretty">Manage employee transfer requests and workflow approvals</p>
        </div>
        <Button onClick={() => { setEditing(null); setDialogOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" /> New Transfer
        </Button>
      </div>

      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-wrap gap-3">
            <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setPage(1); }}>
              <SelectTrigger className="w-44"><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {TRANSFER_STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={v => { setTypeFilter(v); setPage(1); }}>
              <SelectTrigger className="w-44"><SelectValue placeholder="All Types" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {TRANSFER_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace('_', ' ')}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" onClick={load}><RefreshCw className="h-4 w-4" /></Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {loading ? (
          Array.from({ length: 5 }).map((_, i) => <Card key={i}><CardContent className="p-4"><div className="h-10 bg-muted rounded animate-pulse" /></CardContent></Card>)
        ) : requests.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center py-14 text-muted-foreground">
              <ArrowRightLeft className="h-10 w-10 mb-3 opacity-30" />
              <p className="text-sm">No transfer requests found</p>
              <Button variant="outline" size="sm" className="mt-4" onClick={() => { setEditing(null); setDialogOpen(true); }}>
                <Plus className="h-4 w-4 mr-2" /> Create First Request
              </Button>
            </CardContent>
          </Card>
        ) : requests.map(r => (
          <Card key={r.transfer_id} className="h-full">
            <CardHeader className="p-4">
              <div className="flex items-start justify-between gap-2">
                <button className="flex items-center gap-2 flex-1 min-w-0 text-left" onClick={() => toggleExpand(r.transfer_id)}>
                  {expanded.has(r.transfer_id) ? <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-sm truncate">Transfer #{r.transfer_id.slice(0, 8)}</span>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${TYPE_COLORS[r.transfer_type]}`}>{r.transfer_type.replace('_', ' ')}</span>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLORS[r.transfer_status]}`}>{r.transfer_status}</span>
                    </div>
                    <div className="flex items-center gap-3 mt-1 flex-wrap text-xs text-muted-foreground">
                      <span>EMP: {r.employee_id.slice(0, 8)}…</span>
                      {r.effective_date && <span>Effective: {r.effective_date}</span>}
                      <span>{new Date(r.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                </button>
                <div className="flex gap-1 shrink-0">
                  <Button variant="ghost" size="sm" className="h-8 text-xs px-2" onClick={() => setStatusTarget(r)}>Status</Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditing(r); setDialogOpen(true); }}><Pencil className="h-3.5 w-3.5" /></Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleting(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
            </CardHeader>
            {expanded.has(r.transfer_id) && (
              <CardContent className="pt-0 pb-4 px-4 border-t">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 text-xs">
                  <div><p className="text-muted-foreground">Current Dept</p><p className="font-mono">{r.current_department_id ? r.current_department_id.slice(0, 8) + '…' : '—'}</p></div>
                  <div><p className="text-muted-foreground">Target Dept</p><p className="font-mono">{r.target_department_id ? r.target_department_id.slice(0, 8) + '…' : '—'}</p></div>
                  <div><p className="text-muted-foreground">Current Position</p><p className="font-mono">{r.current_position_id ? r.current_position_id.slice(0, 8) + '…' : '—'}</p></div>
                  <div><p className="text-muted-foreground">Target Position</p><p className="font-mono">{r.target_position_id ? r.target_position_id.slice(0, 8) + '…' : '—'}</p></div>
                  {r.reason && <div className="col-span-2 md:col-span-4"><p className="text-muted-foreground">Reason</p><p className="text-pretty">{r.reason}</p></div>}
                </div>
              </CardContent>
            )}
          </Card>
        ))}
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 pt-2">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
          <span className="text-sm text-muted-foreground">Page {page} of {totalPages}</span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
        </div>
      )}

      <TransferDialog open={dialogOpen} onOpenChange={setDialogOpen} editing={editing} onSaved={load} />
      <StatusDialog open={!!statusTarget} onOpenChange={o => !o && setStatusTarget(null)} request={statusTarget} onSaved={load} />

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader><AlertDialogTitle>Delete Request</AlertDialogTitle>
            <AlertDialogDescription>Delete transfer request <strong>{deleting?.transfer_id.slice(0, 8)}</strong>?</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
