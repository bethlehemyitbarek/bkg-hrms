import { useState, useEffect, useCallback } from 'react';
import { dsarService } from '@/services/compliance.service';
import { supabase } from '@/db/supabase';
import { notificationEngine } from '@/services/notification-engine.service';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import {
  RefreshCw, Search, Filter, Eye, ChevronRight, FileText,
  Clock, CheckCircle2, XCircle, AlertCircle, Users, CalendarClock,
} from 'lucide-react';

/* ─── Types ─────────────────────────────────────────────────────────────── */
type DsarRow = Record<string, unknown> & {
  dsar_id: string;
  employee_id: string;
  request_type: string;
  request_date: string;
  deadline_date: string;
  request_status: string;
  response_notes?: string;
  completion_date?: string;
  employee?: { first_name: string; last_name: string; employee_no?: string };
};

/* ─── Helpers ────────────────────────────────────────────────────────────── */
const STATUS_FLOW: Record<string, string[]> = {
  SUBMITTED:  ['IN_REVIEW'],
  IN_REVIEW:  ['COMPLETED', 'REJECTED'],
  COMPLETED:  [],
  REJECTED:   [],
  OVERDUE:    ['IN_REVIEW'],
};

const STATUS_META: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  SUBMITTED: { label: 'Submitted',  color: 'bg-blue-100 text-blue-700 border-blue-200',    icon: Clock },
  IN_REVIEW: { label: 'In Review',  color: 'bg-amber-100 text-amber-700 border-amber-200', icon: AlertCircle },
  COMPLETED: { label: 'Completed',  color: 'bg-green-100 text-green-700 border-green-200', icon: CheckCircle2 },
  REJECTED:  { label: 'Rejected',   color: 'bg-red-100 text-red-700 border-red-200',       icon: XCircle },
  OVERDUE:   { label: 'Overdue',    color: 'bg-rose-100 text-rose-700 border-rose-200',    icon: AlertCircle },
};

const TYPE_LABELS: Record<string, string> = {
  ACCESS: 'Data Access', RECTIFICATION: 'Rectification', DELETION: 'Deletion', PORTABILITY: 'Portability',
};

function StatusBadge({ status }: { status: string }) {
  const meta = STATUS_META[status] ?? { label: status, color: 'bg-gray-100 text-gray-700', icon: Clock };
  const Icon = meta.icon;
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${meta.color}`}>
      <Icon className="h-3 w-3" />
      {meta.label}
    </span>
  );
}

function daysUntil(dateStr: string) {
  const diff = Math.ceil((new Date(dateStr).getTime() - Date.now()) / 86400000);
  return diff;
}

/* ─── Detail Dialog ─────────────────────────────────────────────────────── */
function DsarDetailDialog({
  dsar,
  open,
  onClose,
  onRefresh,
}: {
  dsar: DsarRow | null;
  open: boolean;
  onClose: () => void;
  onRefresh: () => void;
}) {
  const [saving, setSaving] = useState(false);
  const [notes, setNotes] = useState('');
  const [targetStatus, setTargetStatus] = useState('');

  useEffect(() => {
    if (dsar) {
      setNotes(dsar.response_notes ?? '');
      setTargetStatus('');
    }
  }, [dsar]);

  if (!dsar) return null;

  const nextStatuses = STATUS_FLOW[dsar.request_status] ?? [];
  const empName = dsar.employee
    ? `${dsar.employee.first_name} ${dsar.employee.last_name}`
    : dsar.employee_id;

  const handleSaveNotes = async () => {
    setSaving(true);
    try {
      await dsarService.adminSaveNotes(dsar.dsar_id, notes);
      toast.success('Response notes saved');
      onRefresh();
    } catch { toast.error('Failed to save notes'); }
    finally { setSaving(false); }
  };

  const handleStatusChange = async () => {
    if (!targetStatus) return;
    setSaving(true);
    try {
      await dsarService.adminUpdateStatus(dsar.dsar_id, targetStatus, { response_notes: notes || undefined });
      toast.success(`DSAR status updated to ${STATUS_META[targetStatus]?.label ?? targetStatus}`);

      // Send in-app notification to the employee about their DSAR status change
      try {
        const STATUS_MESSAGES: Record<string, { title: string; message: string }> = {
          IN_REVIEW:  {
            title: '📋 Your DSAR Request is Under Review',
            message: `Your data subject access request (${dsar.request_type?.replace(/_/g,' ')}) is now being reviewed by our compliance team.`,
          },
          COMPLETED:  {
            title: '✅ Your DSAR Request is Complete',
            message: `Your data subject access request (${dsar.request_type?.replace(/_/g,' ')}) has been completed. Please check your DSAR portal for details.`,
          },
          REJECTED:   {
            title: '❌ Your DSAR Request Was Rejected',
            message: `Your data subject access request (${dsar.request_type?.replace(/_/g,' ')}) could not be fulfilled. Please contact HR for more information.`,
          },
          SUBMITTED:  {
            title: '📨 Your DSAR Request Has Been Received',
            message: `Your data subject access request (${dsar.request_type?.replace(/_/g,' ')}) has been received and is queued for review.`,
          },
        };
        const notif = STATUS_MESSAGES[targetStatus];
        if (notif && dsar.employee_id) {
          await notificationEngine.sendToUser({
            recipient_id:      dsar.employee_id,
            title:             notif.title,
            message:           notif.message,
            notification_type: 'DSAR_STATUS_UPDATED',
            module:            'dsar',
            reference_id:      dsar.dsar_id as unknown as string,
            action_url:        '/compliance/dsar',
          });
        }
      } catch { /* notification failure is non-critical */ }

      onRefresh();
      onClose();
    } catch { toast.error('Failed to update status'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={v => { if (!v) onClose(); }}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            DSAR Request — {TYPE_LABELS[dsar.request_type] ?? dsar.request_type}
          </DialogTitle>
        </DialogHeader>

        {/* Info grid */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground text-xs uppercase tracking-wide mb-0.5">Employee</p>
            <p className="font-semibold">{empName}</p>
            {dsar.employee?.employee_no && (
              <p className="text-xs text-muted-foreground">{dsar.employee.employee_no}</p>
            )}
          </div>
          <div>
            <p className="text-muted-foreground text-xs uppercase tracking-wide mb-0.5">Current Status</p>
            <StatusBadge status={dsar.request_status} />
          </div>
          <div>
            <p className="text-muted-foreground text-xs uppercase tracking-wide mb-0.5">Request Date</p>
            <p className="font-medium">{dsar.request_date}</p>
          </div>
          <div>
            <p className="text-muted-foreground text-xs uppercase tracking-wide mb-0.5">Deadline</p>
            <p className={`font-medium ${daysUntil(dsar.deadline_date) <= 3 ? 'text-destructive' : ''}`}>
              {dsar.deadline_date}
              <span className="text-xs text-muted-foreground ml-1.5">
                ({daysUntil(dsar.deadline_date)} days left)
              </span>
            </p>
          </div>
          {dsar.completion_date && (
            <div>
              <p className="text-muted-foreground text-xs uppercase tracking-wide mb-0.5">Completion Date</p>
              <p className="font-medium">{dsar.completion_date}</p>
            </div>
          )}
        </div>

        {/* Response notes */}
        <div className="space-y-1.5">
          <Label htmlFor="resp-notes">Response Notes</Label>
          <Textarea
            id="resp-notes"
            value={notes}
            onChange={e => setNotes(e.target.value)}
            placeholder="Add internal notes or response details…"
            rows={4}
            className="resize-none"
            disabled={dsar.request_status === 'COMPLETED' || dsar.request_status === 'REJECTED'}
          />
          {dsar.request_status !== 'COMPLETED' && dsar.request_status !== 'REJECTED' && (
            <Button size="sm" variant="outline" onClick={handleSaveNotes} disabled={saving}>
              Save Notes
            </Button>
          )}
        </div>

        {/* Status transition */}
        {nextStatuses.length > 0 && (
          <div className="space-y-2 border-t pt-4">
            <p className="text-sm font-medium">Move to Next Status</p>
            <div className="flex items-center gap-3">
              <Select value={targetStatus} onValueChange={setTargetStatus}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Select status…" />
                </SelectTrigger>
                <SelectContent>
                  {nextStatuses.map(s => (
                    <SelectItem key={s} value={s}>
                      {STATUS_META[s]?.label ?? s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                onClick={handleStatusChange}
                disabled={!targetStatus || saving}
                className="gap-1.5"
              >
                <ChevronRight className="h-4 w-4" />
                Update Status
              </Button>
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ─── KPI Card ─────────────────────────────────────────────────────────── */
function KpiCard({ label, value, icon: Icon, color }: { label: string; value: number; icon: React.ElementType; color: string }) {
  return (
    <Card className={`border-0 shadow-sm ${color}`}>
      <CardContent className="p-5 flex items-center gap-4">
        <div className="p-2.5 bg-white/40 rounded-xl">
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <p className="text-2xl font-bold">{value}</p>
          <p className="text-xs font-medium opacity-80">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}

/* ─── Main Page ─────────────────────────────────────────────────────────── */
/* ─── CronHistoryCard ────────────────────────────────────────────────────── */
type CronRun = {
  runid: number;
  jobid: number;
  job_pid: number | null;
  database: string;
  username: string;
  command: string;
  status: string;
  return_message: string;
  start_time: string;
  end_time: string | null;
};

function CronHistoryCard() {
  const [runs,    setRuns]    = useState<CronRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState<string | null>(null);

  const loadRuns = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: qErr } = await (supabase as unknown as {
        rpc: (fn: string, args: Record<string, unknown>) => Promise<{ data: unknown; error: unknown }>;
      }).rpc('get_dsar_cron_history', {});

      if (qErr) throw new Error((qErr as { message?: string }).message ?? 'Query failed');
      setRuns(Array.isArray(data) ? (data as CronRun[]) : []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load cron history');
      setRuns([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadRuns(); }, [loadRuns]);

  const fmtTs = (iso: string | null) => {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleString(undefined, { dateStyle: 'short', timeStyle: 'medium' });
  };

  const duration = (start: string, end: string | null) => {
    if (!end) return '—';
    const ms = new Date(end).getTime() - new Date(start).getTime();
    if (ms < 1000) return `${ms}ms`;
    return `${(ms / 1000).toFixed(1)}s`;
  };

  const statusBadge = (status: string) => {
    if (status === 'succeeded')
      return <Badge className="bg-green-100 text-green-800 font-medium text-xs"><CheckCircle2 className="h-3 w-3 mr-1" />Succeeded</Badge>;
    if (status === 'failed')
      return <Badge className="bg-red-100 text-red-800 font-medium text-xs"><XCircle className="h-3 w-3 mr-1" />Failed</Badge>;
    if (status === 'running')
      return <Badge className="bg-blue-100 text-blue-800 font-medium text-xs"><Clock className="h-3 w-3 mr-1" />Running</Badge>;
    return <Badge variant="secondary" className="text-xs">{status}</Badge>;
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <CalendarClock className="h-5 w-5 text-primary" />
            <CardTitle className="text-base">DSAR Reminder — Schedule History</CardTitle>
            <Badge variant="outline" className="text-xs font-mono">daily 08:00 UTC</Badge>
          </div>
          <Button variant="ghost" size="sm" onClick={loadRuns} disabled={loading} className="h-8 w-8 p-0" title="Refresh">
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
        <p className="text-sm text-muted-foreground mt-1">
          Last 10 runs of <span className="font-mono text-xs bg-muted px-1.5 py-0.5 rounded">dsar-deadline-reminder-daily</span> pg_cron job
        </p>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap pl-6">Run ID</TableHead>
                <TableHead className="whitespace-nowrap">Started At</TableHead>
                <TableHead className="whitespace-nowrap">Finished At</TableHead>
                <TableHead className="whitespace-nowrap">Duration</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap pr-6">Message</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <TableRow key={i}>
                    {Array.from({ length: 6 }).map((__, j) => (
                      <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>
                    ))}
                  </TableRow>
                ))
              ) : error ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-10 text-muted-foreground pl-6">
                    <AlertCircle className="h-6 w-6 mx-auto mb-2 text-amber-500" />
                    <p className="text-sm">{error}</p>
                    <p className="text-xs mt-1 text-muted-foreground/70">
                      pg_cron history requires the <span className="font-mono">get_dsar_cron_history</span> RPC function.
                    </p>
                  </TableCell>
                </TableRow>
              ) : runs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground pl-6">
                    <CalendarClock className="h-8 w-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">No runs recorded yet.</p>
                    <p className="text-xs mt-1">The job runs daily at 08:00 UTC. Check back after the first scheduled run.</p>
                  </TableCell>
                </TableRow>
              ) : (
                runs.map(r => (
                  <TableRow key={r.runid}>
                    <TableCell className="font-mono text-xs text-muted-foreground pl-6">#{r.runid}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtTs(r.start_time)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtTs(r.end_time)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm font-mono">{duration(r.start_time, r.end_time)}</TableCell>
                    <TableCell className="whitespace-nowrap">{statusBadge(r.status)}</TableCell>
                    <TableCell className="max-w-xs truncate text-xs text-muted-foreground pr-6" title={r.return_message}>
                      {r.return_message || '—'}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}

export function DsarAdminPage() {
  const [rows, setRows] = useState<DsarRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 15;

  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<DsarRow | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await dsarService.list({
        request_status: filterStatus !== 'all' ? filterStatus : undefined,
        page,
        pageSize: PAGE_SIZE,
      });
      let data = res.data as DsarRow[];
      if (filterType !== 'all') data = data.filter(r => r.request_type === filterType);
      if (search.trim()) {
        const q = search.toLowerCase();
        data = data.filter(r => {
          const emp = r.employee;
          if (!emp) return false;
          return `${emp.first_name} ${emp.last_name}`.toLowerCase().includes(q) ||
            (emp.employee_no ?? '').toLowerCase().includes(q);
        });
      }
      setRows(data);
      setTotal(res.total);
    } catch { toast.error('Failed to load DSAR requests'); }
    finally { setLoading(false); }
  }, [filterStatus, filterType, search, page]);

  useEffect(() => { load(); }, [load]);

  // KPI counts
  const kpis = {
    submitted: rows.filter(r => r.request_status === 'SUBMITTED').length,
    inReview:  rows.filter(r => r.request_status === 'IN_REVIEW').length,
    completed: rows.filter(r => r.request_status === 'COMPLETED').length,
    overdue:   rows.filter(r => r.request_status === 'OVERDUE' || daysUntil(r.deadline_date) < 0).length,
  };

  const openDetail = (row: DsarRow) => { setSelected(row); setDialogOpen(true); };
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="space-y-6 p-1">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">DSAR Admin Workflow</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Manage Data Subject Access Requests — process, respond, and close
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load} className="gap-1.5">
          <RefreshCw className="h-4 w-4" />Refresh
        </Button>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <KpiCard label="Awaiting Review"   value={kpis.submitted}  icon={Clock}        color="bg-blue-50 text-blue-800" />
        <KpiCard label="In Review"          value={kpis.inReview}   icon={AlertCircle}  color="bg-amber-50 text-amber-800" />
        <KpiCard label="Completed"          value={kpis.completed}  icon={CheckCircle2} color="bg-green-50 text-green-800" />
        <KpiCard label="Overdue / At Risk"  value={kpis.overdue}    icon={XCircle}      color="bg-red-50 text-red-800" />
      </div>

      {/* Filters */}
      <Card className="shadow-sm">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={search}
                onChange={e => { setSearch(e.target.value); setPage(1); }}
                placeholder="Search employee name or ID…"
                className="pl-9"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <Select value={filterStatus} onValueChange={v => { setFilterStatus(v); setPage(1); }}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="SUBMITTED">Submitted</SelectItem>
                  <SelectItem value="IN_REVIEW">In Review</SelectItem>
                  <SelectItem value="COMPLETED">Completed</SelectItem>
                  <SelectItem value="REJECTED">Rejected</SelectItem>
                  <SelectItem value="OVERDUE">Overdue</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterType} onValueChange={v => { setFilterType(v); setPage(1); }}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="ACCESS">Data Access</SelectItem>
                  <SelectItem value="RECTIFICATION">Rectification</SelectItem>
                  <SelectItem value="DELETION">Deletion</SelectItem>
                  <SelectItem value="PORTABILITY">Portability</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <p className="text-sm text-muted-foreground ml-auto">{total} total</p>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="shadow-sm">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40">
                  <TableHead>Employee</TableHead>
                  <TableHead>Request Type</TableHead>
                  <TableHead>Request Date</TableHead>
                  <TableHead>Deadline</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Response Notes</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading
                  ? Array.from({ length: 6 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 7 }).map((__, j) => (
                        <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                  : rows.length === 0
                  ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-16 text-muted-foreground">
                        <Users className="h-10 w-10 mx-auto mb-3 opacity-30" />
                        No DSAR requests found
                      </TableCell>
                    </TableRow>
                  )
                  : rows.map(row => {
                    const emp = row.employee;
                    const daysLeft = daysUntil(row.deadline_date);
                    const isUrgent = daysLeft <= 3 && !['COMPLETED', 'REJECTED'].includes(row.request_status);
                    return (
                      <TableRow
                        key={row.dsar_id}
                        className="cursor-pointer hover:bg-muted/40 transition-colors"
                        onClick={() => openDetail(row)}
                      >
                        <TableCell>
                          <div>
                            <p className="font-medium">{emp ? `${emp.first_name} ${emp.last_name}` : '—'}</p>
                            {emp?.employee_no && <p className="text-xs text-muted-foreground">{emp.employee_no}</p>}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs">
                            {TYPE_LABELS[row.request_type] ?? row.request_type}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">{row.request_date}</TableCell>
                        <TableCell>
                          <span className={`text-sm font-medium ${isUrgent ? 'text-destructive' : ''}`}>
                            {row.deadline_date}
                          </span>
                          {isUrgent && (
                            <p className="text-xs text-destructive">{daysLeft <= 0 ? 'Overdue!' : `${daysLeft}d left`}</p>
                          )}
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={row.request_status} />
                        </TableCell>
                        <TableCell className="max-w-xs">
                          <p className="text-xs text-muted-foreground line-clamp-2">
                            {row.response_notes ?? <span className="italic opacity-60">No notes yet</span>}
                          </p>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="gap-1.5"
                            onClick={e => { e.stopPropagation(); openDetail(row); }}
                          >
                            <Eye className="h-4 w-4" />
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                }
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t">
              <p className="text-sm text-muted-foreground">Page {page} of {totalPages}</p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
                <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detail dialog */}
      <DsarDetailDialog
        dsar={selected}
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        onRefresh={load}
      />

      {/* pg_cron run history */}
      <CronHistoryCard />
    </div>
  );
}
