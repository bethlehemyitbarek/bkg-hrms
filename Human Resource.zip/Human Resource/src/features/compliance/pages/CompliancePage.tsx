import { useState, useEffect, useCallback } from 'react';
import { complianceService } from '@/services/modules.service';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, ShieldCheck, FileWarning, GitMerge, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

const STATUS_COLORS: Record<string, string> = {
  active: 'bg-green-100 text-green-800',
  draft: 'bg-muted text-muted-foreground',
  expired: 'bg-red-100 text-red-800',
  archived: 'bg-muted text-muted-foreground',
};

export function CompliancePage() {
  const [requirements, setRequirements] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [dialog, setDialog] = useState(false);
  const [saving, setSaving] = useState(false);
  // DB columns: code, title, description, category, version, effective_date, expiry_date, document_url, status
  const [form, setForm] = useState({
    code: '', title: '', description: '',
    category: 'policy', version: '1.0',
    effective_date: '', expiry_date: '', status: 'active',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await complianceService.listPolicies({ page: 1, pageSize: 30 });
      setRequirements(res.data as Record<string, unknown>[]);
      setTotal(res.total);
    } catch { toast.error('Failed to load compliance requirements'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await complianceService.createPolicy({
        code: form.code,
        title: form.title,
        description: form.description || null,
        category: form.category,
        version: form.version,
        effective_date: form.effective_date || null,
        expiry_date: form.expiry_date || null,
        status: form.status,
      });
      toast.success('Compliance requirement created');
      setDialog(false);
      setForm({ code: '', title: '', description: '', category: 'policy', version: '1.0', effective_date: '', expiry_date: '', status: 'active' });
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to create compliance requirement'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-primary" />Compliance</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} policies &amp; requirements</p>
        </div>
        <Dialog open={dialog} onOpenChange={setDialog}>
          <DialogTrigger asChild>
            <Button size="sm"><Plus className="h-4 w-4 mr-1.5" />Add Requirement</Button>
          </DialogTrigger>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
            <DialogHeader><DialogTitle>New Compliance Requirement</DialogTitle></DialogHeader>
            <form onSubmit={handleCreate} className="space-y-4 mt-2">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>Code *</Label><Input value={form.code} onChange={e => setForm(p => ({ ...p, code: e.target.value }))} required placeholder="e.g. COMP-001" /></div>
                <div className="space-y-1.5"><Label>Version</Label><Input value={form.version} onChange={e => setForm(p => ({ ...p, version: e.target.value }))} placeholder="1.0" /></div>
              </div>
              <div className="space-y-1.5"><Label>Title *</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} required /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Category</Label>
                  <Select value={form.category} onValueChange={v => setForm(p => ({ ...p, category: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="policy">Policy</SelectItem>
                      <SelectItem value="regulation">Regulation</SelectItem>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="procedure">Procedure</SelectItem>
                      <SelectItem value="training">Training</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Status</Label>
                  <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="expired">Expired</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>Effective Date</Label><Input type="date" value={form.effective_date} onChange={e => setForm(p => ({ ...p, effective_date: e.target.value }))} /></div>
                <div className="space-y-1.5"><Label>Expiry Date</Label><Input type="date" value={form.expiry_date} onChange={e => setForm(p => ({ ...p, expiry_date: e.target.value }))} /></div>
              </div>
              <div className="space-y-1.5"><Label>Description</Label><Textarea rows={3} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></div>
              <Button type="submit" className="w-full" disabled={saving}>{saving ? 'Saving…' : 'Create Requirement'}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="requirements">
        <TabsList className="flex-wrap gap-1 h-auto">
          <TabsTrigger value="requirements" className="gap-1.5"><ShieldCheck className="h-3.5 w-3.5" />Requirements</TabsTrigger>
          <TabsTrigger value="warning-templates" className="gap-1.5"><FileWarning className="h-3.5 w-3.5" />Warning Templates</TabsTrigger>
          <TabsTrigger value="progressive-discipline" className="gap-1.5"><GitMerge className="h-3.5 w-3.5" />Progressive Discipline</TabsTrigger>
        </TabsList>

        {/* ── Existing requirements table ── */}
        <TabsContent value="requirements" className="mt-4">
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Code</TableHead>
                    <TableHead className="whitespace-nowrap">Title</TableHead>
                    <TableHead className="whitespace-nowrap">Category</TableHead>
                    <TableHead className="whitespace-nowrap">Version</TableHead>
                    <TableHead className="whitespace-nowrap">Effective Date</TableHead>
                    <TableHead className="whitespace-nowrap">Expiry Date</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 7 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                    : requirements.length === 0 ? <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">No compliance requirements found</TableCell></TableRow>
                    : requirements.map(r => (
                      <TableRow key={String(r.id)}>
                        <TableCell className="whitespace-nowrap text-sm font-mono">{r.code ? String(r.code) : '—'}</TableCell>
                        <TableCell className="whitespace-nowrap font-medium">{String(r.title)}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm capitalize">{String(r.category)}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{r.version ? String(r.version) : '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{r.effective_date ? String(r.effective_date) : '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{r.expiry_date ? String(r.expiry_date) : '—'}</TableCell>
                        <TableCell className="whitespace-nowrap"><Badge className={STATUS_COLORS[String(r.status)] || 'bg-muted'}>{String(r.status)}</Badge></TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── FR-CG-012: Warning Letter Templates ── */}
        <TabsContent value="warning-templates" className="mt-4">
          <WarningTemplatesTab />
        </TabsContent>

        {/* ── FR-CG-013: Progressive Discipline ── */}
        <TabsContent value="progressive-discipline" className="mt-4">
          <ProgressiveDisciplineTab />
        </TabsContent>

      </Tabs>
    </div>
  );
}
export default CompliancePage;

/* ─────────────────────────────────────────────────────────────────────────
   FR-CG-012 – Warning Letter Templates
   ───────────────────────────────────────────────────────────────────────── */
type WLTemplate = { template_id?: string; template_name: string; warning_level: string; subject?: string; body_template?: string; created_at?: string };

function WarningTemplatesTab() {
  const [rows, setRows] = useState<WLTemplate[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [preview, setPreview] = useState<WLTemplate | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ template_name: '', warning_level: 'VERBAL', subject: '', body_template: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('warning_letter_templates').select('*').order('created_at', { ascending: false }).limit(50);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.template_name.trim()) { toast.error('Template name required'); return; }
    setSaving(true);
    const { error } = await sb.from('warning_letter_templates').insert({ template_name: form.template_name, warning_level: form.warning_level, subject: form.subject || null, body_template: form.body_template || null });
    if (error) toast.error(error.message); else { toast.success('Template saved'); setOpen(false); setForm({ template_name: '', warning_level: 'VERBAL', subject: '', body_template: '' }); load(); }
    setSaving(false);
  };

  const LEVEL_BADGE: Record<string, string> = { VERBAL: 'bg-yellow-100 text-yellow-800', WRITTEN: 'bg-orange-100 text-orange-800', FINAL: 'bg-red-100 text-red-800', TERMINATION: 'bg-red-200 text-red-900' };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><FileWarning className="h-4 w-4" />Warning Letter Templates (FR-CG-012)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />New Template</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">No warning letter templates created yet</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Template Name</TableHead>
                <TableHead className="whitespace-nowrap">Level</TableHead>
                <TableHead className="whitespace-nowrap">Subject</TableHead>
                <TableHead className="whitespace-nowrap">Created</TableHead>
                <TableHead className="whitespace-nowrap">Actions</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r, i) => (
                  <TableRow key={r.template_id || i}>
                    <TableCell className="whitespace-nowrap font-medium">{r.template_name}</TableCell>
                    <TableCell><Badge className={LEVEL_BADGE[r.warning_level] || 'bg-muted'}>{r.warning_level}</Badge></TableCell>
                    <TableCell className="max-w-[200px] truncate text-sm">{r.subject || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{r.created_at ? new Date(r.created_at).toLocaleDateString() : '—'}</TableCell>
                    <TableCell>
                      <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setPreview(r)}>Preview</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      {/* Create Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>New Warning Letter Template</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Template Name *</Label><Input value={form.template_name} onChange={e => setForm(p => ({ ...p, template_name: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Warning Level</Label>
                <Select value={form.warning_level} onValueChange={v => setForm(p => ({ ...p, warning_level: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="VERBAL">Verbal Warning</SelectItem>
                    <SelectItem value="WRITTEN">Written Warning</SelectItem>
                    <SelectItem value="FINAL">Final Warning</SelectItem>
                    <SelectItem value="TERMINATION">Termination Notice</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5"><Label>Email Subject</Label><Input value={form.subject} onChange={e => setForm(p => ({ ...p, subject: e.target.value }))} placeholder="e.g. Warning Notice – {employee_name}" /></div>
            <div className="space-y-1.5">
              <Label>Letter Body</Label>
              <p className="text-xs text-muted-foreground">Use placeholders: {'{employee_name}'}, {'{date}'}, {'{manager_name}'}, {'{incident_description}'}</p>
              <Textarea rows={8} className="font-mono text-sm" value={form.body_template} onChange={e => setForm(p => ({ ...p, body_template: e.target.value }))} placeholder="Dear {employee_name},&#10;&#10;This letter serves as formal notice…" />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save Template</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={!!preview} onOpenChange={() => setPreview(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>{preview?.template_name}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            {preview?.subject && <div className="rounded bg-muted/50 px-3 py-2 text-sm"><strong>Subject:</strong> {preview.subject}</div>}
            <div className="rounded border border-border p-4 whitespace-pre-wrap font-mono text-sm min-h-[200px] bg-card">
              {preview?.body_template || '(No body content)'}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-CG-013 – Progressive Discipline Tracker
   ───────────────────────────────────────────────────────────────────────── */
type PDRow = { pd_id?: string; employee_id: string; full_name?: string; incident_date?: string; incident_type?: string; action_taken: string; issued_by?: string; notes?: string; status?: string };

function ProgressiveDisciplineTab() {
  const [rows, setRows] = useState<PDRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ employee_id: '', full_name: '', incident_date: '', incident_type: 'ATTENDANCE', action_taken: 'VERBAL_WARNING', issued_by: '', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('progressive_discipline').select('*').order('incident_date', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.employee_id || !form.action_taken) { toast.error('Employee ID and action are required'); return; }
    setSaving(true);
    const { error } = await sb.from('progressive_discipline').insert({ employee_id: form.employee_id, full_name: form.full_name || null, incident_date: form.incident_date || new Date().toISOString().slice(0, 10), incident_type: form.incident_type, action_taken: form.action_taken, issued_by: form.issued_by || null, notes: form.notes || null, status: 'ACTIVE' });
    if (error) toast.error(error.message); else { toast.success('Discipline record created'); setOpen(false); load(); }
    setSaving(false);
  };

  const ACTION_BADGE: Record<string, string> = { VERBAL_WARNING: 'bg-yellow-100 text-yellow-800', WRITTEN_WARNING: 'bg-orange-100 text-orange-800', FINAL_WARNING: 'bg-red-100 text-red-800', SUSPENSION: 'bg-purple-100 text-purple-800', TERMINATION: 'bg-red-200 text-red-900' };
  const INCIDENT_TYPES = ['ATTENDANCE', 'CONDUCT', 'PERFORMANCE', 'POLICY_VIOLATION', 'INSUBORDINATION', 'OTHER'];
  const ACTION_TYPES = ['VERBAL_WARNING', 'WRITTEN_WARNING', 'FINAL_WARNING', 'SUSPENSION', 'TERMINATION'];

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><GitMerge className="h-4 w-4" />Progressive Discipline (FR-CG-013)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add Record</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">No discipline records</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Incident Date</TableHead>
                <TableHead className="whitespace-nowrap">Incident Type</TableHead>
                <TableHead className="whitespace-nowrap">Action Taken</TableHead>
                <TableHead className="whitespace-nowrap">Issued By</TableHead>
                <TableHead className="whitespace-nowrap">Notes</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r, i) => (
                  <TableRow key={r.pd_id || i}>
                    <TableCell className="whitespace-nowrap font-medium">{r.full_name || String(r.employee_id).slice(0, 8)}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.incident_date || '—'}</TableCell>
                    <TableCell><Badge variant="outline">{(r.incident_type || '—').replace(/_/g, ' ')}</Badge></TableCell>
                    <TableCell><Badge className={ACTION_BADGE[r.action_taken] || 'bg-muted'}>{r.action_taken.replace(/_/g, ' ')}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap">{r.issued_by || '—'}</TableCell>
                    <TableCell className="max-w-[200px] truncate text-sm text-muted-foreground">{r.notes || '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Record Disciplinary Action</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Employee ID *</Label><Input value={form.employee_id} onChange={e => setForm(p => ({ ...p, employee_id: e.target.value }))} placeholder="UUID" /></div>
              <div className="space-y-1.5"><Label>Full Name</Label><Input value={form.full_name} onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Incident Type</Label>
                <Select value={form.incident_type} onValueChange={v => setForm(p => ({ ...p, incident_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{INCIDENT_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace(/_/g, ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Action Taken *</Label>
                <Select value={form.action_taken} onValueChange={v => setForm(p => ({ ...p, action_taken: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{ACTION_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace(/_/g, ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Incident Date</Label><Input type="date" value={form.incident_date} onChange={e => setForm(p => ({ ...p, incident_date: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Issued By</Label><Input value={form.issued_by} onChange={e => setForm(p => ({ ...p, issued_by: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Notes</Label><Textarea rows={3} value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
