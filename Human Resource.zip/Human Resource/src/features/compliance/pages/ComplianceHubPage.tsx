import { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck, Plus, Pencil, Trash2, RefreshCw, Eye,
  ClipboardList, AlertTriangle, MessageSquare, Database, BookOpen,
  FileWarning, GitMerge, Gavel, Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { supabase } from '@/db/supabase';
import {
  hrPolicyService,
  policyAckService,
  disciplinaryCaseService,
  disciplinaryActionService,
  grievanceCaseService,
  dataRetentionService,
  dsarService,
} from '@/services/compliance.service';

// ─── helpers ────────────────────────────────────────────────────────────────
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Row = Record<string, any>;

function fmtDate(v?: string | null) {
  if (!v) return '—';
  return new Date(v).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

const SKEL = (cols: number, rows = 5) =>
  Array.from({ length: rows }).map((_, i) => (
    <TableRow key={i}>
      {Array.from({ length: cols }).map((__, j) => (
        <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>
      ))}
    </TableRow>
  ));

const EMPTY = (cols: number, msg: string) => (
  <TableRow>
    <TableCell colSpan={cols} className="text-center py-12 text-muted-foreground text-sm">{msg}</TableCell>
  </TableRow>
);

// ─── Badge helpers ─────────────────────────────────────────────────────────────
const DIST_STATUS: Record<string, string> = {
  DRAFT:     'bg-muted text-muted-foreground',
  PUBLISHED: 'bg-green-100 text-green-700',
  ARCHIVED:  'bg-slate-100 text-slate-500',
};
const GRIEV_STAGE: Record<string, string> = {
  SUBMITTED:     'bg-blue-100 text-blue-700',
  UNDER_REVIEW:  'bg-yellow-100 text-yellow-700',
  INVESTIGATION: 'bg-orange-100 text-orange-700',
  RESOLVED:      'bg-green-100 text-green-700',
  CLOSED:        'bg-slate-100 text-slate-500',
};
const DSAR_STATUS: Record<string, string> = {
  SUBMITTED:   'bg-blue-100 text-blue-700',
  IN_PROGRESS: 'bg-yellow-100 text-yellow-700',
  COMPLETED:   'bg-green-100 text-green-700',
  OVERDUE:     'bg-red-100 text-red-700',
};
const CASE_STATUS: Record<string, string> = {
  OPEN:   'bg-orange-100 text-orange-700',
  CLOSED: 'bg-slate-100 text-slate-500',
};
const EXEC_STATUS: Record<string, string> = {
  SCHEDULED: 'bg-blue-100 text-blue-700',
  EXECUTED:  'bg-green-100 text-green-700',
  PAUSED:    'bg-yellow-100 text-yellow-700',
};

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 1 — HR Policies
// ═══════════════════════════════════════════════════════════════════════════════
function PoliciesTab() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [filter, setFilter] = useState('all');
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Row | null>(null);
  const [deleting, setDeleting] = useState<Row | null>(null);
  const [ackTarget, setAckTarget] = useState<Row | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    policy_title: '', policy_code: '', policy_category: '',
    version_number: '1.0', distribution_scope: 'ALL_EMPLOYEES',
    distribution_status: 'DRAFT', effective_date: '',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await hrPolicyService.list({ distribution_status: filter, page: 1, pageSize: 50 });
      setRows(r.data); setTotal(r.total);
    } catch { toast.error('Failed to load HR policies'); }
    finally { setLoading(false); }
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm({ policy_title: '', policy_code: '', policy_category: '', version_number: '1.0', distribution_scope: 'ALL_EMPLOYEES', distribution_status: 'DRAFT', effective_date: '' });
    setOpen(true);
  };
  const openEdit = (row: Row) => {
    setEditing(row);
    setForm({
      policy_title: row.policy_title ?? '',
      policy_code: row.policy_code ?? '',
      policy_category: row.policy_category ?? '',
      version_number: row.version_number ?? '1.0',
      distribution_scope: row.distribution_scope ?? 'ALL_EMPLOYEES',
      distribution_status: row.distribution_status ?? 'DRAFT',
      effective_date: row.effective_date ?? '',
    });
    setOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.policy_title || !form.policy_code) { toast.error('Title and Code are required'); return; }
    setSaving(true);
    try {
      const payload = { ...form, effective_date: form.effective_date || null };
      if (editing) await hrPolicyService.update(editing.policy_id, payload);
      else await hrPolicyService.create(payload);
      toast.success(editing ? 'Policy updated' : 'Policy created');
      setOpen(false); load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!deleting) return;
    try {
      await hrPolicyService.delete(deleting.policy_id);
      toast.success('Policy deleted'); setDeleting(null); load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Delete failed'); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <p className="text-sm text-muted-foreground">{total} policies</p>
        <div className="flex items-center gap-2">
          <Select value={filter} onValueChange={v => { setFilter(v); }}>
            <SelectTrigger className="h-8 w-36 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="DRAFT">Draft</SelectItem>
              <SelectItem value="PUBLISHED">Published</SelectItem>
              <SelectItem value="ARCHIVED">Archived</SelectItem>
            </SelectContent>
          </Select>
          <Button size="sm" className="h-8" onClick={openCreate}><Plus className="h-3.5 w-3.5 mr-1" />Add Policy</Button>
          <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={load}><RefreshCw className="h-3.5 w-3.5" /></Button>
        </div>
      </div>

      <div className="rounded border border-border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="text-xs">
              <TableHead className="whitespace-nowrap">Code</TableHead>
              <TableHead className="whitespace-nowrap">Title</TableHead>
              <TableHead className="whitespace-nowrap">Category</TableHead>
              <TableHead className="whitespace-nowrap">Version</TableHead>
              <TableHead className="whitespace-nowrap">Scope</TableHead>
              <TableHead className="whitespace-nowrap">Status</TableHead>
              <TableHead className="whitespace-nowrap">Effective</TableHead>
              <TableHead className="whitespace-nowrap w-24">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? SKEL(8) : rows.length === 0 ? EMPTY(8, 'No policies found') : rows.map(r => (
              <TableRow key={r.policy_id} className="text-sm">
                <TableCell className="whitespace-nowrap font-mono text-xs">{r.policy_code}</TableCell>
                <TableCell className="whitespace-nowrap font-medium max-w-[200px] truncate">{r.policy_title}</TableCell>
                <TableCell className="whitespace-nowrap text-xs">{r.policy_category || '—'}</TableCell>
                <TableCell className="whitespace-nowrap text-xs">{r.version_number}</TableCell>
                <TableCell className="whitespace-nowrap text-xs">{r.distribution_scope?.replace('_', ' ') || '—'}</TableCell>
                <TableCell className="whitespace-nowrap">
                  <Badge className={`text-xs ${DIST_STATUS[r.distribution_status] ?? 'bg-muted'}`}>{r.distribution_status}</Badge>
                </TableCell>
                <TableCell className="whitespace-nowrap text-xs">{fmtDate(r.effective_date)}</TableCell>
                <TableCell className="whitespace-nowrap">
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => setAckTarget(r)} title="View acknowledgments"><Eye className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleting(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Create / Edit Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editing ? 'Edit Policy' : 'New HR Policy'}</DialogTitle></DialogHeader>
          <form onSubmit={handleSave} className="space-y-4 py-1">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5 col-span-2"><Label>Title <span className="text-destructive">*</span></Label><Input value={form.policy_title} onChange={e => setForm(p => ({ ...p, policy_title: e.target.value }))} required /></div>
              <div className="space-y-1.5"><Label>Code <span className="text-destructive">*</span></Label><Input value={form.policy_code} onChange={e => setForm(p => ({ ...p, policy_code: e.target.value }))} required placeholder="e.g. POL-001" /></div>
              <div className="space-y-1.5"><Label>Version</Label><Input value={form.version_number} onChange={e => setForm(p => ({ ...p, version_number: e.target.value }))} placeholder="1.0" /></div>
              <div className="space-y-1.5"><Label>Category</Label><Input value={form.policy_category} onChange={e => setForm(p => ({ ...p, policy_category: e.target.value }))} placeholder="e.g. Code of Conduct" /></div>
              <div className="space-y-1.5"><Label>Effective Date</Label><Input type="date" value={form.effective_date} onChange={e => setForm(p => ({ ...p, effective_date: e.target.value }))} /></div>
              <div className="space-y-1.5">
                <Label>Distribution Scope</Label>
                <Select value={form.distribution_scope} onValueChange={v => setForm(p => ({ ...p, distribution_scope: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ALL_EMPLOYEES">All Employees</SelectItem>
                    <SelectItem value="DEPARTMENT">Department</SelectItem>
                    <SelectItem value="ROLE">Role</SelectItem>
                    <SelectItem value="CUSTOM">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Status</Label>
                <Select value={form.distribution_status} onValueChange={v => setForm(p => ({ ...p, distribution_status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DRAFT">Draft</SelectItem>
                    <SelectItem value="PUBLISHED">Published</SelectItem>
                    <SelectItem value="ARCHIVED">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" type="button" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Acknowledgments Drawer */}
      <AckDialog policy={ackTarget} onClose={() => setAckTarget(null)} />

      {/* Delete confirm */}
      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Policy</AlertDialogTitle>
            <AlertDialogDescription>Delete <strong>{deleting?.policy_title}</strong>? This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive hover:bg-destructive/90" onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function AckDialog({ policy, onClose }: { policy: Row | null; onClose: () => void }) {
  const [acks, setAcks] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!policy) return;
    setLoading(true);
    policyAckService.list(policy.policy_id)
      .then((d: Row[]) => setAcks(d))
      .catch(() => toast.error('Failed to load acknowledgments'))
      .finally(() => setLoading(false));
  }, [policy]);

  return (
    <Dialog open={!!policy} onOpenChange={o => !o && onClose()}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
        <DialogHeader><DialogTitle>Acknowledgments — {policy?.policy_title}</DialogTitle></DialogHeader>
        <div className="rounded border border-border overflow-x-auto max-h-96">
          <Table>
            <TableHeader>
              <TableRow className="text-xs">
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Acknowledged At</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? SKEL(3, 3) : acks.length === 0 ? EMPTY(3, 'No acknowledgments yet') : acks.map(a => (
                <TableRow key={a.acknowledgment_id} className="text-sm">
                  <TableCell className="whitespace-nowrap">{a.employee ? `${a.employee.first_name} ${a.employee.last_name}` : a.employee_id.slice(0, 8)}</TableCell>
                  <TableCell><Badge className={a.acknowledgment_status === 'ACKNOWLEDGED' ? 'bg-green-100 text-green-700 text-xs' : 'bg-yellow-100 text-yellow-700 text-xs'}>{a.acknowledgment_status}</Badge></TableCell>
                  <TableCell className="whitespace-nowrap text-xs">{fmtDate(a.acknowledged_at)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <DialogFooter><Button variant="outline" onClick={onClose}>Close</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 2 — Disciplinary
// ═══════════════════════════════════════════════════════════════════════════════
function DisciplinaryTab() {
  const [cases, setCases] = useState<Row[]>([]);
  const [actions, setActions] = useState<Row[]>([]);
  const [loadingC, setLoadingC] = useState(true);
  const [loadingA, setLoadingA] = useState(true);
  const [totalC, setTotalC] = useState(0);
  const [totalA, setTotalA] = useState(0);
  const [statusFilter, setStatusFilter] = useState('all');

  // case dialog
  const [caseOpen, setCaseOpen] = useState(false);
  const [editCase, setEditCase] = useState<Row | null>(null);
  const [deletingCase, setDeletingCase] = useState<Row | null>(null);
  const [caseForm, setCaseForm] = useState({ employee_id: '', case_title: '', description: '' });

  // action dialog
  const [actionOpen, setActionOpen] = useState(false);
  const [editAction, setEditAction] = useState<Row | null>(null);
  const [deletingAction, setDeletingAction] = useState<Row | null>(null);
  const [actionForm, setActionForm] = useState({
    employee_id: '', discipline_case_id: '', action_type: 'WARNING',
    action_reason: '', related_to: '', action_date: '', case_status: 'OPEN',
  });
  const [saving, setSaving] = useState(false);

  const loadCases = useCallback(async () => {
    setLoadingC(true);
    try {
      const r = await disciplinaryCaseService.list({ page: 1, pageSize: 50 });
      setCases(r.data); setTotalC(r.total);
    } catch { toast.error('Failed to load disciplinary cases'); }
    finally { setLoadingC(false); }
  }, []);

  const loadActions = useCallback(async () => {
    setLoadingA(true);
    try {
      const r = await disciplinaryActionService.list({ case_status: statusFilter, page: 1, pageSize: 50 });
      setActions(r.data); setTotalA(r.total);
    } catch { toast.error('Failed to load disciplinary actions'); }
    finally { setLoadingA(false); }
  }, [statusFilter]);

  useEffect(() => { loadCases(); loadActions(); }, [loadCases, loadActions]);

  const openCreateCase = () => { setEditCase(null); setCaseForm({ employee_id: '', case_title: '', description: '' }); setCaseOpen(true); };
  const openEditCase = (r: Row) => { setEditCase(r); setCaseForm({ employee_id: r.employee_id, case_title: r.case_title ?? '', description: r.description ?? '' }); setCaseOpen(true); };

  const saveCase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!caseForm.employee_id) { toast.error('Employee is required'); return; }
    setSaving(true);
    try {
      if (editCase) {
        await disciplinaryCaseService.create({ ...caseForm }); // no update endpoint — just create is shown
        toast.info('Use delete + recreate to update cases');
      } else {
        await disciplinaryCaseService.create(caseForm);
        toast.success('Disciplinary case created');
      }
      setCaseOpen(false); loadCases();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  const openCreateAction = () => {
    setEditAction(null);
    setActionForm({ employee_id: '', discipline_case_id: '', action_type: 'WARNING', action_reason: '', related_to: '', action_date: new Date().toISOString().slice(0, 10), case_status: 'OPEN' });
    setActionOpen(true);
  };
  const openEditAction = (r: Row) => {
    setEditAction(r);
    setActionForm({
      employee_id: r.employee_id, discipline_case_id: r.discipline_case_id ?? '',
      action_type: r.action_type, action_reason: r.action_reason ?? '',
      related_to: r.related_to ?? '', action_date: r.action_date ?? '',
      case_status: r.case_status,
    });
    setActionOpen(true);
  };

  const saveAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!actionForm.employee_id || !actionForm.action_reason || !actionForm.action_date) {
      toast.error('Employee, reason, and date are required'); return;
    }
    setSaving(true);
    try {
      const payload = { ...actionForm, issued_by: actionForm.employee_id };
      if (editAction) await disciplinaryActionService.update(editAction.disciplinary_action_id, payload);
      else await disciplinaryActionService.create(payload);
      toast.success(editAction ? 'Action updated' : 'Action recorded');
      setActionOpen(false); loadActions();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-6">
      {/* Cases */}
      <Card>
        <CardHeader className="pb-3 flex-row items-center justify-between">
          <CardTitle className="text-sm font-semibold">Disciplinary Cases <span className="text-muted-foreground font-normal">({totalC})</span></CardTitle>
          <Button size="sm" className="h-7 text-xs" onClick={openCreateCase}><Plus className="h-3 w-3 mr-1" />New Case</Button>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="rounded border border-border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="text-xs">
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Title</TableHead>
                  <TableHead className="whitespace-nowrap">Description</TableHead>
                  <TableHead className="whitespace-nowrap">Reported By</TableHead>
                  <TableHead className="whitespace-nowrap">Created</TableHead>
                  <TableHead className="whitespace-nowrap w-20">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadingC ? SKEL(6) : cases.length === 0 ? EMPTY(6, 'No disciplinary cases') : cases.map(r => (
                  <TableRow key={r.disciplinary_case_id} className="text-sm">
                    <TableCell className="whitespace-nowrap">{r.employee ? `${r.employee.first_name} ${r.employee.last_name}` : r.employee_id?.slice(0, 8)}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">{r.case_title || '—'}</TableCell>
                    <TableCell className="max-w-[200px] truncate text-xs text-muted-foreground">{r.description || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-xs">{r.reported_by?.slice(0, 8) || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-xs">{fmtDate(r.created_at)}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <div className="flex gap-1">
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEditCase(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeletingCase(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <Card>
        <CardHeader className="pb-3 flex-row items-center justify-between flex-wrap gap-2">
          <CardTitle className="text-sm font-semibold">Disciplinary Actions <span className="text-muted-foreground font-normal">({totalA})</span></CardTitle>
          <div className="flex gap-2">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="h-7 w-28 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="OPEN">Open</SelectItem>
                <SelectItem value="CLOSED">Closed</SelectItem>
              </SelectContent>
            </Select>
            <Button size="sm" className="h-7 text-xs" onClick={openCreateAction}><Plus className="h-3 w-3 mr-1" />New Action</Button>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="rounded border border-border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="text-xs">
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Type</TableHead>
                  <TableHead className="whitespace-nowrap">Reason</TableHead>
                  <TableHead className="whitespace-nowrap">Date</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap w-20">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadingA ? SKEL(6) : actions.length === 0 ? EMPTY(6, 'No disciplinary actions') : actions.map(r => (
                  <TableRow key={r.disciplinary_action_id} className="text-sm">
                    <TableCell className="whitespace-nowrap">{r.employee ? `${r.employee.first_name} ${r.employee.last_name}` : r.employee_id?.slice(0, 8)}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={r.action_type === 'WARNING' ? 'bg-yellow-100 text-yellow-700 text-xs' : r.action_type === 'TERMINATION' ? 'bg-red-100 text-red-700 text-xs' : 'bg-orange-100 text-orange-700 text-xs'}>{r.action_type}</Badge></TableCell>
                    <TableCell className="max-w-[200px] truncate text-xs">{r.action_reason}</TableCell>
                    <TableCell className="whitespace-nowrap text-xs">{fmtDate(r.action_date)}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={`text-xs ${CASE_STATUS[r.case_status] ?? 'bg-muted'}`}>{r.case_status}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap">
                      <div className="flex gap-1">
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEditAction(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeletingAction(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Case Dialog */}
      <Dialog open={caseOpen} onOpenChange={setCaseOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>{editCase ? 'Edit Case' : 'New Disciplinary Case'}</DialogTitle></DialogHeader>
          <form onSubmit={saveCase} className="space-y-4 py-1">
            <EmployeeSelect value={caseForm.employee_id} onChange={v => setCaseForm(p => ({ ...p, employee_id: v }))} required />
            <div className="space-y-1.5"><Label>Case Title</Label><Input value={caseForm.case_title} onChange={e => setCaseForm(p => ({ ...p, case_title: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Description</Label><Textarea rows={3} value={caseForm.description} onChange={e => setCaseForm(p => ({ ...p, description: e.target.value }))} className="resize-none" /></div>
            <DialogFooter>
              <Button variant="outline" type="button" onClick={() => setCaseOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editCase ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Action Dialog */}
      <Dialog open={actionOpen} onOpenChange={setActionOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editAction ? 'Edit Action' : 'New Disciplinary Action'}</DialogTitle></DialogHeader>
          <form onSubmit={saveAction} className="space-y-4 py-1">
            <EmployeeSelect value={actionForm.employee_id} onChange={v => setActionForm(p => ({ ...p, employee_id: v }))} required />
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Action Type <span className="text-destructive">*</span></Label>
                <Select value={actionForm.action_type} onValueChange={v => setActionForm(p => ({ ...p, action_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="WARNING">Warning</SelectItem>
                    <SelectItem value="SUSPENSION">Suspension</SelectItem>
                    <SelectItem value="DEMOTION">Demotion</SelectItem>
                    <SelectItem value="TERMINATION">Termination</SelectItem>
                    <SelectItem value="OTHER">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Case Status</Label>
                <Select value={actionForm.case_status} onValueChange={v => setActionForm(p => ({ ...p, case_status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="OPEN">Open</SelectItem>
                    <SelectItem value="CLOSED">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Action Date <span className="text-destructive">*</span></Label><Input type="date" value={actionForm.action_date} onChange={e => setActionForm(p => ({ ...p, action_date: e.target.value }))} required /></div>
              <div className="space-y-1.5"><Label>Related To</Label><Input value={actionForm.related_to} onChange={e => setActionForm(p => ({ ...p, related_to: e.target.value }))} placeholder="e.g. Repeated Lateness" /></div>
            </div>
            <div className="space-y-1.5"><Label>Reason <span className="text-destructive">*</span></Label><Textarea rows={3} value={actionForm.action_reason} onChange={e => setActionForm(p => ({ ...p, action_reason: e.target.value }))} required className="resize-none" /></div>
            <DialogFooter>
              <Button variant="outline" type="button" onClick={() => setActionOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editAction ? 'Update' : 'Record Action'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete confirms */}
      <AlertDialog open={!!deletingCase} onOpenChange={o => !o && setDeletingCase(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader><AlertDialogTitle>Delete Case</AlertDialogTitle><AlertDialogDescription>This will soft-delete the disciplinary case.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive hover:bg-destructive/90" onClick={async () => { if (deletingCase) { await disciplinaryCaseService.delete(deletingCase.disciplinary_case_id); toast.success('Case deleted'); setDeletingCase(null); loadCases(); } }}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={!!deletingAction} onOpenChange={o => !o && setDeletingAction(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader><AlertDialogTitle>Delete Action</AlertDialogTitle><AlertDialogDescription>This will soft-delete the disciplinary action record.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive hover:bg-destructive/90" onClick={async () => { if (deletingAction) { await disciplinaryActionService.delete(deletingAction.disciplinary_action_id); toast.success('Action deleted'); setDeletingAction(null); loadActions(); } }}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 3 — Grievances
// ═══════════════════════════════════════════════════════════════════════════════
function GrievancesTab() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [stageFilter, setStageFilter] = useState('all');
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Row | null>(null);
  const [deleting, setDeleting] = useState<Row | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    employee_id: '', grievance_title: '', grievance_description: '',
    submission_date: '', workflow_stage: 'SUBMITTED',
    resolution_notes: '', resolution_date: '',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await grievanceCaseService.list({ workflow_stage: stageFilter, page: 1, pageSize: 50 });
      setRows(r.data); setTotal(r.total);
    } catch { toast.error('Failed to load grievances'); }
    finally { setLoading(false); }
  }, [stageFilter]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm({ employee_id: '', grievance_title: '', grievance_description: '', submission_date: new Date().toISOString().slice(0, 10), workflow_stage: 'SUBMITTED', resolution_notes: '', resolution_date: '' });
    setOpen(true);
  };
  const openEdit = (r: Row) => {
    setEditing(r);
    setForm({ employee_id: r.employee_id, grievance_title: r.grievance_title, grievance_description: r.grievance_description, submission_date: r.submission_date, workflow_stage: r.workflow_stage, resolution_notes: r.resolution_notes ?? '', resolution_date: r.resolution_date ?? '' });
    setOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.employee_id || !form.grievance_title || !form.grievance_description) { toast.error('Required fields missing'); return; }
    setSaving(true);
    try {
      const payload = { ...form, submission_date: form.submission_date || new Date().toISOString().slice(0, 10), resolution_date: form.resolution_date || null, resolution_notes: form.resolution_notes || null };
      if (editing) await grievanceCaseService.update(editing.grievance_id, payload);
      else await grievanceCaseService.create(payload);
      toast.success(editing ? 'Grievance updated' : 'Grievance submitted');
      setOpen(false); load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <p className="text-sm text-muted-foreground">{total} grievances</p>
        <div className="flex items-center gap-2">
          <Select value={stageFilter} onValueChange={setStageFilter}>
            <SelectTrigger className="h-8 w-40 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Stages</SelectItem>
              <SelectItem value="SUBMITTED">Submitted</SelectItem>
              <SelectItem value="UNDER_REVIEW">Under Review</SelectItem>
              <SelectItem value="INVESTIGATION">Investigation</SelectItem>
              <SelectItem value="RESOLVED">Resolved</SelectItem>
              <SelectItem value="CLOSED">Closed</SelectItem>
            </SelectContent>
          </Select>
          <Button size="sm" className="h-8" onClick={openCreate}><Plus className="h-3.5 w-3.5 mr-1" />File Grievance</Button>
          <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={load}><RefreshCw className="h-3.5 w-3.5" /></Button>
        </div>
      </div>

      <div className="rounded border border-border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="text-xs">
              <TableHead className="whitespace-nowrap">Employee</TableHead>
              <TableHead className="whitespace-nowrap">Title</TableHead>
              <TableHead className="whitespace-nowrap">Stage</TableHead>
              <TableHead className="whitespace-nowrap">Submitted</TableHead>
              <TableHead className="whitespace-nowrap">Resolved</TableHead>
              <TableHead className="whitespace-nowrap w-20">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? SKEL(6) : rows.length === 0 ? EMPTY(6, 'No grievance cases') : rows.map(r => (
              <TableRow key={r.grievance_id} className="text-sm">
                <TableCell className="whitespace-nowrap">{r.employee ? `${r.employee.first_name} ${r.employee.last_name}` : r.employee_id?.slice(0, 8)}</TableCell>
                <TableCell className="whitespace-nowrap font-medium max-w-[200px] truncate">{r.grievance_title}</TableCell>
                <TableCell className="whitespace-nowrap"><Badge className={`text-xs ${GRIEV_STAGE[r.workflow_stage] ?? 'bg-muted'}`}>{r.workflow_stage?.replace('_', ' ')}</Badge></TableCell>
                <TableCell className="whitespace-nowrap text-xs">{fmtDate(r.submission_date)}</TableCell>
                <TableCell className="whitespace-nowrap text-xs">{fmtDate(r.resolution_date)}</TableCell>
                <TableCell className="whitespace-nowrap">
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleting(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editing ? 'Update Grievance' : 'File New Grievance'}</DialogTitle></DialogHeader>
          <form onSubmit={handleSave} className="space-y-4 py-1">
            <EmployeeSelect value={form.employee_id} onChange={v => setForm(p => ({ ...p, employee_id: v }))} required />
            <div className="space-y-1.5"><Label>Title <span className="text-destructive">*</span></Label><Input value={form.grievance_title} onChange={e => setForm(p => ({ ...p, grievance_title: e.target.value }))} required /></div>
            <div className="space-y-1.5"><Label>Description <span className="text-destructive">*</span></Label><Textarea rows={3} value={form.grievance_description} onChange={e => setForm(p => ({ ...p, grievance_description: e.target.value }))} required className="resize-none" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Submission Date</Label><Input type="date" value={form.submission_date} onChange={e => setForm(p => ({ ...p, submission_date: e.target.value }))} /></div>
              <div className="space-y-1.5">
                <Label>Stage</Label>
                <Select value={form.workflow_stage} onValueChange={v => setForm(p => ({ ...p, workflow_stage: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SUBMITTED">Submitted</SelectItem>
                    <SelectItem value="UNDER_REVIEW">Under Review</SelectItem>
                    <SelectItem value="INVESTIGATION">Investigation</SelectItem>
                    <SelectItem value="RESOLVED">Resolved</SelectItem>
                    <SelectItem value="CLOSED">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Resolution Date</Label><Input type="date" value={form.resolution_date} onChange={e => setForm(p => ({ ...p, resolution_date: e.target.value }))} /></div>
            </div>
            {(form.workflow_stage === 'RESOLVED' || form.workflow_stage === 'CLOSED') && (
              <div className="space-y-1.5"><Label>Resolution Notes</Label><Textarea rows={2} value={form.resolution_notes} onChange={e => setForm(p => ({ ...p, resolution_notes: e.target.value }))} className="resize-none" /></div>
            )}
            <DialogFooter>
              <Button variant="outline" type="button" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Submit'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader><AlertDialogTitle>Delete Grievance</AlertDialogTitle><AlertDialogDescription>Delete <strong>{deleting?.grievance_title}</strong>?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive hover:bg-destructive/90" onClick={async () => { if (deleting) { await grievanceCaseService.delete(deleting.grievance_id); toast.success('Grievance deleted'); setDeleting(null); load(); } }}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 4 — DSAR
// ═══════════════════════════════════════════════════════════════════════════════
function DsarTab() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [statusFilter, setStatusFilter] = useState('all');
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Row | null>(null);
  const [deleting, setDeleting] = useState<Row | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ employee_id: '', request_type: 'ACCESS', request_date: '', deadline_date: '', request_status: 'SUBMITTED', response_document_path: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await dsarService.list({ request_status: statusFilter, page: 1, pageSize: 50 });
      setRows(r.data); setTotal(r.total);
    } catch { toast.error('Failed to load DSARs'); }
    finally { setLoading(false); }
  }, [statusFilter]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    setEditing(null);
    const today = new Date();
    const deadline = new Date(today); deadline.setDate(today.getDate() + 30);
    setForm({ employee_id: '', request_type: 'ACCESS', request_date: today.toISOString().slice(0, 10), deadline_date: deadline.toISOString().slice(0, 10), request_status: 'SUBMITTED', response_document_path: '' });
    setOpen(true);
  };
  const openEdit = (r: Row) => {
    setEditing(r);
    setForm({ employee_id: r.employee_id, request_type: r.request_type, request_date: r.request_date, deadline_date: r.deadline_date, request_status: r.request_status, response_document_path: r.response_document_path ?? '' });
    setOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.employee_id || !form.request_date || !form.deadline_date) { toast.error('Required fields missing'); return; }
    setSaving(true);
    try {
      const payload = { ...form, response_document_path: form.response_document_path || null };
      if (editing) await dsarService.update(editing.dsar_id, payload);
      else await dsarService.create(payload);
      toast.success(editing ? 'DSAR updated' : 'DSAR submitted');
      setOpen(false); load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  const isOverdue = (row: Row) => row.request_status !== 'COMPLETED' && new Date(row.deadline_date) < new Date();

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <p className="text-sm text-muted-foreground">{total} requests</p>
        <div className="flex items-center gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-8 w-36 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="SUBMITTED">Submitted</SelectItem>
              <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
              <SelectItem value="COMPLETED">Completed</SelectItem>
              <SelectItem value="OVERDUE">Overdue</SelectItem>
            </SelectContent>
          </Select>
          <Button size="sm" className="h-8" onClick={openCreate}><Plus className="h-3.5 w-3.5 mr-1" />New DSAR</Button>
          <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={load}><RefreshCw className="h-3.5 w-3.5" /></Button>
        </div>
      </div>

      <div className="rounded border border-border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="text-xs">
              <TableHead className="whitespace-nowrap">Employee</TableHead>
              <TableHead className="whitespace-nowrap">Type</TableHead>
              <TableHead className="whitespace-nowrap">Request Date</TableHead>
              <TableHead className="whitespace-nowrap">Deadline</TableHead>
              <TableHead className="whitespace-nowrap">Status</TableHead>
              <TableHead className="whitespace-nowrap w-20">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? SKEL(6) : rows.length === 0 ? EMPTY(6, 'No data subject access requests') : rows.map(r => (
              <TableRow key={r.dsar_id} className={`text-sm ${isOverdue(r) ? 'bg-red-50/40' : ''}`}>
                <TableCell className="whitespace-nowrap">{r.employee ? `${r.employee.first_name} ${r.employee.last_name}` : r.employee_id?.slice(0, 8)}</TableCell>
                <TableCell className="whitespace-nowrap text-xs">{r.request_type}</TableCell>
                <TableCell className="whitespace-nowrap text-xs">{fmtDate(r.request_date)}</TableCell>
                <TableCell className="whitespace-nowrap text-xs">
                  <span className={isOverdue(r) ? 'text-red-600 font-semibold' : ''}>{fmtDate(r.deadline_date)}</span>
                </TableCell>
                <TableCell className="whitespace-nowrap"><Badge className={`text-xs ${DSAR_STATUS[r.request_status] ?? 'bg-muted'}`}>{r.request_status?.replace('_', ' ')}</Badge></TableCell>
                <TableCell className="whitespace-nowrap">
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleting(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editing ? 'Update DSAR' : 'New Data Subject Access Request'}</DialogTitle></DialogHeader>
          <form onSubmit={handleSave} className="space-y-4 py-1">
            <EmployeeSelect value={form.employee_id} onChange={v => setForm(p => ({ ...p, employee_id: v }))} required />
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Request Type <span className="text-destructive">*</span></Label>
                <Select value={form.request_type} onValueChange={v => setForm(p => ({ ...p, request_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ACCESS">Access</SelectItem>
                    <SelectItem value="RECTIFICATION">Rectification</SelectItem>
                    <SelectItem value="DELETION">Deletion</SelectItem>
                    <SelectItem value="PORTABILITY">Portability</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Status</Label>
                <Select value={form.request_status} onValueChange={v => setForm(p => ({ ...p, request_status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SUBMITTED">Submitted</SelectItem>
                    <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
                    <SelectItem value="COMPLETED">Completed</SelectItem>
                    <SelectItem value="OVERDUE">Overdue</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Request Date <span className="text-destructive">*</span></Label><Input type="date" value={form.request_date} onChange={e => setForm(p => ({ ...p, request_date: e.target.value }))} required /></div>
              <div className="space-y-1.5"><Label>Deadline Date <span className="text-destructive">*</span></Label><Input type="date" value={form.deadline_date} onChange={e => setForm(p => ({ ...p, deadline_date: e.target.value }))} required /></div>
            </div>
            <div className="space-y-1.5"><Label>Response Document Path</Label><Input value={form.response_document_path} onChange={e => setForm(p => ({ ...p, response_document_path: e.target.value }))} placeholder="/docs/dsar-response-001.pdf" /></div>
            <DialogFooter>
              <Button variant="outline" type="button" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Submit'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader><AlertDialogTitle>Delete DSAR</AlertDialogTitle><AlertDialogDescription>Delete this data subject access request?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive hover:bg-destructive/90" onClick={async () => { if (deleting) { await dsarService.delete(deleting.dsar_id); toast.success('DSAR deleted'); setDeleting(null); load(); } }}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 5 — Data Retention
// ═══════════════════════════════════════════════════════════════════════════════
function DataRetentionTab() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Row | null>(null);
  const [deleting, setDeleting] = useState<Row | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ entity_type: '', retention_period_periods: '', action_type: 'ARCHIVE', policy_reference: '', execution_status: 'SCHEDULED' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await dataRetentionService.list({ page: 1, pageSize: 50 });
      setRows(r.data); setTotal(r.total);
    } catch { toast.error('Failed to load retention policies'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm({ entity_type: '', retention_period_periods: '', action_type: 'ARCHIVE', policy_reference: '', execution_status: 'SCHEDULED' });
    setOpen(true);
  };
  const openEdit = (r: Row) => {
    setEditing(r);
    setForm({ entity_type: r.entity_type, retention_period_periods: String(r.retention_period_periods), action_type: r.action_type, policy_reference: r.policy_reference ?? '', execution_status: r.execution_status });
    setOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.entity_type || !form.retention_period_periods) { toast.error('Entity type and period are required'); return; }
    setSaving(true);
    try {
      const payload = { ...form, retention_period_periods: Number(form.retention_period_periods), policy_reference: form.policy_reference || null };
      if (editing) await dataRetentionService.update(editing.retention_period_id, payload);
      else await dataRetentionService.create(payload);
      toast.success(editing ? 'Retention policy updated' : 'Retention policy created');
      setOpen(false); load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <p className="text-sm text-muted-foreground">{total} retention rules</p>
        <div className="flex items-center gap-2">
          <Button size="sm" className="h-8" onClick={openCreate}><Plus className="h-3.5 w-3.5 mr-1" />Add Rule</Button>
          <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={load}><RefreshCw className="h-3.5 w-3.5" /></Button>
        </div>
      </div>

      <div className="rounded border border-border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="text-xs">
              <TableHead className="whitespace-nowrap">Entity Type</TableHead>
              <TableHead className="whitespace-nowrap">Retention (months)</TableHead>
              <TableHead className="whitespace-nowrap">Action on Expiry</TableHead>
              <TableHead className="whitespace-nowrap">Policy Reference</TableHead>
              <TableHead className="whitespace-nowrap">Status</TableHead>
              <TableHead className="whitespace-nowrap">Last Executed</TableHead>
              <TableHead className="whitespace-nowrap w-20">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? SKEL(7) : rows.length === 0 ? EMPTY(7, 'No retention policies defined') : rows.map(r => (
              <TableRow key={r.retention_period_id} className="text-sm">
                <TableCell className="whitespace-nowrap font-medium">{r.entity_type}</TableCell>
                <TableCell className="whitespace-nowrap text-center">{r.retention_period_periods}</TableCell>
                <TableCell className="whitespace-nowrap"><Badge className={r.action_type === 'DELETE' ? 'bg-red-100 text-red-700 text-xs' : r.action_type === 'ANONYMIZE' ? 'bg-orange-100 text-orange-700 text-xs' : 'bg-blue-100 text-blue-700 text-xs'}>{r.action_type}</Badge></TableCell>
                <TableCell className="whitespace-nowrap text-xs max-w-[160px] truncate">{r.policy_reference || '—'}</TableCell>
                <TableCell className="whitespace-nowrap"><Badge className={`text-xs ${EXEC_STATUS[r.execution_status] ?? 'bg-muted'}`}>{r.execution_status}</Badge></TableCell>
                <TableCell className="whitespace-nowrap text-xs">{fmtDate(r.last_executed_at)}</TableCell>
                <TableCell className="whitespace-nowrap">
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleting(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>{editing ? 'Edit Retention Policy' : 'New Data Retention Rule'}</DialogTitle></DialogHeader>
          <form onSubmit={handleSave} className="space-y-4 py-1">
            <div className="space-y-1.5"><Label>Entity Type <span className="text-destructive">*</span></Label><Input value={form.entity_type} onChange={e => setForm(p => ({ ...p, entity_type: e.target.value }))} required placeholder="e.g. Employee Records" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Retention Months <span className="text-destructive">*</span></Label><Input type="number" min={1} value={form.retention_period_periods} onChange={e => setForm(p => ({ ...p, retention_period_periods: e.target.value }))} required /></div>
              <div className="space-y-1.5">
                <Label>Action on Expiry</Label>
                <Select value={form.action_type} onValueChange={v => setForm(p => ({ ...p, action_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ARCHIVE">Archive</SelectItem>
                    <SelectItem value="ANONYMIZE">Anonymize</SelectItem>
                    <SelectItem value="DELETE">Delete</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Execution Status</Label>
                <Select value={form.execution_status} onValueChange={v => setForm(p => ({ ...p, execution_status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SCHEDULED">Scheduled</SelectItem>
                    <SelectItem value="EXECUTED">Executed</SelectItem>
                    <SelectItem value="PAUSED">Paused</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5"><Label>Policy Reference</Label><Input value={form.policy_reference} onChange={e => setForm(p => ({ ...p, policy_reference: e.target.value }))} placeholder="e.g. GDPR Art. 5(1)(e)" /></div>
            <DialogFooter>
              <Button variant="outline" type="button" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader><AlertDialogTitle>Delete Retention Rule</AlertDialogTitle><AlertDialogDescription>Delete the retention rule for <strong>{deleting?.entity_type}</strong>?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive hover:bg-destructive/90" onClick={async () => { if (deleting) { await dataRetentionService.delete(deleting.retention_period_id); toast.success('Rule deleted'); setDeleting(null); load(); } }}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROOT PAGE
// ═══════════════════════════════════════════════════════════════════════════════
export function ComplianceHubPage() {
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2">
        <ShieldCheck className="h-5 w-5 text-primary shrink-0" />
        <div>
          <h1 className="text-xl font-bold text-foreground leading-tight">Compliance &amp; Governance</h1>
          <p className="text-sm text-muted-foreground">Policies, disciplinary, warning templates, progressive discipline, grievances, DSAR, and data retention</p>
        </div>
      </div>

      <Tabs defaultValue="policies" className="space-y-4">
        <TabsList className="h-9 gap-1 flex-wrap">
          <TabsTrigger value="policies" className="text-xs h-7 px-3 gap-1.5"><BookOpen className="h-3.5 w-3.5" />Policies</TabsTrigger>
          <TabsTrigger value="disciplinary" className="text-xs h-7 px-3 gap-1.5"><AlertTriangle className="h-3.5 w-3.5" />Disciplinary</TabsTrigger>
          <TabsTrigger value="grievances" className="text-xs h-7 px-3 gap-1.5"><MessageSquare className="h-3.5 w-3.5" />Grievances</TabsTrigger>
          <TabsTrigger value="dsar" className="text-xs h-7 px-3 gap-1.5"><ClipboardList className="h-3.5 w-3.5" />DSAR</TabsTrigger>
          <TabsTrigger value="retention" className="text-xs h-7 px-3 gap-1.5"><Database className="h-3.5 w-3.5" />Data Retention</TabsTrigger>
          <TabsTrigger value="policy-register" className="text-xs h-7 px-3 gap-1.5"><BookOpen className="h-3.5 w-3.5" />Policy Register</TabsTrigger>
          <TabsTrigger value="warning-templates" className="text-xs h-7 px-3 gap-1.5"><FileWarning className="h-3.5 w-3.5" />Warning Templates</TabsTrigger>
          <TabsTrigger value="prog-discipline" className="text-xs h-7 px-3 gap-1.5"><GitMerge className="h-3.5 w-3.5" />Prog. Discipline</TabsTrigger>
        </TabsList>

        <TabsContent value="policies"><PoliciesTab /></TabsContent>
        <TabsContent value="disciplinary"><DisciplinaryTab /></TabsContent>
        <TabsContent value="grievances"><GrievancesTab /></TabsContent>
        <TabsContent value="dsar"><DsarTab /></TabsContent>
        <TabsContent value="retention"><DataRetentionTab /></TabsContent>
        <TabsContent value="policy-register" className="mt-2"><PolicyRegisterTab /></TabsContent>
        <TabsContent value="warning-templates" className="mt-2"><WarningTemplatesTab /></TabsContent>
        <TabsContent value="prog-discipline" className="mt-2"><ProgDisciplineTab /></TabsContent>
      </Tabs>
    </div>
  );
}


/* ══════════════════════════════════════════════════════════════════════
   Policy Register tab — policy_register table
   ══════════════════════════════════════════════════════════════════════ */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const _sb = (supabase as any);

type PolicyRow = { id?: string; policy_code?: string; title?: string; category?: string; owner?: string; effective_date?: string; review_date?: string; status?: string; description?: string };

function PolicyRegisterTab() {
  const [rows, setRows] = useState<PolicyRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ policy_code: '', title: '', category: 'HR', owner: '', effective_date: '', review_date: '', status: 'ACTIVE', description: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await _sb.from('policy_register').select('*').order('policy_code').limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.policy_code || !form.title) { toast.error('Code and Title are required'); return; }
    setSaving(true);
    const { error } = await _sb.from('policy_register').insert({ policy_code: form.policy_code, title: form.title, category: form.category, owner: form.owner || null, effective_date: form.effective_date || null, review_date: form.review_date || null, status: form.status, description: form.description || null });
    if (error) toast.error(error.message); else { toast.success('Policy registered'); setOpen(false); setForm({ policy_code: '', title: '', category: 'HR', owner: '', effective_date: '', review_date: '', status: 'ACTIVE', description: '' }); load(); }
    setSaving(false);
  };

  const STATUS_CLR: Record<string, string> = { DRAFT: 'bg-muted text-muted-foreground', ACTIVE: 'bg-green-100 text-green-800', UNDER_REVIEW: 'bg-yellow-100 text-yellow-800', RETIRED: 'bg-gray-100 text-gray-500' };

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm flex items-center gap-2"><BookOpen className="h-4 w-4" />Policy Register</CardTitle>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="h-8" onClick={load} disabled={loading}><RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} /></Button>
          <Button size="sm" className="h-8" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add Policy</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground py-8 text-center">No policies registered</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Code</TableHead>
                <TableHead className="whitespace-nowrap">Title</TableHead>
                <TableHead className="whitespace-nowrap">Category</TableHead>
                <TableHead className="whitespace-nowrap">Owner</TableHead>
                <TableHead className="whitespace-nowrap">Effective</TableHead>
                <TableHead className="whitespace-nowrap">Review</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r, i) => (
                  <TableRow key={r.id || i}>
                    <TableCell className="whitespace-nowrap text-sm font-medium">{r.policy_code}</TableCell>
                    <TableCell className="text-sm min-w-[160px]">{r.title}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.category}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.owner || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.effective_date || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.review_date || '—'}</TableCell>
                    <TableCell><Badge className={STATUS_CLR[r.status || ''] || 'bg-muted'}>{r.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Register Policy</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Code *</Label><Input value={form.policy_code} onChange={e => setForm(p => ({ ...p, policy_code: e.target.value }))} placeholder="POL-001" /></div>
              <div className="space-y-1.5"><Label>Category</Label><Input value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Title *</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Owner</Label><Input value={form.owner} onChange={e => setForm(p => ({ ...p, owner: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Status</Label>
                <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DRAFT">Draft</SelectItem>
                    <SelectItem value="ACTIVE">Active</SelectItem>
                    <SelectItem value="UNDER_REVIEW">Under Review</SelectItem>
                    <SelectItem value="RETIRED">Retired</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Effective Date</Label><Input type="date" value={form.effective_date} onChange={e => setForm(p => ({ ...p, effective_date: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Review Date</Label><Input type="date" value={form.review_date} onChange={e => setForm(p => ({ ...p, review_date: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Description</Label><Textarea rows={2} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ══════════════════════════════════════════════════════════════════════
   Warning Templates tab — warning_letter_templates table
   ══════════════════════════════════════════════════════════════════════ */
type WLTemplate = { template_id?: string; template_name: string; warning_level: string; subject?: string; body_template?: string; created_at?: string };

function WarningTemplatesTab() {
  const [rows, setRows] = useState<WLTemplate[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [preview, setPreview] = useState<WLTemplate | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ template_name: '', warning_level: 'VERBAL', subject: '', body_template: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await _sb.from('warning_letter_templates').select('*').order('created_at', { ascending: false }).limit(50);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.template_name.trim()) { toast.error('Template name required'); return; }
    setSaving(true);
    const { error } = await _sb.from('warning_letter_templates').insert({ template_name: form.template_name, warning_level: form.warning_level, subject: form.subject || null, body_template: form.body_template || null });
    if (error) toast.error(error.message); else { toast.success('Template saved'); setOpen(false); setForm({ template_name: '', warning_level: 'VERBAL', subject: '', body_template: '' }); load(); }
    setSaving(false);
  };

  const LEVEL_BADGE: Record<string, string> = { VERBAL: 'bg-yellow-100 text-yellow-800', WRITTEN: 'bg-orange-100 text-orange-800', FINAL: 'bg-red-100 text-red-800', TERMINATION: 'bg-red-200 text-red-900' };

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm flex items-center gap-2"><FileWarning className="h-4 w-4" />Warning Letter Templates</CardTitle>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="h-8" onClick={load} disabled={loading}><RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} /></Button>
          <Button size="sm" className="h-8" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />New Template</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground py-8 text-center">No warning templates created yet</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Template Name</TableHead>
                <TableHead className="whitespace-nowrap">Level</TableHead>
                <TableHead className="whitespace-nowrap">Subject</TableHead>
                <TableHead className="whitespace-nowrap">Created</TableHead>
                <TableHead className="whitespace-nowrap">Actions</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r, i) => (
                  <TableRow key={r.template_id || i}>
                    <TableCell className="whitespace-nowrap font-medium">{r.template_name}</TableCell>
                    <TableCell><Badge className={LEVEL_BADGE[r.warning_level] || 'bg-muted'}>{r.warning_level}</Badge></TableCell>
                    <TableCell className="max-w-[200px] truncate text-sm">{r.subject || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{r.created_at ? new Date(r.created_at).toLocaleDateString() : '—'}</TableCell>
                    <TableCell><Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setPreview(r)}>Preview</Button></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>New Warning Letter Template</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Template Name *</Label><Input value={form.template_name} onChange={e => setForm(p => ({ ...p, template_name: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Warning Level</Label>
                <Select value={form.warning_level} onValueChange={v => setForm(p => ({ ...p, warning_level: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="VERBAL">Verbal Warning</SelectItem>
                    <SelectItem value="WRITTEN">Written Warning</SelectItem>
                    <SelectItem value="FINAL">Final Warning</SelectItem>
                    <SelectItem value="TERMINATION">Termination Notice</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5"><Label>Email Subject</Label><Input value={form.subject} onChange={e => setForm(p => ({ ...p, subject: e.target.value }))} placeholder="e.g. Warning Notice – {employee_name}" /></div>
            <div className="space-y-1.5">
              <Label>Letter Body</Label>
              <p className="text-xs text-muted-foreground">Placeholders: {"{employee_name}"}, {"{date}"}, {"{manager_name}"}, {"{incident_description}"}</p>
              <Textarea rows={7} className="font-mono text-sm" value={form.body_template} onChange={e => setForm(p => ({ ...p, body_template: e.target.value }))} placeholder={"Dear {employee_name},\n\nThis letter serves as formal notice…"} />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save Template</Button>
          </div>
        </DialogContent>
      </Dialog>
      <Dialog open={!!preview} onOpenChange={() => setPreview(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>{preview?.template_name}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            {preview?.subject && <div className="rounded bg-muted/50 px-3 py-2 text-sm"><strong>Subject:</strong> {preview.subject}</div>}
            <div className="rounded border border-border p-4 whitespace-pre-wrap font-mono text-sm min-h-[160px] bg-card">{preview?.body_template || '(No body content)'}</div>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ══════════════════════════════════════════════════════════════════════
   Progressive Discipline tab — progressive_discipline table
   ══════════════════════════════════════════════════════════════════════ */
type PDRow = { pd_id?: string; employee_id: string; full_name?: string; incident_date?: string; incident_type?: string; action_taken: string; issued_by?: string; notes?: string; status?: string };

function ProgDisciplineTab() {
  const [rows, setRows] = useState<PDRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ employee_id: '', full_name: '', incident_date: '', incident_type: 'ATTENDANCE', action_taken: 'VERBAL_WARNING', issued_by: '', notes: '' });

  const INCIDENT_TYPES = ['ATTENDANCE', 'CONDUCT', 'PERFORMANCE', 'POLICY_VIOLATION', 'INSUBORDINATION', 'OTHER'];
  const ACTION_TYPES = ['VERBAL_WARNING', 'WRITTEN_WARNING', 'FINAL_WARNING', 'SUSPENSION', 'TERMINATION'];
  const ACTION_BADGE: Record<string, string> = { VERBAL_WARNING: 'bg-yellow-100 text-yellow-800', WRITTEN_WARNING: 'bg-orange-100 text-orange-800', FINAL_WARNING: 'bg-red-100 text-red-800', SUSPENSION: 'bg-purple-100 text-purple-800', TERMINATION: 'bg-red-200 text-red-900' };

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await _sb.from('progressive_discipline').select('*').order('incident_date', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.employee_id || !form.action_taken) { toast.error('Employee ID and action are required'); return; }
    setSaving(true);
    const { error } = await _sb.from('progressive_discipline').insert({ employee_id: form.employee_id, full_name: form.full_name || null, incident_date: form.incident_date || new Date().toISOString().slice(0, 10), incident_type: form.incident_type, action_taken: form.action_taken, issued_by: form.issued_by || null, notes: form.notes || null, status: 'ACTIVE' });
    if (error) toast.error(error.message); else { toast.success('Discipline record created'); setOpen(false); setForm({ employee_id: '', full_name: '', incident_date: '', incident_type: 'ATTENDANCE', action_taken: 'VERBAL_WARNING', issued_by: '', notes: '' }); load(); }
    setSaving(false);
  };

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm flex items-center gap-2"><GitMerge className="h-4 w-4" />Progressive Discipline</CardTitle>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="h-8" onClick={load} disabled={loading}><RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} /></Button>
          <Button size="sm" className="h-8" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add Record</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground py-8 text-center">No progressive discipline records</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Incident Date</TableHead>
                <TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">Action Taken</TableHead>
                <TableHead className="whitespace-nowrap">Issued By</TableHead>
                <TableHead className="whitespace-nowrap">Notes</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r, i) => (
                  <TableRow key={r.pd_id || i}>
                    <TableCell className="whitespace-nowrap font-medium">{r.full_name || String(r.employee_id).slice(0, 8)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.incident_date || '—'}</TableCell>
                    <TableCell><Badge variant="outline" className="text-xs">{(r.incident_type || '—').replace(/_/g, ' ')}</Badge></TableCell>
                    <TableCell><Badge className={(ACTION_BADGE[r.action_taken] || 'bg-muted') + ' text-xs'}>{r.action_taken.replace(/_/g, ' ')}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.issued_by || '—'}</TableCell>
                    <TableCell className="max-w-[180px] truncate text-sm text-muted-foreground">{r.notes || '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Record Disciplinary Action</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Employee ID *</Label><Input value={form.employee_id} onChange={e => setForm(p => ({ ...p, employee_id: e.target.value }))} placeholder="UUID" /></div>
              <div className="space-y-1.5"><Label>Full Name</Label><Input value={form.full_name} onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Incident Type</Label>
                <Select value={form.incident_type} onValueChange={v => setForm(p => ({ ...p, incident_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{INCIDENT_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace(/_/g, ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Action Taken *</Label>
                <Select value={form.action_taken} onValueChange={v => setForm(p => ({ ...p, action_taken: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{ACTION_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace(/_/g, ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Incident Date</Label><Input type="date" value={form.incident_date} onChange={e => setForm(p => ({ ...p, incident_date: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Issued By</Label><Input value={form.issued_by} onChange={e => setForm(p => ({ ...p, issued_by: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Notes</Label><Textarea rows={3} value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

export default ComplianceHubPage;
