// TrainingPage — Module 9.1 TrainingRequest + 9.2 Trainer
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Eye, GraduationCap, Users, CheckCircle2, ClipboardList, Star, Award, BarChart3, FileSignature, Loader2, TrendingUp, PieChart, BookOpen, Download } from 'lucide-react';
import { exportToCsv } from '@/utils/exportUtils';
import { CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

type TrainingRequest = {
  id: string; training_request_id: string; request_number: string;
  training_topic: string; business_justification?: string;
  estimated_budget?: number; priority_level?: string;
  request_status: string; requested_at: string;
  department?: { name: string };
  requested_by?: { first_name: string; last_name: string };
};
type Trainer = {
  id: string; trainer_id: string; trainer_name: string;
  trainer_type: string; email?: string; phone_number?: string;
  organization?: string; expertise_area?: string;
  average_rating?: number; trainer_status: string;
  employee?: { first_name: string; last_name: string };
};

const REQ_STATUS_COLORS: Record<string, string> = {
  SUBMITTED: 'bg-blue-100 text-blue-800',
  UNDER_REVIEW: 'bg-yellow-100 text-yellow-800',
  APPROVED: 'bg-green-100 text-green-800',
  REJECTED: 'bg-red-100 text-red-800',
  CANCELLED: 'bg-muted text-muted-foreground',
};
const PRIORITY_COLORS: Record<string, string> = {
  LOW: 'bg-muted text-muted-foreground',
  MEDIUM: 'bg-blue-100 text-blue-800',
  HIGH: 'bg-orange-100 text-orange-800',
  STRATEGIC: 'bg-purple-100 text-purple-800',
};
const TRAINER_STATUS_COLORS: Record<string, string> = {
  ACTIVE: 'bg-green-100 text-green-800',
  INACTIVE: 'bg-muted text-muted-foreground',
  BLACKLISTED: 'bg-red-100 text-red-800',
};

export function TrainingPage({ initialTab }: { initialTab?: string } = {}) {
  const [tab, setTab] = useState(initialTab ?? 'requests');

  // Training Requests
  const [requests, setRequests] = useState<TrainingRequest[]>([]);
  const [reqLoading, setReqLoading] = useState(true);
  const [reqSearch, setReqSearch] = useState('');
  const [reqStatusFilter, setReqStatusFilter] = useState('all');
  const [reqDetail, setReqDetail] = useState<TrainingRequest | null>(null);

  // Trainers
  const [trainers, setTrainers] = useState<Trainer[]>([]);
  const [trainerLoading, setTrainerLoading] = useState(false);
  const [trainerSearch, setTrainerSearch] = useState('');
  const [trainerTypeFilter, setTrainerTypeFilter] = useState('all');

  // Departments & Employees for form
  const [departments, setDepartments] = useState<{ id: string; name: string }[]>([]);
  const [employees, setEmployees] = useState<{ id: string; first_name: string; last_name: string; employee_no?: string }[]>([]);

  // Create Request dialog
  const [createReqOpen, setCreateReqOpen] = useState(false);
  const [reqForm, setReqForm] = useState({ department_id: '', training_topic: '', business_justification: '', estimated_budget: '', priority_level: 'MEDIUM' });
  const [reqSaving, setReqSaving] = useState(false);

  // Create Trainer dialog
  const [createTrainerOpen, setCreateTrainerOpen] = useState(false);
  const [trainerForm, setTrainerForm] = useState({ trainer_name: '', trainer_type: 'EXTERNAL', email: '', phone_number: '', organization: '', expertise_area: '', employee_id: '' });
  const [trainerSaving, setTrainerSaving] = useState(false);

  // Stats
  const submitted = requests.filter(r => r.request_status === 'SUBMITTED').length;
  const approved = requests.filter(r => r.request_status === 'APPROVED').length;
  const activeTrainers = trainers.filter(t => t.trainer_status === 'ACTIVE').length;

  const loadRequests = useCallback(async () => {
    setReqLoading(true);
    try {
      let q = sb.from('training_requests')
        .select('id,training_request_id,request_number,training_topic,business_justification,estimated_budget,priority_level,request_status,requested_at,department:departments(name),requested_by:employees(first_name,last_name)')
        .eq('is_deleted', 0).order('created_at', { ascending: false });
      if (reqStatusFilter !== 'all') q = q.eq('request_status', reqStatusFilter);
      const { data, error } = await q;
      if (error) throw error;
      setRequests(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setReqLoading(false); }
  }, [reqStatusFilter]);

  const loadTrainers = useCallback(async () => {
    setTrainerLoading(true);
    try {
      let q = sb.from('trainers')
        .select('id,trainer_id,trainer_name,trainer_type,email,phone_number,organization,expertise_area,average_rating,trainer_status,employee:employees(first_name,last_name)')
        .eq('is_deleted', 0).order('trainer_name', { ascending: true });
      if (trainerTypeFilter !== 'all') q = q.eq('trainer_type', trainerTypeFilter);
      const { data, error } = await q;
      if (error) throw error;
      setTrainers(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setTrainerLoading(false); }
  }, [trainerTypeFilter]);

  const loadRefs = useCallback(async () => {
    const [deptRes, empRes] = await Promise.all([
      sb.from('departments').select('id,name').order('name').limit(100),
      sb.from('employees').select('id,first_name,last_name,employee_no').eq('employment_status', 'active').order('first_name').limit(200),
    ]);
    setDepartments(Array.isArray(deptRes.data) ? deptRes.data : []);
    setEmployees(Array.isArray(empRes.data) ? empRes.data : []);
  }, []);

  useEffect(() => { loadRequests(); loadRefs(); }, [loadRequests, loadRefs]);
  useEffect(() => { if (tab === 'trainers') loadTrainers(); }, [tab, loadTrainers]);

  const filteredRequests = requests.filter(r =>
    r.training_topic.toLowerCase().includes(reqSearch.toLowerCase()) ||
    r.request_number.toLowerCase().includes(reqSearch.toLowerCase()) ||
    (r.department?.name ?? '').toLowerCase().includes(reqSearch.toLowerCase())
  );
  const filteredTrainers = trainers.filter(t =>
    t.trainer_name.toLowerCase().includes(trainerSearch.toLowerCase()) ||
    (t.expertise_area ?? '').toLowerCase().includes(trainerSearch.toLowerCase()) ||
    (t.organization ?? '').toLowerCase().includes(trainerSearch.toLowerCase())
  );

  async function createRequest() {
    if (!reqForm.training_topic.trim()) { toast.error('Training topic required'); return; }
    setReqSaving(true);
    try {
      const { error } = await sb.from('training_requests').insert({
        department_id: reqForm.department_id || null,
        training_topic: reqForm.training_topic.trim(),
        business_justification: reqForm.business_justification || null,
        estimated_budget: reqForm.estimated_budget ? parseFloat(reqForm.estimated_budget) : null,
        priority_level: reqForm.priority_level,
        request_status: 'SUBMITTED',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Training request submitted');
      setCreateReqOpen(false);
      setReqForm({ department_id: '', training_topic: '', business_justification: '', estimated_budget: '', priority_level: 'MEDIUM' });
      loadRequests();
    } catch (e: any) { toast.error(e.message); } finally { setReqSaving(false); }
  }

  async function updateRequestStatus(id: string, status: string) {
    const { error } = await sb.from('training_requests').update({ request_status: status, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Status updated'); loadRequests(); if (reqDetail?.id === id) setReqDetail(d => d ? { ...d, request_status: status } : d); }
  }

  async function createTrainer() {
    if (!trainerForm.trainer_name.trim()) { toast.error('Trainer name required'); return; }
    setTrainerSaving(true);
    try {
      const { error } = await sb.from('trainers').insert({
        trainer_name: trainerForm.trainer_name.trim(),
        trainer_type: trainerForm.trainer_type,
        email: trainerForm.email || null,
        phone_number: trainerForm.phone_number || null,
        organization: trainerForm.organization || null,
        expertise_area: trainerForm.expertise_area || null,
        employee_id: trainerForm.employee_id || null,
        trainer_status: 'ACTIVE',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Trainer registered');
      setCreateTrainerOpen(false);
      setTrainerForm({ trainer_name: '', trainer_type: 'EXTERNAL', email: '', phone_number: '', organization: '', expertise_area: '', employee_id: '' });
      loadTrainers();
    } catch (e: any) { toast.error(e.message); } finally { setTrainerSaving(false); }
  }

  async function updateTrainerStatus(id: string, status: string) {
    const { error } = await sb.from('trainers').update({ trainer_status: status, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Status updated'); loadTrainers(); }
  }

  return (
    <div className="p-4 md:p-6 space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Training</h1>
          <p className="text-sm text-muted-foreground">Manage training requests and trainer registry</p>
        </div>
        <div className="flex gap-2">
          {tab === 'requests' && <Button size="sm" onClick={() => setCreateReqOpen(true)}><Plus className="w-4 h-4 mr-1" /> New Request</Button>}
          {tab === 'trainers' && <Button size="sm" onClick={() => setCreateTrainerOpen(true)}><Plus className="w-4 h-4 mr-1" /> Add Trainer</Button>}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Requests', value: requests.length, icon: ClipboardList },
          { label: 'Submitted', value: submitted, icon: GraduationCap },
          { label: 'Approved', value: approved, icon: CheckCircle2 },
          { label: 'Active Trainers', value: activeTrainers, icon: Users },
        ].map(s => (
          <Card key={s.label} className="h-full">
            <CardContent className="p-4 flex items-center gap-3">
              <s.icon className="w-8 h-8 text-primary shrink-0" />
              <div><p className="text-2xl font-bold">{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex-wrap gap-1 h-auto">
          <TabsTrigger value="requests">Training Requests</TabsTrigger>
          <TabsTrigger value="trainers">Trainers</TabsTrigger>
          <TabsTrigger value="certification" className="gap-1.5"><Award className="h-3.5 w-3.5" />Certification</TabsTrigger>
          <TabsTrigger value="analytics" className="gap-1.5"><BarChart3 className="h-3.5 w-3.5" />Analytics</TabsTrigger>
          <TabsTrigger value="bond" className="gap-1.5"><FileSignature className="h-3.5 w-3.5" />Bond Agreements</TabsTrigger>
          <TabsTrigger value="cost-analytics" className="gap-1.5"><TrendingUp className="h-3.5 w-3.5" />Cost Analytics</TabsTrigger>
          <TabsTrigger value="trainer-perf" className="gap-1.5"><PieChart className="h-3.5 w-3.5" />Trainer Performance</TabsTrigger>
          <TabsTrigger value="td-reporting" className="gap-1.5"><BookOpen className="h-3.5 w-3.5" />T&D Reporting</TabsTrigger>
        </TabsList>

        {/* ── Requests Tab ── */}
        <TabsContent value="requests" className="mt-4 space-y-3">
          <div className="flex flex-col md:flex-row gap-2">
            <Input placeholder="Search topic, number, department…" value={reqSearch} onChange={e => setReqSearch(e.target.value)} className="md:max-w-xs" />
            <Select value={reqStatusFilter} onValueChange={setReqStatusFilter}>
              <SelectTrigger className="md:w-44"><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {['SUBMITTED','UNDER_REVIEW','APPROVED','REJECTED','CANCELLED'].map(s => <SelectItem key={s} value={s}>{s.replace('_',' ')}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Request #</TableHead>
                  <TableHead className="whitespace-nowrap">Topic</TableHead>
                  <TableHead className="whitespace-nowrap">Department</TableHead>
                  <TableHead className="whitespace-nowrap">Priority</TableHead>
                  <TableHead className="whitespace-nowrap">Budget</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reqLoading ? (
                  Array.from({ length: 5 }).map((_, i) => <TableRow key={i}><TableCell colSpan={7}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>)
                ) : filteredRequests.length === 0 ? (
                  <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-10">No training requests found.</TableCell></TableRow>
                ) : filteredRequests.map(r => (
                  <TableRow key={r.id}>
                    <TableCell className="whitespace-nowrap font-mono text-sm">{r.request_number}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium max-w-[200px] truncate">{r.training_topic}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.department?.name ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      {r.priority_level && <Badge className={`text-xs ${PRIORITY_COLORS[r.priority_level] ?? 'bg-muted text-muted-foreground'}`}>{r.priority_level}</Badge>}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.estimated_budget ? `${r.estimated_budget.toLocaleString()}` : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${REQ_STATUS_COLORS[r.request_status] ?? 'bg-muted text-muted-foreground'}`}>{r.request_status.replace('_',' ')}</Badge>
                    </TableCell>
                    <TableCell className="text-right whitespace-nowrap">
                      <Button size="sm" variant="ghost" onClick={() => setReqDetail(r)}><Eye className="w-4 h-4" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* ── Trainers Tab ── */}
        <TabsContent value="trainers" className="mt-4 space-y-3">
          <div className="flex flex-col md:flex-row gap-2">
            <Input placeholder="Search by name, expertise…" value={trainerSearch} onChange={e => setTrainerSearch(e.target.value)} className="md:max-w-xs" />
            <Select value={trainerTypeFilter} onValueChange={setTrainerTypeFilter}>
              <SelectTrigger className="md:w-44"><SelectValue placeholder="All Types" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="INTERNAL">Internal</SelectItem>
                <SelectItem value="EXTERNAL">External</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Name</TableHead>
                  <TableHead className="whitespace-nowrap">Type</TableHead>
                  <TableHead className="whitespace-nowrap">Organization</TableHead>
                  <TableHead className="whitespace-nowrap">Expertise</TableHead>
                  <TableHead className="whitespace-nowrap">Rating</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {trainerLoading ? (
                  Array.from({ length: 5 }).map((_, i) => <TableRow key={i}><TableCell colSpan={7}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>)
                ) : filteredTrainers.length === 0 ? (
                  <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-10">No trainers found.</TableCell></TableRow>
                ) : filteredTrainers.map(t => (
                  <TableRow key={t.id}>
                    <TableCell className="whitespace-nowrap font-medium">{t.trainer_name}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className="text-xs" variant={t.trainer_type === 'INTERNAL' ? 'default' : 'secondary'}>{t.trainer_type}</Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">{t.organization ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap max-w-[160px] truncate text-sm">{t.expertise_area ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      {t.average_rating != null ? (
                        <span className="flex items-center gap-1 text-sm"><Star className="w-3 h-3 text-yellow-500" />{t.average_rating.toFixed(1)}</span>
                      ) : '—'}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${TRAINER_STATUS_COLORS[t.trainer_status] ?? 'bg-muted text-muted-foreground'}`}>{t.trainer_status}</Badge>
                    </TableCell>
                    <TableCell className="text-right whitespace-nowrap">
                      <Select onValueChange={v => updateTrainerStatus(t.id, v)}>
                        <SelectTrigger className="h-7 text-xs w-28"><SelectValue placeholder="Update" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ACTIVE">Active</SelectItem>
                          <SelectItem value="INACTIVE">Inactive</SelectItem>
                          <SelectItem value="BLACKLISTED">Blacklist</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* ── FR-TRND-007: Certification ── */}
        <TabsContent value="certification" className="mt-4">
          <TrainingCertificationTab />
        </TabsContent>

        {/* ── FR-TRND-009: Analytics Dashboard ── */}
        <TabsContent value="analytics" className="mt-4">
          <TrainingAnalyticsTab />
        </TabsContent>

        {/* ── FR-TRND-011: Bond Agreements ── */}
        <TabsContent value="bond" className="mt-4">
          <TrainingBondTab />
        </TabsContent>

        {/* ── FR-TRND-012: Training Cost per Employee Analytics ── */}
        <TabsContent value="cost-analytics" className="mt-4">
          <TrainingCostAnalyticsTab />
        </TabsContent>

        {/* ── FR-TRND-013: Trainer Performance & Evaluation Dashboard ── */}
        <TabsContent value="trainer-perf" className="mt-4">
          <TrainerPerformanceTab />
        </TabsContent>

        {/* ── FR-TRND-014: Training & Development Reporting ── */}
        <TabsContent value="td-reporting" className="mt-4">
          <TDReportingTab />
        </TabsContent>

      </Tabs>

      {/* ── Request Detail Dialog ── */}
      <Dialog open={!!reqDetail} onOpenChange={() => setReqDetail(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{reqDetail?.request_number} — {reqDetail?.training_topic}</DialogTitle></DialogHeader>
          {reqDetail && (
            <div className="space-y-3 pt-2 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div><p className="text-muted-foreground">Department</p><p className="font-medium">{reqDetail.department?.name ?? '—'}</p></div>
                <div><p className="text-muted-foreground">Priority</p>
                  {reqDetail.priority_level
                    ? <Badge className={`text-xs mt-1 ${PRIORITY_COLORS[reqDetail.priority_level] ?? 'bg-muted text-muted-foreground'}`}>{reqDetail.priority_level}</Badge>
                    : <p>—</p>}
                </div>
                <div><p className="text-muted-foreground">Budget Est.</p><p className="font-medium">{reqDetail.estimated_budget?.toLocaleString() ?? '—'}</p></div>
                <div><p className="text-muted-foreground">Requested By</p><p className="font-medium">{reqDetail.requested_by ? `${reqDetail.requested_by.first_name} ${reqDetail.requested_by.last_name}` : '—'}</p></div>
              </div>
              {reqDetail.business_justification && (
                <div><p className="text-muted-foreground">Justification</p><p className="mt-1 text-foreground whitespace-pre-wrap">{reqDetail.business_justification}</p></div>
              )}
              <div>
                <p className="text-muted-foreground mb-1">Status</p>
                <Badge className={`text-xs ${REQ_STATUS_COLORS[reqDetail.request_status] ?? 'bg-muted text-muted-foreground'}`}>{reqDetail.request_status.replace('_',' ')}</Badge>
              </div>
              {reqDetail.request_status === 'SUBMITTED' && (
                <div className="flex gap-2 flex-wrap pt-1">
                  <Button size="sm" onClick={() => updateRequestStatus(reqDetail.id, 'UNDER_REVIEW')}>Under Review</Button>
                  <Button size="sm" variant="outline" onClick={() => updateRequestStatus(reqDetail.id, 'APPROVED')}>Approve</Button>
                  <Button size="sm" variant="outline" onClick={() => updateRequestStatus(reqDetail.id, 'REJECTED')} className="text-destructive border-destructive hover:bg-destructive/10">Reject</Button>
                </div>
              )}
              {reqDetail.request_status === 'UNDER_REVIEW' && (
                <div className="flex gap-2 flex-wrap pt-1">
                  <Button size="sm" onClick={() => updateRequestStatus(reqDetail.id, 'APPROVED')}>Approve</Button>
                  <Button size="sm" variant="outline" onClick={() => updateRequestStatus(reqDetail.id, 'REJECTED')} className="text-destructive border-destructive hover:bg-destructive/10">Reject</Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ── Create Request Dialog ── */}
      <Dialog open={createReqOpen} onOpenChange={setCreateReqOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Training Request</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div><Label>Training Topic *</Label><Input value={reqForm.training_topic} onChange={e => setReqForm(f => ({ ...f, training_topic: e.target.value }))} placeholder="e.g. Advanced Excel for Finance" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Department</Label>
                <Select value={reqForm.department_id} onValueChange={v => setReqForm(f => ({ ...f, department_id: v }))}>
                  <SelectTrigger><SelectValue placeholder="Select dept." /></SelectTrigger>
                  <SelectContent>{departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Priority</Label>
                <Select value={reqForm.priority_level} onValueChange={v => setReqForm(f => ({ ...f, priority_level: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['LOW','MEDIUM','HIGH','STRATEGIC'].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Estimated Budget</Label><Input type="number" min="0" step="0.01" value={reqForm.estimated_budget} onChange={e => setReqForm(f => ({ ...f, estimated_budget: e.target.value }))} placeholder="0.00" /></div>
            <div><Label>Business Justification</Label><Textarea value={reqForm.business_justification} onChange={e => setReqForm(f => ({ ...f, business_justification: e.target.value }))} rows={3} /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCreateReqOpen(false)}>Cancel</Button>
              <Button onClick={createRequest} disabled={reqSaving}>{reqSaving ? 'Submitting…' : 'Submit Request'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Create Trainer Dialog ── */}
      <Dialog open={createTrainerOpen} onOpenChange={setCreateTrainerOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Register Trainer</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Full Name *</Label><Input value={trainerForm.trainer_name} onChange={e => setTrainerForm(f => ({ ...f, trainer_name: e.target.value }))} /></div>
              <div>
                <Label>Type *</Label>
                <Select value={trainerForm.trainer_type} onValueChange={v => setTrainerForm(f => ({ ...f, trainer_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="INTERNAL">Internal</SelectItem><SelectItem value="EXTERNAL">External</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            {trainerForm.trainer_type === 'INTERNAL' && (
              <div>
                <Label>Linked Employee</Label>
                <Select value={trainerForm.employee_id} onValueChange={v => setTrainerForm(f => ({ ...f, employee_id: v }))}>
                  <SelectTrigger><SelectValue placeholder="Select employee" /></SelectTrigger>
                  <SelectContent>{employees.map(e => <SelectItem key={e.id} value={e.id}>{e.first_name} {e.last_name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            {trainerForm.trainer_type === 'EXTERNAL' && (
              <div><Label>Organization</Label><Input value={trainerForm.organization} onChange={e => setTrainerForm(f => ({ ...f, organization: e.target.value }))} /></div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Email</Label><Input type="email" value={trainerForm.email} onChange={e => setTrainerForm(f => ({ ...f, email: e.target.value }))} /></div>
              <div><Label>Phone</Label><Input value={trainerForm.phone_number} onChange={e => setTrainerForm(f => ({ ...f, phone_number: e.target.value }))} /></div>
            </div>
            <div><Label>Expertise Area</Label><Input value={trainerForm.expertise_area} onChange={e => setTrainerForm(f => ({ ...f, expertise_area: e.target.value }))} placeholder="e.g. Project Management, Data Analytics" /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCreateTrainerOpen(false)}>Cancel</Button>
              <Button onClick={createTrainer} disabled={trainerSaving}>{trainerSaving ? 'Saving…' : 'Register'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-TRND-007 – Training Certification Tab
   ───────────────────────────────────────────────────────────────────────── */
type CertRow = { training_certification_id: string; employee_id: string; program_name?: string; issued_date?: string; expiry_date?: string; certificate_number?: string; certificate_status?: string };

function TrainingCertificationTab() {
  const [rows, setRows] = useState<CertRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ employee_id: '', program_name: '', issue_date: '', expiry_date: '', certificate_number: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('training_certifications').select('*').order('issued_date', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.employee_id) { toast.error('Select employee'); return; }
    setSaving(true);
    const { error } = await sb.from('training_certifications').insert({
      employee_id: form.employee_id,
      issued_date: form.issue_date || null, expiry_date: form.expiry_date || null,
      certificate_number: form.certificate_number || null, is_active: 1,
    });
    if (error) toast.error(error.message); else { toast.success('Certification recorded'); setOpen(false); load(); }
    setSaving(false);
  };

  const isExpiringSoon = (d?: string) => { if (!d) return false; return (new Date(d).getTime() - Date.now()) < 90 * 86400000; };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><Award className="h-4 w-4" />Training Certifications (FR-TRND-007)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add Certificate</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee ID</TableHead>
                <TableHead className="whitespace-nowrap">Program</TableHead>
                <TableHead className="whitespace-nowrap">Cert. Number</TableHead>
                <TableHead className="whitespace-nowrap">Issue Date</TableHead>
                <TableHead className="whitespace-nowrap">Expiry Date</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-6 text-sm">No certifications recorded</TableCell></TableRow>}
                {rows.map(r => (
                  <TableRow key={r.training_certification_id || Math.random().toString()}>
                    <TableCell className="whitespace-nowrap text-xs">{String(r.employee_id).slice(0, 8)}…</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">{r.program_name || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.certificate_number || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.issued_date || '—'}</TableCell>
                    <TableCell className={`whitespace-nowrap ${isExpiringSoon(r.expiry_date) ? 'text-destructive font-medium' : ''}`}>{r.expiry_date || '—'}</TableCell>
                    <TableCell><Badge className={r.certificate_status === 'ACTIVE' ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}>{r.certificate_status || 'ACTIVE'}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Record Certification</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Employee *</Label>
              <Input placeholder="Employee ID" value={form.employee_id} onChange={e => setForm(p => ({ ...p, employee_id: e.target.value }))} />
            </div>
            <div className="space-y-1.5"><Label>Program Name</Label><Input value={form.program_name} onChange={e => setForm(p => ({ ...p, program_name: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Certificate Number</Label><Input value={form.certificate_number} onChange={e => setForm(p => ({ ...p, certificate_number: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Issue Date</Label><Input type="date" value={form.issue_date} onChange={e => setForm(p => ({ ...p, issue_date: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Expiry Date</Label><Input type="date" value={form.expiry_date} onChange={e => setForm(p => ({ ...p, expiry_date: e.target.value }))} /></div>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-TRND-009 – Training Analytics Dashboard
   ───────────────────────────────────────────────────────────────────────── */
function TrainingAnalyticsTab() {
  const [stats, setStats] = useState({ total: 0, approved: 0, completed: 0, pending: 0, trainers: 0, budget_used: 0 });
  const [topTopics, setTopTopics] = useState<{ topic: string; count: number }[]>([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: reqs }, { data: trainers }] = await Promise.all([
      sb.from('training_requests').select('request_status, training_topic, estimated_budget').limit(500),
      sb.from('trainers').select('id').limit(200),
    ]);
    if (reqs) {
      const total = reqs.length;
      const approved = reqs.filter((r: Record<string, unknown>) => r.request_status === 'APPROVED').length;
      const completed = reqs.filter((r: Record<string, unknown>) => r.request_status === 'COMPLETED').length;
      const pending = reqs.filter((r: Record<string, unknown>) => r.request_status === 'PENDING').length;
      const budget_used = reqs.reduce((s: number, r: Record<string, unknown>) => s + (Number(r.estimated_budget) || 0), 0);
      const topicMap: Record<string, number> = {};
      for (const r of reqs as Record<string, unknown>[]) { const t = String(r.training_topic || 'Unknown'); topicMap[t] = (topicMap[t] || 0) + 1; }
      const top = Object.entries(topicMap).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([topic, count]) => ({ topic, count }));
      setStats({ total, approved, completed, pending, trainers: trainers?.length || 0, budget_used });
      setTopTopics(top);
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {[
          { label: 'Total Requests', value: stats.total, color: 'text-primary' },
          { label: 'Approved', value: stats.approved, color: 'text-green-700' },
          { label: 'Completed', value: stats.completed, color: 'text-blue-700' },
          { label: 'Pending', value: stats.pending, color: 'text-yellow-700' },
          { label: 'Active Trainers', value: stats.trainers, color: 'text-purple-700' },
          { label: 'Est. Budget Used', value: `${stats.budget_used.toLocaleString()} ETB`, color: 'text-red-700' },
        ].map(s => (
          <Card key={s.label} className="h-full">
            <CardContent className="pt-4 pb-4">
              {loading ? <Skeleton className="h-10 bg-muted" /> : (
                <>
                  <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
                </>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">Top Training Topics</CardTitle></CardHeader>
        <CardContent>
          {loading ? <Skeleton className="h-24 bg-muted" /> : topTopics.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">No data yet — run some training requests first</p>
          ) : (
            <div className="space-y-2">
              {topTopics.map((t, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-xs w-4 text-muted-foreground">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm font-medium truncate">{t.topic}</p>
                      <span className="text-xs text-muted-foreground ml-2 shrink-0">{t.count}</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                      <div className="h-full bg-primary rounded-full" style={{ width: `${Math.round((t.count / (topTopics[0]?.count || 1)) * 100)}%` }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-TRND-011 – Training Bond Agreements
   ───────────────────────────────────────────────────────────────────────── */
type BondRow = { training_bond_id: string; employee_id: string; training_cost_amount?: number; bond_duration_months?: number; bond_start_date?: string; bond_end_date?: string; bond_status?: string };

function TrainingBondTab() {
  const [rows, setRows] = useState<BondRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ employee_id: '', program_name: '', bond_amount: '', bond_period_months: '12', start_date: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('training_bond_agreements').select('*').order('bond_start_date', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.employee_id) { toast.error('Employee ID required'); return; }
    setSaving(true);
    const start = form.start_date || new Date().toISOString().slice(0, 10);
    const end = new Date(start);
    end.setMonth(end.getMonth() + Number(form.bond_period_months));
    const { error } = await sb.from('training_bond_agreements').insert({
      employee_id: form.employee_id,
      training_cost_amount: form.bond_amount ? Number(form.bond_amount) : 0,
      bond_duration_months: Number(form.bond_period_months),
      bond_start_date: start,
      bond_end_date: end.toISOString().slice(0, 10), bond_status: 'ACTIVE',
    });
    if (error) toast.error(error.message); else { toast.success('Bond agreement created'); setOpen(false); load(); }
    setSaving(false);
  };

  const daysLeft = (endDate?: string) => {
    if (!endDate) return null;
    const d = Math.ceil((new Date(endDate).getTime() - Date.now()) / 86400000);
    return d;
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><FileSignature className="h-4 w-4" />Training Bond Agreements (FR-TRND-011)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />New Bond</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Program</TableHead>
                <TableHead className="whitespace-nowrap">Bond Amount</TableHead>
                <TableHead className="whitespace-nowrap">Period</TableHead>
                <TableHead className="whitespace-nowrap">End Date</TableHead>
                <TableHead className="whitespace-nowrap">Days Left</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-6 text-sm">No bond agreements on record</TableCell></TableRow>}
                {rows.map(r => {
                  const dl = daysLeft(r.bond_end_date);
                  return (
                    <TableRow key={r.training_bond_id || Math.random().toString()}>
                      <TableCell className="whitespace-nowrap text-xs">{String(r.employee_id).slice(0, 8)}…</TableCell>
                      <TableCell className="whitespace-nowrap font-medium">—</TableCell>
                      <TableCell className="whitespace-nowrap">{r.training_cost_amount?.toLocaleString() || '—'} ETB</TableCell>
                      <TableCell className="whitespace-nowrap">{r.bond_duration_months || '—'} mo</TableCell>
                      <TableCell className="whitespace-nowrap">{r.bond_end_date || '—'}</TableCell>
                      <TableCell className={`whitespace-nowrap font-medium ${dl != null && dl < 90 ? 'text-destructive' : 'text-muted-foreground'}`}>
                        {dl != null ? (dl > 0 ? `${dl}d` : 'Expired') : '—'}
                      </TableCell>
                      <TableCell><Badge className={r.bond_status === 'ACTIVE' ? 'bg-green-100 text-green-800' : r.bond_status === 'COMPLETED' ? 'bg-muted text-muted-foreground' : 'bg-red-100 text-red-800'}>{r.bond_status || 'ACTIVE'}</Badge></TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Create Bond Agreement</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Employee ID *</Label><Input value={form.employee_id} onChange={e => setForm(p => ({ ...p, employee_id: e.target.value }))} placeholder="Enter employee UUID" /></div>
            <div className="space-y-1.5"><Label>Training Program</Label><Input value={form.program_name} onChange={e => setForm(p => ({ ...p, program_name: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Bond Amount (ETB)</Label><Input type="number" value={form.bond_amount} onChange={e => setForm(p => ({ ...p, bond_amount: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Period (months)</Label><Input type="number" min="1" value={form.bond_period_months} onChange={e => setForm(p => ({ ...p, bond_period_months: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Start Date</Label><Input type="date" value={form.start_date} onChange={e => setForm(p => ({ ...p, start_date: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ────────────────────────────────────────────────────────────────────────────
   TrainingCostAnalyticsTab  (FR-TRND-012)
──────────────────────────────────────────────────────────────────────────── */
function TrainingCostAnalyticsTab() {
  const sb = _sb as any; // eslint-disable-line @typescript-eslint/no-explicit-any
  const [rows, setRows] = useState<{ employee_name: string; dept: string; programs: number; total_cost: number; avg_cost: number }[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('training_enrollments')
      .select('employee_id, employee:employees(first_name, last_name, department:departments(name)), session:training_sessions(training_program_id, program:training_programs(budget_amount))')
      .eq('enrollment_status', 'COMPLETED').limit(500);
    const map: Record<string, { name: string; dept: string; cost: number; count: number }> = {};
    (data ?? []).forEach((r: any) => {
      const k = r.employee_id;
      const empName = r.employee ? `${r.employee.first_name} ${r.employee.last_name}` : k.substring(0, 8);
      const deptName = r.employee?.department?.name ?? '—';
      const cost = Number(r.session?.program?.budget_amount) || 0;
      if (!map[k]) map[k] = { name: empName, dept: deptName, cost: 0, count: 0 };
      map[k].cost  += cost;
      map[k].count += 1;
    });
    setRows(Object.values(map).map(v => ({
      employee_name: v.name, dept: v.dept, programs: v.count,
      total_cost: v.cost, avg_cost: v.count > 0 ? v.cost / v.count : 0,
    })).sort((a, b) => b.total_cost - a.total_cost));
    setLoading(false);
  }, [sb]);

  useEffect(() => { load(); }, [load]);
  const totalCost = rows.reduce((s, r) => s + r.total_cost, 0);

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2"><TrendingUp className="h-4 w-4 text-primary" /><span className="font-semibold">Training Cost per Employee</span></div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground">Total: <span className="font-bold text-foreground">{totalCost.toLocaleString()}</span></span>
            <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => exportToCsv(rows as unknown as Record<string,unknown>[], 'Training_Cost_Analytics')}>
              <Download className="h-3 w-3" />Export CSV
            </Button>
          </div>
        </div>
        {loading ? <div className="space-y-2">{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-10 w-full"/>)}</div> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Department</TableHead>
                <TableHead className="whitespace-nowrap text-right">Programs</TableHead>
                <TableHead className="whitespace-nowrap text-right">Total Cost</TableHead>
                <TableHead className="whitespace-nowrap text-right">Avg Cost/Program</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0
                  ? <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">No training cost data found.</TableCell></TableRow>
                  : rows.map((r, i) => (
                    <TableRow key={i}>
                      <TableCell className="whitespace-nowrap font-medium">{r.employee_name}</TableCell>
                      <TableCell className="whitespace-nowrap">{r.dept}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">{r.programs}</TableCell>
                      <TableCell className="whitespace-nowrap text-right font-semibold">{r.total_cost.toLocaleString()}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">{r.avg_cost.toFixed(0)}</TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ────────────────────────────────────────────────────────────────────────────
   TrainerPerformanceTab  (FR-TRND-013)
──────────────────────────────────────────────────────────────────────────── */
function TrainerPerformanceTab() {
  const sb = _sb as any; // eslint-disable-line @typescript-eslint/no-explicit-any
  const [rows, setRows] = useState<{
    trainer_name: string; sessions: number; total_trainees: number;
    avg_rating: number; completion_rate: number;
  }[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('trainers').select('id, trainer_name, average_rating').limit(100);
    const trainerIds = (data ?? []).map((t: { id: string }) => t.id);
    const { data: reqs } = trainerIds.length > 0
      ? await sb.from('training_sessions').select('trainer_id, session_status, registered_count').in('trainer_id', trainerIds).limit(1000)
      : { data: [] };
    const reqMap: Record<string, { sessions: number; completed: number; trainees: number }> = {};
    (reqs ?? []).forEach((r: { trainer_id: string; session_status: string; registered_count?: number }) => {
      if (!reqMap[r.trainer_id]) reqMap[r.trainer_id] = { sessions: 0, completed: 0, trainees: 0 };
      reqMap[r.trainer_id].sessions++;
      reqMap[r.trainer_id].trainees += (r.registered_count || 0);
      if (r.session_status === 'COMPLETED') reqMap[r.trainer_id].completed++;
    });
    setRows((data ?? []).map((t: { id: string; trainer_name: string; average_rating: number }) => {
      const m = reqMap[t.id] ?? { sessions: 0, completed: 0, trainees: 0 };
      return {
        trainer_name: t.trainer_name, sessions: m.sessions, total_trainees: m.trainees,
        avg_rating: t.average_rating ?? 0,
        completion_rate: m.sessions > 0 ? (m.completed / m.sessions) * 100 : 0,
      };
    }));
    setLoading(false);
  }, [sb]);

  useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2"><PieChart className="h-4 w-4 text-primary" /><span className="font-semibold">Trainer Performance &amp; Evaluation</span></div>
          <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => exportToCsv(rows as unknown as Record<string,unknown>[], 'Trainer_Performance')}>
            <Download className="h-3 w-3" />Export CSV
          </Button>
        </div>
        {loading ? <div className="space-y-2">{Array.from({length:4}).map((_,i)=><Skeleton key={i} className="h-10 w-full"/>)}</div> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Trainer</TableHead>
                <TableHead className="whitespace-nowrap text-right">Sessions</TableHead>
                <TableHead className="whitespace-nowrap text-right">Trainees (est.)</TableHead>
                <TableHead className="whitespace-nowrap text-right">Avg Rating</TableHead>
                <TableHead className="whitespace-nowrap text-right">Completion</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0
                  ? <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">No trainers found.</TableCell></TableRow>
                  : rows.map((r, i) => (
                    <TableRow key={i}>
                      <TableCell className="whitespace-nowrap font-medium">{r.trainer_name}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">{r.sessions}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">{r.total_trainees}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Star className="h-3.5 w-3.5 text-amber-500 fill-amber-500" />
                          <span>{r.avg_rating.toFixed(1)}</span>
                        </div>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-right">
                        <Badge variant={r.completion_rate >= 80 ? 'default' : r.completion_rate >= 60 ? 'secondary' : 'destructive'}>{r.completion_rate.toFixed(0)}%</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ────────────────────────────────────────────────────────────────────────────
   TDReportingTab  (FR-TRND-014)
──────────────────────────────────────────────────────────────────────────── */
function TDReportingTab() {
  const sb = _sb as any; // eslint-disable-line @typescript-eslint/no-explicit-any
  const [stats, setStats] = useState({ total_requests: 0, approved: 0, completed: 0, total_cost: 0, avg_cost: 0, completion_rate: 0 });
  const [deptBreakdown, setDeptBreakdown] = useState<{ dept: string; count: number; cost: number }[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('training_requests')
      .select('request_status, estimated_budget, department:departments(name)').limit(1000);
    const allRows = data ?? [];
    const total     = allRows.length;
    const approved  = allRows.filter((r: { request_status: string }) => r.request_status === 'APPROVED').length;
    const completed = allRows.filter((r: { request_status: string }) => r.request_status === 'COMPLETED').length;
    const totalCost = allRows.reduce((s: number, r: { estimated_budget?: number }) => s + (Number(r.estimated_budget) || 0), 0);
    const dMap: Record<string, { count: number; cost: number }> = {};
    allRows.forEach((r: any) => {
      const d = r.department?.name ?? 'Unassigned';
      if (!dMap[d]) dMap[d] = { count: 0, cost: 0 };
      dMap[d].count++; dMap[d].cost += Number(r.estimated_budget) || 0;
    });
    setStats({ total_requests: total, approved, completed, total_cost: totalCost, avg_cost: total > 0 ? totalCost / total : 0, completion_rate: total > 0 ? (completed / total) * 100 : 0 });
    setDeptBreakdown(Object.entries(dMap).map(([dept, v]) => ({ dept, count: v.count, cost: v.cost })).sort((a, b) => b.cost - a.cost));
    setLoading(false);
  }, [sb]);

  useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardContent className="p-4 space-y-4">
        <div className="flex items-center justify-between"><div className="flex items-center gap-2"><BookOpen className="h-4 w-4 text-primary" /><span className="font-semibold">Training &amp; Development Report</span></div>
          <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => exportToCsv(deptBreakdown as unknown as Record<string,unknown>[], 'TD_Reporting')}>
            <Download className="h-3 w-3" />Export CSV
          </Button>
        </div>
        {loading ? <div className="space-y-2">{Array.from({length:4}).map((_,i)=><Skeleton key={i} className="h-12 w-full"/>)}</div> : (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {[
                { label: 'Total Requests',   value: String(stats.total_requests) },
                { label: 'Approved',         value: String(stats.approved) },
                { label: 'Completed',        value: String(stats.completed) },
                { label: 'Total Cost',       value: stats.total_cost.toLocaleString() },
                { label: 'Avg Cost/Program', value: stats.avg_cost.toFixed(0) },
                { label: 'Completion Rate',  value: `${stats.completion_rate.toFixed(1)}%` },
              ].map(({ label, value }) => (
                <div key={label} className="p-3 rounded-lg bg-muted/40">
                  <p className="text-lg font-bold">{value}</p>
                  <p className="text-xs text-muted-foreground">{label}</p>
                </div>
              ))}
            </div>
            <div>
              <p className="text-sm font-medium mb-2">Training by Department</p>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader><TableRow>
                    <TableHead className="whitespace-nowrap">Department</TableHead>
                    <TableHead className="whitespace-nowrap text-right">Programs</TableHead>
                    <TableHead className="whitespace-nowrap text-right">Total Cost</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {deptBreakdown.length === 0
                      ? <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground py-6">No training records.</TableCell></TableRow>
                      : deptBreakdown.map((r, i) => (
                        <TableRow key={i}>
                          <TableCell className="whitespace-nowrap font-medium">{r.dept}</TableCell>
                          <TableCell className="whitespace-nowrap text-right">{r.count}</TableCell>
                          <TableCell className="whitespace-nowrap text-right">{r.cost.toLocaleString()}</TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

