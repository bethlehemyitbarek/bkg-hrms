// TrainingSessionDetailPage — Module 9.4 Session + 9.5 Enrollment + 9.6 Evaluation
import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft, Plus, Star, CheckCircle2, XCircle, Clock } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

type Session = {
  id: string; training_session_id: string; session_number: string;
  session_title: string; start_datetime: string; end_datetime: string;
  location?: string; online_meeting_url?: string;
  max_participants?: number; registered_count: number;
  session_status: string; notes?: string;
  trainer?: { trainer_name: string; trainer_type: string };
  program?: { program_name: string; program_number: string; program_type: string };
};
type Enrollment = {
  id: string; training_enrollment_id: string; enrollment_number: string;
  enrollment_status: string; enrolled_at: string;
  employee?: { first_name: string; last_name: string; employee_no?: string };
  evaluation?: Evaluation;
};
type Evaluation = {
  id: string; training_evaluation_id: string;
  overall_rating?: number; content_rating?: number;
  trainer_rating?: number; logistics_rating?: number;
  assessment_score?: number; assessment_passed: number;
  strengths?: string; areas_for_improvement?: string;
  comments?: string; evaluation_date: string;
};

const ENROLL_COLORS: Record<string, string> = {
  ENROLLED: 'bg-blue-100 text-blue-800',
  CONFIRMED: 'bg-indigo-100 text-indigo-800',
  ATTENDED: 'bg-green-100 text-green-800',
  ABSENT: 'bg-red-100 text-red-800',
  WITHDRAWN: 'bg-muted text-muted-foreground',
  WAITLISTED: 'bg-yellow-100 text-yellow-800',
};
const SES_STATUS_COLORS: Record<string, string> = {
  SCHEDULED: 'bg-blue-100 text-blue-800',
  IN_PROGRESS: 'bg-yellow-100 text-yellow-800',
  COMPLETED: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-red-100 text-red-800',
  POSTPONED: 'bg-orange-100 text-orange-800',
};

function StarRating({ value }: { value?: number }) {
  if (!value) return <span className="text-muted-foreground text-sm">—</span>;
  return (
    <span className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={`w-3 h-3 ${i < Math.round(value) ? 'text-yellow-500 fill-yellow-500' : 'text-muted-foreground'}`} />
      ))}
      <span className="text-xs ml-1">{value.toFixed(1)}</span>
    </span>
  );
}

export function TrainingSessionDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('enrollments');

  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [enrollLoading, setEnrollLoading] = useState(false);

  // Employees for enrollment
  const [employees, setEmployees] = useState<{ id: string; first_name: string; last_name: string; employee_no?: string }[]>([]);
  const [enrollEmployeeId, setEnrollEmployeeId] = useState('');
  const [enrollOpen, setEnrollOpen] = useState(false);
  const [enrollSaving, setEnrollSaving] = useState(false);

  // Evaluation dialog
  const [evalOpen, setEvalOpen] = useState<Enrollment | null>(null);
  const [evalForm, setEvalForm] = useState({
    overall_rating: '', content_rating: '', trainer_rating: '',
    logistics_rating: '', assessment_score: '', assessment_passed: '0',
    strengths: '', areas_for_improvement: '', comments: '',
    evaluation_date: new Date().toISOString().split('T')[0],
  });
  const [evalSaving, setEvalSaving] = useState(false);

  const loadSession = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const { data, error } = await sb.from('training_sessions')
        .select('id,training_session_id,session_number,session_title,start_datetime,end_datetime,location,online_meeting_url,max_participants,registered_count,session_status,notes,trainer:trainers(trainer_name,trainer_type),program:training_programs(program_name,program_number,program_type)')
        .eq('training_session_id', id)
        .eq('is_deleted', 0)
        .maybeSingle();
      if (error) throw error;
      setSession(data);
    } catch (e: any) { toast.error(e.message); } finally { setLoading(false); }
  }, [id]);

  const loadEnrollments = useCallback(async () => {
    if (!id) return;
    setEnrollLoading(true);
    try {
      const { data, error } = await sb.from('training_enrollments')
        .select('id,training_enrollment_id,enrollment_number,enrollment_status,enrolled_at,employee:employees(first_name,last_name,employee_no),evaluation:training_evaluations(id,training_evaluation_id,overall_rating,content_rating,trainer_rating,logistics_rating,assessment_score,assessment_passed,strengths,areas_for_improvement,comments,evaluation_date)')
        .eq('training_session_id', id)
        .eq('is_deleted', 0)
        .order('enrolled_at', { ascending: true });
      if (error) throw error;
      setEnrollments(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setEnrollLoading(false); }
  }, [id]);

  const loadEmployees = useCallback(async () => {
    const { data } = await sb.from('employees').select('id,first_name,last_name,employee_no').eq('status', 'active').order('first_name').limit(200);
    setEmployees(Array.isArray(data) ? data : []);
  }, []);

  useEffect(() => { loadSession(); loadEmployees(); }, [loadSession, loadEmployees]);
  useEffect(() => { if (tab === 'enrollments') loadEnrollments(); }, [tab, loadEnrollments]);

  async function enrollEmployee() {
    if (!enrollEmployeeId) { toast.error('Select an employee'); return; }
    setEnrollSaving(true);
    try {
      const { error } = await sb.from('training_enrollments').insert({
        training_session_id: id,
        employee_id: enrollEmployeeId,
        enrollment_status: 'ENROLLED',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      // Increment registered_count
      await sb.from('training_sessions').update({ registered_count: (session?.registered_count ?? 0) + 1, updated_at: new Date().toISOString() }).eq('training_session_id', id);
      toast.success('Employee enrolled');
      setEnrollOpen(false);
      setEnrollEmployeeId('');
      loadEnrollments();
      loadSession();
    } catch (e: any) { toast.error(e.message); } finally { setEnrollSaving(false); }
  }

  async function updateEnrollmentStatus(enrollId: string, status: string) {
    const update: Record<string, any> = { enrollment_status: status, updated_at: new Date().toISOString() };
    if (status === 'ATTENDED') update.attended_at = new Date().toISOString();
    if (status === 'CONFIRMED') update.confirmed_at = new Date().toISOString();
    const { error } = await sb.from('training_enrollments').update(update).eq('id', enrollId);
    if (error) toast.error(error.message);
    else { toast.success('Status updated'); loadEnrollments(); }
  }

  async function submitEvaluation() {
    if (!evalOpen) return;
    setEvalSaving(true);
    try {
      const payload: Record<string, any> = {
        training_enrollment_id: evalOpen.training_enrollment_id,
        training_session_id: id,
        employee_id: evalOpen.employee,
        evaluation_date: evalForm.evaluation_date,
        assessment_passed: parseInt(evalForm.assessment_passed),
        updated_at: new Date().toISOString(),
      };
      // Get employee_id from enrollment
      const { data: enrData } = await sb.from('training_enrollments').select('employee_id').eq('id', evalOpen.id).maybeSingle();
      payload.employee_id = enrData?.employee_id;
      if (evalForm.overall_rating) payload.overall_rating = parseFloat(evalForm.overall_rating);
      if (evalForm.content_rating) payload.content_rating = parseFloat(evalForm.content_rating);
      if (evalForm.trainer_rating) payload.trainer_rating = parseFloat(evalForm.trainer_rating);
      if (evalForm.logistics_rating) payload.logistics_rating = parseFloat(evalForm.logistics_rating);
      if (evalForm.assessment_score) payload.assessment_score = parseFloat(evalForm.assessment_score);
      if (evalForm.strengths) payload.strengths = evalForm.strengths;
      if (evalForm.areas_for_improvement) payload.areas_for_improvement = evalForm.areas_for_improvement;
      if (evalForm.comments) payload.comments = evalForm.comments;

      const { error } = await sb.from('training_evaluations').insert(payload);
      if (error) throw error;
      toast.success('Evaluation submitted');
      setEvalOpen(null);
      setEvalForm({ overall_rating: '', content_rating: '', trainer_rating: '', logistics_rating: '', assessment_score: '', assessment_passed: '0', strengths: '', areas_for_improvement: '', comments: '', evaluation_date: new Date().toISOString().split('T')[0] });
      loadEnrollments();
    } catch (e: any) { toast.error(e.message); } finally { setEvalSaving(false); }
  }

  const fmtDateTime = (dt: string) => {
    try { return new Date(dt).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }
    catch { return dt; }
  };

  const avgRating = enrollments.reduce((sum, e) => sum + (e.evaluation?.overall_rating ?? 0), 0) /
    (enrollments.filter(e => e.evaluation?.overall_rating).length || 1);
  const attended = enrollments.filter(e => e.enrollment_status === 'ATTENDED').length;

  if (loading) return <div className="p-6 space-y-4"><Skeleton className="h-8 w-64 bg-muted" /><Skeleton className="h-32 w-full bg-muted" /></div>;
  if (!session) return (
    <div className="p-6">
      <Button variant="ghost" onClick={() => navigate('/training/programs')}><ArrowLeft className="w-4 h-4 mr-1" />Back</Button>
      <p className="text-muted-foreground mt-4">Session not found.</p>
    </div>
  );

  return (
    <div className="p-4 md:p-6 space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
        <div>
          <Button variant="ghost" size="sm" className="mb-2 -ml-2" onClick={() => navigate('/training/programs')}>
            <ArrowLeft className="w-4 h-4 mr-1" /> Back to Programs
          </Button>
          <h1 className="text-xl font-semibold">{session.session_title}</h1>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            <span className="text-sm font-mono text-muted-foreground">{session.session_number}</span>
            <Badge className={`text-xs ${SES_STATUS_COLORS[session.session_status]}`}>{session.session_status}</Badge>
            {session.program && <Badge variant="secondary" className="text-xs">{session.program.program_name}</Badge>}
          </div>
        </div>
      </div>

      {/* Session info */}
      <Card className="h-full">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div><p className="text-muted-foreground">Trainer</p><p className="font-medium">{session.trainer?.trainer_name ?? '—'}</p></div>
            <div><p className="text-muted-foreground">Start</p><p className="font-medium">{fmtDateTime(session.start_datetime)}</p></div>
            <div><p className="text-muted-foreground">End</p><p className="font-medium">{fmtDateTime(session.end_datetime)}</p></div>
            <div><p className="text-muted-foreground">Location</p><p className="font-medium">{session.location ?? (session.online_meeting_url ? 'Online' : '—')}</p></div>
            <div><p className="text-muted-foreground">Registrations</p><p className="font-medium">{session.registered_count}{session.max_participants ? ` / ${session.max_participants}` : ''}</p></div>
            <div><p className="text-muted-foreground">Attended</p><p className="font-medium">{attended}</p></div>
            <div><p className="text-muted-foreground">Avg Rating</p><StarRating value={enrollments.some(e => e.evaluation?.overall_rating) ? avgRating : undefined} /></div>
            {session.online_meeting_url && <div><p className="text-muted-foreground">Meeting URL</p><a href={session.online_meeting_url} target="_blank" rel="noreferrer" className="text-primary text-xs underline">Join</a></div>}
          </div>
        </CardContent>
      </Card>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="enrollments">Enrollments ({enrollments.length})</TabsTrigger>
          <TabsTrigger value="evaluations">Evaluations ({enrollments.filter(e => e.evaluation).length})</TabsTrigger>
        </TabsList>

        {/* ── Enrollments ── */}
        <TabsContent value="enrollments" className="mt-4 space-y-3">
          <div className="flex justify-end">
            <Button size="sm" onClick={() => setEnrollOpen(true)}><Plus className="w-4 h-4 mr-1" /> Enroll Employee</Button>
          </div>
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Enrollment #</TableHead>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Enrolled At</TableHead>
                  <TableHead className="whitespace-nowrap">Evaluated</TableHead>
                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {enrollLoading ? (
                  Array.from({ length: 4 }).map((_, i) => <TableRow key={i}><TableCell colSpan={6}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>)
                ) : enrollments.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-10">No enrollments yet.</TableCell></TableRow>
                ) : enrollments.map(e => (
                  <TableRow key={e.id}>
                    <TableCell className="whitespace-nowrap font-mono text-sm">{e.enrollment_number}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">
                      {e.employee ? `${e.employee.first_name} ${e.employee.last_name}` : '—'}
                      {e.employee?.employee_no && <span className="ml-1 text-xs text-muted-foreground">({e.employee.employee_no})</span>}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${ENROLL_COLORS[e.enrollment_status]}`}>{e.enrollment_status}</Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{new Date(e.enrolled_at).toLocaleDateString()}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      {e.evaluation
                        ? <CheckCircle2 className="w-4 h-4 text-green-600" />
                        : <XCircle className="w-4 h-4 text-muted-foreground" />}
                    </TableCell>
                    <TableCell className="text-right whitespace-nowrap">
                      <div className="flex gap-1 justify-end">
                        <Select onValueChange={v => updateEnrollmentStatus(e.id, v)}>
                          <SelectTrigger className="h-7 text-xs w-28"><SelectValue placeholder="Status" /></SelectTrigger>
                          <SelectContent>
                            {['ENROLLED', 'CONFIRMED', 'ATTENDED', 'ABSENT', 'WITHDRAWN', 'WAITLISTED'].map(s => (
                              <SelectItem key={s} value={s}>{s}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {!e.evaluation && (
                          <Button size="sm" variant="ghost" onClick={() => {
                            setEvalOpen(e);
                            setEvalForm({ overall_rating: '', content_rating: '', trainer_rating: '', logistics_rating: '', assessment_score: '', assessment_passed: '0', strengths: '', areas_for_improvement: '', comments: '', evaluation_date: new Date().toISOString().split('T')[0] });
                          }}>
                            <Star className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* ── Evaluations ── */}
        <TabsContent value="evaluations" className="mt-4 space-y-3">
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Overall</TableHead>
                  <TableHead className="whitespace-nowrap">Content</TableHead>
                  <TableHead className="whitespace-nowrap">Trainer</TableHead>
                  <TableHead className="whitespace-nowrap">Logistics</TableHead>
                  <TableHead className="whitespace-nowrap">Score</TableHead>
                  <TableHead className="whitespace-nowrap">Passed</TableHead>
                  <TableHead className="whitespace-nowrap">Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {enrollments.filter(e => e.evaluation).length === 0 ? (
                  <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground py-10">No evaluations submitted yet.</TableCell></TableRow>
                ) : enrollments.filter(e => e.evaluation).map(e => (
                  <TableRow key={e.id}>
                    <TableCell className="whitespace-nowrap font-medium">
                      {e.employee ? `${e.employee.first_name} ${e.employee.last_name}` : '—'}
                    </TableCell>
                    <TableCell className="whitespace-nowrap"><StarRating value={e.evaluation?.overall_rating} /></TableCell>
                    <TableCell className="whitespace-nowrap"><StarRating value={e.evaluation?.content_rating} /></TableCell>
                    <TableCell className="whitespace-nowrap"><StarRating value={e.evaluation?.trainer_rating} /></TableCell>
                    <TableCell className="whitespace-nowrap"><StarRating value={e.evaluation?.logistics_rating} /></TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{e.evaluation?.assessment_score ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      {e.evaluation?.assessment_passed
                        ? <CheckCircle2 className="w-4 h-4 text-green-600" />
                        : <XCircle className="w-4 h-4 text-red-500" />}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{e.evaluation?.evaluation_date}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      {/* ── Enroll Dialog ── */}
      <Dialog open={enrollOpen} onOpenChange={setEnrollOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Enroll Employee</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div>
              <Label>Employee *</Label>
              <Select value={enrollEmployeeId} onValueChange={setEnrollEmployeeId}>
                <SelectTrigger><SelectValue placeholder="Select employee" /></SelectTrigger>
                <SelectContent>
                  {employees.filter(emp => !enrollments.some(en => en.employee && `${en.employee.first_name} ${en.employee.last_name}` === `${emp.first_name} ${emp.last_name}`)).map(emp => (
                    <SelectItem key={emp.id} value={emp.id}>{emp.first_name} {emp.last_name}{emp.employee_no ? ` (${emp.employee_no})` : ''}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setEnrollOpen(false)}>Cancel</Button>
              <Button onClick={enrollEmployee} disabled={enrollSaving}>{enrollSaving ? 'Enrolling…' : 'Enroll'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Evaluation Dialog ── */}
      <Dialog open={!!evalOpen} onOpenChange={() => setEvalOpen(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Submit Evaluation — {evalOpen?.employee ? `${evalOpen.employee.first_name} ${evalOpen.employee.last_name}` : ''}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { key: 'overall_rating', label: 'Overall (1–5)' },
                { key: 'content_rating', label: 'Content (1–5)' },
                { key: 'trainer_rating', label: 'Trainer (1–5)' },
                { key: 'logistics_rating', label: 'Logistics (1–5)' },
              ].map(({ key, label }) => (
                <div key={key}>
                  <Label>{label}</Label>
                  <Input type="number" min="1" max="5" step="0.1"
                    value={(evalForm as any)[key]}
                    onChange={e => setEvalForm(f => ({ ...f, [key]: e.target.value }))}
                    placeholder="e.g. 4.5" />
                </div>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Assessment Score</Label><Input type="number" min="0" max="100" step="0.01" value={evalForm.assessment_score} onChange={e => setEvalForm(f => ({ ...f, assessment_score: e.target.value }))} placeholder="0–100" /></div>
              <div>
                <Label>Assessment Passed</Label>
                <Select value={evalForm.assessment_passed} onValueChange={v => setEvalForm(f => ({ ...f, assessment_passed: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="1">Yes</SelectItem><SelectItem value="0">No</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Evaluation Date</Label><Input type="date" value={evalForm.evaluation_date} onChange={e => setEvalForm(f => ({ ...f, evaluation_date: e.target.value }))} /></div>
            <div><Label>Strengths</Label><Textarea value={evalForm.strengths} onChange={e => setEvalForm(f => ({ ...f, strengths: e.target.value }))} rows={2} /></div>
            <div><Label>Areas for Improvement</Label><Textarea value={evalForm.areas_for_improvement} onChange={e => setEvalForm(f => ({ ...f, areas_for_improvement: e.target.value }))} rows={2} /></div>
            <div><Label>Additional Comments</Label><Textarea value={evalForm.comments} onChange={e => setEvalForm(f => ({ ...f, comments: e.target.value }))} rows={2} /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setEvalOpen(null)}>Cancel</Button>
              <Button onClick={submitEvaluation} disabled={evalSaving}>{evalSaving ? 'Submitting…' : 'Submit'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
