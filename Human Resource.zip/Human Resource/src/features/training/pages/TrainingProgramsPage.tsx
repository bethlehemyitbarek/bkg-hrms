// TrainingProgramsPage — Module 9.3 TrainingProgram + 9.4 TrainingSession
import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Eye, BookOpen, Calendar, Users, ChevronDown, ChevronRight, Clock } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

// ─── Types ───────────────────────────────────────────────────────────────────
type Program = {
  id: string; training_program_id: string; program_number: string;
  program_name: string; program_type: string; delivery_mode: string;
  duration_hours?: number; max_participants?: number;
  program_status: string; description?: string;
  cost_per_participant?: number; currency_code: string;
  department?: { name: string };
  sessions?: Session[];
};
type Session = {
  id: string; training_session_id: string; session_number: string;
  session_title: string; start_datetime: string; end_datetime: string;
  location?: string; online_meeting_url?: string;
  max_participants?: number; registered_count: number;
  session_status: string; notes?: string;
  trainer?: { trainer_name: string; trainer_type: string };
};

const PROG_STATUS_COLORS: Record<string, string> = {
  DRAFT: 'bg-muted text-muted-foreground',
  ACTIVE: 'bg-green-100 text-green-800',
  ARCHIVED: 'bg-yellow-100 text-yellow-800',
};
const SES_STATUS_COLORS: Record<string, string> = {
  SCHEDULED: 'bg-blue-100 text-blue-800',
  IN_PROGRESS: 'bg-yellow-100 text-yellow-800',
  COMPLETED: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-red-100 text-red-800',
  POSTPONED: 'bg-orange-100 text-orange-800',
};
const PROG_TYPES = ['TECHNICAL', 'SOFT_SKILLS', 'COMPLIANCE', 'LEADERSHIP', 'ONBOARDING', 'OTHER'];
const DELIVERY_MODES = ['CLASSROOM', 'ONLINE', 'BLENDED', 'ON_THE_JOB'];

export function TrainingProgramsPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState('programs');

  // Programs
  const [programs, setPrograms] = useState<Program[]>([]);
  const [progLoading, setProgLoading] = useState(true);
  const [progSearch, setProgSearch] = useState('');
  const [progStatusFilter, setProgStatusFilter] = useState('all');
  const [progTypeFilter, setProgTypeFilter] = useState('all');
  const [expandedProg, setExpandedProg] = useState<string | null>(null);

  // Sessions
  const [sessions, setSessions] = useState<Session[]>([]);
  const [sesLoading, setSesLoading] = useState(false);
  const [sesSearch, setSesSearch] = useState('');
  const [sesStatusFilter, setSesStatusFilter] = useState('all');

  // Refs
  const [departments, setDepartments] = useState<{ id: string; name: string }[]>([]);
  const [trainers, setTrainers] = useState<{ trainer_id: string; trainer_name: string; trainer_type: string }[]>([]);
  const [trainingRequests, setTrainingRequests] = useState<{ training_request_id: string; request_number: string; training_topic: string }[]>([]);

  // Create Program dialog
  const [createProgOpen, setCreateProgOpen] = useState(false);
  const [progForm, setProgForm] = useState({
    program_name: '', program_type: 'TECHNICAL', delivery_mode: 'CLASSROOM',
    duration_hours: '', max_participants: '', description: '',
    cost_per_participant: '', currency_code: 'ETB',
    department_id: '', training_request_id: '',
  });
  const [progSaving, setProgSaving] = useState(false);

  // Add Session dialog
  const [addSesOpen, setAddSesOpen] = useState<string | null>(null); // program_id
  const [sesForm, setSesForm] = useState({
    session_title: '', trainer_id: '', start_datetime: '', end_datetime: '',
    location: '', online_meeting_url: '', max_participants: '', notes: '',
  });
  const [sesSaving, setSesSaving] = useState(false);

  // Stats
  const activePrograms = programs.filter(p => p.program_status === 'ACTIVE').length;
  const totalSessions = sessions.length;
  const scheduledSessions = sessions.filter(s => s.session_status === 'SCHEDULED').length;
  const totalRegistrations = sessions.reduce((sum, s) => sum + (s.registered_count || 0), 0);

  const loadPrograms = useCallback(async () => {
    setProgLoading(true);
    try {
      let q = sb.from('training_programs')
        .select('id,training_program_id,program_number,program_name,program_type,delivery_mode,duration_hours,max_participants,program_status,description,cost_per_participant,currency_code,department:departments(name),sessions:training_sessions(id,training_session_id,session_number,session_title,start_datetime,end_datetime,location,max_participants,registered_count,session_status,trainer:trainers(trainer_name,trainer_type))')
        .eq('is_deleted', 0).order('created_at', { ascending: false });
      if (progStatusFilter !== 'all') q = q.eq('program_status', progStatusFilter);
      if (progTypeFilter !== 'all') q = q.eq('program_type', progTypeFilter);
      const { data, error } = await q;
      if (error) throw error;
      setPrograms(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setProgLoading(false); }
  }, [progStatusFilter, progTypeFilter]);

  const loadSessions = useCallback(async () => {
    setSesLoading(true);
    try {
      let q = sb.from('training_sessions')
        .select('id,training_session_id,session_number,session_title,start_datetime,end_datetime,location,online_meeting_url,max_participants,registered_count,session_status,notes,trainer:trainers(trainer_name,trainer_type),program:training_programs(program_name,program_number)')
        .eq('is_deleted', 0).order('start_datetime', { ascending: true });
      if (sesStatusFilter !== 'all') q = q.eq('session_status', sesStatusFilter);
      const { data, error } = await q;
      if (error) throw error;
      setSessions(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setSesLoading(false); }
  }, [sesStatusFilter]);

  const loadRefs = useCallback(async () => {
    const [deptRes, trainerRes, reqRes] = await Promise.all([
      sb.from('departments').select('id,name').order('name').limit(100),
      sb.from('trainers').select('trainer_id,trainer_name,trainer_type').eq('trainer_status', 'ACTIVE').eq('is_deleted', 0).order('trainer_name').limit(100),
      sb.from('training_requests').select('training_request_id,request_number,training_topic').eq('request_status', 'APPROVED').eq('is_deleted', 0).order('created_at', { ascending: false }).limit(100),
    ]);
    setDepartments(Array.isArray(deptRes.data) ? deptRes.data : []);
    setTrainers(Array.isArray(trainerRes.data) ? trainerRes.data : []);
    setTrainingRequests(Array.isArray(reqRes.data) ? reqRes.data : []);
  }, []);

  useEffect(() => { loadPrograms(); loadRefs(); }, [loadPrograms, loadRefs]);
  useEffect(() => { if (tab === 'sessions') loadSessions(); }, [tab, loadSessions]);

  const filteredPrograms = programs.filter(p =>
    p.program_name.toLowerCase().includes(progSearch.toLowerCase()) ||
    p.program_number.toLowerCase().includes(progSearch.toLowerCase()) ||
    (p.department?.name ?? '').toLowerCase().includes(progSearch.toLowerCase())
  );

  const filteredSessions = (sessions as any[]).filter((s: any) =>
    s.session_title.toLowerCase().includes(sesSearch.toLowerCase()) ||
    s.session_number.toLowerCase().includes(sesSearch.toLowerCase()) ||
    (s.trainer?.trainer_name ?? '').toLowerCase().includes(sesSearch.toLowerCase())
  );

  async function createProgram() {
    if (!progForm.program_name.trim()) { toast.error('Program name required'); return; }
    setProgSaving(true);
    try {
      const { error } = await sb.from('training_programs').insert({
        program_name: progForm.program_name.trim(),
        program_type: progForm.program_type,
        delivery_mode: progForm.delivery_mode,
        duration_hours: progForm.duration_hours ? parseFloat(progForm.duration_hours) : null,
        max_participants: progForm.max_participants ? parseInt(progForm.max_participants) : null,
        description: progForm.description || null,
        cost_per_participant: progForm.cost_per_participant ? parseFloat(progForm.cost_per_participant) : null,
        currency_code: progForm.currency_code,
        department_id: progForm.department_id || null,
        training_request_id: progForm.training_request_id || null,
        program_status: 'DRAFT',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Training program created');
      setCreateProgOpen(false);
      setProgForm({ program_name: '', program_type: 'TECHNICAL', delivery_mode: 'CLASSROOM', duration_hours: '', max_participants: '', description: '', cost_per_participant: '', currency_code: 'ETB', department_id: '', training_request_id: '' });
      loadPrograms();
    } catch (e: any) { toast.error(e.message); } finally { setProgSaving(false); }
  }

  async function addSession() {
    if (!sesForm.session_title.trim() || !sesForm.start_datetime || !sesForm.end_datetime || !addSesOpen) {
      toast.error('Title, start and end datetime required'); return;
    }
    if (new Date(sesForm.end_datetime) <= new Date(sesForm.start_datetime)) {
      toast.error('End time must be after start time'); return;
    }
    setSesSaving(true);
    try {
      const { error } = await sb.from('training_sessions').insert({
        training_program_id: addSesOpen,
        session_title: sesForm.session_title.trim(),
        trainer_id: sesForm.trainer_id || null,
        start_datetime: sesForm.start_datetime,
        end_datetime: sesForm.end_datetime,
        location: sesForm.location || null,
        online_meeting_url: sesForm.online_meeting_url || null,
        max_participants: sesForm.max_participants ? parseInt(sesForm.max_participants) : null,
        notes: sesForm.notes || null,
        session_status: 'SCHEDULED',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Session scheduled');
      setAddSesOpen(null);
      setSesForm({ session_title: '', trainer_id: '', start_datetime: '', end_datetime: '', location: '', online_meeting_url: '', max_participants: '', notes: '' });
      loadPrograms();
    } catch (e: any) { toast.error(e.message); } finally { setSesSaving(false); }
  }

  async function activateProgram(progId: string) {
    const { error } = await sb.from('training_programs').update({ program_status: 'ACTIVE', updated_at: new Date().toISOString() }).eq('id', progId);
    if (error) toast.error(error.message);
    else { toast.success('Program activated'); loadPrograms(); }
  }

  async function updateSessionStatus(sesId: string, status: string) {
    const { error } = await sb.from('training_sessions').update({ session_status: status, updated_at: new Date().toISOString() }).eq('id', sesId);
    if (error) toast.error(error.message);
    else { toast.success('Session status updated'); if (tab === 'sessions') loadSessions(); else loadPrograms(); }
  }

  const fmtDateTime = (dt: string) => {
    try { return new Date(dt).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }
    catch { return dt; }
  };

  return (
    <div className="p-4 md:p-6 space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Training Programs</h1>
          <p className="text-sm text-muted-foreground">Manage training programs, schedule sessions and track participation</p>
        </div>
        <div className="flex gap-2">
          {tab === 'programs' && <Button size="sm" onClick={() => setCreateProgOpen(true)}><Plus className="w-4 h-4 mr-1" /> New Program</Button>}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Programs', value: programs.length, icon: BookOpen },
          { label: 'Active Programs', value: activePrograms, icon: BookOpen },
          { label: 'Upcoming Sessions', value: scheduledSessions, icon: Calendar },
          { label: 'Total Registrations', value: totalRegistrations, icon: Users },
        ].map(s => (
          <Card key={s.label} className="h-full">
            <CardContent className="p-4 flex items-center gap-3">
              <s.icon className="w-8 h-8 text-primary shrink-0" />
              <div><p className="text-2xl font-bold">{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="programs">Programs ({programs.length})</TabsTrigger>
          <TabsTrigger value="sessions">All Sessions ({totalSessions})</TabsTrigger>
        </TabsList>

        {/* ── Programs Tab ── */}
        <TabsContent value="programs" className="mt-4 space-y-3">
          <div className="flex flex-col md:flex-row gap-2">
            <Input placeholder="Search programs…" value={progSearch} onChange={e => setProgSearch(e.target.value)} className="md:max-w-xs" />
            <Select value={progStatusFilter} onValueChange={setProgStatusFilter}>
              <SelectTrigger className="md:w-40"><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {['DRAFT', 'ACTIVE', 'ARCHIVED'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={progTypeFilter} onValueChange={setProgTypeFilter}>
              <SelectTrigger className="md:w-44"><SelectValue placeholder="All Types" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {PROG_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace('_', ' ')}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {progLoading ? (
            <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 w-full bg-muted" />)}</div>
          ) : filteredPrograms.length === 0 ? (
            <p className="text-center text-muted-foreground py-10">No programs found.</p>
          ) : (
            <div className="space-y-2">
              {filteredPrograms.map(p => (
                <Card key={p.id} className="h-full">
                  <div className="p-4">
                    <div className="flex items-start gap-2">
                      <button
                        className="flex items-center gap-2 text-left flex-1 min-w-0"
                        onClick={() => setExpandedProg(expandedProg === p.id ? null : p.id)}
                      >
                        {expandedProg === p.id ? <ChevronDown className="w-4 h-4 shrink-0 mt-0.5" /> : <ChevronRight className="w-4 h-4 shrink-0 mt-0.5" />}
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium truncate">{p.program_name}</span>
                            <span className="text-xs font-mono text-muted-foreground">{p.program_number}</span>
                            <Badge className={`text-xs shrink-0 ${PROG_STATUS_COLORS[p.program_status]}`}>{p.program_status}</Badge>
                            <Badge variant="secondary" className="text-xs shrink-0">{p.program_type.replace('_', ' ')}</Badge>
                            <Badge variant="outline" className="text-xs shrink-0">{p.delivery_mode.replace('_', ' ')}</Badge>
                          </div>
                          <div className="flex gap-3 mt-1 text-xs text-muted-foreground flex-wrap">
                            {p.department && <span>{p.department.name}</span>}
                            {p.duration_hours && <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{p.duration_hours}h</span>}
                            {p.max_participants && <span className="flex items-center gap-1"><Users className="w-3 h-3" />Max {p.max_participants}</span>}
                            <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{(p.sessions ?? []).length} sessions</span>
                          </div>
                        </div>
                      </button>
                      <div className="flex gap-1 shrink-0">
                        {p.program_status === 'DRAFT' && (
                          <Button size="sm" variant="ghost" className="text-xs" onClick={() => activateProgram(p.id)}>Activate</Button>
                        )}
                        <Button size="sm" variant="ghost" onClick={() => {
                          setAddSesOpen(p.training_program_id);
                          setSesForm({ session_title: '', trainer_id: '', start_datetime: '', end_datetime: '', location: '', online_meeting_url: '', max_participants: '', notes: '' });
                        }}>
                          <Plus className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => navigate(`/training/programs/${p.training_program_id}`)}>
                          <Eye className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Expanded sessions list */}
                    {expandedProg === p.id && (
                      <div className="mt-3 ml-6">
                        {(!p.sessions || p.sessions.length === 0) ? (
                          <p className="text-sm text-muted-foreground">No sessions scheduled yet.</p>
                        ) : (
                          <div className="border rounded overflow-x-auto">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead className="whitespace-nowrap">Session</TableHead>
                                  <TableHead className="whitespace-nowrap">Trainer</TableHead>
                                  <TableHead className="whitespace-nowrap">Start</TableHead>
                                  <TableHead className="whitespace-nowrap">End</TableHead>
                                  <TableHead className="whitespace-nowrap">Location</TableHead>
                                  <TableHead className="whitespace-nowrap text-center">Reg</TableHead>
                                  <TableHead className="whitespace-nowrap">Status</TableHead>
                                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {p.sessions.map(s => (
                                  <TableRow key={s.id}>
                                    <TableCell className="whitespace-nowrap">
                                      <div className="font-medium text-sm">{s.session_title}</div>
                                      <div className="text-xs font-mono text-muted-foreground">{s.session_number}</div>
                                    </TableCell>
                                    <TableCell className="whitespace-nowrap text-sm">{s.trainer?.trainer_name ?? '—'}</TableCell>
                                    <TableCell className="whitespace-nowrap text-sm">{fmtDateTime(s.start_datetime)}</TableCell>
                                    <TableCell className="whitespace-nowrap text-sm">{fmtDateTime(s.end_datetime)}</TableCell>
                                    <TableCell className="whitespace-nowrap text-sm">{s.location ?? (s.online_meeting_url ? 'Online' : '—')}</TableCell>
                                    <TableCell className="whitespace-nowrap text-center text-sm">
                                      {s.registered_count}{s.max_participants ? `/${s.max_participants}` : ''}
                                    </TableCell>
                                    <TableCell className="whitespace-nowrap">
                                      <Badge className={`text-xs ${SES_STATUS_COLORS[s.session_status]}`}>{s.session_status}</Badge>
                                    </TableCell>
                                    <TableCell className="text-right whitespace-nowrap">
                                      <Select onValueChange={v => updateSessionStatus(s.id, v)}>
                                        <SelectTrigger className="h-7 text-xs w-28"><SelectValue placeholder="Update" /></SelectTrigger>
                                        <SelectContent>
                                          {['SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED', 'POSTPONED'].map(st => (
                                            <SelectItem key={st} value={st}>{st.replace('_', ' ')}</SelectItem>
                                          ))}
                                        </SelectContent>
                                      </Select>
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ── All Sessions Tab ── */}
        <TabsContent value="sessions" className="mt-4 space-y-3">
          <div className="flex flex-col md:flex-row gap-2">
            <Input placeholder="Search sessions, trainer…" value={sesSearch} onChange={e => setSesSearch(e.target.value)} className="md:max-w-xs" />
            <Select value={sesStatusFilter} onValueChange={setSesStatusFilter}>
              <SelectTrigger className="md:w-44"><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {['SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED', 'POSTPONED'].map(s => <SelectItem key={s} value={s}>{s.replace('_', ' ')}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Session #</TableHead>
                  <TableHead className="whitespace-nowrap">Title</TableHead>
                  <TableHead className="whitespace-nowrap">Program</TableHead>
                  <TableHead className="whitespace-nowrap">Trainer</TableHead>
                  <TableHead className="whitespace-nowrap">Start</TableHead>
                  <TableHead className="whitespace-nowrap">End</TableHead>
                  <TableHead className="whitespace-nowrap">Location</TableHead>
                  <TableHead className="whitespace-nowrap text-center">Reg / Max</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sesLoading ? (
                  Array.from({ length: 5 }).map((_, i) => <TableRow key={i}><TableCell colSpan={10}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>)
                ) : filteredSessions.length === 0 ? (
                  <TableRow><TableCell colSpan={10} className="text-center text-muted-foreground py-10">No sessions found.</TableCell></TableRow>
                ) : filteredSessions.map((s: any) => (
                  <TableRow key={s.id}>
                    <TableCell className="whitespace-nowrap font-mono text-sm">{s.session_number}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">{s.session_title}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{s.program?.program_name ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{s.trainer?.trainer_name ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtDateTime(s.start_datetime)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtDateTime(s.end_datetime)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{s.location ?? (s.online_meeting_url ? 'Online' : '—')}</TableCell>
                    <TableCell className="whitespace-nowrap text-center text-sm">
                      {s.registered_count}{s.max_participants ? `/${s.max_participants}` : ''}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${SES_STATUS_COLORS[s.session_status]}`}>{s.session_status.replace('_', ' ')}</Badge>
                    </TableCell>
                    <TableCell className="text-right whitespace-nowrap">
                      <Button size="sm" variant="ghost" onClick={() => navigate(`/training/sessions/${s.training_session_id}`)}>
                        <Eye className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      {/* ── Create Program Dialog ── */}
      <Dialog open={createProgOpen} onOpenChange={setCreateProgOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>New Training Program</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div><Label>Program Name *</Label><Input value={progForm.program_name} onChange={e => setProgForm(f => ({ ...f, program_name: e.target.value }))} placeholder="e.g. Leadership Excellence Program" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Program Type</Label>
                <Select value={progForm.program_type} onValueChange={v => setProgForm(f => ({ ...f, program_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PROG_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace('_', ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Delivery Mode</Label>
                <Select value={progForm.delivery_mode} onValueChange={v => setProgForm(f => ({ ...f, delivery_mode: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{DELIVERY_MODES.map(m => <SelectItem key={m} value={m}>{m.replace('_', ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div><Label>Duration (hours)</Label><Input type="number" min="0" step="0.5" value={progForm.duration_hours} onChange={e => setProgForm(f => ({ ...f, duration_hours: e.target.value }))} placeholder="8" /></div>
              <div><Label>Max Participants</Label><Input type="number" min="1" value={progForm.max_participants} onChange={e => setProgForm(f => ({ ...f, max_participants: e.target.value }))} placeholder="20" /></div>
              <div><Label>Cost per Participant</Label><Input type="number" min="0" step="0.01" value={progForm.cost_per_participant} onChange={e => setProgForm(f => ({ ...f, cost_per_participant: e.target.value }))} placeholder="0.00" /></div>
              <div>
                <Label>Currency</Label>
                <Select value={progForm.currency_code} onValueChange={v => setProgForm(f => ({ ...f, currency_code: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['ETB', 'USD', 'EUR', 'GBP', 'MYR', 'SGD', 'AED'].map(c => <SelectItem key={c} value={c}>{c === 'ETB' ? 'ETB — ብር' : c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Department</Label>
                <Select value={progForm.department_id} onValueChange={v => setProgForm(f => ({ ...f, department_id: v }))}>
                  <SelectTrigger><SelectValue placeholder="Select dept." /></SelectTrigger>
                  <SelectContent>{departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Linked Training Request</Label>
                <Select value={progForm.training_request_id} onValueChange={v => setProgForm(f => ({ ...f, training_request_id: v }))}>
                  <SelectTrigger><SelectValue placeholder="Select request (opt.)" /></SelectTrigger>
                  <SelectContent>{trainingRequests.map(r => <SelectItem key={r.training_request_id} value={r.training_request_id}>{r.request_number} — {r.training_topic}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Description</Label><Textarea value={progForm.description} onChange={e => setProgForm(f => ({ ...f, description: e.target.value }))} rows={3} /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCreateProgOpen(false)}>Cancel</Button>
              <Button onClick={createProgram} disabled={progSaving}>{progSaving ? 'Creating…' : 'Create Program'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Add Session Dialog ── */}
      <Dialog open={!!addSesOpen} onOpenChange={() => setAddSesOpen(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>Schedule Training Session</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div><Label>Session Title *</Label><Input value={sesForm.session_title} onChange={e => setSesForm(f => ({ ...f, session_title: e.target.value }))} placeholder="e.g. Module 1 — Foundations" /></div>
            <div>
              <Label>Trainer</Label>
              <Select value={sesForm.trainer_id} onValueChange={v => setSesForm(f => ({ ...f, trainer_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Select trainer (optional)" /></SelectTrigger>
                <SelectContent>{trainers.map(t => <SelectItem key={t.trainer_id} value={t.trainer_id}>{t.trainer_name} ({t.trainer_type})</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Start Date & Time *</Label><Input type="datetime-local" value={sesForm.start_datetime} onChange={e => setSesForm(f => ({ ...f, start_datetime: e.target.value }))} /></div>
              <div><Label>End Date & Time *</Label><Input type="datetime-local" value={sesForm.end_datetime} onChange={e => setSesForm(f => ({ ...f, end_datetime: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Location</Label><Input value={sesForm.location} onChange={e => setSesForm(f => ({ ...f, location: e.target.value }))} placeholder="Room / Building / Campus" /></div>
              <div><Label>Max Participants</Label><Input type="number" min="1" value={sesForm.max_participants} onChange={e => setSesForm(f => ({ ...f, max_participants: e.target.value }))} /></div>
            </div>
            <div><Label>Online Meeting URL</Label><Input value={sesForm.online_meeting_url} onChange={e => setSesForm(f => ({ ...f, online_meeting_url: e.target.value }))} placeholder="https://zoom.us/j/..." /></div>
            <div><Label>Notes</Label><Textarea value={sesForm.notes} onChange={e => setSesForm(f => ({ ...f, notes: e.target.value }))} rows={2} /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setAddSesOpen(null)}>Cancel</Button>
              <Button onClick={addSession} disabled={sesSaving}>{sesSaving ? 'Scheduling…' : 'Schedule Session'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
