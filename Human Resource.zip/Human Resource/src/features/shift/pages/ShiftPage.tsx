import { useState, useEffect, useCallback } from 'react';
import { shiftService } from '@/services/modules.service';
import { supabase } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Plus, RefreshCw, Layers, ArrowLeftRight, Clock, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';

interface ShiftRow { id: string; code: string; name: string; start_time: string; end_time: string; break_minutes: number; is_night_shift: boolean; is_active: boolean; }
interface Employee { id: string; full_name: string; employee_no: string; }
interface SwapRequest {
  id: string;
  swap_date: string;
  reason: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  created_at: string;
  requester_name: string;
  target_name: string;
  shift_name: string;
}

const SWAP_EMPTY = { shift_id: '', requester_id: '', target_id: '', swap_date: '', reason: '' };

const STATUS_CONFIG: Record<string, { label: string; class: string; icon: React.ReactNode }> = {
  PENDING:  { label: 'Pending',  class: 'bg-amber-100 text-amber-800',  icon: <AlertCircle className="h-3 w-3" /> },
  APPROVED: { label: 'Approved', class: 'bg-green-100 text-green-800',  icon: <CheckCircle2 className="h-3 w-3" /> },
  REJECTED: { label: 'Rejected', class: 'bg-red-100 text-red-800',      icon: <XCircle className="h-3 w-3" /> },
};

export function ShiftPage() {
  const [shifts,    setShifts]    = useState<ShiftRow[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [swaps,     setSwaps]     = useState<SwapRequest[]>([]);
  const [loading,   setLoading]   = useState(true);
  const [swapLoading, setSwapLoading] = useState(false);

  // Create shift dialog
  const [dialog, setDialog] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ code: '', name: '', start_time: '09:00', end_time: '18:00', break_minutes: '60', is_night_shift: false, is_active: true });

  // Swap request dialog
  const [swapDialog, setSwapDialog] = useState(false);
  const [swapSaving, setSwapSaving] = useState(false);
  const [swapForm, setSwapForm] = useState({ ...SWAP_EMPTY });
  const [swapErrors, setSwapErrors] = useState<Partial<typeof SWAP_EMPTY>>({});

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await shiftService.list();
      setShifts(res as ShiftRow[]);
    } catch { toast.error('Failed to load shifts'); }
    finally { setLoading(false); }
  }, []);

  const loadEmployees = useCallback(async () => {
    const { data } = await supabase.from('employees').select('id, full_name, employee_no').eq('status', 'ACTIVE').order('full_name');
    setEmployees((data ?? []) as Employee[]);
  }, []);

  const loadSwaps = useCallback(async () => {
    setSwapLoading(true);
    try {
      const { data } = await supabase
        .from('shift_swap_requests')
        .select('id, swap_date, reason, status, created_at, shifts(name), requester:employees!requester_id(full_name), target:employees!target_id(full_name)')
        .order('created_at', { ascending: false })
        .limit(50);
      setSwaps((data ?? []).map((r: Record<string, unknown>) => ({
        id: String(r.id),
        swap_date: String(r.swap_date ?? ''),
        reason: String(r.reason ?? ''),
        status: (r.status as SwapRequest['status']) ?? 'PENDING',
        created_at: String(r.created_at ?? ''),
        requester_name: (r.requester as Record<string,unknown>)?.full_name as string ?? '—',
        target_name: (r.target as Record<string,unknown>)?.full_name as string ?? '—',
        shift_name: (r.shifts as Record<string,unknown>)?.name as string ?? '—',
      })));
    } catch { toast.error('Failed to load swap requests'); }
    finally { setSwapLoading(false); }
  }, []);

  useEffect(() => { load(); loadEmployees(); loadSwaps(); }, [load, loadEmployees, loadSwaps]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await shiftService.create({ ...form, break_minutes: Number(form.break_minutes) });
      toast.success('Shift created');
      setDialog(false);
      setForm({ code: '', name: '', start_time: '09:00', end_time: '18:00', break_minutes: '60', is_night_shift: false, is_active: true });
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };

  const validateSwap = () => {
    const errs: Partial<typeof SWAP_EMPTY> = {};
    if (!swapForm.shift_id)     errs.shift_id     = 'Required';
    if (!swapForm.requester_id) errs.requester_id = 'Required';
    if (!swapForm.target_id)    errs.target_id    = 'Required';
    if (swapForm.requester_id === swapForm.target_id) errs.target_id = 'Must differ from requester';
    if (!swapForm.swap_date)    errs.swap_date    = 'Required';
    setSwapErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSwapSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateSwap()) return;
    setSwapSaving(true);
    try {
      const { error } = await supabase.from('shift_swap_requests').insert({
        shift_id:     swapForm.shift_id,
        requester_id: swapForm.requester_id,
        target_id:    swapForm.target_id,
        swap_date:    swapForm.swap_date,
        reason:       swapForm.reason || null,
        status:       'PENDING',
      });
      if (error) throw error;
      toast.success('Swap request submitted successfully');

      // Notify HR via email (fire-and-forget; don't block UX on failure)
      const requesterEmp = employees.find(emp => emp.id === swapForm.requester_id);
      const targetEmp    = employees.find(emp => emp.id === swapForm.target_id);
      const shiftItem    = shifts.find(s => s.id === swapForm.shift_id);
      supabase.functions.invoke('send-notification-email', {
        body: {
          notification_type: 'SHIFT_SWAP_SUBMITTED',
          recipient_email:   'hr@bkggroup.hr',
          employee_name:     requesterEmp?.full_name ?? 'Employee',
          data: {
            requester_name: requesterEmp?.full_name ?? '—',
            target_name:    targetEmp?.full_name    ?? '—',
            shift_name:     shiftItem?.name         ?? '—',
            swap_date:      swapForm.swap_date,
            reason:         swapForm.reason || '',
          },
        },
      }).catch(() => { /* silent — email is non-critical */ });

      setSwapDialog(false);
      setSwapForm({ ...SWAP_EMPTY });
      setSwapErrors({});
      loadSwaps();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to submit swap request'); }
    finally { setSwapSaving(false); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-balance">Shifts</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{shifts.length} shifts configured</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={() => { load(); loadSwaps(); }}>
            <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
          </Button>

          {/* Swap Request Dialog */}
          <Dialog open={swapDialog} onOpenChange={(o) => { setSwapDialog(o); if (!o) { setSwapForm({ ...SWAP_EMPTY }); setSwapErrors({}); } }}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <ArrowLeftRight className="h-4 w-4 mr-1.5" />Request Swap
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <ArrowLeftRight className="h-4 w-4 text-primary" />
                  Request Shift Swap
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSwapSubmit} className="space-y-4 mt-2">
                {/* Shift */}
                <div className="space-y-1.5">
                  <Label>Shift to Swap *</Label>
                  <Select value={swapForm.shift_id} onValueChange={v => setSwapForm(p => ({ ...p, shift_id: v }))}>
                    <SelectTrigger className={swapErrors.shift_id ? 'border-destructive' : ''}>
                      <SelectValue placeholder="Select shift…" />
                    </SelectTrigger>
                    <SelectContent>
                      {shifts.filter(s => s.is_active).map(s => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.name} ({s.start_time}–{s.end_time})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {swapErrors.shift_id && <p className="text-xs text-destructive">{swapErrors.shift_id}</p>}
                </div>

                {/* Requester + Target */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label>Requesting Employee *</Label>
                    <Select value={swapForm.requester_id} onValueChange={v => setSwapForm(p => ({ ...p, requester_id: v }))}>
                      <SelectTrigger className={swapErrors.requester_id ? 'border-destructive' : ''}>
                        <SelectValue placeholder="Select…" />
                      </SelectTrigger>
                      <SelectContent>
                        {employees.map(e => <SelectItem key={e.id} value={e.id}>{e.full_name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    {swapErrors.requester_id && <p className="text-xs text-destructive">{swapErrors.requester_id}</p>}
                  </div>
                  <div className="space-y-1.5">
                    <Label>Swap With *</Label>
                    <Select value={swapForm.target_id} onValueChange={v => setSwapForm(p => ({ ...p, target_id: v }))}>
                      <SelectTrigger className={swapErrors.target_id ? 'border-destructive' : ''}>
                        <SelectValue placeholder="Select…" />
                      </SelectTrigger>
                      <SelectContent>
                        {employees.filter(e => e.id !== swapForm.requester_id).map(e => (
                          <SelectItem key={e.id} value={e.id}>{e.full_name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {swapErrors.target_id && <p className="text-xs text-destructive">{swapErrors.target_id}</p>}
                  </div>
                </div>

                {/* Swap Date */}
                <div className="space-y-1.5">
                  <Label>Swap Date *</Label>
                  <Input
                    type="date"
                    value={swapForm.swap_date}
                    min={new Date().toISOString().slice(0, 10)}
                    onChange={e => setSwapForm(p => ({ ...p, swap_date: e.target.value }))}
                    className={swapErrors.swap_date ? 'border-destructive' : ''}
                  />
                  {swapErrors.swap_date && <p className="text-xs text-destructive">{swapErrors.swap_date}</p>}
                </div>

                {/* Reason */}
                <div className="space-y-1.5">
                  <Label>Reason <span className="text-muted-foreground text-xs">(optional)</span></Label>
                  <Textarea
                    placeholder="Briefly explain the reason for the swap request…"
                    value={swapForm.reason}
                    onChange={e => setSwapForm(p => ({ ...p, reason: e.target.value }))}
                    rows={3}
                    className="resize-none"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-1">
                  <Button type="button" variant="outline" onClick={() => setSwapDialog(false)}>Cancel</Button>
                  <Button type="submit" disabled={swapSaving}>
                    <ArrowLeftRight className="h-3.5 w-3.5 mr-1.5" />
                    {swapSaving ? 'Submitting…' : 'Submit Request'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>

          {/* Add Shift Dialog */}
          <Dialog open={dialog} onOpenChange={setDialog}>
            <DialogTrigger asChild><Button size="sm"><Plus className="h-4 w-4 mr-1.5" />Add Shift</Button></DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>Create Shift</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 mt-2">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5"><Label>Code *</Label><Input value={form.code} onChange={e => setForm(p => ({ ...p, code: e.target.value }))} required /></div>
                  <div className="space-y-1.5"><Label>Name *</Label><Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} required /></div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-1.5"><Label>Start Time</Label><Input type="time" value={form.start_time} onChange={e => setForm(p => ({ ...p, start_time: e.target.value }))} /></div>
                  <div className="space-y-1.5"><Label>End Time</Label><Input type="time" value={form.end_time} onChange={e => setForm(p => ({ ...p, end_time: e.target.value }))} /></div>
                  <div className="space-y-1.5"><Label>Break (min)</Label><Input type="number" value={form.break_minutes} onChange={e => setForm(p => ({ ...p, break_minutes: e.target.value }))} /></div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setDialog(false)}>Cancel</Button>
                  <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Create'}</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="shifts">
        <TabsList className="h-9">
          <TabsTrigger value="shifts" className="text-xs md:text-sm"><Clock className="h-3.5 w-3.5 mr-1.5" />Shift Definitions</TabsTrigger>
          <TabsTrigger value="swaps"  className="text-xs md:text-sm"><ArrowLeftRight className="h-3.5 w-3.5 mr-1.5" />My Swap Requests</TabsTrigger>
        </TabsList>

        {/* ── Shift Definitions Tab ─────────────────────────────────── */}
        <TabsContent value="shifts" className="mt-4">
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Code</TableHead>
                  <TableHead className="whitespace-nowrap">Name</TableHead>
                  <TableHead className="whitespace-nowrap">Start</TableHead>
                  <TableHead className="whitespace-nowrap">End</TableHead>
                  <TableHead className="whitespace-nowrap">Break (min)</TableHead>
                  <TableHead className="whitespace-nowrap">Night Shift</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {loading
                    ? Array.from({ length: 4 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 7 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                    : shifts.length === 0
                      ? <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground"><Layers className="h-8 w-8 mx-auto mb-2 opacity-40" />No shifts found</TableCell></TableRow>
                      : shifts.map((s) => (
                        <TableRow key={s.id}>
                          <TableCell className="whitespace-nowrap font-mono text-xs">{s.code}</TableCell>
                          <TableCell className="whitespace-nowrap font-medium text-sm">{s.name}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{s.start_time}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{s.end_time}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{s.break_minutes ?? '—'}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{s.is_night_shift ? 'Yes' : 'No'}</TableCell>
                          <TableCell className="whitespace-nowrap">
                            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${s.is_active ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}`}>
                              {s.is_active ? 'Active' : 'Inactive'}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── Swap Requests Tab ─────────────────────────────────────── */}
        <TabsContent value="swaps" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base">Shift Swap Requests</CardTitle>
                  <CardDescription>View and track all submitted shift swap requests</CardDescription>
                </div>
                <Button variant="outline" size="sm" onClick={loadSwaps} disabled={swapLoading}>
                  <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${swapLoading ? 'animate-spin' : ''}`} />Refresh
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader><TableRow>
                    <TableHead className="whitespace-nowrap">Date</TableHead>
                    <TableHead className="whitespace-nowrap">Shift</TableHead>
                    <TableHead className="whitespace-nowrap">Requester</TableHead>
                    <TableHead className="whitespace-nowrap">Swap With</TableHead>
                    <TableHead className="whitespace-nowrap">Reason</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Submitted</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {swapLoading
                      ? Array.from({ length: 3 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 7 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                      : swaps.length === 0
                        ? <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">
                            <ArrowLeftRight className="h-8 w-8 mx-auto mb-2 opacity-40" />
                            No swap requests yet. Click <strong>Request Swap</strong> to submit one.
                          </TableCell></TableRow>
                        : swaps.map((s) => {
                          const cfg = STATUS_CONFIG[s.status] ?? STATUS_CONFIG.PENDING;
                          return (
                            <TableRow key={s.id}>
                              <TableCell className="whitespace-nowrap text-sm">{s.swap_date}</TableCell>
                              <TableCell className="whitespace-nowrap text-sm font-medium">{s.shift_name}</TableCell>
                              <TableCell className="whitespace-nowrap text-sm">{s.requester_name}</TableCell>
                              <TableCell className="whitespace-nowrap text-sm">{s.target_name}</TableCell>
                              <TableCell className="text-sm max-w-[180px] truncate" title={s.reason}>{s.reason || '—'}</TableCell>
                              <TableCell className="whitespace-nowrap">
                                <Badge className={`${cfg.class} flex items-center gap-1 w-fit text-xs font-medium border-0`}>
                                  {cfg.icon}{cfg.label}
                                </Badge>
                              </TableCell>
                              <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                                {new Date(s.created_at).toLocaleDateString()}
                              </TableCell>
                            </TableRow>
                          );
                        })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
