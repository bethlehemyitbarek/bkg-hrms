import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import type { Shift, OvertimeRule, WorkCalendar, Department } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { Plus, RefreshCw, Pencil, Trash2, AlertTriangle, Clock, Layers, Timer, TrendingUp, Calendar, Users2, ArrowLeftRight, CheckCircle2, XCircle, Download } from 'lucide-react';
import { exportToCsv } from '@/utils/exportUtils';

// ── Schemas ────────────────────────────────────────────────────────
const shiftSchema = z.object({
  name: z.string().min(1, 'Required'),
  shift_code: z.string().min(1, 'Required'),
  shift_type: z.enum(['FIXED', 'FLEXIBLE', 'ROTATING']),
  start_time: z.string().min(1, 'Required'),
  end_time: z.string().min(1, 'Required'),
  break_duration_minutes: z.coerce.number().min(0).max(240),
  grace_period_minutes: z.coerce.number().min(0).max(60),
  department_id: z.string().optional(),
});
type ShiftForm = z.infer<typeof shiftSchema>;

const overtimeSchema = z.object({
  overtime_type: z.enum(['WEEKDAY', 'WEEKEND', 'HOLIDAY', 'NIGHT']),
  threshold_hours: z.coerce.number().min(0).max(24),
  multiplier_rate: z.coerce.number().min(1).max(10),
  work_calendar_id: z.string().optional(),
});
type OvertimeForm = z.infer<typeof overtimeSchema>;

// ── Helpers ────────────────────────────────────────────────────────
const SHIFT_TYPE_COLOR: Record<string, string> = {
  FIXED:    'bg-blue-100 text-blue-800',
  FLEXIBLE: 'bg-purple-100 text-purple-800',
  ROTATING: 'bg-orange-100 text-orange-800',
};
const OT_TYPE_COLOR: Record<string, string> = {
  WEEKDAY: 'bg-blue-100 text-blue-800',
  WEEKEND: 'bg-green-100 text-green-800',
  HOLIDAY: 'bg-red-100 text-red-800',
  NIGHT:   'bg-slate-100 text-slate-800',
};

function calcHours(start: string, end: string, breakMin: number) {
  if (!start || !end) return null;
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  let mins = (eh * 60 + em) - (sh * 60 + sm);
  if (mins < 0) mins += 24 * 60;
  mins -= breakMin;
  return (mins / 60).toFixed(1);
}

export function ShiftManagementPage() {
  const [tab, setTab] = useState<'shifts' | 'overtime' | 'roster' | 'swaps'>('shifts');

  // Roster
  const [rosterRows, setRosterRows]   = useState<{id:string;employee_name:string;dept:string;shift_name:string;week_start:string;notes:string}[]>([]);
  const [rosterLoading, setRosterLoading] = useState(true);
  const [rosterMonth, setRosterMonth] = useState(() => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`; });

  const [rosterDept, setRosterDept] = useState<string>('all');

  // Roster CRUD
  const [rosterDialog, setRosterDialog]   = useState(false);
  const [rosterEditing, setRosterEditing] = useState<string | null>(null);
  const [rosterForm,    setRosterForm]    = useState({ employee_id: '', shift_id: '', week_start: '', notes: '' });
  const [rosterSaving,  setRosterSaving]  = useState(false);
  const [rosterFormErr, setRosterFormErr] = useState<Record<string,string>>({});
  const [empList,       setEmpList]       = useState<{id:string;full_name:string;employee_no:string}[]>([]);

  // Swap Requests
  const [swaps, setSwaps]         = useState<{id:string;requester:string;target:string;shift_name:string;swap_date:string;reason:string;status:string;created_at:string}[]>([]);
  const [swapsLoading, setSwapsLoading] = useState(true);

  // Shifts
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [shiftLoading, setShiftLoading] = useState(true);
  const [shiftDialog, setShiftDialog] = useState(false);
  const [editShift, setEditShift] = useState<Shift | null>(null);
  const [shiftSaving, setShiftSaving] = useState(false);
  const [departments, setDepartments] = useState<Pick<Department, 'id' | 'name'>[]>([]);

  // Overtime
  const [overtimeRules, setOvertimeRules] = useState<OvertimeRule[]>([]);
  const [otLoading, setOtLoading] = useState(true);
  const [otDialog, setOtDialog] = useState(false);
  const [editOt, setEditOt] = useState<OvertimeRule | null>(null);
  const [otSaving, setOtSaving] = useState(false);
  const [calendars, setCalendars] = useState<Pick<WorkCalendar, 'id' | 'calendar_name'>[]>([]);

  // Forms
  const shiftForm = useForm<ShiftForm>({
    resolver: zodResolver(shiftSchema),
    defaultValues: { name: '', shift_code: '', shift_type: 'FIXED', start_time: '09:00', end_time: '18:00', break_duration_minutes: 60, grace_period_minutes: 5 },
  });
  const otForm = useForm<OvertimeForm>({
    resolver: zodResolver(overtimeSchema),
    defaultValues: { overtime_type: 'WEEKDAY', threshold_hours: 8, multiplier_rate: 1.25 },
  });

  // Load
  const loadShifts = useCallback(async () => {
    setShiftLoading(true);
    const { data, error } = await supabase.from('shifts').select('*, department:departments(id,name)').eq('is_active', true).order('created_at');
    if (error) toast.error('Failed to load shifts');
    else setShifts((data ?? []) as Shift[]);
    setShiftLoading(false);
  }, []);

  const loadOvertimeRules = useCallback(async () => {
    setOtLoading(true);
    const { data, error } = await supabase.from('overtime_rules').select('*, work_calendar:work_calendars(id,calendar_name)').eq('is_deleted', 0).order('overtime_type');
    if (error) toast.error('Failed to load overtime rules');
    else setOvertimeRules((data ?? []) as OvertimeRule[]);
    setOtLoading(false);
  }, []);

  const loadDepts = useCallback(async () => {
    const { data } = await supabase.from('departments').select('id,name').eq('is_active', true).order('name');
    setDepartments((data ?? []) as Pick<Department, 'id' | 'name'>[]);
  }, []);

  const loadCalendars = useCallback(async () => {
    const { data } = await supabase.from('work_calendars').select('id,calendar_name').eq('is_deleted', 0).order('calendar_name');
    setCalendars((data ?? []) as Pick<WorkCalendar, 'id' | 'calendar_name'>[]);
  }, []);

  useEffect(() => { loadShifts(); loadDepts(); }, [loadShifts, loadDepts]);
  useEffect(() => { loadOvertimeRules(); loadCalendars(); }, [loadOvertimeRules, loadCalendars]);


  // Shift CRUD
  const openCreateShift = () => {
    setEditShift(null);
    shiftForm.reset({ name: '', shift_code: '', shift_type: 'FIXED', start_time: '09:00', end_time: '18:00', break_duration_minutes: 60, grace_period_minutes: 5 });
    setShiftDialog(true);
  };
  const openEditShift = (s: Shift) => {
    setEditShift(s);
    shiftForm.reset({
      name: s.name,
      shift_code: s.shift_code ?? s.code ?? '',
      shift_type: (s.shift_type as 'FIXED' | 'FLEXIBLE' | 'ROTATING') in SHIFT_TYPE_COLOR ? s.shift_type as 'FIXED' | 'FLEXIBLE' | 'ROTATING' : 'FIXED',
      start_time: s.start_time,
      end_time: s.end_time,
      break_duration_minutes: s.break_duration_minutes ?? s.break_minutes ?? 60,
      grace_period_minutes: s.grace_period_minutes ?? 5,
      department_id: s.department_id ?? '',
    });
    setShiftDialog(true);
  };
  const submitShift = shiftForm.handleSubmit(async (vals) => {
    setShiftSaving(true);
    const payload = {
      name: vals.name,
      code: vals.shift_code,
      shift_code: vals.shift_code,
      shift_type: vals.shift_type,
      start_time: vals.start_time,
      end_time: vals.end_time,
      break_minutes: vals.break_duration_minutes,
      break_duration_minutes: vals.break_duration_minutes,
      grace_period_minutes: vals.grace_period_minutes,
      department_id: vals.department_id || null,
      is_active: true,
      updated_at: new Date().toISOString(),
    };
    const { error } = editShift
      ? await supabase.from('shifts').update(payload).eq('id', editShift.id)
      : await supabase.from('shifts').insert({ ...payload, effective_from: new Date().toISOString(), effective_to: '9999-12-31T23:59:59Z' });
    if (error) toast.error(error.message);
    else { toast.success(editShift ? 'Shift updated' : 'Shift created'); setShiftDialog(false); loadShifts(); }
    setShiftSaving(false);
  });
  const deleteShift = async (id: string) => {
    if (!confirm('Delete this shift?')) return;
    const { error } = await supabase.from('shifts').update({ is_active: false, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Shift deleted'); loadShifts(); }
  };

  // Overtime CRUD
  const openCreateOt = () => {
    setEditOt(null);
    otForm.reset({ overtime_type: 'WEEKDAY', threshold_hours: 8, multiplier_rate: 1.25 });
    setOtDialog(true);
  };
  const openEditOt = (r: OvertimeRule) => {
    setEditOt(r);
    otForm.reset({
      overtime_type: r.overtime_type,
      threshold_hours: r.threshold_hours,
      multiplier_rate: r.multiplier_rate,
      work_calendar_id: r.work_calendar_id ?? '',
    });
    setOtDialog(true);
  };
  const submitOt = otForm.handleSubmit(async (vals) => {
    setOtSaving(true);
    const payload = {
      overtime_type: vals.overtime_type,
      threshold_hours: vals.threshold_hours,
      multiplier_rate: vals.multiplier_rate,
      work_calendar_id: vals.work_calendar_id || null,
      updated_at: new Date().toISOString(),
    };
    const { error } = editOt
      ? await supabase.from('overtime_rules').update(payload).eq('id', editOt.id)
      : await supabase.from('overtime_rules').insert({ ...payload, effective_from: new Date().toISOString(), effective_to: '9999-12-31T23:59:59Z' });
    if (error) toast.error(error.message);
    else { toast.success(editOt ? 'Rule updated' : 'Rule created'); setOtDialog(false); loadOvertimeRules(); }
    setOtSaving(false);
  });
  const deleteOt = async (id: string) => {
    if (!confirm('Delete this overtime rule?')) return;
    const { error } = await supabase.from('overtime_rules').update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Rule deleted'); loadOvertimeRules(); }
  };


  const loadRoster = useCallback(async (month: string, deptId?: string) => {
    setRosterLoading(true);
    try {
      const [y, m] = month.split('-').map(Number);
      const start = `${y}-${String(m).padStart(2,'0')}-01`;
      const end   = new Date(y, m, 0).toISOString().split('T')[0];
      let query = supabase.from('shift_roster')
        .select('id, week_start, notes, employees!inner(full_name, department_id, departments(id, name)), shifts(name)')
        .gte('week_start', start).lte('week_start', end)
        .order('week_start', { ascending: true }).limit(200);
      if (deptId && deptId !== 'all') {
        query = query.eq('employees.department_id', deptId);
      }
      const { data } = await query;
      setRosterRows((data ?? []).map((r: Record<string,unknown>) => ({
        id: r.id as string,
        employee_name: (r.employees as Record<string,unknown>)?.full_name as string ?? '—',
        dept: ((r.employees as Record<string,unknown>)?.departments as Record<string,unknown>)?.name as string ?? '—',
        shift_name: (r.shifts as Record<string,unknown>)?.name as string ?? '—',
        week_start: r.week_start as string,
        notes: r.notes as string ?? '',
      })));
    } catch { /* silent */ } finally { setRosterLoading(false); }
  }, []);

  const loadEmpList = useCallback(async () => {
    const { data } = await supabase.from('employees').select('id, full_name, employee_no').eq('status', 'ACTIVE').order('full_name');
    setEmpList((data ?? []) as {id:string;full_name:string;employee_no:string}[]);
  }, []);

  const openRosterCreate = () => {
    setRosterEditing(null);
    const nextMon = new Date();
    nextMon.setDate(nextMon.getDate() + ((8 - nextMon.getDay()) % 7 || 7));
    setRosterForm({ employee_id: '', shift_id: '', week_start: nextMon.toISOString().slice(0,10), notes: '' });
    setRosterFormErr({});
    setRosterDialog(true);
  };

  const openRosterEdit = (row: {id:string;employee_name:string;dept:string;shift_name:string;week_start:string;notes:string}) => {
    setRosterEditing(row.id);
    // We only have names not IDs in rosterRows; refetch the raw row for IDs
    supabase.from('shift_roster').select('employee_id, shift_id, week_start, notes').eq('id', row.id).maybeSingle().then(({ data }) => {
      if (data) setRosterForm({ employee_id: String(data.employee_id ?? ''), shift_id: String(data.shift_id ?? ''), week_start: String(data.week_start ?? ''), notes: String(data.notes ?? '') });
    });
    setRosterFormErr({});
    setRosterDialog(true);
  };

  const validateRosterForm = () => {
    const e: Record<string,string> = {};
    if (!rosterForm.employee_id) e.employee_id = 'Required';
    if (!rosterForm.shift_id)    e.shift_id    = 'Required';
    if (!rosterForm.week_start)  e.week_start  = 'Required';
    setRosterFormErr(e);
    return Object.keys(e).length === 0;
  };

  const saveRoster = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validateRosterForm()) return;
    setRosterSaving(true);
    try {
      const payload = { employee_id: rosterForm.employee_id, shift_id: rosterForm.shift_id, week_start: rosterForm.week_start, notes: rosterForm.notes || null };
      const { error } = rosterEditing
        ? await supabase.from('shift_roster').update(payload).eq('id', rosterEditing)
        : await supabase.from('shift_roster').insert(payload);
      if (error) throw error;
      toast.success(rosterEditing ? 'Assignment updated' : 'Assignment created');
      setRosterDialog(false);
      loadRoster(rosterMonth, rosterDept);
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to save'); }
    finally { setRosterSaving(false); }
  };

  const deleteRoster = async (id: string) => {
    if (!window.confirm('Delete this roster assignment?')) return;
    const { error } = await supabase.from('shift_roster').delete().eq('id', id);
    if (error) toast.error('Delete failed');
    else { toast.success('Assignment deleted'); loadRoster(rosterMonth, rosterDept); }
  };

  const loadSwaps = useCallback(async () => {
    setSwapsLoading(true);
    try {
      const { data } = await supabase.from('shift_swap_requests')
        .select('id, swap_date, reason, status, created_at, shifts(name), requester:employees!requester_id(full_name), target:employees!target_id(full_name)')
        .order('created_at', { ascending: false }).limit(100);
      setSwaps((data ?? []).map((r: Record<string,unknown>) => ({
        id: r.id as string,
        requester: (r.requester as Record<string,unknown>)?.full_name as string ?? '—',
        target:    (r.target    as Record<string,unknown>)?.full_name as string ?? '—',
        shift_name: (r.shifts   as Record<string,unknown>)?.name      as string ?? '—',
        swap_date:  r.swap_date  as string,
        reason:     r.reason     as string ?? '',
        status:     r.status     as string ?? 'pending',
        created_at: r.created_at as string,
      })));
    } catch { /* silent */ } finally { setSwapsLoading(false); }
  }, []);

  const updateSwap = async (id: string, status: 'approved' | 'rejected') => {
    const { error } = await supabase.from('shift_swap_requests').update({ status }).eq('id', id);
    if (error) { toast.error('Failed to update swap request'); return; }
    toast.success(`Swap request ${status}`);

    // Notify requester employee by email (fire-and-forget)
    const sw = swaps.find(s => s.id === id);
    if (sw) {
      const notifType = status === 'approved' ? 'SHIFT_SWAP_APPROVED' : 'SHIFT_SWAP_REJECTED';
      (async () => {
        try {
          const { data: emp } = await supabase.from('employees').select('id, email, work_email').eq('full_name', sw.requester).maybeSingle();
          const recipientEmail = (emp as Record<string, unknown>)?.work_email as string
            || (emp as Record<string, unknown>)?.email as string
            || `${sw.requester.toLowerCase().replace(/\s+/g, '.')}@bkggroup.hr`;
          await supabase.functions.invoke('send-notification-email', {
            body: {
              notification_type: notifType,
              recipient_email:   recipientEmail,
              employee_name:     sw.requester,
              data: {
                target_name: sw.target,
                shift_name:  sw.shift_name,
                swap_date:   sw.swap_date,
                reason:      sw.reason || '',
              },
            },
          });
        } catch { /* silent — email is non-critical */ }
      })();
    }

    loadSwaps();
  };

  useEffect(() => { loadRoster(rosterMonth, rosterDept); }, [loadRoster, rosterMonth, rosterDept]);
  useEffect(() => { loadSwaps(); }, [loadSwaps]);
  useEffect(() => { loadEmpList(); }, [loadEmpList]);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Shifts & Overtime Rules</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Configure work shifts, types, and overtime multiplier rates</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => { loadShifts(); loadOvertimeRules(); }}>
            <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
          </Button>
          {tab === 'shifts'
            ? <Button size="sm" onClick={openCreateShift}><Plus className="h-4 w-4 mr-1.5" />New Shift</Button>
            : <Button size="sm" onClick={openCreateOt}><Plus className="h-4 w-4 mr-1.5" />Add Rule</Button>}
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Shifts', value: shifts.length, icon: Layers, color: 'text-primary' },
          { label: 'Fixed Shifts', value: shifts.filter(s => s.shift_type === 'FIXED' || s.shift_type === 'regular').length, icon: Clock, color: 'text-blue-500' },
          { label: 'Flexible/Rotating', value: shifts.filter(s => ['FLEXIBLE','ROTATING','flexible','rotating'].includes(s.shift_type ?? '')).length, icon: Timer, color: 'text-purple-500' },
          { label: 'OT Rules', value: overtimeRules.length, icon: TrendingUp, color: 'text-orange-500' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <s.icon className={`h-4 w-4 ${s.color} shrink-0`} />
            <div><p className="text-xs text-muted-foreground">{s.label}</p><p className="text-xl font-bold">{s.value}</p></div>
          </div>
        ))}
      </div>

      <Tabs value={tab} onValueChange={v => setTab(v as typeof tab)}>
        <TabsList>
          <TabsTrigger value="shifts"><Layers className="h-4 w-4 mr-1.5" />Shifts ({shifts.length})</TabsTrigger>
          <TabsTrigger value="overtime"><TrendingUp className="h-4 w-4 mr-1.5" />Overtime Rules ({overtimeRules.length})</TabsTrigger>
          <TabsTrigger value="roster"><Calendar className="h-4 w-4 mr-1.5" />Roster</TabsTrigger>
          <TabsTrigger value="swaps"><ArrowLeftRight className="h-4 w-4 mr-1.5" />Swap Requests</TabsTrigger>
        </TabsList>

        {/* ── SHIFTS ── */}
        <TabsContent value="shifts" className="mt-4">
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Shift Name</TableHead>
                    <TableHead className="whitespace-nowrap">Code</TableHead>
                    <TableHead className="whitespace-nowrap">Type</TableHead>
                    <TableHead className="whitespace-nowrap">Start</TableHead>
                    <TableHead className="whitespace-nowrap">End</TableHead>
                    <TableHead className="whitespace-nowrap">Net Hours</TableHead>
                    <TableHead className="whitespace-nowrap">Break (min)</TableHead>
                    <TableHead className="whitespace-nowrap">Grace (min)</TableHead>
                    <TableHead className="whitespace-nowrap">Department</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {shiftLoading ? Array.from({ length: 4 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 10 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-16 bg-muted" /></TableCell>)}</TableRow>
                  )) : shifts.length === 0 ? (
                    <TableRow><TableCell colSpan={10} className="text-center py-10 text-muted-foreground">
                      <Layers className="h-8 w-8 mx-auto mb-2 opacity-40" />No shifts configured yet
                    </TableCell></TableRow>
                  ) : shifts.map(s => {
                    const netHours = calcHours(s.start_time, s.end_time, s.break_duration_minutes ?? s.break_minutes ?? 0);
                    const typeKey = (s.shift_type ?? '').toUpperCase() as string;
                    return (
                      <TableRow key={s.id}>
                        <TableCell className="whitespace-nowrap font-medium text-sm">{s.name}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm font-mono text-muted-foreground">{s.shift_code ?? s.code}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${SHIFT_TYPE_COLOR[typeKey] ?? 'bg-muted text-muted-foreground'}`}>
                            {typeKey || s.shift_type}
                          </span>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{s.start_time}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{s.end_time}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm font-medium">
                          {netHours ? `${netHours}h` : '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{s.break_duration_minutes ?? s.break_minutes ?? 0}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{s.grace_period_minutes ?? 0}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                          {(s as { department?: { name: string } }).department?.name ?? '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex gap-1.5">
                            <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openEditShift(s)}><Pencil className="h-3.5 w-3.5" /></Button>
                            <Button size="sm" variant="outline" className="h-7 px-2 text-destructive hover:bg-destructive/10" onClick={() => deleteShift(s.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── OVERTIME ── */}
        <TabsContent value="overtime" className="mt-4">
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Overtime Type</TableHead>
                    <TableHead className="whitespace-nowrap">Threshold (hrs)</TableHead>
                    <TableHead className="whitespace-nowrap">Multiplier</TableHead>
                    <TableHead className="whitespace-nowrap">Effective Pay Rate</TableHead>
                    <TableHead className="whitespace-nowrap">Calendar</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {otLoading ? Array.from({ length: 4 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-16 bg-muted" /></TableCell>)}</TableRow>
                  )) : overtimeRules.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">
                      <TrendingUp className="h-8 w-8 mx-auto mb-2 opacity-40" />No overtime rules configured
                    </TableCell></TableRow>
                  ) : overtimeRules.map(r => (
                    <TableRow key={r.id}>
                      <TableCell className="whitespace-nowrap">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${OT_TYPE_COLOR[r.overtime_type] ?? 'bg-muted text-muted-foreground'}`}>
                          {r.overtime_type}
                        </span>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.threshold_hours}h</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-semibold">×{r.multiplier_rate}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">
                        <Badge variant="outline" className="font-mono">{(r.multiplier_rate * 100).toFixed(0)}%</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                        {(r as { work_calendar?: { calendar_name: string } }).work_calendar?.calendar_name ?? '— All —'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex gap-1.5">
                          <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openEditOt(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                          <Button size="sm" variant="outline" className="h-7 px-2 text-destructive hover:bg-destructive/10" onClick={() => deleteOt(r.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── ROSTER ASSIGNMENT ── */}
        <TabsContent value="roster" className="mt-4 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h2 className="font-semibold flex items-center gap-2"><Calendar className="h-4 w-4" />Roster Assignment</h2>
              <p className="text-xs text-muted-foreground">View and manage employee shift assignments by month</p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <input type="month" value={rosterMonth} onChange={e => { setRosterMonth(e.target.value); loadRoster(e.target.value, rosterDept); }} className="text-sm border rounded px-2 py-1 bg-background" />
              <Select value={rosterDept} onValueChange={v => setRosterDept(v)}>
                <SelectTrigger className="h-8 w-44 text-xs">
                  <SelectValue placeholder="All Departments" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  {departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm" onClick={() => loadRoster(rosterMonth, rosterDept)}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
              <Button variant="outline" size="sm" onClick={() => exportToCsv(rosterRows as unknown as Record<string,unknown>[], 'Roster_Assignment')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
              <Button size="sm" onClick={openRosterCreate}><Plus className="h-3.5 w-3.5 mr-1.5" />Add Assignment</Button>
            </div>

            {/* Roster Create/Edit Dialog */}
            <Dialog open={rosterDialog} onOpenChange={(o) => { setRosterDialog(o); if(!o){ setRosterEditing(null); setRosterFormErr({}); } }}>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-primary" />
                    {rosterEditing ? 'Edit Roster Assignment' : 'New Roster Assignment'}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={saveRoster} className="space-y-4 mt-2">
                  <div className="space-y-1.5">
                    <Label>Employee *</Label>
                    <Select value={rosterForm.employee_id} onValueChange={v => setRosterForm(p => ({ ...p, employee_id: v }))}>
                      <SelectTrigger className={rosterFormErr.employee_id ? 'border-destructive' : ''}>
                        <SelectValue placeholder="Select employee…" />
                      </SelectTrigger>
                      <SelectContent>
                        {empList.map(e => <SelectItem key={e.id} value={e.id}>{e.full_name} ({e.employee_no})</SelectItem>)}
                        {empList.length === 0 && <SelectItem value="_none" disabled>No active employees</SelectItem>}
                      </SelectContent>
                    </Select>
                    {rosterFormErr.employee_id && <p className="text-xs text-destructive">{rosterFormErr.employee_id}</p>}
                  </div>

                  <div className="space-y-1.5">
                    <Label>Shift *</Label>
                    <Select value={rosterForm.shift_id} onValueChange={v => setRosterForm(p => ({ ...p, shift_id: v }))}>
                      <SelectTrigger className={rosterFormErr.shift_id ? 'border-destructive' : ''}>
                        <SelectValue placeholder="Select shift…" />
                      </SelectTrigger>
                      <SelectContent>
                        {shifts.filter(s => s.is_active).map(s => (
                          <SelectItem key={s.id} value={s.id}>
                            {s.name} — {s.shift_type} ({s.start_time}–{s.end_time})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {rosterFormErr.shift_id && <p className="text-xs text-destructive">{rosterFormErr.shift_id}</p>}
                  </div>

                  <div className="space-y-1.5">
                    <Label>Week Starting (Monday) *</Label>
                    <Input
                      type="date"
                      value={rosterForm.week_start}
                      onChange={e => setRosterForm(p => ({ ...p, week_start: e.target.value }))}
                      className={rosterFormErr.week_start ? 'border-destructive' : ''}
                    />
                    {rosterFormErr.week_start && <p className="text-xs text-destructive">{rosterFormErr.week_start}</p>}
                  </div>

                  <div className="space-y-1.5">
                    <Label>Notes <span className="text-muted-foreground text-xs">(optional)</span></Label>
                    <Textarea
                      placeholder="Any notes for this roster assignment…"
                      value={rosterForm.notes}
                      onChange={e => setRosterForm(p => ({ ...p, notes: e.target.value }))}
                      rows={2}
                      className="resize-none"
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-1">
                    <Button type="button" variant="outline" onClick={() => setRosterDialog(false)}>Cancel</Button>
                    <Button type="submit" disabled={rosterSaving}>
                      {rosterEditing ? <Pencil className="h-3.5 w-3.5 mr-1.5" /> : <Plus className="h-3.5 w-3.5 mr-1.5" />}
                      {rosterSaving ? 'Saving…' : rosterEditing ? 'Update Assignment' : 'Create Assignment'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Department</TableHead>
                    <TableHead className="whitespace-nowrap">Shift</TableHead>
                    <TableHead className="whitespace-nowrap">Week Starting</TableHead>
                    <TableHead className="whitespace-nowrap">Notes</TableHead>
                    <TableHead className="whitespace-nowrap w-20 text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rosterLoading ? Array.from({length:6}).map((_,i) => (
                    <TableRow key={i}><TableCell colSpan={5}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>
                  )) : rosterRows.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      <Users2 className="h-8 w-8 mx-auto mb-2 opacity-30" />
                      No roster assignments found for this month
                    </TableCell></TableRow>
                  ) : rosterRows.map(row => (
                    <TableRow key={row.id}>
                      <TableCell className="whitespace-nowrap font-medium">{row.employee_name}</TableCell>
                      <TableCell className="whitespace-nowrap">{row.dept}</TableCell>
                      <TableCell className="whitespace-nowrap"><Badge variant="secondary">{row.shift_name}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap">{row.week_start}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground text-sm">{row.notes || '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openRosterEdit(row)} title="Edit">
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => deleteRoster(row.id)} title="Delete">
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── SHIFT SWAP REQUESTS ── */}
        <TabsContent value="swaps" className="mt-4 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h2 className="font-semibold flex items-center gap-2"><ArrowLeftRight className="h-4 w-4" />Shift Swap Requests</h2>
              <p className="text-xs text-muted-foreground">Review and approve employee shift swap requests</p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={loadSwaps}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
              <Button variant="outline" size="sm" onClick={() => exportToCsv(swaps as unknown as Record<string,unknown>[], 'Shift_Swap_Requests')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
            </div>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Requester</TableHead>
                    <TableHead className="whitespace-nowrap">Target Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Shift</TableHead>
                    <TableHead className="whitespace-nowrap">Swap Date</TableHead>
                    <TableHead className="whitespace-nowrap">Reason</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {swapsLoading ? Array.from({length:5}).map((_,i) => (
                    <TableRow key={i}><TableCell colSpan={7}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>
                  )) : swaps.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                      <ArrowLeftRight className="h-8 w-8 mx-auto mb-2 opacity-30" />
                      No swap requests found
                    </TableCell></TableRow>
                  ) : swaps.map(sw => (
                    <TableRow key={sw.id}>
                      <TableCell className="whitespace-nowrap font-medium">{sw.requester}</TableCell>
                      <TableCell className="whitespace-nowrap">{sw.target}</TableCell>
                      <TableCell className="whitespace-nowrap"><Badge variant="outline">{sw.shift_name}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap">{sw.swap_date}</TableCell>
                      <TableCell className="max-w-[180px] truncate text-sm">{sw.reason || '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge variant={sw.status === 'approved' ? 'default' : sw.status === 'rejected' ? 'destructive' : 'secondary'}>
                          {sw.status === 'approved' && <CheckCircle2 className="h-3 w-3 mr-1" />}
                          {sw.status === 'rejected' && <XCircle className="h-3 w-3 mr-1" />}
                          {sw.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        {sw.status === 'pending' && (
                          <div className="flex gap-1">
                            <Button size="sm" variant="outline" className="h-7 text-xs text-green-600 border-green-300 hover:bg-green-50" onClick={() => updateSwap(sw.id, 'approved')}>
                              <CheckCircle2 className="h-3 w-3 mr-1" />Approve
                            </Button>
                            <Button size="sm" variant="outline" className="h-7 text-xs text-red-600 border-red-300 hover:bg-red-50" onClick={() => updateSwap(sw.id, 'rejected')}>
                              <XCircle className="h-3 w-3 mr-1" />Reject
                            </Button>
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

      </Tabs>

      {/* ── Shift Dialog ── */}
      <Dialog open={shiftDialog} onOpenChange={o => { if (!o) setShiftDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editShift ? 'Edit' : 'New'} Shift</DialogTitle></DialogHeader>
          <Form {...shiftForm}>
            <form onSubmit={submitShift} className="space-y-4 mt-1">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={shiftForm.control} name="name" render={({ field }) => (
                  <FormItem><FormLabel>Shift Name *</FormLabel><FormControl><Input {...field} placeholder="Morning Shift" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={shiftForm.control} name="shift_code" render={({ field }) => (
                  <FormItem><FormLabel>Code *</FormLabel><FormControl><Input {...field} placeholder="MRN" className="font-mono" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={shiftForm.control} name="shift_type" render={({ field }) => (
                <FormItem><FormLabel>Shift Type *</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="FIXED">Fixed</SelectItem>
                      <SelectItem value="FLEXIBLE">Flexible</SelectItem>
                      <SelectItem value="ROTATING">Rotating</SelectItem>
                    </SelectContent>
                  </Select>
                <FormMessage /></FormItem>
              )} />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={shiftForm.control} name="start_time" render={({ field }) => (
                  <FormItem><FormLabel>Start Time *</FormLabel><FormControl><Input type="time" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={shiftForm.control} name="end_time" render={({ field }) => (
                  <FormItem><FormLabel>End Time *</FormLabel><FormControl><Input type="time" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField control={shiftForm.control} name="break_duration_minutes" render={({ field }) => (
                  <FormItem><FormLabel>Break (min)</FormLabel><FormControl><Input type="number" min={0} max={240} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={shiftForm.control} name="grace_period_minutes" render={({ field }) => (
                  <FormItem><FormLabel>Grace Period (min)</FormLabel><FormControl><Input type="number" min={0} max={60} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={shiftForm.control} name="department_id" render={({ field }) => (
                <FormItem><FormLabel>Department (optional)</FormLabel>
                  <Select value={field.value ?? ''} onValueChange={v => field.onChange(v === 'none' ? '' : v)}>
                    <FormControl><SelectTrigger><SelectValue placeholder="— All Departments —" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="none">— All Departments —</SelectItem>
                      {departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                <FormMessage /></FormItem>
              )} />
              <Separator />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setShiftDialog(false)}>Cancel</Button>
                <Button type="submit" disabled={shiftSaving}>{shiftSaving ? 'Saving…' : (editShift ? 'Update' : 'Create')}</Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* ── Overtime Dialog ── */}
      <Dialog open={otDialog} onOpenChange={o => { if (!o) setOtDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editOt ? 'Edit' : 'Add'} Overtime Rule</DialogTitle></DialogHeader>
          <Form {...otForm}>
            <form onSubmit={submitOt} className="space-y-4 mt-1">
              <FormField control={otForm.control} name="overtime_type" render={({ field }) => (
                <FormItem><FormLabel>Overtime Type *</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="WEEKDAY">Weekday</SelectItem>
                      <SelectItem value="WEEKEND">Weekend</SelectItem>
                      <SelectItem value="HOLIDAY">Holiday</SelectItem>
                      <SelectItem value="NIGHT">Night</SelectItem>
                    </SelectContent>
                  </Select>
                <FormMessage /></FormItem>
              )} />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={otForm.control} name="threshold_hours" render={({ field }) => (
                  <FormItem><FormLabel>Threshold Hours *</FormLabel><FormControl><Input type="number" min={0} max={24} step={0.5} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={otForm.control} name="multiplier_rate" render={({ field }) => (
                  <FormItem><FormLabel>Multiplier Rate *</FormLabel><FormControl><Input type="number" min={1} max={10} step={0.25} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={otForm.control} name="work_calendar_id" render={({ field }) => (
                <FormItem><FormLabel>Calendar (optional)</FormLabel>
                  <Select value={field.value ?? ''} onValueChange={v => field.onChange(v === 'none' ? '' : v)}>
                    <FormControl><SelectTrigger><SelectValue placeholder="— All Calendars —" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="none">— All Calendars —</SelectItem>
                      {calendars.map(c => <SelectItem key={c.id} value={c.id}>{c.calendar_name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                <FormMessage /></FormItem>
              )} />
              <Separator />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setOtDialog(false)}>Cancel</Button>
                <Button type="submit" disabled={otSaving}>{otSaving ? 'Saving…' : (editOt ? 'Update' : 'Add Rule')}</Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
