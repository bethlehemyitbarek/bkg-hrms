import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Plus, RefreshCw, FileText, Search, CheckCircle2, XCircle, Send, Eye } from 'lucide-react';

const sb = _sb as any; // eslint-disable-line @typescript-eslint/no-explicit-any

type Offer = {
  id: string; offer_id: string; offer_number: string; offer_version: number;
  application_id: string;
  base_salary: number; total_compensation?: number; currency_code: string;
  pay_frequency?: string; grade_level?: string; contract_type: string;
  start_date?: string; expiry_date?: string; offer_status: string;
  response_type?: string; response_comments?: string; responded_at?: string;
  rejection_category?: string; rejection_reason?: string;
  signature_status?: string; signed_at?: string; created_at: string;
  application?: {
    application_number: string;
    candidate?: { first_name: string; last_name: string; email: string };
    vacancy?: { title: string };
  };
};
type Application = {
  application_id: string; application_number: string;
  candidate?: { first_name: string; last_name: string };
  vacancy?: { title: string };
};

const OFFER_STATUS_COLORS: Record<string, string> = {
  DRAFT: 'bg-muted text-muted-foreground',
  PENDING_APPROVAL: 'bg-yellow-100 text-yellow-800',
  APPROVED: 'bg-blue-100 text-blue-800',
  SENT: 'bg-indigo-100 text-indigo-800',
  VIEWED: 'bg-purple-100 text-purple-800',
  ACCEPTED: 'bg-green-100 text-green-800',
  DECLINED: 'bg-red-100 text-red-800',
  EXPIRED: 'bg-orange-100 text-orange-800',
  REVOKED: 'bg-muted text-muted-foreground',
};

const STATUS_FLOW: Record<string, string[]> = {
  DRAFT: ['PENDING_APPROVAL', 'REVOKED'],
  PENDING_APPROVAL: ['APPROVED', 'REVOKED'],
  APPROVED: ['SENT', 'REVOKED'],
  SENT: ['VIEWED', 'REVOKED'],
  VIEWED: ['ACCEPTED', 'DECLINED'],
};

const EMPTY_FORM = {
  application_id: '', base_salary: '', total_compensation: '', currency_code: 'ETB',
  pay_frequency: 'MONTHLY', grade_level: '', contract_type: 'PERMANENT',
  start_date: '', expiry_date: '',
};

export function OffersPage() {
  const [offers, setOffers] = useState<Offer[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [responseOpen, setResponseOpen] = useState<Offer | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [responseType, setResponseType] = useState('ACCEPTED');
  const [responseComments, setResponseComments] = useState('');
  const [rejCategory, setRejCategory] = useState('SALARY');
  const [statusFilter, setStatusFilter] = useState('all');

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [offRes, appRes] = await Promise.all([
        sb.from('offers')
          .select('*, application:applications(application_number, candidate:candidates(first_name,last_name,email), vacancy:job_vacancies(title))')
          .eq('is_deleted', false)
          .order('created_at', { ascending: false }),
        sb.from('applications')
          .select('application_id, application_number, candidate:candidates(first_name,last_name), vacancy:job_vacancies(title)')
          .eq('is_deleted', false)
          .eq('current_stage', 'OFFER')
          .order('created_at', { ascending: false })
          .limit(200),
      ]);
      setOffers(offRes.data ?? []);
      setApplications(appRes.data ?? []);
    } catch { toast.error('Failed to load offers'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const handleCreate = async () => {
    if (!form.application_id || form.application_id === 'none') { toast.error('Select an application'); return; }
    if (!form.base_salary) { toast.error('Base salary required'); return; }
    if (!form.contract_type) { toast.error('Contract type required'); return; }
    setSaving(true);
    try {
      const { error } = await sb.from('offers').insert({
        application_id: form.application_id,
        base_salary: Number(form.base_salary),
        total_compensation: form.total_compensation ? Number(form.total_compensation) : null,
        currency_code: form.currency_code,
        pay_frequency: form.pay_frequency || null,
        grade_level: form.grade_level || null,
        contract_type: form.contract_type,
        start_date: form.start_date || null,
        expiry_date: form.expiry_date || null,
        offer_status: 'DRAFT',
      });
      if (error) throw error;
      toast.success('Offer created');
      setCreateOpen(false);
      setForm({ ...EMPTY_FORM });
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const advanceStatus = async (offer: Offer, newStatus: string) => {
    try {
      const { error } = await sb.from('offers').update({ offer_status: newStatus, updated_at: new Date().toISOString() }).eq('id', offer.id);
      if (error) throw error;
      toast.success(`Offer ${newStatus.toLowerCase().replace('_', ' ')}`);
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
  };

  const submitResponse = async () => {
    if (!responseOpen) return;
    setSaving(true);
    try {
      const update: Record<string, unknown> = {
        response_type: responseType,
        response_comments: responseComments || null,
        responded_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      if (responseType === 'ACCEPTED') {
        update.offer_status = 'ACCEPTED';
        update.signature_status = 'PENDING';
      } else if (responseType === 'DECLINED') {
        update.offer_status = 'DECLINED';
        update.rejection_category = rejCategory;
        update.rejection_reason = responseComments || null;
      } else {
        update.offer_status = 'VIEWED'; // counter-offer stays in viewed
      }
      const { error } = await sb.from('offers').update(update).eq('id', responseOpen.id);
      if (error) throw error;
      // If accepted, advance application to HIRED
      if (responseType === 'ACCEPTED') {
        await sb.from('applications').update({
          current_stage: 'HIRED',
          hired_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }).eq('application_id', responseOpen.application_id);
      }
      toast.success('Response recorded');
      setResponseOpen(null);
      setResponseComments('');
      setResponseType('ACCEPTED');
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const markSigned = async (offer: Offer) => {
    try {
      const { error } = await sb.from('offers').update({ signature_status: 'SIGNED', signed_at: new Date().toISOString(), updated_at: new Date().toISOString() }).eq('id', offer.id);
      if (error) throw error;
      toast.success('Offer marked as signed');
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
  };

  const filtered = offers.filter(o => {
    const matchSearch = !search || (o.application?.candidate
      ? `${o.application.candidate.first_name} ${o.application.candidate.last_name}`.toLowerCase().includes(search.toLowerCase())
      : false) || o.offer_number.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || o.offer_status === statusFilter;
    return matchSearch && matchStatus;
  });

  const stats = {
    draft: offers.filter(o => o.offer_status === 'DRAFT').length,
    pending: offers.filter(o => o.offer_status === 'PENDING_APPROVAL').length,
    sent: offers.filter(o => ['SENT','VIEWED'].includes(o.offer_status)).length,
    accepted: offers.filter(o => o.offer_status === 'ACCEPTED').length,
    declined: offers.filter(o => o.offer_status === 'DECLINED').length,
    total: offers.length,
  };

  return (
    <div className="p-4 md:p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Offers</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Create and manage employment offers</p>
        </div>
        <Button variant="outline" size="sm" onClick={loadAll} className="gap-1.5">
          <RefreshCw className="h-4 w-4" />Refresh
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
        {[
          { label: 'Draft', value: stats.draft, color: 'text-muted-foreground' },
          { label: 'Pending', value: stats.pending, color: 'text-yellow-600' },
          { label: 'Sent/Viewed', value: stats.sent, color: 'text-indigo-600' },
          { label: 'Accepted', value: stats.accepted, color: 'text-green-600' },
          { label: 'Declined', value: stats.declined, color: 'text-red-600' },
          { label: 'Total', value: stats.total, color: 'text-primary' },
        ].map(s => (
          <Card key={s.label}><CardContent className="p-3 text-center">
            <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </CardContent></Card>
        ))}
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-3 flex-wrap justify-between">
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
            <Input className="pl-9 h-9 w-52" placeholder="Search offers…" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-9 w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {Object.keys(OFFER_STATUS_COLORS).map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <Button size="sm" onClick={() => setCreateOpen(true)} className="gap-1.5">
          <Plus className="h-4 w-4" />New Offer
        </Button>
      </div>

      {/* Table */}
      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead className="whitespace-nowrap">Offer #</TableHead>
              <TableHead className="whitespace-nowrap">Candidate</TableHead>
              <TableHead className="whitespace-nowrap">Position</TableHead>
              <TableHead className="whitespace-nowrap">Contract</TableHead>
              <TableHead className="whitespace-nowrap text-right">Base Salary</TableHead>
              <TableHead className="whitespace-nowrap">Start Date</TableHead>
              <TableHead className="whitespace-nowrap">Expiry</TableHead>
              <TableHead className="whitespace-nowrap">Signature</TableHead>
              <TableHead className="whitespace-nowrap">Status</TableHead>
              <TableHead className="whitespace-nowrap">Actions</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {loading
                ? Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 10 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>
                  ))
                : filtered.length === 0
                  ? <TableRow><TableCell colSpan={10} className="text-center py-12 text-muted-foreground">
                      <FileText className="h-8 w-8 mx-auto mb-2 opacity-40" />
                      No offers found
                    </TableCell></TableRow>
                  : filtered.map(o => (
                    <TableRow key={o.id}>
                      <TableCell className="whitespace-nowrap font-mono text-xs font-medium">{o.offer_number}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-medium">
                        {o.application?.candidate
                          ? `${o.application.candidate.first_name} ${o.application.candidate.last_name}`
                          : o.application?.application_number ?? '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm max-w-[140px] truncate" title={o.application?.vacancy?.title}>
                        {o.application?.vacancy?.title ?? '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{o.contract_type}</TableCell>
                      <TableCell className="whitespace-nowrap text-right text-sm font-medium">
                        {o.base_salary.toLocaleString()} {o.currency_code}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{o.start_date ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{o.expiry_date ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        {o.signature_status
                          ? <Badge className={o.signature_status === 'SIGNED' ? 'bg-green-100 text-green-800' : o.signature_status === 'FAILED' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}>{o.signature_status}</Badge>
                          : <span className="text-xs text-muted-foreground">—</span>}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={OFFER_STATUS_COLORS[o.offer_status] ?? 'bg-muted text-muted-foreground'}>{o.offer_status}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex gap-1 flex-wrap">
                          {/* Status flow buttons */}
                          {o.offer_status === 'DRAFT' && (
                            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => advanceStatus(o, 'PENDING_APPROVAL')}>Submit</Button>
                          )}
                          {o.offer_status === 'PENDING_APPROVAL' && (
                            <>
                              <Button size="sm" className="h-7 text-xs bg-green-600 hover:bg-green-700 text-white" onClick={() => advanceStatus(o, 'APPROVED')}>Approve</Button>
                              <Button size="sm" variant="outline" className="h-7 text-xs border-red-400 text-red-600" onClick={() => advanceStatus(o, 'REVOKED')}>Reject</Button>
                            </>
                          )}
                          {o.offer_status === 'APPROVED' && (
                            <Button size="sm" className="h-7 text-xs gap-1" onClick={() => advanceStatus(o, 'SENT')}>
                              <Send className="h-3 w-3" />Send
                            </Button>
                          )}
                          {o.offer_status === 'SENT' && (
                            <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => advanceStatus(o, 'VIEWED')}>
                              <Eye className="h-3 w-3" />Mark Viewed
                            </Button>
                          )}
                          {(o.offer_status === 'VIEWED' || o.offer_status === 'SENT') && (
                            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => { setResponseOpen(o); setResponseType('ACCEPTED'); setResponseComments(''); }}>
                              Response
                            </Button>
                          )}
                          {o.offer_status === 'ACCEPTED' && o.signature_status === 'PENDING' && (
                            <Button size="sm" className="h-7 text-xs gap-1 bg-teal-600 hover:bg-teal-700 text-white" onClick={() => markSigned(o)}>
                              <CheckCircle2 className="h-3 w-3" />Signed
                            </Button>
                          )}
                          {['DRAFT','PENDING_APPROVAL','APPROVED','SENT'].includes(o.offer_status) && (
                            <Button size="sm" variant="outline" className="h-7 text-xs border-red-300 text-red-500" onClick={() => advanceStatus(o, 'REVOKED')}>
                              <XCircle className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
              }
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Create Offer Dialog */}
      <Dialog open={createOpen} onOpenChange={o => { setCreateOpen(o); if (!o) setForm({ ...EMPTY_FORM }); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>Create Offer Letter</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label>Application (OFFER stage) *</Label>
              <Select value={form.application_id} onValueChange={v => setForm(f => ({ ...f, application_id: v }))}>
                <SelectTrigger className="h-9"><SelectValue placeholder="Select application…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Select —</SelectItem>
                  {applications.map(a => (
                    <SelectItem key={a.application_id} value={a.application_id}>
                      {a.candidate ? `${a.candidate.first_name} ${a.candidate.last_name}` : a.application_number}
                      {a.vacancy ? ` — ${a.vacancy.title}` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Contract Type *</Label>
                <Select value={form.contract_type} onValueChange={v => setForm(f => ({ ...f, contract_type: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['PERMANENT','CONTRACT','INTERNSHIP','TEMPORARY'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Pay Frequency</Label>
                <Select value={form.pay_frequency} onValueChange={v => setForm(f => ({ ...f, pay_frequency: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['MONTHLY','BIWEEKLY','WEEKLY'].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>Base Salary *</Label>
                <Input type="number" value={form.base_salary} onChange={e => setForm(f => ({ ...f, base_salary: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Total Compensation</Label>
                <Input type="number" value={form.total_compensation} onChange={e => setForm(f => ({ ...f, total_compensation: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Currency</Label>
                <Input value={form.currency_code} onChange={e => setForm(f => ({ ...f, currency_code: e.target.value }))} className="h-9" maxLength={3} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Grade Level</Label>
                <Input value={form.grade_level} onChange={e => setForm(f => ({ ...f, grade_level: e.target.value }))} className="h-9" placeholder="e.g. P3" />
              </div>
              <div className="space-y-1.5">
                <Label>Start Date</Label>
                <Input type="date" value={form.start_date} onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Offer Expiry Date</Label>
              <Input type="date" value={form.expiry_date} onChange={e => setForm(f => ({ ...f, expiry_date: e.target.value }))} className="h-9" />
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={saving}>{saving ? 'Saving…' : 'Create Offer'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Candidate Response Dialog */}
      <Dialog open={!!responseOpen} onOpenChange={o => { if (!o) setResponseOpen(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Record Candidate Response</DialogTitle></DialogHeader>
          {responseOpen && (
            <div className="space-y-4 mt-2">
              <p className="text-sm text-muted-foreground">
                Offer <span className="font-medium text-foreground">{responseOpen.offer_number}</span>
                {responseOpen.application?.candidate && (
                  <> — <span className="font-medium text-foreground">{responseOpen.application.candidate.first_name} {responseOpen.application.candidate.last_name}</span></>
                )}
              </p>
              <div className="space-y-1.5">
                <Label>Response Type</Label>
                <Select value={responseType} onValueChange={setResponseType}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ACCEPTED">Accepted</SelectItem>
                    <SelectItem value="DECLINED">Declined</SelectItem>
                    <SelectItem value="COUNTER_OFFER">Counter Offer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {responseType === 'DECLINED' && (
                <div className="space-y-1.5">
                  <Label>Rejection Category</Label>
                  <Select value={rejCategory} onValueChange={setRejCategory}>
                    <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['SALARY','ROLE_MISMATCH','LOCATION','COUNTER_OFFER','OTHER'].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div className="space-y-1.5">
                <Label>Comments / Notes</Label>
                <Textarea rows={3} value={responseComments} onChange={e => setResponseComments(e.target.value)} placeholder="Optional remarks from candidate…" />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setResponseOpen(null)}>Cancel</Button>
                <Button
                  onClick={submitResponse}
                  disabled={saving}
                  className={responseType === 'ACCEPTED' ? 'bg-green-600 hover:bg-green-700 text-white' : responseType === 'DECLINED' ? 'bg-red-600 hover:bg-red-700 text-white' : ''}
                >
                  {saving ? 'Saving…' : 'Record Response'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
