import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Plus, RefreshCw, GraduationCap, ClipboardCheck, Search } from 'lucide-react';

const sb = _sb as any; // eslint-disable-line @typescript-eslint/no-explicit-any

type Exam = {
  id: string; exam_id: string; exam_type: string; exam_stage?: string; exam_title: string;
  exam_description?: string; exam_date?: string; duration_minutes?: number; location?: string;
  online_link?: string; passing_score?: number; exam_status: string; created_at: string;
  vacancy?: { title: string; vacancy_code: string };
};
type ExamResult = {
  id: string; exam_result_id: string; exam_id: string; attendance_status: string;
  score?: number; maximum_score?: number; percentage?: number; result_status: string;
  evaluation_method?: string; evaluation_notes?: string; created_at: string;
  exam?: { exam_title: string; exam_type: string };
  application?: {
    application_number: string;
    candidate?: { first_name: string; last_name: string; email: string };
  };
};
type Vacancy = { job_vacancy_id: string; title: string; vacancy_code: string };
type Application = {
  application_id: string; application_number: string;
  candidate?: { first_name: string; last_name: string };
  vacancy?: { title: string };
};

const EXAM_STATUS_COLORS: Record<string, string> = {
  SCHEDULED: 'bg-blue-100 text-blue-800', IN_PROGRESS: 'bg-yellow-100 text-yellow-800',
  COMPLETED: 'bg-green-100 text-green-800', CANCELLED: 'bg-muted text-muted-foreground',
};
const RESULT_COLORS: Record<string, string> = {
  PENDING: 'bg-muted text-muted-foreground', PASSED: 'bg-green-100 text-green-800', FAILED: 'bg-red-100 text-red-800',
};

const EMPTY_EXAM = { job_vacancy_id: '', exam_type: 'WRITTEN', exam_stage: 'SCREENING_EXAM', exam_title: '', exam_description: '', exam_date: '', duration_minutes: '', location: '', online_link: '', passing_score: '' };
const EMPTY_RESULT = { exam_id: '', application_id: '', attendance_status: 'REGISTERED', score: '', maximum_score: '', evaluation_method: 'MANUAL_SCORE', evaluation_notes: '' };

export function ExamsPage() {
  const [exams, setExams] = useState<Exam[]>([]);
  const [results, setResults] = useState<ExamResult[]>([]);
  const [vacancies, setVacancies] = useState<Vacancy[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [examOpen, setExamOpen] = useState(false);
  const [resultOpen, setResultOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [examForm, setExamForm] = useState({ ...EMPTY_EXAM });
  const [resultForm, setResultForm] = useState({ ...EMPTY_RESULT });

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [exRes, rsRes, vacRes, appRes] = await Promise.all([
        sb.from('exams').select('*, vacancy:job_vacancies(title, vacancy_code)').eq('is_deleted', false).order('created_at', { ascending: false }),
        sb.from('exam_results').select('*, exam:exams(exam_title, exam_type), application:applications(application_number, candidate:candidates(first_name, last_name))').eq('is_deleted', false).order('created_at', { ascending: false }),
        sb.from('job_vacancies').select('job_vacancy_id, title, vacancy_code').eq('is_deleted', false).eq('vacancy_status', 'OPEN').order('title'),
        sb.from('applications').select('application_id, application_number, candidate:candidates(first_name, last_name)').eq('is_deleted', false).order('created_at', { ascending: false }).limit(200),
      ]);
      setExams(exRes.data ?? []);
      setResults(rsRes.data ?? []);
      setVacancies(vacRes.data ?? []);
      setApplications(appRes.data ?? []);
    } catch { toast.error('Failed to load exam data'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const handleCreateExam = async () => {
    if (!examForm.exam_title.trim()) { toast.error('Exam title required'); return; }
    if (!examForm.job_vacancy_id || examForm.job_vacancy_id === 'none') { toast.error('Select a vacancy'); return; }
    setSaving(true);
    try {
      const { error } = await sb.from('exams').insert({
        job_vacancy_id: examForm.job_vacancy_id,
        exam_type: examForm.exam_type,
        exam_stage: examForm.exam_stage || null,
        exam_title: examForm.exam_title.trim(),
        exam_description: examForm.exam_description || null,
        exam_date: examForm.exam_date ? new Date(examForm.exam_date).toISOString() : null,
        duration_minutes: examForm.duration_minutes ? Number(examForm.duration_minutes) : null,
        location: examForm.location || null,
        online_link: examForm.online_link || null,
        passing_score: examForm.passing_score ? Number(examForm.passing_score) : null,
      });
      if (error) throw error;
      toast.success('Exam created');
      setExamOpen(false);
      setExamForm({ ...EMPTY_EXAM });
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const handleCreateResult = async () => {
    if (!resultForm.exam_id || resultForm.exam_id === 'none') { toast.error('Select an exam'); return; }
    if (!resultForm.application_id || resultForm.application_id === 'none') { toast.error('Select an application'); return; }
    setSaving(true);
    try {
      const score = resultForm.score ? Number(resultForm.score) : null;
      const maxScore = resultForm.maximum_score ? Number(resultForm.maximum_score) : null;
      const pct = score != null && maxScore ? Math.round((score / maxScore) * 100 * 100) / 100 : null;
      const { error } = await sb.from('exam_results').insert({
        exam_id: resultForm.exam_id,
        application_id: resultForm.application_id,
        attendance_status: resultForm.attendance_status,
        score, maximum_score: maxScore, percentage: pct,
        evaluation_method: resultForm.evaluation_method || null,
        evaluation_notes: resultForm.evaluation_notes || null,
        result_status: 'PENDING',
      });
      if (error) throw error;
      toast.success('Result recorded');
      setResultOpen(false);
      setResultForm({ ...EMPTY_RESULT });
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const updateExamStatus = async (id: string, status: string) => {
    try {
      const { error } = await sb.from('exams').update({ exam_status: status, updated_at: new Date().toISOString() }).eq('id', id);
      if (error) throw error;
      toast.success(`Exam ${status.toLowerCase()}`);
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
  };

  const updateResultStatus = async (id: string, status: string) => {
    try {
      const { error } = await sb.from('exam_results').update({ result_status: status, updated_at: new Date().toISOString() }).eq('id', id);
      if (error) throw error;
      toast.success(`Result marked ${status.toLowerCase()}`);
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
  };

  const filteredExams = exams.filter(e => !search || e.exam_title.toLowerCase().includes(search.toLowerCase()) || (e.vacancy?.title ?? '').toLowerCase().includes(search.toLowerCase()));
  const filteredResults = results.filter(r => !search || (r.application?.candidate ? `${r.application.candidate.first_name} ${r.application.candidate.last_name}`.toLowerCase().includes(search.toLowerCase()) : false) || (r.exam?.exam_title ?? '').toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="p-4 md:p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Recruitment Exams</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Schedule assessments and record candidate results</p>
        </div>
        <Button variant="outline" size="sm" onClick={loadAll} className="gap-1.5"><RefreshCw className="h-4 w-4" />Refresh</Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Scheduled', value: exams.filter(e => e.exam_status === 'SCHEDULED').length, icon: GraduationCap, color: 'text-blue-600' },
          { label: 'In Progress', value: exams.filter(e => e.exam_status === 'IN_PROGRESS').length, icon: GraduationCap, color: 'text-yellow-600' },
          { label: 'Completed', value: exams.filter(e => e.exam_status === 'COMPLETED').length, icon: ClipboardCheck, color: 'text-green-600' },
          { label: 'Results Recorded', value: results.length, icon: ClipboardCheck, color: 'text-primary' },
        ].map(s => (
          <Card key={s.label}><CardContent className="p-3 flex items-center gap-2">
            <s.icon className={`h-7 w-7 shrink-0 ${s.color}`} />
            <div><p className={`text-xl font-bold ${s.color}`}>{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
          </CardContent></Card>
        ))}
      </div>

      <Tabs defaultValue="exams">
        <TabsList>
          <TabsTrigger value="exams" className="gap-1.5"><GraduationCap className="h-3.5 w-3.5" />Exams ({exams.length})</TabsTrigger>
          <TabsTrigger value="results" className="gap-1.5"><ClipboardCheck className="h-3.5 w-3.5" />Results ({results.length})</TabsTrigger>
        </TabsList>

        {/* Exams */}
        <TabsContent value="exams" className="mt-4 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="relative max-w-xs w-full">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
              <Input className="pl-9 h-9" placeholder="Search exams…" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <Button size="sm" onClick={() => setExamOpen(true)} className="gap-1.5 shrink-0"><Plus className="h-4 w-4" />New Exam</Button>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Title</TableHead>
                  <TableHead className="whitespace-nowrap">Vacancy</TableHead>
                  <TableHead className="whitespace-nowrap">Type</TableHead>
                  <TableHead className="whitespace-nowrap">Stage</TableHead>
                  <TableHead className="whitespace-nowrap">Date</TableHead>
                  <TableHead className="whitespace-nowrap text-center">Duration</TableHead>
                  <TableHead className="whitespace-nowrap text-center">Pass Score</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 4 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 9 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                  : filteredExams.length === 0 ? <TableRow><TableCell colSpan={9} className="text-center py-10 text-muted-foreground"><GraduationCap className="h-8 w-8 mx-auto mb-2 opacity-40" />No exams found</TableCell></TableRow>
                  : filteredExams.map(e => (
                    <TableRow key={e.id}>
                      <TableCell className="whitespace-nowrap font-medium text-sm">{e.exam_title}</TableCell>
                      <TableCell className="whitespace-nowrap text-xs text-muted-foreground">{e.vacancy?.title ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{e.exam_type}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{e.exam_stage ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{e.exam_date ? new Date(e.exam_date).toLocaleDateString() : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-center text-sm">{e.duration_minutes ? `${e.duration_minutes}m` : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-center text-sm">{e.passing_score ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={EXAM_STATUS_COLORS[e.exam_status] ?? 'bg-muted text-muted-foreground'}>{e.exam_status}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex gap-1">
                          {e.exam_status === 'SCHEDULED' && <Button size="sm" className="h-7 text-xs bg-yellow-500 hover:bg-yellow-600 text-white" onClick={() => updateExamStatus(e.id, 'IN_PROGRESS')}>Start</Button>}
                          {e.exam_status === 'IN_PROGRESS' && <Button size="sm" className="h-7 text-xs bg-green-600 hover:bg-green-700 text-white" onClick={() => updateExamStatus(e.id, 'COMPLETED')}>Complete</Button>}
                          {(e.exam_status === 'SCHEDULED' || e.exam_status === 'IN_PROGRESS') && <Button size="sm" variant="outline" className="h-7 text-xs border-red-400 text-red-600" onClick={() => updateExamStatus(e.id, 'CANCELLED')}>Cancel</Button>}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* Results */}
        <TabsContent value="results" className="mt-4 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="relative max-w-xs w-full">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
              <Input className="pl-9 h-9" placeholder="Search results…" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <Button size="sm" onClick={() => setResultOpen(true)} className="gap-1.5 shrink-0"><Plus className="h-4 w-4" />Record Result</Button>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Candidate</TableHead>
                  <TableHead className="whitespace-nowrap">Exam</TableHead>
                  <TableHead className="whitespace-nowrap">Attendance</TableHead>
                  <TableHead className="whitespace-nowrap text-center">Score</TableHead>
                  <TableHead className="whitespace-nowrap text-center">%</TableHead>
                  <TableHead className="whitespace-nowrap">Method</TableHead>
                  <TableHead className="whitespace-nowrap">Result</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 4 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 8 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                  : filteredResults.length === 0 ? <TableRow><TableCell colSpan={8} className="text-center py-10 text-muted-foreground"><ClipboardCheck className="h-8 w-8 mx-auto mb-2 opacity-40" />No results recorded</TableCell></TableRow>
                  : filteredResults.map(r => (
                    <TableRow key={r.id}>
                      <TableCell className="whitespace-nowrap font-medium text-sm">
                        {r.application?.candidate ? `${r.application.candidate.first_name} ${r.application.candidate.last_name}` : r.application?.application_number ?? '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.exam?.exam_title ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap"><Badge className={r.attendance_status === 'ATTENDED' ? 'bg-green-100 text-green-800' : r.attendance_status === 'ABSENT' ? 'bg-red-100 text-red-800' : 'bg-muted text-muted-foreground'}>{r.attendance_status}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap text-center text-sm">{r.score ?? '—'}{r.maximum_score ? `/${r.maximum_score}` : ''}</TableCell>
                      <TableCell className="whitespace-nowrap text-center text-sm">{r.percentage != null ? `${r.percentage}%` : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.evaluation_method ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={RESULT_COLORS[r.result_status] ?? 'bg-muted text-muted-foreground'}>{r.result_status}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        {r.result_status === 'PENDING' && r.attendance_status === 'ATTENDED' && (
                          <div className="flex gap-1">
                            <Button size="sm" className="h-7 text-xs bg-green-600 hover:bg-green-700 text-white" onClick={() => updateResultStatus(r.id, 'PASSED')}>Pass</Button>
                            <Button size="sm" className="h-7 text-xs bg-red-600 hover:bg-red-700 text-white" onClick={() => updateResultStatus(r.id, 'FAILED')}>Fail</Button>
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* New Exam Dialog */}
      <Dialog open={examOpen} onOpenChange={o => { setExamOpen(o); if (!o) setExamForm({ ...EMPTY_EXAM }); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>Schedule Exam</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label>Exam Title *</Label>
              <Input value={examForm.exam_title} onChange={e => setExamForm(f => ({ ...f, exam_title: e.target.value }))} className="h-9" placeholder="e.g. Technical Written Test" />
            </div>
            <div className="space-y-1.5">
              <Label>Vacancy *</Label>
              <Select value={examForm.job_vacancy_id} onValueChange={v => setExamForm(f => ({ ...f, job_vacancy_id: v }))}>
                <SelectTrigger className="h-9"><SelectValue placeholder="Select vacancy…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Select —</SelectItem>
                  {vacancies.map(v => <SelectItem key={v.job_vacancy_id} value={v.job_vacancy_id}>{v.title} ({v.vacancy_code})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Type</Label>
                <Select value={examForm.exam_type} onValueChange={v => setExamForm(f => ({ ...f, exam_type: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="WRITTEN">Written</SelectItem><SelectItem value="PRACTICAL">Practical</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Stage</Label>
                <Select value={examForm.exam_stage} onValueChange={v => setExamForm(f => ({ ...f, exam_stage: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>{['SCREENING_EXAM','TECHNICAL_EXAM','FINAL_EXAM'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Exam Date &amp; Time</Label>
                <Input type="datetime-local" value={examForm.exam_date} onChange={e => setExamForm(f => ({ ...f, exam_date: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Duration (min)</Label>
                <Input type="number" value={examForm.duration_minutes} onChange={e => setExamForm(f => ({ ...f, duration_minutes: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Location</Label>
                <Input value={examForm.location} onChange={e => setExamForm(f => ({ ...f, location: e.target.value }))} className="h-9" placeholder="Room / Address" />
              </div>
              <div className="space-y-1.5">
                <Label>Passing Score</Label>
                <Input type="number" value={examForm.passing_score} onChange={e => setExamForm(f => ({ ...f, passing_score: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Online Link</Label>
              <Input value={examForm.online_link} onChange={e => setExamForm(f => ({ ...f, online_link: e.target.value }))} className="h-9" placeholder="https://…" />
            </div>
            <div className="space-y-1.5">
              <Label>Description</Label>
              <Textarea rows={3} value={examForm.exam_description} onChange={e => setExamForm(f => ({ ...f, exam_description: e.target.value }))} />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setExamOpen(false)}>Cancel</Button>
              <Button onClick={handleCreateExam} disabled={saving}>{saving ? 'Saving…' : 'Create Exam'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Record Result Dialog */}
      <Dialog open={resultOpen} onOpenChange={o => { setResultOpen(o); if (!o) setResultForm({ ...EMPTY_RESULT }); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Record Exam Result</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label>Exam *</Label>
              <Select value={resultForm.exam_id} onValueChange={v => setResultForm(f => ({ ...f, exam_id: v }))}>
                <SelectTrigger className="h-9"><SelectValue placeholder="Select exam…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Select —</SelectItem>
                  {exams.filter(e => e.exam_status !== 'CANCELLED').map(e => <SelectItem key={e.exam_id} value={e.exam_id}>{e.exam_title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Application *</Label>
              <Select value={resultForm.application_id} onValueChange={v => setResultForm(f => ({ ...f, application_id: v }))}>
                <SelectTrigger className="h-9"><SelectValue placeholder="Select application…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Select —</SelectItem>
                  {applications.map(a => <SelectItem key={a.application_id} value={a.application_id}>{a.candidate ? `${a.candidate.first_name} ${a.candidate.last_name}` : a.application_number} — {a.application_number}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Attendance</Label>
                <Select value={resultForm.attendance_status} onValueChange={v => setResultForm(f => ({ ...f, attendance_status: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>{['REGISTERED','ATTENDED','ABSENT'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Evaluation Method</Label>
                <Select value={resultForm.evaluation_method} onValueChange={v => setResultForm(f => ({ ...f, evaluation_method: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>{['AUTO_SCORE','MANUAL_SCORE','PANEL_EVALUATION'].map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Score</Label>
                <Input type="number" value={resultForm.score} onChange={e => setResultForm(f => ({ ...f, score: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Maximum Score</Label>
                <Input type="number" value={resultForm.maximum_score} onChange={e => setResultForm(f => ({ ...f, maximum_score: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Evaluation Notes</Label>
              <Textarea rows={3} value={resultForm.evaluation_notes} onChange={e => setResultForm(f => ({ ...f, evaluation_notes: e.target.value }))} />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setResultOpen(false)}>Cancel</Button>
              <Button onClick={handleCreateResult} disabled={saving}>{saving ? 'Saving…' : 'Record Result'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
