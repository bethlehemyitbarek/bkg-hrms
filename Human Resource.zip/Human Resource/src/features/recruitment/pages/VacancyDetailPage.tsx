import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { ArrowLeft, Plus, Users, ChevronRight, ChevronLeft, UserCheck, XCircle } from 'lucide-react';

const sb = _sb as any; // eslint-disable-line @typescript-eslint/no-explicit-any

const STAGES = ['SUBMITTED','SCREENING','SHORTLISTED','EXAM','INTERVIEW','OFFER','HIRED','REJECTED','WITHDRAWN'] as const;
type Stage = typeof STAGES[number];

const STAGE_COLORS: Record<Stage, string> = {
  SUBMITTED:   'bg-blue-50 border-blue-200',
  SCREENING:   'bg-yellow-50 border-yellow-200',
  SHORTLISTED: 'bg-indigo-50 border-indigo-200',
  EXAM:        'bg-purple-50 border-purple-200',
  INTERVIEW:   'bg-orange-50 border-orange-200',
  OFFER:       'bg-teal-50 border-teal-200',
  HIRED:       'bg-green-50 border-green-200',
  REJECTED:    'bg-red-50 border-red-200',
  WITHDRAWN:   'bg-muted border-border',
};
const STAGE_BADGE: Record<Stage, string> = {
  SUBMITTED:   'bg-blue-100 text-blue-800',
  SCREENING:   'bg-yellow-100 text-yellow-800',
  SHORTLISTED: 'bg-indigo-100 text-indigo-800',
  EXAM:        'bg-purple-100 text-purple-800',
  INTERVIEW:   'bg-orange-100 text-orange-800',
  OFFER:       'bg-teal-100 text-teal-800',
  HIRED:       'bg-green-100 text-green-800',
  REJECTED:    'bg-red-100 text-red-800',
  WITHDRAWN:   'bg-muted text-muted-foreground',
};

type Vacancy = {
  id: string; job_vacancy_id: string; vacancy_code: string; title: string;
  employment_type: string; vacancy_quota: number; filled_count: number;
  vacancy_type: string; vacancy_status: string; application_deadline?: string;
  salary_min?: number; salary_max?: number; required_skills?: string;
  required_qualification?: string; required_experience_years?: number;
  job_description?: string; department?: { name: string };
};
type Application = {
  id: string; application_id: string; application_number: string;
  current_stage: Stage; application_type: string; application_source?: string;
  stage_updated_at?: string; created_at: string;
  candidate?: { first_name: string; last_name: string; email: string; phone_number?: string; candidate_number: string };
  rejection_reason?: string;
};
type Candidate = { candidate_id: string; candidate_number: string; first_name: string; last_name: string; email: string };

const NEXT_STAGE: Partial<Record<Stage, Stage>> = {
  SUBMITTED: 'SCREENING', SCREENING: 'SHORTLISTED', SHORTLISTED: 'EXAM',
  EXAM: 'INTERVIEW', INTERVIEW: 'OFFER', OFFER: 'HIRED',
};
const PREV_STAGE: Partial<Record<Stage, Stage>> = Object.fromEntries(
  Object.entries(NEXT_STAGE).map(([k, v]) => [v, k as Stage])
) as Partial<Record<Stage, Stage>>;

export function VacancyDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [vacancy, setVacancy] = useState<Vacancy | null>(null);
  const [applications, setApplications] = useState<Application[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [addOpen, setAddOpen] = useState(false);
  const [rejectOpen, setRejectOpen] = useState<Application | null>(null);
  const [rejCategory, setRejCategory] = useState('QUALIFICATION');
  const [rejReason, setRejReason] = useState('');
  const [saving, setSaving] = useState(false);
  const [addForm, setAddForm] = useState({ candidate_id: '', application_source: 'MANUAL', application_type: 'EXTERNAL' });

  const loadData = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const [vacRes, appRes, candRes] = await Promise.all([
        sb.from('job_vacancies').select('*, department:departments(name)').eq('job_vacancy_id', id).eq('is_deleted', false).maybeSingle(),
        sb.from('applications').select('*, candidate:candidates(first_name,last_name,email,phone_number,candidate_number)').eq('job_vacancy_id', id).eq('is_deleted', false).order('created_at', { ascending: false }),
        sb.from('candidates').select('candidate_id, candidate_number, first_name, last_name, email').eq('is_deleted', false).eq('is_blacklisted', false).order('last_name'),
      ]);
      setVacancy(vacRes.data);
      setApplications(appRes.data ?? []);
      setCandidates(candRes.data ?? []);
    } catch { toast.error('Failed to load vacancy'); }
    finally { setLoading(false); }
  }, [id]);

  useEffect(() => { loadData(); }, [loadData]);

  const moveStage = async (app: Application, direction: 'next' | 'prev' | 'reject') => {
    if (direction === 'reject') { setRejectOpen(app); return; }
    const newStage = direction === 'next' ? NEXT_STAGE[app.current_stage] : PREV_STAGE[app.current_stage];
    if (!newStage) return;
    try {
      const update: Record<string, unknown> = { current_stage: newStage, stage_updated_at: new Date().toISOString(), updated_at: new Date().toISOString() };
      if (newStage === 'HIRED') update.hired_at = new Date().toISOString();
      const { error } = await sb.from('applications').update(update).eq('application_id', app.application_id);
      if (error) throw error;
      toast.success(`Moved to ${newStage}`);
      loadData();
    } catch (e) { toast.error((e as Error).message); }
  };

  const submitReject = async () => {
    if (!rejectOpen) return;
    setSaving(true);
    try {
      const { error } = await sb.from('applications').update({
        current_stage: 'REJECTED', rejection_category: rejCategory,
        rejection_reason: rejReason || null, stage_updated_at: new Date().toISOString(), updated_at: new Date().toISOString(),
      }).eq('application_id', rejectOpen.application_id);
      if (error) throw error;
      toast.success('Application rejected');
      setRejectOpen(null); setRejReason(''); setRejCategory('QUALIFICATION');
      loadData();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const addApplication = async () => {
    if (!addForm.candidate_id || addForm.candidate_id === 'none') { toast.error('Select a candidate'); return; }
    setSaving(true);
    try {
      const { error } = await sb.from('applications').insert({
        job_vacancy_id: id,
        candidate_id: addForm.candidate_id,
        application_type: addForm.application_type,
        application_source: addForm.application_source,
        current_stage: 'SUBMITTED',
      });
      if (error) throw error;
      toast.success('Application added');
      setAddOpen(false);
      setAddForm({ candidate_id: '', application_source: 'MANUAL', application_type: 'EXTERNAL' });
      loadData();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const byStage = (stage: Stage) => applications.filter(a => a.current_stage === stage);
  const activeStages: Stage[] = ['SUBMITTED','SCREENING','SHORTLISTED','EXAM','INTERVIEW','OFFER','HIRED'];

  if (loading) return <div className="p-6 space-y-4">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>;
  if (!vacancy) return <div className="p-6"><p className="text-muted-foreground">Vacancy not found.</p></div>;

  return (
    <div className="p-4 md:p-6 space-y-5">
      {/* Header */}
      <div className="flex items-start gap-3">
        <Button variant="outline" size="sm" onClick={() => navigate('/recruitment')} className="gap-1 mt-0.5 shrink-0"><ArrowLeft className="h-4 w-4" />Back</Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-bold text-balance">{vacancy.title}</h1>
            <Badge className="bg-muted text-muted-foreground font-mono text-xs">{vacancy.vacancy_code}</Badge>
            <Badge className={(STAGE_BADGE as Record<string,string>)[vacancy.vacancy_status] ?? 'bg-muted text-muted-foreground'}>{vacancy.vacancy_status}</Badge>
          </div>
          <p className="text-sm text-muted-foreground mt-0.5">
            {vacancy.department?.name ?? 'No Dept'} · {vacancy.employment_type} · {vacancy.vacancy_type}
            {vacancy.application_deadline && ` · Closes ${vacancy.application_deadline}`}
          </p>
        </div>
        <Button size="sm" onClick={() => setAddOpen(true)} className="gap-1.5 shrink-0"><Plus className="h-4 w-4" />Add Application</Button>
      </div>

      {/* Info cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Quota / Filled', value: `${vacancy.vacancy_quota} / ${vacancy.filled_count}` },
          { label: 'Total Applications', value: applications.filter(a => !['REJECTED','WITHDRAWN'].includes(a.current_stage)).length },
          { label: 'Hired', value: byStage('HIRED').length },
          { label: 'Rejected', value: byStage('REJECTED').length },
        ].map(s => (
          <Card key={s.label}><CardContent className="p-3 text-center">
            <p className="text-xl font-bold text-primary">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </CardContent></Card>
        ))}
      </div>

      {/* Pipeline board */}
      <div>
        <h2 className="text-sm font-semibold mb-3 text-muted-foreground uppercase tracking-wide">Application Pipeline</h2>
        <div className="overflow-x-auto">
          <div className="flex gap-3 min-w-max pb-2">
            {activeStages.map(stage => (
              <div key={stage} className={`w-52 shrink-0 rounded-lg border-2 ${STAGE_COLORS[stage]} flex flex-col`}>
                <div className="px-3 pt-3 pb-2 border-b border-inherit flex items-center justify-between">
                  <span className="text-xs font-semibold">{stage}</span>
                  <span className="text-xs font-bold bg-white/60 rounded-full w-5 h-5 flex items-center justify-center">{byStage(stage).length}</span>
                </div>
                <div className="flex-1 p-2 space-y-2 overflow-y-auto max-h-80">
                  {byStage(stage).length === 0
                    ? <p className="text-center text-xs text-muted-foreground py-4">Empty</p>
                    : byStage(stage).map(app => (
                      <div key={app.application_id} className="bg-background rounded-md p-2.5 border border-border shadow-sm">
                        <p className="text-xs font-semibold truncate">
                          {app.candidate ? `${app.candidate.first_name} ${app.candidate.last_name}` : app.application_number}
                        </p>
                        {app.candidate?.email && <p className="text-xs text-muted-foreground truncate">{app.candidate.email}</p>}
                        <p className="text-xs text-muted-foreground font-mono">{app.application_number}</p>
                        <div className="flex items-center gap-1 mt-2">
                          {PREV_STAGE[stage] && (
                            <button className="p-0.5 rounded hover:bg-muted" onClick={() => moveStage(app, 'prev')} title="Move back">
                              <ChevronLeft className="h-3.5 w-3.5 text-muted-foreground" />
                            </button>
                          )}
                          <div className="flex-1" />
                          {stage !== 'HIRED' && stage !== 'REJECTED' && (
                            <button className="p-0.5 rounded hover:bg-red-100" onClick={() => moveStage(app, 'reject')} title="Reject">
                              <XCircle className="h-3.5 w-3.5 text-red-500" />
                            </button>
                          )}
                          {NEXT_STAGE[stage] && (
                            <button className="p-0.5 rounded hover:bg-muted" onClick={() => moveStage(app, 'next')} title="Move forward">
                              <ChevronRight className="h-3.5 w-3.5 text-primary" />
                            </button>
                          )}
                          {stage === 'HIRED' && <UserCheck className="h-3.5 w-3.5 text-green-600 ml-auto" />}
                        </div>
                      </div>
                    ))
                  }
                </div>
              </div>
            ))}
            {/* Rejected column */}
            <div className={`w-52 shrink-0 rounded-lg border-2 ${STAGE_COLORS.REJECTED} flex flex-col`}>
              <div className="px-3 pt-3 pb-2 border-b border-inherit flex items-center justify-between">
                <span className="text-xs font-semibold">REJECTED</span>
                <span className="text-xs font-bold bg-white/60 rounded-full w-5 h-5 flex items-center justify-center">{byStage('REJECTED').length}</span>
              </div>
              <div className="flex-1 p-2 space-y-2 overflow-y-auto max-h-80">
                {byStage('REJECTED').length === 0
                  ? <p className="text-center text-xs text-muted-foreground py-4">None</p>
                  : byStage('REJECTED').map(app => (
                    <div key={app.application_id} className="bg-background rounded-md p-2.5 border border-border shadow-sm opacity-70">
                      <p className="text-xs font-semibold truncate">
                        {app.candidate ? `${app.candidate.first_name} ${app.candidate.last_name}` : app.application_number}
                      </p>
                      {app.rejection_reason && <p className="text-xs text-red-600 truncate" title={app.rejection_reason}>{app.rejection_reason}</p>}
                    </div>
                  ))
                }
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Job detail */}
      <Card>
        <CardHeader className="pb-2 pt-4 px-4"><CardTitle className="text-sm">Vacancy Details</CardTitle></CardHeader>
        <CardContent className="px-4 pb-4 grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-3 text-sm">
          {[
            { label: 'Required Qualification', value: vacancy.required_qualification },
            { label: 'Experience Required', value: vacancy.required_experience_years != null ? `${vacancy.required_experience_years} yrs` : null },
            { label: 'Required Skills', value: vacancy.required_skills },
            { label: 'Salary Range', value: vacancy.salary_min && vacancy.salary_max ? `${vacancy.salary_min.toLocaleString()} – ${vacancy.salary_max.toLocaleString()} ETB` : null },
            { label: 'Vacancy Type', value: vacancy.vacancy_type },
            { label: 'Employment Type', value: vacancy.employment_type },
          ].map(f => f.value && (
            <div key={f.label}><p className="text-xs text-muted-foreground">{f.label}</p><p className="font-medium">{f.value}</p></div>
          ))}
          {vacancy.job_description && (
            <div className="col-span-full"><p className="text-xs text-muted-foreground">Job Description</p><p className="whitespace-pre-wrap text-sm">{vacancy.job_description}</p></div>
          )}
        </CardContent>
      </Card>

      {/* Add Application Dialog */}
      <Dialog open={addOpen} onOpenChange={o => { setAddOpen(o); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Add Application</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label>Candidate *</Label>
              <Select value={addForm.candidate_id} onValueChange={v => setAddForm(f => ({ ...f, candidate_id: v }))}>
                <SelectTrigger className="h-9"><SelectValue placeholder="Select candidate…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Select —</SelectItem>
                  {candidates.map(c => <SelectItem key={c.candidate_id} value={c.candidate_id}>{c.first_name} {c.last_name} ({c.email})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Type</Label>
                <Select value={addForm.application_type} onValueChange={v => setAddForm(f => ({ ...f, application_type: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="EXTERNAL">External</SelectItem><SelectItem value="INTERNAL">Internal</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Source</Label>
                <Select value={addForm.application_source} onValueChange={v => setAddForm(f => ({ ...f, application_source: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>{['CAREER_SITE','REFERRAL','LINKEDIN','AGENCY','MANUAL','INTERNAL'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
              <Button onClick={addApplication} disabled={saving}>{saving ? 'Adding…' : 'Add Application'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={!!rejectOpen} onOpenChange={o => { if (!o) setRejectOpen(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Reject Application</DialogTitle></DialogHeader>
          {rejectOpen && <div className="space-y-4 mt-2">
            <p className="text-sm text-muted-foreground">
              Rejecting <span className="font-medium text-foreground">
                {rejectOpen.candidate ? `${rejectOpen.candidate.first_name} ${rejectOpen.candidate.last_name}` : rejectOpen.application_number}
              </span>
            </p>
            <div className="space-y-1.5">
              <Label>Rejection Category</Label>
              <Select value={rejCategory} onValueChange={setRejCategory}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>{['QUALIFICATION','EXPERIENCE','BEHAVIORAL','SALARY_MISMATCH','OTHER'].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Reason</Label>
              <Textarea rows={3} value={rejReason} onChange={e => setRejReason(e.target.value)} placeholder="Optional rejection notes…" />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setRejectOpen(null)}>Cancel</Button>
              <Button className="bg-red-600 hover:bg-red-700 text-white" onClick={submitReject} disabled={saving}>{saving ? 'Saving…' : 'Reject'}</Button>
            </div>
          </div>}
        </DialogContent>
      </Dialog>
    </div>
  );
}
