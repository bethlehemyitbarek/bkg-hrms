import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Plus, RefreshCw, Briefcase, Users, ClipboardList, ChevronRight, Search, FileText, Layers, DollarSign, UserSearch, ShieldCheck } from 'lucide-react';

const sb = _sb as any; // eslint-disable-line @typescript-eslint/no-explicit-any

type RR = {
  id: string; recruitment_request_id: string; request_number: string;
  employee_type: string; requested_headcount: number; approved_headcount?: number; priority_level?: string;
  request_status: string; work_location?: string; justification?: string;
  budget_estimated?: number; expiry_date?: string; created_at: string;
  department?: { name: string };
};
type Vacancy = {
  id: string; job_vacancy_id: string; vacancy_code: string; title: string;
  employment_type: string; vacancy_quota: number; filled_count: number;
  vacancy_type: string; vacancy_status: string; application_deadline?: string;
  salary_min?: number; salary_max?: number; required_skills?: string;
  department?: { name: string };
};
type Candidate = {
  id: string; candidate_id: string; candidate_number: string;
  first_name: string; last_name: string; email: string; phone_number?: string;
  source_channel?: string; years_of_experience?: number; current_company?: string;
  expected_salary?: number; is_blacklisted: boolean; is_consent_given: boolean; created_at: string;
};

const STATUS_COLORS: Record<string, string> = {
  DRAFT: 'bg-muted text-muted-foreground',
  PENDING_APPROVAL: 'bg-yellow-100 text-yellow-800',
  APPROVED: 'bg-green-100 text-green-800',
  OPEN: 'bg-green-100 text-green-800',
  REJECTED: 'bg-red-100 text-red-800',
  EXPIRED: 'bg-orange-100 text-orange-800',
  ON_HOLD: 'bg-orange-100 text-orange-800',
  CLOSED: 'bg-muted text-muted-foreground',
  CANCELLED: 'bg-red-100 text-red-800',
  ARCHIVED: 'bg-muted text-muted-foreground',
  CRITICAL: 'bg-red-100 text-red-800',
  HIGH: 'bg-orange-100 text-orange-800',
  MEDIUM: 'bg-yellow-100 text-yellow-800',
  LOW: 'bg-blue-100 text-blue-800',
};

const EMPTY_RR_FORM = { employee_type: 'PERMANENT', requested_headcount: 1, priority_level: 'MEDIUM', work_location: '', justification: '', budget_estimated: '', expiry_date: '' };
const EMPTY_VAC_FORM = { title: '', employment_type: 'PERMANENT', vacancy_quota: 1, vacancy_type: 'BOTH', salary_min: '', salary_max: '', required_skills: '', required_qualification: '', required_experience_years: '', application_deadline: '', job_description: '' };
const EMPTY_CAND_FORM = { first_name: '', last_name: '', email: '', phone_number: '', source_channel: 'OTHER', years_of_experience: '', current_company: '', expected_salary: '', is_consent_given: true };

export function RecruitmentPage() {
  const navigate = useNavigate();
  const [requests, setRequests] = useState<RR[]>([]);
  const [vacancies, setVacancies] = useState<Vacancy[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [departments, setDepartments] = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  // Stats
  const [stats, setStats] = useState({ openVacancies: 0, totalApplications: 0, pendingRR: 0, totalCandidates: 0 });

  // Dialogs
  const [rrOpen, setRrOpen] = useState(false);
  const [vacOpen, setVacOpen] = useState(false);
  const [candOpen, setCandOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [rrForm, setRrForm] = useState({ ...EMPTY_RR_FORM, department_id: '' });
  const [vacForm, setVacForm] = useState({ ...EMPTY_VAC_FORM, department_id: '', recruitment_request_id: '' });
  const [candForm, setCandForm] = useState({ ...EMPTY_CAND_FORM });

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [rrRes, vacRes, candRes, deptRes, appRes] = await Promise.all([
        sb.from('recruitment_requests').select('*, department:departments(name)').eq('is_deleted', false).order('created_at', { ascending: false }).limit(50),
        sb.from('job_vacancies').select('*, department:departments(name)').eq('is_deleted', false).order('created_at', { ascending: false }).limit(50),
        sb.from('candidates').select('*').eq('is_deleted', false).order('created_at', { ascending: false }).limit(100),
        sb.from('departments').select('id, name').order('name'),
        sb.from('applications').select('id', { count: 'exact', head: true }).eq('is_deleted', false),
      ]);
      setRequests(rrRes.data ?? []);
      setVacancies(vacRes.data ?? []);
      setCandidates(candRes.data ?? []);
      setDepartments(deptRes.data ?? []);
      setStats({
        openVacancies: (vacRes.data ?? []).filter((v: Vacancy) => v.vacancy_status === 'OPEN').length,
        pendingRR: (rrRes.data ?? []).filter((r: RR) => r.request_status === 'PENDING_APPROVAL').length,
        totalApplications: appRes.count ?? 0,
        totalCandidates: (candRes.data ?? []).length,
      });
    } catch { toast.error('Failed to load recruitment data'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const handleCreateRR = async () => {
    if (!rrForm.employee_type) { toast.error('Employee type required'); return; }
    setSaving(true);
    try {
      const { error } = await sb.from('recruitment_requests').insert({
        employee_type: rrForm.employee_type,
        department_id: rrForm.department_id || null,
        requested_headcount: Number(rrForm.requested_headcount),
        priority_level: rrForm.priority_level || null,
        work_location: rrForm.work_location || null,
        justification: rrForm.justification || null,
        budget_estimated: rrForm.budget_estimated ? Number(rrForm.budget_estimated) : null,
        expiry_date: rrForm.expiry_date || null,
      });
      if (error) throw error;
      toast.success('Recruitment request created');
      setRrOpen(false);
      setRrForm({ ...EMPTY_RR_FORM, department_id: '' });
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const handleCreateVacancy = async () => {
    if (!vacForm.title.trim()) { toast.error('Title required'); return; }
    setSaving(true);
    try {
      const { error } = await sb.from('job_vacancies').insert({
        title: vacForm.title.trim(),
        employment_type: vacForm.employment_type,
        department_id: vacForm.department_id || null,
        recruitment_request_id: vacForm.recruitment_request_id || null,
        vacancy_quota: Number(vacForm.vacancy_quota),
        vacancy_type: vacForm.vacancy_type,
        salary_min: vacForm.salary_min ? Number(vacForm.salary_min) : null,
        salary_max: vacForm.salary_max ? Number(vacForm.salary_max) : null,
        required_skills: vacForm.required_skills || null,
        required_qualification: vacForm.required_qualification || null,
        required_experience_years: vacForm.required_experience_years ? Number(vacForm.required_experience_years) : null,
        application_deadline: vacForm.application_deadline || null,
        job_description: vacForm.job_description || null,
        vacancy_status: 'DRAFT',
      });
      if (error) throw error;
      toast.success('Job vacancy created');
      setVacOpen(false);
      setVacForm({ ...EMPTY_VAC_FORM, department_id: '', recruitment_request_id: '' });
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const handleCreateCandidate = async () => {
    if (!candForm.first_name.trim() || !candForm.email.trim()) { toast.error('First name and email required'); return; }
    setSaving(true);
    try {
      const { error } = await sb.from('candidates').insert({
        first_name: candForm.first_name.trim(),
        last_name: candForm.last_name.trim() || '',
        email: candForm.email.trim(),
        phone_number: candForm.phone_number || null,
        source_channel: candForm.source_channel || null,
        years_of_experience: candForm.years_of_experience ? Number(candForm.years_of_experience) : null,
        current_company: candForm.current_company || null,
        expected_salary: candForm.expected_salary ? Number(candForm.expected_salary) : null,
        is_consent_given: candForm.is_consent_given,
        consent_timestamp: candForm.is_consent_given ? new Date().toISOString() : null,
      });
      if (error) throw error;
      toast.success('Candidate added');
      setCandOpen(false);
      setCandForm({ ...EMPTY_CAND_FORM });
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const filteredCandidates = candidates.filter(c =>
    !search || `${c.first_name} ${c.last_name} ${c.email}`.toLowerCase().includes(search.toLowerCase())
  );
  const filteredVacancies = vacancies.filter(v =>
    !search || v.title.toLowerCase().includes(search.toLowerCase())
  );

  const updateRRStatus = async (id: string, status: string) => {
    try {
      const { error } = await sb.from('recruitment_requests').update({ request_status: status, updated_at: new Date().toISOString() }).eq('id', id);
      if (error) throw error;
      toast.success(`Request ${status.toLowerCase()}`);
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
  };

  const updateVacancyStatus = async (id: string, status: string) => {
    try {
      const { error } = await sb.from('job_vacancies').update({ vacancy_status: status, updated_at: new Date().toISOString() }).eq('id', id);
      if (error) throw error;
      toast.success(`Vacancy ${status.toLowerCase()}`);
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Recruitment</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage hiring requests, vacancies, candidates, and pipeline</p>
        </div>
        <Button variant="outline" size="sm" onClick={loadAll} className="gap-1.5">
          <RefreshCw className="h-4 w-4" />Refresh
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Open Vacancies', value: stats.openVacancies, icon: Briefcase, color: 'text-green-600' },
          { label: 'Pending Requests', value: stats.pendingRR, icon: ClipboardList, color: 'text-yellow-600' },
          { label: 'Total Applications', value: stats.totalApplications, icon: FileText, color: 'text-blue-600' },
          { label: 'Candidates', value: stats.totalCandidates, icon: Users, color: 'text-primary' },
        ].map(s => (
          <Card key={s.label}><CardContent className="p-4 flex items-center gap-3">
            <s.icon className={`h-8 w-8 shrink-0 ${s.color}`} />
            <div><p className={`text-2xl font-bold ${s.color}`}>{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
          </CardContent></Card>
        ))}
      </div>

      {/* Main tabs */}
      <Tabs defaultValue="requests">
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="requests" className="gap-1.5"><ClipboardList className="h-3.5 w-3.5" />Requests ({requests.length})</TabsTrigger>
          <TabsTrigger value="vacancies" className="gap-1.5"><Briefcase className="h-3.5 w-3.5" />Vacancies ({vacancies.length})</TabsTrigger>
          <TabsTrigger value="candidates" className="gap-1.5"><Users className="h-3.5 w-3.5" />Candidates ({candidates.length})</TabsTrigger>
          <TabsTrigger value="pipeline" className="gap-1.5"><Layers className="h-3.5 w-3.5" />Pipeline</TabsTrigger>
          <TabsTrigger value="cost" className="gap-1.5"><DollarSign className="h-3.5 w-3.5" />Cost Per Hire</TabsTrigger>
          <TabsTrigger value="talent-pool" className="gap-1.5"><UserSearch className="h-3.5 w-3.5" />Talent Pool</TabsTrigger>
          <TabsTrigger value="background" className="gap-1.5"><ShieldCheck className="h-3.5 w-3.5" />Background Check</TabsTrigger>
        </TabsList>

        {/* ── Recruitment Requests ── */}
        <TabsContent value="requests" className="mt-4 space-y-3">
          <div className="flex justify-end">
            <Button size="sm" onClick={() => setRrOpen(true)} className="gap-1.5"><Plus className="h-4 w-4" />New Request</Button>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Request #</TableHead>
                  <TableHead className="whitespace-nowrap">Department</TableHead>
                  <TableHead className="whitespace-nowrap">Type</TableHead>
                  <TableHead className="whitespace-nowrap text-center">Headcount</TableHead>
                  <TableHead className="whitespace-nowrap">Priority</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Expiry</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 4 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 8 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                  : requests.length === 0 ? <TableRow><TableCell colSpan={8} className="text-center py-10 text-muted-foreground"><ClipboardList className="h-8 w-8 mx-auto mb-2 opacity-40" />No recruitment requests yet</TableCell></TableRow>
                  : requests.map(r => (
                    <TableRow key={r.id}>
                      <TableCell className="whitespace-nowrap font-mono text-xs font-medium">{r.request_number}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.department?.name ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.employee_type}</TableCell>
                      <TableCell className="whitespace-nowrap text-center text-sm font-medium">{r.requested_headcount}{r.approved_headcount != null && <span className="text-muted-foreground">/{r.approved_headcount}</span>}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        {r.priority_level && <Badge className={STATUS_COLORS[r.priority_level] ?? 'bg-muted text-muted-foreground'}>{r.priority_level}</Badge>}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={STATUS_COLORS[r.request_status] ?? 'bg-muted text-muted-foreground'}>{r.request_status}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.expiry_date ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        {r.request_status === 'DRAFT' && (
                          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => updateRRStatus(r.id, 'PENDING_APPROVAL')}>Submit</Button>
                        )}
                        {r.request_status === 'PENDING_APPROVAL' && (
                          <div className="flex gap-1">
                            <Button size="sm" className="h-7 text-xs bg-green-600 hover:bg-green-700 text-white" onClick={() => updateRRStatus(r.id, 'APPROVED')}>Approve</Button>
                            <Button size="sm" variant="outline" className="h-7 text-xs border-red-500 text-red-600" onClick={() => updateRRStatus(r.id, 'REJECTED')}>Reject</Button>
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── Vacancies ── */}
        <TabsContent value="vacancies" className="mt-4 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="relative max-w-xs w-full">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
              <Input className="pl-9 h-9" placeholder="Search vacancies…" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <Button size="sm" onClick={() => setVacOpen(true)} className="gap-1.5 shrink-0"><Plus className="h-4 w-4" />New Vacancy</Button>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Code</TableHead>
                  <TableHead className="whitespace-nowrap">Title</TableHead>
                  <TableHead className="whitespace-nowrap">Department</TableHead>
                  <TableHead className="whitespace-nowrap">Type</TableHead>
                  <TableHead className="whitespace-nowrap text-center">Quota/Filled</TableHead>
                  <TableHead className="whitespace-nowrap">Deadline</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 4 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 8 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                  : filteredVacancies.length === 0 ? <TableRow><TableCell colSpan={8} className="text-center py-10 text-muted-foreground"><Briefcase className="h-8 w-8 mx-auto mb-2 opacity-40" />No vacancies found</TableCell></TableRow>
                  : filteredVacancies.map(v => (
                    <TableRow key={v.id} className="cursor-pointer hover:bg-muted/30" onClick={() => navigate(`/recruitment/vacancy/${v.job_vacancy_id}`)}>
                      <TableCell className="whitespace-nowrap font-mono text-xs">{v.vacancy_code}</TableCell>
                      <TableCell className="whitespace-nowrap font-medium text-sm">{v.title}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{v.department?.name ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{v.employment_type}</TableCell>
                      <TableCell className="whitespace-nowrap text-center text-sm">{v.filled_count}<span className="text-muted-foreground">/{v.vacancy_quota}</span></TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{v.application_deadline ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap" onClick={e => e.stopPropagation()}>
                        <Badge className={STATUS_COLORS[v.vacancy_status] ?? 'bg-muted text-muted-foreground'}>{v.vacancy_status}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap" onClick={e => e.stopPropagation()}>
                        <div className="flex gap-1">
                          {v.vacancy_status === 'DRAFT' && <Button size="sm" className="h-7 text-xs bg-green-600 hover:bg-green-700 text-white" onClick={() => updateVacancyStatus(v.id, 'OPEN')}>Publish</Button>}
                          {v.vacancy_status === 'OPEN' && <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => updateVacancyStatus(v.id, 'ON_HOLD')}>Hold</Button>}
                          <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => navigate(`/recruitment/vacancy/${v.job_vacancy_id}`)}>
                            <ChevronRight className="h-3.5 w-3.5" />View
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── Candidates ── */}
        <TabsContent value="candidates" className="mt-4 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="relative max-w-xs w-full">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
              <Input className="pl-9 h-9" placeholder="Search candidates…" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <Button size="sm" onClick={() => setCandOpen(true)} className="gap-1.5 shrink-0"><Plus className="h-4 w-4" />Add Candidate</Button>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Candidate #</TableHead>
                  <TableHead className="whitespace-nowrap">Name</TableHead>
                  <TableHead className="whitespace-nowrap">Email</TableHead>
                  <TableHead className="whitespace-nowrap">Phone</TableHead>
                  <TableHead className="whitespace-nowrap">Source</TableHead>
                  <TableHead className="whitespace-nowrap text-center">Exp (yrs)</TableHead>
                  <TableHead className="whitespace-nowrap">Company</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 8 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                  : filteredCandidates.length === 0 ? <TableRow><TableCell colSpan={8} className="text-center py-10 text-muted-foreground"><Users className="h-8 w-8 mx-auto mb-2 opacity-40" />No candidates found</TableCell></TableRow>
                  : filteredCandidates.map(c => (
                    <TableRow key={c.id}>
                      <TableCell className="whitespace-nowrap font-mono text-xs">{c.candidate_number}</TableCell>
                      <TableCell className="whitespace-nowrap font-medium text-sm">{c.first_name} {c.last_name}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{c.email}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{c.phone_number ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{c.source_channel ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-center text-sm">{c.years_of_experience ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{c.current_company ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        {c.is_blacklisted
                          ? <Badge className="bg-red-100 text-red-800">Blacklisted</Badge>
                          : c.is_consent_given
                            ? <Badge className="bg-green-100 text-green-800">Active</Badge>
                            : <Badge className="bg-muted text-muted-foreground">No Consent</Badge>}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── Pipeline Summary ── */}
        <TabsContent value="pipeline" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card><CardContent className="p-4">
              <h3 className="font-semibold mb-3 text-sm">Vacancies by Status</h3>
              <div className="space-y-2">
                {['DRAFT','APPROVED','OPEN','ON_HOLD','CLOSED','CANCELLED'].map(s => {
                  const count = vacancies.filter(v => v.vacancy_status === s).length;
                  return (
                    <div key={s} className="flex items-center gap-3">
                      <span className="w-32 text-xs text-muted-foreground">{s}</span>
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: vacancies.length ? `${(count / vacancies.length) * 100}%` : '0%' }} />
                      </div>
                      <span className="w-8 text-xs font-medium text-right">{count}</span>
                    </div>
                  );
                })}
              </div>
            </CardContent></Card>
            <Card><CardContent className="p-4">
              <h3 className="font-semibold mb-3 text-sm">Request Status</h3>
              <div className="space-y-2">
                {['DRAFT','PENDING_APPROVAL','APPROVED','REJECTED','EXPIRED'].map(s => {
                  const count = requests.filter(r => r.request_status === s).length;
                  return (
                    <div key={s} className="flex items-center gap-3">
                      <span className="w-36 text-xs text-muted-foreground">{s}</span>
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: requests.length ? `${(count / requests.length) * 100}%` : '0%' }} />
                      </div>
                      <span className="w-8 text-xs font-medium text-right">{count}</span>
                    </div>
                  );
                })}
              </div>
            </CardContent></Card>
            <Card className="md:col-span-2"><CardContent className="p-4">
              <h3 className="font-semibold mb-3 text-sm">Active Open Vacancies</h3>
              {vacancies.filter(v => v.vacancy_status === 'OPEN').length === 0
                ? <p className="text-sm text-muted-foreground text-center py-4">No open vacancies</p>
                : <div className="space-y-2">
                  {vacancies.filter(v => v.vacancy_status === 'OPEN').map(v => (
                    <div key={v.id} className="flex items-center justify-between gap-2 py-1.5 border-b border-border last:border-0">
                      <div className="min-w-0">
                        <p className="font-medium text-sm truncate">{v.title}</p>
                        <p className="text-xs text-muted-foreground">{v.department?.name ?? '—'} · {v.employment_type}</p>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Filled</p>
                          <p className="text-sm font-bold">{v.filled_count}/{v.vacancy_quota}</p>
                        </div>
                        <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => navigate(`/recruitment/vacancy/${v.job_vacancy_id}`)}>
                          <ChevronRight className="h-3.5 w-3.5" />Pipeline
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              }
            </CardContent></Card>
          </div>
        </TabsContent>

        {/* ── FR-REC-017: Cost Per Hire ── */}
        <TabsContent value="cost" className="mt-4">
          <RecruitmentCostTab />
        </TabsContent>

        {/* ── FR-REC-018: Talent Pool ── */}
        <TabsContent value="talent-pool" className="mt-4">
          <TalentPoolTab />
        </TabsContent>

        {/* ── FR-REC-019/023: Background Check ── */}
        <TabsContent value="background" className="mt-4">
          <BackgroundCheckTab />
        </TabsContent>

      </Tabs>

      {/* ── New RR Dialog ── */}
      <Dialog open={rrOpen} onOpenChange={o => { setRrOpen(o); if (!o) setRrForm({ ...EMPTY_RR_FORM, department_id: '' }); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Recruitment Request</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Department</Label>
                <Select value={rrForm.department_id} onValueChange={v => setRrForm(f => ({ ...f, department_id: v }))}>
                  <SelectTrigger className="h-9"><SelectValue placeholder="Select…" /></SelectTrigger>
                  <SelectContent>{departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Employee Type *</Label>
                <Select value={rrForm.employee_type} onValueChange={v => setRrForm(f => ({ ...f, employee_type: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['PERMANENT','CONTRACT','INTERNSHIP','TEMPORARY'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>Headcount</Label>
                <Input type="number" min={1} value={rrForm.requested_headcount} onChange={e => setRrForm(f => ({ ...f, requested_headcount: Number(e.target.value) }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Priority</Label>
                <Select value={rrForm.priority_level} onValueChange={v => setRrForm(f => ({ ...f, priority_level: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>{['LOW','MEDIUM','HIGH','CRITICAL'].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Expiry Date</Label>
                <Input type="date" value={rrForm.expiry_date} onChange={e => setRrForm(f => ({ ...f, expiry_date: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Work Location</Label>
              <Input value={rrForm.work_location} onChange={e => setRrForm(f => ({ ...f, work_location: e.target.value }))} className="h-9" placeholder="e.g. Addis Ababa HQ" />
            </div>
            <div className="space-y-1.5">
              <Label>Justification</Label>
              <Textarea rows={3} value={rrForm.justification} onChange={e => setRrForm(f => ({ ...f, justification: e.target.value }))} placeholder="Business justification…" />
            </div>
            <div className="space-y-1.5">
              <Label>Estimated Budget (ETB)</Label>
              <Input type="number" value={rrForm.budget_estimated} onChange={e => setRrForm(f => ({ ...f, budget_estimated: e.target.value }))} className="h-9" />
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setRrOpen(false)}>Cancel</Button>
              <Button onClick={handleCreateRR} disabled={saving}>{saving ? 'Saving…' : 'Create Request'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── New Vacancy Dialog ── */}
      <Dialog open={vacOpen} onOpenChange={o => { setVacOpen(o); if (!o) setVacForm({ ...EMPTY_VAC_FORM, department_id: '', recruitment_request_id: '' }); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>New Job Vacancy</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label>Job Title *</Label>
              <Input value={vacForm.title} onChange={e => setVacForm(f => ({ ...f, title: e.target.value }))} className="h-9" placeholder="e.g. Senior Software Engineer" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Department</Label>
                <Select value={vacForm.department_id} onValueChange={v => setVacForm(f => ({ ...f, department_id: v }))}>
                  <SelectTrigger className="h-9"><SelectValue placeholder="Select…" /></SelectTrigger>
                  <SelectContent>{departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Source Request</Label>
                <Select value={vacForm.recruitment_request_id} onValueChange={v => setVacForm(f => ({ ...f, recruitment_request_id: v }))}>
                  <SelectTrigger className="h-9"><SelectValue placeholder="Optional…" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {requests.filter(r => r.request_status === 'APPROVED').map(r => <SelectItem key={r.recruitment_request_id} value={r.recruitment_request_id}>{r.request_number}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>Employment Type *</Label>
                <Select value={vacForm.employment_type} onValueChange={v => setVacForm(f => ({ ...f, employment_type: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>{['PERMANENT','CONTRACT','INTERNSHIP','TEMPORARY'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Posting Type</Label>
                <Select value={vacForm.vacancy_type} onValueChange={v => setVacForm(f => ({ ...f, vacancy_type: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>{['INTERNAL','EXTERNAL','BOTH'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Quota</Label>
                <Input type="number" min={1} value={vacForm.vacancy_quota} onChange={e => setVacForm(f => ({ ...f, vacancy_quota: Number(e.target.value) }))} className="h-9" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>Min Salary (ETB)</Label>
                <Input type="number" value={vacForm.salary_min} onChange={e => setVacForm(f => ({ ...f, salary_min: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Max Salary (ETB)</Label>
                <Input type="number" value={vacForm.salary_max} onChange={e => setVacForm(f => ({ ...f, salary_max: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Experience (yrs)</Label>
                <Input type="number" value={vacForm.required_experience_years} onChange={e => setVacForm(f => ({ ...f, required_experience_years: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Qualification</Label>
                <Input value={vacForm.required_qualification} onChange={e => setVacForm(f => ({ ...f, required_qualification: e.target.value }))} className="h-9" placeholder="e.g. BSc in CS" />
              </div>
              <div className="space-y-1.5">
                <Label>Application Deadline</Label>
                <Input type="date" value={vacForm.application_deadline} onChange={e => setVacForm(f => ({ ...f, application_deadline: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Required Skills</Label>
              <Input value={vacForm.required_skills} onChange={e => setVacForm(f => ({ ...f, required_skills: e.target.value }))} className="h-9" placeholder="e.g. React, Node.js, SQL" />
            </div>
            <div className="space-y-1.5">
              <Label>Job Description</Label>
              <Textarea rows={4} value={vacForm.job_description} onChange={e => setVacForm(f => ({ ...f, job_description: e.target.value }))} placeholder="Responsibilities and scope…" />
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setVacOpen(false)}>Cancel</Button>
              <Button onClick={handleCreateVacancy} disabled={saving}>{saving ? 'Saving…' : 'Create Vacancy'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Add Candidate Dialog ── */}
      <Dialog open={candOpen} onOpenChange={o => { setCandOpen(o); if (!o) setCandForm({ ...EMPTY_CAND_FORM }); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>Add Candidate</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>First Name *</Label>
                <Input value={candForm.first_name} onChange={e => setCandForm(f => ({ ...f, first_name: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Last Name</Label>
                <Input value={candForm.last_name} onChange={e => setCandForm(f => ({ ...f, last_name: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Email *</Label>
                <Input type="email" value={candForm.email} onChange={e => setCandForm(f => ({ ...f, email: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Phone</Label>
                <Input value={candForm.phone_number} onChange={e => setCandForm(f => ({ ...f, phone_number: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>Source</Label>
                <Select value={candForm.source_channel} onValueChange={v => setCandForm(f => ({ ...f, source_channel: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>{['LINKEDIN','JOB_BOARD','REFERRAL','CAREER_SITE','AGENCY','INTERNAL','OTHER'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Experience (yrs)</Label>
                <Input type="number" value={candForm.years_of_experience} onChange={e => setCandForm(f => ({ ...f, years_of_experience: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Expected Salary</Label>
                <Input type="number" value={candForm.expected_salary} onChange={e => setCandForm(f => ({ ...f, expected_salary: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Current Company</Label>
              <Input value={candForm.current_company} onChange={e => setCandForm(f => ({ ...f, current_company: e.target.value }))} className="h-9" />
            </div>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" checked={candForm.is_consent_given} onChange={e => setCandForm(f => ({ ...f, is_consent_given: e.target.checked }))} className="h-4 w-4 accent-primary rounded" />
              Candidate has given data processing consent
            </label>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setCandOpen(false)}>Cancel</Button>
              <Button onClick={handleCreateCandidate} disabled={saving}>{saving ? 'Saving…' : 'Add Candidate'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-REC-017 – Cost Per Hire Tracker
   ───────────────────────────────────────────────────────────────────────── */
type CostRow = { cost_id?: string; vacancy_id?: string; job_title?: string; cost_category: string; amount: number; cost_date?: string; notes?: string };

function RecruitmentCostTab() {
  const [rows, setRows] = useState<CostRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ vacancy_id: '', job_title: '', cost_category: 'ADVERTISING', amount: '', cost_date: '', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('recruitment_costs').select('*').order('cost_date', { ascending: false }).limit(200);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.amount) { toast.error('Amount is required'); return; }
    setSaving(true);
    const { error } = await sb.from('recruitment_costs').insert({ vacancy_id: form.vacancy_id || null, job_title: form.job_title || null, cost_category: form.cost_category, amount: Number(form.amount), cost_date: form.cost_date || new Date().toISOString().slice(0, 10), notes: form.notes || null });
    if (error) toast.error(error.message); else { toast.success('Cost recorded'); setOpen(false); load(); }
    setSaving(false);
  };

  const totalCost = rows.reduce((s, r) => s + (r.amount || 0), 0);
  const byCategory: Record<string, number> = {};
  for (const r of rows) byCategory[r.cost_category] = (byCategory[r.cost_category] || 0) + r.amount;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="h-full"><CardContent className="pt-4 pb-4">
          <p className="text-2xl font-bold text-primary">{rows.length}</p>
          <p className="text-xs text-muted-foreground mt-1">Total Entries</p>
        </CardContent></Card>
        <Card className="h-full"><CardContent className="pt-4 pb-4">
          <p className="text-2xl font-bold text-foreground">{totalCost.toLocaleString()}</p>
          <p className="text-xs text-muted-foreground mt-1">Total Cost (ETB)</p>
        </CardContent></Card>
        {Object.entries(byCategory).slice(0, 2).map(([cat, amt]) => (
          <Card key={cat} className="h-full"><CardContent className="pt-4 pb-4">
            <p className="text-xl font-bold">{amt.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground mt-1">{cat}</p>
          </CardContent></Card>
        ))}
      </div>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2"><DollarSign className="h-4 w-4" />Cost Per Hire (FR-REC-017)</CardTitle>
            <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add Cost</Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? <Skeleton className="h-24 bg-muted" /> : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Job Title</TableHead>
                  <TableHead className="whitespace-nowrap">Category</TableHead>
                  <TableHead className="whitespace-nowrap">Amount (ETB)</TableHead>
                  <TableHead className="whitespace-nowrap">Date</TableHead>
                  <TableHead className="whitespace-nowrap">Notes</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {rows.length === 0 && <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6 text-sm">No costs recorded yet</TableCell></TableRow>}
                  {rows.map((r, i) => (
                    <TableRow key={r.cost_id || i}>
                      <TableCell className="whitespace-nowrap font-medium">{r.job_title || '—'}</TableCell>
                      <TableCell><Badge variant="outline">{r.cost_category}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap">{r.amount.toLocaleString()}</TableCell>
                      <TableCell className="whitespace-nowrap">{r.cost_date || '—'}</TableCell>
                      <TableCell className="max-w-[200px] truncate text-sm text-muted-foreground">{r.notes || '—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Record Recruitment Cost</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Job Title</Label><Input value={form.job_title} onChange={e => setForm(p => ({ ...p, job_title: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Category</Label>
                <Select value={form.cost_category} onValueChange={v => setForm(p => ({ ...p, cost_category: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ADVERTISING">Advertising</SelectItem>
                    <SelectItem value="AGENCY_FEE">Agency Fee</SelectItem>
                    <SelectItem value="ASSESSMENT">Assessment</SelectItem>
                    <SelectItem value="ONBOARDING">Onboarding</SelectItem>
                    <SelectItem value="TRAVEL">Travel</SelectItem>
                    <SelectItem value="OTHER">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Amount (ETB) *</Label><Input type="number" value={form.amount} onChange={e => setForm(p => ({ ...p, amount: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Date</Label><Input type="date" value={form.cost_date} onChange={e => setForm(p => ({ ...p, cost_date: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Notes</Label><Textarea rows={2} value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Save'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-REC-018 – Talent Pool
   ───────────────────────────────────────────────────────────────────────── */
type TalentRow = { talent_id?: string; full_name: string; email?: string; phone?: string; position_interest?: string; skills?: string; source?: string; status?: string; added_date?: string };

function TalentPoolTab() {
  const [rows, setRows] = useState<TalentRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ full_name: '', email: '', phone: '', position_interest: '', skills: '', source: 'REFERRAL' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('talent_pool').select('*').order('added_date', { ascending: false }).limit(200);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = rows.filter(r => !search || r.full_name.toLowerCase().includes(search.toLowerCase()) || (r.position_interest || '').toLowerCase().includes(search.toLowerCase()) || (r.skills || '').toLowerCase().includes(search.toLowerCase()));

  const save = async () => {
    if (!form.full_name.trim()) { toast.error('Full name required'); return; }
    setSaving(true);
    const { error } = await sb.from('talent_pool').insert({ full_name: form.full_name, email: form.email || null, phone: form.phone || null, position_interest: form.position_interest || null, skills: form.skills || null, source: form.source, status: 'ACTIVE', added_date: new Date().toISOString().slice(0, 10) });
    if (error) toast.error(error.message); else { toast.success('Added to talent pool'); setOpen(false); load(); }
    setSaving(false);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><UserSearch className="h-4 w-4" />Talent Pool (FR-REC-018)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add Candidate</Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input className="pl-8" placeholder="Search name, position, skills…" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <span className="text-sm text-muted-foreground">{filtered.length} candidates</span>
        </div>
        {loading ? <Skeleton className="h-32 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Name</TableHead>
                <TableHead className="whitespace-nowrap">Email</TableHead>
                <TableHead className="whitespace-nowrap">Position Interest</TableHead>
                <TableHead className="whitespace-nowrap">Skills</TableHead>
                <TableHead className="whitespace-nowrap">Source</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {filtered.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-6 text-sm">No talent pool candidates</TableCell></TableRow>}
                {filtered.map((r, i) => (
                  <TableRow key={r.talent_id || i}>
                    <TableCell className="whitespace-nowrap font-medium">{r.full_name}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.email || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.position_interest || '—'}</TableCell>
                    <TableCell className="max-w-[180px] truncate text-sm">{r.skills || '—'}</TableCell>
                    <TableCell><Badge variant="outline">{r.source || '—'}</Badge></TableCell>
                    <TableCell><Badge className={r.status === 'ACTIVE' ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}>{r.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add to Talent Pool</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2 space-y-1.5"><Label>Full Name *</Label><Input value={form.full_name} onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Email</Label><Input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Phone</Label><Input value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Position Interest</Label><Input value={form.position_interest} onChange={e => setForm(p => ({ ...p, position_interest: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Source</Label>
                <Select value={form.source} onValueChange={v => setForm(p => ({ ...p, source: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="REFERRAL">Referral</SelectItem>
                    <SelectItem value="JOB_PORTAL">Job Portal</SelectItem>
                    <SelectItem value="UNIVERSITY">University</SelectItem>
                    <SelectItem value="WALK_IN">Walk-in</SelectItem>
                    <SelectItem value="LINKEDIN">LinkedIn</SelectItem>
                    <SelectItem value="OTHER">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5"><Label>Skills</Label><Textarea rows={2} placeholder="Comma-separated skills" value={form.skills} onChange={e => setForm(p => ({ ...p, skills: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Add'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-REC-019/023 – Background Check
   ───────────────────────────────────────────────────────────────────────── */
type BgRow = { check_id?: string; candidate_id?: string; candidate_name?: string; check_type: string; vendor?: string; requested_date?: string; completed_date?: string; result?: string; status?: string };

function BackgroundCheckTab() {
  const [rows, setRows] = useState<BgRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ candidate_name: '', check_type: 'CRIMINAL', vendor: '', requested_date: '', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('background_checks').select('*').order('requested_date', { ascending: false }).limit(200);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.candidate_name.trim()) { toast.error('Candidate name required'); return; }
    setSaving(true);
    const { error } = await sb.from('background_checks').insert({ candidate_name: form.candidate_name, check_type: form.check_type, vendor: form.vendor || null, requested_date: form.requested_date || new Date().toISOString().slice(0, 10), status: 'PENDING' });
    if (error) toast.error(error.message); else { toast.success('Background check requested'); setOpen(false); load(); }
    setSaving(false);
  };

  const STATUS_BADGE: Record<string, string> = { PENDING: 'bg-yellow-100 text-yellow-800', IN_PROGRESS: 'bg-blue-100 text-blue-800', PASSED: 'bg-green-100 text-green-800', FAILED: 'bg-red-100 text-red-800' };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><ShieldCheck className="h-4 w-4" />Background Checks (FR-REC-019)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Request Check</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Candidate</TableHead>
                <TableHead className="whitespace-nowrap">Check Type</TableHead>
                <TableHead className="whitespace-nowrap">Vendor</TableHead>
                <TableHead className="whitespace-nowrap">Requested</TableHead>
                <TableHead className="whitespace-nowrap">Completed</TableHead>
                <TableHead className="whitespace-nowrap">Result</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-6 text-sm">No background checks yet</TableCell></TableRow>}
                {rows.map((r, i) => (
                  <TableRow key={r.check_id || i}>
                    <TableCell className="whitespace-nowrap font-medium">{r.candidate_name || '—'}</TableCell>
                    <TableCell><Badge variant="outline">{r.check_type}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap">{r.vendor || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.requested_date || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.completed_date || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.result || '—'}</TableCell>
                    <TableCell><Badge className={STATUS_BADGE[r.status || 'PENDING'] || 'bg-muted'}>{r.status || 'PENDING'}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Request Background Check</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Candidate Name *</Label><Input value={form.candidate_name} onChange={e => setForm(p => ({ ...p, candidate_name: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Check Type</Label>
                <Select value={form.check_type} onValueChange={v => setForm(p => ({ ...p, check_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="CRIMINAL">Criminal</SelectItem>
                    <SelectItem value="EMPLOYMENT">Employment History</SelectItem>
                    <SelectItem value="EDUCATION">Education</SelectItem>
                    <SelectItem value="REFERENCE">Reference Check</SelectItem>
                    <SelectItem value="CREDIT">Credit</SelectItem>
                    <SelectItem value="DRUG_TEST">Drug Test</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Vendor</Label><Input value={form.vendor} onChange={e => setForm(p => ({ ...p, vendor: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Requested Date</Label><Input type="date" value={form.requested_date} onChange={e => setForm(p => ({ ...p, requested_date: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Request'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
