import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Plus, RefreshCw, Users, Search, Shield, AlertTriangle } from 'lucide-react';

const sb = _sb as any; // eslint-disable-line @typescript-eslint/no-explicit-any

type Candidate = {
  id: string; candidate_id: string; candidate_number: string;
  first_name: string; last_name: string; gender?: string;
  email: string; phone_number?: string; source_channel?: string;
  years_of_experience?: number; current_company?: string;
  expected_salary?: number; is_blacklisted: boolean;
  blacklist_reason?: string; is_consent_given: boolean;
  consent_timestamp?: string; created_at: string;
};
type BackgroundCheck = {
  id: string; background_check_id: string;
  application_id: string; check_type: string; check_status: string;
  vendor_name?: string; initiated_at?: string; completed_at?: string;
  result_summary?: string; notes?: string; created_at: string;
  application?: {
    application_number: string;
    candidate?: { first_name: string; last_name: string };
    vacancy?: { title: string };
  };
};
type Application = {
  application_id: string; application_number: string;
  candidate?: { first_name: string; last_name: string };
  vacancy?: { title: string };
};

const CHECK_STATUS_COLORS: Record<string, string> = {
  PENDING: 'bg-muted text-muted-foreground',
  IN_PROGRESS: 'bg-yellow-100 text-yellow-800',
  PASSED: 'bg-green-100 text-green-800',
  FAILED: 'bg-red-100 text-red-800',
  CANCELLED: 'bg-muted text-muted-foreground',
};

const EMPTY_BGC_FORM = { application_id: '', check_type: 'CRIMINAL', vendor_name: '', initiated_at: '', notes: '' };
const EMPTY_CAND_FORM = { first_name: '', last_name: '', gender: '', email: '', phone_number: '', source_channel: 'OTHER', years_of_experience: '', current_company: '', expected_salary: '', is_consent_given: true };

export function CandidatesPage() {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [bgChecks, setBgChecks] = useState<BackgroundCheck[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Candidate | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [bgcOpen, setBgcOpen] = useState(false);
  const [blacklistOpen, setBlacklistOpen] = useState<Candidate | null>(null);
  const [blacklistReason, setBlacklistReason] = useState('');
  const [saving, setSaving] = useState(false);
  const [candForm, setCandForm] = useState({ ...EMPTY_CAND_FORM });
  const [bgcForm, setBgcForm] = useState({ ...EMPTY_BGC_FORM });

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [candRes, bgcRes, appRes] = await Promise.all([
        sb.from('candidates').select('*').eq('is_deleted', false).order('created_at', { ascending: false }),
        sb.from('background_checks')
          .select('*, application:applications(application_number, candidate:candidates(first_name,last_name), vacancy:job_vacancies(title))')
          .eq('is_deleted', false).order('created_at', { ascending: false }),
        sb.from('applications')
          .select('application_id, application_number, candidate:candidates(first_name,last_name), vacancy:job_vacancies(title)')
          .eq('is_deleted', false).in('current_stage', ['OFFER','HIRED']).order('created_at', { ascending: false }).limit(200),
      ]);
      setCandidates(candRes.data ?? []);
      setBgChecks(bgcRes.data ?? []);
      setApplications(appRes.data ?? []);
    } catch { toast.error('Failed to load candidate data'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const handleAddCandidate = async () => {
    if (!candForm.first_name.trim() || !candForm.email.trim()) { toast.error('First name and email required'); return; }
    setSaving(true);
    try {
      const { error } = await sb.from('candidates').insert({
        first_name: candForm.first_name.trim(),
        last_name: candForm.last_name.trim() || '',
        gender: candForm.gender || null,
        email: candForm.email.trim(),
        phone_number: candForm.phone_number || null,
        source_channel: candForm.source_channel || null,
        years_of_experience: candForm.years_of_experience ? Number(candForm.years_of_experience) : null,
        current_company: candForm.current_company || null,
        expected_salary: candForm.expected_salary ? Number(candForm.expected_salary) : null,
        is_consent_given: candForm.is_consent_given,
        consent_timestamp: candForm.is_consent_given ? new Date().toISOString() : null,
      });
      if (error) throw error;
      toast.success('Candidate added');
      setAddOpen(false);
      setCandForm({ ...EMPTY_CAND_FORM });
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const handleCreateBgc = async () => {
    if (!bgcForm.application_id || bgcForm.application_id === 'none') { toast.error('Select an application'); return; }
    setSaving(true);
    try {
      const { error } = await sb.from('background_checks').insert({
        application_id: bgcForm.application_id,
        check_type: bgcForm.check_type,
        vendor_name: bgcForm.vendor_name || null,
        initiated_at: bgcForm.initiated_at ? new Date(bgcForm.initiated_at).toISOString() : null,
        notes: bgcForm.notes || null,
        check_status: 'PENDING',
      });
      if (error) throw error;
      toast.success('Background check initiated');
      setBgcOpen(false);
      setBgcForm({ ...EMPTY_BGC_FORM });
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const updateBgcStatus = async (id: string, status: string) => {
    try {
      const update: Record<string, unknown> = { check_status: status, updated_at: new Date().toISOString() };
      if (status === 'IN_PROGRESS') update.initiated_at = new Date().toISOString();
      if (status === 'PASSED' || status === 'FAILED' || status === 'CANCELLED') update.completed_at = new Date().toISOString();
      const { error } = await sb.from('background_checks').update(update).eq('id', id);
      if (error) throw error;
      toast.success(`Check ${status.toLowerCase()}`);
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
  };

  const handleBlacklist = async () => {
    if (!blacklistOpen) return;
    setSaving(true);
    try {
      const { error } = await sb.from('candidates').update({ is_blacklisted: true, blacklist_reason: blacklistReason || null, updated_at: new Date().toISOString() }).eq('id', blacklistOpen.id);
      if (error) throw error;
      toast.success('Candidate blacklisted');
      setBlacklistOpen(null);
      setBlacklistReason('');
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const handleUnblacklist = async (id: string) => {
    try {
      const { error } = await sb.from('candidates').update({ is_blacklisted: false, blacklist_reason: null, updated_at: new Date().toISOString() }).eq('id', id);
      if (error) throw error;
      toast.success('Candidate removed from blacklist');
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
  };

  const filteredCands = candidates.filter(c =>
    !search || `${c.first_name} ${c.last_name} ${c.email} ${c.candidate_number}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 md:p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Candidates</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage candidate profiles and background checks</p>
        </div>
        <Button variant="outline" size="sm" onClick={loadAll} className="gap-1.5">
          <RefreshCw className="h-4 w-4" />Refresh
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Candidates', value: candidates.length, color: 'text-primary', icon: Users },
          { label: 'Active', value: candidates.filter(c => !c.is_blacklisted && c.is_consent_given).length, color: 'text-green-600', icon: Users },
          { label: 'Blacklisted', value: candidates.filter(c => c.is_blacklisted).length, color: 'text-red-600', icon: AlertTriangle },
          { label: 'Bg Checks Pending', value: bgChecks.filter(b => b.check_status === 'PENDING').length, color: 'text-yellow-600', icon: Shield },
        ].map(s => (
          <Card key={s.label}><CardContent className="p-3 flex items-center gap-2">
            <s.icon className={`h-7 w-7 shrink-0 ${s.color}`} />
            <div><p className={`text-xl font-bold ${s.color}`}>{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
          </CardContent></Card>
        ))}
      </div>

      <Tabs defaultValue="candidates">
        <TabsList>
          <TabsTrigger value="candidates" className="gap-1.5"><Users className="h-3.5 w-3.5" />Candidates ({candidates.length})</TabsTrigger>
          <TabsTrigger value="bgchecks" className="gap-1.5"><Shield className="h-3.5 w-3.5" />Background Checks ({bgChecks.length})</TabsTrigger>
        </TabsList>

        {/* ── Candidates Tab ── */}
        <TabsContent value="candidates" className="mt-4 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="relative max-w-xs w-full">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
              <Input className="pl-9 h-9" placeholder="Search candidates…" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <Button size="sm" onClick={() => setAddOpen(true)} className="gap-1.5 shrink-0">
              <Plus className="h-4 w-4" />Add Candidate
            </Button>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Cand #</TableHead>
                  <TableHead className="whitespace-nowrap">Name</TableHead>
                  <TableHead className="whitespace-nowrap">Email</TableHead>
                  <TableHead className="whitespace-nowrap">Phone</TableHead>
                  <TableHead className="whitespace-nowrap">Source</TableHead>
                  <TableHead className="whitespace-nowrap text-center">Exp</TableHead>
                  <TableHead className="whitespace-nowrap">Company</TableHead>
                  <TableHead className="whitespace-nowrap">Consent</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {loading
                    ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 10 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                    : filteredCands.length === 0
                      ? <TableRow><TableCell colSpan={10} className="text-center py-10 text-muted-foreground"><Users className="h-8 w-8 mx-auto mb-2 opacity-40" />No candidates found</TableCell></TableRow>
                      : filteredCands.map(c => (
                        <TableRow key={c.id} className="cursor-pointer hover:bg-muted/30" onClick={() => setSelected(c)}>
                          <TableCell className="whitespace-nowrap font-mono text-xs">{c.candidate_number}</TableCell>
                          <TableCell className="whitespace-nowrap font-medium text-sm">{c.first_name} {c.last_name}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{c.email}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{c.phone_number ?? '—'}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{c.source_channel ?? '—'}</TableCell>
                          <TableCell className="whitespace-nowrap text-center text-sm">{c.years_of_experience ?? '—'}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm max-w-[120px] truncate" title={c.current_company}>{c.current_company ?? '—'}</TableCell>
                          <TableCell className="whitespace-nowrap">
                            {c.is_consent_given
                              ? <Badge className="bg-green-100 text-green-800 text-xs">Given</Badge>
                              : <Badge className="bg-red-100 text-red-800 text-xs">No</Badge>}
                          </TableCell>
                          <TableCell className="whitespace-nowrap">
                            {c.is_blacklisted
                              ? <Badge className="bg-red-100 text-red-800 text-xs">Blacklisted</Badge>
                              : <Badge className="bg-green-100 text-green-800 text-xs">Active</Badge>}
                          </TableCell>
                          <TableCell className="whitespace-nowrap" onClick={e => e.stopPropagation()}>
                            {c.is_blacklisted
                              ? <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => handleUnblacklist(c.id)}>Restore</Button>
                              : <Button size="sm" variant="outline" className="h-7 text-xs border-red-400 text-red-600" onClick={() => { setBlacklistOpen(c); setBlacklistReason(''); }}>Blacklist</Button>}
                          </TableCell>
                        </TableRow>
                      ))
                  }
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── Background Checks Tab ── */}
        <TabsContent value="bgchecks" className="mt-4 space-y-3">
          <div className="flex justify-end">
            <Button size="sm" onClick={() => setBgcOpen(true)} className="gap-1.5">
              <Plus className="h-4 w-4" />Initiate Check
            </Button>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Candidate</TableHead>
                  <TableHead className="whitespace-nowrap">Vacancy</TableHead>
                  <TableHead className="whitespace-nowrap">Check Type</TableHead>
                  <TableHead className="whitespace-nowrap">Vendor</TableHead>
                  <TableHead className="whitespace-nowrap">Initiated</TableHead>
                  <TableHead className="whitespace-nowrap">Completed</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {loading
                    ? Array.from({ length: 4 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 8 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                    : bgChecks.length === 0
                      ? <TableRow><TableCell colSpan={8} className="text-center py-10 text-muted-foreground"><Shield className="h-8 w-8 mx-auto mb-2 opacity-40" />No background checks</TableCell></TableRow>
                      : bgChecks.map(b => (
                        <TableRow key={b.id}>
                          <TableCell className="whitespace-nowrap font-medium text-sm">
                            {b.application?.candidate ? `${b.application.candidate.first_name} ${b.application.candidate.last_name}` : b.application?.application_number ?? '—'}
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-sm max-w-[140px] truncate" title={b.application?.vacancy?.title}>{b.application?.vacancy?.title ?? '—'}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{b.check_type}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{b.vendor_name ?? '—'}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{b.initiated_at ? new Date(b.initiated_at).toLocaleDateString() : '—'}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{b.completed_at ? new Date(b.completed_at).toLocaleDateString() : '—'}</TableCell>
                          <TableCell className="whitespace-nowrap">
                            <Badge className={CHECK_STATUS_COLORS[b.check_status] ?? 'bg-muted text-muted-foreground'}>{b.check_status}</Badge>
                          </TableCell>
                          <TableCell className="whitespace-nowrap">
                            <div className="flex gap-1">
                              {b.check_status === 'PENDING' && (
                                <Button size="sm" className="h-7 text-xs bg-yellow-500 hover:bg-yellow-600 text-white" onClick={() => updateBgcStatus(b.id, 'IN_PROGRESS')}>Start</Button>
                              )}
                              {b.check_status === 'IN_PROGRESS' && (
                                <>
                                  <Button size="sm" className="h-7 text-xs bg-green-600 hover:bg-green-700 text-white" onClick={() => updateBgcStatus(b.id, 'PASSED')}>Pass</Button>
                                  <Button size="sm" className="h-7 text-xs bg-red-600 hover:bg-red-700 text-white" onClick={() => updateBgcStatus(b.id, 'FAILED')}>Fail</Button>
                                </>
                              )}
                              {['PENDING','IN_PROGRESS'].includes(b.check_status) && (
                                <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => updateBgcStatus(b.id, 'CANCELLED')}>Cancel</Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                  }
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Candidate Detail Dialog */}
      <Dialog open={!!selected} onOpenChange={o => { if (!o) setSelected(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>Candidate Profile</DialogTitle></DialogHeader>
          {selected && (
            <div className="space-y-4 mt-2">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-lg shrink-0">
                  {selected.first_name[0]}{selected.last_name[0] || ''}
                </div>
                <div>
                  <p className="font-semibold text-lg">{selected.first_name} {selected.last_name}</p>
                  <p className="text-sm text-muted-foreground font-mono">{selected.candidate_number}</p>
                </div>
                <div className="ml-auto">
                  {selected.is_blacklisted
                    ? <Badge className="bg-red-100 text-red-800">Blacklisted</Badge>
                    : <Badge className="bg-green-100 text-green-800">Active</Badge>}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm">
                {[
                  { label: 'Email', value: selected.email },
                  { label: 'Phone', value: selected.phone_number },
                  { label: 'Gender', value: selected.gender },
                  { label: 'Source', value: selected.source_channel },
                  { label: 'Experience', value: selected.years_of_experience != null ? `${selected.years_of_experience} yrs` : null },
                  { label: 'Current Company', value: selected.current_company },
                  { label: 'Expected Salary', value: selected.expected_salary != null ? selected.expected_salary.toLocaleString() + ' ETB' : null },
                  { label: 'Consent Given', value: selected.is_consent_given ? 'Yes' : 'No' },
                  { label: 'Added On', value: new Date(selected.created_at).toLocaleDateString() },
                ].filter(f => f.value).map(f => (
                  <div key={f.label}>
                    <p className="text-xs text-muted-foreground">{f.label}</p>
                    <p className="font-medium">{f.value}</p>
                  </div>
                ))}
              </div>
              {selected.is_blacklisted && selected.blacklist_reason && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-sm">
                  <p className="font-medium text-red-800 mb-1">Blacklist Reason</p>
                  <p className="text-red-700">{selected.blacklist_reason}</p>
                </div>
              )}
              <div className="flex justify-end gap-2 pt-1">
                <Button variant="outline" onClick={() => setSelected(null)}>Close</Button>
                {!selected.is_blacklisted && (
                  <Button className="bg-red-600 hover:bg-red-700 text-white" onClick={() => { setBlacklistOpen(selected); setSelected(null); setBlacklistReason(''); }}>
                    Blacklist
                  </Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Add Candidate Dialog */}
      <Dialog open={addOpen} onOpenChange={o => { setAddOpen(o); if (!o) setCandForm({ ...EMPTY_CAND_FORM }); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>Add Candidate</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>First Name *</Label>
                <Input value={candForm.first_name} onChange={e => setCandForm(f => ({ ...f, first_name: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Last Name</Label>
                <Input value={candForm.last_name} onChange={e => setCandForm(f => ({ ...f, last_name: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Email *</Label>
                <Input type="email" value={candForm.email} onChange={e => setCandForm(f => ({ ...f, email: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Phone</Label>
                <Input value={candForm.phone_number} onChange={e => setCandForm(f => ({ ...f, phone_number: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>Gender</Label>
                <Select value={candForm.gender} onValueChange={v => setCandForm(f => ({ ...f, gender: v }))}>
                  <SelectTrigger className="h-9"><SelectValue placeholder="Any" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="MALE">Male</SelectItem>
                    <SelectItem value="FEMALE">Female</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Source</Label>
                <Select value={candForm.source_channel} onValueChange={v => setCandForm(f => ({ ...f, source_channel: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['LINKEDIN','JOB_BOARD','REFERRAL','CAREER_SITE','AGENCY','INTERNAL','OTHER'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Experience (yrs)</Label>
                <Input type="number" value={candForm.years_of_experience} onChange={e => setCandForm(f => ({ ...f, years_of_experience: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Current Company</Label>
                <Input value={candForm.current_company} onChange={e => setCandForm(f => ({ ...f, current_company: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Expected Salary (ETB)</Label>
                <Input type="number" value={candForm.expected_salary} onChange={e => setCandForm(f => ({ ...f, expected_salary: e.target.value }))} className="h-9" />
              </div>
            </div>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" checked={candForm.is_consent_given} onChange={e => setCandForm(f => ({ ...f, is_consent_given: e.target.checked }))} className="h-4 w-4 accent-primary rounded" />
              Candidate has given data processing consent
            </label>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
              <Button onClick={handleAddCandidate} disabled={saving}>{saving ? 'Saving…' : 'Add Candidate'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Initiate Background Check Dialog */}
      <Dialog open={bgcOpen} onOpenChange={o => { setBgcOpen(o); if (!o) setBgcForm({ ...EMPTY_BGC_FORM }); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Initiate Background Check</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label>Application *</Label>
              <Select value={bgcForm.application_id} onValueChange={v => setBgcForm(f => ({ ...f, application_id: v }))}>
                <SelectTrigger className="h-9"><SelectValue placeholder="Select application…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Select —</SelectItem>
                  {applications.map(a => (
                    <SelectItem key={a.application_id} value={a.application_id}>
                      {a.candidate ? `${a.candidate.first_name} ${a.candidate.last_name}` : a.application_number}
                      {a.vacancy ? ` — ${a.vacancy.title}` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Check Type</Label>
                <Select value={bgcForm.check_type} onValueChange={v => setBgcForm(f => ({ ...f, check_type: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['CRIMINAL','EDUCATION','EMPLOYMENT','REFERENCE','CREDIT','MEDICAL','OTHER'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Vendor Name</Label>
                <Input value={bgcForm.vendor_name} onChange={e => setBgcForm(f => ({ ...f, vendor_name: e.target.value }))} className="h-9" placeholder="Optional" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Initiation Date</Label>
              <Input type="date" value={bgcForm.initiated_at} onChange={e => setBgcForm(f => ({ ...f, initiated_at: e.target.value }))} className="h-9" />
            </div>
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Textarea rows={3} value={bgcForm.notes} onChange={e => setBgcForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setBgcOpen(false)}>Cancel</Button>
              <Button onClick={handleCreateBgc} disabled={saving}>{saving ? 'Saving…' : 'Initiate Check'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Blacklist Dialog */}
      <Dialog open={!!blacklistOpen} onOpenChange={o => { if (!o) setBlacklistOpen(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle>Blacklist Candidate</DialogTitle></DialogHeader>
          {blacklistOpen && (
            <div className="space-y-4 mt-2">
              <p className="text-sm text-muted-foreground">
                Blacklisting <span className="font-semibold text-foreground">{blacklistOpen.first_name} {blacklistOpen.last_name}</span>. This will prevent future applications.
              </p>
              <div className="space-y-1.5">
                <Label>Reason</Label>
                <Textarea rows={3} value={blacklistReason} onChange={e => setBlacklistReason(e.target.value)} placeholder="Reason for blacklisting…" />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setBlacklistOpen(null)}>Cancel</Button>
                <Button className="bg-red-600 hover:bg-red-700 text-white" onClick={handleBlacklist} disabled={saving}>{saving ? 'Saving…' : 'Blacklist'}</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
