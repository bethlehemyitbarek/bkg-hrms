import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Plus, RefreshCw, CalendarDays, Users, Search, ChevronDown, ChevronUp } from 'lucide-react';

const sb = _sb as any; // eslint-disable-line @typescript-eslint/no-explicit-any

type Interview = {
  id: string; interview_id: string; interview_round: number; interview_stage: string;
  mode?: string; scheduled_at?: string; meeting_link?: string; room_id?: string;
  final_score?: number; final_recommendation?: string; interview_status: string; created_at: string;
  application?: {
    application_number: string;
    candidate?: { first_name: string; last_name: string; email: string };
    vacancy?: { title: string };
  };
};
type PanelMember = {
  id: string; panel_member_id: string; panel_role: string; attendance_status: string;
  overall_score?: number; recommendation?: string; comments?: string; submitted_at?: string;
  employee?: { first_name: string; last_name: string; employee_no?: string };
};
type Application = {
  application_id: string; application_number: string;
  candidate?: { first_name: string; last_name: string };
};
type Employee = { id: string; first_name: string; last_name: string; employee_no?: string };

const IV_STATUS_COLORS: Record<string, string> = {
  SCHEDULED: 'bg-blue-100 text-blue-800',
  COMPLETED: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-muted text-muted-foreground',
};
const REC_COLORS: Record<string, string> = {
  STRONG_HIRE: 'bg-green-100 text-green-800',
  HIRE: 'bg-teal-100 text-teal-800',
  HOLD: 'bg-yellow-100 text-yellow-800',
  REJECT: 'bg-red-100 text-red-800',
};

const EMPTY_IV = { application_id: '', interview_round: 1, interview_stage: 'HR', mode: 'ONSITE', scheduled_at: '', meeting_link: '', room_id: '' };
const EMPTY_PANEL = { employee_id: '', panel_role: 'MEMBER', overall_score: '', recommendation: 'HIRE', comments: '' };

export function InterviewsPage() {
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [ivOpen, setIvOpen] = useState(false);
  const [panelOpen, setPanelOpen] = useState<Interview | null>(null);
  const [panelMembers, setPanelMembers] = useState<PanelMember[]>([]);
  const [expandedIv, setExpandedIv] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [ivForm, setIvForm] = useState({ ...EMPTY_IV });
  const [panelForm, setPanelForm] = useState({ ...EMPTY_PANEL });

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [ivRes, appRes, empRes] = await Promise.all([
        sb.from('interviews').select('*, application:applications(application_number, candidate:candidates(first_name,last_name,email))').eq('is_deleted', false).order('created_at', { ascending: false }),
        sb.from('applications').select('application_id, application_number, candidate:candidates(first_name, last_name)').eq('is_deleted', false).order('created_at', { ascending: false }).limit(200),
        sb.from('employees').select('id, first_name, last_name, employee_no').eq('is_active', true).order('first_name').limit(200),
      ]);
      setInterviews(ivRes.data ?? []);
      setApplications(appRes.data ?? []);
      setEmployees(empRes.data ?? []);
    } catch { toast.error('Failed to load interview data'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const loadPanelMembers = async (interviewId: string) => {
    try {
      const { data } = await sb.from('interview_panel_members')
        .select('*, employee:employees(first_name, last_name, employee_no)')
        .eq('interview_id', interviewId).eq('is_deleted', false).order('created_at');
      setPanelMembers(data ?? []);
    } catch { toast.error('Failed to load panel'); }
  };

  const handleCreateInterview = async () => {
    if (!ivForm.application_id || ivForm.application_id === 'none') { toast.error('Select an application'); return; }
    setSaving(true);
    try {
      const { error } = await sb.from('interviews').insert({
        application_id: ivForm.application_id,
        interview_round: Number(ivForm.interview_round),
        interview_stage: ivForm.interview_stage,
        mode: ivForm.mode || null,
        scheduled_at: ivForm.scheduled_at ? new Date(ivForm.scheduled_at).toISOString() : null,
        meeting_link: ivForm.meeting_link || null,
        room_id: ivForm.room_id || null,
      });
      if (error) throw error;
      toast.success('Interview scheduled');
      setIvOpen(false);
      setIvForm({ ...EMPTY_IV });
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const handleAddPanel = async () => {
    if (!panelOpen) return;
    if (!panelForm.employee_id || panelForm.employee_id === 'none') { toast.error('Select an employee'); return; }
    setSaving(true);
    try {
      const { error } = await sb.from('interview_panel_members').insert({
        interview_id: panelOpen.interview_id,
        employee_id: panelForm.employee_id,
        panel_role: panelForm.panel_role,
        overall_score: panelForm.overall_score ? Number(panelForm.overall_score) : null,
        recommendation: panelForm.recommendation || null,
        comments: panelForm.comments || null,
        submitted_at: panelForm.overall_score ? new Date().toISOString() : null,
      });
      if (error) throw error;
      toast.success('Panel member added');
      setPanelForm({ ...EMPTY_PANEL });
      loadPanelMembers(panelOpen.interview_id);
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const updateIvStatus = async (id: string, status: string, rec?: string) => {
    try {
      const update: Record<string, unknown> = { interview_status: status, updated_at: new Date().toISOString() };
      if (rec) update.final_recommendation = rec;
      const { error } = await sb.from('interviews').update(update).eq('id', id);
      if (error) throw error;
      toast.success(`Interview ${status.toLowerCase()}`);
      loadAll();
    } catch (e) { toast.error((e as Error).message); }
  };

  const filteredIv = interviews.filter(iv => {
    if (!search) return true;
    const name = iv.application?.candidate ? `${iv.application.candidate.first_name} ${iv.application.candidate.last_name}`.toLowerCase() : '';
    return name.includes(search.toLowerCase()) || iv.interview_stage.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="p-4 md:p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Interviews</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Schedule interviews and manage panel evaluations</p>
        </div>
        <Button variant="outline" size="sm" onClick={loadAll} className="gap-1.5"><RefreshCw className="h-4 w-4" />Refresh</Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Scheduled', value: interviews.filter(i => i.interview_status === 'SCHEDULED').length, color: 'text-blue-600' },
          { label: 'Completed', value: interviews.filter(i => i.interview_status === 'COMPLETED').length, color: 'text-green-600' },
          { label: 'Strong Hire', value: interviews.filter(i => i.final_recommendation === 'STRONG_HIRE').length, color: 'text-teal-600' },
          { label: 'Rejected', value: interviews.filter(i => i.final_recommendation === 'REJECT').length, color: 'text-red-600' },
        ].map(s => (
          <Card key={s.label}><CardContent className="p-3 text-center">
            <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </CardContent></Card>
        ))}
      </div>

      {/* Interview List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div className="relative max-w-xs w-full">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
            <Input className="pl-9 h-9" placeholder="Search interviews…" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <Button size="sm" onClick={() => setIvOpen(true)} className="gap-1.5 shrink-0"><Plus className="h-4 w-4" />Schedule Interview</Button>
        </div>
        <div className="border border-border rounded-lg overflow-hidden bg-card">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="w-8 pl-3"></TableHead>
                <TableHead className="whitespace-nowrap">Candidate</TableHead>
                <TableHead className="whitespace-nowrap">Stage</TableHead>
                <TableHead className="whitespace-nowrap text-center">Round</TableHead>
                <TableHead className="whitespace-nowrap">Mode</TableHead>
                <TableHead className="whitespace-nowrap">Scheduled</TableHead>
                <TableHead className="whitespace-nowrap">Recommendation</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Actions</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {loading ? Array.from({ length: 4 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 9 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                : filteredIv.length === 0 ? <TableRow><TableCell colSpan={9} className="text-center py-10 text-muted-foreground"><CalendarDays className="h-8 w-8 mx-auto mb-2 opacity-40" />No interviews found</TableCell></TableRow>
                : filteredIv.map(iv => (
                  <>
                    <TableRow key={iv.id} className={expandedIv === iv.interview_id ? 'bg-muted/20' : undefined}>
                      <TableCell className="pl-3">
                        <button className="p-0.5 rounded hover:bg-muted" onClick={async () => {
                          if (expandedIv === iv.interview_id) { setExpandedIv(null); return; }
                          setExpandedIv(iv.interview_id);
                          await loadPanelMembers(iv.interview_id);
                        }}>
                          {expandedIv === iv.interview_id ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
                        </button>
                      </TableCell>
                      <TableCell className="whitespace-nowrap font-medium text-sm">
                        {iv.application?.candidate ? `${iv.application.candidate.first_name} ${iv.application.candidate.last_name}` : iv.application?.application_number ?? '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{iv.interview_stage}</TableCell>
                      <TableCell className="whitespace-nowrap text-center text-sm">{iv.interview_round}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{iv.mode ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{iv.scheduled_at ? new Date(iv.scheduled_at).toLocaleString() : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        {iv.final_recommendation ? <Badge className={REC_COLORS[iv.final_recommendation] ?? 'bg-muted text-muted-foreground'}>{iv.final_recommendation}</Badge> : <span className="text-muted-foreground text-xs">—</span>}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={IV_STATUS_COLORS[iv.interview_status] ?? 'bg-muted text-muted-foreground'}>{iv.interview_status}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex gap-1">
                          {iv.interview_status === 'SCHEDULED' && (
                            <>
                              <Button size="sm" className="h-7 text-xs bg-green-600 hover:bg-green-700 text-white" onClick={() => updateIvStatus(iv.id, 'COMPLETED')}>Complete</Button>
                              <Button size="sm" variant="outline" className="h-7 text-xs border-red-400 text-red-600" onClick={() => updateIvStatus(iv.id, 'CANCELLED')}>Cancel</Button>
                            </>
                          )}
                          <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={async () => { setPanelOpen(iv); await loadPanelMembers(iv.interview_id); }}>
                            <Users className="h-3 w-3" />Panel
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                    {expandedIv === iv.interview_id && (
                      <TableRow key={`${iv.id}-expanded`}>
                        <TableCell colSpan={9} className="bg-muted/10 px-8 py-3">
                          <p className="text-xs font-semibold text-muted-foreground mb-2">Panel Members</p>
                          {panelMembers.length === 0
                            ? <p className="text-xs text-muted-foreground">No panel members assigned</p>
                            : <div className="flex flex-wrap gap-3">
                              {panelMembers.map(p => (
                                <div key={p.panel_member_id} className="flex items-center gap-2 bg-background border border-border rounded-md px-3 py-1.5 text-xs">
                                  <span className="font-medium">{p.employee ? `${p.employee.first_name} ${p.employee.last_name}` : '—'}</span>
                                  <Badge className="text-xs py-0">{p.panel_role}</Badge>
                                  {p.overall_score != null && <span className="text-muted-foreground">Score: {p.overall_score}</span>}
                                  {p.recommendation && <Badge className={(REC_COLORS[p.recommendation] ?? 'bg-muted text-muted-foreground') + ' text-xs py-0'}>{p.recommendation}</Badge>}
                                </div>
                              ))}
                            </div>
                          }
                        </TableCell>
                      </TableRow>
                    )}
                  </>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      {/* Schedule Interview Dialog */}
      <Dialog open={ivOpen} onOpenChange={o => { setIvOpen(o); if (!o) setIvForm({ ...EMPTY_IV }); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Schedule Interview</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label>Application *</Label>
              <Select value={ivForm.application_id} onValueChange={v => setIvForm(f => ({ ...f, application_id: v }))}>
                <SelectTrigger className="h-9"><SelectValue placeholder="Select application…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Select —</SelectItem>
                  {applications.map(a => <SelectItem key={a.application_id} value={a.application_id}>{a.candidate ? `${a.candidate.first_name} ${a.candidate.last_name}` : a.application_number} — {a.application_number}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>Stage</Label>
                <Select value={ivForm.interview_stage} onValueChange={v => setIvForm(f => ({ ...f, interview_stage: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>{['TECHNICAL','HR','MANAGERIAL','EXECUTIVE'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Mode</Label>
                <Select value={ivForm.mode} onValueChange={v => setIvForm(f => ({ ...f, mode: v }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>{['ONLINE','ONSITE','HYBRID'].map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Round</Label>
                <Input type="number" min={1} value={ivForm.interview_round} onChange={e => setIvForm(f => ({ ...f, interview_round: Number(e.target.value) }))} className="h-9" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Date &amp; Time</Label>
                <Input type="datetime-local" value={ivForm.scheduled_at} onChange={e => setIvForm(f => ({ ...f, scheduled_at: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label>Room / Location</Label>
                <Input value={ivForm.room_id} onChange={e => setIvForm(f => ({ ...f, room_id: e.target.value }))} className="h-9" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Meeting Link</Label>
              <Input value={ivForm.meeting_link} onChange={e => setIvForm(f => ({ ...f, meeting_link: e.target.value }))} className="h-9" placeholder="https://…" />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIvOpen(false)}>Cancel</Button>
              <Button onClick={handleCreateInterview} disabled={saving}>{saving ? 'Saving…' : 'Schedule'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Panel Management Dialog */}
      <Dialog open={!!panelOpen} onOpenChange={o => { if (!o) { setPanelOpen(null); setPanelMembers([]); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Panel Members — {panelOpen?.interview_stage} Round {panelOpen?.interview_round}</DialogTitle>
          </DialogHeader>
          {panelOpen && (
            <Tabs defaultValue="members" className="mt-2">
              <TabsList><TabsTrigger value="members">Current Panel</TabsTrigger><TabsTrigger value="add">Add Member</TabsTrigger></TabsList>
              <TabsContent value="members" className="mt-3">
                {panelMembers.length === 0
                  ? <p className="text-sm text-muted-foreground text-center py-6">No panel members assigned</p>
                  : <div className="space-y-2">
                    {panelMembers.map(p => (
                      <div key={p.panel_member_id} className="flex items-start gap-3 p-3 rounded-lg border border-border bg-card">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium text-sm">{p.employee ? `${p.employee.first_name} ${p.employee.last_name}` : '—'}</span>
                            <Badge className="text-xs">{p.panel_role}</Badge>
                            <Badge className={(IV_STATUS_COLORS[p.attendance_status] ?? 'bg-muted text-muted-foreground') + ' text-xs'}>{p.attendance_status}</Badge>
                          </div>
                          {p.recommendation && <p className="text-xs mt-1"><span className="text-muted-foreground">Recommendation: </span><Badge className={(REC_COLORS[p.recommendation] ?? 'bg-muted text-muted-foreground') + ' text-xs'}>{p.recommendation}</Badge></p>}
                          {p.overall_score != null && <p className="text-xs text-muted-foreground mt-0.5">Score: {p.overall_score}</p>}
                          {p.comments && <p className="text-xs text-muted-foreground mt-0.5 truncate" title={p.comments}>{p.comments}</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                }
              </TabsContent>
              <TabsContent value="add" className="mt-3 space-y-4">
                <div className="space-y-1.5">
                  <Label>Employee *</Label>
                  <Select value={panelForm.employee_id} onValueChange={v => setPanelForm(f => ({ ...f, employee_id: v }))}>
                    <SelectTrigger className="h-9"><SelectValue placeholder="Select employee…" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">— Select —</SelectItem>
                      {employees.map(e => <SelectItem key={e.id} value={e.id}>{e.first_name} {e.last_name}{e.employee_no ? ` #${e.employee_no}` : ''}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Role</Label>
                    <Select value={panelForm.panel_role} onValueChange={v => setPanelForm(f => ({ ...f, panel_role: v }))}>
                      <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                      <SelectContent>{['CHAIR','MEMBER','OBSERVER'].map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Recommendation</Label>
                    <Select value={panelForm.recommendation} onValueChange={v => setPanelForm(f => ({ ...f, recommendation: v }))}>
                      <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                      <SelectContent>{['STRONG_HIRE','HIRE','HOLD','REJECT'].map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label>Overall Score (0–100)</Label>
                  <Input type="number" min={0} max={100} value={panelForm.overall_score} onChange={e => setPanelForm(f => ({ ...f, overall_score: e.target.value }))} className="h-9" />
                </div>
                <div className="space-y-1.5">
                  <Label>Comments</Label>
                  <Textarea rows={3} value={panelForm.comments} onChange={e => setPanelForm(f => ({ ...f, comments: e.target.value }))} />
                </div>
                <div className="flex justify-end gap-2">
                  <Button onClick={handleAddPanel} disabled={saving}>{saving ? 'Adding…' : 'Add to Panel'}</Button>
                </div>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
