import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const supabase = _sb as any;
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { RefreshCw, GitBranch } from 'lucide-react';

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  in_progress: 'bg-blue-100 text-blue-800',
  approved: 'bg-green-100 text-green-800',
  rejected: 'bg-red-100 text-red-800',
  completed: 'bg-teal-100 text-teal-800',
  cancelled: 'bg-muted text-muted-foreground',
};

export function WorkflowPage() {
  const [workflows, setWorkflows] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [statusFilter, setStatusFilter] = useState('all');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      let q = supabase.from('workflow_instances').select('*, initiated_by:employees!initiated_by_id(id,first_name,last_name)', { count: 'exact' });
      if (statusFilter !== 'all') q = q.eq('status', statusFilter);
      const { data, count, error } = await q.order('created_at', { ascending: false }).range(0, 29);
      if (error) throw error;
      setWorkflows((data || []) as Record<string, unknown>[]);
      setTotal(count || 0);
    } catch { toast.error('Failed to load workflows'); }
    finally { setLoading(false); }
  }, [statusFilter]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Workflow Instances</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} instances</p>
        </div>
        <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
      </div>
      <div className="flex gap-3">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead className="whitespace-nowrap">Workflow Type</TableHead>
              <TableHead className="whitespace-nowrap">Reference</TableHead>
              <TableHead className="whitespace-nowrap">Initiated By</TableHead>
              <TableHead className="whitespace-nowrap">Current Step</TableHead>
              <TableHead className="whitespace-nowrap">Status</TableHead>
              <TableHead className="whitespace-nowrap">Started</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {loading ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
              : workflows.length === 0 ? <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground"><GitBranch className="h-8 w-8 mx-auto mb-2 opacity-40" />No workflow instances found</TableCell></TableRow>
              : workflows.map((w, i) => {
                const emp = w.initiated_by as { first_name?: string; last_name?: string } | undefined;
                return (
                  <TableRow key={String(w.id ?? i)}>
                    <TableCell className="whitespace-nowrap text-sm capitalize">{String(w.workflow_type ?? '').replace(/_/g, ' ')}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-xs">{String(w.reference_id ?? '—').slice(0, 8)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{emp ? `${emp.first_name} ${emp.last_name}` : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{String(w.current_step ?? '—')}</TableCell>
                    <TableCell className="whitespace-nowrap"><span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${STATUS_COLORS[String(w.status ?? '')] ?? 'bg-muted text-muted-foreground'}`}>{String(w.status ?? '').replace('_', ' ')}</span></TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{w.created_at ? new Date(String(w.created_at)).toLocaleDateString() : '—'}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
