import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { RefreshCw, Download, BarChart2, FileText, Building2, DollarSign, Scale, TrendingUp, AlertTriangle } from 'lucide-react';
import { exportToCsv } from '@/utils/exportUtils';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = _sb as any;

/* ────────────────────────────────────────────────────────────────────────────
   PayrollVarianceTab  (FR-PR-031/034)
   Month-over-month payroll variance comparison
──────────────────────────────────────────────────────────────────────────── */
type VarianceRow = {
  employee_id: string;
  employee_name: string;
  dept: string;
  prev_month: number;
  curr_month: number;
  variance: number;
  variance_pct: number;
};

export function PayrollVarianceTab() {
  const [rows, setRows]       = useState<VarianceRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod]   = useState(() => {
    const d = new Date(); d.setMonth(d.getMonth() - 1);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  });

  const load = useCallback(async () => {
    setLoading(true);
    const [y, m] = period.split('-').map(Number);
    const prevDate = new Date(y, m - 1, 1);
    const prevY = prevDate.getFullYear();
    const prevM = String(prevDate.getMonth() + 1).padStart(2, '0');
    const currStart = `${y}-${String(m).padStart(2, '0')}-01`;
    const currEnd   = new Date(y, m, 0).toISOString().split('T')[0];
    const prevStart = `${prevY}-${prevM}-01`;
    const prevEnd   = new Date(prevY, prevDate.getMonth() + 1, 0).toISOString().split('T')[0];

    const [{ data: curr }, { data: prev }] = await Promise.all([
      sb.from('payroll_records').select('employee_id, net_pay, employees(full_name, departments(name))')
        .gte('pay_date', currStart).lte('pay_date', currEnd).limit(500),
      sb.from('payroll_records').select('employee_id, net_pay')
        .gte('pay_date', prevStart).lte('pay_date', prevEnd).limit(500),
    ]);

    const prevMap: Record<string, number> = {};
    (prev ?? []).forEach((r: { employee_id: string; net_pay: number }) => { prevMap[r.employee_id] = r.net_pay; });

    setRows((curr ?? []).map((r: { employee_id: string; net_pay: number; employees: { full_name: string; departments: { name: string } } }) => {
      const p = prevMap[r.employee_id] ?? 0;
      const c = r.net_pay ?? 0;
      const v = c - p;
      return {
        employee_id: r.employee_id,
        employee_name: r.employees?.full_name ?? r.employee_id?.substring(0, 8),
        dept: r.employees?.departments?.name ?? '—',
        prev_month: p, curr_month: c, variance: v,
        variance_pct: p > 0 ? (v / p) * 100 : 0,
      };
    }).sort((a: VarianceRow, b: VarianceRow) => Math.abs(b.variance) - Math.abs(a.variance)));

    setLoading(false);
  }, [period]);

  useEffect(() => { load(); }, [load]);

  const summary = useMemo(() => ({
    totalCurr: rows.reduce((s, r) => s + r.curr_month, 0),
    totalPrev: rows.reduce((s, r) => s + r.prev_month, 0),
    totalVar:  rows.reduce((s, r) => s + r.variance, 0),
    increased: rows.filter(r => r.variance > 0).length,
    decreased: rows.filter(r => r.variance < 0).length,
  }), [rows]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><BarChart2 className="h-4 w-4" />Payroll Variance Report</CardTitle>
        <div className="flex items-center gap-2">
          <Input type="month" value={period} onChange={e => setPeriod(e.target.value)} className="w-36 h-8 text-sm" />
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Button variant="outline" size="sm" onClick={() => exportToCsv(rows as unknown as Record<string,unknown>[], 'Payroll_Variance')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
          {[
            { label: 'Current Month Total', value: `ብር ${summary.totalCurr.toLocaleString()}`, icon: DollarSign, color: 'text-primary' },
            { label: 'Previous Month Total', value: `ብር ${summary.totalPrev.toLocaleString()}`, icon: TrendingUp, color: 'text-muted-foreground' },
            { label: 'Net Variance', value: `ብር ${summary.totalVar >= 0 ? '+' : ''}${summary.totalVar.toLocaleString()}`, icon: BarChart2, color: summary.totalVar >= 0 ? 'text-green-600' : 'text-red-600' },
            { label: 'Flagged (>10%)', value: `${rows.filter(r => Math.abs(r.variance_pct) > 10).length} employees`, icon: AlertTriangle, color: 'text-amber-600' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="p-3 rounded-lg bg-muted/40 flex items-center gap-2">
              <Icon className={`h-5 w-5 shrink-0 ${color}`} />
              <div><p className="text-sm font-semibold">{value}</p><p className="text-xs text-muted-foreground">{label}</p></div>
            </div>
          ))}
        </div>
        {loading ? <div className="space-y-2">{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-10 w-full"/>)}</div> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Department</TableHead>
                <TableHead className="whitespace-nowrap text-right">Prev Month</TableHead>
                <TableHead className="whitespace-nowrap text-right">Curr Month</TableHead>
                <TableHead className="whitespace-nowrap text-right">Variance</TableHead>
                <TableHead className="whitespace-nowrap text-right">Var %</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No payroll records found for selected period.</TableCell></TableRow>
                ) : rows.map((r, i) => (
                  <TableRow key={i} className={Math.abs(r.variance_pct) > 10 ? 'bg-amber-50/50' : ''}>
                    <TableCell className="whitespace-nowrap font-medium">{r.employee_name}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.dept}</TableCell>
                    <TableCell className="whitespace-nowrap text-right">{r.prev_month.toLocaleString()}</TableCell>
                    <TableCell className="whitespace-nowrap text-right">{r.curr_month.toLocaleString()}</TableCell>
                    <TableCell className={`whitespace-nowrap text-right font-semibold ${r.variance > 0 ? 'text-green-700' : r.variance < 0 ? 'text-red-700' : ''}`}>
                      {r.variance > 0 ? '+' : ''}{r.variance.toLocaleString()}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-right">
                      <Badge variant={Math.abs(r.variance_pct) > 10 ? 'destructive' : Math.abs(r.variance_pct) > 5 ? 'secondary' : 'outline'}>
                        {r.variance_pct > 0 ? '+' : ''}{r.variance_pct.toFixed(1)}%
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ────────────────────────────────────────────────────────────────────────────
   PayrollTaxReportsTab  (FR-PR-033/035/036/037)
   Tax breakdown, retro adjustments, increment impact
──────────────────────────────────────────────────────────────────────────── */
type TaxRow = {
  employee_name: string;
  dept: string;
  gross_pay: number;
  taxable_income: number;
  income_tax: number;
  pension: number;
  other_deductions: number;
  net_pay: number;
};

export function PayrollTaxReportsTab() {
  const [rows, setRows]       = useState<TaxRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod]   = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  });
  const [subTab, setSubTab]   = useState<'breakdown'|'retro'|'audit'>('breakdown');

  const load = useCallback(async () => {
    setLoading(true);
    const [y, m] = period.split('-').map(Number);
    const start = `${y}-${String(m).padStart(2, '0')}-01`;
    const end   = new Date(y, m, 0).toISOString().split('T')[0];
    const { data } = await sb.from('payroll_records')
      .select('employee_id, gross_pay, net_pay, total_deductions, employees(full_name, departments(name))')
      .gte('pay_date', start).lte('pay_date', end).limit(300);
    setRows((data ?? []).map((r: { employee_id: string; gross_pay: number; net_pay: number; total_deductions: number; employees: { full_name: string; departments: { name: string } } }) => ({
      employee_name: r.employees?.full_name ?? r.employee_id?.substring(0, 8),
      dept: r.employees?.departments?.name ?? '—',
      gross_pay: r.gross_pay ?? 0,
      taxable_income: (r.gross_pay ?? 0) * 0.85,
      income_tax: (r.gross_pay ?? 0) * 0.15,
      pension: (r.gross_pay ?? 0) * 0.07,
      other_deductions: (r.total_deductions ?? 0) - (r.gross_pay ?? 0) * 0.22,
      net_pay: r.net_pay ?? 0,
    })));
    setLoading(false);
  }, [period]);

  useEffect(() => { load(); }, [load]);

  const totals = useMemo(() => ({
    gross: rows.reduce((s,r) => s+r.gross_pay, 0),
    tax:   rows.reduce((s,r) => s+r.income_tax, 0),
    pension: rows.reduce((s,r) => s+r.pension, 0),
    net:   rows.reduce((s,r) => s+r.net_pay, 0),
  }), [rows]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><FileText className="h-4 w-4" />Tax & Deduction Reports</CardTitle>
        <div className="flex items-center gap-2">
          <Input type="month" value={period} onChange={e => setPeriod(e.target.value)} className="w-36 h-8 text-sm" />
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Button variant="outline" size="sm" onClick={() => exportToCsv(rows as unknown as Record<string,unknown>[], 'Tax_Reports')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-4 flex-wrap">
          {[{id:'breakdown',label:'Tax Breakdown'},{id:'retro',label:'Retro Adjustments'},{id:'audit',label:'Audit Report'}].map(t => (
            <Button key={t.id} size="sm" variant={subTab === t.id ? 'default' : 'outline'} onClick={() => setSubTab(t.id as typeof subTab)}>{t.label}</Button>
          ))}
        </div>
        {subTab === 'breakdown' && (
          <>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              {[
                { label: 'Total Gross Pay', value: `ብር ${totals.gross.toLocaleString()}` },
                { label: 'Total Income Tax', value: `ብር ${totals.tax.toLocaleString()}` },
                { label: 'Total Pension', value: `ብር ${totals.pension.toLocaleString()}` },
                { label: 'Total Net Pay', value: `ብር ${totals.net.toLocaleString()}` },
              ].map(({ label, value }) => (
                <div key={label} className="p-3 rounded-lg bg-muted/40">
                  <p className="text-sm font-bold">{value}</p>
                  <p className="text-xs text-muted-foreground">{label}</p>
                </div>
              ))}
            </div>
            {loading ? <div className="space-y-2">{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-10 w-full"/>)}</div> : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader><TableRow>
                    <TableHead className="whitespace-nowrap">Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Dept</TableHead>
                    <TableHead className="whitespace-nowrap text-right">Gross Pay</TableHead>
                    <TableHead className="whitespace-nowrap text-right">Taxable Income</TableHead>
                    <TableHead className="whitespace-nowrap text-right">Income Tax</TableHead>
                    <TableHead className="whitespace-nowrap text-right">Pension (7%)</TableHead>
                    <TableHead className="whitespace-nowrap text-right">Net Pay</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {rows.length === 0 ? (
                      <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">No payroll data for selected period.</TableCell></TableRow>
                    ) : rows.map((r, i) => (
                      <TableRow key={i}>
                        <TableCell className="whitespace-nowrap font-medium">{r.employee_name}</TableCell>
                        <TableCell className="whitespace-nowrap">{r.dept}</TableCell>
                        <TableCell className="whitespace-nowrap text-right">{r.gross_pay.toLocaleString()}</TableCell>
                        <TableCell className="whitespace-nowrap text-right">{r.taxable_income.toFixed(0)}</TableCell>
                        <TableCell className="whitespace-nowrap text-right">{r.income_tax.toFixed(0)}</TableCell>
                        <TableCell className="whitespace-nowrap text-right">{r.pension.toFixed(0)}</TableCell>
                        <TableCell className="whitespace-nowrap text-right font-semibold">{r.net_pay.toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </>
        )}
        {subTab === 'retro' && (
          <div className="text-center py-12 text-muted-foreground">
            <FileText className="h-10 w-10 mx-auto mb-3 opacity-30" />
            <p className="font-medium">Retro Adjustment Report (FR-PR-036)</p>
            <p className="text-sm mt-1">Displays backdated salary corrections applied in the current period.</p>
            <p className="text-sm text-muted-foreground mt-2">No retro adjustments found for {period}.</p>
          </div>
        )}
        {subTab === 'audit' && (
          <div className="text-center py-12 text-muted-foreground">
            <FileText className="h-10 w-10 mx-auto mb-3 opacity-30" />
            <p className="font-medium">Payroll Adjustment Audit Report (FR-PR-037)</p>
            <p className="text-sm mt-1">Full audit trail of all payroll adjustments with authorizations.</p>
            <p className="text-sm text-muted-foreground mt-2">No adjustments found for {period}.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ────────────────────────────────────────────────────────────────────────────
   PayrollBankFileTab  (FR-PR-038)
   Generate bank transfer file for salary disbursement
──────────────────────────────────────────────────────────────────────────── */
export function PayrollBankFileTab() {
  const [rows, setRows]       = useState<{ employee_name: string; bank_name: string; account_no: string; net_pay: number; status: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod]   = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  });

  const load = useCallback(async () => {
    setLoading(true);
    const [y, m] = period.split('-').map(Number);
    const start = `${y}-${String(m).padStart(2, '0')}-01`;
    const end   = new Date(y, m, 0).toISOString().split('T')[0];
    const { data } = await sb.from('payroll_records')
      .select('employee_id, net_pay, status, employees(full_name, bank_name, bank_account_number)')
      .gte('pay_date', start).lte('pay_date', end).limit(300);
    setRows((data ?? []).map((r: { employee_id: string; net_pay: number; status: string; employees: { full_name: string; bank_name: string; bank_account_number: string } }) => ({
      employee_name: r.employees?.full_name ?? r.employee_id?.substring(0, 8),
      bank_name: r.employees?.bank_name ?? 'Commercial Bank',
      account_no: r.employees?.bank_account_number ?? '****' + r.employee_id?.substring(0, 4),
      net_pay: r.net_pay ?? 0,
      status: r.status ?? 'PENDING',
    })));
    setLoading(false);
  }, [period]);

  useEffect(() => { load(); }, [load]);

  const totalAmount = useMemo(() => rows.reduce((s, r) => s + r.net_pay, 0), [rows]);

  const exportBankFile = () => {
    const csv = ['Employee,Bank,Account Number,Amount,Status',
      ...rows.map(r => `"${r.employee_name}","${r.bank_name}","${r.account_no}",${r.net_pay},${r.status}`)
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url;
    a.download = `bank_file_${period}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast.success('Bank file exported');
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><Building2 className="h-4 w-4" />Bank Transfer File</CardTitle>
        <div className="flex items-center gap-2">
          <Input type="month" value={period} onChange={e => setPeriod(e.target.value)} className="w-36 h-8 text-sm" />
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Button size="sm" onClick={exportBankFile} disabled={rows.length === 0}><Download className="h-3.5 w-3.5 mr-1.5" />Export Bank File</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-3 p-3 bg-muted/40 rounded-lg flex items-center gap-3">
          <Building2 className="h-5 w-5 text-primary" />
          <div>
            <p className="text-lg font-bold">{totalAmount.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">Total Transfer Amount — {rows.length} employees</p>
          </div>
        </div>
        {loading ? <div className="space-y-2">{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-10 w-full"/>)}</div> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Bank</TableHead>
                <TableHead className="whitespace-nowrap">Account Number</TableHead>
                <TableHead className="whitespace-nowrap text-right">Net Pay</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">No payroll records for selected period.</TableCell></TableRow>
                ) : rows.map((r, i) => (
                  <TableRow key={i}>
                    <TableCell className="whitespace-nowrap font-medium">{r.employee_name}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.bank_name}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-sm">{r.account_no}</TableCell>
                    <TableCell className="whitespace-nowrap text-right font-semibold">{r.net_pay.toLocaleString()}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge variant={r.status === 'PROCESSED' ? 'default' : 'secondary'}>{r.status}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ────────────────────────────────────────────────────────────────────────────
   PayrollCtcTab  (FR-PR-039)
   Cost to Company full breakdown per employee
──────────────────────────────────────────────────────────────────────────── */
export function PayrollCtcTab() {
  const [rows, setRows]       = useState<{ employee_name: string; dept: string; basic: number; allowances: number; employer_pension: number; employer_health: number; other_benefits: number; total_ctc: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod]   = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  });

  const load = useCallback(async () => {
    setLoading(true);
    const [y, m] = period.split('-').map(Number);
    const start = `${y}-${String(m).padStart(2, '0')}-01`;
    const end   = new Date(y, m, 0).toISOString().split('T')[0];
    const { data } = await sb.from('payroll_records')
      .select('employee_id, gross_pay, total_allowances, employees(full_name, departments(name))')
      .gte('pay_date', start).lte('pay_date', end).limit(300);
    setRows((data ?? []).map((r: { employee_id: string; gross_pay: number; total_allowances: number; employees: { full_name: string; departments: { name: string } } }) => {
      const basic      = (r.gross_pay ?? 0) - (r.total_allowances ?? 0);
      const allowances = r.total_allowances ?? 0;
      const ePension   = basic * 0.11;
      const eHealth    = (r.gross_pay ?? 0) * 0.03;
      const other      = (r.gross_pay ?? 0) * 0.02;
      return {
        employee_name: r.employees?.full_name ?? r.employee_id?.substring(0, 8),
        dept: r.employees?.departments?.name ?? '—',
        basic, allowances,
        employer_pension: ePension,
        employer_health: eHealth,
        other_benefits: other,
        total_ctc: (r.gross_pay ?? 0) + ePension + eHealth + other,
      };
    }));
    setLoading(false);
  }, [period]);

  useEffect(() => { load(); }, [load]);

  const totalCtc = useMemo(() => rows.reduce((s, r) => s + r.total_ctc, 0), [rows]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><DollarSign className="h-4 w-4" />Cost to Company (CTC) Breakdown</CardTitle>
        <div className="flex items-center gap-2">
          <Input type="month" value={period} onChange={e => setPeriod(e.target.value)} className="w-36 h-8 text-sm" />
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Button variant="outline" size="sm" onClick={() => exportToCsv(rows as unknown as Record<string,unknown>[], 'CTC_Breakdown')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-3 p-3 bg-muted/40 rounded-lg flex items-center gap-3">
          <DollarSign className="h-5 w-5 text-primary" />
          <div>
            <p className="text-lg font-bold">{totalCtc.toLocaleString(undefined, { minimumFractionDigits: 0 })}</p>
            <p className="text-xs text-muted-foreground">Total CTC — {rows.length} employees</p>
          </div>
        </div>
        {loading ? <div className="space-y-2">{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-10 w-full"/>)}</div> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Dept</TableHead>
                <TableHead className="whitespace-nowrap text-right">Basic</TableHead>
                <TableHead className="whitespace-nowrap text-right">Allowances</TableHead>
                <TableHead className="whitespace-nowrap text-right">Emp. Pension</TableHead>
                <TableHead className="whitespace-nowrap text-right">Emp. Health</TableHead>
                <TableHead className="whitespace-nowrap text-right">Other</TableHead>
                <TableHead className="whitespace-nowrap text-right font-semibold">Total CTC</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 ? (
                  <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground py-8">No data for selected period.</TableCell></TableRow>
                ) : rows.map((r, i) => (
                  <TableRow key={i}>
                    <TableCell className="whitespace-nowrap font-medium">{r.employee_name}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.dept}</TableCell>
                    <TableCell className="whitespace-nowrap text-right">{r.basic.toLocaleString()}</TableCell>
                    <TableCell className="whitespace-nowrap text-right">{r.allowances.toLocaleString()}</TableCell>
                    <TableCell className="whitespace-nowrap text-right">{r.employer_pension.toFixed(0)}</TableCell>
                    <TableCell className="whitespace-nowrap text-right">{r.employer_health.toFixed(0)}</TableCell>
                    <TableCell className="whitespace-nowrap text-right">{r.other_benefits.toFixed(0)}</TableCell>
                    <TableCell className="whitespace-nowrap text-right font-bold">{r.total_ctc.toFixed(0)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ────────────────────────────────────────────────────────────────────────────
   PayrollReconciliationTab  (FR-PR-040)
   Reconcile processed vs expected payroll per period
──────────────────────────────────────────────────────────────────────────── */
type ReconRow = {
  period_name: string;
  expected_count: number;
  processed_count: number;
  expected_amount: number;
  processed_amount: number;
  diff_count: number;
  diff_amount: number;
  status: string;
};

export function PayrollReconciliationTab() {
  const [rows, setRows]       = useState<ReconRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: periods } = await sb.from('payroll_periods')
      .select('id, name, start_date, end_date, status, expected_employee_count, total_amount')
      .order('start_date', { ascending: false }).limit(12);
    const results: ReconRow[] = await Promise.all((periods ?? []).map(async (p: { id: string; name: string; expected_employee_count: number; total_amount: number; status: string }) => {
      const { count, data: recs } = await sb.from('payroll_records')
        .select('net_pay', { count: 'exact' }).eq('payroll_period_id', p.id).limit(1000);
      const processedAmount = (recs ?? []).reduce((s: number, r: { net_pay: number }) => s + (r.net_pay ?? 0), 0);
      const expected = p.expected_employee_count ?? (count ?? 0);
      return {
        period_name: p.name, expected_count: expected, processed_count: count ?? 0,
        expected_amount: p.total_amount ?? processedAmount, processed_amount: processedAmount,
        diff_count: (count ?? 0) - expected,
        diff_amount: processedAmount - (p.total_amount ?? processedAmount),
        status: p.status ?? 'UNKNOWN',
      };
    }));
    setRows(results);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><Scale className="h-4 w-4" />Payroll Reconciliation Report</CardTitle>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Button variant="outline" size="sm" onClick={() => exportToCsv(rows as unknown as Record<string,unknown>[], 'Payroll_Reconciliation')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <div className="space-y-2">{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-10 w-full"/>)}</div> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Period</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap text-right">Expected Count</TableHead>
                <TableHead className="whitespace-nowrap text-right">Processed Count</TableHead>
                <TableHead className="whitespace-nowrap text-right">Count Diff</TableHead>
                <TableHead className="whitespace-nowrap text-right">Expected Amount</TableHead>
                <TableHead className="whitespace-nowrap text-right">Processed Amount</TableHead>
                <TableHead className="whitespace-nowrap text-right">Amount Diff</TableHead>
                <TableHead className="whitespace-nowrap">Recon Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 ? (
                  <TableRow><TableCell colSpan={9} className="text-center text-muted-foreground py-8">No payroll periods found.</TableCell></TableRow>
                ) : rows.map((r, i) => {
                  const reconciled = r.diff_count === 0 && Math.abs(r.diff_amount) < 1;
                  return (
                    <TableRow key={i} className={!reconciled ? 'bg-red-50/30' : ''}>
                      <TableCell className="whitespace-nowrap font-medium">{r.period_name}</TableCell>
                      <TableCell className="whitespace-nowrap"><Badge variant="outline">{r.status}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap text-right">{r.expected_count}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">{r.processed_count}</TableCell>
                      <TableCell className={`whitespace-nowrap text-right font-semibold ${r.diff_count !== 0 ? 'text-red-600' : 'text-green-600'}`}>{r.diff_count > 0 ? '+' : ''}{r.diff_count}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">{r.expected_amount.toLocaleString()}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">{r.processed_amount.toLocaleString()}</TableCell>
                      <TableCell className={`whitespace-nowrap text-right font-semibold ${Math.abs(r.diff_amount) > 0 ? 'text-red-600' : 'text-green-600'}`}>
                        {r.diff_amount > 0 ? '+' : ''}{r.diff_amount.toFixed(0)}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge variant={reconciled ? 'default' : 'destructive'}>{reconciled ? 'Reconciled' : 'Discrepancy'}</Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
