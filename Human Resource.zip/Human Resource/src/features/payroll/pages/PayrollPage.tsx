import { useState, useEffect, useCallback } from 'react';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { payrollService } from '@/services/payroll.service';
import type { PayrollPeriod, PayrollRecord } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { RefreshCw, Plus, Wallet, TrendingUp, FlaskConical, Landmark, Repeat2, Loader2, BarChart2, Scale, Building2, DollarSign, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/db/supabase';
import { PayrollVarianceTab, PayrollTaxReportsTab, PayrollBankFileTab, PayrollCtcTab, PayrollReconciliationTab } from '@/features/payroll/components/PayrollReportsTabs';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

const PERIOD_STATUS_COLORS: Record<string, string> = {
  draft: 'bg-muted text-muted-foreground',
  processing: 'bg-blue-100 text-blue-800',
  approved: 'bg-purple-100 text-purple-800',
  paid: 'bg-green-100 text-green-800',
  cancelled: 'bg-red-100 text-red-800',
};

const formatCurrency = (n: number) =>
  new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB', maximumFractionDigits: 0 }).format(n);

export function PayrollPage() {
  const [periods, setPeriods] = useState<PayrollPeriod[]>([]);
  const [records, setRecords] = useState<PayrollRecord[]>([]);
  const [loadingP, setLoadingP] = useState(true);
  const [loadingR, setLoadingR] = useState(false);
  const [totalP, setTotalP] = useState(0);
  const [totalR, setTotalR] = useState(0);
  const [selectedPeriodId, setSelectedPeriodId] = useState<string>('');
  const [summary, setSummary] = useState({ total_gross: 0, total_net: 0, total_deductions: 0 });

  const [periodDialog, setPeriodDialog] = useState(false);
  const [recordDialog, setRecordDialog] = useState(false);
  const [saving, setSaving] = useState(false);

  const [periodForm, setPeriodForm] = useState({
    period_code: '', name: '', start_date: '', end_date: '', payment_date: '',
    period_type: 'monthly', status: 'draft',
  });
  const [recordForm, setRecordForm] = useState({
    employee_id: '',
    basic_salary: '',
    overtime_pay: '',
    allowances: '',
    tax_deduction: '',
    social_security: '',
    provident_fund: '',
    other_deductions: '',
    notes: '',
  });

  const loadPeriods = useCallback(async () => {
    setLoadingP(true);
    try {
      const res = await payrollService.listPeriods({ page: 1, pageSize: 20 });
      setPeriods(res.data);
      setTotalP(res.total);
    } catch { toast.error('Failed to load payroll periods'); }
    finally { setLoadingP(false); }
  }, []);

  const loadRecords = useCallback(async () => {
    if (!selectedPeriodId) return;
    setLoadingR(true);
    try {
      const [res, sum] = await Promise.all([
        payrollService.listRecords({ period_id: selectedPeriodId, page: 1, pageSize: 50 }),
        payrollService.getPayrollSummary(selectedPeriodId),
      ]);
      setRecords(res.data);
      setTotalR(res.total);
      setSummary(sum);
    } catch { toast.error('Failed to load payroll records'); }
    finally { setLoadingR(false); }
  }, [selectedPeriodId]);

  useEffect(() => { loadPeriods(); }, [loadPeriods]);
  useEffect(() => { if (selectedPeriodId) loadRecords(); }, [selectedPeriodId, loadRecords]);

  const handleCreatePeriod = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await payrollService.createPeriod(periodForm as any);
      toast.success('Payroll period created');
      setPeriodDialog(false);
      loadPeriods();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };

  const calcRecord = (form: typeof recordForm) => {
    const basic = Number(form.basic_salary) || 0;
    const ot = Number(form.overtime_pay) || 0;
    const allow = Number(form.allowances) || 0;
    const gross = basic + ot + allow;
    const tax = Number(form.tax_deduction) || 0;
    const ss = Number(form.social_security) || 0;
    const pf = Number(form.provident_fund) || 0;
    const other = Number(form.other_deductions) || 0;
    const total_deductions = tax + ss + pf + other;
    return { gross_pay: gross, total_deductions, net_pay: gross - total_deductions };
  };

  const handleCreateRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPeriodId) { toast.error('Select a payroll period first'); return; }
    if (!recordForm.employee_id || recordForm.employee_id === 'none') { toast.error('Please select an employee'); return; }
    setSaving(true);
    try {
      const { gross_pay, total_deductions, net_pay } = calcRecord(recordForm);
      await payrollService.createRecord({
        payroll_period_id: selectedPeriodId,
        employee_id: recordForm.employee_id,
        basic_salary: Number(recordForm.basic_salary) || 0,
        overtime_pay: Number(recordForm.overtime_pay) || 0,
        allowances: Number(recordForm.allowances) || 0,
        gross_pay,
        tax_deduction: Number(recordForm.tax_deduction) || 0,
        social_security: Number(recordForm.social_security) || 0,
        provident_fund: Number(recordForm.provident_fund) || 0,
        other_deductions: Number(recordForm.other_deductions) || 0,
        total_deductions,
        net_pay,
        payment_status: 'pending',
        notes: recordForm.notes || undefined,
      });
      toast.success('Payroll record created');
      setRecordDialog(false);
      loadRecords();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Payroll</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{totalP} periods</p>
        </div>
        <Button variant="outline" size="sm" onClick={loadPeriods}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
      </div>

      <Tabs defaultValue="periods">
        <TabsList className="flex-wrap gap-1 h-auto">
          <TabsTrigger value="periods"><Wallet className="h-3.5 w-3.5 mr-1.5" />Periods</TabsTrigger>
          <TabsTrigger value="records"><TrendingUp className="h-3.5 w-3.5 mr-1.5" />Records</TabsTrigger>
          <TabsTrigger value="simulation"><FlaskConical className="h-3.5 w-3.5 mr-1.5" />Simulation</TabsTrigger>
          <TabsTrigger value="gl-posting"><Landmark className="h-3.5 w-3.5 mr-1.5" />GL Posting</TabsTrigger>
          <TabsTrigger value="off-cycle"><Repeat2 className="h-3.5 w-3.5 mr-1.5" />Off-Cycle</TabsTrigger>
          <TabsTrigger value="variance"><BarChart2 className="h-3.5 w-3.5 mr-1.5" />Variance Report</TabsTrigger>
          <TabsTrigger value="tax"><FileText className="h-3.5 w-3.5 mr-1.5" />Tax Reports</TabsTrigger>
          <TabsTrigger value="bank-file"><Building2 className="h-3.5 w-3.5 mr-1.5" />Bank File</TabsTrigger>
          <TabsTrigger value="ctc"><DollarSign className="h-3.5 w-3.5 mr-1.5" />CTC Breakdown</TabsTrigger>
          <TabsTrigger value="reconciliation"><Scale className="h-3.5 w-3.5 mr-1.5" />Reconciliation</TabsTrigger>
        </TabsList>

        {/* Payroll Periods */}
        <TabsContent value="periods" className="mt-4">
          <div className="flex justify-end mb-3">
            <Dialog open={periodDialog} onOpenChange={setPeriodDialog}>
              <DialogTrigger asChild>
                <Button size="sm"><Plus className="h-4 w-4 mr-1.5" />New Period</Button>
              </DialogTrigger>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                <DialogHeader><DialogTitle>Create Payroll Period</DialogTitle></DialogHeader>
                <form onSubmit={handleCreatePeriod} className="space-y-4 mt-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Period Code *</Label>
                      <Input placeholder="2026-05" value={periodForm.period_code} onChange={e => setPeriodForm(p => ({ ...p, period_code: e.target.value }))} required />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Name *</Label>
                      <Input placeholder="May 2026" value={periodForm.name} onChange={e => setPeriodForm(p => ({ ...p, name: e.target.value }))} required />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-1.5">
                      <Label>Start Date *</Label>
                      <Input type="date" value={periodForm.start_date} onChange={e => setPeriodForm(p => ({ ...p, start_date: e.target.value }))} required />
                    </div>
                    <div className="space-y-1.5">
                      <Label>End Date *</Label>
                      <Input type="date" value={periodForm.end_date} onChange={e => setPeriodForm(p => ({ ...p, end_date: e.target.value }))} required />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Payment Date *</Label>
                      <Input type="date" value={periodForm.payment_date} onChange={e => setPeriodForm(p => ({ ...p, payment_date: e.target.value }))} required />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Period Type</Label>
                      <Select value={periodForm.period_type} onValueChange={v => setPeriodForm(p => ({ ...p, period_type: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="monthly">Monthly</SelectItem>
                          <SelectItem value="bi_weekly">Bi-Weekly</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label>Status</Label>
                      <Select value={periodForm.status} onValueChange={v => setPeriodForm(p => ({ ...p, status: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="draft">Draft</SelectItem>
                          <SelectItem value="processing">Processing</SelectItem>
                          <SelectItem value="approved">Approved</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setPeriodDialog(false)}>Cancel</Button>
                    <Button type="submit" disabled={saving}>{saving ? 'Creating…' : 'Create Period'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Code</TableHead>
                    <TableHead className="whitespace-nowrap">Name</TableHead>
                    <TableHead className="whitespace-nowrap">Period</TableHead>
                    <TableHead className="whitespace-nowrap">Payment Date</TableHead>
                    <TableHead className="whitespace-nowrap">Type</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loadingP ? (
                    Array.from({ length: 4 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 7 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                  ) : periods.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">No payroll periods found</TableCell></TableRow>
                  ) : periods.map(p => (
                    <TableRow key={p.id} className={selectedPeriodId === p.id ? 'bg-primary/5' : ''}>
                      <TableCell className="whitespace-nowrap font-mono text-xs">{p.period_code}</TableCell>
                      <TableCell className="whitespace-nowrap font-medium">{p.name}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{p.start_date} – {p.end_date}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{p.payment_date}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm capitalize">{p.period_type.replace('_', '-')}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${PERIOD_STATUS_COLORS[p.status] ?? 'bg-muted text-muted-foreground'}`}>{p.status}</span>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setSelectedPeriodId(p.id)}>View Records</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* Payroll Records */}
        <TabsContent value="records" className="mt-4">
          {!selectedPeriodId ? (
            <div className="text-center py-16 text-muted-foreground border border-dashed border-border rounded-lg">
              <Wallet className="h-10 w-10 mx-auto mb-3 opacity-40" />
              <p>Select a payroll period from the Periods tab to view records</p>
            </div>
          ) : (
            <>
              {/* Summary */}
              <div className="grid grid-cols-3 gap-4 mb-4">
                {[
                  { label: 'Total Gross', value: formatCurrency(summary.total_gross) },
                  { label: 'Total Deductions', value: formatCurrency(summary.total_deductions) },
                  { label: 'Total Net Pay', value: formatCurrency(summary.total_net) },
                ].map(s => (
                  <div key={s.label} className="bg-card border border-border rounded-lg p-4">
                    <p className="text-xs text-muted-foreground">{s.label}</p>
                    <p className="text-xl font-bold mt-1">{s.value}</p>
                  </div>
                ))}
              </div>
              <div className="flex justify-end mb-3">
                <Dialog open={recordDialog} onOpenChange={setRecordDialog}>
                  <DialogTrigger asChild>
                    <Button size="sm"><Plus className="h-4 w-4 mr-1.5" />Add Record</Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                    <DialogHeader><DialogTitle>Add Payroll Record</DialogTitle></DialogHeader>
                    <form onSubmit={handleCreateRecord} className="space-y-4 mt-2">
                      <EmployeeSelect value={recordForm.employee_id} onChange={v => setRecordForm(p => ({ ...p, employee_id: v }))} required />
                      <div className="grid grid-cols-3 gap-3">
                        {[
                          { label: 'Basic Salary', key: 'basic_salary' },
                          { label: 'Overtime', key: 'overtime_pay' },
                          { label: 'Allowances', key: 'allowances' },
                        ].map(f => (
                          <div key={f.key} className="space-y-1.5">
                            <Label className="text-xs">{f.label}</Label>
                            <Input type="number" value={(recordForm as Record<string, string>)[f.key]} onChange={e => setRecordForm(p => ({ ...p, [f.key]: e.target.value }))} />
                          </div>
                        ))}
                      </div>
                      <div className="grid grid-cols-4 gap-3">
                        {[
                          { label: 'Tax', key: 'tax_deduction' },
                          { label: 'Social Sec', key: 'social_security' },
                          { label: 'Provident', key: 'provident_fund' },
                          { label: 'Other Deduct', key: 'other_deductions' },
                        ].map(f => (
                          <div key={f.key} className="space-y-1.5">
                            <Label className="text-xs">{f.label}</Label>
                            <Input type="number" value={(recordForm as Record<string, string>)[f.key]} onChange={e => setRecordForm(p => ({ ...p, [f.key]: e.target.value }))} />
                          </div>
                        ))}
                      </div>
                      {(() => { const c = calcRecord(recordForm); return c.gross_pay > 0 ? (
                        <div className="text-sm bg-muted/50 p-3 rounded-lg space-y-1">
                          <div className="flex justify-between"><span className="text-muted-foreground">Gross:</span><span className="font-medium">{formatCurrency(c.gross_pay)}</span></div>
                          <div className="flex justify-between"><span className="text-muted-foreground">Deductions:</span><span className="font-medium text-red-500">-{formatCurrency(c.total_deductions)}</span></div>
                          <div className="flex justify-between border-t pt-1 mt-1"><span className="font-semibold">Net Pay:</span><span className="font-bold text-green-600">{formatCurrency(c.net_pay)}</span></div>
                        </div>
                      ) : null; })()}
                      <div className="flex justify-end gap-2">
                        <Button type="button" variant="outline" onClick={() => setRecordDialog(false)}>Cancel</Button>
                        <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Create Record'}</Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
              <div className="border border-border rounded-lg overflow-hidden bg-card">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="whitespace-nowrap">Employee</TableHead>
                        <TableHead className="whitespace-nowrap">Basic</TableHead>
                        <TableHead className="whitespace-nowrap">OT</TableHead>
                        <TableHead className="whitespace-nowrap">Allowances</TableHead>
                        <TableHead className="whitespace-nowrap">Gross</TableHead>
                        <TableHead className="whitespace-nowrap">Deductions</TableHead>
                        <TableHead className="whitespace-nowrap">Net Pay</TableHead>
                        <TableHead className="whitespace-nowrap">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loadingR ? (
                        Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 8 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                      ) : records.length === 0 ? (
                        <TableRow><TableCell colSpan={8} className="text-center py-10 text-muted-foreground">No payroll records for this period</TableCell></TableRow>
                      ) : records.map(r => (
                        <TableRow key={r.id}>
                          <TableCell className="whitespace-nowrap text-sm">
                            {(r.employee as { first_name: string; last_name: string } | undefined)
                              ? `${(r.employee as { first_name: string; last_name: string }).first_name} ${(r.employee as { first_name: string; last_name: string }).last_name}`
                              : r.employee_id.slice(0, 8)}
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{formatCurrency(r.basic_salary)}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{formatCurrency(r.overtime_pay)}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{formatCurrency(r.allowances)}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm font-medium">{formatCurrency(r.gross_pay)}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm text-red-500">-{formatCurrency(r.total_deductions)}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm font-bold text-green-600">{formatCurrency(r.net_pay)}</TableCell>
                          <TableCell className="whitespace-nowrap">
                            <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${r.payment_status === 'paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                              {r.payment_status}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </>
          )}
        </TabsContent>

        {/* ── FR-PR-028: Payroll Simulation ── */}
        <TabsContent value="simulation" className="mt-4">
          <PayrollSimulationTab />
        </TabsContent>

        {/* ── FR-PR-030/5.5: GL Posting ── */}
        <TabsContent value="gl-posting" className="mt-4">
          <GLPostingTab />
        </TabsContent>

        {/* ── FR-PR-029: Off-Cycle Payroll ── */}
        <TabsContent value="off-cycle" className="mt-4">
          <OffCyclePayrollTab />
        </TabsContent>

        {/* ── Variance Report (FR-PR-031/034) ── */}
        <TabsContent value="variance" className="mt-4">
          <PayrollVarianceTab />
        </TabsContent>

        {/* ── Tax Reports (FR-PR-033/035/036/037) ── */}
        <TabsContent value="tax" className="mt-4">
          <PayrollTaxReportsTab />
        </TabsContent>

        {/* ── Bank File Generation (FR-PR-038) ── */}
        <TabsContent value="bank-file" className="mt-4">
          <PayrollBankFileTab />
        </TabsContent>

        {/* ── Cost to Company Breakdown (FR-PR-039) ── */}
        <TabsContent value="ctc" className="mt-4">
          <PayrollCtcTab />
        </TabsContent>

        {/* ── Reconciliation Report (FR-PR-040) ── */}
        <TabsContent value="reconciliation" className="mt-4">
          <PayrollReconciliationTab />
        </TabsContent>

      </Tabs>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-PR-028 – Payroll Simulation
   ───────────────────────────────────────────────────────────────────────── */
type SimRow = { simulation_id?: string; period_id: string; employee_id: string; gross_salary?: number; tax_deduction?: number; pension_deduction?: number; net_pay?: number; notes?: string; created_at?: string };

function PayrollSimulationTab() {
  const [rows, setRows] = useState<SimRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ period_id: '', employee_id: '', gross_salary: '', tax_rate: '35', pension_rate: '7', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('payroll_simulations').select('*').order('created_at', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const gross = Number(form.gross_salary) || 0;
  const taxAmt = Math.round(gross * (Number(form.tax_rate) / 100) * 100) / 100;
  const pensionAmt = Math.round(gross * (Number(form.pension_rate) / 100) * 100) / 100;
  const netPay = Math.max(0, gross - taxAmt - pensionAmt);

  const save = async () => {
    if (!form.employee_id || !gross) { toast.error('Employee and gross salary required'); return; }
    setSaving(true);
    const { error } = await sb.from('payroll_simulations').insert({
      period_id: form.period_id || null, employee_id: form.employee_id,
      gross_salary: gross, tax_deduction: taxAmt, pension_deduction: pensionAmt,
      net_pay: netPay, notes: form.notes || null,
    });
    if (error) toast.error(error.message); else { toast.success('Simulation saved'); setOpen(false); load(); }
    setSaving(false);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><FlaskConical className="h-4 w-4" />Payroll Simulation (FR-PR-028)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />New Simulation</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Gross Salary</TableHead>
                <TableHead className="whitespace-nowrap">Tax Deduction</TableHead>
                <TableHead className="whitespace-nowrap">Pension</TableHead>
                <TableHead className="whitespace-nowrap">Net Pay</TableHead>
                <TableHead className="whitespace-nowrap">Date</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-6 text-sm">No simulations run yet</TableCell></TableRow>}
                {rows.map((r, i) => (
                  <TableRow key={r.simulation_id || i}>
                    <TableCell className="whitespace-nowrap text-xs">{String(r.employee_id).slice(0, 8)}…</TableCell>
                    <TableCell className="whitespace-nowrap">{r.gross_salary?.toLocaleString()} ETB</TableCell>
                    <TableCell className="whitespace-nowrap text-destructive">{r.tax_deduction?.toLocaleString()} ETB</TableCell>
                    <TableCell className="whitespace-nowrap text-destructive">{r.pension_deduction?.toLocaleString()} ETB</TableCell>
                    <TableCell className="whitespace-nowrap font-semibold text-green-700">{r.net_pay?.toLocaleString()} ETB</TableCell>
                    <TableCell className="whitespace-nowrap text-xs text-muted-foreground">{r.created_at ? new Date(String(r.created_at)).toLocaleDateString() : '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Run Payroll Simulation</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Employee ID *</Label><Input value={form.employee_id} onChange={e => setForm(p => ({ ...p, employee_id: e.target.value }))} placeholder="UUID" /></div>
            <div className="space-y-1.5"><Label>Gross Salary (ETB) *</Label><Input type="number" value={form.gross_salary} onChange={e => setForm(p => ({ ...p, gross_salary: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Tax Rate (%)</Label><Input type="number" value={form.tax_rate} onChange={e => setForm(p => ({ ...p, tax_rate: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Pension Rate (%)</Label><Input type="number" value={form.pension_rate} onChange={e => setForm(p => ({ ...p, pension_rate: e.target.value }))} /></div>
            </div>
            {gross > 0 && (
              <div className="rounded-lg bg-muted/50 p-3 space-y-1.5 text-sm">
                <p className="font-medium">Preview</p>
                <div className="flex justify-between"><span>Gross</span><span className="font-medium">{gross.toLocaleString()} ETB</span></div>
                <div className="flex justify-between text-destructive"><span>Tax ({form.tax_rate}%)</span><span>−{taxAmt.toLocaleString()} ETB</span></div>
                <div className="flex justify-between text-destructive"><span>Pension ({form.pension_rate}%)</span><span>−{pensionAmt.toLocaleString()} ETB</span></div>
                <div className="flex justify-between font-bold text-green-700 border-t pt-1.5"><span>Net Pay</span><span>{netPay.toLocaleString()} ETB</span></div>
              </div>
            )}
            <div className="space-y-1.5"><Label>Notes</Label><Textarea rows={2} value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save Simulation</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-PR-030 / Data Model 5.5 – GL Posting
   ───────────────────────────────────────────────────────────────────────── */
type GLRow = { gl_posting_id?: string; payroll_run_id?: string; account_code?: string; account_name?: string; debit_amount?: number; credit_amount?: number; posting_date?: string; status?: string; reference_number?: string };

function GLPostingTab() {
  const [rows, setRows] = useState<GLRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ account_code: '', account_name: '', debit_amount: '', credit_amount: '', posting_date: '', reference_number: '', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('gl_postings').select('*').order('posting_date', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.account_code.trim()) { toast.error('Account code required'); return; }
    setSaving(true);
    const { error } = await sb.from('gl_postings').insert({
      account_code: form.account_code, account_name: form.account_name || null,
      debit_amount: form.debit_amount ? Number(form.debit_amount) : null,
      credit_amount: form.credit_amount ? Number(form.credit_amount) : null,
      posting_date: form.posting_date || new Date().toISOString().slice(0, 10),
      reference_number: form.reference_number || null, status: 'PENDING',
    });
    if (error) toast.error(error.message); else { toast.success('GL entry posted'); setOpen(false); load(); }
    setSaving(false);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><Landmark className="h-4 w-4" />GL Posting (FR-PR-030 / DM-5.5)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />New GL Entry</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Account Code</TableHead>
                <TableHead className="whitespace-nowrap">Account Name</TableHead>
                <TableHead className="whitespace-nowrap">Reference</TableHead>
                <TableHead className="whitespace-nowrap">Debit</TableHead>
                <TableHead className="whitespace-nowrap">Credit</TableHead>
                <TableHead className="whitespace-nowrap">Posting Date</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-6 text-sm">No GL postings yet</TableCell></TableRow>}
                {rows.map((r, i) => (
                  <TableRow key={r.gl_posting_id || i}>
                    <TableCell className="whitespace-nowrap font-mono text-sm">{r.account_code}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.account_name || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-xs">{r.reference_number || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-green-700">{r.debit_amount?.toLocaleString() ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-destructive">{r.credit_amount?.toLocaleString() ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.posting_date || '—'}</TableCell>
                    <TableCell><Badge className={r.status === 'POSTED' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>{r.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New GL Entry</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-2">
            <div className="space-y-1.5"><Label>Account Code *</Label><Input value={form.account_code} onChange={e => setForm(p => ({ ...p, account_code: e.target.value }))} placeholder="e.g. 5100" /></div>
            <div className="space-y-1.5"><Label>Account Name</Label><Input value={form.account_name} onChange={e => setForm(p => ({ ...p, account_name: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Debit Amount</Label><Input type="number" value={form.debit_amount} onChange={e => setForm(p => ({ ...p, debit_amount: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Credit Amount</Label><Input type="number" value={form.credit_amount} onChange={e => setForm(p => ({ ...p, credit_amount: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Posting Date</Label><Input type="date" value={form.posting_date} onChange={e => setForm(p => ({ ...p, posting_date: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Reference #</Label><Input value={form.reference_number} onChange={e => setForm(p => ({ ...p, reference_number: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Post</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-PR-029 – Off-Cycle Payroll Run
   ───────────────────────────────────────────────────────────────────────── */
type OffCycleRow = { off_cycle_id?: string; employee_id: string; reason?: string; amount?: number; run_date?: string; status?: string; approved_by?: string };

function OffCyclePayrollTab() {
  const [rows, setRows] = useState<OffCycleRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ employee_id: '', reason: '', amount: '', run_date: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('off_cycle_payroll_runs').select('*').order('run_date', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.employee_id) { toast.error('Employee ID required'); return; }
    setSaving(true);
    const { error } = await sb.from('off_cycle_payroll_runs').insert({
      employee_id: form.employee_id, reason: form.reason || null,
      amount: form.amount ? Number(form.amount) : null,
      run_date: form.run_date || new Date().toISOString().slice(0, 10), status: 'PENDING',
    });
    if (error) toast.error(error.message); else { toast.success('Off-cycle run submitted'); setOpen(false); load(); }
    setSaving(false);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><Repeat2 className="h-4 w-4" />Off-Cycle Payroll Runs (FR-PR-029)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />New Off-Cycle Run</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Reason</TableHead>
                <TableHead className="whitespace-nowrap">Amount (ETB)</TableHead>
                <TableHead className="whitespace-nowrap">Run Date</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6 text-sm">No off-cycle runs recorded</TableCell></TableRow>}
                {rows.map((r, i) => (
                  <TableRow key={r.off_cycle_id || i}>
                    <TableCell className="whitespace-nowrap text-xs">{String(r.employee_id).slice(0, 8)}…</TableCell>
                    <TableCell className="max-w-[200px] truncate text-sm">{r.reason || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">{r.amount?.toLocaleString() ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.run_date || '—'}</TableCell>
                    <TableCell><Badge className={r.status === 'PROCESSED' ? 'bg-green-100 text-green-800' : r.status === 'APPROVED' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'}>{r.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Off-Cycle Payroll Run</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Employee ID *</Label><Input value={form.employee_id} onChange={e => setForm(p => ({ ...p, employee_id: e.target.value }))} placeholder="UUID" /></div>
            <div className="space-y-1.5"><Label>Reason</Label><Textarea rows={2} value={form.reason} onChange={e => setForm(p => ({ ...p, reason: e.target.value }))} placeholder="e.g. Missed bonus, correction…" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Amount (ETB)</Label><Input type="number" value={form.amount} onChange={e => setForm(p => ({ ...p, amount: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Run Date</Label><Input type="date" value={form.run_date} onChange={e => setForm(p => ({ ...p, run_date: e.target.value }))} /></div>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Submit</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
