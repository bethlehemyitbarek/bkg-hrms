import { useState, useEffect, useCallback } from 'react';
import { payrollComponentService, salaryStructureService } from '@/services/payroll.service';
import type { PayrollComponent, SalaryStructure } from '@/services/payroll.service';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Plus, RefreshCw, Pencil, Trash2, Layers, DollarSign, Minus } from 'lucide-react';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger
} from '@/components/ui/alert-dialog';

const TYPE_BADGE: Record<string, string> = {
  earning:   'bg-green-100 text-green-800',
  deduction: 'bg-red-100 text-red-800',
  benefit:   'bg-blue-100 text-blue-800',
};

const fmtCurrency = (n: number | null | undefined) =>
  n != null ? `ብር ${Number(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}` : '—';

export function PayrollComponentsPage() {
  const [components, setComponents] = useState<PayrollComponent[]>([]);
  const [structures, setStructures]   = useState<SalaryStructure[]>([]);
  const [loading, setLoading]         = useState(true);
  const [saving,  setSaving]          = useState(false);

  /* Component dialog */
  const [compDialog, setCompDialog] = useState(false);
  const [editComp,   setEditComp]   = useState<PayrollComponent | null>(null);
  const [compForm, setCompForm] = useState({
    name: '', component_type: 'earning', calculation_method: 'fixed',
    is_taxable: false, is_active: true, description: '',
  });

  /* Structure dialog */
  const [structDialog, setStructDialog]   = useState(false);
  const [editStruct,   setEditStruct]     = useState<SalaryStructure | null>(null);
  const [structForm, setStructForm]       = useState({ name: '', description: '', is_active: true });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [c, s] = await Promise.all([payrollComponentService.list(), salaryStructureService.list()]);
      setComponents(c);
      setStructures(s);
    } catch { toast.error('Failed to load payroll data'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  /* ── Component CRUD ── */
  const openCompCreate = () => {
    setEditComp(null);
    setCompForm({ name: '', component_type: 'earning', calculation_method: 'fixed', is_taxable: false, is_active: true, description: '' });
    setCompDialog(true);
  };
  const openCompEdit = (c: PayrollComponent) => {
    setEditComp(c);
    setCompForm({ name: c.name, component_type: c.component_type, calculation_method: c.calculation_method, is_taxable: c.is_taxable, is_active: c.is_active, description: c.description ?? '' });
    setCompDialog(true);
  };
  const handleCompSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editComp) {
        await payrollComponentService.update(editComp.id, { ...compForm, component_type: compForm.component_type as PayrollComponent['component_type'], calculation_method: compForm.calculation_method as PayrollComponent['calculation_method'] });
        toast.success('Component updated');
      } else {
        await payrollComponentService.create({ ...compForm, component_type: compForm.component_type as PayrollComponent['component_type'], calculation_method: compForm.calculation_method as PayrollComponent['calculation_method'] });
        toast.success('Component created');
      }
      setCompDialog(false);
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };
  const handleCompDelete = async (id: string) => {
    try { await payrollComponentService.remove(id); toast.success('Component deleted'); load(); }
    catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to delete'); }
  };

  /* ── Structure CRUD ── */
  const openStructCreate = () => {
    setEditStruct(null);
    setStructForm({ name: '', description: '', is_active: true });
    setStructDialog(true);
  };
  const openStructEdit = (s: SalaryStructure) => {
    setEditStruct(s);
    setStructForm({ name: s.name, description: s.description ?? '', is_active: s.is_active });
    setStructDialog(true);
  };
  const handleStructSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editStruct) {
        await salaryStructureService.update(editStruct.id, structForm);
        toast.success('Structure updated');
      } else {
        await salaryStructureService.create(structForm);
        toast.success('Structure created');
      }
      setStructDialog(false);
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };
  const handleStructDelete = async (id: string) => {
    try { await salaryStructureService.remove(id); toast.success('Structure deleted'); load(); }
    catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to delete'); }
  };

  /* ── Structure component toggle ── */
  const toggleStructComp = async (structure: SalaryStructure, compId: string, has: boolean) => {
    try {
      if (has) await salaryStructureService.removeComponent(structure.id, compId);
      else     await salaryStructureService.addComponent(structure.id, compId);
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
  };

  const earnings   = components.filter(c => c.component_type === 'earning');
  const deductions = components.filter(c => c.component_type === 'deduction');
  const benefits   = components.filter(c => c.component_type === 'benefit');

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-balance">Payroll Components & Structures</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{components.length} components · {structures.length} structures</p>
        </div>
        <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
      </div>

      <Tabs defaultValue="components">
        <TabsList className="h-9">
          <TabsTrigger value="components"><DollarSign className="h-3.5 w-3.5 mr-1.5" />Components</TabsTrigger>
          <TabsTrigger value="structures"><Layers className="h-3.5 w-3.5 mr-1.5" />Salary Structures</TabsTrigger>
        </TabsList>

        {/* ── Components tab ── */}
        <TabsContent value="components" className="mt-4 space-y-4">
          <div className="flex justify-end">
            <Dialog open={compDialog} onOpenChange={setCompDialog}>
              <DialogTrigger asChild>
                <Button size="sm" onClick={openCompCreate}><Plus className="h-4 w-4 mr-1.5" />Add Component</Button>
              </DialogTrigger>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                <DialogHeader><DialogTitle>{editComp ? 'Edit' : 'New'} Payroll Component</DialogTitle></DialogHeader>
                <form onSubmit={handleCompSave} className="space-y-4 mt-2">
                  <div className="space-y-1.5"><Label>Name *</Label><Input value={compForm.name} onChange={e => setCompForm(p => ({ ...p, name: e.target.value }))} required /></div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Type *</Label>
                      <Select value={compForm.component_type} onValueChange={v => setCompForm(p => ({ ...p, component_type: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="earning">Earning</SelectItem>
                          <SelectItem value="deduction">Deduction</SelectItem>
                          <SelectItem value="benefit">Benefit</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label>Calculation *</Label>
                      <Select value={compForm.calculation_method} onValueChange={v => setCompForm(p => ({ ...p, calculation_method: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="fixed">Fixed Amount</SelectItem>
                          <SelectItem value="percentage">Percentage</SelectItem>
                          <SelectItem value="formula">Formula</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2">
                      <Switch checked={compForm.is_taxable} onCheckedChange={v => setCompForm(p => ({ ...p, is_taxable: v }))} id="taxable" />
                      <Label htmlFor="taxable">Taxable</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch checked={compForm.is_active} onCheckedChange={v => setCompForm(p => ({ ...p, is_active: v }))} id="active-c" />
                      <Label htmlFor="active-c">Active</Label>
                    </div>
                  </div>
                  <div className="space-y-1.5"><Label>Description</Label><Textarea value={compForm.description} onChange={e => setCompForm(p => ({ ...p, description: e.target.value }))} rows={2} /></div>
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setCompDialog(false)}>Cancel</Button>
                    <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            {[{ label: 'Earnings', count: earnings.length, icon: DollarSign, color: 'text-green-600' },
              { label: 'Deductions', count: deductions.length, icon: Minus, color: 'text-red-600' },
              { label: 'Benefits', count: benefits.length, icon: Layers, color: 'text-blue-600' }].map(s => (
              <div key={s.label} className="bg-card border border-border rounded-lg p-3 flex items-center gap-2.5">
                <s.icon className={`h-4 w-4 shrink-0 ${s.color}`} />
                <div><p className="text-xs text-muted-foreground">{s.label}</p><p className="text-lg font-bold leading-tight">{s.count}</p></div>
              </div>
            ))}
          </div>

          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Name</TableHead>
                    <TableHead className="whitespace-nowrap">Type</TableHead>
                    <TableHead className="whitespace-nowrap">Method</TableHead>
                    <TableHead className="whitespace-nowrap">Taxable</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 6 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>
                  )) : components.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No components found</TableCell></TableRow>
                  ) : components.map(c => (
                    <TableRow key={c.id}>
                      <TableCell className="font-medium whitespace-nowrap">{c.name}</TableCell>
                      <TableCell className="whitespace-nowrap"><Badge className={`text-xs capitalize ${TYPE_BADGE[c.component_type]}`}>{c.component_type}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap text-sm capitalize">{c.calculation_method}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{c.is_taxable ? '✓' : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge variant="outline" className={`text-xs ${c.is_active ? 'text-green-600 border-green-200' : 'text-muted-foreground'}`}>{c.is_active ? 'Active' : 'Inactive'}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex items-center gap-1">
                          <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openCompEdit(c)}><Pencil className="h-3.5 w-3.5" /></Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="sm" variant="outline" className="h-7 px-2 text-red-500 border-red-200 hover:bg-red-50"><Trash2 className="h-3.5 w-3.5" /></Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
                              <AlertDialogHeader><AlertDialogTitle>Delete Component</AlertDialogTitle><AlertDialogDescription>Delete &quot;{c.name}&quot;? This cannot be undone.</AlertDialogDescription></AlertDialogHeader>
                              <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={() => handleCompDelete(c.id)} className="bg-red-500 hover:bg-red-600">Delete</AlertDialogAction></AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── Structures tab ── */}
        <TabsContent value="structures" className="mt-4 space-y-4">
          <div className="flex justify-end">
            <Dialog open={structDialog} onOpenChange={setStructDialog}>
              <DialogTrigger asChild>
                <Button size="sm" onClick={openStructCreate}><Plus className="h-4 w-4 mr-1.5" />New Structure</Button>
              </DialogTrigger>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                <DialogHeader><DialogTitle>{editStruct ? 'Edit' : 'New'} Salary Structure</DialogTitle></DialogHeader>
                <form onSubmit={handleStructSave} className="space-y-4 mt-2">
                  <div className="space-y-1.5"><Label>Name *</Label><Input value={structForm.name} onChange={e => setStructForm(p => ({ ...p, name: e.target.value }))} required /></div>
                  <div className="space-y-1.5"><Label>Description</Label><Textarea value={structForm.description} onChange={e => setStructForm(p => ({ ...p, description: e.target.value }))} rows={2} /></div>
                  <div className="flex items-center gap-2">
                    <Switch checked={structForm.is_active} onCheckedChange={v => setStructForm(p => ({ ...p, is_active: v }))} id="active-s" />
                    <Label htmlFor="active-s">Active</Label>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setStructDialog(false)}>Cancel</Button>
                    <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-4">
            {loading ? Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-40 rounded-lg bg-muted" />)
            : structures.length === 0 ? (
              <div className="border border-border rounded-lg py-12 text-center text-muted-foreground"><Layers className="h-10 w-10 mx-auto mb-2 opacity-40" />No salary structures yet</div>
            ) : structures.map(s => {
              const linkedIds = new Set((s.salary_structure_components ?? []).map(sc => sc.payroll_component_id));
              return (
                <div key={s.id} className="border border-border rounded-lg bg-card p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-semibold">{s.name}</p>
                      {s.description && <p className="text-xs text-muted-foreground mt-0.5">{s.description}</p>}
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Badge variant="outline" className={`text-xs ${s.is_active ? 'text-green-600 border-green-200' : 'text-muted-foreground'}`}>{s.is_active ? 'Active' : 'Inactive'}</Badge>
                      <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openStructEdit(s)}><Pencil className="h-3.5 w-3.5" /></Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button size="sm" variant="outline" className="h-7 px-2 text-red-500 border-red-200 hover:bg-red-50"><Trash2 className="h-3.5 w-3.5" /></Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
                          <AlertDialogHeader><AlertDialogTitle>Delete Structure</AlertDialogTitle><AlertDialogDescription>Delete &quot;{s.name}&quot;? All component links will be removed.</AlertDialogDescription></AlertDialogHeader>
                          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={() => handleStructDelete(s.id)} className="bg-red-500 hover:bg-red-600">Delete</AlertDialogAction></AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-2">Components ({linkedIds.size})</p>
                    <div className="flex flex-wrap gap-2">
                      {components.map(c => {
                        const has = linkedIds.has(c.id);
                        return (
                          <button key={c.id}
                            onClick={() => toggleStructComp(s, c.id, has)}
                            className={`text-xs px-2.5 py-1 rounded-full border transition-colors ${has
                              ? 'border-primary bg-primary/10 text-primary font-medium'
                              : 'border-border bg-card text-muted-foreground hover:border-primary/40'}`}
                          >
                            {c.name}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  {linkedIds.size > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {(s.salary_structure_components ?? []).map(sc => (
                        <Badge key={sc.id} className={`text-xs ${TYPE_BADGE[sc.payroll_component?.component_type ?? 'earning']}`}>
                          {sc.payroll_component?.name}
                          {sc.amount != null && ` · ${fmtCurrency(sc.amount)}`}
                          {sc.rate != null && ` · ${(Number(sc.rate) * 100).toFixed(1)}%`}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
