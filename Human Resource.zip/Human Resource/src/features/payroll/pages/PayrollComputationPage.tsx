import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase as _supabase } from '@/db/supabase';
import { payrollService, salaryStructureService, payrollSettingsService } from '@/services/payroll.service';
import type { PayrollComponent, SalaryStructure, EmployeeSalaryStructure, PayrollSettings, StatutoryDeduction } from '@/services/payroll.service';
import type { PayrollPeriod, PayrollRecord, Employee } from '@/types/database.types';
import { employeeService } from '@/services/employee.service';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import {
  RefreshCw, Play, Download, Eye, Wallet, TrendingUp, Users,
  CheckCircle2, AlertCircle, Loader2, Printer, ChevronDown, ChevronUp,
  DollarSign, Minus, Plus, BarChart2, FileText, Zap, Lock,
} from 'lucide-react';

// ── Helpers ────────────────────────────────────────────────────
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const supabase = _supabase as any;

const fmtCcy = (n: number | null | undefined, currency = 'ETB') =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 2 }).format(Number(n) || 0);

const fmtDate = (d?: string) =>
  d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

const PERIOD_BADGE: Record<string, string> = {
  draft:      'bg-muted text-muted-foreground',
  processing: 'bg-blue-100 text-blue-800',
  approved:   'bg-purple-100 text-purple-800',
  paid:       'bg-green-100 text-green-800',
  cancelled:  'bg-red-100 text-red-800',
};
const PAY_BADGE: Record<string, string> = {
  pending:  'bg-yellow-100 text-yellow-800',
  paid:     'bg-green-100 text-green-800',
  held:     'bg-orange-100 text-orange-800',
  reversed: 'bg-red-100 text-red-800',
};

// ── Payslip line item ──────────────────────────────────────────
interface PayslipLine {
  label: string;
  amount: number;
  type: 'earning' | 'deduction' | 'net';
  is_bold?: boolean;
}

interface ComputedPayslip {
  employee: Employee;
  record?: PayrollRecord;
  lines: PayslipLine[];
  gross: number;
  deductions: number;
  net: number;
  structure?: SalaryStructure;
  status: 'computed' | 'existing' | 'no_structure';
}

// ── Print payslip as browser-native print dialog ───────────────
function printPayslip(ps: ComputedPayslip, period: PayrollPeriod, currency: string) {
  const empName = `${ps.employee.first_name} ${ps.employee.last_name}`;
  const lines = ps.lines.map(l => `
    <tr>
      <td style="padding:4px 8px;${l.is_bold ? 'font-weight:600;' : ''}${l.type === 'net' ? 'font-size:14px;' : ''}">${l.label}</td>
      <td style="padding:4px 8px;text-align:right;${l.type === 'deduction' ? 'color:#dc2626;' : ''}${l.type === 'net' ? 'font-size:14px;font-weight:700;color:#2563eb;' : ''}${l.is_bold && l.type !== 'net' ? 'font-weight:600;' : ''}">${l.type === 'deduction' ? '-' : ''}${fmtCcy(l.amount, currency)}</td>
    </tr>`).join('');
  const html = `<!DOCTYPE html><html><head><title>Payslip - ${empName}</title>
    <style>body{font-family:Arial,sans-serif;margin:0;padding:32px;color:#111;}
    h2{margin:0 0 4px}h3{margin:0;font-weight:normal;color:#555}
    table{width:100%;border-collapse:collapse;margin-top:12px}
    th{text-align:left;padding:4px 8px;border-bottom:2px solid #ddd;font-size:12px;color:#666;text-transform:uppercase}
    tr:nth-child(even){background:#f9f9f9}
    .sep{border:none;border-top:1px solid #ddd;margin:8px 0}
    .footer{margin-top:24px;font-size:12px;color:#888;text-align:center}
    @media print{body{padding:16px}}</style></head><body>
    <div style="display:flex;justify-content:space-between;align-items:flex-start">
      <div><h2>PAYSLIP</h2><h3>BKG Company</h3></div>
      <div style="text-align:right;font-size:13px">
        <div><b>${period.name}</b></div>
        <div>${fmtDate(period.start_date)} — ${fmtDate(period.end_date)}</div>
        <div>Payment: ${fmtDate(period.payment_date)}</div>
      </div>
    </div>
    <hr class="sep">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:13px;margin:8px 0">
      <div><b>Employee:</b> ${empName}</div>
      <div><b>Employee No:</b> ${ps.employee.employee_no}</div>
      <div><b>Structure:</b> ${ps.structure?.name ?? '—'}</div>
      <div><b>Status:</b> ${ps.record?.payment_status ?? 'pending'}</div>
    </div>
    <hr class="sep">
    <table><thead><tr><th>Description</th><th style="text-align:right">Amount</th></tr></thead>
    <tbody>${lines}</tbody></table>
    <div class="footer">This is a computer-generated payslip. No signature required.</div>
    </body></html>`;
  const win = window.open('', '_blank', 'width=700,height=600');
  if (!win) return;
  win.document.write(html);
  win.document.close();
  win.onload = () => { win.print(); };
}

// ── Main Component ─────────────────────────────────────────────
export function PayrollComputationPage() {
  const [periods,     setPeriods]     = useState<PayrollPeriod[]>([]);
  const [selPeriod,   setSelPeriod]   = useState<string>('');
  const [period,      setPeriod]      = useState<PayrollPeriod | null>(null);
  const [records,     setRecords]     = useState<PayrollRecord[]>([]);
  const [structures,  setStructures]  = useState<SalaryStructure[]>([]);
  const [assignments, setAssignments] = useState<EmployeeSalaryStructure[]>([]);
  const [employees,   setEmployees]   = useState<Employee[]>([]);
  const [settings,    setSettings]    = useState<PayrollSettings | null>(null);
  const [deductions,  setDeductions]  = useState<StatutoryDeduction[]>([]);
  const [loading,     setLoading]     = useState(true);
  const [computing,   setComputing]   = useState(false);
  const [progress,    setProgress]    = useState(0);
  const [payslips,    setPayslips]    = useState<ComputedPayslip[]>([]);
  const [tab,         setTab]         = useState<'overview' | 'payslips' | 'breakdown'>('overview');
  const [search,      setSearch]      = useState('');
  const [viewSlip,    setViewSlip]    = useState<ComputedPayslip | null>(null);
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [saving,      setSaving]      = useState(false);
  const computingRef = useRef(false);

  // ── Load initial data ────────────────────────────────────────
  const loadBase = useCallback(async () => {
    setLoading(true);
    try {
      const [pRes, sRes, aRes, eRes, stRes, dRes] = await Promise.all([
        payrollService.listPeriods({ page: 1, pageSize: 50 }),
        salaryStructureService.list(),
        salaryStructureService.listAssignments(),
        employeeService.list({ page: 1, pageSize: 500, employment_status: 'active' }),
        payrollSettingsService.get(),
        payrollSettingsService.listStatutoryDeductions(),
      ]);
      setPeriods(pRes.data);
      setStructures(sRes);
      setAssignments(Array.isArray(aRes) ? aRes : []);
      setEmployees(Array.isArray(eRes.data) ? eRes.data : []);
      setSettings(stRes);
      setDeductions(Array.isArray(dRes) ? dRes : []);

      // Auto-select most recent non-paid period
      const autoSel = pRes.data.find(p => p.status === 'processing' || p.status === 'draft');
      if (autoSel && !selPeriod) setSelPeriod(autoSel.id);
    } catch { toast.error('Failed to load payroll data'); }
    finally { setLoading(false); }
  }, [selPeriod]);

  useEffect(() => { loadBase(); }, []); // eslint-disable-line

  // Load records when period changes
  useEffect(() => {
    if (!selPeriod) return;
    const found = periods.find(p => p.id === selPeriod);
    setPeriod(found ?? null);
    setPayslips([]);
    payrollService.listRecords({ period_id: selPeriod, page: 1, pageSize: 500 })
      .then(r => setRecords(r.data))
      .catch(() => setRecords([]));
  }, [selPeriod, periods]);

  // ── Compute payslips ─────────────────────────────────────────
  const computeAll = useCallback(async () => {
    if (!period || computingRef.current) return;
    computingRef.current = true;
    setComputing(true);
    setProgress(0);
    setPayslips([]);

    try {
      const currency = settings?.currency ?? 'ETB';
      const activeDeductions = deductions.filter(d => d.is_active);
      const structMap = new Map(structures.map(s => [s.id, s]));
      const assignMap = new Map(assignments.map(a => [a.employee_id, a]));
      const recordMap = new Map(records.map(r => [r.employee_id, r]));

      const computed: ComputedPayslip[] = [];
      const total = employees.length;

      for (let i = 0; i < employees.length; i++) {
        const emp = employees[i];
        setProgress(Math.round(((i + 1) / total) * 100));

        const assignment = assignMap.get(emp.id);
        if (!assignment) {
          computed.push({ employee: emp, lines: [], gross: 0, deductions: 0, net: 0, status: 'no_structure' });
          continue;
        }
        const structure = structMap.get(assignment.salary_structure_id);
        if (!structure) {
          computed.push({ employee: emp, lines: [], gross: 0, deductions: 0, net: 0, status: 'no_structure' });
          continue;
        }

        const comps = structure.salary_structure_components ?? [];
        const lines: PayslipLine[] = [];
        let gross = 0;
        let rawDeductions = 0;

        // ── Earnings ───────────────────────────────────────────
        lines.push({ label: 'EARNINGS', amount: 0, type: 'earning', is_bold: true });
        for (const c of comps.filter(x => x.payroll_component?.component_type === 'earning')) {
          const amt = c.amount ?? 0;
          lines.push({ label: c.payroll_component!.name, amount: amt, type: 'earning' });
          gross += amt;
        }
        lines.push({ label: 'Gross Pay', amount: gross, type: 'earning', is_bold: true });

        // ── Statutory deductions (applied to gross) ────────────
        let taxTotal = 0;
        let socialTotal = 0;
        let pfTotal = 0;
        for (const d of activeDeductions) {
          const rate = (d.rate ?? 0) / 100;
          let amt = gross * rate;
          if (d.max_amount && amt > d.max_amount) amt = d.max_amount;
          if (d.threshold && gross < d.threshold) amt = 0;
          if (d.deduction_type === 'income_tax')       taxTotal    += amt;
          if (d.deduction_type === 'social_insurance')  socialTotal += amt;
          if (d.deduction_type === 'provident_fund')    pfTotal     += amt;
        }

        // ── Component deductions ───────────────────────────────
        lines.push({ label: 'DEDUCTIONS', amount: 0, type: 'deduction', is_bold: true });
        if (taxTotal > 0)    lines.push({ label: 'Income Tax',        amount: taxTotal,    type: 'deduction' });
        if (socialTotal > 0) lines.push({ label: 'Social Insurance',   amount: socialTotal, type: 'deduction' });
        if (pfTotal > 0)     lines.push({ label: 'Provident Fund',     amount: pfTotal,     type: 'deduction' });

        for (const c of comps.filter(x => x.payroll_component?.component_type === 'deduction')) {
          let amt = c.amount ?? 0;
          if (c.rate) amt = gross * (c.rate / 100);
          lines.push({ label: c.payroll_component!.name, amount: amt, type: 'deduction' });
          rawDeductions += amt;
        }
        rawDeductions += taxTotal + socialTotal + pfTotal;
        lines.push({ label: 'Total Deductions', amount: rawDeductions, type: 'deduction', is_bold: true });

        // ── Net Pay ────────────────────────────────────────────
        const net = gross - rawDeductions;
        lines.push({ label: `Net Pay (${currency})`, amount: net, type: 'net', is_bold: true });

        const existingRecord = recordMap.get(emp.id);
        computed.push({
          employee: emp,
          record: existingRecord,
          lines,
          gross,
          deductions: rawDeductions,
          net,
          structure,
          status: existingRecord ? 'existing' : 'computed',
        });
      }
      setPayslips(computed);
      const withStructure = computed.filter(c => c.status !== 'no_structure').length;
      toast.success(`Computed ${withStructure} payslips (${computed.filter(c => c.status === 'no_structure').length} employees missing structure)`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Computation failed');
    } finally {
      computingRef.current = false;
      setComputing(false);
      setProgress(100);
    }
  }, [period, employees, structures, assignments, records, settings, deductions]);

  // ── Save payroll records ─────────────────────────────────────
  const saveToPayroll = async () => {
    if (!period || !payslips.length) return;
    setSaving(true);
    let created = 0; let updated = 0; let skipped = 0;
    try {
      for (const ps of payslips) {
        if (ps.status === 'no_structure') { skipped++; continue; }
        const overtime_pay      = ps.record?.overtime_pay      ?? 0;
        const other_deductions  = ps.record?.other_deductions  ?? 0;
        const basicLine = ps.lines.find(l => l.type === 'earning' && !l.is_bold);
        const basic_salary      = basicLine?.amount ?? ps.gross;
        const allowances        = ps.gross - basic_salary;
        const taxLine           = ps.lines.find(l => l.label === 'Income Tax');
        const socialLine        = ps.lines.find(l => l.label === 'Social Insurance');
        const pfLine            = ps.lines.find(l => l.label === 'Provident Fund');
        const payload = {
          employee_id:       ps.employee.id,
          payroll_period_id: period.id,
          basic_salary,
          overtime_pay,
          allowances,
          tax_deduction:   taxLine?.amount    ?? 0,
          social_security: socialLine?.amount ?? 0,
          provident_fund:  pfLine?.amount     ?? 0,
          other_deductions,
          gross_pay:        ps.gross,
          total_deductions: ps.deductions,
          net_pay:          ps.net,
          payment_status:  (ps.record?.payment_status ?? 'pending') as PayrollRecord['payment_status'],
        };
        if (ps.record) {
          await payrollService.updateRecord(ps.record.id, payload);
          updated++;
        } else {
          await payrollService.createRecord(payload);
          created++;
        }
      }
      toast.success(`Saved: ${created} created, ${updated} updated, ${skipped} skipped`);
      // Reload records
      const r = await payrollService.listRecords({ period_id: period.id, page: 1, pageSize: 500 });
      setRecords(r.data);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  // ── Summary stats ────────────────────────────────────────────
  const stats = {
    total:         payslips.length,
    computed:      payslips.filter(p => p.status !== 'no_structure').length,
    no_structure:  payslips.filter(p => p.status === 'no_structure').length,
    total_gross:   payslips.reduce((a, p) => a + p.gross, 0),
    total_net:     payslips.reduce((a, p) => a + p.net, 0),
    total_ded:     payslips.reduce((a, p) => a + p.deductions, 0),
  };

  const currency = settings?.currency ?? 'ETB';
  const filtered = payslips.filter(p => {
    if (!search) return true;
    const q = search.toLowerCase();
    return `${p.employee.first_name} ${p.employee.last_name} ${p.employee.employee_no}`.toLowerCase().includes(q);
  });

  const toggleRow = (id: string) => {
    setExpandedRows(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  // ── JSX ───────────────────────────────────────────────────────
  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-balance">Payroll Computation</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Compute salary, apply statutory deductions, generate payslips and save to payroll run.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={loadBase} disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-1.5 ${loading ? 'animate-spin' : ''}`} />Refresh
        </Button>
      </div>

      {/* Period selector + action bar */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row md:items-end gap-4">
            <div className="flex-1 space-y-1.5">
              <Label>Payroll Period</Label>
              <Select value={selPeriod} onValueChange={setSelPeriod}>
                <SelectTrigger>
                  <SelectValue placeholder="Select payroll period…" />
                </SelectTrigger>
                <SelectContent>
                  {periods.map(p => (
                    <SelectItem key={p.id} value={p.id}>
                      <span className="flex items-center gap-2">
                        {p.name}
                        <Badge className={`text-xs capitalize ${PERIOD_BADGE[p.status]}`}>{p.status}</Badge>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {period && (
              <div className="text-sm text-muted-foreground shrink-0">
                <span>{fmtDate(period.start_date)} — {fmtDate(period.end_date)}</span>
                {period.payment_date && <span> · Pay: {fmtDate(period.payment_date)}</span>}
              </div>
            )}
            <Button onClick={computeAll} disabled={!selPeriod || computing} className="gap-2 shrink-0">
              {computing
                ? <><Loader2 className="h-4 w-4 animate-spin" />Computing…</>
                : <><Zap className="h-4 w-4" />Compute Payslips</>}
            </Button>
            {payslips.length > 0 && (
              <Button onClick={saveToPayroll} disabled={saving || !period} variant="secondary" className="gap-2 shrink-0">
                {saving
                  ? <><Loader2 className="h-4 w-4 animate-spin" />Saving…</>
                  : <><Lock className="h-4 w-4" />Save to Payroll Run</>}
              </Button>
            )}
          </div>
          {computing && (
            <div className="mt-4 space-y-1.5">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Computing payslips…</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Stats */}
      {payslips.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { label: 'Employees', value: stats.total, icon: Users, color: 'text-foreground' },
            { label: 'With Structure', value: stats.computed, icon: CheckCircle2, color: 'text-green-600' },
            { label: 'No Structure', value: stats.no_structure, icon: AlertCircle, color: 'text-orange-500' },
            { label: 'Total Gross', value: fmtCcy(stats.total_gross, currency), icon: TrendingUp, color: 'text-primary' },
            { label: 'Total Deductions', value: fmtCcy(stats.total_ded, currency), icon: Minus, color: 'text-red-500' },
            { label: 'Total Net Pay', value: fmtCcy(stats.total_net, currency), icon: Wallet, color: 'text-emerald-600' },
          ].map(s => (
            <Card key={s.label} className="h-full">
              <CardContent className="p-3 flex items-center gap-2.5">
                <s.icon className={`h-4 w-4 shrink-0 ${s.color}`} />
                <div className="min-w-0">
                  <div className={`text-sm font-semibold truncate ${s.color}`}>{s.value}</div>
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Tabs */}
      {payslips.length > 0 && (
        <Tabs value={tab} onValueChange={v => setTab(v as typeof tab)}>
          <TabsList>
            <TabsTrigger value="overview"><BarChart2 className="h-3.5 w-3.5 mr-1.5" />Overview</TabsTrigger>
            <TabsTrigger value="payslips"><FileText className="h-3.5 w-3.5 mr-1.5" />Payslips</TabsTrigger>
            <TabsTrigger value="breakdown"><DollarSign className="h-3.5 w-3.5 mr-1.5" />Component Breakdown</TabsTrigger>
          </TabsList>

          {/* ── Overview tab ── */}
          <TabsContent value="overview" className="mt-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Computation Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Employee</TableHead>
                        <TableHead>Structure</TableHead>
                        <TableHead className="whitespace-nowrap">Gross Pay</TableHead>
                        <TableHead className="whitespace-nowrap">Deductions</TableHead>
                        <TableHead className="whitespace-nowrap">Net Pay</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loading ? (
                        Array.from({ length: 6 }).map((_, i) => (
                          <TableRow key={i}><TableCell colSpan={7}><Skeleton className="h-8 w-full" /></TableCell></TableRow>
                        ))
                      ) : filtered.length === 0 ? (
                        <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-10">No results</TableCell></TableRow>
                      ) : filtered.map(ps => (
                        <TableRow key={ps.employee.id} className={ps.status === 'no_structure' ? 'opacity-50' : ''}>
                          <TableCell className="whitespace-nowrap font-medium">
                            {ps.employee.first_name} {ps.employee.last_name}
                            <span className="ml-1 text-xs text-muted-foreground">#{ps.employee.employee_no}</span>
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-sm">
                            {ps.structure?.name ?? <span className="text-orange-500 text-xs">No structure</span>}
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{fmtCcy(ps.gross, currency)}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm text-red-600">{fmtCcy(ps.deductions, currency)}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm font-semibold text-emerald-600">{fmtCcy(ps.net, currency)}</TableCell>
                          <TableCell>
                            <Badge className={`text-xs ${
                              ps.status === 'existing' ? 'bg-blue-100 text-blue-800' :
                              ps.status === 'computed' ? 'bg-green-100 text-green-800' :
                              'bg-orange-100 text-orange-800'
                            }`}>
                              {ps.status === 'existing' ? 'Saved' : ps.status === 'computed' ? 'Computed' : 'No Structure'}
                            </Badge>
                            {ps.record && (
                              <Badge className={`ml-1 text-xs capitalize ${PAY_BADGE[ps.record.payment_status]}`}>
                                {ps.record.payment_status}
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            {ps.status !== 'no_structure' && (
                              <div className="flex items-center gap-1">
                                <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => setViewSlip(ps)}>
                                  <Eye className="h-3.5 w-3.5" />
                                </Button>
                                <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => { if (period) printPayslip(ps, period, currency); }}>
                                  <Printer className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ── Payslips tab ── */}
          <TabsContent value="payslips" className="mt-4">
            <div className="flex items-center gap-2 mb-3">
              <Input
                placeholder="Search employee…"
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="max-w-xs"
              />
              <span className="text-sm text-muted-foreground">{filtered.filter(p => p.status !== 'no_structure').length} payslips</span>
            </div>
            <div className="space-y-3">
              {filtered.filter(p => p.status !== 'no_structure').map(ps => {
                const expanded = expandedRows.has(ps.employee.id);
                return (
                  <Card key={ps.employee.id}>
                    <div
                      className="p-4 flex items-center justify-between cursor-pointer hover:bg-muted/30 transition-colors rounded-t-lg"
                      onClick={() => toggleRow(ps.employee.id)}
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center h-9 w-9 rounded-full bg-primary/10 text-primary font-semibold text-sm shrink-0">
                          {ps.employee.first_name[0]}{ps.employee.last_name[0]}
                        </div>
                        <div>
                          <div className="font-medium text-sm">{ps.employee.first_name} {ps.employee.last_name}</div>
                          <div className="text-xs text-muted-foreground">#{ps.employee.employee_no} · {ps.structure?.name}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right hidden md:block">
                          <div className="text-xs text-muted-foreground">Gross</div>
                          <div className="text-sm font-medium">{fmtCcy(ps.gross, currency)}</div>
                        </div>
                        <div className="text-right hidden md:block">
                          <div className="text-xs text-muted-foreground">Deductions</div>
                          <div className="text-sm font-medium text-red-600">-{fmtCcy(ps.deductions, currency)}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-xs text-muted-foreground">Net Pay</div>
                          <div className="text-base font-bold text-emerald-600">{fmtCcy(ps.net, currency)}</div>
                        </div>
                        {expanded ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
                      </div>
                    </div>
                    {expanded && (
                      <div className="px-4 pb-4 border-t border-border">
                        <div className="mt-3 space-y-1">
                          {ps.lines.filter(l => !l.is_bold || l.type === 'net').map((line, idx) => (
                            line.is_bold && line.type !== 'net' ? (
                              <div key={idx} className="pt-2 pb-0.5">
                                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{line.label}</span>
                              </div>
                            ) : (
                              <div key={idx} className={`flex justify-between py-1 ${line.type === 'net' ? 'border-t-2 border-border mt-2 pt-2' : 'pl-2'}`}>
                                <span className={`text-sm ${line.is_bold ? 'font-semibold' : ''}`}>{line.label}</span>
                                <span className={`text-sm font-medium ${
                                  line.type === 'deduction' ? 'text-red-600' :
                                  line.type === 'net' ? 'text-emerald-600 font-bold text-base' : ''
                                }`}>
                                  {line.type === 'deduction' ? '-' : ''}{fmtCcy(line.amount, currency)}
                                </span>
                              </div>
                            )
                          ))}
                        </div>
                        <div className="flex justify-end gap-2 mt-3">
                          <Button size="sm" variant="outline" className="gap-1.5 h-8" onClick={() => setViewSlip(ps)}>
                            <Eye className="h-3.5 w-3.5" />Preview
                          </Button>
                          <Button size="sm" variant="outline" className="gap-1.5 h-8" onClick={() => { if (period) printPayslip(ps, period, currency); }}>
                            <Printer className="h-3.5 w-3.5" />Print
                          </Button>
                        </div>
                      </div>
                    )}
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* ── Component Breakdown tab ── */}
          <TabsContent value="breakdown" className="mt-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Payroll Component Summary</CardTitle>
              </CardHeader>
              <CardContent>
                {/* Aggregate component totals across all payslips */}
                {(() => {
                  const compMap = new Map<string, { label: string; type: string; total: number }>();
                  for (const ps of payslips.filter(p => p.status !== 'no_structure')) {
                    for (const line of ps.lines) {
                      if (line.is_bold) continue;
                      const key = line.label;
                      const existing = compMap.get(key);
                      if (existing) existing.total += line.amount;
                      else compMap.set(key, { label: line.label, type: line.type, total: line.amount });
                    }
                  }
                  const rows = Array.from(compMap.values()).sort((a, b) => b.total - a.total);
                  return (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Component</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead className="whitespace-nowrap">Total Amount</TableHead>
                            <TableHead className="whitespace-nowrap">% of Gross</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {rows.map(r => (
                            <TableRow key={r.label}>
                              <TableCell className="font-medium text-sm">{r.label}</TableCell>
                              <TableCell>
                                <Badge className={`text-xs capitalize ${
                                  r.type === 'earning' ? 'bg-green-100 text-green-800' :
                                  r.type === 'deduction' ? 'bg-red-100 text-red-800' :
                                  'bg-blue-100 text-blue-800'
                                }`}>{r.type}</Badge>
                              </TableCell>
                              <TableCell className={`whitespace-nowrap font-medium ${r.type === 'deduction' ? 'text-red-600' : ''}`}>
                                {r.type === 'deduction' ? '-' : ''}{fmtCcy(r.total, currency)}
                              </TableCell>
                              <TableCell className="text-sm text-muted-foreground">
                                {stats.total_gross > 0 ? `${((r.total / stats.total_gross) * 100).toFixed(1)}%` : '—'}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  );
                })()}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}

      {/* Empty state */}
      {!loading && !computing && payslips.length === 0 && selPeriod && (
        <Card>
          <CardContent className="py-16 flex flex-col items-center gap-3 text-center">
            <Wallet className="h-12 w-12 text-muted-foreground/40" />
            <p className="text-muted-foreground">Select a payroll period and click <strong>Compute Payslips</strong> to begin.</p>
            <p className="text-xs text-muted-foreground">
              Salary structures will be applied, statutory deductions calculated, and payslips generated for all active employees.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Payslip Detail Dialog */}
      <Dialog open={!!viewSlip} onOpenChange={open => { if (!open) setViewSlip(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Payslip — {viewSlip && `${viewSlip.employee.first_name} ${viewSlip.employee.last_name}`}
            </DialogTitle>
          </DialogHeader>
          {viewSlip && period && (
            <div className="space-y-3">
              {/* Employee info */}
              <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm bg-muted/30 rounded-lg p-3">
                <div><span className="text-muted-foreground">Employee No:</span> <span className="font-medium">{viewSlip.employee.employee_no}</span></div>
                <div><span className="text-muted-foreground">Period:</span> <span className="font-medium">{period.name}</span></div>
                <div><span className="text-muted-foreground">Structure:</span> <span className="font-medium">{viewSlip.structure?.name ?? '—'}</span></div>
                <div><span className="text-muted-foreground">Currency:</span> <span className="font-medium">{currency}</span></div>
              </div>
              <Separator />
              {/* Line items */}
              <div className="space-y-1">
                {viewSlip.lines.filter(l => !l.is_bold || l.type === 'net').map((line, idx) =>
                  line.is_bold && line.type !== 'net' ? (
                    <div key={idx} className="pt-2">
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{line.label}</span>
                    </div>
                  ) : (
                    <div key={idx} className={`flex justify-between py-1 ${line.type === 'net' ? 'border-t-2 border-border mt-1 pt-2' : 'pl-2'}`}>
                      <span className={`text-sm ${line.is_bold ? 'font-semibold' : ''}`}>{line.label}</span>
                      <span className={`text-sm font-medium ${
                        line.type === 'deduction' ? 'text-red-600' :
                        line.type === 'net' ? 'text-emerald-600 font-bold text-base' : ''
                      }`}>
                        {line.type === 'deduction' ? '-' : ''}{fmtCcy(line.amount, currency)}
                      </span>
                    </div>
                  )
                )}
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setViewSlip(null)}>Close</Button>
                <Button className="gap-2" onClick={() => { printPayslip(viewSlip, period, currency); }}>
                  <Printer className="h-4 w-4" />Print Payslip
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ── suppress unused import warning ──
const _unused = { Download, Plus };
void _unused;
