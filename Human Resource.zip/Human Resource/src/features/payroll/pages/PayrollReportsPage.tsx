import { useState, useEffect, useCallback } from 'react';
import { payrollService } from '@/services/payroll.service';
import type { PayrollPeriod, PayrollRecord } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { RefreshCw, BarChart2, Building2, TrendingUp } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, LineChart, Line,
} from 'recharts';

const fmtCurrency = (n: number) =>
  `ብር ${Number(n||0).toLocaleString('en-US',{maximumFractionDigits:0})}`;

const fmtDate = (d?: string) =>
  d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

interface DeptRow { department: string; headcount: number; gross: number; net: number; deductions: number; }
interface MonthlyRow { period: string; gross: number; net: number; deductions: number; count: number; }

export function PayrollReportsPage() {
  const [periods, setPeriods]     = useState<PayrollPeriod[]>([]);
  const [selPeriod, setSelPeriod] = useState<string>('all');
  const [records,  setRecords]    = useState<PayrollRecord[]>([]);
  const [loading,  setLoading]    = useState(true);
  const [summary,  setSummary]    = useState({ total_gross: 0, total_net: 0, total_deductions: 0, total_records: 0, paid_count: 0 });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const pRes = await payrollService.listPeriods({ page: 1, pageSize: 50 });
      setPeriods(pRes.data);

      const rRes = await payrollService.listRecords({
        period_id: selPeriod !== 'all' ? selPeriod : undefined,
        page: 1, pageSize: 500,
      });
      setRecords(rRes.data);

      const sum = await payrollService.getPayrollSummary(selPeriod !== 'all' ? selPeriod : undefined);
      setSummary(sum);
    } catch { toast.error('Failed to load reports'); }
    finally { setLoading(false); }
  }, [selPeriod]);

  useEffect(() => { load(); }, [load]);

  /* ── Department Cost breakdown ── */
  const deptMap: Record<string, DeptRow> = {};
  for (const r of records) {
    const emp  = r.employee as { department?: { name?: string } } | undefined;
    const dept = (emp as Record<string, unknown>)?.department_name as string | undefined
      ?? (emp?.department as { name?: string })?.name
      ?? 'Unknown';
    if (!deptMap[dept]) deptMap[dept] = { department: dept, headcount: 0, gross: 0, net: 0, deductions: 0 };
    deptMap[dept].headcount++;
    deptMap[dept].gross      += Number(r.gross_pay)        || 0;
    deptMap[dept].net        += Number(r.net_pay)          || 0;
    deptMap[dept].deductions += Number(r.total_deductions) || 0;
  }
  const deptData: DeptRow[] = Object.values(deptMap).sort((a, b) => b.gross - a.gross);

  /* ── Monthly trend ── */
  const monthlyMap: Record<string, MonthlyRow> = {};
  for (const r of records) {
    const p = r.payroll_period as { period_code?: string } | undefined;
    const key = p?.period_code ?? 'Unknown';
    if (!monthlyMap[key]) monthlyMap[key] = { period: key, gross: 0, net: 0, deductions: 0, count: 0 };
    monthlyMap[key].gross      += Number(r.gross_pay)        || 0;
    monthlyMap[key].net        += Number(r.net_pay)          || 0;
    monthlyMap[key].deductions += Number(r.total_deductions) || 0;
    monthlyMap[key].count++;
  }
  const monthlyData: MonthlyRow[] = Object.values(monthlyMap).sort((a, b) => a.period.localeCompare(b.period)).slice(-12);

  /* ── YTD summary ── */
  const currentYear = new Date().getFullYear();
  const ytdPeriods  = periods.filter(p => p.start_date?.startsWith(String(currentYear)));
  const ytdGross    = records.filter(r => ytdPeriods.find(p => p.id === r.payroll_period_id))
    .reduce((s, r) => s + (Number(r.gross_pay) || 0), 0);
  const ytdNet = records.filter(r => ytdPeriods.find(p => p.id === r.payroll_period_id))
    .reduce((s, r) => s + (Number(r.net_pay) || 0), 0);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-balance">Payroll Reports</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Analytics and cost breakdown</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selPeriod} onValueChange={v => { setSelPeriod(v); }}>
            <SelectTrigger className="w-48"><SelectValue placeholder="All periods" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Periods</SelectItem>
              {periods.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
        </div>
      </div>

      {/* Summary KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: 'Employees',       value: summary.total_records },
          { label: 'Paid',            value: summary.paid_count },
          { label: 'Total Gross',     value: fmtCurrency(summary.total_gross) },
          { label: 'Deductions',      value: fmtCurrency(summary.total_deductions) },
          { label: 'Total Net',       value: fmtCurrency(summary.total_net) },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3">
            <p className="text-xs text-muted-foreground">{s.label}</p>
            <p className={`text-base font-bold leading-tight mt-0.5 ${s.label === 'Total Net' ? 'text-primary' : ''}`}>{s.value}</p>
          </div>
        ))}
      </div>

      <Tabs defaultValue="monthly">
        <TabsList className="h-9">
          <TabsTrigger value="monthly"><BarChart2 className="h-3.5 w-3.5 mr-1.5" />Monthly Trend</TabsTrigger>
          <TabsTrigger value="department"><Building2 className="h-3.5 w-3.5 mr-1.5" />By Department</TabsTrigger>
          <TabsTrigger value="ytd"><TrendingUp className="h-3.5 w-3.5 mr-1.5" />Year-to-Date</TabsTrigger>
        </TabsList>

        {/* Monthly trend */}
        <TabsContent value="monthly" className="mt-4 space-y-4">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Gross vs Net Pay — Monthly</CardTitle></CardHeader>
            <CardContent>
              {loading ? <Skeleton className="h-64 w-full bg-muted" />
              : monthlyData.length === 0 ? <div className="h-40 flex items-center justify-center text-muted-foreground">No data available</div>
              : (
                <div className="w-full min-w-0 overflow-hidden">
                  <ResponsiveContainer width="100%" height={280}>
                    <BarChart data={monthlyData} margin={{ top: 4, right: 16, left: 0, bottom: 4 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="period" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
                      <Tooltip formatter={(v: number) => fmtCurrency(v)} />
                      <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8 }} />
                      <Bar dataKey="gross"      name="Gross Pay"    fill="hsl(var(--primary))"   radius={[3, 3, 0, 0]} />
                      <Bar dataKey="net"        name="Net Pay"      fill="hsl(142 71% 45%)"      radius={[3, 3, 0, 0]} />
                      <Bar dataKey="deductions" name="Deductions"   fill="hsl(0 72% 51%)"        radius={[3, 3, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Headcount Trend</CardTitle></CardHeader>
            <CardContent>
              {loading ? <Skeleton className="h-48 w-full bg-muted" />
              : monthlyData.length === 0 ? <div className="h-32 flex items-center justify-center text-muted-foreground">No data</div>
              : (
                <div className="w-full min-w-0 overflow-hidden">
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={monthlyData} margin={{ top: 4, right: 16, left: 0, bottom: 4 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="period" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8 }} />
                      <Line type="monotone" dataKey="count" name="Employees" stroke="hsl(var(--primary))" strokeWidth={2} dot />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Monthly table */}
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Period</TableHead>
                    <TableHead className="whitespace-nowrap">Employees</TableHead>
                    <TableHead className="whitespace-nowrap">Gross Pay</TableHead>
                    <TableHead className="whitespace-nowrap">Deductions</TableHead>
                    <TableHead className="whitespace-nowrap">Net Pay</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 4 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 5 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>
                  )) : monthlyData.length === 0 ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No data</TableCell></TableRow>
                  ) : monthlyData.map(r => (
                    <TableRow key={r.period}>
                      <TableCell className="whitespace-nowrap font-medium">{r.period}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.count}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-semibold">{fmtCurrency(r.gross)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-red-600">{fmtCurrency(r.deductions)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-bold text-primary">{fmtCurrency(r.net)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* Department breakdown */}
        <TabsContent value="department" className="mt-4 space-y-4">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Gross Pay by Department</CardTitle></CardHeader>
            <CardContent>
              {loading ? <Skeleton className="h-64 w-full bg-muted" />
              : deptData.length === 0 ? <div className="h-40 flex items-center justify-center text-muted-foreground">No data</div>
              : (
                <div className="w-full min-w-0 overflow-hidden">
                  <ResponsiveContainer width="100%" height={280}>
                    <BarChart data={deptData} margin={{ top: 4, right: 16, left: 0, bottom: 4 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="department" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
                      <Tooltip formatter={(v: number) => fmtCurrency(v)} />
                      <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8 }} />
                      <Bar dataKey="gross" name="Gross Pay" fill="hsl(var(--primary))" radius={[3, 3, 0, 0]} />
                      <Bar dataKey="net"   name="Net Pay"   fill="hsl(142 71% 45%)"    radius={[3, 3, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Department</TableHead>
                    <TableHead className="whitespace-nowrap">Headcount</TableHead>
                    <TableHead className="whitespace-nowrap">Gross Pay</TableHead>
                    <TableHead className="whitespace-nowrap">Deductions</TableHead>
                    <TableHead className="whitespace-nowrap">Net Pay</TableHead>
                    <TableHead className="whitespace-nowrap">Avg. Gross</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>
                  )) : deptData.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No data</TableCell></TableRow>
                  ) : deptData.map(d => (
                    <TableRow key={d.department}>
                      <TableCell className="whitespace-nowrap font-medium">{d.department}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{d.headcount}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-semibold">{fmtCurrency(d.gross)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-red-600">{fmtCurrency(d.deductions)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-bold text-primary">{fmtCurrency(d.net)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{fmtCurrency(d.headcount > 0 ? d.gross / d.headcount : 0)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* YTD */}
        <TabsContent value="ytd" className="mt-4 space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: `YTD Runs (${currentYear})`, value: ytdPeriods.length },
              { label: 'YTD Gross',                 value: fmtCurrency(ytdGross)  },
              { label: 'YTD Net',                   value: fmtCurrency(ytdNet)    },
              { label: 'YTD Deductions',            value: fmtCurrency(ytdGross - ytdNet) },
            ].map(s => (
              <div key={s.label} className="bg-card border border-border rounded-lg p-4">
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className="text-xl font-bold leading-tight mt-1">{s.value}</p>
              </div>
            ))}
          </div>

          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Period</TableHead>
                    <TableHead className="whitespace-nowrap">Type</TableHead>
                    <TableHead className="whitespace-nowrap">Dates</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Payment Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 5 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>
                  )) : ytdPeriods.length === 0 ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-10 text-muted-foreground">No runs for {currentYear}</TableCell></TableRow>
                  ) : ytdPeriods.map(p => (
                    <TableRow key={p.id}>
                      <TableCell className="whitespace-nowrap font-medium">{p.name}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm capitalize">{p.period_type?.replace('_', '-')}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{fmtDate(p.start_date)} – {fmtDate(p.end_date)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm capitalize">{p.status}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{fmtDate(p.payment_date)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
