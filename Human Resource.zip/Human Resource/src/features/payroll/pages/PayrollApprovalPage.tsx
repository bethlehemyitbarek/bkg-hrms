import { useState, useEffect, useCallback } from 'react';
import { payrollService } from '@/services/payroll.service';
import type { PayrollPeriod } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { RefreshCw, Check, X, Clock, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const fmtCurrency = (n: number) =>
  `ብር ${Number(n||0).toLocaleString('en-US',{maximumFractionDigits:0})}`;

const fmtDate = (d?: string) =>
  d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

export function PayrollApprovalPage() {
  const navigate = useNavigate();
  const [pending,   setPending]   = useState<PayrollPeriod[]>([]);
  const [approved,  setApproved]  = useState<PayrollPeriod[]>([]);
  const [summaries, setSummaries] = useState<Record<string, { total_gross: number; total_net: number; total_records: number }>>({});
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [pendingRes, approvedRes] = await Promise.all([
        payrollService.listPeriods({ status: 'processing', page: 1, pageSize: 50 }),
        payrollService.listPeriods({ status: 'approved',   page: 1, pageSize: 20 }),
      ]);
      setPending(pendingRes.data);
      setApproved(approvedRes.data);

      // load summaries for pending runs
      const sums: typeof summaries = {};
      await Promise.all(pendingRes.data.map(async (p) => {
        try { sums[p.id] = await payrollService.getPayrollSummary(p.id); } catch { /* skip */ }
      }));
      setSummaries(sums);
    } catch { toast.error('Failed to load approval queue'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleApprove = async (p: PayrollPeriod) => {
    try {
      await payrollService.updatePeriodStatus(p.id, 'approved');
      toast.success(`"${p.name}" approved`);
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
  };

  const handleReject = async (p: PayrollPeriod) => {
    try {
      await payrollService.updatePeriodStatus(p.id, 'draft');
      toast.success(`"${p.name}" returned to draft`);
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
  };

  const handleMarkPaid = async (p: PayrollPeriod) => {
    try {
      await payrollService.updatePeriodStatus(p.id, 'paid');
      toast.success(`"${p.name}" marked as paid`);
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-balance">Payroll Approval</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{pending.length} pending approval</p>
        </div>
        <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Awaiting Approval', value: pending.length,  icon: Clock,        color: 'text-yellow-600' },
          { label: 'Approved',          value: approved.length, icon: CheckCircle2, color: 'text-green-600'  },
          { label: 'Total Gross (Pending)', value: fmtCurrency(Object.values(summaries).reduce((s, v) => s + v.total_gross, 0)), icon: Check, color: 'text-primary' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3 flex items-center gap-2.5">
            <s.icon className={`h-5 w-5 shrink-0 ${s.color}`} />
            <div><p className="text-xs text-muted-foreground">{s.label}</p><p className="text-lg font-bold leading-tight">{s.value}</p></div>
          </div>
        ))}
      </div>

      {/* Pending approval */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2"><Clock className="h-4 w-4 text-yellow-600" />Pending Approval</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Period</TableHead>
                  <TableHead className="whitespace-nowrap">Dates</TableHead>
                  <TableHead className="whitespace-nowrap">Employees</TableHead>
                  <TableHead className="whitespace-nowrap">Gross Pay</TableHead>
                  <TableHead className="whitespace-nowrap">Net Pay</TableHead>
                  <TableHead className="whitespace-nowrap">Payment Date</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? Array.from({ length: 3 }).map((_, i) => (
                  <TableRow key={i}>{Array.from({ length: 7 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>
                )) : pending.length === 0 ? (
                  <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">
                    <CheckCircle2 className="h-8 w-8 mx-auto mb-2 opacity-40" />No payroll runs awaiting approval
                  </TableCell></TableRow>
                ) : pending.map(p => {
                  const sum = summaries[p.id];
                  return (
                    <TableRow key={p.id}>
                      <TableCell className="whitespace-nowrap font-medium cursor-pointer hover:text-primary" onClick={() => navigate(`/payroll/runs/${p.id}`)}>
                        {p.name}<span className="text-xs text-muted-foreground ml-1">({p.period_code})</span>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{fmtDate(p.start_date)} – {fmtDate(p.end_date)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{sum?.total_records ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-semibold">{sum ? fmtCurrency(sum.total_gross) : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-semibold text-primary">{sum ? fmtCurrency(sum.total_net) : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{fmtDate(p.payment_date)}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex items-center gap-1">
                          <Button size="sm" className="h-7 px-2 bg-green-600 hover:bg-green-700" onClick={() => handleApprove(p)}>
                            <Check className="h-3.5 w-3.5 mr-1" />Approve
                          </Button>
                          <Button size="sm" variant="outline" className="h-7 px-2 text-red-500 border-red-200 hover:bg-red-50" onClick={() => handleReject(p)}>
                            <X className="h-3.5 w-3.5 mr-1" />Return
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Approved — ready for payment */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-green-600" />Approved — Ready for Payment</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Period</TableHead>
                  <TableHead className="whitespace-nowrap">Payment Date</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? Array.from({ length: 3 }).map((_, i) => (
                  <TableRow key={i}>{Array.from({ length: 4 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>
                )) : approved.length === 0 ? (
                  <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No approved runs yet</TableCell></TableRow>
                ) : approved.map(p => (
                  <TableRow key={p.id}>
                    <TableCell className="whitespace-nowrap font-medium cursor-pointer hover:text-primary" onClick={() => navigate(`/payroll/runs/${p.id}`)}>
                      {p.name} <span className="text-xs text-muted-foreground">({p.period_code})</span>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtDate(p.payment_date)}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className="bg-purple-100 text-purple-800 text-xs">Approved</Badge></TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Button size="sm" className="h-7 px-3 text-xs" onClick={() => handleMarkPaid(p)}>Mark as Paid</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
