import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { payrollService, salaryStructureService } from '@/services/payroll.service';
import type { EmployeeSalaryStructure, SalaryStructure } from '@/services/payroll.service';
import type { PayrollPeriod, PayrollRecord } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Plus, RefreshCw, ArrowLeft, Pencil, ChevronRight, Wallet, Zap, FileDown } from 'lucide-react';
import { generatePayslipPdf } from '@/utils/payslipPdf';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const STATUS_COLORS: Record<string, string> = {
  draft:      'bg-muted text-muted-foreground',
  processing: 'bg-blue-100 text-blue-800',
  approved:   'bg-purple-100 text-purple-800',
  paid:       'bg-green-100 text-green-800',
  cancelled:  'bg-red-100 text-red-800',
};

const fmtCurrency = (n: number | string | null | undefined) =>
  `ብር ${Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}`;

const fmtDate = (d?: string) =>
  d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

const PAYMENT_STATUS_NEXT: Record<string, string> = {
  pending: 'paid',
  paid:    'reversed',
};

const emptyRecord = {
  employee_id: '', basic_salary: '', overtime_pay: '', allowances: '',
  tax_deduction: '', social_security: '', provident_fund: '', other_deductions: '',
  notes: '', payment_status: 'pending',
};

type OTSourceInfo = { request: number; timesheet: number; used: number };

export function PayrollRunDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [period,  setPeriod]  = useState<PayrollPeriod | null>(null);
  const [records, setRecords] = useState<PayrollRecord[]>([]);
  const [summary, setSummary] = useState({ total_gross: 0, total_net: 0, total_deductions: 0, total_records: 0, paid_count: 0 });
  const [loading, setLoading] = useState(true);
  const [saving,  setSaving]  = useState(false);
  const [autoCalcBusy, setAutoCalcBusy] = useState(false);
  const [otSourceMap, setOtSourceMap] = useState<Map<string, OTSourceInfo>>(new Map());
  const [autoCalcOpen, setAutoCalcOpen] = useState(false);

  const [createOpen, setCreateOpen] = useState(false);
  const [editRecord, setEditRecord] = useState<PayrollRecord | null>(null);
  const [form, setForm] = useState({ ...emptyRecord });

  const loadData = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const [p, res, sum] = await Promise.all([
        payrollService.getPeriod(id),
        payrollService.listRecords({ period_id: id, page: 1, pageSize: 100 }),
        payrollService.getPayrollSummary(id),
      ]);
      setPeriod(p);
      setRecords(res.data);
      setSummary(sum);
    } catch { toast.error('Failed to load payroll run'); }
    finally { setLoading(false); }
  }, [id]);

  useEffect(() => { loadData(); }, [loadData]);

  const calcGross = (f: typeof form) => {
    return (Number(f.basic_salary) || 0) + (Number(f.overtime_pay) || 0) + (Number(f.allowances) || 0);
  };
  const calcDeductions = (f: typeof form) => {
    return (Number(f.tax_deduction) || 0) + (Number(f.social_security) || 0) + (Number(f.provident_fund) || 0) + (Number(f.other_deductions) || 0);
  };
  const calcNet = (f: typeof form) => calcGross(f) - calcDeductions(f);

  /** Auto-calculate payroll for all employees based on salary structures + approved overtime */
  const handleAutoCalc = async () => {
    if (!id || !period) return;
    setAutoCalcBusy(true);
    setAutoCalcOpen(false);
    try {
      // Fetch salary structure assignments, structures, and approved overtime in parallel
      const { supabase } = await import('@/db/supabase');
      const [assignments, allStructures, overtimeResult, timesheetResult] = await Promise.all([
        salaryStructureService.listAssignments(),
        salaryStructureService.list(),
        // Fetch approved overtime requests that overlap the payroll period
        (supabase as any)
          .from('overtime_requests')
          .select('employee_id, hours, requested_date')
          .eq('status', 'approved')
          .gte('requested_date', period.start_date)
          .lte('requested_date', period.end_date),
        // Fetch approved timesheets whose period overlaps the payroll period
        (supabase as any)
          .from('timesheets')
          .select('employee_id, overtime_hours, period_start, period_end')
          .eq('status', 'approved')
          .lte('period_start', period.end_date)
          .gte('period_end',   period.start_date),
      ]);

      // Build maps
      const structureMap = new Map<string, SalaryStructure>(allStructures.map(s => [s.id, s]));
      const assignMap = new Map<string, EmployeeSalaryStructure>(assignments.map(a => [a.employee_id, a]));

      // Aggregate OT hours from overtime_requests
      const otRequestMap = new Map<string, number>();
      for (const ot of (overtimeResult.data ?? [])) {
        otRequestMap.set(ot.employee_id, (otRequestMap.get(ot.employee_id) ?? 0) + Number(ot.hours || 0));
      }

      // Aggregate OT hours from approved timesheets
      const otTimesheetMap = new Map<string, number>();
      for (const ts of (timesheetResult.data ?? [])) {
        const tsOt = Number(ts.overtime_hours || 0);
        if (tsOt > 0) {
          otTimesheetMap.set(ts.employee_id, (otTimesheetMap.get(ts.employee_id) ?? 0) + tsOt);
        }
      }

      // De-duplicate: use MAX of the two sources per employee to prevent double-counting
      // when the same OT is recorded in both overtime_requests and timesheets
      const allEmpIds   = new Set([...otRequestMap.keys(), ...otTimesheetMap.keys()]);
      const otHoursMap  = new Map<string, number>();
      const newOtSrcMap = new Map<string, OTSourceInfo>();
      for (const empId of allEmpIds) {
        const reqHrs = otRequestMap.get(empId) ?? 0;
        const tsHrs  = otTimesheetMap.get(empId) ?? 0;
        const used   = Math.max(reqHrs, tsHrs);
        otHoursMap.set(empId, used);
        newOtSrcMap.set(empId, { request: reqHrs, timesheet: tsHrs, used });
      }
      setOtSourceMap(newOtSrcMap);

      if (assignMap.size === 0) {
        toast.warning('No salary structure assignments found. Assign structures first.');
        return;
      }

      let created = 0;
      let skipped = 0;
      const existingEmployeeIds = new Set(records.map(r => r.employee_id));

      for (const [employee_id, assignment] of assignMap) {
        if (existingEmployeeIds.has(employee_id)) { skipped++; continue; }

        const structure = structureMap.get(assignment.salary_structure_id);
        if (!structure) { skipped++; continue; }

        const comps = structure.salary_structure_components ?? [];
        let basic_salary = 0, allowances = 0;
        let tax_deduction = 0, social_security = 0, provident_fund = 0, other_deductions = 0;

        for (const c of comps) {
          const ctype  = c.payroll_component?.component_type;
          const amount = c.amount ?? 0;
          if (ctype === 'earning') {
            if ((c.payroll_component?.name ?? '').toLowerCase().includes('basic')) basic_salary += amount;
            else allowances += amount;
          } else if (ctype === 'deduction') {
            const name = (c.payroll_component?.name ?? '').toLowerCase();
            if (name.includes('tax'))           tax_deduction    += amount;
            else if (name.includes('social'))   social_security  += amount;
            else if (name.includes('provident')) provident_fund  += amount;
            else                                other_deductions += amount;
          }
        }

        // Calculate overtime pay from approved overtime requests
        // OT rate = basic_salary / (work_days_per_month * hours_per_day) * 1.5
        const approvedOtHours = otHoursMap.get(employee_id) ?? 0;
        const hourlyRate      = basic_salary > 0 ? basic_salary / (22 * 8) : 0;
        const overtime_pay    = Math.round(approvedOtHours * hourlyRate * 1.5 * 100) / 100;

        const gross_pay        = basic_salary + allowances + overtime_pay;
        const total_deductions = tax_deduction + social_security + provident_fund + other_deductions;
        const net_pay          = gross_pay - total_deductions;

        await payrollService.createRecord({
          employee_id,
          payroll_period_id: id,
          basic_salary,
          overtime_pay,
          allowances,
          tax_deduction,
          social_security,
          provident_fund,
          other_deductions,
          gross_pay,
          total_deductions,
          net_pay,
          payment_status: 'pending',
        });
        created++;
      }

      const otMsg = otHoursMap.size > 0 ? ` (${otHoursMap.size} employee${otHoursMap.size > 1 ? 's' : ''} with approved OT, de-duplicated)` : '';
      if (created > 0) toast.success(`Auto-calculated ${created} payroll record${created > 1 ? 's' : ''}${otMsg}`);
      if (skipped > 0)  toast.info(`${skipped} employee${skipped > 1 ? 's' : ''} skipped`);
      loadData();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Auto-calculation failed');
    } finally {
      setAutoCalcBusy(false);
    }
  };

  const openCreate = () => {
    setEditRecord(null);
    setForm({ ...emptyRecord });
    setCreateOpen(true);
  };
  const openEdit = (r: PayrollRecord) => {
    setEditRecord(r);
    setForm({
      employee_id: r.employee_id, basic_salary: String(r.basic_salary), overtime_pay: String(r.overtime_pay),
      allowances: String(r.allowances), tax_deduction: String(r.tax_deduction),
      social_security: String(r.social_security), provident_fund: String(r.provident_fund),
      other_deductions: String(r.other_deductions), notes: r.notes ?? '', payment_status: r.payment_status,
    });
    setCreateOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.employee_id || form.employee_id === 'none') { toast.error('Select an employee'); return; }
    setSaving(true);
    const gross_pay       = calcGross(form);
    const total_deductions = calcDeductions(form);
    const net_pay          = calcNet(form);
    const payload = {
      employee_id:       form.employee_id,
      payroll_period_id: id!,
      basic_salary:      Number(form.basic_salary) || 0,
      overtime_pay:      Number(form.overtime_pay) || 0,
      allowances:        Number(form.allowances)   || 0,
      tax_deduction:     Number(form.tax_deduction) || 0,
      social_security:   Number(form.social_security) || 0,
      provident_fund:    Number(form.provident_fund)   || 0,
      other_deductions:  Number(form.other_deductions) || 0,
      gross_pay, total_deductions, net_pay,
      payment_status:    form.payment_status as PayrollRecord['payment_status'],
      notes:             form.notes || undefined,
    };
    try {
      if (editRecord) {
        await payrollService.updateRecord(editRecord.id, payload);
        toast.success('Record updated');
      } else {
        await payrollService.createRecord(payload);
        toast.success('Record added');
      }
      setCreateOpen(false);
      loadData();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };

  const handlePaymentStatusUpdate = async (r: PayrollRecord) => {
    const next = PAYMENT_STATUS_NEXT[r.payment_status];
    if (!next) return;
    try {
      await payrollService.updateRecord(r.id, { payment_status: next as PayrollRecord['payment_status'] });
      toast.success(`Payment status → ${next}`);

      // Auto-send payslip email when transitioning to "paid"
      if (next === 'paid') {
        try {
          const { supabase } = await import('@/db/supabase');
          // Fetch employee email
          const { data: empData } = await (supabase as any)
            .from('employees')
            .select('id, first_name, last_name, work_email, personal_email')
            .eq('id', r.employee_id)
            .maybeSingle();

          const toEmail: string | null = empData?.work_email ?? empData?.personal_email ?? null;
          if (toEmail) {
            const emp = r.employee as { first_name?: string; last_name?: string } | undefined;
            const empName = emp ? `${emp.first_name ?? ''} ${emp.last_name ?? ''}`.trim() : (empData ? `${empData.first_name} ${empData.last_name}`.trim() : 'Employee');
            const periodLabel = period
              ? new Date(period.start_date).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
              : 'Payslip';

            // Generate PDF inline
            const { generatePayslipPdfBase64 } = await import('@/utils/payslipPdf');
            const pdfBase64 = await generatePayslipPdfBase64({
              employee: { name: empName, employee_no: (r.employee as any)?.employee_no ?? r.employee_id.slice(0, 8), department: undefined },
              period_label: periodLabel,
              basic_salary:     Number(r.basic_salary)     || 0,
              overtime_pay:     Number(r.overtime_pay)     || 0,
              allowances:       Number(r.allowances)       || 0,
              gross_pay:        Number(r.gross_pay)        || 0,
              tax_deduction:    Number(r.tax_deduction)    || 0,
              social_security:  Number(r.social_security)  || 0,
              provident_fund:   Number(r.provident_fund)   || 0,
              other_deductions: Number(r.other_deductions) || 0,
              loan_deductions:  0,
              total_deductions: Number(r.total_deductions) || 0,
              net_pay:          Number(r.net_pay)          || 0,
            });

            const { error: emailErr } = await supabase.functions.invoke('send-payslip-email', {
              body: {
                to_email:          toEmail,
                employee_name:     empName,
                period_name:       period?.name ?? periodLabel,
                pdf_base64:        pdfBase64,
                net_pay:           Number(r.net_pay) || undefined,
                currency:          'ETB',
                payroll_record_id: r.id,
                employee_id:       r.employee_id,
              },
            });
            if (emailErr) {
              const msg = await emailErr?.context?.text?.();
              console.error('Auto-email payslip error:', msg || emailErr.message);
              toast.warning('Status updated, but payslip email failed to send');
            } else {
              toast.success(`Payslip emailed to ${toEmail}`);
            }
          }
        } catch (emailEx) {
          console.error('Auto-email payslip error:', emailEx);
          toast.warning('Status updated, but payslip auto-email encountered an error');
        }
      }

      loadData();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
  };

  if (!loading && !period) {
    return <div className="text-center py-20 text-muted-foreground">Payroll run not found</div>;
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <Button variant="outline" size="sm" className="mt-0.5 shrink-0" onClick={() => navigate('/payroll/runs')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-balance">{period?.name ?? 'Payroll Run'}</h1>
              {period && <Badge className={`text-xs capitalize ${STATUS_COLORS[period.status]}`}>{period.status}</Badge>}
            </div>
            <p className="text-sm text-muted-foreground mt-0.5">
              {period ? `${fmtDate(period.start_date)} — ${fmtDate(period.end_date)}` : ''}
              {period?.payment_date ? ` · Payment: ${fmtDate(period.payment_date)}` : ''}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Button variant="outline" size="sm" onClick={loadData}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
          {/* Auto-Calculate button */}
          <Button
            variant="secondary"
            size="sm"
            disabled={autoCalcBusy}
            onClick={() => setAutoCalcOpen(true)}
            className="gap-1.5"
          >
            <Zap className={`h-4 w-4 ${autoCalcBusy ? 'animate-pulse' : ''}`} />
            {autoCalcBusy ? 'Calculating…' : 'Auto-Calculate'}
          </Button>
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1.5" />Add Record</Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-xl">
              <DialogHeader><DialogTitle>{editRecord ? 'Edit' : 'Add'} Payroll Record</DialogTitle></DialogHeader>
              <form onSubmit={handleSave} className="space-y-4 mt-2">
                <EmployeeSelect value={form.employee_id} onChange={v => setForm(p => ({ ...p, employee_id: v }))} required />
                <div className="grid grid-cols-2 gap-4">
                  {[
                    ['Basic Salary', 'basic_salary'], ['Overtime Pay', 'overtime_pay'],
                    ['Allowances',   'allowances'],   ['Income Tax',   'tax_deduction'],
                    ['Social Security','social_security'], ['Provident Fund','provident_fund'],
                    ['Other Deductions','other_deductions'],
                  ].map(([label, key]) => (
                    <div key={key} className="space-y-1.5">
                      <Label>{label}</Label>
                      <Input type="number" min="0" step="0.01" value={form[key as keyof typeof form] as string}
                        onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))} placeholder="0.00" />
                    </div>
                  ))}
                  <div className="space-y-1.5">
                    <Label>Payment Status</Label>
                    <Select value={form.payment_status} onValueChange={v => setForm(p => ({ ...p, payment_status: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="paid">Paid</SelectItem>
                        <SelectItem value="held">Held</SelectItem>
                        <SelectItem value="reversed">Reversed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                {/* Live calc preview */}
                <div className="bg-muted/40 rounded-lg p-3 grid grid-cols-3 gap-3 text-center">
                  {[['Gross Pay', calcGross(form)], ['Deductions', calcDeductions(form)], ['Net Pay', calcNet(form)]].map(([label, val]) => (
                    <div key={label as string}>
                      <p className="text-xs text-muted-foreground">{label}</p>
                      <p className="font-bold text-sm">{fmtCurrency(val as number)}</p>
                    </div>
                  ))}
                </div>
                <div className="space-y-1.5"><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} rows={2} /></div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
                  <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save'}</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: 'Employees', value: summary.total_records },
          { label: 'Paid',      value: summary.paid_count },
          { label: 'Total Gross',  value: fmtCurrency(summary.total_gross) },
          { label: 'Deductions',   value: fmtCurrency(summary.total_deductions) },
          { label: 'Total Net',    value: fmtCurrency(summary.total_net) },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3">
            <p className="text-xs text-muted-foreground">{s.label}</p>
            <p className="text-base font-bold leading-tight mt-0.5">{s.value}</p>
          </div>
        ))}
      </div>

      {/* Records table */}
      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Basic</TableHead>
                <TableHead className="whitespace-nowrap">OT Pay</TableHead>
                <TableHead className="whitespace-nowrap">OT Source</TableHead>
                <TableHead className="whitespace-nowrap">Allowances</TableHead>
                <TableHead className="whitespace-nowrap">Gross</TableHead>
                <TableHead className="whitespace-nowrap">Deductions</TableHead>
                <TableHead className="whitespace-nowrap">Net Pay</TableHead>
                <TableHead className="whitespace-nowrap">Payment</TableHead>
                <TableHead className="whitespace-nowrap">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? Array.from({ length: 6 }).map((_, i) => (
                <TableRow key={i}>{Array.from({ length: 9 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>
              )) : records.length === 0 ? (
                <TableRow><TableCell colSpan={9} className="text-center py-12 text-muted-foreground">
                  <Wallet className="h-10 w-10 mx-auto mb-2 opacity-40" />No records yet. Add payroll records above.
                </TableCell></TableRow>
              ) : records.map(r => {
                const emp = r.employee;
                return (
                  <TableRow key={r.id}>
                    <TableCell className="whitespace-nowrap font-medium text-sm">
                      {emp ? `${emp.first_name} ${emp.last_name}` : r.employee_id.slice(0, 8)}
                      {emp && <span className="text-xs text-muted-foreground ml-1">#{emp.employee_no}</span>}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtCurrency(r.basic_salary)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtCurrency(r.overtime_pay)}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      {(() => {
                        const src = otSourceMap.get(r.employee_id);
                        if (!src || src.used === 0) return <span className="text-muted-foreground text-xs">—</span>;
                        return (
                          <div className="text-xs space-y-0.5" title={`Used: ${src.used}h (MAX of requests vs timesheets)`}>
                            <div className="flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0" />
                              <span className="text-muted-foreground">Req:</span>
                              <span className="font-medium">{src.request}h</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                              <span className="text-muted-foreground">TS:</span>
                              <span className="font-medium">{src.timesheet}h</span>
                            </div>
                            <div className="flex items-center gap-1 border-t border-border pt-0.5 mt-0.5">
                              <span className="text-muted-foreground">Used:</span>
                              <span className="font-semibold text-primary">{src.used}h</span>
                            </div>
                          </div>
                        );
                      })()}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtCurrency(r.allowances)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm font-semibold">{fmtCurrency(r.gross_pay)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-red-600">{fmtCurrency(r.total_deductions)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm font-bold text-primary">{fmtCurrency(r.net_pay)}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs capitalize ${r.payment_status === 'paid' ? 'bg-green-100 text-green-800' : r.payment_status === 'reversed' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}`}>
                        {r.payment_status}
                      </Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      <div className="flex items-center gap-1">
                        <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openEdit(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                        {PAYMENT_STATUS_NEXT[r.payment_status] && (
                          <Button size="sm" variant="outline" className="h-7 px-2 text-xs" onClick={() => handlePaymentStatusUpdate(r)}>
                            <ChevronRight className="h-3.5 w-3.5 mr-0.5" />{PAYMENT_STATUS_NEXT[r.payment_status]}
                          </Button>
                        )}
                        <Button
                          size="sm" variant="outline"
                          className="h-7 px-2 text-xs text-emerald-700 border-emerald-200 hover:bg-emerald-50"
                          title="Download PDF Payslip"
                          onClick={() => {
                            const emp = r.employee;
                            const periodLabel = period
                              ? new Date(period.start_date).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
                              : 'Payslip';
                            generatePayslipPdf({
                              employee: {
                                name: emp ? `${emp.first_name} ${emp.last_name}` : 'Employee',
                                employee_no: emp?.employee_no ?? r.employee_id.slice(0, 8),
                                department: undefined,
                              },
                              period_label: periodLabel,
                              basic_salary:     Number(r.basic_salary)     || 0,
                              overtime_pay:     Number(r.overtime_pay)     || 0,
                              allowances:       Number(r.allowances)       || 0,
                              gross_pay:        Number(r.gross_pay)        || 0,
                              tax_deduction:    Number(r.tax_deduction)    || 0,
                              social_security:  Number(r.social_security)  || 0,
                              provident_fund:   Number(r.provident_fund)   || 0,
                              other_deductions: Number(r.other_deductions) || 0,
                              loan_deductions:  0,
                              total_deductions: Number(r.total_deductions) || 0,
                              net_pay:          Number(r.net_pay)          || 0,
                            });
                            toast.success(`Payslip for ${emp ? `${emp.first_name} ${emp.last_name}` : 'employee'} downloaded`);
                          }}
                        >
                          <FileDown className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Auto-Calculate confirmation dialog */}
      <Dialog open={autoCalcOpen} onOpenChange={setAutoCalcOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-primary" />Auto-Calculate Payroll
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-1">
            <p className="text-sm text-muted-foreground">
              This will create payroll records for all employees who have a salary structure assigned
              and do not yet have a record in this run.
            </p>
            <ul className="text-sm space-y-1 bg-muted/40 rounded-lg p-3 list-disc list-inside text-muted-foreground">
              <li>Earnings &amp; deductions are pulled from each employee's assigned salary structure</li>
              <li>Overtime pay defaults to <span className="font-medium text-foreground">$0</span> — edit records manually if needed</li>
              <li>Employees already in this run are <span className="font-medium text-foreground">skipped</span></li>
            </ul>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setAutoCalcOpen(false)}>Cancel</Button>
              <Button onClick={handleAutoCalc} className="gap-2">
                <Zap className="h-4 w-4" /> Run Auto-Calculate
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
