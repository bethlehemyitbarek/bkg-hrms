import { useState, useEffect, useCallback } from 'react';
import { payrollSettingsService } from '@/services/payroll.service';
import type { PayrollSettings, StatutoryDeduction } from '@/services/payroll.service';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { RefreshCw, Plus, Pencil, Trash2, Settings, Percent } from 'lucide-react';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const TYPE_LABELS: Record<string, string> = {
  income_tax:       'Income Tax',
  social_insurance: 'Social Insurance',
  provident_fund:   'Provident Fund',
  other:            'Other',
};

export function PayrollSettingsPage() {
  const [settings,   setSettings]   = useState<PayrollSettings | null>(null);
  const [deductions, setDeductions] = useState<StatutoryDeduction[]>([]);
  const [loading, setLoading]       = useState(true);
  const [savingSettings, setSavingSettings] = useState(false);
  const [savingDed,      setSavingDed]      = useState(false);

  const [settingsForm, setSettingsForm] = useState({
    pay_frequency: 'monthly', currency: 'ETB', cut_off_day: '25', payment_day: '5',
  });

  const [dedDialog, setDedDialog] = useState(false);
  const [editDed,   setEditDed]   = useState<StatutoryDeduction | null>(null);
  const [dedForm, setDedForm] = useState({
    deduction_type: 'income_tax', name: '', rate: '', threshold: '', max_amount: '', is_active: true,
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [s, d] = await Promise.all([
        payrollSettingsService.get(),
        payrollSettingsService.listStatutoryDeductions(),
      ]);
      if (s) {
        setSettings(s);
        setSettingsForm({
          pay_frequency: s.pay_frequency,
          currency: s.currency,
          cut_off_day: String(s.cut_off_day),
          payment_day: String(s.payment_day),
        });
      }
      setDeductions(d);
    } catch { toast.error('Failed to load settings'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSettingsSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      await payrollSettingsService.upsert({
        pay_frequency: settingsForm.pay_frequency as PayrollSettings['pay_frequency'],
        currency:      settingsForm.currency,
        cut_off_day:   Number(settingsForm.cut_off_day),
        payment_day:   Number(settingsForm.payment_day),
      });
      toast.success('Settings saved');
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSavingSettings(false); }
  };

  const openDedCreate = () => {
    setEditDed(null);
    setDedForm({ deduction_type: 'income_tax', name: '', rate: '', threshold: '', max_amount: '', is_active: true });
    setDedDialog(true);
  };
  const openDedEdit = (d: StatutoryDeduction) => {
    setEditDed(d);
    setDedForm({
      deduction_type: d.deduction_type,
      name:       d.name,
      rate:       d.rate != null ? String(Number(d.rate) * 100) : '',
      threshold:  d.threshold != null ? String(d.threshold) : '',
      max_amount: d.max_amount != null ? String(d.max_amount) : '',
      is_active:  d.is_active,
    });
    setDedDialog(true);
  };
  const handleDedSave = async (ev: React.FormEvent) => {
    ev.preventDefault();
    setSavingDed(true);
    const payload: Partial<StatutoryDeduction> = {
      deduction_type: dedForm.deduction_type as StatutoryDeduction['deduction_type'],
      name:       dedForm.name,
      rate:       dedForm.rate ? Number(dedForm.rate) / 100 : undefined,
      threshold:  dedForm.threshold  ? Number(dedForm.threshold)  : undefined,
      max_amount: dedForm.max_amount ? Number(dedForm.max_amount) : undefined,
      is_active:  dedForm.is_active,
    };
    try {
      if (editDed) { await payrollSettingsService.updateDeduction(editDed.id, payload); toast.success('Deduction updated'); }
      else         { await payrollSettingsService.createDeduction(payload);             toast.success('Deduction created'); }
      setDedDialog(false);
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSavingDed(false); }
  };
  const handleDedDelete = async (id: string) => {
    try { await payrollSettingsService.removeDeduction(id); toast.success('Deduction deleted'); load(); }
    catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-balance">Payroll Settings</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Configure pay frequency, currency, and statutory deductions</p>
        </div>
        <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
      </div>

      <Tabs defaultValue="general">
        <TabsList className="h-9">
          <TabsTrigger value="general"><Settings className="h-3.5 w-3.5 mr-1.5" />General</TabsTrigger>
          <TabsTrigger value="deductions"><Percent className="h-3.5 w-3.5 mr-1.5" />Statutory Deductions</TabsTrigger>
        </TabsList>

        {/* ── General settings ── */}
        <TabsContent value="general" className="mt-4">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Pay Configuration</CardTitle></CardHeader>
            <CardContent>
              {loading ? <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 w-full bg-muted" />)}</div>
              : (
                <form onSubmit={handleSettingsSave} className="space-y-5 max-w-lg">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Pay Frequency</Label>
                      <Select value={settingsForm.pay_frequency} onValueChange={v => setSettingsForm(p => ({ ...p, pay_frequency: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="monthly">Monthly</SelectItem>
                          <SelectItem value="bi_weekly">Bi-Weekly</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label>Currency</Label>
                      <Select value={settingsForm.currency} onValueChange={v => setSettingsForm(p => ({ ...p, currency: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ETB">ETB — Ethiopian Birr (ብር)</SelectItem>
                          <SelectItem value="USD">USD — US Dollar</SelectItem>
                          <SelectItem value="THB">THB — Thai Baht</SelectItem>
                          <SelectItem value="EUR">EUR — Euro</SelectItem>
                          <SelectItem value="GBP">GBP — British Pound</SelectItem>
                          <SelectItem value="SGD">SGD — Singapore Dollar</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Cut-off Day of Month</Label>
                      <Input type="number" min="1" max="31" value={settingsForm.cut_off_day} onChange={e => setSettingsForm(p => ({ ...p, cut_off_day: e.target.value }))} />
                      <p className="text-xs text-muted-foreground">Attendance is locked after this day</p>
                    </div>
                    <div className="space-y-1.5">
                      <Label>Payment Day of Month</Label>
                      <Input type="number" min="1" max="31" value={settingsForm.payment_day} onChange={e => setSettingsForm(p => ({ ...p, payment_day: e.target.value }))} />
                      <p className="text-xs text-muted-foreground">Day salary is disbursed</p>
                    </div>
                  </div>

                  {settings && (
                    <div className="bg-muted/40 rounded-lg p-3 text-sm text-muted-foreground">
                      <p className="font-medium text-foreground mb-1">Current Settings</p>
                      <p>Frequency: <strong>{settings.pay_frequency}</strong> · Currency: <strong>{settings.currency}</strong> · Cut-off: <strong>{settings.cut_off_day}</strong> · Payment: <strong>{settings.payment_day}</strong></p>
                    </div>
                  )}

                  <Button type="submit" disabled={savingSettings}>{savingSettings ? 'Saving…' : 'Save Settings'}</Button>
                </form>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Statutory deductions ── */}
        <TabsContent value="deductions" className="mt-4 space-y-4">
          <div className="flex justify-end">
            <Dialog open={dedDialog} onOpenChange={setDedDialog}>
              <DialogTrigger asChild>
                <Button size="sm" onClick={openDedCreate}><Plus className="h-4 w-4 mr-1.5" />Add Deduction Rule</Button>
              </DialogTrigger>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                <DialogHeader><DialogTitle>{editDed ? 'Edit' : 'New'} Statutory Deduction</DialogTitle></DialogHeader>
                <form onSubmit={handleDedSave} className="space-y-4 mt-2">
                  <div className="space-y-1.5">
                    <Label>Type *</Label>
                    <Select value={dedForm.deduction_type} onValueChange={v => setDedForm(p => ({ ...p, deduction_type: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="income_tax">Income Tax</SelectItem>
                        <SelectItem value="social_insurance">Social Insurance</SelectItem>
                        <SelectItem value="provident_fund">Provident Fund</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5"><Label>Name *</Label><Input value={dedForm.name} onChange={e => setDedForm(p => ({ ...p, name: e.target.value }))} required /></div>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="space-y-1.5"><Label>Rate (%)</Label><Input type="number" min="0" max="100" step="0.01" value={dedForm.rate} onChange={e => setDedForm(p => ({ ...p, rate: e.target.value }))} placeholder="15" /></div>
                    <div className="space-y-1.5"><Label>Threshold</Label><Input type="number" min="0" step="0.01" value={dedForm.threshold} onChange={e => setDedForm(p => ({ ...p, threshold: e.target.value }))} placeholder="5000" /></div>
                    <div className="space-y-1.5"><Label>Max Amount</Label><Input type="number" min="0" step="0.01" value={dedForm.max_amount} onChange={e => setDedForm(p => ({ ...p, max_amount: e.target.value }))} placeholder="—" /></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch checked={dedForm.is_active} onCheckedChange={v => setDedForm(p => ({ ...p, is_active: v }))} id="ded-active" />
                    <Label htmlFor="ded-active">Active</Label>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setDedDialog(false)}>Cancel</Button>
                    <Button type="submit" disabled={savingDed}>{savingDed ? 'Saving…' : 'Save'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Name</TableHead>
                    <TableHead className="whitespace-nowrap">Type</TableHead>
                    <TableHead className="whitespace-nowrap">Rate</TableHead>
                    <TableHead className="whitespace-nowrap">Threshold</TableHead>
                    <TableHead className="whitespace-nowrap">Max Amount</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 4 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 7 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>
                  )) : deductions.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">No deduction rules found</TableCell></TableRow>
                  ) : deductions.map(d => (
                    <TableRow key={d.id}>
                      <TableCell className="font-medium whitespace-nowrap">{d.name}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{TYPE_LABELS[d.deduction_type] ?? d.deduction_type}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-mono">{d.rate != null ? `${(Number(d.rate) * 100).toFixed(2)}%` : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{d.threshold != null ? d.threshold.toLocaleString() : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{d.max_amount != null ? d.max_amount.toLocaleString() : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge variant="outline" className={`text-xs ${d.is_active ? 'text-green-600 border-green-200' : 'text-muted-foreground'}`}>{d.is_active ? 'Active' : 'Inactive'}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex items-center gap-1">
                          <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openDedEdit(d)}><Pencil className="h-3.5 w-3.5" /></Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="sm" variant="outline" className="h-7 px-2 text-red-500 border-red-200 hover:bg-red-50"><Trash2 className="h-3.5 w-3.5" /></Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
                              <AlertDialogHeader><AlertDialogTitle>Delete Deduction Rule</AlertDialogTitle><AlertDialogDescription>Delete &quot;{d.name}&quot;? This cannot be undone.</AlertDialogDescription></AlertDialogHeader>
                              <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={() => handleDedDelete(d.id)} className="bg-red-500 hover:bg-red-600">Delete</AlertDialogAction></AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
