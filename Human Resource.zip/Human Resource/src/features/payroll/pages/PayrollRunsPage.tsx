import { useState, useEffect, useCallback } from 'react';
import { payrollService } from '@/services/payroll.service';
import { supabase } from '@/db/supabase';
import type { PayrollPeriod, LoanRepaymentSchedule } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Plus, RefreshCw, ArrowRight, CalendarRange } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const STATUS_COLORS: Record<string, string> = {
  draft:      'bg-muted text-muted-foreground',
  processing: 'bg-blue-100 text-blue-800',
  approved:   'bg-purple-100 text-purple-800',
  paid:       'bg-green-100 text-green-800',
  cancelled:  'bg-red-100 text-red-800',
};

const STATUS_NEXT: Record<string, string> = {
  draft:      'processing',
  processing: 'approved',
  approved:   'paid',
};

const fmtDate = (d?: string) =>
  d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

const fmtCurrency = (n: number) =>
  `ብር ${Number(n||0).toLocaleString('en-US',{maximumFractionDigits:0})}`;

// ── Auto-apply loan deductions when payroll moves to PROCESSING ──────────────
async function autoApplyLoanDeductions(period: PayrollPeriod): Promise<number> {
  // 1. Find PENDING installments whose due_date falls within this payroll period
  const { data: installments, error } = await supabase
    .from('loan_repayment_schedules')
    .select('schedule_id, loan_request_id, due_date, total_installment, employee_id:loan_requests!loan_repayment_schedules_loan_request_id_fkey(employee_id)')
    .eq('payment_status', 'PENDING')
    .is('payroll_run_id', null)
    .is('deleted_at', null)
    .gte('due_date', period.start_date)
    .lte('due_date', period.end_date);

  if (error || !installments || installments.length === 0) return 0;

  let applied = 0;

  for (const inst of installments) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const empId: string | undefined = (inst as any).employee_id?.employee_id;
    if (!empId) continue;

    // 2. Find/create the payroll record for this employee in this period
    const { data: existing } = await supabase
      .from('payroll_records')
      .select('id, other_deductions, total_deductions, net_pay')
      .eq('payroll_period_id', period.id)
      .eq('employee_id', empId)
      .maybeSingle();

    if (existing) {
      // Update deductions on existing record
      const instAmt = (inst as unknown as LoanRepaymentSchedule).total_installment ?? 0;
      await supabase
        .from('payroll_records')
        .update({
          other_deductions: (existing.other_deductions ?? 0) + instAmt,
          total_deductions:  (existing.total_deductions  ?? 0) + instAmt,
          net_pay:           (existing.net_pay            ?? 0) - instAmt,
          updated_at:        new Date().toISOString(),
        })
        .eq('id', existing.id);
    }

    // 3. Link installment to this payroll run and mark as IN_PAYROLL
    await supabase
      .from('loan_repayment_schedules')
      .update({
        payroll_run_id: period.id,
        payment_status: 'PAID' as const,
        paid_date:      period.payment_date ?? new Date().toISOString().slice(0, 10),
        paid_amount:    (inst as unknown as LoanRepaymentSchedule).total_installment ?? 0,
        updated_at:     new Date().toISOString(),
      })
      .eq('schedule_id', (inst as unknown as LoanRepaymentSchedule).schedule_id);

    applied++;
  }

  return applied;
}

export function PayrollRunsPage() {
  const navigate = useNavigate();
  const [periods, setPeriods]   = useState<PayrollPeriod[]>([]);
  const [loading, setLoading]   = useState(true);
  const [total,   setTotal]     = useState(0);
  const [page,    setPage]      = useState(1);
  const pageSize = 15;
  const [statusFilter, setStatusFilter] = useState('all');
  const [createOpen, setCreateOpen]     = useState(false);
  const [saving, setSaving]             = useState(false);
  const [summaryAll, setSummaryAll]     = useState({ total_gross: 0, total_net: 0, total_records: 0, paid_count: 0 });

  const [form, setForm] = useState({
    period_code: '', name: '', start_date: '', end_date: '', payment_date: '',
    period_type: 'monthly', status: 'draft',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await payrollService.listPeriods({
        status: statusFilter !== 'all' ? statusFilter : undefined,
        page, pageSize,
      });
      setPeriods(res.data);
      setTotal(res.total);
    } catch { toast.error('Failed to load payroll runs'); }
    finally { setLoading(false); }
  }, [statusFilter, page, pageSize]);

  const loadSummary = useCallback(async () => {
    try {
      const s = await payrollService.getPayrollSummary();
      setSummaryAll(s);
    } catch { /* silent */ }
  }, []);

  useEffect(() => { load(); loadSummary(); }, [load, loadSummary]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.period_code || !form.name || !form.start_date || !form.end_date) {
      toast.error('Fill all required fields'); return;
    }
    setSaving(true);
    try {
      const created = await payrollService.createPeriod({ ...form, status: 'draft' } as Partial<PayrollPeriod>);
      toast.success('Payroll run created');
      setCreateOpen(false);
      setForm({ period_code: '', name: '', start_date: '', end_date: '', payment_date: '', period_type: 'monthly', status: 'draft' });
      load(); loadSummary();
      navigate(`/payroll/runs/${created.id}`);
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };

  const handleAdvance = async (p: PayrollPeriod) => {
    const next = STATUS_NEXT[p.status];
    if (!next) return;
    try {
      await payrollService.updatePeriodStatus(p.id, next as PayrollPeriod['status']);

      // Auto-apply loan deductions when run moves to processing
      if (next === 'processing') {
        const count = await autoApplyLoanDeductions(p);
        toast.success(`Status updated to processing — ${count} loan deduction${count !== 1 ? 's' : ''} auto-applied`);
      } else {
        toast.success(`Status updated to ${next}`);
      }

      load(); loadSummary();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-balance">Payroll Runs</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} runs</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => { load(); loadSummary(); }}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button size="sm"><Plus className="h-4 w-4 mr-1.5" />New Run</Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>Create Payroll Run</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 mt-2">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5"><Label>Period Code *</Label><Input value={form.period_code} onChange={e => setForm(p => ({ ...p, period_code: e.target.value }))} placeholder="2026-05" required /></div>
                  <div className="space-y-1.5"><Label>Name *</Label><Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="May 2026" required /></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5"><Label>Start Date *</Label><Input type="date" value={form.start_date} onChange={e => setForm(p => ({ ...p, start_date: e.target.value }))} required /></div>
                  <div className="space-y-1.5"><Label>End Date *</Label><Input type="date" value={form.end_date} onChange={e => setForm(p => ({ ...p, end_date: e.target.value }))} required /></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5"><Label>Payment Date</Label><Input type="date" value={form.payment_date} onChange={e => setForm(p => ({ ...p, payment_date: e.target.value }))} /></div>
                  <div className="space-y-1.5">
                    <Label>Type</Label>
                    <Select value={form.period_type} onValueChange={v => setForm(p => ({ ...p, period_type: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="monthly">Monthly</SelectItem>
                        <SelectItem value="bi_weekly">Bi-Weekly</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
                  <Button type="submit" disabled={saving}>{saving ? 'Creating…' : 'Create Run'}</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Records', value: summaryAll.total_records },
          { label: 'Paid Records',  value: summaryAll.paid_count },
          { label: 'Total Gross',   value: fmtCurrency(summaryAll.total_gross) },
          { label: 'Total Net',     value: fmtCurrency(summaryAll.total_net) },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3">
            <p className="text-xs text-muted-foreground">{s.label}</p>
            <p className="text-lg font-bold leading-tight mt-0.5">{s.value}</p>
          </div>
        ))}
      </div>

      {/* Filter */}
      <div className="flex items-center gap-3">
        <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setPage(1); }}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="processing">Processing</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Period Code</TableHead>
                <TableHead className="whitespace-nowrap">Name</TableHead>
                <TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">Start</TableHead>
                <TableHead className="whitespace-nowrap">End</TableHead>
                <TableHead className="whitespace-nowrap">Payment</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? Array.from({ length: 6 }).map((_, i) => (
                <TableRow key={i}>{Array.from({ length: 8 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>
              )) : periods.length === 0 ? (
                <TableRow><TableCell colSpan={8} className="text-center py-12 text-muted-foreground">
                  <CalendarRange className="h-10 w-10 mx-auto mb-2 opacity-40" />No payroll runs found
                </TableCell></TableRow>
              ) : periods.map(p => (
                <TableRow key={p.id} className="cursor-pointer hover:bg-muted/30" onClick={() => navigate(`/payroll/runs/${p.id}`)}>
                  <TableCell className="whitespace-nowrap font-mono text-sm">{p.period_code}</TableCell>
                  <TableCell className="whitespace-nowrap font-medium">{p.name}</TableCell>
                  <TableCell className="whitespace-nowrap text-sm capitalize">{p.period_type?.replace('_', '-')}</TableCell>
                  <TableCell className="whitespace-nowrap text-sm">{fmtDate(p.start_date)}</TableCell>
                  <TableCell className="whitespace-nowrap text-sm">{fmtDate(p.end_date)}</TableCell>
                  <TableCell className="whitespace-nowrap text-sm">{fmtDate(p.payment_date)}</TableCell>
                  <TableCell className="whitespace-nowrap">
                    <Badge className={`text-xs capitalize ${STATUS_COLORS[p.status] ?? 'bg-muted text-muted-foreground'}`}>{p.status}</Badge>
                  </TableCell>
                  <TableCell className="whitespace-nowrap" onClick={e => e.stopPropagation()}>
                    <div className="flex items-center gap-1">
                      <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => navigate(`/payroll/runs/${p.id}`)}>
                        <ArrowRight className="h-3.5 w-3.5" />
                      </Button>
                      {STATUS_NEXT[p.status] && (
                        <Button size="sm" variant="outline" className="h-7 px-2 text-xs capitalize" onClick={() => handleAdvance(p)}>
                          → {STATUS_NEXT[p.status]}
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {Math.ceil(total / pageSize) > 1 && (
        <div className="flex justify-end gap-2">
          <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</Button>
          <span className="text-sm self-center">{page} / {Math.ceil(total / pageSize)}</span>
          <Button size="sm" variant="outline" disabled={page >= Math.ceil(total / pageSize)} onClick={() => setPage(p => p + 1)}>Next</Button>
        </div>
      )}
    </div>
  );
}
