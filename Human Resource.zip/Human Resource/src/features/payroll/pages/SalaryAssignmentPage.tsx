import { useState, useEffect, useCallback } from 'react';
import { employeeService } from '@/services/employee.service';
import { salaryStructureService } from '@/services/payroll.service';
import type { EmployeeSalaryStructure, SalaryStructure } from '@/services/payroll.service';
import type { Employee } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { RefreshCw, UserCheck, Plus, Search, CalendarDays, Layers, Users, CheckCheck } from 'lucide-react';

const fmtDate = (d?: string) =>
  d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

interface AssignForm {
  employee_id: string;
  salary_structure_id: string;
  effective_date: string;
}
const emptyForm: AssignForm = { employee_id: '', salary_structure_id: '', effective_date: '' };

export function SalaryAssignmentPage() {
  const [assignments, setAssignments] = useState<EmployeeSalaryStructure[]>([]);
  const [structures,  setStructures]  = useState<SalaryStructure[]>([]);
  const [employees,   setEmployees]   = useState<Employee[]>([]);
  const [loading,     setLoading]     = useState(true);
  const [saving,      setSaving]      = useState(false);
  const [open,        setOpen]        = useState(false);
  const [form,        setForm]        = useState<AssignForm>(emptyForm);
  const [search,      setSearch]      = useState('');
  const [filterStr,   setFilterStr]   = useState<string>('all');

  // Bulk-reassign state
  const [selectedIds,       setSelectedIds]       = useState<Set<string>>(new Set());
  const [bulkOpen,          setBulkOpen]          = useState(false);
  const [bulkStructureId,   setBulkStructureId]   = useState('');
  const [bulkEffectiveDate, setBulkEffectiveDate] = useState(new Date().toISOString().slice(0, 10));
  const [bulkSaving,        setBulkSaving]        = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [a, s, e] = await Promise.all([
        salaryStructureService.listAssignments(),
        salaryStructureService.list(),
        employeeService.list({ page: 1, pageSize: 200 }).then(r => r.data),
      ]);
      setAssignments(a);
      setStructures(s);
      setEmployees(e as Employee[]);
    } catch {
      toast.error('Failed to load assignments');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // Single assign/reassign
  const handleOpen = () => {
    setForm({ ...emptyForm, effective_date: new Date().toISOString().slice(0, 10) });
    setOpen(true);
  };

  const handleSave = async () => {
    if (!form.employee_id || form.employee_id === 'none') { toast.error('Select an employee'); return; }
    if (!form.salary_structure_id || form.salary_structure_id === 'none') { toast.error('Select a salary structure'); return; }
    if (!form.effective_date) { toast.error('Provide an effective date'); return; }
    setSaving(true);
    try {
      await salaryStructureService.assign(form.employee_id, form.salary_structure_id, form.effective_date);
      toast.success('Salary structure assigned');
      setOpen(false);
      setSelectedIds(new Set());
      await load();
    } catch {
      toast.error('Failed to save assignment');
    } finally {
      setSaving(false);
    }
  };

  // Bulk reassign
  const handleBulkReassign = async () => {
    if (!bulkStructureId || bulkStructureId === 'none') { toast.error('Select a target salary structure'); return; }
    if (!bulkEffectiveDate) { toast.error('Provide an effective date'); return; }
    if (selectedIds.size === 0) { toast.error('Select at least one employee'); return; }
    setBulkSaving(true);
    let ok = 0, fail = 0;
    for (const empId of selectedIds) {
      try {
        await salaryStructureService.assign(empId, bulkStructureId, bulkEffectiveDate);
        ok++;
      } catch { fail++; }
    }
    setBulkSaving(false);
    if (ok > 0) toast.success(`Bulk reassigned ${ok} employee${ok > 1 ? 's' : ''}`);
    if (fail > 0) toast.warning(`${fail} assignment${fail > 1 ? 's' : ''} failed`);
    setBulkOpen(false);
    setSelectedIds(new Set());
    await load();
  };

  const visible = assignments.filter(a => {
    const emp  = a.employee;
    const name = emp ? `${emp.first_name} ${emp.last_name} ${emp.employee_no}`.toLowerCase() : '';
    return (!search || name.includes(search.toLowerCase())) &&
      (filterStr === 'all' || a.salary_structure_id === filterStr);
  });

  const visibleIds   = visible.map(a => a.employee_id);
  const allChecked   = visibleIds.length > 0 && visibleIds.every(id => selectedIds.has(id));
  const someChecked  = visibleIds.some(id => selectedIds.has(id));
  const unassigned   = employees.filter(e => !assignments.find(a => a.employee_id === e.id));

  const toggleId = (id: string) => setSelectedIds(prev => {
    const next = new Set(prev);
    next.has(id) ? next.delete(id) : next.add(id);
    return next;
  });

  const toggleAll = () => {
    if (allChecked) {
      setSelectedIds(prev => { const next = new Set(prev); visibleIds.forEach(id => next.delete(id)); return next; });
    } else {
      setSelectedIds(prev => new Set([...prev, ...visibleIds]));
    }
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground text-balance">Salary Structure Assignments</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Assign or bulk-reassign salary structures with effective dates</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Button variant="ghost" size="icon" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
          {selectedIds.size > 0 && (
            <Button variant="secondary" className="gap-2" onClick={() => { setBulkStructureId(''); setBulkEffectiveDate(new Date().toISOString().slice(0, 10)); setBulkOpen(true); }}>
              <CheckCheck className="h-4 w-4" />Bulk Reassign ({selectedIds.size})
            </Button>
          )}
          <Button onClick={handleOpen} className="gap-2">
            <Plus className="h-4 w-4" />Assign Structure
          </Button>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Employees', value: employees.length,   icon: Users },
          { label: 'Assigned',        value: assignments.length, icon: Layers },
          { label: 'Unassigned',      value: unassigned.length,  icon: CalendarDays },
          { label: 'Selected',        value: selectedIds.size,   icon: CheckCheck },
        ].map(({ label, value, icon: Icon }) => (
          <Card key={label} className="h-full">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="rounded-lg bg-primary/10 p-2.5 shrink-0"><Icon className="h-5 w-5 text-primary" /></div>
              <div className="min-w-0">
                <p className="text-xs text-muted-foreground truncate">{label}</p>
                <p className="text-xl font-bold text-foreground">{loading ? '—' : value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters + selection hint */}
      <div className="flex flex-col gap-2 md:flex-row md:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <Input placeholder="Search employee name or number…" value={search}
            onChange={e => setSearch(e.target.value)} className="pl-8" />
        </div>
        <Select value={filterStr} onValueChange={setFilterStr}>
          <SelectTrigger className="md:w-52"><SelectValue placeholder="All structures" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All structures</SelectItem>
            {structures.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      {selectedIds.size > 0 && (
        <div className="bg-primary/5 border border-primary/20 rounded-lg px-4 py-2.5 flex items-center justify-between gap-3 text-sm">
          <span className="text-foreground"><strong>{selectedIds.size}</strong> employee{selectedIds.size > 1 ? 's' : ''} selected</span>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="secondary" className="gap-1.5 h-7"
              onClick={() => { setBulkStructureId(''); setBulkEffectiveDate(new Date().toISOString().slice(0, 10)); setBulkOpen(true); }}>
              <CheckCheck className="h-3.5 w-3.5" />Bulk Reassign
            </Button>
            <Button size="sm" variant="ghost" className="h-7 text-muted-foreground" onClick={() => setSelectedIds(new Set())}>Clear</Button>
          </div>
        </div>
      )}

      {/* Assignments table */}
      <Card>
        <CardHeader className="pb-3 pt-4 px-4 md:px-6">
          <CardTitle className="text-base">Current Assignments ({visible.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10 whitespace-nowrap">
                    <Checkbox
                      checked={allChecked ? true : someChecked ? 'indeterminate' : false}
                      onCheckedChange={toggleAll}
                      aria-label="Select all visible"
                    />
                  </TableHead>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Employee #</TableHead>
                  <TableHead className="whitespace-nowrap">Salary Structure</TableHead>
                  <TableHead className="whitespace-nowrap">Effective Date</TableHead>
                  <TableHead className="whitespace-nowrap">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-24 bg-muted" /></TableCell>)}
                    </TableRow>
                  ))
                ) : visible.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                      <UserCheck className="h-8 w-8 mx-auto mb-2 opacity-40" />No assignments found
                    </TableCell>
                  </TableRow>
                ) : visible.map(a => {
                  const emp = a.employee;
                  const str = a.salary_structure;
                  const checked = selectedIds.has(a.employee_id);
                  return (
                    <TableRow key={a.id} className={checked ? 'bg-primary/5' : ''}>
                      <TableCell className="whitespace-nowrap">
                        <Checkbox checked={checked} onCheckedChange={() => toggleId(a.employee_id)} />
                      </TableCell>
                      <TableCell className="whitespace-nowrap font-medium">
                        {emp ? `${emp.first_name} ${emp.last_name}` : '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge variant="outline" className="font-mono text-xs">{emp?.employee_no ?? '—'}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">{str?.name ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">{fmtDate(a.effective_date)}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="text-xs h-7" onClick={() => {
                          setForm({ employee_id: a.employee_id, salary_structure_id: a.salary_structure_id, effective_date: new Date().toISOString().slice(0, 10) });
                          setOpen(true);
                        }}>Reassign</Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Unassigned */}
      {!loading && unassigned.length > 0 && (
        <Card>
          <CardHeader className="pb-3 pt-4 px-4 md:px-6">
            <CardTitle className="text-base text-amber-700">Employees Without Assignment ({unassigned.length})</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Employee #</TableHead>
                    <TableHead className="whitespace-nowrap">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {unassigned.slice(0, 20).map(e => (
                    <TableRow key={e.id}>
                      <TableCell className="whitespace-nowrap font-medium">{e.first_name} {e.last_name}</TableCell>
                      <TableCell className="whitespace-nowrap"><Badge variant="outline" className="font-mono text-xs">{e.employee_no}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="text-xs h-7 gap-1" onClick={() => {
                          setForm({ employee_id: e.id, salary_structure_id: '', effective_date: new Date().toISOString().slice(0, 10) });
                          setOpen(true);
                        }}><Plus className="h-3 w-3" />Assign</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Single assign dialog */}
      <Dialog open={open} onOpenChange={o => { if (!o) setOpen(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Assign Salary Structure</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label>Employee</Label>
              <Select value={form.employee_id || 'none'} onValueChange={v => setForm(f => ({ ...f, employee_id: v === 'none' ? '' : v }))}>
                <SelectTrigger><SelectValue placeholder="Select employee…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Select employee —</SelectItem>
                  {employees.map(e => <SelectItem key={e.id} value={e.id}>{e.first_name} {e.last_name} ({e.employee_no})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Salary Structure</Label>
              <Select value={form.salary_structure_id || 'none'} onValueChange={v => setForm(f => ({ ...f, salary_structure_id: v === 'none' ? '' : v }))}>
                <SelectTrigger><SelectValue placeholder="Select structure…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Select structure —</SelectItem>
                  {structures.filter(s => s.is_active).map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Effective Date</Label>
              <Input type="date" value={form.effective_date} onChange={e => setForm(f => ({ ...f, effective_date: e.target.value }))} />
            </div>
            {form.salary_structure_id && form.salary_structure_id !== 'none' && (() => {
              const str = structures.find(s => s.id === form.salary_structure_id);
              const comps = str?.salary_structure_components ?? [];
              if (!comps.length) return null;
              return (
                <div className="rounded-lg border border-border bg-muted/30 p-3 space-y-1.5">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Components Preview</p>
                  {comps.map(c => (
                    <div key={c.id} className="flex items-center justify-between text-xs">
                      <span>{c.payroll_component?.name ?? c.payroll_component_id}</span>
                      <Badge variant="secondary" className="text-[10px] capitalize">{c.payroll_component?.component_type}</Badge>
                    </div>
                  ))}
                </div>
              );
            })()}
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setOpen(false)} disabled={saving}>Cancel</Button>
              <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving…' : 'Save Assignment'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Bulk reassign dialog */}
      <Dialog open={bulkOpen} onOpenChange={o => { if (!o) setBulkOpen(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><CheckCheck className="h-5 w-5 text-primary" />Bulk Reassign — {selectedIds.size} Employees</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="bg-muted/40 rounded-lg p-3 text-sm text-muted-foreground">
              The selected <strong className="text-foreground">{selectedIds.size} employee{selectedIds.size > 1 ? 's' : ''}</strong> will all be reassigned to the chosen salary structure effective on the date below.
            </div>
            <div className="space-y-1.5">
              <Label>Target Salary Structure *</Label>
              <Select value={bulkStructureId || 'none'} onValueChange={v => setBulkStructureId(v === 'none' ? '' : v)}>
                <SelectTrigger><SelectValue placeholder="Select target structure…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Select structure —</SelectItem>
                  {structures.filter(s => s.is_active).map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Effective Date *</Label>
              <Input type="date" value={bulkEffectiveDate} onChange={e => setBulkEffectiveDate(e.target.value)} />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setBulkOpen(false)} disabled={bulkSaving}>Cancel</Button>
              <Button onClick={handleBulkReassign} disabled={bulkSaving} className="gap-2">
                <CheckCheck className="h-4 w-4" />{bulkSaving ? 'Reassigning…' : `Reassign ${selectedIds.size} Employee${selectedIds.size > 1 ? 's' : ''}`}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
