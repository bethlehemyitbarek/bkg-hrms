import { useState, useEffect, useCallback } from 'react';
import { positionService } from '@/services/organization.service';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Plus, RefreshCw, Briefcase } from 'lucide-react';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const supabase = _sb as any;

interface LookupItem { id: string; code: string; name: string; }

export function PositionPage() {
  const [positions, setPositions] = useState<Record<string, unknown>[]>([]);
  const [departments, setDepartments] = useState<LookupItem[]>([]);
  const [jobGrades, setJobGrades] = useState<LookupItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialog, setDialog] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ code: '', title: '', department_id: '', job_grade_id: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await positionService.list();
      setPositions(data as unknown as Record<string, unknown>[]);
    } catch { toast.error('Failed to load positions'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    load();
    supabase.from('departments').select('id, code, name').eq('is_active', true).order('name')
      .then(({ data }: { data: LookupItem[] | null }) => setDepartments(data || []));
    supabase.from('job_grades').select('id, code, name').eq('is_active', true).order('name')
      .then(({ data }: { data: LookupItem[] | null }) => setJobGrades(data || []));
  }, [load]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await positionService.create({
        code: form.code,
        title: form.title,
        department_id: form.department_id && form.department_id !== 'none' ? form.department_id : undefined,
        job_grade_id: form.job_grade_id && form.job_grade_id !== 'none' ? form.job_grade_id : undefined,
      });
      toast.success('Position created');
      setDialog(false);
      setForm({ code: '', title: '', department_id: '', job_grade_id: '' });
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to create position'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2"><Briefcase className="h-5 w-5 text-primary" />Positions</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{positions.length} positions</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
          <Dialog open={dialog} onOpenChange={setDialog}>
            <DialogTrigger asChild><Button size="sm"><Plus className="h-4 w-4 mr-1.5" />Add Position</Button></DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>Create Position</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 mt-2">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5"><Label>Code *</Label><Input value={form.code} onChange={e => setForm(p => ({ ...p, code: e.target.value }))} required placeholder="e.g. SWE-01" /></div>
                  <div className="space-y-1.5"><Label>Title *</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} required placeholder="e.g. Software Engineer" /></div>
                </div>
                <div className="space-y-1.5">
                  <Label>Department</Label>
                  <Select value={form.department_id} onValueChange={v => setForm(p => ({ ...p, department_id: v }))}>
                    <SelectTrigger><SelectValue placeholder="Select department (optional)" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">— None —</SelectItem>
                      {departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Job Grade</Label>
                  <Select value={form.job_grade_id} onValueChange={v => setForm(p => ({ ...p, job_grade_id: v }))}>
                    <SelectTrigger><SelectValue placeholder="Select job grade (optional)" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">— None —</SelectItem>
                      {jobGrades.map(g => <SelectItem key={g.id} value={g.id}>{g.name} ({g.code})</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setDialog(false)}>Cancel</Button>
                  <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Create Position'}</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead className="whitespace-nowrap">Code</TableHead>
              <TableHead className="whitespace-nowrap">Title</TableHead>
              <TableHead className="whitespace-nowrap">Department</TableHead>
              <TableHead className="whitespace-nowrap">Grade</TableHead>
              <TableHead className="whitespace-nowrap">Status</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {loading
                ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 5 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                : positions.length === 0
                  ? <TableRow><TableCell colSpan={5} className="text-center py-10 text-muted-foreground"><Briefcase className="h-8 w-8 mx-auto mb-2 opacity-40" />No positions found</TableCell></TableRow>
                  : positions.map((p, i) => {
                    const dept = p.department as { name?: string } | undefined;
                    const grade = p.job_grade as { name?: string } | undefined;
                    return (
                      <TableRow key={String(p.id ?? i)}>
                        <TableCell className="whitespace-nowrap font-mono text-xs">{String(p.code ?? '')}</TableCell>
                        <TableCell className="whitespace-nowrap font-medium text-sm">{String(p.title ?? '')}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{dept?.name ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{grade?.name ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${p.is_active ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}`}>
                            {p.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </TableCell>
                      </TableRow>
                    );
                  })}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
