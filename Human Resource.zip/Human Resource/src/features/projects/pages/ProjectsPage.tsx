import { useState, useEffect, useCallback } from 'react';
import {
  FolderKanban, Plus, Pencil, Trash2, RefreshCw,
  ChevronRight, ChevronDown, ListTodo, AlertTriangle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { projectService, projectTaskService } from '@/services/project.service';
import type { Project, ProjectTask, ProjectStatus, TaskStatus } from '@/types/database.types';

const PROJECT_STATUS_COLORS: Record<ProjectStatus, string> = {
  DRAFT:      'bg-slate-100 text-slate-600',
  ACTIVE:     'bg-emerald-100 text-emerald-800',
  ON_HOLD:    'bg-amber-100 text-amber-800',
  CLOSED:     'bg-blue-100 text-blue-800',
  CANCELLED:  'bg-red-100 text-red-800',
};

const TASK_STATUS_COLORS: Record<TaskStatus, string> = {
  PENDING:     'bg-slate-100 text-slate-600',
  IN_PROGRESS: 'bg-blue-100 text-blue-800',
  COMPLETED:   'bg-emerald-100 text-emerald-800',
  CANCELLED:   'bg-red-100 text-red-800',
};

const BLANK_PROJECT = {
  project_name: '', project_code: '', description: '',
  manager_id: '', department_id: '',
  start_date: '', end_date: '',
  project_status: 'DRAFT' as ProjectStatus,
};

const BLANK_TASK = {
  task_name: '', description: '', assigned_employee_id: '',
  start_date: '', end_date: '', task_status: 'PENDING' as TaskStatus,
};

export default function ProjectsPage() {
  const [projects, setProjects]           = useState<Project[]>([]);
  const [total, setTotal]                 = useState(0);
  const [loadingProj, setLoadingProj]     = useState(false);
  const [filterStatus, setFilterStatus]   = useState('all');
  const [page, setPage]                   = useState(1);
  const pageSize = 20;

  // expanded project for tasks
  const [expandedId, setExpandedId]       = useState<string | null>(null);
  const [tasks, setTasks]                 = useState<ProjectTask[]>([]);
  const [loadingTasks, setLoadingTasks]   = useState(false);

  // dialogs
  const [projDialog, setProjDialog]       = useState(false);
  const [editProj, setEditProj]           = useState<Project | null>(null);
  const [projForm, setProjForm]           = useState({ ...BLANK_PROJECT });
  const [savingProj, setSavingProj]       = useState(false);
  const [deleteProj, setDeleteProj]       = useState<Project | null>(null);

  const [taskDialog, setTaskDialog]       = useState(false);
  const [editTask, setEditTask]           = useState<ProjectTask | null>(null);
  const [taskForm, setTaskForm]           = useState({ ...BLANK_TASK });
  const [savingTask, setSavingTask]       = useState(false);
  const [deleteTask, setDeleteTask]       = useState<ProjectTask | null>(null);

  const loadProjects = useCallback(async () => {
    setLoadingProj(true);
    try {
      const { data, total: t } = await projectService.list({ project_status: filterStatus, page, pageSize });
      setProjects(data as Project[]);
      setTotal(t);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to load projects');
    } finally { setLoadingProj(false); }
  }, [filterStatus, page]);

  useEffect(() => { loadProjects(); }, [loadProjects]);

  const loadTasks = useCallback(async (projectId: string) => {
    setLoadingTasks(true);
    try {
      const data = await projectTaskService.listByProject(projectId);
      setTasks(data as ProjectTask[]);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to load tasks');
    } finally { setLoadingTasks(false); }
  }, []);

  const toggleExpand = (id: string) => {
    if (expandedId === id) { setExpandedId(null); setTasks([]); }
    else { setExpandedId(id); loadTasks(id); }
  };

  // ── Project CRUD ──────────────────────────────────────────────
  const openCreateProject = () => { setEditProj(null); setProjForm({ ...BLANK_PROJECT }); setProjDialog(true); };
  const openEditProject = (r: Project) => {
    setEditProj(r);
    setProjForm({
      project_name: r.project_name, project_code: r.project_code,
      description: r.description ?? '', manager_id: r.manager_id ?? '',
      department_id: r.department_id ?? '',
      start_date: r.start_date ?? '', end_date: r.end_date ?? '',
      project_status: r.project_status,
    });
    setProjDialog(true);
  };
  const saveProject = async () => {
    if (!projForm.project_name.trim() || !projForm.project_code.trim()) {
      toast.error('Project name and code are required'); return;
    }
    setSavingProj(true);
    try {
      const payload = {
        ...projForm,
        manager_id: projForm.manager_id || null,
        department_id: projForm.department_id || null,
        start_date: projForm.start_date || null,
        end_date: projForm.end_date || null,
      };
      if (editProj) { await projectService.update(editProj.id, payload); toast.success('Project updated'); }
      else          { await projectService.create(payload); toast.success('Project created'); }
      setProjDialog(false);
      loadProjects();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Save failed'); }
    finally { setSavingProj(false); }
  };
  const handleDeleteProject = async () => {
    if (!deleteProj) return;
    try {
      await projectService.delete(deleteProj.id);
      toast.success('Project deleted');
      setDeleteProj(null);
      if (expandedId === deleteProj.id) { setExpandedId(null); setTasks([]); }
      loadProjects();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Delete failed'); }
  };

  // ── Task CRUD ─────────────────────────────────────────────────
  const openCreateTask = () => { setEditTask(null); setTaskForm({ ...BLANK_TASK }); setTaskDialog(true); };
  const openEditTask = (t: ProjectTask) => {
    setEditTask(t);
    setTaskForm({
      task_name: t.task_name, description: t.description ?? '',
      assigned_employee_id: t.assigned_employee_id ?? '',
      start_date: t.start_date ?? '', end_date: t.end_date ?? '',
      task_status: t.task_status,
    });
    setTaskDialog(true);
  };
  const saveTask = async () => {
    if (!taskForm.task_name.trim()) { toast.error('Task name is required'); return; }
    if (!expandedId) { toast.error('No project selected'); return; }
    setSavingTask(true);
    try {
      const payload = {
        ...taskForm,
        project_id: expandedId,
        assigned_employee_id: taskForm.assigned_employee_id || null,
        start_date: taskForm.start_date || null,
        end_date: taskForm.end_date || null,
      };
      if (editTask) { await projectTaskService.update(editTask.id, payload); toast.success('Task updated'); }
      else          { await projectTaskService.create(payload); toast.success('Task created'); }
      setTaskDialog(false);
      loadTasks(expandedId);
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Save failed'); }
    finally { setSavingTask(false); }
  };
  const handleDeleteTask = async () => {
    if (!deleteTask || !expandedId) return;
    try {
      await projectTaskService.delete(deleteTask.id);
      toast.success('Task deleted');
      setDeleteTask(null);
      loadTasks(expandedId);
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Delete failed'); }
  };

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <FolderKanban className="h-5 w-5 text-primary" />
          <h1 className="text-xl font-semibold text-foreground">Projects &amp; Tasks</h1>
          <Badge variant="secondary" className="ml-1">{total}</Badge>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={loadProjects} disabled={loadingProj}>
            <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${loadingProj ? 'animate-spin' : ''}`} />Refresh
          </Button>
          <Button size="sm" onClick={openCreateProject}>
            <Plus className="h-3.5 w-3.5 mr-1.5" />New Project
          </Button>
        </div>
      </div>

      {/* Filter */}
      <Card>
        <CardContent className="pt-4 pb-3">
          <div className="flex items-center gap-2">
            <Label className="text-xs shrink-0">Status</Label>
            <Select value={filterStatus} onValueChange={v => { setFilterStatus(v); setPage(1); }}>
              <SelectTrigger className="h-8 w-36 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="DRAFT">Draft</SelectItem>
                <SelectItem value="ACTIVE">Active</SelectItem>
                <SelectItem value="ON_HOLD">On Hold</SelectItem>
                <SelectItem value="CLOSED">Closed</SelectItem>
                <SelectItem value="CANCELLED">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Project List */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Projects</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="w-full overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap w-8"></TableHead>
                  <TableHead className="whitespace-nowrap">Code</TableHead>
                  <TableHead className="whitespace-nowrap">Project Name</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Start</TableHead>
                  <TableHead className="whitespace-nowrap">End</TableHead>
                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadingProj ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 7 }).map((__, j) => (
                        <TableCell key={j}><Skeleton className="h-4 w-20 bg-muted" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : projects.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="py-16 text-center text-muted-foreground">
                      <FolderKanban className="h-10 w-10 mx-auto mb-2 opacity-30" />No projects found
                    </TableCell>
                  </TableRow>
                ) : projects.map(r => (
                  <>
                    <TableRow key={r.id} className={expandedId === r.id ? 'bg-muted/30' : ''}>
                      <TableCell className="whitespace-nowrap w-8">
                        <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => toggleExpand(r.id)}>
                          {expandedId === r.id
                            ? <ChevronDown className="h-3.5 w-3.5" />
                            : <ChevronRight className="h-3.5 w-3.5" />}
                        </Button>
                      </TableCell>
                      <TableCell className="whitespace-nowrap font-mono text-xs">{r.project_code}</TableCell>
                      <TableCell className="whitespace-nowrap font-medium">{r.project_name}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={`text-xs ${PROJECT_STATUS_COLORS[r.project_status]}`}>{r.project_status}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                        {r.start_date ? new Date(r.start_date).toLocaleDateString() : '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                        {r.end_date ? new Date(r.end_date).toLocaleDateString() : '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEditProject(r)}>
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive" onClick={() => setDeleteProj(r)}>
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>

                    {/* Tasks sub-panel */}
                    {expandedId === r.id && (
                      <TableRow key={`${r.id}-tasks`}>
                        <TableCell colSpan={7} className="p-0 bg-muted/10">
                          <div className="border-t border-border px-6 py-4 space-y-3">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-medium flex items-center gap-1.5">
                                <ListTodo className="h-4 w-4 text-muted-foreground" />
                                Tasks — {r.project_name}
                              </p>
                              <Button size="sm" variant="outline" className="h-7 text-xs" onClick={openCreateTask}>
                                <Plus className="h-3 w-3 mr-1" />Add Task
                              </Button>
                            </div>

                            {loadingTasks ? (
                              <div className="space-y-2">
                                {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-8 w-full bg-muted" />)}
                              </div>
                            ) : tasks.length === 0 ? (
                              <p className="text-xs text-muted-foreground py-4 text-center">No tasks yet. Click "Add Task" to create one.</p>
                            ) : (
                              <div className="w-full overflow-x-auto">
                                <Table>
                                  <TableHeader>
                                    <TableRow>
                                      <TableHead className="whitespace-nowrap text-xs">Task Name</TableHead>
                                      <TableHead className="whitespace-nowrap text-xs">Assigned To</TableHead>
                                      <TableHead className="whitespace-nowrap text-xs">Status</TableHead>
                                      <TableHead className="whitespace-nowrap text-xs">Start</TableHead>
                                      <TableHead className="whitespace-nowrap text-xs">End</TableHead>
                                      <TableHead className="whitespace-nowrap text-xs text-right">Actions</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {tasks.map(t => (
                                      <TableRow key={t.id}>
                                        <TableCell className="whitespace-nowrap text-sm">{t.task_name}</TableCell>
                                        <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                                          {t.assigned_employee
                                            ? `${t.assigned_employee.first_name} ${t.assigned_employee.last_name}`
                                            : '—'}
                                        </TableCell>
                                        <TableCell className="whitespace-nowrap">
                                          <Badge className={`text-xs ${TASK_STATUS_COLORS[t.task_status]}`}>{t.task_status}</Badge>
                                        </TableCell>
                                        <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                                          {t.start_date ? new Date(t.start_date).toLocaleDateString() : '—'}
                                        </TableCell>
                                        <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                                          {t.end_date ? new Date(t.end_date).toLocaleDateString() : '—'}
                                        </TableCell>
                                        <TableCell className="whitespace-nowrap text-right">
                                          <div className="flex items-center justify-end gap-1">
                                            <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => openEditTask(t)}>
                                              <Pencil className="h-3 w-3" />
                                            </Button>
                                            <Button size="sm" variant="ghost" className="h-6 w-6 p-0 text-destructive" onClick={() => setDeleteTask(t)}>
                                              <Trash2 className="h-3 w-3" />
                                            </Button>
                                          </div>
                                        </TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                              </div>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </>
                ))}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <p className="text-xs text-muted-foreground">
                {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, total)} of {total}
              </p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="h-7 text-xs" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</Button>
                <Button size="sm" variant="outline" className="h-7 text-xs" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Project Dialog */}
      <Dialog open={projDialog} onOpenChange={setProjDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editProj ? 'Edit Project' : 'New Project'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Project Name <span className="text-destructive">*</span></Label>
                <Input value={projForm.project_name} onChange={e => setProjForm(p => ({ ...p, project_name: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Project Code <span className="text-destructive">*</span></Label>
                <Input value={projForm.project_code} onChange={e => setProjForm(p => ({ ...p, project_code: e.target.value }))}
                  placeholder="e.g. PROJ-001" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Description</Label>
              <Textarea value={projForm.description} onChange={e => setProjForm(p => ({ ...p, description: e.target.value }))} rows={3} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Project Manager</Label>
                <EmployeeSelect value={projForm.manager_id} onChange={v => setProjForm(p => ({ ...p, manager_id: v }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Status</Label>
                <Select value={projForm.project_status} onValueChange={v => setProjForm(p => ({ ...p, project_status: v as ProjectStatus }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DRAFT">Draft</SelectItem>
                    <SelectItem value="ACTIVE">Active</SelectItem>
                    <SelectItem value="ON_HOLD">On Hold</SelectItem>
                    <SelectItem value="CLOSED">Closed</SelectItem>
                    <SelectItem value="CANCELLED">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Start Date</Label>
                <Input type="date" value={projForm.start_date} onChange={e => setProjForm(p => ({ ...p, start_date: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>End Date</Label>
                <Input type="date" value={projForm.end_date} onChange={e => setProjForm(p => ({ ...p, end_date: e.target.value }))} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setProjDialog(false)}>Cancel</Button>
            <Button onClick={saveProject} disabled={savingProj}>{savingProj ? 'Saving…' : 'Save'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Task Dialog */}
      <Dialog open={taskDialog} onOpenChange={setTaskDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editTask ? 'Edit Task' : 'New Task'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label>Task Name <span className="text-destructive">*</span></Label>
              <Input value={taskForm.task_name} onChange={e => setTaskForm(p => ({ ...p, task_name: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Description</Label>
              <Textarea value={taskForm.description} onChange={e => setTaskForm(p => ({ ...p, description: e.target.value }))} rows={2} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Assigned To</Label>
                <EmployeeSelect value={taskForm.assigned_employee_id} onChange={v => setTaskForm(p => ({ ...p, assigned_employee_id: v }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Status</Label>
                <Select value={taskForm.task_status} onValueChange={v => setTaskForm(p => ({ ...p, task_status: v as TaskStatus }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PENDING">Pending</SelectItem>
                    <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
                    <SelectItem value="COMPLETED">Completed</SelectItem>
                    <SelectItem value="CANCELLED">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Start Date</Label>
                <Input type="date" value={taskForm.start_date} onChange={e => setTaskForm(p => ({ ...p, start_date: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>End Date</Label>
                <Input type="date" value={taskForm.end_date} onChange={e => setTaskForm(p => ({ ...p, end_date: e.target.value }))} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTaskDialog(false)}>Cancel</Button>
            <Button onClick={saveTask} disabled={savingTask}>{savingTask ? 'Saving…' : 'Save'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Project */}
      <AlertDialog open={!!deleteProj} onOpenChange={o => { if (!o) setDeleteProj(null); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-destructive" />Delete Project?
            </AlertDialogTitle>
            <AlertDialogDescription>
              <strong>"{deleteProj?.project_name}"</strong> and all its tasks will be removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDeleteProject}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Task */}
      <AlertDialog open={!!deleteTask} onOpenChange={o => { if (!o) setDeleteTask(null); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Task?</AlertDialogTitle>
            <AlertDialogDescription>
              <strong>"{deleteTask?.task_name}"</strong> will be permanently removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDeleteTask}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
