// SeparationPage — Module 10: Separation Notices + Clearance Workflows + Final Settlements
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Eye, CheckCircle2, XCircle, AlertCircle, FileText, ShieldCheck, DollarSign } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

// ─── Types ───────────────────────────────────────────────────────────────────
type SeparationNotice = {
  id: string; separation_notice_id: string; notice_number: string;
  separation_type: string; notice_date: string; last_working_day: string;
  reason?: string; notice_status: string;
  employee?: { first_name: string; last_name: string; employee_no?: string };
  approved_by?: { first_name: string; last_name: string };
};
type ClearanceWorkflow = {
  id: string; clearance_workflow_id: string; clearance_number: string;
  overall_status: string;
  hr_status: string; hr_notes?: string; hr_cleared_at?: string;
  it_status: string; it_notes?: string; it_cleared_at?: string;
  finance_status: string; finance_notes?: string; finance_cleared_at?: string;
  assets_status: string; assets_notes?: string; assets_cleared_at?: string;
  legal_status: string; legal_notes?: string; legal_cleared_at?: string;
  security_status: string; security_notes?: string; security_cleared_at?: string;
  employee?: { first_name: string; last_name: string; employee_no?: string };
  notice?: { notice_number: string; separation_type: string; last_working_day: string };
};
type FinalSettlement = {
  id: string; final_settlement_id: string; settlement_number: string;
  settlement_status: string; basic_salary_balance: number; leave_encashment: number;
  gratuity_amount: number; bonus_amount: number; deductions: number;
  loan_deductions: number; other_additions: number; other_deductions: number;
  net_payable: number; currency_code: string;
  payment_method?: string; payment_date?: string; payment_reference?: string;
  notes?: string;
  employee?: { first_name: string; last_name: string; employee_no?: string };
  approved_by?: { first_name: string; last_name: string };
};

const NOTICE_STATUS_COLORS: Record<string, string> = {
  SUBMITTED: 'bg-blue-100 text-blue-800',
  ACKNOWLEDGED: 'bg-indigo-100 text-indigo-800',
  APPROVED: 'bg-green-100 text-green-800',
  REJECTED: 'bg-red-100 text-red-800',
  WITHDRAWN: 'bg-muted text-muted-foreground',
};
const CLEARANCE_STATUS_COLORS: Record<string, string> = {
  PENDING: 'bg-yellow-100 text-yellow-800',
  CLEARED: 'bg-green-100 text-green-800',
  BLOCKED: 'bg-red-100 text-red-800',
};
const SETTLEMENT_STATUS_COLORS: Record<string, string> = {
  DRAFT: 'bg-muted text-muted-foreground',
  PENDING_APPROVAL: 'bg-yellow-100 text-yellow-800',
  APPROVED: 'bg-blue-100 text-blue-800',
  PAID: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-red-100 text-red-800',
};
const SEP_TYPES = ['RESIGNATION', 'TERMINATION', 'RETIREMENT', 'CONTRACT_END', 'REDUNDANCY', 'DEATH', 'OTHER'];
const DEPARTMENTS_CLR = ['hr', 'it', 'finance', 'assets', 'legal', 'security'] as const;
type ClrDept = typeof DEPARTMENTS_CLR[number];

export function SeparationPage() {
  const [tab, setTab] = useState('notices');

  // Notices
  const [notices, setNotices] = useState<SeparationNotice[]>([]);
  const [noticeLoading, setNoticeLoading] = useState(true);
  const [noticeDetail, setNoticeDetail] = useState<SeparationNotice | null>(null);

  // Clearances
  const [clearances, setClearances] = useState<ClearanceWorkflow[]>([]);
  const [clearanceLoading, setClearanceLoading] = useState(false);
  const [clearanceDetail, setClearanceDetail] = useState<ClearanceWorkflow | null>(null);

  // Settlements
  const [settlements, setSettlements] = useState<FinalSettlement[]>([]);
  const [settlementLoading, setSettlementLoading] = useState(false);
  const [settlementDetail, setSettlementDetail] = useState<FinalSettlement | null>(null);

  // Create dialogs
  const [createNoticeOpen, setCreateNoticeOpen] = useState(false);
  const [noticeForm, setNoticeForm] = useState({
    employee_id: '', separation_type: 'RESIGNATION',
    notice_date: new Date().toISOString().split('T')[0],
    last_working_day: '', reason: '',
  });
  const [noticeSaving, setNoticeSaving] = useState(false);

  const [createClearanceOpen, setCreateClearanceOpen] = useState(false);
  const [clearanceEmpId, setClearanceEmpId] = useState('');
  const [clearanceNoticeId, setClearanceNoticeId] = useState('');
  const [clearanceSaving, setClearanceSaving] = useState(false);

  const [createSettlementOpen, setCreateSettlementOpen] = useState(false);
  const [settlementForm, setSettlementForm] = useState({
    employee_id: '', separation_notice_id: '', clearance_workflow_id: '',
    basic_salary_balance: '0', leave_encashment: '0',
    gratuity_amount: '0', bonus_amount: '0',
    deductions: '0', loan_deductions: '0',
    other_additions: '0', other_deductions: '0',
    currency_code: 'ETB', payment_method: 'BANK_TRANSFER',
    payment_date: '', payment_reference: '', notes: '',
  });
  const [settlementSaving, setSettlementSaving] = useState(false);

  // Clearance dept update dialog
  const [clrUpdateOpen, setClrUpdateOpen] = useState<{ id: string; dept: ClrDept } | null>(null);
  const [clrNotes, setClrNotes] = useState('');
  const [clrSaving, setClrSaving] = useState(false);

  // Stats
  const pendingNotices = notices.filter(n => n.notice_status === 'SUBMITTED').length;
  const activeClearances = clearances.filter(c => c.overall_status !== 'CLEARED').length;
  const pendingSettlements = settlements.filter(s => ['DRAFT', 'PENDING_APPROVAL'].includes(s.settlement_status)).length;

  const loadNotices = useCallback(async () => {
    setNoticeLoading(true);
    try {
      const { data, error } = await sb.from('separation_notices')
        .select('id,separation_notice_id,notice_number,separation_type,notice_date,last_working_day,reason,notice_status,employee:employees!separation_notices_employee_id_fkey(first_name,last_name,employee_no),approved_by:employees!separation_notices_approved_by_id_fkey(first_name,last_name)')
        .eq('is_deleted', 0).order('created_at', { ascending: false });
      if (error) throw error;
      setNotices(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setNoticeLoading(false); }
  }, []);

  const loadClearances = useCallback(async () => {
    setClearanceLoading(true);
    try {
      const { data, error } = await sb.from('clearance_workflows')
        .select('id,clearance_workflow_id,clearance_number,overall_status,hr_status,hr_notes,hr_cleared_at,it_status,it_notes,it_cleared_at,finance_status,finance_notes,finance_cleared_at,assets_status,assets_notes,assets_cleared_at,legal_status,legal_notes,legal_cleared_at,security_status,security_notes,security_cleared_at,employee:employees!clearance_workflows_employee_id_fkey(first_name,last_name,employee_no),notice:separation_notices(notice_number,separation_type,last_working_day)')
        .eq('is_deleted', 0).order('created_at', { ascending: false });
      if (error) throw error;
      setClearances(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setClearanceLoading(false); }
  }, []);

  const loadSettlements = useCallback(async () => {
    setSettlementLoading(true);
    try {
      const { data, error } = await sb.from('final_settlements')
        .select('id,final_settlement_id,settlement_number,settlement_status,basic_salary_balance,leave_encashment,gratuity_amount,bonus_amount,deductions,loan_deductions,other_additions,other_deductions,net_payable,currency_code,payment_method,payment_date,payment_reference,notes,employee:employees!final_settlements_employee_id_fkey(first_name,last_name,employee_no),approved_by:employees!final_settlements_approved_by_id_fkey(first_name,last_name)')
        .eq('is_deleted', 0).order('created_at', { ascending: false });
      if (error) throw error;
      setSettlements(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setSettlementLoading(false); }
  }, []);

  useEffect(() => { loadNotices(); }, [loadNotices]);
  useEffect(() => { if (tab === 'clearances') loadClearances(); }, [tab, loadClearances]);
  useEffect(() => { if (tab === 'settlements') loadSettlements(); }, [tab, loadSettlements]);

  async function createNotice() {
    if (!noticeForm.employee_id || !noticeForm.last_working_day) { toast.error('Employee and last working day required'); return; }
    setNoticeSaving(true);
    try {
      const { error } = await sb.from('separation_notices').insert({
        employee_id: noticeForm.employee_id,
        separation_type: noticeForm.separation_type,
        notice_date: noticeForm.notice_date,
        last_working_day: noticeForm.last_working_day,
        reason: noticeForm.reason || null,
        notice_status: 'SUBMITTED',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Separation notice submitted');
      setCreateNoticeOpen(false);
      setNoticeForm({ employee_id: '', separation_type: 'RESIGNATION', notice_date: new Date().toISOString().split('T')[0], last_working_day: '', reason: '' });
      loadNotices();
    } catch (e: any) { toast.error(e.message); } finally { setNoticeSaving(false); }
  }

  async function updateNoticeStatus(id: string, status: string) {
    const update: Record<string, any> = { notice_status: status, updated_at: new Date().toISOString() };
    if (status === 'ACKNOWLEDGED') update.acknowledged_at = new Date().toISOString();
    if (status === 'APPROVED') update.approved_at = new Date().toISOString();
    const { error } = await sb.from('separation_notices').update(update).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Notice status updated'); loadNotices(); if (noticeDetail?.id === id) setNoticeDetail(d => d ? { ...d, notice_status: status } : d); }
  }

  async function createClearance() {
    if (!clearanceEmpId) { toast.error('Employee required'); return; }
    setClearanceSaving(true);
    try {
      const { error } = await sb.from('clearance_workflows').insert({
        employee_id: clearanceEmpId,
        separation_notice_id: clearanceNoticeId || null,
        overall_status: 'PENDING',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Clearance workflow initiated');
      setCreateClearanceOpen(false);
      setClearanceEmpId('');
      setClearanceNoticeId('');
      loadClearances();
    } catch (e: any) { toast.error(e.message); } finally { setClearanceSaving(false); }
  }

  async function clearDepartment(clrId: string, dept: ClrDept, notes: string) {
    setClrSaving(true);
    try {
      const update: Record<string, any> = {
        [`${dept}_status`]: 'CLEARED',
        [`${dept}_cleared_at`]: new Date().toISOString(),
        [`${dept}_notes`]: notes || null,
        updated_at: new Date().toISOString(),
      };
      // Recompute overall
      const { data: existing } = await sb.from('clearance_workflows').select('hr_status,it_status,finance_status,assets_status,legal_status,security_status').eq('id', clrId).maybeSingle();
      if (existing) {
        const statuses = { ...existing, [`${dept}_status`]: 'CLEARED' };
        const allCleared = DEPARTMENTS_CLR.every(d => statuses[`${d}_status`] === 'CLEARED');
        if (allCleared) update.overall_status = 'CLEARED';
        else update.overall_status = 'IN_PROGRESS';
      }
      const { error } = await sb.from('clearance_workflows').update(update).eq('id', clrId);
      if (error) throw error;
      toast.success(`${dept.toUpperCase()} clearance updated`);
      setClrUpdateOpen(null);
      setClrNotes('');
      loadClearances();
      if (clearanceDetail?.id === clrId) {
        setClearanceDetail(d => d ? { ...d, ...update } as ClearanceWorkflow : d);
      }
    } catch (e: any) { toast.error(e.message); } finally { setClrSaving(false); }
  }

  async function blockDepartment(clrId: string, dept: ClrDept) {
    const update: Record<string, any> = { [`${dept}_status`]: 'BLOCKED', overall_status: 'BLOCKED', updated_at: new Date().toISOString() };
    const { error } = await sb.from('clearance_workflows').update(update).eq('id', clrId);
    if (error) toast.error(error.message);
    else { toast.success(`${dept.toUpperCase()} blocked`); loadClearances(); }
  }

  async function createSettlement() {
    if (!settlementForm.employee_id) { toast.error('Employee required'); return; }
    setSettlementSaving(true);
    try {
      const { error } = await sb.from('final_settlements').insert({
        employee_id: settlementForm.employee_id,
        separation_notice_id: settlementForm.separation_notice_id || null,
        clearance_workflow_id: settlementForm.clearance_workflow_id || null,
        settlement_status: 'DRAFT',
        basic_salary_balance: parseFloat(settlementForm.basic_salary_balance) || 0,
        leave_encashment: parseFloat(settlementForm.leave_encashment) || 0,
        gratuity_amount: parseFloat(settlementForm.gratuity_amount) || 0,
        bonus_amount: parseFloat(settlementForm.bonus_amount) || 0,
        deductions: parseFloat(settlementForm.deductions) || 0,
        loan_deductions: parseFloat(settlementForm.loan_deductions) || 0,
        other_additions: parseFloat(settlementForm.other_additions) || 0,
        other_deductions: parseFloat(settlementForm.other_deductions) || 0,
        currency_code: settlementForm.currency_code,
        payment_method: settlementForm.payment_method || null,
        payment_date: settlementForm.payment_date || null,
        payment_reference: settlementForm.payment_reference || null,
        notes: settlementForm.notes || null,
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Final settlement created');
      setCreateSettlementOpen(false);
      loadSettlements();
    } catch (e: any) { toast.error(e.message); } finally { setSettlementSaving(false); }
  }

  async function updateSettlementStatus(id: string, status: string) {
    const update: Record<string, any> = { settlement_status: status, updated_at: new Date().toISOString() };
    if (status === 'APPROVED') update.approved_at = new Date().toISOString();
    const { error } = await sb.from('final_settlements').update(update).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Settlement status updated'); loadSettlements(); if (settlementDetail?.id === id) setSettlementDetail(d => d ? { ...d, settlement_status: status } : d); }
  }

  const fmtCcy = (v: number, ccy: string) => `${ccy} ${v.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const ClearanceStatusIcon = ({ status }: { status: string }) => {
    if (status === 'CLEARED') return <CheckCircle2 className="w-4 h-4 text-green-600" />;
    if (status === 'BLOCKED') return <XCircle className="w-4 h-4 text-red-500" />;
    return <AlertCircle className="w-4 h-4 text-yellow-500" />;
  };

  return (
    <div className="p-4 md:p-6 space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Separations</h1>
          <p className="text-sm text-muted-foreground">Separation notices, department clearance, and final settlements</p>
        </div>
        <div className="flex gap-2">
          {tab === 'notices' && <Button size="sm" onClick={() => setCreateNoticeOpen(true)}><Plus className="w-4 h-4 mr-1" /> New Notice</Button>}
          {tab === 'clearances' && <Button size="sm" onClick={() => setCreateClearanceOpen(true)}><Plus className="w-4 h-4 mr-1" /> Initiate Clearance</Button>}
          {tab === 'settlements' && <Button size="sm" onClick={() => setCreateSettlementOpen(true)}><Plus className="w-4 h-4 mr-1" /> New Settlement</Button>}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Notices', value: notices.length, icon: FileText },
          { label: 'Pending Notices', value: pendingNotices, icon: FileText },
          { label: 'Active Clearances', value: activeClearances, icon: ShieldCheck },
          { label: 'Pending Settlements', value: pendingSettlements, icon: DollarSign },
        ].map(s => (
          <Card key={s.label} className="h-full">
            <CardContent className="p-4 flex items-center gap-3">
              <s.icon className="w-8 h-8 text-primary shrink-0" />
              <div><p className="text-2xl font-bold">{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="notices">Separation Notices</TabsTrigger>
          <TabsTrigger value="clearances">Clearance Workflows</TabsTrigger>
          <TabsTrigger value="settlements">Final Settlements</TabsTrigger>
        </TabsList>

        {/* ── Notices Tab ── */}
        <TabsContent value="notices" className="mt-4">
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Notice #</TableHead>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Type</TableHead>
                  <TableHead className="whitespace-nowrap">Notice Date</TableHead>
                  <TableHead className="whitespace-nowrap">Last Working Day</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {noticeLoading ? (
                  Array.from({ length: 5 }).map((_, i) => <TableRow key={i}><TableCell colSpan={7}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>)
                ) : notices.length === 0 ? (
                  <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-10">No separation notices found.</TableCell></TableRow>
                ) : notices.map(n => (
                  <TableRow key={n.id}>
                    <TableCell className="whitespace-nowrap font-mono text-sm">{n.notice_number}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">
                      {n.employee ? `${n.employee.first_name} ${n.employee.last_name}` : '—'}
                      {n.employee?.employee_no && <span className="ml-1 text-xs text-muted-foreground">({n.employee.employee_no})</span>}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{n.separation_type.replace('_', ' ')}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{n.notice_date}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{n.last_working_day}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${NOTICE_STATUS_COLORS[n.notice_status]}`}>{n.notice_status}</Badge>
                    </TableCell>
                    <TableCell className="text-right whitespace-nowrap">
                      <Button size="sm" variant="ghost" onClick={() => setNoticeDetail(n)}><Eye className="w-4 h-4" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* ── Clearances Tab ── */}
        <TabsContent value="clearances" className="mt-4">
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Clearance #</TableHead>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">HR</TableHead>
                  <TableHead className="whitespace-nowrap">IT</TableHead>
                  <TableHead className="whitespace-nowrap">Finance</TableHead>
                  <TableHead className="whitespace-nowrap">Assets</TableHead>
                  <TableHead className="whitespace-nowrap">Legal</TableHead>
                  <TableHead className="whitespace-nowrap">Security</TableHead>
                  <TableHead className="whitespace-nowrap">Overall</TableHead>
                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clearanceLoading ? (
                  Array.from({ length: 4 }).map((_, i) => <TableRow key={i}><TableCell colSpan={10}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>)
                ) : clearances.length === 0 ? (
                  <TableRow><TableCell colSpan={10} className="text-center text-muted-foreground py-10">No clearance workflows found.</TableCell></TableRow>
                ) : clearances.map(c => (
                  <TableRow key={c.id}>
                    <TableCell className="whitespace-nowrap font-mono text-sm">{c.clearance_number}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">
                      {c.employee ? `${c.employee.first_name} ${c.employee.last_name}` : '—'}
                    </TableCell>
                    {DEPARTMENTS_CLR.map(dept => (
                      <TableCell key={dept} className="whitespace-nowrap text-center">
                        <div className="flex items-center justify-center gap-1">
                          <ClearanceStatusIcon status={(c as any)[`${dept}_status`]} />
                          {(c as any)[`${dept}_status`] === 'PENDING' && (
                            <Button size="sm" variant="ghost" className="text-xs h-6 px-1" onClick={() => { setClrUpdateOpen({ id: c.id, dept }); setClrNotes(''); }}>
                              Clear
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    ))}
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${CLEARANCE_STATUS_COLORS[c.overall_status]}`}>{c.overall_status}</Badge>
                    </TableCell>
                    <TableCell className="text-right whitespace-nowrap">
                      <Button size="sm" variant="ghost" onClick={() => setClearanceDetail(c)}><Eye className="w-4 h-4" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* ── Settlements Tab ── */}
        <TabsContent value="settlements" className="mt-4">
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Settlement #</TableHead>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Basic Balance</TableHead>
                  <TableHead className="whitespace-nowrap">Leave Encash</TableHead>
                  <TableHead className="whitespace-nowrap">Gratuity</TableHead>
                  <TableHead className="whitespace-nowrap">Deductions</TableHead>
                  <TableHead className="whitespace-nowrap">Net Payable</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {settlementLoading ? (
                  Array.from({ length: 4 }).map((_, i) => <TableRow key={i}><TableCell colSpan={9}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>)
                ) : settlements.length === 0 ? (
                  <TableRow><TableCell colSpan={9} className="text-center text-muted-foreground py-10">No final settlements found.</TableCell></TableRow>
                ) : settlements.map(s => (
                  <TableRow key={s.id}>
                    <TableCell className="whitespace-nowrap font-mono text-sm">{s.settlement_number}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">
                      {s.employee ? `${s.employee.first_name} ${s.employee.last_name}` : '—'}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtCcy(s.basic_salary_balance, s.currency_code)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtCcy(s.leave_encashment, s.currency_code)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtCcy(s.gratuity_amount, s.currency_code)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-destructive">{fmtCcy(s.deductions + s.loan_deductions + s.other_deductions, s.currency_code)}</TableCell>
                    <TableCell className="whitespace-nowrap font-semibold">{fmtCcy(s.net_payable, s.currency_code)}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${SETTLEMENT_STATUS_COLORS[s.settlement_status]}`}>{s.settlement_status.replace('_', ' ')}</Badge>
                    </TableCell>
                    <TableCell className="text-right whitespace-nowrap">
                      <Button size="sm" variant="ghost" onClick={() => setSettlementDetail(s)}><Eye className="w-4 h-4" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      {/* ── Notice Detail Dialog ── */}
      <Dialog open={!!noticeDetail} onOpenChange={() => setNoticeDetail(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{noticeDetail?.notice_number}</DialogTitle></DialogHeader>
          {noticeDetail && (
            <div className="space-y-3 pt-2 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div><p className="text-muted-foreground">Employee</p><p className="font-medium">{noticeDetail.employee ? `${noticeDetail.employee.first_name} ${noticeDetail.employee.last_name}` : '—'}</p></div>
                <div><p className="text-muted-foreground">Type</p><p className="font-medium">{noticeDetail.separation_type.replace('_', ' ')}</p></div>
                <div><p className="text-muted-foreground">Notice Date</p><p className="font-medium">{noticeDetail.notice_date}</p></div>
                <div><p className="text-muted-foreground">Last Working Day</p><p className="font-medium">{noticeDetail.last_working_day}</p></div>
              </div>
              {noticeDetail.reason && <div><p className="text-muted-foreground">Reason</p><p className="whitespace-pre-wrap">{noticeDetail.reason}</p></div>}
              <div><p className="text-muted-foreground mb-1">Status</p><Badge className={`text-xs ${NOTICE_STATUS_COLORS[noticeDetail.notice_status]}`}>{noticeDetail.notice_status}</Badge></div>
              {noticeDetail.notice_status === 'SUBMITTED' && (
                <div className="flex gap-2 flex-wrap pt-1">
                  <Button size="sm" onClick={() => updateNoticeStatus(noticeDetail.id, 'ACKNOWLEDGED')}>Acknowledge</Button>
                  <Button size="sm" variant="outline" onClick={() => updateNoticeStatus(noticeDetail.id, 'APPROVED')}>Approve</Button>
                  <Button size="sm" variant="outline" onClick={() => updateNoticeStatus(noticeDetail.id, 'REJECTED')} className="text-destructive border-destructive hover:bg-destructive/10">Reject</Button>
                </div>
              )}
              {noticeDetail.notice_status === 'ACKNOWLEDGED' && (
                <div className="flex gap-2 pt-1">
                  <Button size="sm" onClick={() => updateNoticeStatus(noticeDetail.id, 'APPROVED')}>Approve</Button>
                  <Button size="sm" variant="outline" onClick={() => updateNoticeStatus(noticeDetail.id, 'REJECTED')} className="text-destructive border-destructive hover:bg-destructive/10">Reject</Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ── Clearance Detail Dialog ── */}
      <Dialog open={!!clearanceDetail} onOpenChange={() => setClearanceDetail(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>{clearanceDetail?.clearance_number}</DialogTitle></DialogHeader>
          {clearanceDetail && (
            <div className="space-y-4 pt-2 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div><p className="text-muted-foreground">Employee</p><p className="font-medium">{clearanceDetail.employee ? `${clearanceDetail.employee.first_name} ${clearanceDetail.employee.last_name}` : '—'}</p></div>
                <div><p className="text-muted-foreground">Overall Status</p><Badge className={`text-xs mt-1 ${CLEARANCE_STATUS_COLORS[clearanceDetail.overall_status]}`}>{clearanceDetail.overall_status}</Badge></div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {DEPARTMENTS_CLR.map(dept => {
                  const status = (clearanceDetail as any)[`${dept}_status`] as string;
                  const notes = (clearanceDetail as any)[`${dept}_notes`] as string | undefined;
                  const clearedAt = (clearanceDetail as any)[`${dept}_cleared_at`] as string | undefined;
                  return (
                    <Card key={dept} className="h-full">
                      <CardContent className="p-3">
                        <div className="flex items-center gap-2 mb-1">
                          <ClearanceStatusIcon status={status} />
                          <span className="font-semibold uppercase text-xs">{dept}</span>
                          <Badge className={`text-xs ml-auto ${CLEARANCE_STATUS_COLORS[status]}`}>{status}</Badge>
                        </div>
                        {clearedAt && <p className="text-xs text-muted-foreground">Cleared: {new Date(clearedAt).toLocaleDateString()}</p>}
                        {notes && <p className="text-xs text-muted-foreground mt-1">{notes}</p>}
                        {status === 'PENDING' && (
                          <div className="flex gap-1 mt-2">
                            <Button size="sm" className="text-xs h-6" onClick={() => { setClrUpdateOpen({ id: clearanceDetail.id, dept }); setClrNotes(''); }}>Clear</Button>
                            <Button size="sm" variant="outline" className="text-xs h-6 text-destructive border-destructive hover:bg-destructive/10" onClick={() => blockDepartment(clearanceDetail.id, dept)}>Block</Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ── Settlement Detail Dialog ── */}
      <Dialog open={!!settlementDetail} onOpenChange={() => setSettlementDetail(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{settlementDetail?.settlement_number}</DialogTitle></DialogHeader>
          {settlementDetail && (
            <div className="space-y-3 pt-2 text-sm">
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: 'Basic Salary Balance', value: settlementDetail.basic_salary_balance },
                  { label: 'Leave Encashment', value: settlementDetail.leave_encashment },
                  { label: 'Gratuity', value: settlementDetail.gratuity_amount },
                  { label: 'Bonus', value: settlementDetail.bonus_amount },
                  { label: 'Other Additions', value: settlementDetail.other_additions },
                  { label: 'Deductions', value: settlementDetail.deductions },
                  { label: 'Loan Deductions', value: settlementDetail.loan_deductions },
                  { label: 'Other Deductions', value: settlementDetail.other_deductions },
                ].map(row => (
                  <div key={row.label} className="flex justify-between border-b pb-1">
                    <span className="text-muted-foreground">{row.label}</span>
                    <span>{fmtCcy(row.value, settlementDetail.currency_code)}</span>
                  </div>
                ))}
                <div className="col-span-2 flex justify-between font-semibold pt-1 text-base">
                  <span>Net Payable</span>
                  <span>{fmtCcy(settlementDetail.net_payable, settlementDetail.currency_code)}</span>
                </div>
              </div>
              {settlementDetail.payment_date && (
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div><p className="text-muted-foreground">Payment Method</p><p>{settlementDetail.payment_method}</p></div>
                  <div><p className="text-muted-foreground">Payment Date</p><p>{settlementDetail.payment_date}</p></div>
                </div>
              )}
              <div><p className="text-muted-foreground mb-1">Status</p><Badge className={`text-xs ${SETTLEMENT_STATUS_COLORS[settlementDetail.settlement_status]}`}>{settlementDetail.settlement_status.replace('_', ' ')}</Badge></div>
              {settlementDetail.settlement_status === 'DRAFT' && (
                <Button size="sm" className="w-full" onClick={() => updateSettlementStatus(settlementDetail.id, 'PENDING_APPROVAL')}>Submit for Approval</Button>
              )}
              {settlementDetail.settlement_status === 'PENDING_APPROVAL' && (
                <div className="flex gap-2">
                  <Button size="sm" className="flex-1" onClick={() => updateSettlementStatus(settlementDetail.id, 'APPROVED')}>Approve</Button>
                  <Button size="sm" variant="outline" className="flex-1 text-destructive border-destructive hover:bg-destructive/10" onClick={() => updateSettlementStatus(settlementDetail.id, 'CANCELLED')}>Reject</Button>
                </div>
              )}
              {settlementDetail.settlement_status === 'APPROVED' && (
                <Button size="sm" className="w-full" onClick={() => updateSettlementStatus(settlementDetail.id, 'PAID')}>Mark as Paid</Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ── Create Notice Dialog ── */}
      <Dialog open={createNoticeOpen} onOpenChange={setCreateNoticeOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Separation Notice</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div><Label>Employee *</Label><EmployeeSelect value={noticeForm.employee_id} onChange={v => setNoticeForm(f => ({ ...f, employee_id: v }))} /></div>
            <div>
              <Label>Separation Type *</Label>
              <Select value={noticeForm.separation_type} onValueChange={v => setNoticeForm(f => ({ ...f, separation_type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{SEP_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace('_', ' ')}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Notice Date *</Label><Input type="date" value={noticeForm.notice_date} onChange={e => setNoticeForm(f => ({ ...f, notice_date: e.target.value }))} /></div>
              <div><Label>Last Working Day *</Label><Input type="date" value={noticeForm.last_working_day} onChange={e => setNoticeForm(f => ({ ...f, last_working_day: e.target.value }))} /></div>
            </div>
            <div><Label>Reason</Label><Textarea value={noticeForm.reason} onChange={e => setNoticeForm(f => ({ ...f, reason: e.target.value }))} rows={3} /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCreateNoticeOpen(false)}>Cancel</Button>
              <Button onClick={createNotice} disabled={noticeSaving}>{noticeSaving ? 'Submitting…' : 'Submit Notice'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Create Clearance Dialog ── */}
      <Dialog open={createClearanceOpen} onOpenChange={setCreateClearanceOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Initiate Clearance Workflow</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div><Label>Employee *</Label><EmployeeSelect value={clearanceEmpId} onChange={setClearanceEmpId} /></div>
            <div>
              <Label>Link to Separation Notice (optional)</Label>
              <Select value={clearanceNoticeId} onValueChange={setClearanceNoticeId}>
                <SelectTrigger><SelectValue placeholder="Select notice (optional)" /></SelectTrigger>
                <SelectContent>
                  {notices.filter(n => ['APPROVED', 'ACKNOWLEDGED'].includes(n.notice_status)).map(n => (
                    <SelectItem key={n.separation_notice_id} value={n.separation_notice_id}>
                      {n.notice_number} — {n.employee?.first_name} {n.employee?.last_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCreateClearanceOpen(false)}>Cancel</Button>
              <Button onClick={createClearance} disabled={clearanceSaving}>{clearanceSaving ? 'Creating…' : 'Initiate Clearance'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Dept Clear Dialog ── */}
      <Dialog open={!!clrUpdateOpen} onOpenChange={() => setClrUpdateOpen(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle>Clear {clrUpdateOpen?.dept.toUpperCase()} Department</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div><Label>Notes (optional)</Label><Textarea value={clrNotes} onChange={e => setClrNotes(e.target.value)} rows={3} placeholder="Clearance notes…" /></div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setClrUpdateOpen(null)}>Cancel</Button>
              <Button onClick={() => clrUpdateOpen && clearDepartment(clrUpdateOpen.id, clrUpdateOpen.dept, clrNotes)} disabled={clrSaving}>
                {clrSaving ? 'Saving…' : 'Confirm Clearance'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Create Settlement Dialog ── */}
      <Dialog open={createSettlementOpen} onOpenChange={setCreateSettlementOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>New Final Settlement</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="md:col-span-2"><Label>Employee *</Label><EmployeeSelect value={settlementForm.employee_id} onChange={v => setSettlementForm(f => ({ ...f, employee_id: v }))} /></div>
              <div>
                <Label>Link Separation Notice</Label>
                <Select value={settlementForm.separation_notice_id} onValueChange={v => setSettlementForm(f => ({ ...f, separation_notice_id: v }))}>
                  <SelectTrigger><SelectValue placeholder="Select notice (optional)" /></SelectTrigger>
                  <SelectContent>{notices.map(n => <SelectItem key={n.separation_notice_id} value={n.separation_notice_id}>{n.notice_number} — {n.employee?.first_name} {n.employee?.last_name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Currency</Label>
                <Select value={settlementForm.currency_code} onValueChange={v => setSettlementForm(f => ({ ...f, currency_code: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['ETB', 'USD', 'EUR', 'GBP', 'MYR', 'SGD', 'AED'].map(c => <SelectItem key={c} value={c}>{c === 'ETB' ? 'ETB — ብር' : c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <p className="text-xs font-semibold uppercase text-muted-foreground">Additions</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { key: 'basic_salary_balance', label: 'Basic Balance' },
                { key: 'leave_encashment', label: 'Leave Encashment' },
                { key: 'gratuity_amount', label: 'Gratuity' },
                { key: 'bonus_amount', label: 'Bonus' },
                { key: 'other_additions', label: 'Other Additions' },
              ].map(({ key, label }) => (
                <div key={key}>
                  <Label>{label}</Label>
                  <Input type="number" min="0" step="0.01" value={(settlementForm as any)[key]} onChange={e => setSettlementForm(f => ({ ...f, [key]: e.target.value }))} />
                </div>
              ))}
            </div>
            <p className="text-xs font-semibold uppercase text-muted-foreground">Deductions</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { key: 'deductions', label: 'Statutory Deductions' },
                { key: 'loan_deductions', label: 'Loan Deductions' },
                { key: 'other_deductions', label: 'Other Deductions' },
              ].map(({ key, label }) => (
                <div key={key}>
                  <Label>{label}</Label>
                  <Input type="number" min="0" step="0.01" value={(settlementForm as any)[key]} onChange={e => setSettlementForm(f => ({ ...f, [key]: e.target.value }))} />
                </div>
              ))}
            </div>
            <p className="text-xs font-semibold uppercase text-muted-foreground">Payment Info</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <Label>Payment Method</Label>
                <Select value={settlementForm.payment_method} onValueChange={v => setSettlementForm(f => ({ ...f, payment_method: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['BANK_TRANSFER', 'CHEQUE', 'CASH', 'OTHER'].map(m => <SelectItem key={m} value={m}>{m.replace('_', ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Payment Date</Label><Input type="date" value={settlementForm.payment_date} onChange={e => setSettlementForm(f => ({ ...f, payment_date: e.target.value }))} /></div>
              <div className="md:col-span-2"><Label>Payment Reference</Label><Input value={settlementForm.payment_reference} onChange={e => setSettlementForm(f => ({ ...f, payment_reference: e.target.value }))} /></div>
            </div>
            <div><Label>Notes</Label><Textarea value={settlementForm.notes} onChange={e => setSettlementForm(f => ({ ...f, notes: e.target.value }))} rows={2} /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCreateSettlementOpen(false)}>Cancel</Button>
              <Button onClick={createSettlement} disabled={settlementSaving}>{settlementSaving ? 'Creating…' : 'Create Settlement'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ClearanceStatusIcon({ status }: { status: string }) {
  if (status === 'CLEARED') return <CheckCircle2 className="w-4 h-4 text-green-600" />;
  if (status === 'BLOCKED') return <XCircle className="w-4 h-4 text-red-500" />;
  return <AlertCircle className="w-4 h-4 text-yellow-500" />;
}
