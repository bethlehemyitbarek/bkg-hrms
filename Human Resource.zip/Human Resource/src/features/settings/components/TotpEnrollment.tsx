import { useState, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const supabase = _sb as any;
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import {
  ShieldCheck, ShieldOff, Loader2, Copy, CheckCircle2, Smartphone,
} from 'lucide-react';

type EnrollStep = 'idle' | 'qr' | 'verify' | 'done';

export interface TotpFactor {
  id: string;
  friendly_name?: string;
  factor_type: string;
  status: string;
}

interface TotpEnrollmentProps {
  factors: TotpFactor[];
  onFactorsChange: () => void;
}

export function TotpEnrollment({ factors, onFactorsChange }: TotpEnrollmentProps) {
  const [step,      setStep]      = useState<EnrollStep>('idle');
  const [qrSvg,    setQrSvg]     = useState('');
  const [secret,   setSecret]    = useState('');
  const [factorId, setFactorId]  = useState('');
  const [code,     setCode]      = useState('');
  const [loading,  setLoading]   = useState(false);
  const [copied,   setCopied]    = useState(false);
  const [pendingUnenroll, setPendingUnenroll] = useState('');

  const verifiedFactors   = factors.filter(f => f.factor_type === 'totp' && f.status === 'verified');
  const unverifiedFactors = factors.filter(f => f.factor_type === 'totp' && f.status === 'unverified');

  /* ── Step 1: Start enrollment ──────────────────────────────────────── */
  const startEnroll = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.mfa.enroll({
        factorType: 'totp',
        friendlyName: `BKG HRMS (${new Date().toLocaleDateString()})`,
      });
      if (error) throw error;
      setQrSvg(data.totp.qr_code);
      setSecret(data.totp.secret);
      setFactorId(data.id);
      setStep('qr');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to start enrollment');
    } finally {
      setLoading(false);
    }
  }, []);

  /* ── Step 2: Verify 6-digit code ──────────────────────────────────── */
  const verifyCode = useCallback(async () => {
    if (code.length !== 6) {
      toast.error('Enter the 6-digit code from your authenticator app');
      return;
    }
    setLoading(true);
    try {
      const { data: challengeData, error: challengeErr } = await supabase.auth.mfa.challenge({ factorId });
      if (challengeErr) throw challengeErr;

      const { error: verifyErr } = await supabase.auth.mfa.verify({
        factorId,
        challengeId: challengeData.id,
        code,
      });
      if (verifyErr) throw verifyErr;

      toast.success('Authenticator enrolled successfully!');
      setStep('done');
      onFactorsChange();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Incorrect code — please try again');
    } finally {
      setLoading(false);
    }
  }, [code, factorId, onFactorsChange]);

  /* ── Unenroll ─────────────────────────────────────────────────────── */
  const unenroll = useCallback(async (fId: string) => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.mfa.unenroll({ factorId: fId });
      if (error) throw error;
      toast.success('Authenticator removed');
      onFactorsChange();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to remove authenticator');
    } finally {
      setLoading(false);
      setPendingUnenroll('');
    }
  }, [onFactorsChange]);

  /* ── Copy secret ──────────────────────────────────────────────────── */
  const copySecret = () => {
    navigator.clipboard.writeText(secret).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const reset = () => {
    setStep('idle');
    setCode('');
    setQrSvg('');
    setSecret('');
    setFactorId('');
  };

  return (
    <div className="space-y-4">
      {/* Active devices */}
      {verifiedFactors.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm font-medium">Enrolled Authenticators</p>
          {verifiedFactors.map(f => (
            <div
              key={f.id}
              className="flex items-center justify-between p-3 border border-border rounded-lg bg-card gap-3"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="h-8 w-8 rounded-md bg-green-100 flex items-center justify-center shrink-0">
                  <Smartphone className="h-4 w-4 text-green-700" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">
                    {f.friendly_name || 'Authenticator App'}
                  </p>
                  <p className="text-xs text-muted-foreground font-mono">{f.id.slice(0, 8)}…</p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Badge variant="secondary" className="text-green-700 bg-green-100 border-0 text-xs hidden sm:flex">
                  <CheckCircle2 className="h-3 w-3 mr-1" />Active
                </Badge>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive hover:bg-destructive/10 h-8"
                      onClick={() => setPendingUnenroll(f.id)}
                    >
                      <ShieldOff className="h-3.5 w-3.5 mr-1.5" />Remove
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                    <AlertDialogHeader>
                      <AlertDialogTitle>Remove authenticator?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This disables two-factor authentication on your account.
                        You can re-enroll a new authenticator at any time.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel onClick={() => setPendingUnenroll('')}>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => unenroll(pendingUnenroll || f.id)}
                        disabled={loading}
                      >
                        {loading
                          ? <Loader2 className="h-4 w-4 animate-spin" />
                          : 'Remove'}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Incomplete enrollment warning */}
      {unverifiedFactors.length > 0 && (
        <div className="p-3 rounded-lg border border-yellow-200 bg-yellow-50 text-yellow-800 text-sm flex items-start gap-2">
          <ShieldOff className="h-4 w-4 mt-0.5 shrink-0" />
          <span>
            You have an incomplete enrollment pending. Starting a new one will replace it.
          </span>
        </div>
      )}

      <Separator />

      {/* IDLE */}
      {step === 'idle' && (
        <div className="flex flex-col items-start gap-3">
          <p className="text-sm text-muted-foreground text-pretty">
            {verifiedFactors.length === 0
              ? 'No authenticator app enrolled. Add one to protect your account with two-factor authentication.'
              : 'Add another authenticator as a backup device.'}
          </p>
          <Button onClick={startEnroll} disabled={loading}>
            {loading
              ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Starting…</>
              : <><ShieldCheck className="h-4 w-4 mr-2" />Enroll Authenticator App</>}
          </Button>
        </div>
      )}

      {/* QR CODE */}
      {step === 'qr' && (
        <div className="space-y-5">
          <p className="text-sm text-muted-foreground text-pretty">
            Open your authenticator app (Google Authenticator, Authy, 1Password, etc.)
            and scan the QR code below.
          </p>

          <div className="flex justify-center">
            <div
              className="border border-border rounded-xl p-4 bg-white shadow-sm"
              dangerouslySetInnerHTML={{ __html: qrSvg }}
              style={{ width: 200, height: 200 }}
            />
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">
              Can't scan? Enter this setup key manually:
            </Label>
            <div className="flex items-center gap-2">
              <Input
                readOnly
                value={secret}
                className="font-mono text-xs bg-muted tracking-widest"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={copySecret}
                className="shrink-0 h-9 w-9"
              >
                {copied
                  ? <CheckCircle2 className="h-4 w-4 text-green-600" />
                  : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={reset}>Cancel</Button>
            <Button onClick={() => setStep('verify')}>
              I've scanned the code — Next
            </Button>
          </div>
        </div>
      )}

      {/* VERIFY */}
      {step === 'verify' && (
        <div className="space-y-5">
          <p className="text-sm text-muted-foreground text-pretty">
            Enter the 6-digit code shown in your authenticator app to confirm enrollment.
          </p>

          <div className="space-y-1.5 max-w-xs">
            <Label htmlFor="totp-code">6-Digit Code</Label>
            <Input
              id="totp-code"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={6}
              placeholder="000000"
              value={code}
              onChange={e => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
              onKeyDown={e => e.key === 'Enter' && verifyCode()}
              className="text-center text-xl font-mono tracking-[0.4em] h-12"
              autoFocus
            />
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setStep('qr')}>Back</Button>
            <Button
              onClick={verifyCode}
              disabled={loading || code.length !== 6}
            >
              {loading
                ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Verifying…</>
                : 'Verify & Activate'}
            </Button>
          </div>
        </div>
      )}

      {/* DONE */}
      {step === 'done' && (
        <div className="flex flex-col items-start gap-3">
          <div className="flex items-start gap-3 p-4 rounded-lg bg-green-50 border border-green-200 w-full">
            <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-green-800">Authenticator enrolled!</p>
              <p className="text-xs text-green-700 mt-0.5 text-pretty">
                Your account is now protected with two-factor authentication.
                You will be asked for a code on each login.
              </p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={reset}>
            Enroll Another Device
          </Button>
        </div>
      )}
    </div>
  );
}
