import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const supabase = _sb as any;
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Save, KeyRound, Building2, UserCog, ShieldCheck } from 'lucide-react';
import { useSelector } from 'react-redux';
import { RootState } from '@/app/store';
import { TotpEnrollment, type TotpFactor } from '../components/TotpEnrollment';

export function SettingsPage() {
  const authUser = useSelector((state: RootState) => state.auth.user);

  const [businessUnits,  setBusinessUnits]  = useState<Record<string, unknown>[]>([]);
  const [loadingBU,      setLoadingBU]      = useState(true);
  const [passwordForm,   setPasswordForm]   = useState({ new_password: '', confirm_password: '' });
  const [savingPassword, setSavingPassword] = useState(false);
  const [factors,        setFactors]        = useState<TotpFactor[]>([]);

  useEffect(() => {
    supabase.from('business_units').select('*').order('name')
      .then(({ data, error }: { data: any; error: any }) => {
        if (!error) setBusinessUnits((data || []) as Record<string, unknown>[]);
        setLoadingBU(false);
      });
  }, []);

  const loadFactors = useCallback(async () => {
    try {
      const { data, error } = await supabase.auth.mfa.listFactors();
      if (error) throw error;
      setFactors((data?.totp ?? []) as TotpFactor[]);
    } catch {
      // MFA listing silently ignored if unavailable
    }
  }, []);

  useEffect(() => { loadFactors(); }, [loadFactors]);

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordForm.new_password !== passwordForm.confirm_password) {
      toast.error('Passwords do not match');
      return;
    }
    if (passwordForm.new_password.length < 8) {
      toast.error('Password must be at least 8 characters');
      return;
    }
    setSavingPassword(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: passwordForm.new_password });
      if (error) throw error;
      toast.success('Password updated successfully');
      setPasswordForm({ new_password: '', confirm_password: '' });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update password');
    } finally {
      setSavingPassword(false);
    }
  };

  return (
    <div className="space-y-5 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold text-balance">Settings</h1>
        <p className="text-sm text-muted-foreground mt-0.5">System and account configuration</p>
      </div>

      <Tabs defaultValue="account">
        <TabsList>
          <TabsTrigger value="account">
            <UserCog className="h-3.5 w-3.5 mr-1.5" />Account
          </TabsTrigger>
          <TabsTrigger value="security">
            <KeyRound className="h-3.5 w-3.5 mr-1.5" />Security
          </TabsTrigger>
          <TabsTrigger value="company">
            <Building2 className="h-3.5 w-3.5 mr-1.5" />Company
          </TabsTrigger>
        </TabsList>

        {/* ── ACCOUNT ── */}
        <TabsContent value="account" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Account Information</CardTitle>
              <CardDescription>Your login and profile details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label>Email</Label>
                <Input value={authUser?.email ?? ''} readOnly className="bg-muted" />
              </div>
              <div className="space-y-1.5">
                <Label>User ID</Label>
                <Input value={authUser?.id ?? ''} readOnly className="bg-muted font-mono text-xs" />
              </div>
              <div className="space-y-1.5">
                <Label>Roles</Label>
                <Input value={(authUser?.roles ?? []).join(', ')} readOnly className="bg-muted" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── SECURITY ── */}
        <TabsContent value="security" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Change Password</CardTitle>
              <CardDescription>Update your account password</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleChangePassword} className="space-y-4">
                <div className="space-y-1.5">
                  <Label>New Password *</Label>
                  <Input
                    type="password"
                    value={passwordForm.new_password}
                    onChange={e => setPasswordForm(p => ({ ...p, new_password: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Confirm New Password *</Label>
                  <Input
                    type="password"
                    value={passwordForm.confirm_password}
                    onChange={e => setPasswordForm(p => ({ ...p, confirm_password: e.target.value }))}
                    required
                  />
                </div>
                <Button type="submit" disabled={savingPassword}>
                  <Save className="h-4 w-4 mr-1.5" />
                  {savingPassword ? 'Updating…' : 'Update Password'}
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-primary" />
                Two-Factor Authentication (TOTP)
              </CardTitle>
              <CardDescription>
                Use an authenticator app to add a second layer of protection to your account.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <TotpEnrollment factors={factors} onFactorsChange={loadFactors} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── COMPANY ── */}
        <TabsContent value="company" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Business Units</CardTitle>
              <CardDescription>Configured business entities in your organization</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingBU
                ? <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-8 rounded bg-muted animate-pulse" />)}</div>
                : businessUnits.length === 0
                  ? <p className="text-sm text-muted-foreground">No business units configured</p>
                  : (
                    <ul className="space-y-2">
                      {businessUnits.map((bu, i) => (
                        <li key={String(bu.id ?? i)} className="flex items-center justify-between p-3 border border-border rounded-lg text-sm">
                          <div>
                            <span className="font-medium">{String(bu.name ?? '')}</span>
                            <span className="ml-2 text-muted-foreground font-mono text-xs">{String(bu.code ?? '')}</span>
                          </div>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${bu.is_active ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}`}>
                            {bu.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
