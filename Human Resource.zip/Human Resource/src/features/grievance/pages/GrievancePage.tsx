import { useState, useEffect, useCallback } from 'react';
import { grievanceService } from '@/services/modules.service';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, MessageSquareWarning } from 'lucide-react';
import { toast } from 'sonner';

const STATUS_COLORS: Record<string, string> = {
  open: 'bg-red-100 text-red-800',
  under_review: 'bg-yellow-100 text-yellow-800',
  resolved: 'bg-green-100 text-green-800',
  closed: 'bg-muted text-muted-foreground',
  escalated: 'bg-orange-100 text-orange-800',
};

const PRIORITY_COLORS: Record<string, string> = {
  low: 'bg-muted text-muted-foreground',
  medium: 'bg-blue-100 text-blue-800',
  high: 'bg-orange-100 text-orange-800',
  critical: 'bg-red-100 text-red-800',
};

export function GrievancePage() {
  const [records, setRecords] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [statusFilter, setStatusFilter] = useState('all');
  const [dialog, setDialog] = useState(false);
  const [saving, setSaving] = useState(false);
  // DB columns: employee_id, category, description, priority, is_anonymous, filed_date, status
  const [form, setForm] = useState({
    employee_id: '', category: 'workplace',
    description: '', priority: 'medium', is_anonymous: false,
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await grievanceService.list({ status: statusFilter !== 'all' ? statusFilter : undefined, page: 1, pageSize: 30 });
      setRecords(res.data as Record<string, unknown>[]);
      setTotal(res.total);
    } catch { toast.error('Failed to load grievances'); }
    finally { setLoading(false); }
  }, [statusFilter]);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.is_anonymous && (!form.employee_id || form.employee_id === 'none')) {
      toast.error('Please select an employee or check Anonymous');
      return;
    }
    setSaving(true);
    try {
      await grievanceService.create({
        employee_id: form.is_anonymous ? null : form.employee_id,
        category: form.category,
        description: form.description,
        priority: form.priority,
        is_anonymous: form.is_anonymous,
        status: 'open',
      });
      toast.success('Grievance filed successfully');
      setDialog(false);
      setForm({ employee_id: '', category: 'workplace', description: '', priority: 'medium', is_anonymous: false });
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to file grievance'); }
    finally { setSaving(false); }
  };

  const emp = (r: Record<string, unknown>) => {
    if (r.is_anonymous) return 'Anonymous';
    const e = r.employee as Record<string, unknown> | undefined;
    return e ? `${e.first_name} ${e.last_name}` : '—';
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2"><MessageSquareWarning className="h-5 w-5 text-primary" />Grievances</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} cases</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-36 h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="under_review">Under Review</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
            </SelectContent>
          </Select>
          <Dialog open={dialog} onOpenChange={setDialog}>
            <DialogTrigger asChild>
              <Button size="sm"><Plus className="h-4 w-4 mr-1.5" />File Grievance</Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>File a Grievance</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 mt-2">
                <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                  <Checkbox
                    id="anon"
                    checked={form.is_anonymous}
                    onCheckedChange={v => setForm(p => ({ ...p, is_anonymous: Boolean(v), employee_id: Boolean(v) ? '' : p.employee_id }))}
                  />
                  <Label htmlFor="anon" className="cursor-pointer">File anonymously</Label>
                </div>
                {!form.is_anonymous && (
                  <EmployeeSelect value={form.employee_id} onChange={v => setForm(p => ({ ...p, employee_id: v }))} required={!form.is_anonymous} />
                )}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Category *</Label>
                    <Select value={form.category} onValueChange={v => setForm(p => ({ ...p, category: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="workplace">Workplace</SelectItem>
                        <SelectItem value="harassment">Harassment</SelectItem>
                        <SelectItem value="discrimination">Discrimination</SelectItem>
                        <SelectItem value="compensation">Compensation</SelectItem>
                        <SelectItem value="management">Management</SelectItem>
                        <SelectItem value="safety">Safety</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Priority</Label>
                    <Select value={form.priority} onValueChange={v => setForm(p => ({ ...p, priority: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-1.5"><Label>Description *</Label><Textarea rows={4} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} required placeholder="Describe the grievance in detail…" /></div>
                <Button type="submit" className="w-full" disabled={saving}>{saving ? 'Filing…' : 'File Grievance'}</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Case #</TableHead>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Category</TableHead>
                <TableHead className="whitespace-nowrap">Priority</TableHead>
                <TableHead className="whitespace-nowrap">Filed Date</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                : records.length === 0 ? <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No grievances found</TableCell></TableRow>
                : records.map(r => (
                  <TableRow key={String(r.id)}>
                    <TableCell className="whitespace-nowrap text-sm font-mono">{r.case_number ? String(r.case_number) : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">{emp(r)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm capitalize">{String(r.category)}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={PRIORITY_COLORS[String(r.priority)] || 'bg-muted'}>{String(r.priority)}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.filed_date ? String(r.filed_date) : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={STATUS_COLORS[String(r.status)] || 'bg-muted'}>{String(r.status).replace('_', ' ')}</Badge></TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
export default GrievancePage;
