import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { Plus, RefreshCw, UserCheck, ShieldBan, ArrowRightLeft, CheckCircle, XCircle } from 'lucide-react';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = _sb as any;

/* ────────────────────────────────────────────────────────────────────────────
   GetPassTab  (FR-LEAVE-020 / FR-LEAVE-021)
   Employee exit-pass during working hours with manager approval
──────────────────────────────────────────────────────────────────────────── */
type GetPass = {
  id: string;
  employee_id: string;
  employee_name: string;
  exit_time: string;
  return_time: string;
  purpose: string;
  status: string;
  approved_by: string | null;
  approved_at: string | null;
  created_at: string;
};

const GP_STATUS_BADGE: Record<string, string> = {
  PENDING:  'bg-yellow-100 text-yellow-800',
  APPROVED: 'bg-green-100 text-green-800',
  REJECTED: 'bg-red-100 text-red-800',
};

export function GetPassTab() {
  const [rows, setRows]     = useState<GetPass[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]     = useState(false);
  const [form, setForm]     = useState({ employee_name: '', exit_time: '', return_time: '', purpose: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('leave_get_pass').select('*').order('created_at', { ascending: false }).limit(100);
    setRows(data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.employee_name || !form.exit_time || !form.return_time || !form.purpose) {
      toast.error('All fields are required'); return;
    }
    const { error } = await sb.from('leave_get_pass').insert({
      employee_name: form.employee_name,
      exit_time: form.exit_time,
      return_time: form.return_time,
      purpose: form.purpose,
      status: 'PENDING',
    });
    if (error) { toast.error('Failed to save'); return; }
    toast.success('Get pass request submitted');
    setOpen(false);
    setForm({ employee_name: '', exit_time: '', return_time: '', purpose: '' });
    load();
  };

  const updateStatus = async (id: string, status: string) => {
    const { error } = await sb.from('leave_get_pass').update({ status, approved_by: 'HR Manager', approved_at: new Date().toISOString() }).eq('id', id);
    if (error) { toast.error('Update failed'); return; }
    toast.success(`Pass ${status.toLowerCase()}`);
    load();
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><UserCheck className="h-4 w-4" />Get Pass Requests</CardTitle>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm"><Plus className="h-3.5 w-3.5 mr-1.5" />New Get Pass</Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>Request Exit Pass</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Employee Name</Label><Input value={form.employee_name} onChange={e => setForm(p => ({ ...p, employee_name: e.target.value }))} placeholder="Full name" /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Exit Time</Label><Input type="datetime-local" value={form.exit_time} onChange={e => setForm(p => ({ ...p, exit_time: e.target.value }))} /></div>
                  <div><Label>Expected Return</Label><Input type="datetime-local" value={form.return_time} onChange={e => setForm(p => ({ ...p, return_time: e.target.value }))} /></div>
                </div>
                <div><Label>Purpose</Label><Textarea value={form.purpose} onChange={e => setForm(p => ({ ...p, purpose: e.target.value }))} rows={3} placeholder="Reason for exit…" /></div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button onClick={save}>Submit Request</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
        ) : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">No get pass requests found.</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Exit Time</TableHead>
                  <TableHead className="whitespace-nowrap">Return Time</TableHead>
                  <TableHead className="whitespace-nowrap">Purpose</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map(r => (
                  <TableRow key={r.id}>
                    <TableCell className="whitespace-nowrap font-medium">{r.employee_name}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.exit_time ? new Date(r.exit_time).toLocaleString() : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.return_time ? new Date(r.return_time).toLocaleString() : '—'}</TableCell>
                    <TableCell className="max-w-[200px] truncate">{r.purpose}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${GP_STATUS_BADGE[r.status] ?? 'bg-muted text-muted-foreground'}`}>{r.status}</span>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {r.status === 'PENDING' && (
                        <div className="flex gap-1">
                          <Button size="sm" variant="outline" className="h-7 px-2 text-green-700 border-green-300" onClick={() => updateStatus(r.id, 'APPROVED')}><CheckCircle className="h-3 w-3 mr-1" />Approve</Button>
                          <Button size="sm" variant="outline" className="h-7 px-2 text-red-700 border-red-300" onClick={() => updateStatus(r.id, 'REJECTED')}><XCircle className="h-3 w-3 mr-1" />Reject</Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ────────────────────────────────────────────────────────────────────────────
   BlackoutPeriodsTab  (FR-LEAVE-022)
   Define periods during which leave requests are blocked
──────────────────────────────────────────────────────────────────────────── */
type BlackoutPeriod = {
  id: string;
  name: string;
  start_date: string;
  end_date: string;
  leave_types: string | null;
  applies_to: string;
  reason: string | null;
  active: boolean;
  created_at: string;
};

export function BlackoutPeriodsTab() {
  const [rows, setRows]     = useState<BlackoutPeriod[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]     = useState(false);
  const [form, setForm]     = useState({ name: '', start_date: '', end_date: '', leave_types: '', applies_to: 'ALL', reason: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('leave_blackout_periods').select('*').order('start_date', { ascending: false }).limit(100);
    setRows(data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.name || !form.start_date || !form.end_date) { toast.error('Name and dates are required'); return; }
    const { error } = await sb.from('leave_blackout_periods').insert({
      name: form.name, start_date: form.start_date, end_date: form.end_date,
      leave_types: form.leave_types || null, applies_to: form.applies_to,
      reason: form.reason || null, active: true,
    });
    if (error) { toast.error('Failed to save blackout period'); return; }
    toast.success('Blackout period created');
    setOpen(false);
    setForm({ name: '', start_date: '', end_date: '', leave_types: '', applies_to: 'ALL', reason: '' });
    load();
  };

  const toggleActive = async (id: string, active: boolean) => {
    await sb.from('leave_blackout_periods').update({ active: !active }).eq('id', id);
    load();
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><ShieldBan className="h-4 w-4" />Blackout Periods</CardTitle>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm"><Plus className="h-3.5 w-3.5 mr-1.5" />Add Blackout Period</Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>New Blackout Period</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Period Name</Label><Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="e.g. Year-End Freeze" /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Start Date</Label><Input type="date" value={form.start_date} onChange={e => setForm(p => ({ ...p, start_date: e.target.value }))} /></div>
                  <div><Label>End Date</Label><Input type="date" value={form.end_date} onChange={e => setForm(p => ({ ...p, end_date: e.target.value }))} /></div>
                </div>
                <div>
                  <Label>Applies To</Label>
                  <Select value={form.applies_to} onValueChange={v => setForm(p => ({ ...p, applies_to: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ALL">All Employees</SelectItem>
                      <SelectItem value="DEPT">Specific Department</SelectItem>
                      <SelectItem value="GRADE">Specific Grade</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label>Blocked Leave Types (comma-separated, blank = all)</Label><Input value={form.leave_types} onChange={e => setForm(p => ({ ...p, leave_types: e.target.value }))} placeholder="Annual Leave, Sick Leave" /></div>
                <div><Label>Reason / Notes</Label><Textarea value={form.reason} onChange={e => setForm(p => ({ ...p, reason: e.target.value }))} rows={2} placeholder="Business justification…" /></div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button onClick={save}>Save Period</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
        ) : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">No blackout periods configured.</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Period Name</TableHead>
                  <TableHead className="whitespace-nowrap">Start Date</TableHead>
                  <TableHead className="whitespace-nowrap">End Date</TableHead>
                  <TableHead className="whitespace-nowrap">Applies To</TableHead>
                  <TableHead className="whitespace-nowrap">Blocked Types</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map(r => (
                  <TableRow key={r.id}>
                    <TableCell className="whitespace-nowrap font-medium">{r.name}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.start_date}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.end_date}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.applies_to}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.leave_types ?? 'All'}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge variant={r.active ? 'default' : 'secondary'}>{r.active ? 'Active' : 'Inactive'}</Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Button size="sm" variant="outline" className="h-7" onClick={() => toggleActive(r.id, r.active)}>
                        {r.active ? 'Deactivate' : 'Activate'}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ────────────────────────────────────────────────────────────────────────────
   SubstitutionTab  (FR-LEAVE-023)
   Assign a substitute employee while another is on leave
──────────────────────────────────────────────────────────────────────────── */
type Substitution = {
  id: string;
  requester_name: string;
  substitute_name: string;
  leave_start: string;
  leave_end: string;
  substitute_role: string | null;
  status: string;
  notes: string | null;
  created_at: string;
};

const SUB_STATUS: Record<string, string> = {
  PENDING:  'bg-yellow-100 text-yellow-800',
  ACCEPTED: 'bg-green-100 text-green-800',
  DECLINED: 'bg-red-100 text-red-800',
};

export function SubstitutionTab() {
  const [rows, setRows]     = useState<Substitution[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]     = useState(false);
  const [form, setForm]     = useState({ requester_name: '', substitute_name: '', leave_start: '', leave_end: '', substitute_role: '', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('leave_substitutions').select('*').order('created_at', { ascending: false }).limit(100);
    setRows(data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.requester_name || !form.substitute_name || !form.leave_start || !form.leave_end) {
      toast.error('Names and dates are required'); return;
    }
    const { error } = await sb.from('leave_substitutions').insert({
      requester_name: form.requester_name, substitute_name: form.substitute_name,
      leave_start: form.leave_start, leave_end: form.leave_end,
      substitute_role: form.substitute_role || null,
      notes: form.notes || null, status: 'PENDING',
    });
    if (error) { toast.error('Failed to save substitution'); return; }
    toast.success('Substitution request created');
    setOpen(false);
    setForm({ requester_name: '', substitute_name: '', leave_start: '', leave_end: '', substitute_role: '', notes: '' });
    load();
  };

  const updateStatus = async (id: string, status: string) => {
    await sb.from('leave_substitutions').update({ status }).eq('id', id);
    toast.success(`Substitution ${status.toLowerCase()}`);
    load();
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><ArrowRightLeft className="h-4 w-4" />Leave Substitutions</CardTitle>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm"><Plus className="h-3.5 w-3.5 mr-1.5" />Assign Substitute</Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>New Substitution Assignment</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Requester (On Leave)</Label><Input value={form.requester_name} onChange={e => setForm(p => ({ ...p, requester_name: e.target.value }))} placeholder="Employee name" /></div>
                  <div><Label>Substitute Employee</Label><Input value={form.substitute_name} onChange={e => setForm(p => ({ ...p, substitute_name: e.target.value }))} placeholder="Substitute name" /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Leave Start</Label><Input type="date" value={form.leave_start} onChange={e => setForm(p => ({ ...p, leave_start: e.target.value }))} /></div>
                  <div><Label>Leave End</Label><Input type="date" value={form.leave_end} onChange={e => setForm(p => ({ ...p, leave_end: e.target.value }))} /></div>
                </div>
                <div><Label>Substitute Role / Duties</Label><Input value={form.substitute_role} onChange={e => setForm(p => ({ ...p, substitute_role: e.target.value }))} placeholder="e.g. Handle approvals, cover counter" /></div>
                <div><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} rows={2} placeholder="Additional notes…" /></div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button onClick={save}>Create Assignment</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
        ) : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">No substitution assignments found.</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">On Leave</TableHead>
                  <TableHead className="whitespace-nowrap">Substitute</TableHead>
                  <TableHead className="whitespace-nowrap">Period</TableHead>
                  <TableHead className="whitespace-nowrap">Role / Duties</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map(r => (
                  <TableRow key={r.id}>
                    <TableCell className="whitespace-nowrap font-medium">{r.requester_name}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.substitute_name}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.leave_start} – {r.leave_end}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.substitute_role ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${SUB_STATUS[r.status] ?? 'bg-muted text-muted-foreground'}`}>{r.status}</span>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {r.status === 'PENDING' && (
                        <div className="flex gap-1">
                          <Button size="sm" variant="outline" className="h-7 px-2 text-green-700 border-green-300" onClick={() => updateStatus(r.id, 'ACCEPTED')}><CheckCircle className="h-3 w-3 mr-1" />Accept</Button>
                          <Button size="sm" variant="outline" className="h-7 px-2 text-red-700 border-red-300" onClick={() => updateStatus(r.id, 'DECLINED')}><XCircle className="h-3 w-3 mr-1" />Decline</Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
