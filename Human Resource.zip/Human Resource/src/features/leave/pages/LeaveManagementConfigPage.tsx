import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import type { LeaveType, LeavePolicy } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { Plus, RefreshCw, Pencil, Trash2, Tag, FileText, CreditCard, Calendar, ToggleLeft } from 'lucide-react';

// ── Constants ──────────────────────────────────────────────────
const LEAVE_CATEGORIES = ['ANNUAL','SICK','MATERNITY','PATERNITY','UNPAID','SPECIAL','COMPASSIONATE'] as const;
const ACCRUAL_FREQUENCIES = ['MONTHLY','QUARTERLY','YEARLY','UPFRONT'] as const;
const CATEGORY_COLORS: Record<string, string> = {
  ANNUAL:        'bg-blue-100 text-blue-800',
  SICK:          'bg-red-100 text-red-800',
  MATERNITY:     'bg-pink-100 text-pink-800',
  PATERNITY:     'bg-purple-100 text-purple-800',
  UNPAID:        'bg-muted text-muted-foreground',
  SPECIAL:       'bg-teal-100 text-teal-800',
  COMPASSIONATE: 'bg-orange-100 text-orange-800',
};

// ── Schemas ────────────────────────────────────────────────────
const leaveTypeSchema = z.object({
  name:                     z.string().min(1, 'Required'),
  leave_category:           z.enum(LEAVE_CATEGORIES),
  is_paid:                  z.boolean(),
  is_attachment_required:   z.boolean(),
  allowed_attachment_types: z.string().optional(),
  max_days_per_year:        z.coerce.number().min(0).optional(),
  gender_restriction:       z.enum(['NONE', 'MALE', 'FEMALE']),
  min_service_months:       z.coerce.number().min(0).optional(),
  description:              z.string().optional(),
});
type LeaveTypeForm = z.infer<typeof leaveTypeSchema>;

const leavePolicySchema = z.object({
  leave_type_id:              z.string().min(1, 'Required'),
  policy_name:                z.string().min(1, 'Required'),
  entitlement_days:           z.coerce.number().min(0),
  accrual_frequency:          z.enum(['NONE', ...ACCRUAL_FREQUENCIES]),
  accrual_rate:               z.coerce.number().min(0).optional(),
  is_pro_rata:                z.boolean(),
  is_auto_credit:             z.boolean(),
  carry_forward_limit_days:   z.coerce.number().min(0),
  carry_forward_expiry_months:z.coerce.number().min(0).optional(),
  is_carry_forward_auto:      z.boolean(),
  is_encashment_allowed:      z.boolean(),
  is_negative_balance_allowed:z.boolean(),
  max_backdated_days:         z.coerce.number().min(0),
});
type LeavePolicyForm = z.infer<typeof leavePolicySchema>;

export function LeaveManagementConfigPage() {
  const [tab, setTab] = useState<'types' | 'policies'>('types');

  // Leave Types
  const [leaveTypes,    setLeaveTypes]    = useState<LeaveType[]>([]);
  const [typesLoading,  setTypesLoading]  = useState(true);
  const [typeDialog,    setTypeDialog]    = useState(false);
  const [editType,      setEditType]      = useState<LeaveType | null>(null);
  const [typeSaving,    setTypeSaving]    = useState(false);

  // Leave Policies
  const [policies,      setPolicies]      = useState<LeavePolicy[]>([]);
  const [polLoading,    setPolLoading]    = useState(true);
  const [polDialog,     setPolDialog]     = useState(false);
  const [editPol,       setEditPol]       = useState<LeavePolicy | null>(null);
  const [polSaving,     setPolSaving]     = useState(false);

  const typeForm = useForm<LeaveTypeForm>({
    resolver: zodResolver(leaveTypeSchema),
    defaultValues: { name: '', leave_category: 'ANNUAL', is_paid: true, is_attachment_required: false, gender_restriction: 'NONE' },
  });
  const polForm = useForm<LeavePolicyForm>({
    resolver: zodResolver(leavePolicySchema),
    defaultValues: {
      leave_type_id: '', policy_name: '', entitlement_days: 0, accrual_frequency: 'NONE',
      is_pro_rata: false, is_auto_credit: false, carry_forward_limit_days: 0,
      is_carry_forward_auto: false, is_encashment_allowed: false, is_negative_balance_allowed: false, max_backdated_days: 0,
    },
  });

  // Load
  const loadTypes = useCallback(async () => {
    setTypesLoading(true);
    const { data, error } = await supabase.from('leave_types').select('*').eq('is_active', true).order('name');
    if (error) toast.error('Failed to load leave types');
    else setLeaveTypes((data ?? []) as LeaveType[]);
    setTypesLoading(false);
  }, []);

  const loadPolicies = useCallback(async () => {
    setPolLoading(true);
    const { data, error } = await supabase
      .from('leave_policies')
      .select('*, leave_type:leave_types(id,name,leave_category)')
      .eq('is_deleted', 0)
      .order('policy_name');
    if (error) toast.error('Failed to load policies');
    else setPolicies((data ?? []) as LeavePolicy[]);
    setPolLoading(false);
  }, []);

  useEffect(() => { loadTypes(); }, [loadTypes]);
  useEffect(() => { loadPolicies(); }, [loadPolicies]);

  // ── Leave Type CRUD ──────────────────────────────────────────
  const openCreateType = () => {
    setEditType(null);
    typeForm.reset({ name: '', leave_category: 'ANNUAL', is_paid: true, is_attachment_required: false, gender_restriction: 'NONE' });
    setTypeDialog(true);
  };
  const openEditType = (t: LeaveType) => {
    setEditType(t);
    typeForm.reset({
      name:                     t.name,
      leave_category:           (t.leave_category ?? 'ANNUAL') as typeof LEAVE_CATEGORIES[number],
      is_paid:                  Boolean(t.is_paid),
      is_attachment_required:   (t.is_attachment_required ?? 0) === 1,
      allowed_attachment_types: t.allowed_attachment_types ?? '',
      max_days_per_year:        t.max_days_per_year ?? t.days_per_year ?? 0,
      gender_restriction:       (t.gender_restriction ?? 'NONE') as 'NONE' | 'MALE' | 'FEMALE',
      min_service_months:       t.min_service_months ?? 0,
      description:              t.description ?? '',
    });
    setTypeDialog(true);
  };
  const submitType = typeForm.handleSubmit(async (vals) => {
    setTypeSaving(true);
    const payload = {
      name:                     vals.name,
      leave_name:               vals.name,
      leave_category:           vals.leave_category,
      is_paid:                  vals.is_paid,
      is_attachment_required:   vals.is_attachment_required ? 1 : 0,
      allowed_attachment_types: vals.allowed_attachment_types || null,
      max_days_per_year:        vals.max_days_per_year ?? null,
      days_per_year:            vals.max_days_per_year ?? 0,
      gender_restriction:       vals.gender_restriction === 'NONE' ? null : vals.gender_restriction,
      min_service_months:       vals.min_service_months ?? null,
      description:              vals.description || null,
      is_active:                true,
      updated_at:               new Date().toISOString(),
    };
    const { error } = editType
      ? await supabase.from('leave_types').update(payload).eq('id', editType.id)
      : await supabase.from('leave_types').insert({ ...payload, effective_from: new Date().toISOString(), effective_to: '9999-12-31T23:59:59Z', requires_approval: true, can_carry_forward: false });
    if (error) toast.error(error.message);
    else { toast.success(editType ? 'Leave type updated' : 'Leave type created'); setTypeDialog(false); loadTypes(); }
    setTypeSaving(false);
  });
  const deleteType = async (id: string) => {
    if (!confirm('Deactivate this leave type?')) return;
    const { error } = await supabase.from('leave_types').update({ is_active: false, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Leave type deactivated'); loadTypes(); }
  };

  // ── Leave Policy CRUD ────────────────────────────────────────
  const openCreatePol = () => {
    setEditPol(null);
    polForm.reset({ leave_type_id: '', policy_name: '', entitlement_days: 0, accrual_frequency: 'NONE', is_pro_rata: false, is_auto_credit: false, carry_forward_limit_days: 0, is_carry_forward_auto: false, is_encashment_allowed: false, is_negative_balance_allowed: false, max_backdated_days: 0 });
    setPolDialog(true);
  };
  const openEditPol = (p: LeavePolicy) => {
    setEditPol(p);
    polForm.reset({
      leave_type_id:               p.leave_type_id,
      policy_name:                 p.policy_name,
      entitlement_days:            p.entitlement_days,
      accrual_frequency:           (p.accrual_frequency ?? 'NONE') as 'NONE' | 'MONTHLY' | 'QUARTERLY' | 'YEARLY' | 'UPFRONT',
      accrual_rate:                p.accrual_rate ?? 0,
      is_pro_rata:                 p.is_pro_rata === 1,
      is_auto_credit:              p.is_auto_credit === 1,
      carry_forward_limit_days:    p.carry_forward_limit_days ?? 0,
      carry_forward_expiry_months: p.carry_forward_expiry_months ?? 0,
      is_carry_forward_auto:       p.is_carry_forward_auto === 1,
      is_encashment_allowed:       p.is_encashment_allowed === 1,
      is_negative_balance_allowed: p.is_negative_balance_allowed === 1,
      max_backdated_days:          p.max_backdated_days ?? 0,
    });
    setPolDialog(true);
  };
  const submitPol = polForm.handleSubmit(async (vals) => {
    setPolSaving(true);
    const payload = {
      leave_type_id:               vals.leave_type_id,
      policy_name:                 vals.policy_name,
      entitlement_days:            vals.entitlement_days,
      accrual_frequency:           vals.accrual_frequency === 'NONE' ? null : vals.accrual_frequency,
      accrual_rate:                vals.accrual_rate ?? null,
      is_pro_rata:                 vals.is_pro_rata ? 1 : 0,
      is_auto_credit:              vals.is_auto_credit ? 1 : 0,
      carry_forward_limit_days:    vals.carry_forward_limit_days,
      carry_forward_expiry_months: vals.carry_forward_expiry_months ?? null,
      is_carry_forward_auto:       vals.is_carry_forward_auto ? 1 : 0,
      is_encashment_allowed:       vals.is_encashment_allowed ? 1 : 0,
      is_negative_balance_allowed: vals.is_negative_balance_allowed ? 1 : 0,
      max_backdated_days:          vals.max_backdated_days,
      is_active:                   1,
      updated_at:                  new Date().toISOString(),
    };
    const { error } = editPol
      ? await supabase.from('leave_policies').update(payload).eq('id', editPol.id)
      : await supabase.from('leave_policies').insert({ ...payload, effective_from: new Date().toISOString(), effective_to: '9999-12-31T23:59:59Z' });
    if (error) toast.error(error.message);
    else { toast.success(editPol ? 'Policy updated' : 'Policy created'); setPolDialog(false); loadPolicies(); }
    setPolSaving(false);
  });
  const deletePol = async (id: string) => {
    if (!confirm('Delete this leave policy?')) return;
    const { error } = await supabase.from('leave_policies').update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Policy deleted'); loadPolicies(); }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Leave Types & Policies</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Configure available leave categories and their entitlement policies</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => { loadTypes(); loadPolicies(); }}>
            <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
          </Button>
          {tab === 'types'
            ? <Button size="sm" onClick={openCreateType}><Plus className="h-4 w-4 mr-1.5" />New Leave Type</Button>
            : <Button size="sm" onClick={openCreatePol}><Plus className="h-4 w-4 mr-1.5" />New Policy</Button>}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Leave Types', value: leaveTypes.length, icon: Tag, color: 'text-primary' },
          { label: 'Paid Types', value: leaveTypes.filter(t=>Boolean(t.is_paid)).length, icon: CreditCard, color: 'text-green-600' },
          { label: 'Policies', value: policies.length, icon: FileText, color: 'text-blue-600' },
          { label: 'Max Entitlement', value: `${Math.max(0, ...leaveTypes.map(t=>t.max_days_per_year??t.days_per_year??0))} d`, icon: Calendar, color: 'text-orange-500' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <s.icon className={`h-4 w-4 ${s.color} shrink-0`} />
            <div><p className="text-xs text-muted-foreground">{s.label}</p><p className="text-xl font-bold">{s.value}</p></div>
          </div>
        ))}
      </div>

      <Tabs value={tab} onValueChange={v => setTab(v as typeof tab)}>
        <TabsList>
          <TabsTrigger value="types"><Tag className="h-4 w-4 mr-1.5" />Leave Types ({leaveTypes.length})</TabsTrigger>
          <TabsTrigger value="policies"><FileText className="h-4 w-4 mr-1.5" />Policies ({policies.length})</TabsTrigger>
        </TabsList>

        {/* ── LEAVE TYPES ── */}
        <TabsContent value="types" className="mt-4">
          {typesLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-36 bg-muted rounded-lg" />)}
            </div>
          ) : leaveTypes.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <Tag className="h-10 w-10 mx-auto mb-3 opacity-40" />
              <p className="font-medium">No leave types configured</p>
              <Button className="mt-4" onClick={openCreateType}><Plus className="h-4 w-4 mr-1.5" />Create First Type</Button>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {leaveTypes.map(t => (
                <div key={t.id} className="bg-card border border-border rounded-lg p-4 flex flex-col h-full">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="min-w-0">
                      <p className="font-semibold text-sm text-balance">{t.name}</p>
                      {t.description && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2 text-pretty">{t.description}</p>}
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium whitespace-nowrap shrink-0 ${CATEGORY_COLORS[t.leave_category ?? 'ANNUAL'] ?? 'bg-muted text-muted-foreground'}`}>
                      {(t.leave_category ?? 'ANNUAL').replace(/_/g,' ')}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {Boolean(t.is_paid) && <Badge variant="outline" className="text-xs text-green-700 border-green-300">Paid</Badge>}
                    {!Boolean(t.is_paid) && <Badge variant="outline" className="text-xs text-muted-foreground">Unpaid</Badge>}
                    {(t.is_attachment_required ?? 0) === 1 && <Badge variant="outline" className="text-xs">Attachment Req.</Badge>}
                    {t.gender_restriction && <Badge variant="outline" className="text-xs">{t.gender_restriction} only</Badge>}
                    {(t.max_days_per_year ?? t.days_per_year) && (
                      <Badge variant="secondary" className="text-xs">{t.max_days_per_year ?? t.days_per_year} d/yr</Badge>
                    )}
                  </div>
                  <div className="flex gap-2 mt-auto">
                    <Button size="sm" variant="outline" className="flex-1 h-8" onClick={() => openEditType(t)}>
                      <Pencil className="h-3.5 w-3.5 mr-1" />Edit
                    </Button>
                    <Button size="sm" variant="outline" className="h-8 px-2 text-destructive hover:bg-destructive/10" onClick={() => deleteType(t.id)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ── POLICIES ── */}
        <TabsContent value="policies" className="mt-4">
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Policy Name</TableHead>
                    <TableHead className="whitespace-nowrap">Leave Type</TableHead>
                    <TableHead className="whitespace-nowrap">Entitlement (d)</TableHead>
                    <TableHead className="whitespace-nowrap">Accrual</TableHead>
                    <TableHead className="whitespace-nowrap">Carry Fwd (d)</TableHead>
                    <TableHead className="whitespace-nowrap">Features</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {polLoading ? Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 7 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-16 bg-muted" /></TableCell>)}</TableRow>
                  )) : policies.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">
                      <FileText className="h-8 w-8 mx-auto mb-2 opacity-40" />No leave policies configured yet
                    </TableCell></TableRow>
                  ) : policies.map(p => {
                    const lt = p.leave_type as { name: string; leave_category: string } | undefined;
                    return (
                      <TableRow key={p.id}>
                        <TableCell className="whitespace-nowrap font-medium text-sm">{p.policy_name}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          {lt ? (
                            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${CATEGORY_COLORS[lt.leave_category] ?? 'bg-muted text-muted-foreground'}`}>
                              {lt.name}
                            </span>
                          ) : '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm font-semibold">{p.entitlement_days}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{p.accrual_frequency ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{p.carry_forward_limit_days ?? 0}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex flex-wrap gap-1">
                            {p.is_pro_rata === 1 && <Badge variant="secondary" className="text-xs">Pro-rata</Badge>}
                            {p.is_carry_forward_auto === 1 && <Badge variant="secondary" className="text-xs">Auto CF</Badge>}
                            {p.is_encashment_allowed === 1 && <Badge variant="secondary" className="text-xs">Encashable</Badge>}
                            {p.is_negative_balance_allowed === 1 && <Badge variant="outline" className="text-xs text-orange-600">Overdraft</Badge>}
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex gap-1.5">
                            <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openEditPol(p)}><Pencil className="h-3.5 w-3.5" /></Button>
                            <Button size="sm" variant="outline" className="h-7 px-2 text-destructive hover:bg-destructive/10" onClick={() => deletePol(p.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* ── Leave Type Dialog ── */}
      <Dialog open={typeDialog} onOpenChange={o => { if (!o) setTypeDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editType ? 'Edit' : 'New'} Leave Type</DialogTitle></DialogHeader>
          <Form {...typeForm}>
            <form onSubmit={submitType} className="space-y-4 mt-1">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <FormField control={typeForm.control} name="name" render={({ field }) => (
                    <FormItem><FormLabel>Leave Type Name *</FormLabel><FormControl><Input {...field} placeholder="Annual Leave" /></FormControl><FormMessage /></FormItem>
                  )} />
                </div>
                <FormField control={typeForm.control} name="leave_category" render={({ field }) => (
                  <FormItem><FormLabel>Category *</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>{LEAVE_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
                <FormField control={typeForm.control} name="max_days_per_year" render={({ field }) => (
                  <FormItem><FormLabel>Max Days / Year</FormLabel><FormControl><Input type="number" min={0} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={typeForm.control} name="gender_restriction" render={({ field }) => (
                  <FormItem><FormLabel>Gender Restriction</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="NONE">None</SelectItem>
                        <SelectItem value="MALE">Male Only</SelectItem>
                        <SelectItem value="FEMALE">Female Only</SelectItem>
                      </SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
                <FormField control={typeForm.control} name="min_service_months" render={({ field }) => (
                  <FormItem><FormLabel>Min Service (months)</FormLabel><FormControl><Input type="number" min={0} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={typeForm.control} name="allowed_attachment_types" render={({ field }) => (
                <FormItem><FormLabel>Allowed Attachment Types</FormLabel><FormControl><Input {...field} placeholder="pdf,jpg,png" /></FormControl><FormMessage /></FormItem>
              )} />
              <div className="flex gap-6">
                <FormField control={typeForm.control} name="is_paid" render={({ field }) => (
                  <FormItem className="flex items-center gap-2"><FormControl><Checkbox checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                    <FormLabel className="!mt-0">Paid Leave</FormLabel></FormItem>
                )} />
                <FormField control={typeForm.control} name="is_attachment_required" render={({ field }) => (
                  <FormItem className="flex items-center gap-2"><FormControl><Checkbox checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                    <FormLabel className="!mt-0">Attachment Required</FormLabel></FormItem>
                )} />
              </div>
              <Separator />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setTypeDialog(false)}>Cancel</Button>
                <Button type="submit" disabled={typeSaving}>{typeSaving ? 'Saving…' : (editType ? 'Update' : 'Create')}</Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* ── Leave Policy Dialog ── */}
      <Dialog open={polDialog} onOpenChange={o => { if (!o) setPolDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>{editPol ? 'Edit' : 'New'} Leave Policy</DialogTitle></DialogHeader>
          <Form {...polForm}>
            <form onSubmit={submitPol} className="space-y-4 mt-1">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <FormField control={polForm.control} name="policy_name" render={({ field }) => (
                    <FormItem><FormLabel>Policy Name *</FormLabel><FormControl><Input {...field} placeholder="Standard Annual Leave Policy" /></FormControl><FormMessage /></FormItem>
                  )} />
                </div>
                <FormField control={polForm.control} name="leave_type_id" render={({ field }) => (
                  <FormItem><FormLabel>Leave Type *</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select leave type" /></SelectTrigger></FormControl>
                      <SelectContent>
                        {leaveTypes.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
                <FormField control={polForm.control} name="entitlement_days" render={({ field }) => (
                  <FormItem><FormLabel>Entitlement Days *</FormLabel><FormControl><Input type="number" min={0} step={0.5} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={polForm.control} name="accrual_frequency" render={({ field }) => (
                  <FormItem><FormLabel>Accrual Frequency</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="NONE">No Accrual (Upfront)</SelectItem>
                        {ACCRUAL_FREQUENCIES.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
                <FormField control={polForm.control} name="accrual_rate" render={({ field }) => (
                  <FormItem><FormLabel>Accrual Rate (days/period)</FormLabel><FormControl><Input type="number" min={0} step={0.5} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={polForm.control} name="carry_forward_limit_days" render={({ field }) => (
                  <FormItem><FormLabel>Carry Forward Limit (days)</FormLabel><FormControl><Input type="number" min={0} step={0.5} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={polForm.control} name="carry_forward_expiry_months" render={({ field }) => (
                  <FormItem><FormLabel>Carry Fwd Expiry (months)</FormLabel><FormControl><Input type="number" min={0} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={polForm.control} name="max_backdated_days" render={({ field }) => (
                  <FormItem><FormLabel>Max Backdated Days</FormLabel><FormControl><Input type="number" min={0} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              {/* Boolean flags */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {[
                  { name: 'is_pro_rata' as const,                label: 'Pro-rata' },
                  { name: 'is_auto_credit' as const,             label: 'Auto Credit' },
                  { name: 'is_carry_forward_auto' as const,      label: 'Auto Carry Fwd' },
                  { name: 'is_encashment_allowed' as const,      label: 'Encashment Allowed' },
                  { name: 'is_negative_balance_allowed' as const, label: 'Allow Overdraft' },
                ].map(f => (
                  <FormField key={f.name} control={polForm.control} name={f.name} render={({ field }) => (
                    <FormItem className="flex items-center gap-2">
                      <FormControl><Checkbox checked={Boolean(field.value)} onCheckedChange={field.onChange} /></FormControl>
                      <FormLabel className="!mt-0 font-normal">{f.label}</FormLabel>
                    </FormItem>
                  )} />
                ))}
              </div>
              <Separator />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setPolDialog(false)}>Cancel</Button>
                <Button type="submit" disabled={polSaving}>{polSaving ? 'Saving…' : (editPol ? 'Update' : 'Create Policy')}</Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Empty state hint */}
      {leaveTypes.length > 0 && policies.length === 0 && tab === 'policies' && (
        <p className="text-xs text-muted-foreground flex items-center gap-1.5">
          <ToggleLeft className="h-3.5 w-3.5 shrink-0" />
          Create policies to define entitlement rules for each leave type.
        </p>
      )}
    </div>
  );
}
