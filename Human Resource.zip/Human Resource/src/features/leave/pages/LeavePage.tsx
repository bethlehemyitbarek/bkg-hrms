import { useState, useEffect, useCallback, useMemo } from 'react';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { leaveService } from '@/services/attendance.service';
import type { LeaveRequest, LeaveType, LeaveBalance } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { Plus, RefreshCw, CalendarDays, Check, X, ChevronLeft, ChevronRight, List, BarChart2, Eye, Paperclip, Download, ClipboardCheck, ShieldBan, ArrowRightLeft, Loader2 } from 'lucide-react';
import { GetPassTab, BlackoutPeriodsTab, SubstitutionTab } from '@/features/leave/components/LeaveAdvancedTabs';

const STATUS_COLORS: Record<string, string> = {
  pending:   'bg-yellow-100 text-yellow-800',
  approved:  'bg-green-100 text-green-800',
  rejected:  'bg-red-100 text-red-800',
  cancelled: 'bg-muted text-muted-foreground',
  withdrawn: 'bg-muted text-muted-foreground',
};

const LEAVE_PALETTE = ['bg-blue-400','bg-emerald-400','bg-violet-400','bg-orange-400','bg-pink-400','bg-teal-400','bg-amber-400','bg-rose-400'];
const WEEKDAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const MONTHS   = ['January','February','March','April','May','June','July','August','September','October','November','December'];

function daysInMonth(y: number, m: number) { return new Date(y, m + 1, 0).getDate(); }
function firstDayOfMonth(y: number, m: number) { return new Date(y, m, 1).getDay(); }

type CalLeave = { id: string; employee_name: string; start_date: string; end_date: string; leave_type_name: string; colorClass: string; };

function LeaveCalendar({ approvedLeaves, onExportCsv }: { approvedLeaves: LeaveRequest[]; onExportCsv: (year: number, month: number) => void }) {
  const today = new Date();
  const [year,  setYear]  = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());
  const [search, setSearch] = useState('');
  const [selectedDay, setSelectedDay] = useState<{ day: number; leaves: CalLeave[] } | null>(null);

  const prev = () => month === 0  ? (setYear(y => y - 1), setMonth(11)) : setMonth(m => m - 1);
  const next = () => month === 11 ? (setYear(y => y + 1), setMonth(0))  : setMonth(m => m + 1);
  const goToday = () => { setYear(today.getFullYear()); setMonth(today.getMonth()); };

  const employeeColors = useMemo(() => {
    const map = new Map<string, string>();
    approvedLeaves.forEach(l => {
      if (!map.has(l.employee_id)) map.set(l.employee_id, LEAVE_PALETTE[map.size % LEAVE_PALETTE.length]);
    });
    return map;
  }, [approvedLeaves]);

  const calLeaves: CalLeave[] = useMemo(() => {
    return approvedLeaves
      .map(l => {
        const emp = l.employee as { first_name: string; last_name: string } | undefined;
        const name = emp ? `${emp.first_name} ${emp.last_name}` : l.employee_id.slice(0, 8);
        return {
          id:               l.id,
          employee_name:    name,
          start_date:       l.start_date,
          end_date:         l.end_date,
          leave_type_name:  (l.leave_type as { name: string } | undefined)?.name ?? 'Leave',
          colorClass:       employeeColors.get(l.employee_id) ?? LEAVE_PALETTE[0],
        };
      })
      .filter(l => !search || l.employee_name.toLowerCase().includes(search.toLowerCase()) || l.leave_type_name.toLowerCase().includes(search.toLowerCase()));
  }, [approvedLeaves, employeeColors, search]);

  const totalDays = daysInMonth(year, month);
  const startDay  = firstDayOfMonth(year, month);
  const cells: (number | null)[] = [...Array(startDay).fill(null), ...Array.from({ length: totalDays }, (_, i) => i + 1)];
  while (cells.length % 7 !== 0) cells.push(null);
  const todayStr = today.toISOString().split('T')[0];

  const leavesOnDay = (day: number): CalLeave[] => {
    const ds = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return calLeaves.filter(l => l.start_date <= ds && l.end_date >= ds);
  };

  const monthOnLeave = useMemo(() => {
    const set = new Set<string>();
    calLeaves.forEach(l => {
      const d0 = new Date(Math.max(new Date(l.start_date).getTime(), new Date(year, month, 1).getTime()));
      const d1 = new Date(Math.min(new Date(l.end_date).getTime(),   new Date(year, month + 1, 0).getTime()));
      if (d0 <= d1) set.add(l.employee_name);
    });
    return set.size;
  }, [calLeaves, year, month]);

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1">
          <Button variant="outline" size="sm" onClick={prev} className="h-8 w-8 p-0"><ChevronLeft className="h-4 w-4" /></Button>
          <span className="font-semibold text-base min-w-[140px] text-center">{MONTHS[month]} {year}</span>
          <Button variant="outline" size="sm" onClick={next} className="h-8 w-8 p-0"><ChevronRight className="h-4 w-4" /></Button>
        </div>
        <Button variant="outline" size="sm" className="h-8" onClick={goToday}>Today</Button>
        <Button variant="outline" size="sm" className="h-8 gap-1.5" onClick={() => onExportCsv(year, month)}>
          <Download className="h-3.5 w-3.5" />Export CSV
        </Button>
        <div className="flex-1 min-w-[160px] max-w-xs">
          <Input
            placeholder="Filter by name or leave type…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="h-8 text-xs"
          />
        </div>
        {monthOnLeave > 0 && (
          <span className="text-xs text-muted-foreground ml-auto">{monthOnLeave} employee{monthOnLeave > 1 ? 's' : ''} on leave this month</span>
        )}
      </div>

      {/* Calendar grid */}
      <div className="border border-border rounded-lg overflow-hidden">
        {/* Day headers */}
        <div className="grid grid-cols-7 bg-muted/60 border-b border-border">
          {WEEKDAYS.map(d => (
            <div key={d} className="text-center text-xs font-semibold text-muted-foreground py-2">{d}</div>
          ))}
        </div>
        {/* Cells */}
        <div className="grid grid-cols-7">
          {cells.map((day, idx) => {
            const isToday = day !== null && `${year}-${String(month+1).padStart(2,'0')}-${String(day).padStart(2,'0')}` === todayStr;
            const isWeekend = idx % 7 === 0 || idx % 7 === 6;
            const dayLeaves = day ? leavesOnDay(day) : [];
            const MAX_SHOW = 3;
            return (
              <div
                key={idx}
                onClick={() => day && dayLeaves.length > 0 && setSelectedDay({ day, leaves: dayLeaves })}
                className={[
                  'min-h-[88px] border-b border-r border-border p-1 flex flex-col gap-0.5',
                  day === null ? 'bg-muted/20' : isWeekend ? 'bg-muted/10' : 'bg-card',
                  idx % 7 === 6 ? 'border-r-0' : '',
                  day && dayLeaves.length > 0 ? 'cursor-pointer hover:bg-accent/30 transition-colors' : '',
                ].join(' ')}
              >
                {day !== null && (
                  <>
                    <span className={`text-xs font-medium w-6 h-6 flex items-center justify-center rounded-full self-end ${isToday ? 'bg-primary text-primary-foreground' : isWeekend ? 'text-muted-foreground' : 'text-foreground'}`}>
                      {day}
                    </span>
                    {dayLeaves.slice(0, MAX_SHOW).map(l => (
                      <div
                        key={l.id}
                        title={`${l.employee_name} — ${l.leave_type_name}`}
                        className={`${l.colorClass} text-white text-[10px] leading-tight rounded px-1 py-0.5 truncate`}
                      >
                        {l.employee_name.split(' ')[0]}
                      </div>
                    ))}
                    {dayLeaves.length > MAX_SHOW && (
                      <span className="text-[10px] text-primary font-medium pl-1 cursor-pointer">+{dayLeaves.length - MAX_SHOW} more</span>
                    )}
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Day detail dialog */}
      {selectedDay && (
        <Dialog open onOpenChange={o => { if (!o) setSelectedDay(null); }}>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
            <DialogHeader>
              <DialogTitle>
                {MONTHS[month]} {selectedDay.day}, {year} — {selectedDay.leaves.length} on leave
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-2 mt-2 max-h-72 overflow-y-auto">
              {selectedDay.leaves.map(l => (
                <div key={l.id} className="flex items-center gap-3 p-2.5 border border-border rounded-lg">
                  <span className={`w-3 h-3 rounded-full shrink-0 ${l.colorClass}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{l.employee_name}</p>
                    <p className="text-xs text-muted-foreground">{l.leave_type_name} · {l.start_date} → {l.end_date}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-end pt-2">
              <Button variant="outline" size="sm" onClick={() => setSelectedDay(null)}>Close</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Employee color legend */}
      {employeeColors.size > 0 && (
        <div className="flex flex-wrap gap-x-4 gap-y-2 pt-1">
          {Array.from(employeeColors.entries()).map(([empId, color]) => {
            const name = calLeaves.find(l => approvedLeaves.some(a => a.employee_id === empId && l.id === a.id))?.employee_name ?? empId.slice(0, 8);
            return (
              <div key={empId} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className={`w-3 h-3 rounded-sm shrink-0 ${color}`} />{name}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ── Balance Tab ── */
function BalanceTab() {
  const [employeeId, setEmployeeId] = useState('');
  const [balances,   setBalances]   = useState<LeaveBalance[]>([]);
  const [loading,    setLoading]    = useState(false);
  const year = new Date().getFullYear();

  const load = useCallback(async (eid: string) => {
    if (!eid || eid === 'none') { setBalances([]); return; }
    setLoading(true);
    try { setBalances(await leaveService.getBalances(eid, year)); }
    catch { toast.error('Failed to load balances'); }
    finally { setLoading(false); }
  }, [year]);

  useEffect(() => { if (employeeId) load(employeeId); }, [employeeId, load]);

  return (
    <div className="space-y-4">
      <div className="max-w-xs">
        <EmployeeSelect value={employeeId} onChange={v => { setEmployeeId(v); }} />
      </div>
      {loading ? (
        <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-12 bg-muted" />)}</div>
      ) : balances.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <BarChart2 className="h-10 w-10 mx-auto mb-2 opacity-40" />
          {employeeId ? 'No leave balances for this employee' : 'Select an employee to view balances'}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {balances.map(b => {
            const lt = b.leave_type as { name: string; is_paid?: boolean } | undefined;
            const used = b.used_days + b.pending_days;
            const remaining = Math.max(0, b.entitled_days - used);
            const pct = b.entitled_days > 0 ? Math.min(100, Math.round((used / b.entitled_days) * 100)) : 0;
            return (
              <div key={b.id} className="bg-card border border-border rounded-lg p-4 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-semibold text-sm">{lt?.name ?? 'Leave'}</p>
                    <p className="text-xs text-muted-foreground">{year}</p>
                  </div>
                  {lt?.is_paid != null && (
                    <Badge variant={lt.is_paid ? 'default' : 'secondary'} className="text-xs shrink-0">
                      {lt.is_paid ? 'Paid' : 'Unpaid'}
                    </Badge>
                  )}
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  {[['Entitled', b.entitled_days],['Used', b.used_days],['Pending', b.pending_days]].map(([l, v]) => (
                    <div key={l as string}>
                      <p className="text-lg font-bold">{v}</p>
                      <p className="text-xs text-muted-foreground">{l}</p>
                    </div>
                  ))}
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Used {pct}%</span>
                    <span className="font-medium text-foreground">{remaining} remaining</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5">
                    <div className={`h-1.5 rounded-full ${pct > 90 ? 'bg-red-500' : pct > 70 ? 'bg-orange-400' : 'bg-primary'}`} style={{ width: `${pct}%` }} />
                  </div>
                </div>
                {b.carried_forward > 0 && <p className="text-xs text-muted-foreground">Carried forward: +{b.carried_forward} days</p>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ── Detail Dialog ── */
function LeaveDetailDialog({ request, onClose }: { request: LeaveRequest; onClose: () => void }) {
  const emp = request.employee as { first_name: string; last_name: string; employee_no: string } | undefined;
  const lt  = request.leave_type as { name: string; is_paid?: boolean } | undefined;
  return (
    <Dialog open onOpenChange={o => { if (!o) onClose(); }}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
        <DialogHeader><DialogTitle>Leave Request Details</DialogTitle></DialogHeader>
        <div className="space-y-4 mt-2 text-sm">
          <div className="grid grid-cols-2 gap-3">
            {[
              ['Employee',    emp ? `${emp.first_name} ${emp.last_name} (#${emp.employee_no})` : '—'],
              ['Leave Type',  lt?.name ?? '—'],
              ['Start Date',  request.start_date],
              ['End Date',    request.end_date],
              ['Total Days',  String(request.total_days)],
              ['Half Day',    request.is_half_day ? (request.half_day_period ?? 'Yes') : 'No'],
              ['Status',      request.status],
              ['Approved By', request.approved_by ?? '—'],
              ['Approved At', request.approved_at ? new Date(request.approved_at).toLocaleString() : '—'],
            ].map(([l, v]) => (
              <div key={l} className="bg-muted/40 rounded-lg p-2.5">
                <p className="text-xs text-muted-foreground">{l}</p>
                <p className="font-medium capitalize">{v}</p>
              </div>
            ))}
          </div>
          {request.reason && (
            <div className="space-y-1">
              <p className="text-xs font-medium text-muted-foreground">Reason</p>
              <p className="bg-muted/40 rounded-lg p-2.5">{request.reason}</p>
            </div>
          )}
          {request.rejection_reason && (
            <div className="space-y-1">
              <p className="text-xs font-medium text-red-500">Rejection Reason</p>
              <p className="bg-red-50 text-red-700 rounded-lg p-2.5">{request.rejection_reason}</p>
            </div>
          )}
          {request.document_url && (
            <a href={request.document_url} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 text-primary hover:underline text-sm">
              <Paperclip className="h-4 w-4" />View Attached Document
            </a>
          )}
          <div className="flex justify-end">
            <Button variant="outline" onClick={onClose}>Close</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ── Main Page ── */
export function LeavePage() {
  const [requests,      setRequests]      = useState<LeaveRequest[]>([]);
  const [leaveTypes,    setLeaveTypes]    = useState<LeaveType[]>([]);
  const [loading,       setLoading]       = useState(true);
  const [total,         setTotal]         = useState(0);
  const [page,          setPage]          = useState(1);
  const pageSize = 15;
  const [statusFilter, setStatusFilter]   = useState('all');
  const [createOpen,   setCreateOpen]     = useState(false);
  const [saving,       setSaving]         = useState(false);
  const [viewRequest,  setViewRequest]    = useState<LeaveRequest | null>(null);
  const [rejectId,     setRejectId]       = useState<string | null>(null);
  const [rejectReason, setRejectReason]   = useState('');

  const [formData, setFormData] = useState({
    leave_type_id: '', start_date: '', end_date: '', reason: '', employee_id: '',
    is_half_day: false, half_day_period: 'morning' as 'morning' | 'afternoon',
    document_url: '',
  });

  const [approvedLeaves, setApprovedLeaves] = useState<LeaveRequest[]>([]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const result = await leaveService.listRequests({
        status: statusFilter !== 'all' ? statusFilter : undefined, page, pageSize,
      });
      setRequests(result.data); setTotal(result.total);
    } catch { toast.error('Failed to load leave requests'); }
    finally { setLoading(false); }
  }, [statusFilter, page, pageSize]);

  const loadApproved = useCallback(async () => {
    try {
      // Fetch up to 500 approved leaves for the calendar view
      const r = await leaveService.listRequests({ status: 'approved', page: 1, pageSize: 500 });
      setApprovedLeaves(r.data);
    } catch { /* silent */ }
  }, []);

  const exportMonthCsv = useCallback((year: number, month: number) => {
    const monthStart = `${year}-${String(month + 1).padStart(2, '0')}-01`;
    const monthEnd   = `${year}-${String(month + 1).padStart(2, '0')}-${new Date(year, month + 1, 0).getDate().toString().padStart(2, '0')}`;
    const rows = approvedLeaves.filter(l => l.start_date <= monthEnd && l.end_date >= monthStart);
    if (rows.length === 0) { toast.info('No approved leaves in this month to export.'); return; }

    const monthName = ['January','February','March','April','May','June','July','August','September','October','November','December'][month];
    const header = ['Employee', 'Leave Type', 'Start Date', 'End Date', 'Days', 'Half Day', 'Status'];
    const lines  = rows.map(l => {
      const emp  = l.employee as { first_name: string; last_name: string } | undefined;
      const name = emp ? `${emp.first_name} ${emp.last_name}` : l.employee_id.slice(0, 8);
      const type = (l.leave_type as { name: string } | undefined)?.name ?? 'Leave';
      const days = Math.max(1, Math.round((new Date(l.end_date).getTime() - new Date(l.start_date).getTime()) / 86400000) + 1);
      const half = l.is_half_day ? `Yes (${l.half_day_period ?? ''})` : 'No';
      return [name, type, l.start_date, l.end_date, String(days), half, l.status]
        .map(v => `"${String(v).replace(/"/g, '""')}"`)
        .join(',');
    });
    const csv  = [header.join(','), ...lines].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `leave_calendar_${monthName}_${year}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${rows.length} leave record${rows.length > 1 ? 's' : ''} for ${monthName} ${year}`);
  }, [approvedLeaves]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { loadApproved(); }, [loadApproved]);
  useEffect(() => { leaveService.listTypes().then(setLeaveTypes).catch(() => {}); }, []);

  const calcDays = (s: string, e: string) => {
    if (!s || !e) return 0;
    return Math.max(1, Math.floor((new Date(e).getTime() - new Date(s).getTime()) / 86400000) + 1);
  };

  const handleApprove = async (id: string) => {
    try { await leaveService.approveRequest(id); toast.success('Approved'); load(); loadApproved(); }
    catch { toast.error('Failed to approve'); }
  };

  const handleRejectConfirm = async () => {
    if (!rejectId) return;
    try { await leaveService.rejectRequest(rejectId, rejectReason || 'Rejected by manager'); toast.success('Rejected'); setRejectId(null); setRejectReason(''); load(); loadApproved(); }
    catch { toast.error('Failed to reject'); }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.employee_id || formData.employee_id === 'none') { toast.error('Select an employee'); return; }
    if (!formData.leave_type_id) { toast.error('Select leave type'); return; }
    if (!formData.start_date || !formData.end_date) { toast.error('Select dates'); return; }
    setSaving(true);
    try {
      await leaveService.createRequest({
        ...formData,
        total_days: calcDays(formData.start_date, formData.end_date),
        status: 'pending',
        document_url: formData.document_url || undefined,
      });
      toast.success('Leave request submitted');
      setCreateOpen(false);
      setFormData({ leave_type_id: '', start_date: '', end_date: '', reason: '', employee_id: '', is_half_day: false, half_day_period: 'morning', document_url: '' });
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Leave Management</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} total requests</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => { load(); loadApproved(); }}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild><Button size="sm"><Plus className="h-4 w-4 mr-1.5" />New Request</Button></DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>Submit Leave Request</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 mt-2">
                <EmployeeSelect value={formData.employee_id} onChange={v => setFormData(p => ({ ...p, employee_id: v }))} required />
                <div className="space-y-1.5">
                  <Label>Leave Type *</Label>
                  <Select value={formData.leave_type_id} onValueChange={v => setFormData(p => ({ ...p, leave_type_id: v }))}>
                    <SelectTrigger><SelectValue placeholder="Select leave type" /></SelectTrigger>
                    <SelectContent>
                      {leaveTypes.map(lt => <SelectItem key={lt.id} value={lt.id}>{lt.name} ({lt.days_per_year} days/yr)</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5"><Label>Start Date *</Label>
                    <Input type="date" value={formData.start_date} onChange={e => setFormData(p => ({ ...p, start_date: e.target.value }))} required /></div>
                  <div className="space-y-1.5"><Label>End Date *</Label>
                    <Input type="date" value={formData.end_date} onChange={e => setFormData(p => ({ ...p, end_date: e.target.value }))} required /></div>
                </div>
                {formData.start_date && formData.end_date && (
                  <p className="text-sm text-muted-foreground">Total: <strong>{calcDays(formData.start_date, formData.end_date)} day(s)</strong></p>
                )}
                {/* Half Day */}
                <div className="flex items-center gap-3">
                  <Switch id="half-day" checked={formData.is_half_day} onCheckedChange={v => setFormData(p => ({ ...p, is_half_day: v }))} />
                  <Label htmlFor="half-day" className="font-normal">Half Day</Label>
                  {formData.is_half_day && (
                    <Select value={formData.half_day_period} onValueChange={v => setFormData(p => ({ ...p, half_day_period: v as 'morning' | 'afternoon' }))}>
                      <SelectTrigger className="w-36 h-8"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="morning">Morning</SelectItem>
                        <SelectItem value="afternoon">Afternoon</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                </div>
                <div className="space-y-1.5"><Label>Reason</Label>
                  <Textarea value={formData.reason} onChange={e => setFormData(p => ({ ...p, reason: e.target.value }))} rows={3} placeholder="Reason for leave…" /></div>
                <div className="space-y-1.5"><Label>Document URL</Label>
                  <Input value={formData.document_url} onChange={e => setFormData(p => ({ ...p, document_url: e.target.value }))} placeholder="https://…  (optional)" /></div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
                  <Button type="submit" disabled={saving}>{saving ? 'Submitting…' : 'Submit Request'}</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Reject reason dialog */}
      <Dialog open={!!rejectId} onOpenChange={o => { if (!o) { setRejectId(null); setRejectReason(''); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle>Reject Leave Request</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5"><Label>Rejection Reason</Label>
              <Textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)} rows={3} placeholder="Optional reason…" /></div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => { setRejectId(null); setRejectReason(''); }}>Cancel</Button>
              <Button variant="destructive" onClick={handleRejectConfirm}>Confirm Reject</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Detail view */}
      {viewRequest && <LeaveDetailDialog request={viewRequest} onClose={() => setViewRequest(null)} />}

      <Tabs defaultValue="list">
        <TabsList className="flex-wrap gap-1 h-auto">
          <TabsTrigger value="list"><List className="h-3.5 w-3.5 mr-1.5" />Requests</TabsTrigger>
          <TabsTrigger value="calendar"><CalendarDays className="h-3.5 w-3.5 mr-1.5" />Calendar</TabsTrigger>
          <TabsTrigger value="balances"><BarChart2 className="h-3.5 w-3.5 mr-1.5" />Balances</TabsTrigger>
          <TabsTrigger value="get-pass"><ClipboardCheck className="h-3.5 w-3.5 mr-1.5" />Get Pass</TabsTrigger>
          <TabsTrigger value="blackout"><ShieldBan className="h-3.5 w-3.5 mr-1.5" />Blackout Periods</TabsTrigger>
          <TabsTrigger value="substitution"><ArrowRightLeft className="h-3.5 w-3.5 mr-1.5" />Substitutions</TabsTrigger>
        </TabsList>

        {/* ── List ── */}
        <TabsContent value="list" className="mt-4 space-y-4">
          <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setPage(1); }}>
            <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              {['all','pending','approved','rejected','cancelled'].map(s => (
                <SelectItem key={s} value={s}>{s === 'all' ? 'All Statuses' : s.charAt(0).toUpperCase() + s.slice(1)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Leave Type</TableHead>
                    <TableHead className="whitespace-nowrap">Start</TableHead>
                    <TableHead className="whitespace-nowrap">End</TableHead>
                    <TableHead className="whitespace-nowrap">Days</TableHead>
                    <TableHead className="whitespace-nowrap">Half Day</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Approved By</TableHead>
                    <TableHead className="whitespace-nowrap">Doc</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 8 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 10 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-16 bg-muted" /></TableCell>)}</TableRow>
                  )) : requests.length === 0 ? (
                    <TableRow><TableCell colSpan={10} className="text-center py-12 text-muted-foreground">
                      <CalendarDays className="h-10 w-10 mx-auto mb-2 opacity-40" />No leave requests found
                    </TableCell></TableRow>
                  ) : requests.map(req => {
                    const emp = req.employee as { first_name: string; last_name: string } | undefined;
                    const lt  = req.leave_type as { name: string } | undefined;
                    return (
                      <TableRow key={req.id}>
                        <TableCell className="whitespace-nowrap font-medium text-sm">
                          {emp ? `${emp.first_name} ${emp.last_name}` : req.employee_id.slice(0, 8)}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{lt?.name ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{req.start_date}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{req.end_date}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm font-medium">{req.total_days}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">
                          {req.is_half_day
                            ? <Badge variant="outline" className="text-xs capitalize">{req.half_day_period ?? 'Yes'}</Badge>
                            : <span className="text-muted-foreground text-xs">—</span>}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${STATUS_COLORS[req.status] ?? 'bg-muted text-muted-foreground'}`}>{req.status}</span>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                          {req.approved_by ? req.approved_by.slice(0, 8) + '…' : '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          {req.document_url
                            ? <a href={req.document_url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline"><Paperclip className="h-3.5 w-3.5" /></a>
                            : <span className="text-muted-foreground">—</span>}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex items-center gap-1">
                            <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => setViewRequest(req)}><Eye className="h-3.5 w-3.5" /></Button>
                            {req.status === 'pending' && (
                              <>
                                <Button size="sm" variant="outline" className="h-7 px-2 text-green-600 border-green-200 hover:bg-green-50" onClick={() => handleApprove(req.id)}><Check className="h-3.5 w-3.5" /></Button>
                                <Button size="sm" variant="outline" className="h-7 px-2 text-red-500 border-red-200 hover:bg-red-50" onClick={() => { setRejectId(req.id); setRejectReason(''); }}><X className="h-3.5 w-3.5" /></Button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
          {Math.ceil(total / pageSize) > 1 && (
            <div className="flex justify-end gap-2">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</Button>
              <span className="text-sm self-center">{page} / {Math.ceil(total / pageSize)}</span>
              <Button size="sm" variant="outline" disabled={page >= Math.ceil(total / pageSize)} onClick={() => setPage(p => p + 1)}>Next</Button>
            </div>
          )}
        </TabsContent>

        {/* ── Calendar ── */}
        <TabsContent value="calendar" className="mt-4">
          <div className="bg-card border border-border rounded-lg p-4 md:p-6">
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-muted-foreground">Showing all approved leave requests</p>
              <Button variant="outline" size="sm" className="h-8 gap-1.5" onClick={loadApproved}>
                <RefreshCw className="h-3.5 w-3.5" />Refresh
              </Button>
            </div>
            <LeaveCalendar approvedLeaves={approvedLeaves} onExportCsv={exportMonthCsv} />
          </div>
        </TabsContent>

        {/* ── Balances ── */}
        <TabsContent value="balances" className="mt-4">
          <BalanceTab />
        </TabsContent>

        {/* ── Get Pass (FR-LEAVE-020/021) ── */}
        <TabsContent value="get-pass" className="mt-4">
          <GetPassTab />
        </TabsContent>

        {/* ── Blackout Periods (FR-LEAVE-022) ── */}
        <TabsContent value="blackout" className="mt-4">
          <BlackoutPeriodsTab />
        </TabsContent>

        {/* ── Leave Substitutions (FR-LEAVE-023) ── */}
        <TabsContent value="substitution" className="mt-4">
          <SubstitutionTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
