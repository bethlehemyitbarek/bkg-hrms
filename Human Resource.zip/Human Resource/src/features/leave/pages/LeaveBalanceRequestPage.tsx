import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import type { LeaveBalance, LeaveRequest, LeaveType, FiscalYear } from '@/types/database.types';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import {
  Plus, RefreshCw, Pencil, Trash2, Wallet, CheckCircle,
  XCircle, Calendar, SendHorizonal, AlertCircle
} from 'lucide-react';

const REQUEST_STATUS_COLORS: Record<string, string> = {
  DRAFT:     'bg-muted text-muted-foreground',
  SUBMITTED: 'bg-blue-100 text-blue-800',
  APPROVED:  'bg-green-100 text-green-800',
  REJECTED:  'bg-red-100 text-red-800',
  CANCELLED: 'bg-orange-100 text-orange-800',
  WITHDRAWN: 'bg-muted text-muted-foreground',
};
const REQUEST_STATUSES = ['DRAFT','SUBMITTED','APPROVED','REJECTED','CANCELLED','WITHDRAWN'] as const;

const balanceSchema = z.object({
  employee_id:          z.string().min(1, 'Required'),
  leave_type_id:        z.string().min(1, 'Required'),
  fiscal_year_id:       z.string().optional(),
  entitled_days:        z.coerce.number().min(0),
  used_days:            z.coerce.number().min(0),
  accrued_days:         z.coerce.number().min(0),
  carried_forward_days: z.coerce.number().min(0),
  adjustment_days:      z.coerce.number().min(0),
});
type BalanceForm = z.infer<typeof balanceSchema>;

const requestSchema = z.object({
  employee_id:            z.string().min(1, 'Required'),
  leave_type_id:          z.string().min(1, 'Required'),
  start_date:             z.string().min(1, 'Required'),
  end_date:               z.string().min(1, 'Required'),
  total_days:             z.coerce.number().min(0.5),
  reason:                 z.string().optional(),
  contact_info:           z.string().optional(),
  substitute_employee_id: z.string().optional(),
  request_status:         z.enum(REQUEST_STATUSES),
  is_backdated:           z.boolean(),
});
type RequestForm = z.infer<typeof requestSchema>;

export function LeaveBalanceRequestPage() {
  const [tab, setTab] = useState<'balances' | 'requests'>('requests');

  const [balances,    setBalances]    = useState<LeaveBalance[]>([]);
  const [balLoading,  setBalLoading]  = useState(true);
  const [balDialog,   setBalDialog]   = useState(false);
  const [editBal,     setEditBal]     = useState<LeaveBalance | null>(null);
  const [balSaving,   setBalSaving]   = useState(false);
  const [balEmpFilter,setBalEmpFilter]= useState('');

  const [requests,    setRequests]    = useState<LeaveRequest[]>([]);
  const [reqLoading,  setReqLoading]  = useState(true);
  const [reqTotal,    setReqTotal]    = useState(0);
  const [reqPage,     setReqPage]     = useState(1);
  const [reqDialog,   setReqDialog]   = useState(false);
  const [editReq,     setEditReq]     = useState<LeaveRequest | null>(null);
  const [reqSaving,   setReqSaving]   = useState(false);
  const [reqStatusFilter, setReqStatusFilter] = useState('all');
  const [reqEmpFilter,setReqEmpFilter]= useState('');
  const PAGE = 20;

  const [leaveTypes,  setLeaveTypes]  = useState<LeaveType[]>([]);
  const [fiscalYears, setFiscalYears] = useState<FiscalYear[]>([]);

  const balForm = useForm<BalanceForm>({
    resolver: zodResolver(balanceSchema),
    defaultValues: { employee_id: '', leave_type_id: '', entitled_days: 0, used_days: 0, accrued_days: 0, carried_forward_days: 0, adjustment_days: 0 },
  });
  const reqForm = useForm<RequestForm>({
    resolver: zodResolver(requestSchema),
    defaultValues: { employee_id: '', leave_type_id: '', start_date: '', end_date: '', total_days: 1, request_status: 'DRAFT', is_backdated: false },
  });

  const loadBalances = useCallback(async () => {
    setBalLoading(true);
    let q = supabase.from('leave_balances')
      .select('*, leave_type:leave_types(id,name,leave_category), fiscal_year:fiscal_years(id,year_label)')
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false });
    if (balEmpFilter) q = q.eq('employee_id', balEmpFilter);
    const { data, error } = await q;
    if (error) toast.error('Failed to load balances');
    else setBalances((data ?? []) as LeaveBalance[]);
    setBalLoading(false);
  }, [balEmpFilter]);

  const loadRequests = useCallback(async () => {
    setReqLoading(true);
    let q = supabase.from('leave_requests')
      .select('*, employee:employees!leave_requests_employee_id_fkey(id,first_name,last_name,employee_no), leave_type:leave_types(id,name)', { count: 'exact' })
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false })
      .range((reqPage - 1) * PAGE, reqPage * PAGE - 1);
    if (reqStatusFilter !== 'all') q = q.eq('request_status', reqStatusFilter);
    if (reqEmpFilter) q = q.eq('employee_id', reqEmpFilter);
    const { data, count, error } = await q;
    if (error) toast.error('Failed to load requests');
    else { setRequests((data ?? []) as LeaveRequest[]); setReqTotal(count ?? 0); }
    setReqLoading(false);
  }, [reqStatusFilter, reqEmpFilter, reqPage]);

  const loadMeta = useCallback(async () => {
    const [lt, fy] = await Promise.all([
      supabase.from('leave_types').select('id,name,leave_category').eq('is_active', true).order('name'),
      supabase.from('fiscal_years').select('id,year_label').eq('is_deleted', 0).order('start_date', { ascending: false }),
    ]);
    setLeaveTypes((lt.data ?? []) as LeaveType[]);
    setFiscalYears((fy.data ?? []) as FiscalYear[]);
  }, []);

  useEffect(() => { loadBalances(); }, [loadBalances]);
  useEffect(() => { loadRequests(); }, [loadRequests]);
  useEffect(() => { loadMeta(); }, [loadMeta]);

  const openCreateBal = () => {
    setEditBal(null);
    balForm.reset({ employee_id: '', leave_type_id: '', entitled_days: 0, used_days: 0, accrued_days: 0, carried_forward_days: 0, adjustment_days: 0 });
    setBalDialog(true);
  };
  const openEditBal = (b: LeaveBalance) => {
    setEditBal(b);
    balForm.reset({
      employee_id:          b.employee_id,
      leave_type_id:        b.leave_type_id,
      fiscal_year_id:       b.fiscal_year_id ?? '',
      entitled_days:        b.entitled_days ?? 0,
      used_days:            b.used_days ?? 0,
      accrued_days:         b.accrued_days ?? 0,
      carried_forward_days: b.carried_forward_days ?? 0,
      adjustment_days:      b.adjustment_days ?? 0,
    });
    setBalDialog(true);
  };
  const submitBal = balForm.handleSubmit(async (vals) => {
    setBalSaving(true);
    const avail = (vals.entitled_days ?? 0) + (vals.accrued_days ?? 0) + (vals.carried_forward_days ?? 0) + (vals.adjustment_days ?? 0) - (vals.used_days ?? 0);
    const payload: Record<string, unknown> = {
      employee_id: vals.employee_id,
      leave_type_id: vals.leave_type_id,
      fiscal_year_id: vals.fiscal_year_id || null,
      entitled_days: vals.entitled_days,
      used_days: vals.used_days,
      accrued_days: vals.accrued_days,
      carried_forward_days: vals.carried_forward_days,
      carried_forward: vals.carried_forward_days,
      adjustment_days: vals.adjustment_days,
      available_days: avail < 0 ? 0 : avail,
      updated_at: new Date().toISOString(),
    };
    const { error } = editBal
      ? await supabase.from('leave_balances').update(payload).eq('id', editBal.id)
      : await supabase.from('leave_balances').insert({ ...payload, year: new Date().getFullYear() });
    if (error) toast.error(error.message);
    else { toast.success(editBal ? 'Balance updated' : 'Balance created'); setBalDialog(false); loadBalances(); }
    setBalSaving(false);
  });
  const deleteBal = async (id: string) => {
    if (!confirm('Delete this leave balance record?')) return;
    const { error } = await supabase.from('leave_balances').update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Balance deleted'); loadBalances(); }
  };

  const openCreateReq = () => {
    setEditReq(null);
    reqForm.reset({ employee_id: '', leave_type_id: '', start_date: '', end_date: '', total_days: 1, request_status: 'DRAFT', is_backdated: false });
    setReqDialog(true);
  };
  const openEditReq = (r: LeaveRequest) => {
    setEditReq(r);
    const st = (r.request_status ?? r.status ?? 'DRAFT').toUpperCase() as typeof REQUEST_STATUSES[number];
    reqForm.reset({
      employee_id:            r.employee_id,
      leave_type_id:          r.leave_type_id,
      start_date:             r.start_date,
      end_date:               r.end_date,
      total_days:             r.total_days,
      reason:                 r.reason ?? '',
      contact_info:           r.contact_info ?? '',
      substitute_employee_id: r.substitute_employee_id ?? '',
      request_status:         st,
      is_backdated:           (r.is_backdated ?? 0) === 1,
    });
    setReqDialog(true);
  };
  const submitReq = reqForm.handleSubmit(async (vals) => {
    setReqSaving(true);
    const payload: Record<string, unknown> = {
      employee_id:            vals.employee_id,
      leave_type_id:          vals.leave_type_id,
      start_date:             vals.start_date,
      end_date:               vals.end_date,
      total_days:             vals.total_days,
      reason:                 vals.reason || null,
      contact_info:           vals.contact_info || null,
      substitute_employee_id: vals.substitute_employee_id || null,
      request_status:         vals.request_status,
      status:                 vals.request_status.toLowerCase(),
      is_backdated:           vals.is_backdated ? 1 : 0,
      updated_at:             new Date().toISOString(),
    };
    const { error } = editReq
      ? await supabase.from('leave_requests').update(payload).eq('id', editReq.id)
      : await supabase.from('leave_requests').insert({ ...payload, is_half_day: false });
    if (error) toast.error(error.message);
    else { toast.success(editReq ? 'Request updated' : 'Request created'); setReqDialog(false); loadRequests(); }
    setReqSaving(false);
  });
  const deleteReq = async (id: string) => {
    if (!confirm('Delete this leave request?')) return;
    const { error } = await supabase.from('leave_requests').update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Request deleted'); loadRequests(); }
  };

  const quickAction = async (id: string, status: string) => {
    const { error } = await supabase.from('leave_requests').update({ request_status: status, status: status.toLowerCase(), updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success(`Request ${status.toLowerCase()}`); loadRequests(); }
  };

  const reqPages = Math.ceil(reqTotal / PAGE);
  const pendingCount = requests.filter(r => (r.request_status ?? r.status ?? '').toUpperCase() === 'SUBMITTED').length;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Leave Balances & Requests</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Track employee leave balances and manage leave requests</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => { loadBalances(); loadRequests(); }}>
            <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
          </Button>
          {tab === 'balances'
            ? <Button size="sm" onClick={openCreateBal}><Plus className="h-4 w-4 mr-1.5" />Add Balance</Button>
            : <Button size="sm" onClick={openCreateReq}><Plus className="h-4 w-4 mr-1.5" />New Request</Button>}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Balance Records', value: balances.length, icon: Wallet, color: 'text-primary' },
          { label: 'Pending Approval', value: pendingCount, icon: AlertCircle, color: 'text-orange-500' },
          { label: 'Approved (page)', value: requests.filter(r => (r.request_status??r.status??'').toUpperCase()==='APPROVED').length, icon: CheckCircle, color: 'text-green-600' },
          { label: 'Total Requests', value: reqTotal, icon: Calendar, color: 'text-blue-500' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <s.icon className={`h-4 w-4 ${s.color} shrink-0`} />
            <div><p className="text-xs text-muted-foreground">{s.label}</p><p className="text-xl font-bold">{s.value}</p></div>
          </div>
        ))}
      </div>

      {pendingCount > 0 && (
        <div className="bg-orange-50 border border-orange-200 dark:bg-orange-950/20 dark:border-orange-800 rounded-lg px-4 py-2.5 flex items-center gap-2 text-sm text-orange-700 dark:text-orange-400">
          <AlertCircle className="h-4 w-4 shrink-0" />
          <span className="font-medium">{pendingCount} request{pendingCount > 1 ? 's' : ''} awaiting approval</span>
          <Button size="sm" variant="ghost" className="h-7 ml-auto text-orange-700 border border-orange-300"
            onClick={() => { setReqStatusFilter('SUBMITTED'); setTab('requests'); }}>Review</Button>
        </div>
      )}

      <Tabs value={tab} onValueChange={v => setTab(v as typeof tab)}>
        <TabsList>
          <TabsTrigger value="requests"><Calendar className="h-4 w-4 mr-1.5" />Requests ({reqTotal})</TabsTrigger>
          <TabsTrigger value="balances"><Wallet className="h-4 w-4 mr-1.5" />Balances ({balances.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="requests" className="mt-4 space-y-3">
          <div className="flex flex-wrap items-end gap-3">
            <div className="space-y-1 min-w-[180px]"><Label className="text-xs">Employee</Label>
              <EmployeeSelect value={reqEmpFilter} onChange={v => setReqEmpFilter(v === 'none' ? '' : v)} /></div>
            <div className="space-y-1"><Label className="text-xs">Status</Label>
              <Select value={reqStatusFilter} onValueChange={v => { setReqStatusFilter(v); setReqPage(1); }}>
                <SelectTrigger className="w-44 h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  {REQUEST_STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Button variant="outline" size="sm" onClick={() => { setReqEmpFilter(''); setReqStatusFilter('all'); }}>Clear</Button>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Leave Type</TableHead>
                    <TableHead className="whitespace-nowrap">Start Date</TableHead>
                    <TableHead className="whitespace-nowrap">End Date</TableHead>
                    <TableHead className="whitespace-nowrap">Days</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Submitted</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reqLoading ? Array.from({ length: 8 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 8 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-16 bg-muted" /></TableCell>)}</TableRow>
                  )) : requests.length === 0 ? (
                    <TableRow><TableCell colSpan={8} className="text-center py-10 text-muted-foreground">
                      <Calendar className="h-8 w-8 mx-auto mb-2 opacity-40" />No leave requests found
                    </TableCell></TableRow>
                  ) : requests.map(r => {
                    const emp = r.employee as { first_name: string; last_name: string; employee_no: string } | undefined;
                    const lt  = r.leave_type as { name: string } | undefined;
                    const st  = (r.request_status ?? r.status ?? 'DRAFT').toUpperCase();
                    const isPending = st === 'SUBMITTED';
                    return (
                      <TableRow key={r.id} className={isPending ? 'bg-orange-50/30 dark:bg-orange-900/10' : ''}>
                        <TableCell className="whitespace-nowrap font-medium text-sm">
                          {emp ? `${emp.first_name} ${emp.last_name}` : r.employee_id.slice(0,8)}
                          {emp && <span className="text-xs text-muted-foreground ml-1">#{emp.employee_no}</span>}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{lt?.name ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{r.start_date}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{r.end_date}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm font-semibold">{r.total_days}d</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${REQUEST_STATUS_COLORS[st] ?? 'bg-muted text-muted-foreground'}`}>
                            {st}
                          </span>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                          {new Date(r.created_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex gap-1 items-center">
                            {isPending && (
                              <>
                                <Button size="sm" variant="ghost" className="h-7 px-1.5 text-green-600 hover:bg-green-100"
                                  onClick={() => quickAction(r.id, 'APPROVED')} title="Approve">
                                  <CheckCircle className="h-3.5 w-3.5" />
                                </Button>
                                <Button size="sm" variant="ghost" className="h-7 px-1.5 text-red-600 hover:bg-red-100"
                                  onClick={() => quickAction(r.id, 'REJECTED')} title="Reject">
                                  <XCircle className="h-3.5 w-3.5" />
                                </Button>
                              </>
                            )}
                            <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openEditReq(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                            <Button size="sm" variant="outline" className="h-7 px-2 text-destructive hover:bg-destructive/10" onClick={() => deleteReq(r.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
          {reqPages > 1 && (
            <div className="flex justify-end gap-2">
              <Button size="sm" variant="outline" disabled={reqPage <= 1} onClick={() => setReqPage(p => p - 1)}>Prev</Button>
              <span className="text-sm self-center">{reqPage} / {reqPages}</span>
              <Button size="sm" variant="outline" disabled={reqPage >= reqPages} onClick={() => setReqPage(p => p + 1)}>Next</Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="balances" className="mt-4 space-y-3">
          <div className="flex items-end gap-3">
            <div className="space-y-1 min-w-[180px]"><Label className="text-xs">Filter by Employee</Label>
              <EmployeeSelect value={balEmpFilter} onChange={v => setBalEmpFilter(v === 'none' ? '' : v)} /></div>
            <Button variant="outline" size="sm" onClick={() => setBalEmpFilter('')}>Clear</Button>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Employee ID</TableHead>
                    <TableHead className="whitespace-nowrap">Leave Type</TableHead>
                    <TableHead className="whitespace-nowrap">Fiscal Year</TableHead>
                    <TableHead className="whitespace-nowrap">Entitled</TableHead>
                    <TableHead className="whitespace-nowrap">Accrued</TableHead>
                    <TableHead className="whitespace-nowrap">Used</TableHead>
                    <TableHead className="whitespace-nowrap">Carry Fwd</TableHead>
                    <TableHead className="whitespace-nowrap">Adj</TableHead>
                    <TableHead className="whitespace-nowrap">Available</TableHead>
                    <TableHead className="whitespace-nowrap">Usage</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {balLoading ? Array.from({ length: 6 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 11 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-12 bg-muted" /></TableCell>)}</TableRow>
                  )) : balances.length === 0 ? (
                    <TableRow><TableCell colSpan={11} className="text-center py-10 text-muted-foreground">
                      <Wallet className="h-8 w-8 mx-auto mb-2 opacity-40" />No balance records found
                    </TableCell></TableRow>
                  ) : balances.map(b => {
                    const lt = b.leave_type as { name: string } | undefined;
                    const fy = b.fiscal_year as { year_label: string } | undefined;
                    const totalAvail = (b.entitled_days ?? 0) + (b.accrued_days ?? 0) + (b.carried_forward_days ?? 0) + (b.adjustment_days ?? 0);
                    const usedPct = totalAvail > 0 ? Math.min(100, ((b.used_days ?? 0) / totalAvail) * 100) : 0;
                    return (
                      <TableRow key={b.id}>
                        <TableCell className="whitespace-nowrap text-xs font-mono text-muted-foreground">{b.employee_id.slice(0,8)}…</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{lt?.name ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{fy?.year_label ?? b.year ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{b.entitled_days}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{b.accrued_days ?? 0}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm font-medium text-red-600">{b.used_days}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{b.carried_forward_days ?? 0}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">
                          {(b.adjustment_days ?? 0) > 0 ? <span className="text-green-600">+{b.adjustment_days}</span>
                           : (b.adjustment_days ?? 0) < 0 ? <span className="text-red-600">{b.adjustment_days}</span> : '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Badge variant={(b.available_days ?? 0) > 0 ? 'default' : 'destructive'} className="text-xs font-semibold">
                            {b.available_days ?? 0}d
                          </Badge>
                        </TableCell>
                        <TableCell className="whitespace-nowrap min-w-[80px]">
                          <div className="space-y-0.5">
                            <Progress value={usedPct} className="h-1.5 w-16" />
                            <span className="text-xs text-muted-foreground">{usedPct.toFixed(0)}%</span>
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex gap-1.5">
                            <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openEditBal(b)}><Pencil className="h-3.5 w-3.5" /></Button>
                            <Button size="sm" variant="outline" className="h-7 px-2 text-destructive hover:bg-destructive/10" onClick={() => deleteBal(b.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={balDialog} onOpenChange={o => { if (!o) setBalDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editBal ? 'Edit' : 'Add'} Leave Balance</DialogTitle></DialogHeader>
          <Form {...balForm}>
            <form onSubmit={submitBal} className="space-y-4 mt-1">
              <FormField control={balForm.control} name="employee_id" render={({ field }) => (
                <FormItem><FormLabel>Employee *</FormLabel><FormControl>
                  <EmployeeSelect value={field.value} onChange={field.onChange} required />
                </FormControl><FormMessage /></FormItem>
              )} />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={balForm.control} name="leave_type_id" render={({ field }) => (
                  <FormItem><FormLabel>Leave Type *</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger></FormControl>
                      <SelectContent>{leaveTypes.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
                <FormField control={balForm.control} name="fiscal_year_id" render={({ field }) => (
                  <FormItem><FormLabel>Fiscal Year</FormLabel>
                    <Select value={field.value ?? ''} onValueChange={v => field.onChange(v === 'none' ? '' : v)}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select year" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">— None —</SelectItem>
                        {fiscalYears.map(fy => <SelectItem key={fy.id} value={fy.id}>{fy.year_label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
                <FormField control={balForm.control} name="entitled_days" render={({ field }) => (
                  <FormItem><FormLabel>Entitled Days</FormLabel><FormControl><Input type="number" min={0} step={0.5} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={balForm.control} name="accrued_days" render={({ field }) => (
                  <FormItem><FormLabel>Accrued Days</FormLabel><FormControl><Input type="number" min={0} step={0.5} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={balForm.control} name="used_days" render={({ field }) => (
                  <FormItem><FormLabel>Used Days</FormLabel><FormControl><Input type="number" min={0} step={0.5} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={balForm.control} name="carried_forward_days" render={({ field }) => (
                  <FormItem><FormLabel>Carried Forward</FormLabel><FormControl><Input type="number" min={0} step={0.5} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={balForm.control} name="adjustment_days" render={({ field }) => (
                  <FormItem><FormLabel>Adjustment Days</FormLabel><FormControl><Input type="number" step={0.5} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <Separator />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setBalDialog(false)}>Cancel</Button>
                <Button type="submit" disabled={balSaving}>{balSaving ? 'Saving…' : (editBal ? 'Update' : 'Create')}</Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={reqDialog} onOpenChange={o => { if (!o) setReqDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>{editReq ? 'Edit' : 'New'} Leave Request</DialogTitle></DialogHeader>
          <Form {...reqForm}>
            <form onSubmit={submitReq} className="space-y-4 mt-1">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <FormField control={reqForm.control} name="employee_id" render={({ field }) => (
                    <FormItem><FormLabel>Employee *</FormLabel><FormControl>
                      <EmployeeSelect value={field.value} onChange={field.onChange} required />
                    </FormControl><FormMessage /></FormItem>
                  )} />
                </div>
                <FormField control={reqForm.control} name="leave_type_id" render={({ field }) => (
                  <FormItem><FormLabel>Leave Type *</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger></FormControl>
                      <SelectContent>{leaveTypes.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
                <FormField control={reqForm.control} name="request_status" render={({ field }) => (
                  <FormItem><FormLabel>Status *</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>{REQUEST_STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
                <FormField control={reqForm.control} name="start_date" render={({ field }) => (
                  <FormItem><FormLabel>Start Date *</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={reqForm.control} name="end_date" render={({ field }) => (
                  <FormItem><FormLabel>End Date *</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={reqForm.control} name="total_days" render={({ field }) => (
                  <FormItem><FormLabel>Total Days *</FormLabel><FormControl><Input type="number" min={0.5} step={0.5} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={reqForm.control} name="contact_info" render={({ field }) => (
                  <FormItem><FormLabel>Contact Info</FormLabel><FormControl><Input {...field} placeholder="Phone during leave" /></FormControl><FormMessage /></FormItem>
                )} />
                <div className="md:col-span-2">
                  <FormField control={reqForm.control} name="reason" render={({ field }) => (
                    <FormItem><FormLabel>Reason</FormLabel><FormControl><Textarea rows={2} {...field} placeholder="Reason for leave…" /></FormControl><FormMessage /></FormItem>
                  )} />
                </div>
                <div className="md:col-span-2">
                  <FormField control={reqForm.control} name="substitute_employee_id" render={({ field }) => (
                    <FormItem><FormLabel>Substitute Employee</FormLabel><FormControl>
                      <EmployeeSelect value={field.value ?? ''} onChange={v => field.onChange(v === 'none' ? '' : v)} />
                    </FormControl><FormMessage /></FormItem>
                  )} />
                </div>
              </div>
              <FormField control={reqForm.control} name="is_backdated" render={({ field }) => (
                <FormItem className="flex items-center gap-2"><FormControl><Checkbox checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                  <FormLabel className="!mt-0">Backdated request</FormLabel></FormItem>
              )} />
              <Separator />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setReqDialog(false)}>Cancel</Button>
                <Button type="submit" disabled={reqSaving}>
                  {reqSaving ? 'Saving…' : editReq ? 'Update' : <><SendHorizonal className="h-4 w-4 mr-1.5" />Submit</>}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
