import { useState, useEffect, useCallback } from 'react';
import { Plus, Pencil, Trash2, Search, RefreshCw, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Switch } from '@/components/ui/switch';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { allowanceTypeService } from '@/services/compensation.service';
import type { AllowanceType, AllowanceCategory, AllowanceCalculationMethod, AllowanceFrequency } from '@/types/database.types';

const CATEGORIES: AllowanceCategory[] = ['TRANSPORT','HOUSING','MEAL','COMMUNICATION','HARDSHIP','POSITION','REPRESENTATION','FUEL','OTHER'];
const METHODS: AllowanceCalculationMethod[] = ['FIXED','PERCENTAGE_OF_BASIC','PERCENTAGE_OF_GROSS','FORMULA'];
const FREQUENCIES: AllowanceFrequency[] = ['MONTHLY','QUARTERLY','ANNUAL','ONE_TIME'];

const CATEGORY_COLORS: Record<AllowanceCategory, string> = {
  TRANSPORT: 'bg-blue-100 text-blue-700',
  HOUSING: 'bg-purple-100 text-purple-700',
  MEAL: 'bg-orange-100 text-orange-700',
  COMMUNICATION: 'bg-cyan-100 text-cyan-700',
  HARDSHIP: 'bg-red-100 text-red-700',
  POSITION: 'bg-indigo-100 text-indigo-700',
  REPRESENTATION: 'bg-pink-100 text-pink-700',
  FUEL: 'bg-yellow-100 text-yellow-700',
  OTHER: 'bg-muted text-muted-foreground',
};

const schema = z.object({
  allowance_code: z.string().min(1, 'Code is required').max(50),
  allowance_name: z.string().min(1, 'Name is required').max(200),
  allowance_category: z.enum(['TRANSPORT','HOUSING','MEAL','COMMUNICATION','HARDSHIP','POSITION','REPRESENTATION','FUEL','OTHER']),
  calculation_method: z.enum(['FIXED','PERCENTAGE_OF_BASIC','PERCENTAGE_OF_GROSS','FORMULA']),
  default_amount: z.coerce.number().optional(),
  default_percentage: z.coerce.number().min(0).max(100).optional(),
  is_taxable: z.boolean(),
  is_pensionable: z.boolean(),
  frequency: z.enum(['MONTHLY','QUARTERLY','ANNUAL','ONE_TIME']),
  is_active: z.boolean(),
});
type FormValues = z.infer<typeof schema>;

export function AllowanceTypesPage() {
  const [items, setItems] = useState<AllowanceType[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [formOpen, setFormOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<AllowanceType | null>(null);
  const [editing, setEditing] = useState<AllowanceType | null>(null);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      allowance_code: '', allowance_name: '',
      allowance_category: 'OTHER', calculation_method: 'FIXED',
      frequency: 'MONTHLY', is_taxable: true, is_pensionable: false, is_active: true,
    },
  });
  const calcMethod = form.watch('calculation_method');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await allowanceTypeService.list({ category: categoryFilter === 'all' ? undefined : categoryFilter });
      setItems(data);
    } catch (e) {
      toast.error('Failed to load allowance types');
    } finally {
      setLoading(false);
    }
  }, [categoryFilter]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    setEditing(null);
    form.reset({
      allowance_code: '', allowance_name: '',
      allowance_category: 'OTHER', calculation_method: 'FIXED',
      frequency: 'MONTHLY', is_taxable: true, is_pensionable: false, is_active: true,
    });
    setFormOpen(true);
  };

  const openEdit = (item: AllowanceType) => {
    setEditing(item);
    form.reset({
      allowance_code: item.allowance_code,
      allowance_name: item.allowance_name,
      allowance_category: item.allowance_category,
      calculation_method: item.calculation_method,
      default_amount: item.default_amount ?? undefined,
      default_percentage: item.default_percentage ?? undefined,
      is_taxable: item.is_taxable === 1,
      is_pensionable: item.is_pensionable === 1,
      frequency: item.frequency,
      is_active: item.is_active === 1,
    });
    setFormOpen(true);
  };

  const onSubmit = async (vals: FormValues) => {
    setSaving(true);
    try {
      const payload = {
        ...vals,
        tenant_id: '00000000-0000-0000-0000-000000000001',
        is_taxable: vals.is_taxable ? 1 : 0,
        is_pensionable: vals.is_pensionable ? 1 : 0,
        is_active: vals.is_active ? 1 : 0,
        is_current: 1,
        is_deleted: 0,
        row_start: new Date().toISOString(),
        row_end: new Date().toISOString(),
      };
      if (editing) {
        await allowanceTypeService.update(editing.allowance_type_id, payload);
        toast.success('Allowance type updated');
      } else {
        await allowanceTypeService.create(payload);
        toast.success('Allowance type created');
      }
      setFormOpen(false);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await allowanceTypeService.softDelete(deleteTarget.allowance_type_id);
      toast.success('Allowance type deleted');
      setDeleteTarget(null);
      load();
    } catch {
      toast.error('Delete failed');
    }
  };

  const filtered = items.filter(i =>
    !search ||
    i.allowance_name.toLowerCase().includes(search.toLowerCase()) ||
    i.allowance_code.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">Allowance Types</h1>
          <p className="text-sm text-muted-foreground text-pretty">Master list of allowance types offered to employees</p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4 mr-2" /> New Allowance Type
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input className="pl-9" placeholder="Search by name or code…" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="md:w-52">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" onClick={load} title="Refresh">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">
            {loading ? 'Loading…' : `${filtered.length} allowance type${filtered.length !== 1 ? 's' : ''}`}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/40">
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Code</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Name</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Category</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Method</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Default Value</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Frequency</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Taxable</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Status</th>
                  <th className="whitespace-nowrap px-4 py-3 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  Array.from({ length: 4 }).map((_, i) => (
                    <tr key={i} className="border-b">
                      {Array.from({ length: 9 }).map((__, j) => (
                        <td key={j} className="px-4 py-3">
                          <div className="h-4 bg-muted rounded animate-pulse w-20" />
                        </td>
                      ))}
                    </tr>
                  ))
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="px-4 py-10 text-center text-muted-foreground">
                      <Tag className="h-8 w-8 mx-auto mb-2 opacity-30" />
                      No allowance types found
                    </td>
                  </tr>
                ) : filtered.map(item => (
                  <tr key={item.allowance_type_id} className="border-b hover:bg-muted/30 transition-colors">
                    <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">{item.allowance_code}</td>
                    <td className="whitespace-nowrap px-4 py-3 font-medium">{item.allowance_name}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${CATEGORY_COLORS[item.allowance_category]}`}>
                        {item.allowance_category}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs text-muted-foreground">{item.calculation_method.replace(/_/g, ' ')}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">
                      {item.calculation_method === 'FIXED'
                        ? item.default_amount != null ? `${item.default_amount.toLocaleString()} ETB` : '—'
                        : item.default_percentage != null ? `${item.default_percentage}%` : '—'}
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">{item.frequency}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <Badge variant={item.is_taxable ? 'default' : 'secondary'} className="text-xs">
                        {item.is_taxable ? 'Taxable' : 'Non-Taxable'}
                      </Badge>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <Badge variant={item.is_active ? 'default' : 'secondary'} className="text-xs">
                        {item.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(item)}>
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(item)}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Form Dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Allowance Type' : 'New Allowance Type'}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="allowance_code" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Code</FormLabel>
                    <FormControl><Input {...field} placeholder="e.g. TRN-001" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="allowance_name" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl><Input {...field} placeholder="e.g. Transport Allowance" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="allowance_category" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>{CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="calculation_method" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Calculation Method</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>{METHODS.map(m => <SelectItem key={m} value={m}>{m.replace(/_/g, ' ')}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                {(calcMethod === 'FIXED') && (
                  <FormField control={form.control} name="default_amount" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Default Amount (ETB)</FormLabel>
                      <FormControl><Input type="number" min={0} step="0.01" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                )}
                {(calcMethod !== 'FIXED' && calcMethod !== 'FORMULA') && (
                  <FormField control={form.control} name="default_percentage" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Default Percentage (%)</FormLabel>
                      <FormControl><Input type="number" min={0} max={100} step="0.01" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                )}
                <FormField control={form.control} name="frequency" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Frequency</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>{FREQUENCIES.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <div className="flex flex-wrap gap-6 pt-1">
                <FormField control={form.control} name="is_taxable" render={({ field }) => (
                  <FormItem className="flex items-center gap-2">
                    <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                    <FormLabel className="!mt-0">Taxable</FormLabel>
                  </FormItem>
                )} />
                <FormField control={form.control} name="is_pensionable" render={({ field }) => (
                  <FormItem className="flex items-center gap-2">
                    <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                    <FormLabel className="!mt-0">Pensionable</FormLabel>
                  </FormItem>
                )} />
                <FormField control={form.control} name="is_active" render={({ field }) => (
                  <FormItem className="flex items-center gap-2">
                    <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                    <FormLabel className="!mt-0">Active</FormLabel>
                  </FormItem>
                )} />
              </div>
              <DialogFooter className="pt-2">
                <Button type="button" variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={o => !o && setDeleteTarget(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Allowance Type</AlertDialogTitle>
            <AlertDialogDescription>
              Delete <strong>{deleteTarget?.allowance_name}</strong>? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
