import { useState, useEffect, useCallback } from 'react';
import { Plus, History, Search, RefreshCw, DollarSign, ChevronRight, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { employeeCompensationService, compensationStructureService } from '@/services/compensation.service';
import { employeeService } from '@/services/employee.service';
import type { EmployeeCompensation, CompensationStructure, Employee, PaymentType } from '@/types/database.types';

const PAYMENT_TYPES: PaymentType[] = ['MONTHLY', 'DAILY', 'HOURLY', 'WEEKLY'];
const CURRENCIES = ['ETB', 'USD', 'EUR', 'GBP'];

const schema = z.object({
  employee_id: z.string().min(1, 'Employee required'),
  structure_id: z.string().optional(),
  base_salary: z.coerce.number().min(0, 'Salary must be positive'),
  currency_code: z.string().min(1, 'Currency required'),
  payment_type: z.enum(['MONTHLY', 'DAILY', 'HOURLY', 'WEEKLY']),
  effective_from: z.string().min(1, 'Effective from required'),
  effective_to: z.string().optional(),
  reason: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

export function EmployeeCompensationPage() {
  const [records, setRecords] = useState<EmployeeCompensation[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [structures, setStructures] = useState<CompensationStructure[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [historyEmpId, setHistoryEmpId] = useState<string | null>(null);
  const [historyRecords, setHistoryRecords] = useState<EmployeeCompensation[]>([]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [expandedEmp, setExpandedEmp] = useState<Set<string>>(new Set());

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { currency_code: 'ETB', payment_type: 'MONTHLY', effective_from: new Date().toISOString().slice(0,10) },
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [recs, emps, structs] = await Promise.all([
        employeeCompensationService.listAll({ is_current: 1 }),
        employeeService.list({ pageSize: 500 }),
        compensationStructureService.list({ is_active: 1 }),
      ]);
      setRecords(Array.isArray(recs) ? recs : []);
      setEmployees(Array.isArray(emps.data) ? emps.data : []);
      setStructures(Array.isArray(structs) ? structs : []);
    } catch {
      toast.error('Failed to load compensation records');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openAssign = () => {
    form.reset({ currency_code: 'ETB', payment_type: 'MONTHLY', effective_from: new Date().toISOString().slice(0,10) });
    setFormOpen(true);
  };

  const onSubmit = async (vals: FormValues) => {
    setSaving(true);
    try {
      await employeeCompensationService.assign({
        ...vals,
        tenant_id: '00000000-0000-0000-0000-000000000001',
        structure_id: vals.structure_id || undefined,
        is_active: 1,
        is_deleted: 0,
        is_current: 1,
        row_start: new Date().toISOString(),
        row_end: new Date().toISOString(),
      });
      toast.success('Compensation assigned successfully');
      setFormOpen(false);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to assign compensation');
    } finally {
      setSaving(false);
    }
  };

  const openHistory = async (empId: string) => {
    setHistoryEmpId(empId);
    try {
      const hist = await employeeCompensationService.listByEmployee(empId);
      setHistoryRecords(hist);
      setHistoryOpen(true);
    } catch {
      toast.error('Failed to load history');
    }
  };

  const filtered = records.filter(r => {
    if (!search) return true;
    const emp = r.employee;
    const name = emp ? `${emp.first_name} ${emp.last_name} ${emp.employee_no}`.toLowerCase() : '';
    return name.includes(search.toLowerCase());
  });

  // Group by employee for display
  const grouped: Record<string, EmployeeCompensation[]> = {};
  filtered.forEach(r => {
    const key = r.employee_id;
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(r);
  });

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">Employee Compensation</h1>
          <p className="text-sm text-muted-foreground text-pretty">Assign and track employee base salary and compensation structures</p>
        </div>
        <Button onClick={openAssign}>
          <Plus className="h-4 w-4 mr-2" /> Assign Compensation
        </Button>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input className="pl-9" placeholder="Search by employee name or ID…" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <Button variant="ghost" size="icon" onClick={load}><RefreshCw className="h-4 w-4" /></Button>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Active Records', value: records.length },
          { label: 'Avg Base Salary', value: records.length ? `${(records.reduce((s,r) => s + Number(r.base_salary),0) / records.length).toLocaleString(undefined,{maximumFractionDigits:0})} ETB` : '—' },
          { label: 'Total Monthly Cost', value: `${records.filter(r=>r.payment_type==='MONTHLY').reduce((s,r)=>s+Number(r.base_salary),0).toLocaleString()} ETB` },
          { label: 'Structures Used', value: new Set(records.map(r=>r.structure_id).filter(Boolean)).size },
        ].map(s => (
          <Card key={s.label}>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className="text-lg font-semibold mt-1">{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Records Table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">
            {loading ? 'Loading…' : `${Object.keys(grouped).length} employee${Object.keys(grouped).length !== 1 ? 's' : ''}`}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/40">
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Employee</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Base Salary</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Currency</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Type</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Structure</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Effective From</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Status</th>
                  <th className="whitespace-nowrap px-4 py-3 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i} className="border-b">
                      {Array.from({ length: 8 }).map((__, j) => (
                        <td key={j} className="px-4 py-3"><div className="h-4 bg-muted rounded animate-pulse w-20" /></td>
                      ))}
                    </tr>
                  ))
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-4 py-10 text-center text-muted-foreground">
                      <DollarSign className="h-8 w-8 mx-auto mb-2 opacity-30" />
                      No compensation records found
                    </td>
                  </tr>
                ) : filtered.map(r => (
                  <tr key={r.compensation_id} className="border-b hover:bg-muted/30 transition-colors">
                    <td className="whitespace-nowrap px-4 py-3">
                      <div className="font-medium">
                        {r.employee ? `${r.employee.first_name} ${r.employee.last_name}` : r.employee_id}
                      </div>
                      <div className="text-xs text-muted-foreground">{r.employee?.employee_no}</div>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 font-semibold">{Number(r.base_salary).toLocaleString()}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">{r.currency_code}</td>
                    <td className="whitespace-nowrap px-4 py-3"><Badge variant="secondary" className="text-xs">{r.payment_type}</Badge></td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs text-muted-foreground">
                      {r.structure?.structure_name ?? '—'}
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">{r.effective_from}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <Badge variant={r.is_current ? 'default' : 'secondary'} className="text-xs">
                        {r.is_current ? 'Current' : 'Historical'}
                      </Badge>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openHistory(r.employee_id)} title="View History">
                          <History className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Assign Dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Assign Compensation</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="employee_id" render={({ field }) => (
                <FormItem>
                  <FormLabel>Employee</FormLabel>
                  <Select value={field.value ?? ''} onValueChange={field.onChange}>
                    <FormControl><SelectTrigger><SelectValue placeholder="Select employee" /></SelectTrigger></FormControl>
                    <SelectContent>
                      {employees.map(e => (
                        <SelectItem key={e.id} value={e.id}>{e.first_name} {e.last_name} ({e.employee_no})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="base_salary" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Base Salary</FormLabel>
                    <FormControl><Input type="number" min={0} step="0.01" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="currency_code" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Currency</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>{CURRENCIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="payment_type" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Type</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>{PAYMENT_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="structure_id" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Compensation Structure <span className="text-muted-foreground text-xs">(optional)</span></FormLabel>
                    <Select value={field.value ?? 'none'} onValueChange={v => field.onChange(v === 'none' ? undefined : v)}>
                      <FormControl><SelectTrigger><SelectValue placeholder="None" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {structures.map(s => <SelectItem key={s.structure_id} value={s.structure_id}>{s.structure_name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="effective_from" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Effective From</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="effective_to" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Effective To <span className="text-muted-foreground text-xs">(optional)</span></FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="reason" render={({ field }) => (
                <FormItem>
                  <FormLabel>Reason <span className="text-muted-foreground text-xs">(optional)</span></FormLabel>
                  <FormControl><Textarea {...field} rows={2} placeholder="Reason for assignment or change…" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Assign'}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* History Dialog */}
      <Dialog open={historyOpen} onOpenChange={setHistoryOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-3xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Compensation History</DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            {historyRecords.length === 0 ? (
              <p className="text-center py-8 text-muted-foreground">No history found</p>
            ) : historyRecords.map((r, i) => (
              <div key={r.compensation_id} className="flex items-start gap-3">
                <div className="flex flex-col items-center">
                  <div className={`h-3 w-3 rounded-full mt-1 ${r.is_current ? 'bg-primary' : 'bg-muted-foreground/30'}`} />
                  {i < historyRecords.length - 1 && <div className="w-0.5 flex-1 bg-border mt-1" />}
                </div>
                <div className="flex-1 min-w-0 pb-4">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold">{Number(r.base_salary).toLocaleString()} {r.currency_code}</span>
                    <Badge variant="secondary" className="text-xs">{r.payment_type}</Badge>
                    {r.is_current ? <Badge className="text-xs">Current</Badge> : null}
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {r.effective_from} {r.effective_to ? `→ ${r.effective_to}` : '→ Present'}
                    {r.structure?.structure_name ? ` · ${r.structure.structure_name}` : ''}
                  </div>
                  {r.reason && <p className="text-xs text-muted-foreground mt-0.5 italic">{r.reason}</p>}
                </div>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setHistoryOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
