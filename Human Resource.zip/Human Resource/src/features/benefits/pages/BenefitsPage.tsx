import { useState, useEffect, useCallback } from 'react';
import { benefitsService } from '@/services/modules.service';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { RefreshCw, HandCoins, Heart, DollarSign, Building2, Plus, Loader2 } from 'lucide-react';
import { supabase } from '@/db/supabase';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

export function BenefitsPage() {
  const [plans, setPlans] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const p = await benefitsService.listPlans();
      setPlans((p as unknown as Record<string, unknown>[]) || []);
    } catch { toast.error('Failed to load benefits'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Benefits Management</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{plans.length} benefit plans</p>
        </div>
        <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
      </div>

      <Tabs defaultValue="plans">
        <TabsList className="flex-wrap gap-1 h-auto">
          <TabsTrigger value="plans" className="gap-1.5"><HandCoins className="h-3.5 w-3.5" />Benefit Plans</TabsTrigger>
          <TabsTrigger value="life-events" className="gap-1.5"><Heart className="h-3.5 w-3.5" />Life Events</TabsTrigger>
          <TabsTrigger value="cost-tracking" className="gap-1.5"><DollarSign className="h-3.5 w-3.5" />Cost Tracking</TabsTrigger>
          <TabsTrigger value="carrier-billing" className="gap-1.5"><Building2 className="h-3.5 w-3.5" />Carrier Billing</TabsTrigger>
        </TabsList>

        {/* ── FR-BEN-001: Benefit Plans ── */}
        <TabsContent value="plans" className="mt-4">
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Name</TableHead>
                  <TableHead className="whitespace-nowrap">Type</TableHead>
                  <TableHead className="whitespace-nowrap">Provider</TableHead>
                  <TableHead className="whitespace-nowrap">Effective From</TableHead>
                  <TableHead className="whitespace-nowrap">Employment Type</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 4 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                  : plans.length === 0 ? <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground"><HandCoins className="h-8 w-8 mx-auto mb-2 opacity-40" />No benefit plans found</TableCell></TableRow>
                  : plans.map((p, i) => (
                    <TableRow key={String(p.id ?? i)}>
                      <TableCell className="whitespace-nowrap font-medium text-sm">{String(p.plan_name ?? p.name ?? '')}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm capitalize">{String(p.plan_type ?? p.type ?? '').replace(/_/g, ' ')}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{String(p.provider_name ?? p.provider ?? '—')}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{p.effective_start_date ? String(p.effective_start_date) : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{p.eligible_employment_type ? String(p.eligible_employment_type).replace(/_/g,' ') : 'All'}</TableCell>
                      <TableCell className="whitespace-nowrap"><span className={`text-xs px-2 py-0.5 rounded-full font-medium ${Number(p.is_active) === 1 ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}`}>{Number(p.is_active) === 1 ? 'Active' : 'Inactive'}</span></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── FR-BEN-007: Life Events ── */}
        <TabsContent value="life-events" className="mt-4">
          <LifeEventsTab />
        </TabsContent>

        {/* ── FR-BEN-008/009: Cost Tracking ── */}
        <TabsContent value="cost-tracking" className="mt-4">
          <BenefitCostTab />
        </TabsContent>

        {/* ── FR-BEN-010: Carrier Billing ── */}
        <TabsContent value="carrier-billing" className="mt-4">
          <CarrierBillingTab />
        </TabsContent>

      </Tabs>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-BEN-007 – Life Events
   ───────────────────────────────────────────────────────────────────────── */
type LifeRow = { event_id?: string; employee_id: string; event_type: string; event_date?: string; supporting_doc?: string; status?: string; notes?: string };

function LifeEventsTab() {
  const [rows, setRows] = useState<LifeRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ employee_id: '', event_type: 'MARRIAGE', event_date: '', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('benefit_life_events').select('*').order('event_date', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.employee_id) { toast.error('Employee ID required'); return; }
    setSaving(true);
    const { error } = await sb.from('benefit_life_events').insert({ employee_id: form.employee_id, event_type: form.event_type, event_date: form.event_date || new Date().toISOString().slice(0, 10), notes: form.notes || null, status: 'PENDING_REVIEW' });
    if (error) toast.error(error.message); else { toast.success('Life event recorded'); setOpen(false); load(); }
    setSaving(false);
  };

  const EVENT_TYPES = ['MARRIAGE', 'DIVORCE', 'NEW_CHILD', 'ADOPTION', 'DEPENDENT_DEATH', 'SPOUSE_EMPLOYMENT', 'DISABILITY'];
  const STATUS_BADGE: Record<string, string> = { PENDING_REVIEW: 'bg-yellow-100 text-yellow-800', APPROVED: 'bg-green-100 text-green-800', PROCESSED: 'bg-blue-100 text-blue-800' };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><Heart className="h-4 w-4" />Life Events (FR-BEN-007)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Record Event</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Event Type</TableHead>
                <TableHead className="whitespace-nowrap">Event Date</TableHead>
                <TableHead className="whitespace-nowrap">Notes</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6 text-sm">No life events recorded</TableCell></TableRow>}
                {rows.map((r, i) => (
                  <TableRow key={r.event_id || i}>
                    <TableCell className="whitespace-nowrap text-xs">{String(r.employee_id).slice(0, 8)}…</TableCell>
                    <TableCell><Badge variant="outline">{r.event_type.replace(/_/g, ' ')}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap">{r.event_date || '—'}</TableCell>
                    <TableCell className="max-w-[200px] truncate text-sm">{r.notes || '—'}</TableCell>
                    <TableCell><Badge className={STATUS_BADGE[r.status || 'PENDING_REVIEW'] || 'bg-muted'}>{r.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Record Life Event</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Employee ID *</Label><Input value={form.employee_id} onChange={e => setForm(p => ({ ...p, employee_id: e.target.value }))} placeholder="UUID" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Event Type</Label>
                <Select value={form.event_type} onValueChange={v => setForm(p => ({ ...p, event_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{EVENT_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace(/_/g, ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Event Date</Label><Input type="date" value={form.event_date} onChange={e => setForm(p => ({ ...p, event_date: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Notes</Label><Textarea rows={2} value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-BEN-008/009 – Benefit Cost Tracking
   ───────────────────────────────────────────────────────────────────────── */
function BenefitCostTab() {
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ plan_name: '', period: '', employer_cost: '', employee_cost: '', total_enrolled: '', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('benefit_cost_tracking').select('*').order('period', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.plan_name) { toast.error('Plan name required'); return; }
    setSaving(true);
    const { error } = await sb.from('benefit_cost_tracking').insert({ plan_name: form.plan_name, period: form.period || null, employer_cost: form.employer_cost ? Number(form.employer_cost) : null, employee_cost: form.employee_cost ? Number(form.employee_cost) : null, total_enrolled: form.total_enrolled ? Number(form.total_enrolled) : null, notes: form.notes || null });
    if (error) toast.error(error.message); else { toast.success('Cost entry saved'); setOpen(false); load(); }
    setSaving(false);
  };

  const totalEmployer = rows.reduce((s, r) => s + (Number(r.employer_cost) || 0), 0);
  const totalEmployee = rows.reduce((s, r) => s + (Number(r.employee_cost) || 0), 0);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-base flex items-center gap-2"><DollarSign className="h-4 w-4" />Benefit Cost Tracking (FR-BEN-008/009)</CardTitle>
            <div className="flex gap-4 mt-2 text-sm">
              <span className="text-muted-foreground">Employer Total: <strong className="text-foreground">{totalEmployer.toLocaleString()} ETB</strong></span>
              <span className="text-muted-foreground">Employee Total: <strong className="text-foreground">{totalEmployee.toLocaleString()} ETB</strong></span>
            </div>
          </div>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add Entry</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Plan</TableHead>
                <TableHead className="whitespace-nowrap">Period</TableHead>
                <TableHead className="whitespace-nowrap">Enrolled</TableHead>
                <TableHead className="whitespace-nowrap">Employer Cost</TableHead>
                <TableHead className="whitespace-nowrap">Employee Cost</TableHead>
                <TableHead className="whitespace-nowrap">Total</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-6 text-sm">No cost entries yet</TableCell></TableRow>}
                {rows.map((r, i) => (
                  <TableRow key={String(r.cost_id || i)}>
                    <TableCell className="whitespace-nowrap font-medium">{String(r.plan_name || '—')}</TableCell>
                    <TableCell className="whitespace-nowrap">{String(r.period || '—')}</TableCell>
                    <TableCell className="whitespace-nowrap">{String(r.total_enrolled || '—')}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.employer_cost ? Number(r.employer_cost).toLocaleString() : '—'} ETB</TableCell>
                    <TableCell className="whitespace-nowrap">{r.employee_cost ? Number(r.employee_cost).toLocaleString() : '—'} ETB</TableCell>
                    <TableCell className="whitespace-nowrap font-semibold">{(Number(r.employer_cost || 0) + Number(r.employee_cost || 0)).toLocaleString()} ETB</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add Cost Entry</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-2">
            <div className="col-span-2 space-y-1.5"><Label>Plan Name *</Label><Input value={form.plan_name} onChange={e => setForm(p => ({ ...p, plan_name: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Period (e.g. 2025-01)</Label><Input value={form.period} onChange={e => setForm(p => ({ ...p, period: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Total Enrolled</Label><Input type="number" value={form.total_enrolled} onChange={e => setForm(p => ({ ...p, total_enrolled: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Employer Cost (ETB)</Label><Input type="number" value={form.employer_cost} onChange={e => setForm(p => ({ ...p, employer_cost: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Employee Cost (ETB)</Label><Input type="number" value={form.employee_cost} onChange={e => setForm(p => ({ ...p, employee_cost: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-BEN-010 – Carrier Billing Reconciliation
   ───────────────────────────────────────────────────────────────────────── */
function CarrierBillingTab() {
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ carrier_name: '', plan_name: '', billing_period: '', billed_amount: '', expected_amount: '', variance: '', status: 'PENDING' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('carrier_billing').select('*').order('billing_period', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const billed = Number(form.billed_amount) || 0;
  const expected = Number(form.expected_amount) || 0;
  const variance = billed - expected;

  const save = async () => {
    if (!form.carrier_name) { toast.error('Carrier name required'); return; }
    setSaving(true);
    const { error } = await sb.from('carrier_billing').insert({ carrier_name: form.carrier_name, plan_name: form.plan_name || null, billing_period: form.billing_period || null, billed_amount: billed || null, expected_amount: expected || null, variance: variance || null, status: form.status });
    if (error) toast.error(error.message); else { toast.success('Billing record saved'); setOpen(false); load(); }
    setSaving(false);
  };

  const STATUS_BADGE: Record<string, string> = { PENDING: 'bg-yellow-100 text-yellow-800', RECONCILED: 'bg-green-100 text-green-800', DISPUTED: 'bg-red-100 text-red-800' };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><Building2 className="h-4 w-4" />Carrier Billing Reconciliation (FR-BEN-010)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add Record</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Carrier</TableHead>
                <TableHead className="whitespace-nowrap">Plan</TableHead>
                <TableHead className="whitespace-nowrap">Period</TableHead>
                <TableHead className="whitespace-nowrap">Billed</TableHead>
                <TableHead className="whitespace-nowrap">Expected</TableHead>
                <TableHead className="whitespace-nowrap">Variance</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-6 text-sm">No billing records</TableCell></TableRow>}
                {rows.map((r, i) => {
                  const v = Number(r.variance || 0);
                  return (
                    <TableRow key={String(r.billing_id || i)}>
                      <TableCell className="whitespace-nowrap font-medium">{String(r.carrier_name)}</TableCell>
                      <TableCell className="whitespace-nowrap">{String(r.plan_name || '—')}</TableCell>
                      <TableCell className="whitespace-nowrap">{String(r.billing_period || '—')}</TableCell>
                      <TableCell className="whitespace-nowrap">{r.billed_amount ? Number(r.billed_amount).toLocaleString() : '—'} ETB</TableCell>
                      <TableCell className="whitespace-nowrap">{r.expected_amount ? Number(r.expected_amount).toLocaleString() : '—'} ETB</TableCell>
                      <TableCell className={`whitespace-nowrap font-medium ${v > 0 ? 'text-destructive' : v < 0 ? 'text-green-700' : 'text-muted-foreground'}`}>
                        {v !== 0 ? `${v > 0 ? '+' : ''}${v.toLocaleString()} ETB` : '—'}
                      </TableCell>
                      <TableCell><Badge className={STATUS_BADGE[String(r.status)] || 'bg-muted'}>{String(r.status)}</Badge></TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add Carrier Billing Record</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-2">
            <div className="col-span-2 space-y-1.5"><Label>Carrier Name *</Label><Input value={form.carrier_name} onChange={e => setForm(p => ({ ...p, carrier_name: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Plan Name</Label><Input value={form.plan_name} onChange={e => setForm(p => ({ ...p, plan_name: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Billing Period</Label><Input placeholder="e.g. 2025-01" value={form.billing_period} onChange={e => setForm(p => ({ ...p, billing_period: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Billed Amount</Label><Input type="number" value={form.billed_amount} onChange={e => setForm(p => ({ ...p, billed_amount: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Expected Amount</Label><Input type="number" value={form.expected_amount} onChange={e => setForm(p => ({ ...p, expected_amount: e.target.value }))} /></div>
            {(billed > 0 || expected > 0) && (
              <div className="col-span-2 rounded-lg bg-muted/50 px-3 py-2 text-sm">
                Variance: <strong className={variance > 0 ? 'text-destructive' : variance < 0 ? 'text-green-700' : ''}>{variance > 0 ? '+' : ''}{variance.toLocaleString()} ETB</strong>
              </div>
            )}
            <div className="col-span-2 space-y-1.5"><Label>Status</Label>
              <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="PENDING">Pending</SelectItem>
                  <SelectItem value="RECONCILED">Reconciled</SelectItem>
                  <SelectItem value="DISPUTED">Disputed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
