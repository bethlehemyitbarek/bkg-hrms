/**
 * Compensation Hub — wraps all compensation-related modules in one tabbed view
 * FR-Comp-06 Salary Bands, FR-Comp-15/16 Framework/Grade,
 * FR-Comp-20 Merit Cycle, FR-Comp-21 Bonus Cycle,
 * FR-Comp-22 Variable Pay, FR-Comp-23 Budget Pool, FR-Comp-27 Pay Equity
 */
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { CompensationStructurePage } from './CompensationStructurePage';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import {
  LayoutList, TrendingUp, Award, BarChart3, Wallet, PiggyBank,
  Scale, Plus, RefreshCw, Loader2,
  GitCompareArrows, SlidersHorizontal, DollarSign, Grid3x3, ClipboardCheck,
} from 'lucide-react';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = _sb as any;

/* ─────────────────────────────────────────────────────────────────────────── */
export function CompensationHubPage() {
  return (
    <div className="p-4 md:p-6 space-y-4">
      <div>
        <h1 className="text-xl md:text-2xl font-semibold text-balance">Compensation Management</h1>
        <p className="text-sm text-muted-foreground text-pretty">
          Salary structures, bands, merit & bonus cycles, variable pay, budget pools, and pay equity
        </p>
      </div>

      <Tabs defaultValue="structures">
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="structures" className="gap-1.5 text-xs md:text-sm">
            <LayoutList className="h-3.5 w-3.5" />Structures
          </TabsTrigger>
          <TabsTrigger value="salary-bands" className="gap-1.5 text-xs md:text-sm">
            <TrendingUp className="h-3.5 w-3.5" />Salary Bands
          </TabsTrigger>
          <TabsTrigger value="merit" className="gap-1.5 text-xs md:text-sm">
            <Award className="h-3.5 w-3.5" />Merit Cycle
          </TabsTrigger>
          <TabsTrigger value="bonus" className="gap-1.5 text-xs md:text-sm">
            <BarChart3 className="h-3.5 w-3.5" />Bonus Cycle
          </TabsTrigger>
          <TabsTrigger value="variable-pay" className="gap-1.5 text-xs md:text-sm">
            <Wallet className="h-3.5 w-3.5" />Variable Pay
          </TabsTrigger>
          <TabsTrigger value="budget-pool" className="gap-1.5 text-xs md:text-sm">
            <PiggyBank className="h-3.5 w-3.5" />Budget Pool
          </TabsTrigger>
          <TabsTrigger value="pay-equity" className="gap-1.5 text-xs md:text-sm">
            <Scale className="h-3.5 w-3.5" />Pay Equity
          </TabsTrigger>
          <TabsTrigger value="comp-ratio" className="gap-1.5 text-xs md:text-sm">
            <GitCompareArrows className="h-3.5 w-3.5" />Comp Ratio
          </TabsTrigger>
          <TabsTrigger value="range-penetration" className="gap-1.5 text-xs md:text-sm">
            <SlidersHorizontal className="h-3.5 w-3.5" />Range Penetration
          </TabsTrigger>
          <TabsTrigger value="rt-budget" className="gap-1.5 text-xs md:text-sm">
            <DollarSign className="h-3.5 w-3.5" />RT Budget
          </TabsTrigger>
          <TabsTrigger value="merit-matrix" className="gap-1.5 text-xs md:text-sm">
            <Grid3x3 className="h-3.5 w-3.5" />Merit Matrix
          </TabsTrigger>
          <TabsTrigger value="exception-approval" className="gap-1.5 text-xs md:text-sm">
            <ClipboardCheck className="h-3.5 w-3.5" />Exception Approval
          </TabsTrigger>
        </TabsList>

        <TabsContent value="structures" className="mt-4">
          {/* Re-use existing compensation structure page content */}
          <CompensationStructurePage />
        </TabsContent>

        <TabsContent value="salary-bands" className="mt-4">
          <SalaryBandTab />
        </TabsContent>

        <TabsContent value="merit" className="mt-4">
          <MeritCycleTab />
        </TabsContent>

        <TabsContent value="bonus" className="mt-4">
          <BonusCycleTab />
        </TabsContent>

        <TabsContent value="variable-pay" className="mt-4">
          <VariablePayTab />
        </TabsContent>

        <TabsContent value="budget-pool" className="mt-4">
          <BudgetPoolTab />
        </TabsContent>

        <TabsContent value="pay-equity" className="mt-4">
          <PayEquityTab />
        </TabsContent>
        <TabsContent value="comp-ratio" className="mt-4">
          <CompRatioTab />
        </TabsContent>
        <TabsContent value="range-penetration" className="mt-4">
          <RangePenetrationTab />
        </TabsContent>
        <TabsContent value="rt-budget" className="mt-4">
          <RealTimeBudgetTab />
        </TabsContent>
        <TabsContent value="merit-matrix" className="mt-4">
          <MeritMatrixTab />
        </TabsContent>
        <TabsContent value="exception-approval" className="mt-4">
          <ExceptionApprovalTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-Comp-06 / FR-Comp-15 / FR-Comp-16: Salary Bands & Grade/Pay Bands
   ═══════════════════════════════════════════════════════════════════════════ */
function SalaryBandTab() {
  const [bands, setBands]     = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [form, setForm]       = useState({
    band_code: '', band_name: '', job_grade: '', job_level: '',
    currency: 'ETB', min_salary: '', mid_salary: '', max_salary: '',
    effective_date: '', description: '',
  });

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await sb.from('salary_bands')
      .select('id, band_code, band_name, job_grade, job_level, currency, min_salary, mid_salary, max_salary, effective_date, is_active')
      .order('band_code', { ascending: true })
      .limit(100);
    if (!error) setBands(Array.isArray(data) ? data : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.band_code || !form.band_name || !form.min_salary || !form.max_salary) {
      toast.error('Code, Name, Min and Max Salary are required'); return;
    }
    setSaving(true);
    const { error } = await sb.from('salary_bands').insert({
      band_code: form.band_code, band_name: form.band_name,
      job_grade: form.job_grade || null, job_level: form.job_level || null,
      currency: form.currency || 'ETB',
      min_salary: parseFloat(form.min_salary),
      mid_salary: form.mid_salary ? parseFloat(form.mid_salary) : null,
      max_salary: parseFloat(form.max_salary),
      effective_date: form.effective_date || null,
      description: form.description || null,
      is_active: true,
    });
    if (error) { toast.error(error.message); setSaving(false); return; }
    toast.success('Salary band added');
    setOpen(false);
    setForm({ band_code: '', band_name: '', job_grade: '', job_level: '', currency: 'ETB', min_salary: '', mid_salary: '', max_salary: '', effective_date: '', description: '' });
    load();
    setSaving(false);
  };

  const fmt = (v: unknown) => v != null ? `$${Number(v).toLocaleString()}` : '—';

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm flex items-center gap-2"><TrendingUp className="h-4 w-4" />Salary Bands (FR-Comp-06/15/16)</CardTitle>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="h-8" onClick={load} disabled={loading}>
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          </Button>
          <Button size="sm" className="h-8" onClick={() => setOpen(true)}>
            <Plus className="h-3.5 w-3.5 mr-1" />Add Band
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 bg-muted" />)}</div>
        ) : bands.length === 0 ? (
          <div className="py-10 text-center text-muted-foreground text-sm"><TrendingUp className="h-8 w-8 mx-auto mb-2 opacity-30" />No salary bands defined</div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Code</TableHead>
                  <TableHead className="whitespace-nowrap">Band Name</TableHead>
                  <TableHead className="whitespace-nowrap">Grade</TableHead>
                  <TableHead className="whitespace-nowrap">Level</TableHead>
                  <TableHead className="whitespace-nowrap">Min</TableHead>
                  <TableHead className="whitespace-nowrap">Mid</TableHead>
                  <TableHead className="whitespace-nowrap">Max</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bands.map(b => (
                  <TableRow key={b.id as string}>
                    <TableCell className="whitespace-nowrap text-sm font-medium">{b.band_code as string}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{b.band_name as string}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{b.job_grade as string || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{b.job_level as string || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmt(b.min_salary)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{fmt(b.mid_salary)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmt(b.max_salary)}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${b.is_active ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-500'}`}>
                        {b.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add Salary Band</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              {[{ k: 'band_code', l: 'Band Code *' }, { k: 'band_name', l: 'Band Name *' }].map(({ k, l }) => (
                <div key={k}><Label className="text-sm font-normal">{l}</Label>
                  <Input className="mt-1" value={form[k as keyof typeof form]} onChange={e => setForm(p => ({ ...p, [k]: e.target.value }))} />
                </div>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[{ k: 'job_grade', l: 'Job Grade' }, { k: 'job_level', l: 'Job Level' }].map(({ k, l }) => (
                <div key={k}><Label className="text-sm font-normal">{l}</Label>
                  <Input className="mt-1" value={form[k as keyof typeof form]} onChange={e => setForm(p => ({ ...p, [k]: e.target.value }))} />
                </div>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[{ k: 'min_salary', l: 'Min Salary *' }, { k: 'mid_salary', l: 'Mid Salary' }, { k: 'max_salary', l: 'Max Salary *' }].map(({ k, l }) => (
                <div key={k}><Label className="text-sm font-normal">{l}</Label>
                  <Input type="number" className="mt-1" value={form[k as keyof typeof form]} onChange={e => setForm(p => ({ ...p, [k]: e.target.value }))} />
                </div>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-sm font-normal">Currency</Label>
                <Select value={form.currency} onValueChange={v => setForm(p => ({ ...p, currency: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>{['ETB', 'USD', 'EUR', 'GBP', 'AED', 'SAR'].map(c => <SelectItem key={c} value={c}>{c === 'ETB' ? 'ETB — ብር' : c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label className="text-sm font-normal">Effective Date</Label>
                <Input type="date" className="mt-1" value={form.effective_date} onChange={e => setForm(p => ({ ...p, effective_date: e.target.value }))} />
              </div>
            </div>
            <Button className="w-full" onClick={save} disabled={saving}>
              {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Saving…</> : 'Add Salary Band'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-Comp-20: Merit Cycle
   ═══════════════════════════════════════════════════════════════════════════ */
function MeritCycleTab() {
  const [cycles, setCycles]   = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [form, setForm]       = useState({
    cycle_name: '', cycle_year: String(new Date().getFullYear()),
    start_date: '', end_date: '', budget_percentage: '', status: 'DRAFT',
    description: '',
  });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('merit_cycles')
      .select('id, cycle_name, cycle_year, start_date, end_date, budget_percentage, status, created_at')
      .order('cycle_year', { ascending: false }).limit(30);
    setCycles(Array.isArray(data) ? data : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.cycle_name || !form.cycle_year) { toast.error('Cycle name and year required'); return; }
    setSaving(true);
    const { error } = await sb.from('merit_cycles').insert({
      cycle_name: form.cycle_name, cycle_year: parseInt(form.cycle_year),
      start_date: form.start_date || null, end_date: form.end_date || null,
      budget_percentage: form.budget_percentage ? parseFloat(form.budget_percentage) : null,
      status: form.status, description: form.description || null,
    });
    if (error) { toast.error(error.message); setSaving(false); return; }
    toast.success('Merit cycle created'); setOpen(false);
    setForm({ cycle_name: '', cycle_year: String(new Date().getFullYear()), start_date: '', end_date: '', budget_percentage: '', status: 'DRAFT', description: '' });
    load(); setSaving(false);
  };

  const STATUS_CLR: Record<string, string> = { DRAFT: 'bg-slate-100 text-slate-700', ACTIVE: 'bg-emerald-100 text-emerald-800', CLOSED: 'bg-gray-100 text-gray-500' };

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm flex items-center gap-2"><Award className="h-4 w-4" />Merit Cycles (FR-Comp-20)</CardTitle>
        <Button size="sm" className="h-8" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />New Cycle</Button>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : cycles.length === 0 ? (
          <div className="py-10 text-center text-muted-foreground text-sm"><Award className="h-8 w-8 mx-auto mb-2 opacity-30" />No merit cycles defined</div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Cycle Name</TableHead>
                <TableHead className="whitespace-nowrap">Year</TableHead>
                <TableHead className="whitespace-nowrap">Start</TableHead>
                <TableHead className="whitespace-nowrap">End</TableHead>
                <TableHead className="whitespace-nowrap">Budget %</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {cycles.map(c => (
                  <TableRow key={c.id as string}>
                    <TableCell className="whitespace-nowrap text-sm font-medium">{c.cycle_name as string}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{c.cycle_year as string}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{c.start_date ? new Date(c.start_date as string).toLocaleDateString() : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{c.end_date ? new Date(c.end_date as string).toLocaleDateString() : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{c.budget_percentage != null ? `${c.budget_percentage}%` : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={`text-xs ${STATUS_CLR[c.status as string] || ''}`}>{c.status as string}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Create Merit Cycle</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div><Label className="text-sm font-normal">Cycle Name *</Label><Input className="mt-1" value={form.cycle_name} onChange={e => setForm(p => ({ ...p, cycle_name: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-sm font-normal">Year *</Label><Input className="mt-1" value={form.cycle_year} onChange={e => setForm(p => ({ ...p, cycle_year: e.target.value }))} /></div>
              <div><Label className="text-sm font-normal">Budget %</Label><Input type="number" className="mt-1" value={form.budget_percentage} onChange={e => setForm(p => ({ ...p, budget_percentage: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-sm font-normal">Start Date</Label><Input type="date" className="mt-1" value={form.start_date} onChange={e => setForm(p => ({ ...p, start_date: e.target.value }))} /></div>
              <div><Label className="text-sm font-normal">End Date</Label><Input type="date" className="mt-1" value={form.end_date} onChange={e => setForm(p => ({ ...p, end_date: e.target.value }))} /></div>
            </div>
            <div><Label className="text-sm font-normal">Status</Label>
              <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{['DRAFT', 'ACTIVE', 'CLOSED'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <Button className="w-full" onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Create Merit Cycle'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-Comp-21: Bonus Cycle
   ═══════════════════════════════════════════════════════════════════════════ */
function BonusCycleTab() {
  const [cycles, setCycles]   = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [form, setForm]       = useState({
    cycle_name: '', cycle_year: String(new Date().getFullYear()),
    bonus_type: 'ANNUAL', start_date: '', end_date: '',
    target_percentage: '', status: 'DRAFT',
  });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('bonus_cycles')
      .select('id, cycle_name, cycle_year, bonus_type, target_percentage, start_date, end_date, status')
      .order('cycle_year', { ascending: false }).limit(30);
    setCycles(Array.isArray(data) ? data : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.cycle_name) { toast.error('Cycle name required'); return; }
    setSaving(true);
    const { error } = await sb.from('bonus_cycles').insert({
      cycle_name: form.cycle_name, cycle_year: parseInt(form.cycle_year),
      bonus_type: form.bonus_type, status: form.status,
      start_date: form.start_date || null, end_date: form.end_date || null,
      target_percentage: form.target_percentage ? parseFloat(form.target_percentage) : null,
    });
    if (error) { toast.error(error.message); setSaving(false); return; }
    toast.success('Bonus cycle created'); setOpen(false);
    setForm({ cycle_name: '', cycle_year: String(new Date().getFullYear()), bonus_type: 'ANNUAL', start_date: '', end_date: '', target_percentage: '', status: 'DRAFT' });
    load(); setSaving(false);
  };

  const STATUS_CLR: Record<string, string> = { DRAFT: 'bg-slate-100 text-slate-700', ACTIVE: 'bg-emerald-100 text-emerald-800', CLOSED: 'bg-gray-100 text-gray-500' };
  const TYPE_CLR:   Record<string, string> = { ANNUAL: 'bg-indigo-100 text-indigo-800', QUARTERLY: 'bg-amber-100 text-amber-800', SPOT: 'bg-purple-100 text-purple-800', PROJECT: 'bg-teal-100 text-teal-800' };

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm flex items-center gap-2"><BarChart3 className="h-4 w-4" />Bonus Cycles (FR-Comp-21)</CardTitle>
        <Button size="sm" className="h-8" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />New Cycle</Button>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : cycles.length === 0 ? (
          <div className="py-10 text-center text-muted-foreground text-sm"><BarChart3 className="h-8 w-8 mx-auto mb-2 opacity-30" />No bonus cycles defined</div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Cycle Name</TableHead>
                <TableHead className="whitespace-nowrap">Year</TableHead>
                <TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">Target %</TableHead>
                <TableHead className="whitespace-nowrap">Start</TableHead>
                <TableHead className="whitespace-nowrap">End</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {cycles.map(c => (
                  <TableRow key={c.id as string}>
                    <TableCell className="whitespace-nowrap text-sm font-medium">{c.cycle_name as string}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{c.cycle_year as string}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={`text-xs ${TYPE_CLR[c.bonus_type as string] || ''}`}>{c.bonus_type as string}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{c.target_percentage != null ? `${c.target_percentage}%` : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{c.start_date ? new Date(c.start_date as string).toLocaleDateString() : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{c.end_date ? new Date(c.end_date as string).toLocaleDateString() : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={`text-xs ${STATUS_CLR[c.status as string] || ''}`}>{c.status as string}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Create Bonus Cycle</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div><Label className="text-sm font-normal">Cycle Name *</Label><Input className="mt-1" value={form.cycle_name} onChange={e => setForm(p => ({ ...p, cycle_name: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-sm font-normal">Year</Label><Input className="mt-1" value={form.cycle_year} onChange={e => setForm(p => ({ ...p, cycle_year: e.target.value }))} /></div>
              <div><Label className="text-sm font-normal">Bonus Type</Label>
                <Select value={form.bonus_type} onValueChange={v => setForm(p => ({ ...p, bonus_type: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>{['ANNUAL', 'QUARTERLY', 'SPOT', 'PROJECT', 'RETENTION'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div><Label className="text-sm font-normal">Target % of Salary</Label><Input type="number" className="mt-1" value={form.target_percentage} onChange={e => setForm(p => ({ ...p, target_percentage: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-sm font-normal">Start Date</Label><Input type="date" className="mt-1" value={form.start_date} onChange={e => setForm(p => ({ ...p, start_date: e.target.value }))} /></div>
              <div><Label className="text-sm font-normal">End Date</Label><Input type="date" className="mt-1" value={form.end_date} onChange={e => setForm(p => ({ ...p, end_date: e.target.value }))} /></div>
            </div>
            <Button className="w-full" onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Create Bonus Cycle'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-Comp-22: Variable Pay Plans
   ═══════════════════════════════════════════════════════════════════════════ */
function VariablePayTab() {
  const [plans, setPlans]     = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [form, setForm]       = useState({
    plan_name: '', plan_type: 'COMMISSION', target_percentage: '',
    max_percentage: '', calculation_basis: 'BASE_SALARY', description: '',
  });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('variable_pay_plans')
      .select('id, plan_name, plan_type, target_percentage, max_percentage, calculation_basis, is_active, created_at')
      .order('plan_name', { ascending: true }).limit(50);
    setPlans(Array.isArray(data) ? data : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.plan_name || !form.plan_type) { toast.error('Plan name and type required'); return; }
    setSaving(true);
    const { error } = await sb.from('variable_pay_plans').insert({
      plan_name: form.plan_name, plan_type: form.plan_type,
      target_percentage: form.target_percentage ? parseFloat(form.target_percentage) : null,
      max_percentage: form.max_percentage ? parseFloat(form.max_percentage) : null,
      calculation_basis: form.calculation_basis, description: form.description || null,
      is_active: true,
    });
    if (error) { toast.error(error.message); setSaving(false); return; }
    toast.success('Variable pay plan created'); setOpen(false);
    setForm({ plan_name: '', plan_type: 'COMMISSION', target_percentage: '', max_percentage: '', calculation_basis: 'BASE_SALARY', description: '' });
    load(); setSaving(false);
  };

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm flex items-center gap-2"><Wallet className="h-4 w-4" />Variable Pay Plans (FR-Comp-22)</CardTitle>
        <Button size="sm" className="h-8" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add Plan</Button>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : plans.length === 0 ? (
          <div className="py-10 text-center text-muted-foreground text-sm"><Wallet className="h-8 w-8 mx-auto mb-2 opacity-30" />No variable pay plans defined</div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Plan Name</TableHead>
                <TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">Basis</TableHead>
                <TableHead className="whitespace-nowrap">Target %</TableHead>
                <TableHead className="whitespace-nowrap">Max %</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {plans.map(p => (
                  <TableRow key={p.id as string}>
                    <TableCell className="whitespace-nowrap text-sm font-medium">{p.plan_name as string}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{p.plan_type as string}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{p.calculation_basis as string}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{p.target_percentage != null ? `${p.target_percentage}%` : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{p.max_percentage != null ? `${p.max_percentage}%` : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={`text-xs ${p.is_active ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-500'}`}>{p.is_active ? 'Active' : 'Inactive'}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Add Variable Pay Plan</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div><Label className="text-sm font-normal">Plan Name *</Label><Input className="mt-1" value={form.plan_name} onChange={e => setForm(p => ({ ...p, plan_name: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-sm font-normal">Plan Type *</Label>
                <Select value={form.plan_type} onValueChange={v => setForm(p => ({ ...p, plan_type: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>{['COMMISSION', 'INCENTIVE', 'PROFIT_SHARE', 'GAIN_SHARE', 'OVERTIME_BONUS'].map(t => <SelectItem key={t} value={t}>{t.replace('_', ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label className="text-sm font-normal">Basis</Label>
                <Select value={form.calculation_basis} onValueChange={v => setForm(p => ({ ...p, calculation_basis: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>{['BASE_SALARY', 'GROSS_SALARY', 'REVENUE', 'PROFIT'].map(b => <SelectItem key={b} value={b}>{b.replace('_', ' ')}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-sm font-normal">Target %</Label><Input type="number" className="mt-1" value={form.target_percentage} onChange={e => setForm(p => ({ ...p, target_percentage: e.target.value }))} /></div>
              <div><Label className="text-sm font-normal">Max %</Label><Input type="number" className="mt-1" value={form.max_percentage} onChange={e => setForm(p => ({ ...p, max_percentage: e.target.value }))} /></div>
            </div>
            <div><Label className="text-sm font-normal">Description</Label><Textarea className="mt-1" rows={2} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></div>
            <Button className="w-full" onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Add Plan'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-Comp-23: Budget Pool
   ═══════════════════════════════════════════════════════════════════════════ */
function BudgetPoolTab() {
  const [pools, setPools]     = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [form, setForm]       = useState({
    pool_name: '', pool_type: 'MERIT', fiscal_year: String(new Date().getFullYear()),
    total_budget: '', currency: 'ETB', allocated: '', status: 'DRAFT',
  });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('compensation_budget_pools')
      .select('id, pool_name, pool_type, fiscal_year, total_budget, allocated_amount, remaining_amount, currency, status')
      .order('fiscal_year', { ascending: false }).limit(50);
    setPools(Array.isArray(data) ? data : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.pool_name || !form.total_budget) { toast.error('Pool name and total budget required'); return; }
    setSaving(true);
    const total = parseFloat(form.total_budget);
    const alloc = form.allocated ? parseFloat(form.allocated) : 0;
    const { error } = await sb.from('compensation_budget_pools').insert({
      pool_name: form.pool_name, pool_type: form.pool_type,
      fiscal_year: parseInt(form.fiscal_year), currency: form.currency,
      total_budget: total, allocated_amount: alloc, remaining_amount: total - alloc,
      status: form.status,
    });
    if (error) { toast.error(error.message); setSaving(false); return; }
    toast.success('Budget pool created'); setOpen(false);
    setForm({ pool_name: '', pool_type: 'MERIT', fiscal_year: String(new Date().getFullYear()), total_budget: '', currency: 'ETB', allocated: '', status: 'DRAFT' });
    load(); setSaving(false);
  };

  const fmtCur = (v: unknown, c: unknown) => v != null ? `${c === 'ETB' ? 'ብር' : (c || 'ብር')} ${Number(v).toLocaleString()}` : '—';
  const pct = (a: unknown, t: unknown) => t ? `${Math.round((Number(a) / Number(t)) * 100)}%` : '—';
  const STATUS_CLR: Record<string, string> = { DRAFT: 'bg-slate-100 text-slate-700', ACTIVE: 'bg-emerald-100 text-emerald-800', CLOSED: 'bg-gray-100 text-gray-500' };

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm flex items-center gap-2"><PiggyBank className="h-4 w-4" />Compensation Budget Pools (FR-Comp-23)</CardTitle>
        <Button size="sm" className="h-8" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add Pool</Button>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : pools.length === 0 ? (
          <div className="py-10 text-center text-muted-foreground text-sm"><PiggyBank className="h-8 w-8 mx-auto mb-2 opacity-30" />No budget pools defined</div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Pool Name</TableHead>
                <TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">FY</TableHead>
                <TableHead className="whitespace-nowrap">Total Budget</TableHead>
                <TableHead className="whitespace-nowrap">Allocated</TableHead>
                <TableHead className="whitespace-nowrap">Remaining</TableHead>
                <TableHead className="whitespace-nowrap">Utilization</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {pools.map(p => (
                  <TableRow key={p.id as string}>
                    <TableCell className="whitespace-nowrap text-sm font-medium">{p.pool_name as string}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{p.pool_type as string}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{p.fiscal_year as string}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtCur(p.total_budget, p.currency)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtCur(p.allocated_amount, p.currency)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtCur(p.remaining_amount, p.currency)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">
                      <div className="flex items-center gap-1.5">
                        <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: `${Math.min(100, Math.round((Number(p.allocated_amount || 0) / Number(p.total_budget || 1)) * 100))}%` }} />
                        </div>
                        <span className="text-xs text-muted-foreground">{pct(p.allocated_amount, p.total_budget)}</span>
                      </div>
                    </TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={`text-xs ${STATUS_CLR[p.status as string] || ''}`}>{p.status as string}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Create Budget Pool</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div><Label className="text-sm font-normal">Pool Name *</Label><Input className="mt-1" value={form.pool_name} onChange={e => setForm(p => ({ ...p, pool_name: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-sm font-normal">Pool Type</Label>
                <Select value={form.pool_type} onValueChange={v => setForm(p => ({ ...p, pool_type: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>{['MERIT', 'BONUS', 'VARIABLE', 'EQUITY', 'ALLOWANCE'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label className="text-sm font-normal">Fiscal Year</Label><Input className="mt-1" value={form.fiscal_year} onChange={e => setForm(p => ({ ...p, fiscal_year: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-sm font-normal">Total Budget *</Label><Input type="number" className="mt-1" value={form.total_budget} onChange={e => setForm(p => ({ ...p, total_budget: e.target.value }))} /></div>
              <div><Label className="text-sm font-normal">Currency</Label>
                <Select value={form.currency} onValueChange={v => setForm(p => ({ ...p, currency: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>{['ETB', 'USD', 'EUR', 'GBP', 'AED', 'SAR'].map(c => <SelectItem key={c} value={c}>{c === 'ETB' ? 'ETB — ብር' : c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <Button className="w-full" onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Create Budget Pool'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-Comp-27: Pay Equity Analysis
   ═══════════════════════════════════════════════════════════════════════════ */
function PayEquityTab() {
  const [analysis, setAnalysis] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading]   = useState(false);
  const [runOpen, setRunOpen]   = useState(false);
  const [running, setRunning]   = useState(false);
  const [groupBy, setGroupBy]   = useState<'gender' | 'department' | 'job_grade'>('gender');

  const run = useCallback(async () => {
    setLoading(true);
    try {
      // Aggregate pay data from employees + salary_history grouped by selected dimension
      const { data } = await sb.from('employee_salaries')
        .select(`id, base_salary, currency, effective_date,
          employee:employees!employee_salaries_employee_id_fkey(id, gender, department_id, job_grade, departments(name))`)
        .is('end_date', null).limit(500);

      const rows = (Array.isArray(data) ? data : []) as Record<string, unknown>[];

      // Build aggregation map
      const groupMap: Record<string, { count: number; total: number; min: number; max: number }> = {};
      rows.forEach(r => {
        const emp = r.employee as Record<string, unknown> | null;
        if (!emp) return;
        let key = '—';
        if (groupBy === 'gender')     key = (emp.gender as string) || 'Unknown';
        if (groupBy === 'department') key = (emp.departments as Record<string, unknown>)?.name as string || 'Unknown';
        if (groupBy === 'job_grade')  key = (emp.job_grade as string) || 'Unknown';
        const amt = Number(r.base_salary || 0);
        if (!groupMap[key]) groupMap[key] = { count: 0, total: 0, min: Infinity, max: -Infinity };
        groupMap[key].count++;
        groupMap[key].total += amt;
        groupMap[key].min = Math.min(groupMap[key].min, amt);
        groupMap[key].max = Math.max(groupMap[key].max, amt);
      });

      const result = Object.entries(groupMap).map(([group, v]) => ({
        group, count: v.count,
        avg: v.count > 0 ? Math.round(v.total / v.count) : 0,
        min: v.min === Infinity ? 0 : v.min,
        max: v.max === -Infinity ? 0 : v.max,
        total: v.total,
      })).sort((a, b) => b.avg - a.avg);

      setAnalysis(result as Record<string, unknown>[]);
    } catch { toast.error('Failed to run pay equity analysis'); }
    finally { setLoading(false); }
  }, [groupBy]);

  const saveSnapshot = async () => {
    setRunning(true);
    try {
      await sb.from('pay_equity_snapshots').insert({
        snapshot_date: new Date().toISOString().split('T')[0],
        department: groupBy === 'department' ? 'snapshot' : null,
        job_grade: groupBy === 'job_grade' ? 'snapshot' : null,
        gender: groupBy === 'gender' ? 'snapshot' : null,
        avg_salary: analysis.length > 0 ? Number((analysis[0] as Record<string,unknown>).avg ?? 0) : null,
        headcount: analysis.reduce((s, a) => s + Number((a as Record<string,unknown>).count ?? 0), 0),
      });
      toast.success('Pay equity snapshot saved');
    } catch { toast.error('Failed to save snapshot'); }
    finally { setRunning(false); setRunOpen(false); }
  };

  const maxAvg = analysis.reduce((m, a) => Math.max(m, Number(a.avg || 0)), 1);
  const fmt = (v: unknown) => v != null ? `$${Number(v).toLocaleString()}` : '—';

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <CardTitle className="text-sm flex items-center gap-2"><Scale className="h-4 w-4" />Pay Equity Analysis (FR-Comp-27)</CardTitle>
          <div className="flex gap-2 items-center">
            <Select value={groupBy} onValueChange={v => setGroupBy(v as 'gender' | 'department' | 'job_grade')}>
              <SelectTrigger className="h-8 w-36 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="gender">By Gender</SelectItem>
                <SelectItem value="department">By Department</SelectItem>
                <SelectItem value="job_grade">By Job Grade</SelectItem>
              </SelectContent>
            </Select>
            <Button size="sm" className="h-8" onClick={run} disabled={loading}>
              {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : <RefreshCw className="h-3.5 w-3.5 mr-1" />}Run Analysis
            </Button>
            {analysis.length > 0 && (
              <Button size="sm" variant="outline" className="h-8" onClick={() => setRunOpen(true)}>Save Snapshot</Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 bg-muted" />)}</div>
        ) : analysis.length === 0 ? (
          <div className="py-10 text-center text-muted-foreground text-sm">
            <Scale className="h-8 w-8 mx-auto mb-2 opacity-30" />Click "Run Analysis" to compute pay equity across {groupBy.replace('_', ' ')}
          </div>
        ) : (
          <div className="space-y-3">
            {/* Bar chart visualization */}
            <div className="space-y-2">
              {analysis.map(a => (
                <div key={a.group as string} className="flex items-center gap-3">
                  <div className="w-28 text-xs font-medium truncate shrink-0">{a.group as string}</div>
                  <div className="flex-1 min-w-0">
                    <div className="h-5 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full flex items-center justify-end pr-2 transition-all"
                        style={{ width: `${Math.round((Number(a.avg) / maxAvg) * 100)}%` }}
                      >
                        <span className="text-xs text-primary-foreground font-medium whitespace-nowrap">{fmt(a.avg)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground shrink-0 w-14 text-right">{a.count as number} emps</div>
                </div>
              ))}
            </div>

            {/* Detail table */}
            <div className="overflow-x-auto mt-4">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">{groupBy.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</TableHead>
                  <TableHead className="whitespace-nowrap">Count</TableHead>
                  <TableHead className="whitespace-nowrap">Avg Salary</TableHead>
                  <TableHead className="whitespace-nowrap">Min</TableHead>
                  <TableHead className="whitespace-nowrap">Max</TableHead>
                  <TableHead className="whitespace-nowrap">Range</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {analysis.map(a => (
                    <TableRow key={a.group as string}>
                      <TableCell className="whitespace-nowrap text-sm font-medium">{a.group as string}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{a.count as number}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-semibold">{fmt(a.avg)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{fmt(a.min)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{fmt(a.max)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{fmt(Number(a.max) - Number(a.min))}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        )}
      </CardContent>

      <Dialog open={runOpen} onOpenChange={setRunOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle>Save Pay Equity Snapshot</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground py-2">Save the current pay equity analysis results as a dated snapshot for trend comparison.</p>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setRunOpen(false)}>Cancel</Button>
            <Button onClick={saveSnapshot} disabled={running}>{running ? 'Saving…' : 'Save Snapshot'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   FR-Comp-18 – Comparative Ratio (Comp Ratio)
   ══════════════════════════════════════════════════════════════════════════ */
type CompRatioRow = { id?: string; employee_id?: string; base_salary?: number; band_midpoint?: number; comp_ratio?: number; notes?: string; employee?: { first_name?: string; last_name?: string; job_grade?: string } };

function CompRatioTab() {
  const [rows, setRows] = useState<CompRatioRow[]>([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb
      .from('employee_comp_ratios')
      .select('id, employee_id, base_salary, band_midpoint, comp_ratio, notes, employee:employees!employee_comp_ratios_employee_id_fkey(first_name, last_name, job_grade)')
      .order('comp_ratio', { ascending: true })
      .limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const getColor = (r?: number) => {
    if (!r) return 'text-muted-foreground';
    if (r < 0.8) return 'text-red-600';
    if (r > 1.2) return 'text-blue-600';
    return 'text-green-700';
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <GitCompareArrows className="h-4 w-4" />Comparative Ratio (FR-Comp-18)
          </CardTitle>
          <Button size="sm" variant="outline" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
        </div>
        <p className="text-xs text-muted-foreground mt-1">Comp Ratio = Current Salary ÷ Band Midpoint. Target range: 0.80–1.20</p>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-32 bg-muted" /> : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">No comp ratio data. Populate <code>employee_comp_ratios</code> view or table.</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Grade</TableHead>
                <TableHead className="whitespace-nowrap">Current Salary</TableHead>
                <TableHead className="whitespace-nowrap">Midpoint</TableHead>
                <TableHead className="whitespace-nowrap">Comp Ratio</TableHead>
                <TableHead className="whitespace-nowrap">Position</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r, i) => (
                  <TableRow key={r.employee_id || i}>
                    <TableCell className="whitespace-nowrap font-medium">{r.employee ? `${r.employee.first_name} ${r.employee.last_name}` : String(r.employee_id || '').slice(0, 8)}</TableCell>
                    <TableCell><Badge variant="outline">{r.employee?.job_grade || '—'}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap">{r.base_salary?.toLocaleString() ?? '—'} ETB</TableCell>
                    <TableCell className="whitespace-nowrap">{r.band_midpoint?.toLocaleString() ?? '—'} ETB</TableCell>
                    <TableCell className={`whitespace-nowrap font-bold ${getColor(r.comp_ratio)}`}>
                      {r.comp_ratio != null ? r.comp_ratio.toFixed(2) : '—'}
                    </TableCell>
                    <TableCell>
                      {r.comp_ratio != null && (
                        <Badge className={r.comp_ratio < 0.8 ? 'bg-red-100 text-red-800' : r.comp_ratio > 1.2 ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}>
                          {r.comp_ratio < 0.8 ? 'Below Range' : r.comp_ratio > 1.2 ? 'Above Range' : 'In Range'}
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   FR-Comp-19 – Range Penetration
   ══════════════════════════════════════════════════════════════════════════ */
type RangePenRow = { id?: string; employee_id?: string; base_salary?: number; range_min?: number; range_max?: number; penetration?: number; notes?: string; employee?: { first_name?: string; last_name?: string; job_grade?: string } };

function RangePenetrationTab() {
  const [rows, setRows] = useState<RangePenRow[]>([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb
      .from('employee_range_penetration')
      .select('id, employee_id, base_salary, range_min, range_max, penetration, notes, employee:employees!employee_range_penetration_employee_id_fkey(first_name, last_name, job_grade)')
      .order('penetration', { ascending: true })
      .limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <SlidersHorizontal className="h-4 w-4" />Range Penetration (FR-Comp-19)
          </CardTitle>
          <Button size="sm" variant="outline" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
        </div>
        <p className="text-xs text-muted-foreground mt-1">Range Penetration = (Salary − Min) ÷ (Max − Min) × 100%</p>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-32 bg-muted" /> : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">No range penetration data available.</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Grade</TableHead>
                <TableHead className="whitespace-nowrap">Salary</TableHead>
                <TableHead className="whitespace-nowrap">Band Min</TableHead>
                <TableHead className="whitespace-nowrap">Band Max</TableHead>
                <TableHead className="whitespace-nowrap">Penetration</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r, i) => {
                  const pct = r.penetration ?? null;
                  return (
                    <TableRow key={r.employee_id || i}>
                      <TableCell className="whitespace-nowrap font-medium">{r.employee ? `${r.employee.first_name} ${r.employee.last_name}` : '—'}</TableCell>
                      <TableCell><Badge variant="outline">{r.employee?.job_grade || '—'}</Badge></TableCell>
                      <TableCell className="whitespace-nowrap">{r.base_salary?.toLocaleString() ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">{r.range_min?.toLocaleString() ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">{r.range_max?.toLocaleString() ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap w-40">
                        {pct != null ? (
                          <div className="flex items-center gap-2">
                            <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                              <div className="h-full bg-primary rounded-full" style={{ width: `${Math.min(100, Math.max(0, pct * 100))}%` }} />
                            </div>
                            <span className="text-xs font-medium w-10 text-right">{(pct * 100).toFixed(0)}%</span>
                          </div>
                        ) : '—'}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   FR-Comp-24 – Real-Time Compensation Budget
   ══════════════════════════════════════════════════════════════════════════ */
type BudgetRow = { budget_id?: string; dept_name?: string; fiscal_year?: string; total_budget?: number; committed?: number; remaining?: number; utilization_pct?: number };

function RealTimeBudgetTab() {
  const [rows, setRows] = useState<BudgetRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ dept_name: '', fiscal_year: String(new Date().getFullYear()), total_budget: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('compensation_budgets').select('*').order('fiscal_year', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.total_budget) { toast.error('Budget amount required'); return; }
    setSaving(true);
    const { error } = await sb.from('compensation_budgets').insert({ dept_name: form.dept_name || null, fiscal_year: form.fiscal_year, total_budget: Number(form.total_budget), committed: 0, remaining: Number(form.total_budget), utilization_pct: 0 });
    if (error) toast.error(error.message); else { toast.success('Budget entry created'); setOpen(false); load(); }
    setSaving(false);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><DollarSign className="h-4 w-4" />Real-Time Compensation Budget (FR-Comp-24)</CardTitle>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
            <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add Budget</Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-32 bg-muted" /> : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">No budget entries found</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Department</TableHead>
                <TableHead className="whitespace-nowrap">FY</TableHead>
                <TableHead className="whitespace-nowrap">Total Budget</TableHead>
                <TableHead className="whitespace-nowrap">Committed</TableHead>
                <TableHead className="whitespace-nowrap">Remaining</TableHead>
                <TableHead className="whitespace-nowrap">Utilisation</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r, i) => (
                  <TableRow key={r.budget_id || i}>
                    <TableCell className="whitespace-nowrap font-medium">{r.dept_name || 'All'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.fiscal_year}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.total_budget?.toLocaleString() ?? '—'} ETB</TableCell>
                    <TableCell className="whitespace-nowrap text-destructive">{r.committed?.toLocaleString() ?? '—'} ETB</TableCell>
                    <TableCell className="whitespace-nowrap text-green-700 font-medium">{r.remaining?.toLocaleString() ?? '—'} ETB</TableCell>
                    <TableCell className="whitespace-nowrap w-36">
                      {r.utilization_pct != null ? (
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                            <div className={`h-full rounded-full ${Number(r.utilization_pct) > 90 ? 'bg-destructive' : 'bg-primary'}`} style={{ width: `${Math.min(100, Number(r.utilization_pct))}%` }} />
                          </div>
                          <span className="text-xs font-medium w-9 text-right">{Number(r.utilization_pct).toFixed(0)}%</span>
                        </div>
                      ) : '—'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add Compensation Budget</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Department</Label><Input value={form.dept_name} onChange={e => setForm(p => ({ ...p, dept_name: e.target.value }))} placeholder="Leave blank for company-wide" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Fiscal Year</Label><Input value={form.fiscal_year} onChange={e => setForm(p => ({ ...p, fiscal_year: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Total Budget (ETB) *</Label><Input type="number" value={form.total_budget} onChange={e => setForm(p => ({ ...p, total_budget: e.target.value }))} /></div>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   FR-Comp-25 – Merit Matrix
   ══════════════════════════════════════════════════════════════════════════ */
type MeritCell = { performance_rating: string; position_in_range: string; merit_pct: number };

const MERIT_MATRIX_DEFAULT: MeritCell[] = [
  { performance_rating: 'Outstanding',  position_in_range: 'Below Range',  merit_pct: 8 },
  { performance_rating: 'Outstanding',  position_in_range: 'In Range',     merit_pct: 6 },
  { performance_rating: 'Outstanding',  position_in_range: 'Above Range',  merit_pct: 4 },
  { performance_rating: 'Exceeds',      position_in_range: 'Below Range',  merit_pct: 6 },
  { performance_rating: 'Exceeds',      position_in_range: 'In Range',     merit_pct: 4 },
  { performance_rating: 'Exceeds',      position_in_range: 'Above Range',  merit_pct: 2 },
  { performance_rating: 'Meets',        position_in_range: 'Below Range',  merit_pct: 4 },
  { performance_rating: 'Meets',        position_in_range: 'In Range',     merit_pct: 3 },
  { performance_rating: 'Meets',        position_in_range: 'Above Range',  merit_pct: 1 },
  { performance_rating: 'Needs Improvement', position_in_range: 'Below Range', merit_pct: 0 },
  { performance_rating: 'Needs Improvement', position_in_range: 'In Range',    merit_pct: 0 },
  { performance_rating: 'Needs Improvement', position_in_range: 'Above Range', merit_pct: 0 },
];

function MeritMatrixTab() {
  const [matrix, setMatrix] = useState<MeritCell[]>(MERIT_MATRIX_DEFAULT);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('merit_matrix').select('performance_rating, position_in_range, merit_pct').limit(50);
    if (data && data.length > 0) setMatrix(data as MeritCell[]);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const updateCell = (idx: number, val: string) => {
    const updated = [...matrix];
    updated[idx] = { ...updated[idx], merit_pct: Number(val) };
    setMatrix(updated);
  };

  const saveMatrix = async () => {
    setSaving(true);
    const { error } = await sb.from('merit_matrix').upsert(matrix, { onConflict: 'performance_rating,position_in_range' });
    if (error) toast.error(error.message); else toast.success('Merit matrix saved');
    setSaving(false);
  };

  const ratings = [...new Set(matrix.map(r => r.performance_rating))];
  const positions = [...new Set(matrix.map(r => r.position_in_range))];

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><Grid3x3 className="h-4 w-4" />Merit Matrix (FR-Comp-25)</CardTitle>
          <Button size="sm" onClick={saveMatrix} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save Matrix</Button>
        </div>
        <p className="text-xs text-muted-foreground mt-1">Define merit increase % by performance rating and salary range position</p>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-32 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Performance Rating</TableHead>
                  {positions.map(p => <TableHead key={p} className="whitespace-nowrap text-center">{p}</TableHead>)}
                </TableRow>
              </TableHeader>
              <TableBody>
                {ratings.map(rating => (
                  <TableRow key={rating}>
                    <TableCell className="whitespace-nowrap font-medium">{rating}</TableCell>
                    {positions.map(pos => {
                      const idx = matrix.findIndex(m => m.performance_rating === rating && m.position_in_range === pos);
                      return (
                        <TableCell key={pos} className="text-center">
                          {idx >= 0 ? (
                            <Input type="number" min="0" max="30" step="0.5"
                              className="w-20 text-center mx-auto h-8 text-sm"
                              value={matrix[idx].merit_pct}
                              onChange={e => updateCell(idx, e.target.value)}
                            />
                          ) : '—'}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   FR-Comp-26 – Exception Approval
   ══════════════════════════════════════════════════════════════════════════ */
type ExRow = { exception_id?: string; employee_id?: string; full_name?: string; request_type?: string; current_amount?: number; proposed_amount?: number; reason?: string; status?: string; requested_date?: string; approved_by?: string };

function ExceptionApprovalTab() {
  const [rows, setRows] = useState<ExRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ employee_id: '', request_type: 'OFF_CYCLE_INCREASE', current_amount: '', proposed_amount: '', reason: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('compensation_exceptions').select('*').order('requested_date', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.employee_id) { toast.error('Employee ID required'); return; }
    setSaving(true);
    const { error } = await sb.from('compensation_exceptions').insert({ employee_id: form.employee_id, request_type: form.request_type, current_amount: form.current_amount ? Number(form.current_amount) : null, proposed_amount: form.proposed_amount ? Number(form.proposed_amount) : null, reason: form.reason || null, requested_date: new Date().toISOString().slice(0, 10), status: 'PENDING' });
    if (error) toast.error(error.message); else { toast.success('Exception request submitted'); setOpen(false); load(); }
    setSaving(false);
  };

  const approve = async (id: string) => {
    const { error } = await sb.from('compensation_exceptions').update({ status: 'APPROVED' }).eq('exception_id', id);
    if (error) toast.error(error.message); else { toast.success('Approved'); load(); }
  };

  const reject = async (id: string) => {
    const { error } = await sb.from('compensation_exceptions').update({ status: 'REJECTED' }).eq('exception_id', id);
    if (error) toast.error(error.message); else { toast.success('Rejected'); load(); }
  };

  const STATUS_BADGE: Record<string, string> = { PENDING: 'bg-yellow-100 text-yellow-800', APPROVED: 'bg-green-100 text-green-800', REJECTED: 'bg-red-100 text-red-800' };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><ClipboardCheck className="h-4 w-4" />Exception Approval (FR-Comp-26)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />New Request</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-32 bg-muted" /> : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">No exception requests</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">Current</TableHead>
                <TableHead className="whitespace-nowrap">Proposed</TableHead>
                <TableHead className="whitespace-nowrap">Reason</TableHead>
                <TableHead className="whitespace-nowrap">Date</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Actions</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r, i) => (
                  <TableRow key={r.exception_id || i}>
                    <TableCell className="whitespace-nowrap">{r.full_name || String(r.employee_id || '').slice(0, 8)}</TableCell>
                    <TableCell><Badge variant="outline">{r.request_type}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap">{r.current_amount?.toLocaleString() ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">{r.proposed_amount?.toLocaleString() ?? '—'}</TableCell>
                    <TableCell className="max-w-[160px] truncate text-sm text-muted-foreground">{r.reason || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.requested_date || '—'}</TableCell>
                    <TableCell><Badge className={STATUS_BADGE[r.status || 'PENDING'] || 'bg-muted'}>{r.status || 'PENDING'}</Badge></TableCell>
                    <TableCell>
                      {r.status === 'PENDING' && (
                        <div className="flex gap-1">
                          <Button size="sm" className="h-7 text-xs bg-green-600 hover:bg-green-700" onClick={() => approve(r.exception_id!)}>Approve</Button>
                          <Button size="sm" variant="outline" className="h-7 text-xs text-destructive border-destructive/30" onClick={() => reject(r.exception_id!)}>Reject</Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Compensation Exception Request</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Employee ID *</Label><Input value={form.employee_id} onChange={e => setForm(p => ({ ...p, employee_id: e.target.value }))} placeholder="UUID" /></div>
            <div className="space-y-1.5"><Label>Request Type</Label>
              <Select value={form.request_type} onValueChange={v => setForm(p => ({ ...p, request_type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="OFF_CYCLE_INCREASE">Off-Cycle Increase</SelectItem>
                  <SelectItem value="ABOVE_BAND_OFFER">Above Band Offer</SelectItem>
                  <SelectItem value="RETENTION_BONUS">Retention Bonus</SelectItem>
                  <SelectItem value="MARKET_ADJUSTMENT">Market Adjustment</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Current Amount</Label><Input type="number" value={form.current_amount} onChange={e => setForm(p => ({ ...p, current_amount: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Proposed Amount</Label><Input type="number" value={form.proposed_amount} onChange={e => setForm(p => ({ ...p, proposed_amount: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Justification</Label><Textarea rows={3} value={form.reason} onChange={e => setForm(p => ({ ...p, reason: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Submit</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
