import { useState, useEffect, useCallback } from 'react';
import { Plus, Pencil, Trash2, ChevronDown, ChevronRight, Shield, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Switch } from '@/components/ui/switch';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { benefitPlanService, coverageTierService } from '@/services/benefits.service';
import type { BenefitPlan, CoverageTier, BenefitPlanType, EligibleEmploymentType } from '@/types/database.types';

const PLAN_TYPES: BenefitPlanType[] = ['MEDICAL','DENTAL','VISION','LIFE_INSURANCE','PENSION','DISABILITY','OTHER'];
const EMP_TYPES: EligibleEmploymentType[] = ['ALL','FULL_TIME','PART_TIME','CONTRACT'];

const PLAN_TYPE_COLORS: Record<BenefitPlanType, string> = {
  MEDICAL: 'bg-green-100 text-green-700',
  DENTAL: 'bg-cyan-100 text-cyan-700',
  VISION: 'bg-blue-100 text-blue-700',
  LIFE_INSURANCE: 'bg-purple-100 text-purple-700',
  PENSION: 'bg-orange-100 text-orange-700',
  DISABILITY: 'bg-yellow-100 text-yellow-700',
  OTHER: 'bg-muted text-muted-foreground',
};

// ─── Plan dialog ──────────────────────────────────────────────────────────────

const planSchema = z.object({
  plan_name: z.string().min(1, 'Name required').max(200),
  plan_code: z.string().min(1, 'Code required').max(50),
  plan_type: z.enum(['MEDICAL','DENTAL','VISION','LIFE_INSURANCE','PENSION','DISABILITY','OTHER']),
  provider_name: z.string().optional(),
  effective_start_date: z.string().min(1, 'Start date required'),
  effective_end_date: z.string().min(1, 'End date required'),
  min_service_months: z.coerce.number().min(0),
  eligible_employment_type: z.enum(['ALL','FULL_TIME','PART_TIME','CONTRACT']),
  min_age: z.coerce.number().optional(),
  max_age: z.coerce.number().optional(),
  is_active: z.boolean(),
});
type PlanFormValues = z.infer<typeof planSchema>;

interface PlanDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: BenefitPlan | null;
  onSaved: () => void;
}

function PlanDialog({ open, onOpenChange, editing, onSaved }: PlanDialogProps) {
  const [saving, setSaving] = useState(false);
  const form = useForm<PlanFormValues>({
    resolver: zodResolver(planSchema),
    defaultValues: { plan_type: 'MEDICAL', eligible_employment_type: 'ALL', min_service_months: 0, is_active: true, effective_start_date: new Date().toISOString().slice(0,10), effective_end_date: '9999-12-31' },
  });

  useEffect(() => {
    if (open) {
      if (editing) {
        form.reset({
          plan_name: editing.plan_name, plan_code: editing.plan_code, plan_type: editing.plan_type,
          provider_name: editing.provider_name ?? '', effective_start_date: editing.effective_start_date,
          effective_end_date: editing.effective_end_date, min_service_months: editing.min_service_months,
          eligible_employment_type: editing.eligible_employment_type, min_age: editing.min_age ?? undefined,
          max_age: editing.max_age ?? undefined, is_active: editing.is_active === 1,
        });
      } else {
        form.reset({ plan_type: 'MEDICAL', eligible_employment_type: 'ALL', min_service_months: 0, is_active: true, effective_start_date: new Date().toISOString().slice(0,10), effective_end_date: '9999-12-31' });
      }
    }
  }, [open, editing, form]);

  const onSubmit = async (vals: PlanFormValues) => {
    setSaving(true);
    try {
      const payload = {
        ...vals,
        tenant_id: '00000000-0000-0000-0000-000000000001',
        is_active: vals.is_active ? 1 : 0,
        is_deleted: 0, is_current: 0,
        effective_from: new Date().toISOString(),
        effective_to: '9999-12-31T23:59:59+00:00',
        row_start: new Date().toISOString(),
        row_end: '9999-12-31T23:59:59+00:00',
      };
      if (editing) {
        await benefitPlanService.update(editing.benefit_plan_id, payload);
        toast.success('Benefit plan updated');
      } else {
        await benefitPlanService.create(payload);
        toast.success('Benefit plan created');
      }
      onOpenChange(false);
      onSaved();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
        <DialogHeader><DialogTitle>{editing ? 'Edit Benefit Plan' : 'New Benefit Plan'}</DialogTitle></DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField control={form.control} name="plan_name" render={({ field }) => (
                <FormItem><FormLabel>Plan Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="plan_code" render={({ field }) => (
                <FormItem><FormLabel>Code</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="plan_type" render={({ field }) => (
                <FormItem><FormLabel>Plan Type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{PLAN_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="provider_name" render={({ field }) => (
                <FormItem><FormLabel>Provider <span className="text-muted-foreground text-xs">(optional)</span></FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="effective_start_date" render={({ field }) => (
                <FormItem><FormLabel>Start Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="effective_end_date" render={({ field }) => (
                <FormItem><FormLabel>End Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="eligible_employment_type" render={({ field }) => (
                <FormItem><FormLabel>Eligible Employment Type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{EMP_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="min_service_months" render={({ field }) => (
                <FormItem><FormLabel>Min Service Months</FormLabel><FormControl><Input type="number" min={0} {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="min_age" render={({ field }) => (
                <FormItem><FormLabel>Min Age</FormLabel><FormControl><Input type="number" min={0} {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="max_age" render={({ field }) => (
                <FormItem><FormLabel>Max Age</FormLabel><FormControl><Input type="number" min={0} {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            </div>
            <FormField control={form.control} name="is_active" render={({ field }) => (
              <FormItem className="flex items-center gap-2"><FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl><FormLabel className="!mt-0">Active</FormLabel></FormItem>
            )} />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ─── Tier dialog ──────────────────────────────────────────────────────────────

const tierSchema = z.object({
  tier_name: z.string().min(1, 'Tier name required').max(100),
  max_dependents: z.coerce.number().min(0).optional(),
  employee_contribution_percent: z.coerce.number().min(0).max(100).optional(),
  employer_contribution_percent: z.coerce.number().min(0).max(100).optional(),
  premium_amount: z.coerce.number().min(0).optional(),
});
type TierFormValues = z.infer<typeof tierSchema>;

interface TierDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  planId: string | null;
  editing: CoverageTier | null;
  onSaved: (planId: string) => void;
}

function TierDialog({ open, onOpenChange, planId, editing, onSaved }: TierDialogProps) {
  const [saving, setSaving] = useState(false);
  const form = useForm<TierFormValues>({
    resolver: zodResolver(tierSchema),
    defaultValues: { tier_name: '' },
  });

  useEffect(() => {
    if (open) {
      if (editing) {
        form.reset({
          tier_name: editing.tier_name, max_dependents: editing.max_dependents ?? undefined,
          employee_contribution_percent: editing.employee_contribution_percent ?? undefined,
          employer_contribution_percent: editing.employer_contribution_percent ?? undefined,
          premium_amount: editing.premium_amount ?? undefined,
        });
      } else {
        form.reset({ tier_name: '' });
      }
    }
  }, [open, editing, form]);

  const onSubmit = async (vals: TierFormValues) => {
    if (!planId) return;
    setSaving(true);
    try {
      const payload = {
        ...vals, benefit_plan_id: planId, tenant_id: '00000000-0000-0000-0000-000000000001',
        is_active: 1, is_deleted: 0, is_current: 0,
        effective_from: new Date().toISOString(), effective_to: '9999-12-31T23:59:59+00:00',
        row_start: new Date().toISOString(), row_end: '9999-12-31T23:59:59+00:00',
      };
      if (editing) {
        await coverageTierService.update(editing.coverage_tier_id, payload);
        toast.success('Tier updated');
      } else {
        await coverageTierService.create(payload);
        toast.success('Tier added');
      }
      onOpenChange(false);
      onSaved(planId);
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
        <DialogHeader><DialogTitle>{editing ? 'Edit Coverage Tier' : 'Add Coverage Tier'}</DialogTitle></DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField control={form.control} name="tier_name" render={({ field }) => (
              <FormItem><FormLabel>Tier Name</FormLabel><FormControl><Input {...field} placeholder="e.g. Individual, Family" /></FormControl><FormMessage /></FormItem>
            )} />
            <div className="grid grid-cols-2 gap-4">
              <FormField control={form.control} name="employee_contribution_percent" render={({ field }) => (
                <FormItem><FormLabel>Employee Contribution %</FormLabel><FormControl><Input type="number" min={0} max={100} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="employer_contribution_percent" render={({ field }) => (
                <FormItem><FormLabel>Employer Contribution %</FormLabel><FormControl><Input type="number" min={0} max={100} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="premium_amount" render={({ field }) => (
                <FormItem><FormLabel>Premium Amount</FormLabel><FormControl><Input type="number" min={0} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="max_dependents" render={({ field }) => (
                <FormItem><FormLabel>Max Dependents</FormLabel><FormControl><Input type="number" min={0} {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Add Tier'}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export function BenefitPlansPage() {
  const [plans, setPlans] = useState<BenefitPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState('all');
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [tiers, setTiers] = useState<Record<string, CoverageTier[]>>({});

  const [planOpen, setPlanOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<BenefitPlan | null>(null);
  const [deletePlan, setDeletePlan] = useState<BenefitPlan | null>(null);

  const [tierOpen, setTierOpen] = useState(false);
  const [editingTier, setEditingTier] = useState<CoverageTier | null>(null);
  const [deleteTier, setDeleteTier] = useState<CoverageTier | null>(null);
  const [activePlanId, setActivePlanId] = useState<string | null>(null);

  const loadPlans = useCallback(async () => {
    setLoading(true);
    try {
      const data = await benefitPlanService.list({ plan_type: typeFilter === 'all' ? undefined : typeFilter });
      setPlans(data);
    } catch { toast.error('Failed to load benefit plans'); }
    finally { setLoading(false); }
  }, [typeFilter]);

  useEffect(() => { loadPlans(); }, [loadPlans]);

  const reloadTiers = useCallback(async (planId: string) => {
    const t = await coverageTierService.listByPlan(planId);
    setTiers(prev => ({ ...prev, [planId]: t }));
  }, []);

  const toggleExpand = async (planId: string) => {
    const next = new Set(expanded);
    if (next.has(planId)) {
      next.delete(planId);
    } else {
      next.add(planId);
      if (!tiers[planId]) await reloadTiers(planId);
    }
    setExpanded(next);
  };

  const confirmDeletePlan = async () => {
    if (!deletePlan) return;
    try {
      await benefitPlanService.softDelete(deletePlan.benefit_plan_id);
      toast.success('Plan deleted');
      setDeletePlan(null);
      loadPlans();
    } catch { toast.error('Delete failed'); }
  };

  const confirmDeleteTier = async () => {
    if (!deleteTier) return;
    try {
      await coverageTierService.softDelete(deleteTier.coverage_tier_id);
      toast.success('Tier deleted');
      await reloadTiers(deleteTier.benefit_plan_id);
      setDeleteTier(null);
    } catch { toast.error('Delete failed'); }
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">Benefit Plans</h1>
          <p className="text-sm text-muted-foreground text-pretty">Manage benefit plan catalog and coverage tiers</p>
        </div>
        <Button onClick={() => { setEditingPlan(null); setPlanOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" /> New Plan
        </Button>
      </div>

      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-col md:flex-row gap-3">
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="md:w-52"><SelectValue placeholder="All Plan Types" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Plan Types</SelectItem>
                {PLAN_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" onClick={loadPlans}><RefreshCw className="h-4 w-4" /></Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {loading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <Card key={i}><CardContent className="p-4"><div className="h-12 bg-muted rounded animate-pulse" /></CardContent></Card>
          ))
        ) : plans.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center py-12 text-muted-foreground">
              <Shield className="h-10 w-10 mb-3 opacity-30" />
              <p>No benefit plans found</p>
              <Button variant="outline" className="mt-4" onClick={() => { setEditingPlan(null); setPlanOpen(true); }}>
                <Plus className="h-4 w-4 mr-2" /> Create First Plan
              </Button>
            </CardContent>
          </Card>
        ) : plans.map(p => (
          <Card key={p.benefit_plan_id} className="h-full">
            <CardHeader className="p-4">
              <div className="flex items-start justify-between gap-2">
                <button className="flex items-center gap-2 flex-1 min-w-0 text-left" onClick={() => toggleExpand(p.benefit_plan_id)}>
                  {expanded.has(p.benefit_plan_id) ? <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />}
                  <div className="min-w-0">
                    <div className="font-medium flex items-center gap-2 flex-wrap">
                      <span>{p.plan_name}</span>
                      <span className="font-mono text-xs text-muted-foreground">{p.plan_code}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${PLAN_TYPE_COLORS[p.plan_type]}`}>{p.plan_type}</span>
                      {p.provider_name && <span className="text-xs text-muted-foreground">{p.provider_name}</span>}
                      <Badge variant={p.is_active ? 'default' : 'secondary'} className="text-xs">{p.is_active ? 'Active' : 'Inactive'}</Badge>
                      <span className="text-xs text-muted-foreground">{p.effective_start_date} → {p.effective_end_date === '9999-12-31' ? 'Ongoing' : p.effective_end_date}</span>
                    </div>
                  </div>
                </button>
                <div className="flex gap-1 shrink-0">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditingTier(null); setActivePlanId(p.benefit_plan_id); setTierOpen(true); }} title="Add Tier">
                    <Plus className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditingPlan(p); setPlanOpen(true); }}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeletePlan(p)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            {expanded.has(p.benefit_plan_id) && (
              <CardContent className="p-0 border-t">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b bg-muted/30">
                        {['Tier Name','Max Dependents','Employee %','Employer %','Premium','Actions'].map(h => (
                          <th key={h} className={`whitespace-nowrap px-4 py-2 text-xs font-medium ${h === 'Actions' ? 'text-right' : 'text-left'}`}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {(tiers[p.benefit_plan_id] || []).length === 0 ? (
                        <tr><td colSpan={6} className="px-4 py-4 text-center text-xs text-muted-foreground">No tiers — click <Plus className="inline h-3 w-3" /> to add</td></tr>
                      ) : (tiers[p.benefit_plan_id] || []).map(t => (
                        <tr key={t.coverage_tier_id} className="border-b hover:bg-muted/20">
                          <td className="whitespace-nowrap px-4 py-2 font-medium text-xs">{t.tier_name}</td>
                          <td className="whitespace-nowrap px-4 py-2 text-xs">{t.max_dependents ?? '—'}</td>
                          <td className="whitespace-nowrap px-4 py-2 text-xs">{t.employee_contribution_percent != null ? `${t.employee_contribution_percent}%` : '—'}</td>
                          <td className="whitespace-nowrap px-4 py-2 text-xs">{t.employer_contribution_percent != null ? `${t.employer_contribution_percent}%` : '—'}</td>
                          <td className="whitespace-nowrap px-4 py-2 text-xs">{t.premium_amount != null ? Number(t.premium_amount).toLocaleString() : '—'}</td>
                          <td className="whitespace-nowrap px-4 py-2">
                            <div className="flex justify-end gap-1">
                              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditingTier(t); setActivePlanId(t.benefit_plan_id); setTierOpen(true); }}>
                                <Pencil className="h-3 w-3" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => setDeleteTier(t)}>
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            )}
          </Card>
        ))}
      </div>

      <PlanDialog open={planOpen} onOpenChange={setPlanOpen} editing={editingPlan} onSaved={loadPlans} />
      <TierDialog open={tierOpen} onOpenChange={setTierOpen} planId={activePlanId} editing={editingTier} onSaved={reloadTiers} />

      <AlertDialog open={!!deletePlan} onOpenChange={o => !o && setDeletePlan(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader><AlertDialogTitle>Delete Plan</AlertDialogTitle>
            <AlertDialogDescription>Delete benefit plan <strong>{deletePlan?.plan_name}</strong> and all its tiers?</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeletePlan} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!deleteTier} onOpenChange={o => !o && setDeleteTier(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader><AlertDialogTitle>Delete Tier</AlertDialogTitle>
            <AlertDialogDescription>Delete coverage tier <strong>{deleteTier?.tier_name}</strong>?</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteTier} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

