import { useState, useEffect, useCallback } from 'react';
import { Plus, Pencil, CheckCircle, XCircle, Search, RefreshCw, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { benefitEnrollmentService, benefitPlanService, coverageTierService } from '@/services/benefits.service';
import { employeeService } from '@/services/employee.service';
import type {
  BenefitEnrollment, BenefitPlan, CoverageTier, Employee,
  LifeEventType, EnrollmentStatus,
} from '@/types/database.types';

const LIFE_EVENTS: LifeEventType[] = ['NEW_HIRE','MARRIAGE','BIRTH','DIVORCE','TERMINATION','OPEN_ENROLLMENT','OTHER'];
const STATUSES: EnrollmentStatus[] = ['PENDING','ACTIVE','CANCELLED','EXPIRED'];

const STATUS_COLORS: Record<EnrollmentStatus, string> = {
  PENDING: 'bg-yellow-100 text-yellow-700',
  ACTIVE: 'bg-green-100 text-green-700',
  CANCELLED: 'bg-red-100 text-red-700',
  EXPIRED: 'bg-muted text-muted-foreground',
};

const schema = z.object({
  employee_id: z.string().min(1, 'Employee required'),
  benefit_plan_id: z.string().min(1, 'Plan required'),
  coverage_tier_id: z.string().min(1, 'Coverage tier required'),
  life_event_type: z.string().optional(),
  enrollment_date: z.string().min(1, 'Enrollment date required'),
  effective_date: z.string().min(1, 'Effective date required'),
  employee_deduction_monthly: z.coerce.number().optional(),
  employer_contribution_monthly: z.coerce.number().optional(),
});
type FormValues = z.infer<typeof schema>;

const statusSchema = z.object({
  enrollment_status: z.enum(['PENDING','ACTIVE','CANCELLED','EXPIRED']),
  termination_date: z.string().optional(),
});
type StatusForm = z.infer<typeof statusSchema>;

export function BenefitEnrollmentPage() {
  const [enrollments, setEnrollments] = useState<BenefitEnrollment[]>([]);
  const [plans, setPlans] = useState<BenefitPlan[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [tiers, setTiers] = useState<CoverageTier[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [planFilter, setPlanFilter] = useState('all');
  const [formOpen, setFormOpen] = useState(false);
  const [statusOpen, setStatusOpen] = useState(false);
  const [activeEnrollment, setActiveEnrollment] = useState<BenefitEnrollment | null>(null);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { enrollment_date: new Date().toISOString().slice(0,10), effective_date: new Date().toISOString().slice(0,10) },
  });

  const statusForm = useForm<StatusForm>({
    resolver: zodResolver(statusSchema),
    defaultValues: { enrollment_status: 'ACTIVE' },
  });

  const selectedPlanId = form.watch('benefit_plan_id');

  useEffect(() => {
    if (selectedPlanId && selectedPlanId !== '') {
      coverageTierService.listByPlan(selectedPlanId).then(setTiers).catch(() => setTiers([]));
    } else {
      setTiers([]);
    }
  }, [selectedPlanId]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [enr, plns, emps] = await Promise.all([
        benefitEnrollmentService.list({
          benefit_plan_id: planFilter === 'all' ? undefined : planFilter,
          enrollment_status: statusFilter === 'all' ? undefined : statusFilter,
        }),
        benefitPlanService.list({ is_active: 1 }),
        employeeService.list({ pageSize: 500 }),
      ]);
      setEnrollments(Array.isArray(enr) ? enr : []);
      setPlans(Array.isArray(plns) ? plns : []);
      setEmployees(Array.isArray(emps.data) ? emps.data : []);
    } catch {
      toast.error('Failed to load enrollments');
    } finally {
      setLoading(false);
    }
  }, [planFilter, statusFilter]);

  useEffect(() => { load(); }, [load]);

  const openEnroll = () => {
    form.reset({ enrollment_date: new Date().toISOString().slice(0,10), effective_date: new Date().toISOString().slice(0,10) });
    setFormOpen(true);
  };

  const onSubmit = async (vals: FormValues) => {
    setSaving(true);
    try {
      await benefitEnrollmentService.enroll({
        ...vals,
        tenant_id: '00000000-0000-0000-0000-000000000001',
        life_event_type: vals.life_event_type as LifeEventType | undefined,
        enrollment_status: 'PENDING',
        is_active: 1, is_deleted: 0, is_current: 0,
        effective_from: new Date().toISOString(),
        effective_to: '9999-12-31T23:59:59+00:00',
        row_start: new Date().toISOString(),
        row_end: '9999-12-31T23:59:59+00:00',
      });
      toast.success('Enrollment submitted');
      setFormOpen(false);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Enrollment failed');
    } finally {
      setSaving(false);
    }
  };

  const openStatusUpdate = (enr: BenefitEnrollment) => {
    setActiveEnrollment(enr);
    statusForm.reset({ enrollment_status: enr.enrollment_status });
    setStatusOpen(true);
  };

  const submitStatus = async (vals: StatusForm) => {
    if (!activeEnrollment) return;
    setSaving(true);
    try {
      await benefitEnrollmentService.updateStatus(activeEnrollment.benefit_enrollment_id, vals.enrollment_status, vals.termination_date);
      toast.success('Status updated');
      setStatusOpen(false);
      load();
    } catch {
      toast.error('Update failed');
    } finally {
      setSaving(false);
    }
  };

  const filtered = enrollments.filter(e => {
    if (!search) return true;
    const emp = e.employee;
    const name = emp ? `${emp.first_name} ${emp.last_name} ${emp.employee_no}`.toLowerCase() : '';
    return name.includes(search.toLowerCase());
  });

  const statusCount = (s: EnrollmentStatus) => enrollments.filter(e => e.enrollment_status === s).length;

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">Benefit Enrollments</h1>
          <p className="text-sm text-muted-foreground text-pretty">Employee benefit plan enrollments and life-event tracking</p>
        </div>
        <Button onClick={openEnroll}><Plus className="h-4 w-4 mr-2" /> New Enrollment</Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {STATUSES.map(s => (
          <Card key={s}>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">{s}</p>
              <p className="text-2xl font-semibold mt-1">{statusCount(s)}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input className="pl-9" placeholder="Search employee…" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="md:w-44"><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={planFilter} onValueChange={setPlanFilter}>
              <SelectTrigger className="md:w-52"><SelectValue placeholder="All Plans" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Plans</SelectItem>
                {plans.map(p => <SelectItem key={p.benefit_plan_id} value={p.benefit_plan_id}>{p.plan_name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" onClick={load}><RefreshCw className="h-4 w-4" /></Button>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">{loading ? 'Loading…' : `${filtered.length} enrollment${filtered.length !== 1 ? 's' : ''}`}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/40">
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Employee</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Benefit Plan</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Tier</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Life Event</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Enrolled</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Effective</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Monthly Deduction</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Status</th>
                  <th className="whitespace-nowrap px-4 py-3 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i} className="border-b">{Array.from({ length: 9 }).map((__, j) => (
                      <td key={j} className="px-4 py-3"><div className="h-4 bg-muted rounded animate-pulse w-20" /></td>
                    ))}</tr>
                  ))
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="px-4 py-10 text-center text-muted-foreground">
                      <Users className="h-8 w-8 mx-auto mb-2 opacity-30" />
                      No enrollments found
                    </td>
                  </tr>
                ) : filtered.map(e => (
                  <tr key={e.benefit_enrollment_id} className="border-b hover:bg-muted/30 transition-colors">
                    <td className="whitespace-nowrap px-4 py-3">
                      <div className="font-medium">{e.employee ? `${e.employee.first_name} ${e.employee.last_name}` : e.employee_id}</div>
                      <div className="text-xs text-muted-foreground">{e.employee?.employee_no}</div>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">{e.benefit_plan?.plan_name ?? '—'}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">{e.coverage_tier?.tier_name ?? '—'}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">{e.life_event_type ?? '—'}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">{e.enrollment_date}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">{e.effective_date}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">
                      {e.employee_deduction_monthly != null ? Number(e.employee_deduction_monthly).toLocaleString() : '—'}
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLORS[e.enrollment_status]}`}>
                        {e.enrollment_status}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <div className="flex justify-end">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openStatusUpdate(e)} title="Update Status">
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Enrollment Form */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>New Benefit Enrollment</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="employee_id" render={({ field }) => (
                <FormItem><FormLabel>Employee</FormLabel>
                  <Select value={field.value ?? ''} onValueChange={field.onChange}>
                    <FormControl><SelectTrigger><SelectValue placeholder="Select employee" /></SelectTrigger></FormControl>
                    <SelectContent>
                      {employees.map(e => <SelectItem key={e.id} value={e.id}>{e.first_name} {e.last_name} ({e.employee_no})</SelectItem>)}
                    </SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="benefit_plan_id" render={({ field }) => (
                  <FormItem><FormLabel>Benefit Plan</FormLabel>
                    <Select value={field.value ?? ''} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select plan" /></SelectTrigger></FormControl>
                      <SelectContent>
                        {plans.map(p => <SelectItem key={p.benefit_plan_id} value={p.benefit_plan_id}>{p.plan_name}</SelectItem>)}
                      </SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="coverage_tier_id" render={({ field }) => (
                  <FormItem><FormLabel>Coverage Tier</FormLabel>
                    <Select value={field.value ?? ''} onValueChange={field.onChange} disabled={!selectedPlanId}>
                      <FormControl><SelectTrigger><SelectValue placeholder={selectedPlanId ? 'Select tier' : 'Select plan first'} /></SelectTrigger></FormControl>
                      <SelectContent>
                        {tiers.map(t => <SelectItem key={t.coverage_tier_id} value={t.coverage_tier_id}>{t.tier_name}</SelectItem>)}
                      </SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="life_event_type" render={({ field }) => (
                  <FormItem><FormLabel>Life Event</FormLabel>
                    <Select value={field.value ?? 'none'} onValueChange={v => field.onChange(v === 'none' ? undefined : v)}>
                      <FormControl><SelectTrigger><SelectValue placeholder="None" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {LIFE_EVENTS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}
                      </SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="enrollment_date" render={({ field }) => (
                  <FormItem><FormLabel>Enrollment Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="effective_date" render={({ field }) => (
                  <FormItem><FormLabel>Effective Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="employee_deduction_monthly" render={({ field }) => (
                  <FormItem><FormLabel>Monthly Employee Deduction</FormLabel><FormControl><Input type="number" min={0} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="employer_contribution_monthly" render={({ field }) => (
                  <FormItem><FormLabel>Monthly Employer Contribution</FormLabel><FormControl><Input type="number" min={0} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={saving}>{saving ? 'Submitting…' : 'Enroll'}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Status Update Dialog */}
      <Dialog open={statusOpen} onOpenChange={setStatusOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Update Enrollment Status</DialogTitle></DialogHeader>
          <Form {...statusForm}>
            <form onSubmit={statusForm.handleSubmit(submitStatus)} className="space-y-4">
              <FormField control={statusForm.control} name="enrollment_status" render={({ field }) => (
                <FormItem><FormLabel>Status</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={statusForm.control} name="termination_date" render={({ field }) => (
                <FormItem><FormLabel>Termination Date <span className="text-muted-foreground text-xs">(for cancellation)</span></FormLabel>
                  <FormControl><Input type="date" {...field} /></FormControl><FormMessage />
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setStatusOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={saving}>{saving ? 'Updating…' : 'Update'}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
