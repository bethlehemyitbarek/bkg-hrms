import { useState, useEffect, useCallback } from 'react';
import { Plus, Pencil, Trash2, Search, RefreshCw, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Switch } from '@/components/ui/switch';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { bonusConfigService } from '@/services/benefits.service';
import type { BonusConfiguration, BonusType, BonusCalculationMethod, BonusCycleFrequency } from '@/types/database.types';

const BONUS_TYPES: BonusType[] = ['PERFORMANCE','ANNUAL','SPOT','RETENTION','OTHER'];
const CALC_METHODS: BonusCalculationMethod[] = ['FIXED','PERCENTAGE','FORMULA'];
const CYCLE_FREQS: BonusCycleFrequency[] = ['MONTHLY','QUARTERLY','SEMI_ANNUAL','ANNUAL','ONE_TIME'];

const BONUS_TYPE_COLORS: Record<BonusType, string> = {
  PERFORMANCE: 'bg-blue-100 text-blue-700',
  ANNUAL: 'bg-green-100 text-green-700',
  SPOT: 'bg-orange-100 text-orange-700',
  RETENTION: 'bg-purple-100 text-purple-700',
  OTHER: 'bg-muted text-muted-foreground',
};

const schema = z.object({
  bonus_name: z.string().min(1, 'Name required').max(200),
  bonus_code: z.string().min(1, 'Code required').max(50),
  bonus_type: z.enum(['PERFORMANCE','ANNUAL','SPOT','RETENTION','OTHER']),
  calculation_method: z.enum(['FIXED','PERCENTAGE','FORMULA']).optional(),
  default_value: z.coerce.number().optional(),
  cycle_frequency: z.enum(['MONTHLY','QUARTERLY','SEMI_ANNUAL','ANNUAL','ONE_TIME']).optional(),
  effective_from: z.string().min(1, 'Effective from required'),
  effective_to: z.string().optional(),
  is_active: z.boolean(),
});
type FormValues = z.infer<typeof schema>;

export function BonusConfigPage() {
  const [items, setItems] = useState<BonusConfiguration[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [formOpen, setFormOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<BonusConfiguration | null>(null);
  const [editing, setEditing] = useState<BonusConfiguration | null>(null);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { bonus_type: 'PERFORMANCE', calculation_method: 'FIXED', cycle_frequency: 'ANNUAL', is_active: true, effective_from: new Date().toISOString().slice(0,10) },
  });
  const calcMethod = form.watch('calculation_method');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await bonusConfigService.list({ bonus_type: typeFilter === 'all' ? undefined : typeFilter });
      setItems(data);
    } catch {
      toast.error('Failed to load bonus configurations');
    } finally {
      setLoading(false);
    }
  }, [typeFilter]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    setEditing(null);
    form.reset({ bonus_type: 'PERFORMANCE', calculation_method: 'FIXED', cycle_frequency: 'ANNUAL', is_active: true, effective_from: new Date().toISOString().slice(0,10) });
    setFormOpen(true);
  };

  const openEdit = (item: BonusConfiguration) => {
    setEditing(item);
    form.reset({
      bonus_name: item.bonus_name, bonus_code: item.bonus_code,
      bonus_type: item.bonus_type, calculation_method: item.calculation_method,
      default_value: item.default_value ?? undefined, cycle_frequency: item.cycle_frequency,
      effective_from: item.effective_from, effective_to: item.effective_to ?? '',
      is_active: item.is_active === 1,
    });
    setFormOpen(true);
  };

  const onSubmit = async (vals: FormValues) => {
    setSaving(true);
    try {
      const payload = {
        ...vals,
        tenant_id: '00000000-0000-0000-0000-000000000001',
        is_active: vals.is_active ? 1 : 0,
        is_deleted: 0,
      };
      if (editing) {
        await bonusConfigService.update(editing.bonus_config_id, payload);
        toast.success('Bonus configuration updated');
      } else {
        await bonusConfigService.create(payload);
        toast.success('Bonus configuration created');
      }
      setFormOpen(false);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await bonusConfigService.softDelete(deleteTarget.bonus_config_id);
      toast.success('Bonus configuration deleted');
      setDeleteTarget(null);
      load();
    } catch { toast.error('Delete failed'); }
  };

  const filtered = items.filter(i =>
    !search ||
    i.bonus_name.toLowerCase().includes(search.toLowerCase()) ||
    i.bonus_code.toLowerCase().includes(search.toLowerCase())
  );

  // Stats
  const activeCount = items.filter(i => i.is_active === 1).length;
  const typeCount = new Set(items.map(i => i.bonus_type)).size;

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">Bonus Configuration</h1>
          <p className="text-sm text-muted-foreground text-pretty">Define bonus programs with eligibility, calculation rules, and cycles</p>
        </div>
        <Button onClick={openCreate}><Plus className="h-4 w-4 mr-2" /> New Bonus Program</Button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Programs', value: items.length },
          { label: 'Active', value: activeCount },
          { label: 'Types Used', value: typeCount },
          { label: 'With Formula', value: items.filter(i => i.calculation_method === 'FORMULA').length },
        ].map(s => (
          <Card key={s.label}><CardContent className="p-4">
            <p className="text-xs text-muted-foreground">{s.label}</p>
            <p className="text-2xl font-semibold mt-1">{s.value}</p>
          </CardContent></Card>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input className="pl-9" placeholder="Search by name or code…" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="md:w-52"><SelectValue placeholder="All Types" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {BONUS_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" onClick={load}><RefreshCw className="h-4 w-4" /></Button>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">{loading ? 'Loading…' : `${filtered.length} program${filtered.length !== 1 ? 's' : ''}`}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/40">
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Code</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Name</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Type</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Method</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Default Value</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Cycle</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Effective From</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Status</th>
                  <th className="whitespace-nowrap px-4 py-3 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  Array.from({ length: 4 }).map((_, i) => (
                    <tr key={i} className="border-b">{Array.from({ length: 9 }).map((__, j) => (
                      <td key={j} className="px-4 py-3"><div className="h-4 bg-muted rounded animate-pulse w-20" /></td>
                    ))}</tr>
                  ))
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="px-4 py-10 text-center text-muted-foreground">
                      <Gift className="h-8 w-8 mx-auto mb-2 opacity-30" />
                      No bonus programs found
                    </td>
                  </tr>
                ) : filtered.map(item => (
                  <tr key={item.bonus_config_id} className="border-b hover:bg-muted/30 transition-colors">
                    <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">{item.bonus_code}</td>
                    <td className="whitespace-nowrap px-4 py-3 font-medium">{item.bonus_name}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${BONUS_TYPE_COLORS[item.bonus_type]}`}>{item.bonus_type}</span>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">{item.calculation_method ?? '—'}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">
                      {item.default_value != null
                        ? item.calculation_method === 'PERCENTAGE' ? `${item.default_value}%` : item.default_value.toLocaleString()
                        : '—'}
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">{item.cycle_frequency ?? '—'}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs">{item.effective_from}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <Badge variant={item.is_active ? 'default' : 'secondary'} className="text-xs">{item.is_active ? 'Active' : 'Inactive'}</Badge>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(item)}><Pencil className="h-3.5 w-3.5" /></Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(item)}><Trash2 className="h-3.5 w-3.5" /></Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Form Dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing ? 'Edit Bonus Program' : 'New Bonus Program'}</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="bonus_name" render={({ field }) => (
                  <FormItem><FormLabel>Name</FormLabel><FormControl><Input {...field} placeholder="e.g. Annual Performance Bonus" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="bonus_code" render={({ field }) => (
                  <FormItem><FormLabel>Code</FormLabel><FormControl><Input {...field} placeholder="e.g. ANN-PERF-001" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="bonus_type" render={({ field }) => (
                  <FormItem><FormLabel>Bonus Type</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>{BONUS_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="calculation_method" render={({ field }) => (
                  <FormItem><FormLabel>Calculation Method</FormLabel>
                    <Select value={field.value ?? 'none'} onValueChange={v => field.onChange(v === 'none' ? undefined : v)}>
                      <FormControl><SelectTrigger><SelectValue placeholder="None" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {CALC_METHODS.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                      </SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
                {calcMethod && calcMethod !== 'FORMULA' && (
                  <FormField control={form.control} name="default_value" render={({ field }) => (
                    <FormItem><FormLabel>Default Value {calcMethod === 'PERCENTAGE' ? '(%)' : '(ETB)'}</FormLabel>
                      <FormControl><Input type="number" min={0} step="0.01" {...field} /></FormControl><FormMessage />
                    </FormItem>
                  )} />
                )}
                <FormField control={form.control} name="cycle_frequency" render={({ field }) => (
                  <FormItem><FormLabel>Cycle Frequency</FormLabel>
                    <Select value={field.value ?? 'none'} onValueChange={v => field.onChange(v === 'none' ? undefined : v)}>
                      <FormControl><SelectTrigger><SelectValue placeholder="None" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {CYCLE_FREQS.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                      </SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="effective_from" render={({ field }) => (
                  <FormItem><FormLabel>Effective From</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="effective_to" render={({ field }) => (
                  <FormItem><FormLabel>Effective To <span className="text-muted-foreground text-xs">(optional)</span></FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={form.control} name="is_active" render={({ field }) => (
                <FormItem className="flex items-center gap-2"><FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl><FormLabel className="!mt-0">Active</FormLabel></FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={o => !o && setDeleteTarget(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader><AlertDialogTitle>Delete Bonus Program</AlertDialogTitle>
            <AlertDialogDescription>Delete <strong>{deleteTarget?.bonus_name}</strong>? This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
