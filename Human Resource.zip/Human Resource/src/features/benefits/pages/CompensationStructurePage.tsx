import { useState, useEffect, useCallback } from 'react';
import { Plus, Pencil, Trash2, ChevronRight, ChevronDown, LayoutList, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Switch } from '@/components/ui/switch';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { compensationStructureService, compensationComponentService } from '@/services/compensation.service';
import type {
  CompensationStructure, CompensationComponent,
  CompensationStructureType, ComponentType, ComponentCalculationMethod,
} from '@/types/database.types';

// ─── Shared constants ────────────────────────────────────────────────────────

const STRUCTURE_TYPES: CompensationStructureType[] = ['PAYROLL', 'COMPENSATION', 'HYBRID'];
const COMPONENT_TYPES: ComponentType[] = ['EARNING', 'DEDUCTION', 'EMPLOYER_CONTRIBUTION'];
const CALC_METHODS: ComponentCalculationMethod[] = ['FIXED', 'PERCENTAGE', 'FORMULA', 'TABLE_LOOKUP'];
const SUBTYPES = ['BASIC_SALARY','ALLOWANCE','BONUS','OVERTIME','COMMISSION','TAX','PENSION','SOCIAL_SECURITY','LOAN_REPAYMENT','BENEFIT','OTHER'] as const;
const SOURCES = ['STANDARD','STATUTORY','ALLOWANCE','BENEFIT','LOAN','CUSTOM'] as const;

const TYPE_COLORS: Record<ComponentType, string> = {
  EARNING: 'bg-green-100 text-green-700',
  DEDUCTION: 'bg-red-100 text-red-700',
  EMPLOYER_CONTRIBUTION: 'bg-blue-100 text-blue-700',
};

// ─── Structure form schema ────────────────────────────────────────────────────

const structureSchema = z.object({
  structure_name: z.string().min(1, 'Name required').max(200),
  structure_code: z.string().min(1, 'Code required').max(50),
  structure_type: z.enum(['PAYROLL', 'COMPENSATION', 'HYBRID']),
  description: z.string().optional(),
  effective_from: z.string().min(1, 'Effective from required'),
  effective_to: z.string().optional(),
  is_active: z.boolean(),
});
type StructureFormValues = z.infer<typeof structureSchema>;

interface StructureDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: CompensationStructure | null;
  onSaved: () => void;
}

function StructureDialog({ open, onOpenChange, editing, onSaved }: StructureDialogProps) {
  const [saving, setSaving] = useState(false);
  const form = useForm<StructureFormValues>({
    resolver: zodResolver(structureSchema),
    defaultValues: { structure_name: '', structure_code: '', structure_type: 'HYBRID', effective_from: new Date().toISOString().slice(0,10), is_active: true },
  });

  useEffect(() => {
    if (open) {
      if (editing) {
        form.reset({
          structure_name: editing.structure_name,
          structure_code: editing.structure_code,
          structure_type: editing.structure_type,
          description: editing.description ?? '',
          effective_from: editing.effective_from,
          effective_to: editing.effective_to ?? '',
          is_active: editing.is_active === 1,
        });
      } else {
        form.reset({ structure_name: '', structure_code: '', structure_type: 'HYBRID', effective_from: new Date().toISOString().slice(0,10), is_active: true });
      }
    }
  }, [open, editing, form]);

  const onSubmit = async (vals: StructureFormValues) => {
    setSaving(true);
    try {
      const payload = { ...vals, tenant_id: '00000000-0000-0000-0000-000000000001', is_active: vals.is_active ? 1 : 0, is_deleted: 0, is_current: 1, row_start: new Date().toISOString(), row_end: new Date().toISOString(), version_number: 1 };
      if (editing) {
        await compensationStructureService.update(editing.structure_id, payload);
        toast.success('Structure updated');
      } else {
        await compensationStructureService.create(payload);
        toast.success('Structure created');
      }
      onOpenChange(false);
      onSaved();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
        <DialogHeader><DialogTitle>{editing ? 'Edit Structure' : 'New Compensation Structure'}</DialogTitle></DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField control={form.control} name="structure_name" render={({ field }) => (
                <FormItem><FormLabel>Structure Name</FormLabel><FormControl><Input {...field} placeholder="e.g. Standard Pay Structure" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="structure_code" render={({ field }) => (
                <FormItem><FormLabel>Code</FormLabel><FormControl><Input {...field} placeholder="e.g. STD-PAY-001" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="structure_type" render={({ field }) => (
                <FormItem><FormLabel>Type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{STRUCTURE_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="effective_from" render={({ field }) => (
                <FormItem><FormLabel>Effective From</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="effective_to" render={({ field }) => (
                <FormItem><FormLabel>Effective To <span className="text-muted-foreground text-xs">(optional)</span></FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            </div>
            <FormField control={form.control} name="description" render={({ field }) => (
              <FormItem><FormLabel>Description</FormLabel><FormControl><Textarea {...field} rows={2} placeholder="Optional description…" /></FormControl><FormMessage /></FormItem>
            )} />
            <FormField control={form.control} name="is_active" render={({ field }) => (
              <FormItem className="flex items-center gap-2"><FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl><FormLabel className="!mt-0">Active</FormLabel></FormItem>
            )} />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ─── Component form schema ────────────────────────────────────────────────────

const componentSchema = z.object({
  component_name: z.string().min(1, 'Name required').max(200),
  component_code: z.string().min(1, 'Code required').max(50),
  component_type: z.enum(['EARNING', 'DEDUCTION', 'EMPLOYER_CONTRIBUTION']),
  component_subtype: z.string().optional(),
  calculation_method: z.enum(['FIXED', 'PERCENTAGE', 'FORMULA', 'TABLE_LOOKUP']),
  formula: z.string().optional(),
  default_value: z.coerce.number().optional(),
  is_taxable: z.boolean(),
  is_pensionable: z.boolean(),
  source: z.string().optional(),
  display_order: z.coerce.number().optional(),
});
type ComponentFormValues = z.infer<typeof componentSchema>;

interface ComponentDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  structureId: string | null;
  editing: CompensationComponent | null;
  onSaved: (structureId: string) => void;
}

function ComponentDialog({ open, onOpenChange, structureId, editing, onSaved }: ComponentDialogProps) {
  const [saving, setSaving] = useState(false);
  const form = useForm<ComponentFormValues>({
    resolver: zodResolver(componentSchema),
    defaultValues: { component_name: '', component_code: '', component_type: 'EARNING', calculation_method: 'FIXED', is_taxable: true, is_pensionable: false, source: 'STANDARD' },
  });
  const calcMethod = form.watch('calculation_method');

  useEffect(() => {
    if (open) {
      if (editing) {
        form.reset({
          component_name: editing.component_name, component_code: editing.component_code,
          component_type: editing.component_type, component_subtype: editing.component_subtype ?? '',
          calculation_method: editing.calculation_method, formula: editing.formula ?? '',
          default_value: editing.default_value ?? undefined,
          is_taxable: editing.is_taxable === 1, is_pensionable: editing.is_pensionable === 1,
          source: editing.source ?? 'STANDARD', display_order: editing.display_order ?? undefined,
        });
      } else {
        form.reset({ component_name: '', component_code: '', component_type: 'EARNING', calculation_method: 'FIXED', is_taxable: true, is_pensionable: false, source: 'STANDARD' });
      }
    }
  }, [open, editing, form]);

  const onSubmit = async (vals: ComponentFormValues) => {
    if (!structureId) return;
    setSaving(true);
    try {
      const payload = {
        ...vals,
        structure_id: structureId,
        tenant_id: '00000000-0000-0000-0000-000000000001',
        is_taxable: vals.is_taxable ? 1 : 0,
        is_pensionable: vals.is_pensionable ? 1 : 0,
        source: (vals.source ?? 'STANDARD') as CompensationComponent['source'],
        component_subtype: vals.component_subtype as CompensationComponent['component_subtype'],
        is_active: 1, is_deleted: 0, is_current: 1,
        effective_from: new Date().toISOString(), effective_to: '9999-12-31T23:59:59+00:00',
        row_start: new Date().toISOString(), row_end: '9999-12-31T23:59:59+00:00',
      };
      if (editing) {
        await compensationComponentService.update(editing.component_id, payload);
        toast.success('Component updated');
      } else {
        await compensationComponentService.create(payload);
        toast.success('Component added');
      }
      onOpenChange(false);
      onSaved(structureId);
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
        <DialogHeader><DialogTitle>{editing ? 'Edit Component' : 'Add Component'}</DialogTitle></DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField control={form.control} name="component_name" render={({ field }) => (
                <FormItem><FormLabel>Component Name</FormLabel><FormControl><Input {...field} placeholder="e.g. Basic Salary" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="component_code" render={({ field }) => (
                <FormItem><FormLabel>Code</FormLabel><FormControl><Input {...field} placeholder="e.g. BASIC" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="component_type" render={({ field }) => (
                <FormItem><FormLabel>Type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{COMPONENT_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="component_subtype" render={({ field }) => (
                <FormItem><FormLabel>Subtype</FormLabel>
                  <Select value={field.value ?? 'none'} onValueChange={v => field.onChange(v === 'none' ? undefined : v)}><FormControl><SelectTrigger><SelectValue placeholder="None" /></SelectTrigger></FormControl>
                    <SelectContent><SelectItem value="none">None</SelectItem>{SUBTYPES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="calculation_method" render={({ field }) => (
                <FormItem><FormLabel>Calculation Method</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{CALC_METHODS.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="default_value" render={({ field }) => (
                <FormItem><FormLabel>Default Value {calcMethod === 'PERCENTAGE' ? '(%)' : ''}</FormLabel><FormControl><Input type="number" min={0} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="source" render={({ field }) => (
                <FormItem><FormLabel>Source</FormLabel>
                  <Select value={field.value ?? 'STANDARD'} onValueChange={field.onChange}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{SOURCES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="display_order" render={({ field }) => (
                <FormItem><FormLabel>Display Order</FormLabel><FormControl><Input type="number" min={1} step={1} {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            </div>
            {calcMethod === 'FORMULA' && (
              <FormField control={form.control} name="formula" render={({ field }) => (
                <FormItem><FormLabel>Formula</FormLabel><FormControl><Textarea {...field} rows={2} placeholder="e.g. BASIC_SALARY * 0.1" /></FormControl><FormMessage /></FormItem>
              )} />
            )}
            <div className="flex gap-6">
              <FormField control={form.control} name="is_taxable" render={({ field }) => (
                <FormItem className="flex items-center gap-2"><FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl><FormLabel className="!mt-0">Taxable</FormLabel></FormItem>
              )} />
              <FormField control={form.control} name="is_pensionable" render={({ field }) => (
                <FormItem className="flex items-center gap-2"><FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl><FormLabel className="!mt-0">Pensionable</FormLabel></FormItem>
              )} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Add'}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export function CompensationStructurePage() {
  const [structures, setStructures] = useState<CompensationStructure[]>([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [components, setComponents] = useState<Record<string, CompensationComponent[]>>({});
  const [loadingComponents, setLoadingComponents] = useState<Set<string>>(new Set());
  const [typeFilter, setTypeFilter] = useState('all');

  const [structureOpen, setStructureOpen] = useState(false);
  const [editingStructure, setEditingStructure] = useState<CompensationStructure | null>(null);
  const [deleteStructure, setDeleteStructure] = useState<CompensationStructure | null>(null);

  const [componentOpen, setComponentOpen] = useState(false);
  const [editingComponent, setEditingComponent] = useState<CompensationComponent | null>(null);
  const [deleteComponent, setDeleteComponent] = useState<CompensationComponent | null>(null);
  const [activeStructureId, setActiveStructureId] = useState<string | null>(null);

  const loadStructures = useCallback(async () => {
    setLoading(true);
    try {
      const data = await compensationStructureService.list({ structure_type: typeFilter === 'all' ? undefined : typeFilter });
      setStructures(data);
    } catch { toast.error('Failed to load structures'); }
    finally { setLoading(false); }
  }, [typeFilter]);

  useEffect(() => { loadStructures(); }, [loadStructures]);

  const reloadComponents = useCallback(async (structureId: string) => {
    const comps = await compensationComponentService.listByStructure(structureId);
    setComponents(prev => ({ ...prev, [structureId]: comps }));
  }, []);

  const toggleExpand = async (structureId: string) => {
    const next = new Set(expanded);
    if (next.has(structureId)) {
      next.delete(structureId);
    } else {
      next.add(structureId);
      if (!components[structureId]) {
        setLoadingComponents(prev => new Set(prev).add(structureId));
        try { await reloadComponents(structureId); }
        catch { toast.error('Failed to load components'); }
        finally { setLoadingComponents(prev => { const s = new Set(prev); s.delete(structureId); return s; }); }
      }
    }
    setExpanded(next);
  };

  const confirmDeleteStructure = async () => {
    if (!deleteStructure) return;
    try {
      await compensationStructureService.softDelete(deleteStructure.structure_id);
      toast.success('Structure deleted');
      setDeleteStructure(null);
      loadStructures();
    } catch { toast.error('Delete failed'); }
  };

  const confirmDeleteComponent = async () => {
    if (!deleteComponent) return;
    try {
      await compensationComponentService.softDelete(deleteComponent.component_id);
      toast.success('Component deleted');
      await reloadComponents(deleteComponent.structure_id);
      setDeleteComponent(null);
    } catch { toast.error('Delete failed'); }
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">Compensation Structures</h1>
          <p className="text-sm text-muted-foreground text-pretty">Define pay structures and their earning/deduction components</p>
        </div>
        <Button onClick={() => { setEditingStructure(null); setStructureOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" /> New Structure
        </Button>
      </div>

      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-col md:flex-row gap-3">
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="md:w-52"><SelectValue placeholder="All Types" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {STRUCTURE_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" onClick={loadStructures}><RefreshCw className="h-4 w-4" /></Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {loading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <Card key={i}><CardContent className="p-4"><div className="h-12 bg-muted rounded animate-pulse" /></CardContent></Card>
          ))
        ) : structures.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center py-12 text-muted-foreground">
              <LayoutList className="h-10 w-10 mb-3 opacity-30" />
              <p>No compensation structures found</p>
              <Button variant="outline" className="mt-4" onClick={() => { setEditingStructure(null); setStructureOpen(true); }}>
                <Plus className="h-4 w-4 mr-2" /> Create First Structure
              </Button>
            </CardContent>
          </Card>
        ) : structures.map(s => (
          <Card key={s.structure_id} className="h-full">
            <CardHeader className="p-4">
              <div className="flex items-start justify-between gap-2">
                <button className="flex items-center gap-2 flex-1 min-w-0 text-left" onClick={() => toggleExpand(s.structure_id)}>
                  {expanded.has(s.structure_id) ? <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />}
                  <div className="min-w-0">
                    <div className="font-medium flex items-center gap-2 flex-wrap">
                      <span className="truncate">{s.structure_name}</span>
                      <span className="font-mono text-xs text-muted-foreground">{s.structure_code}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <Badge variant="secondary" className="text-xs">{s.structure_type}</Badge>
                      <Badge variant={s.is_active ? 'default' : 'secondary'} className="text-xs">{s.is_active ? 'Active' : 'Inactive'}</Badge>
                      <span className="text-xs text-muted-foreground">From {s.effective_from}</span>
                    </div>
                  </div>
                </button>
                <div className="flex gap-1 shrink-0">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditingComponent(null); setActiveStructureId(s.structure_id); setComponentOpen(true); }}>
                    <Plus className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditingStructure(s); setStructureOpen(true); }}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleteStructure(s)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            {expanded.has(s.structure_id) && (
              <CardContent className="p-0 border-t">
                {loadingComponents.has(s.structure_id) ? (
                  <div className="p-4 space-y-2">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-8 bg-muted rounded animate-pulse" />)}</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b bg-muted/30">
                          {['#','Code','Name','Type','Subtype','Method','Default','Taxable','Actions'].map(h => (
                            <th key={h} className={`whitespace-nowrap px-4 py-2 text-xs font-medium ${h === 'Actions' ? 'text-right' : 'text-left'}`}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {(components[s.structure_id] || []).length === 0 ? (
                          <tr><td colSpan={9} className="px-4 py-6 text-center text-xs text-muted-foreground">No components — click <Plus className="inline h-3 w-3" /> to add</td></tr>
                        ) : (components[s.structure_id] || []).map(c => (
                          <tr key={c.component_id} className="border-b hover:bg-muted/20 transition-colors">
                            <td className="whitespace-nowrap px-4 py-2 text-xs text-muted-foreground">{c.display_order ?? '—'}</td>
                            <td className="whitespace-nowrap px-4 py-2 font-mono text-xs">{c.component_code}</td>
                            <td className="whitespace-nowrap px-4 py-2 font-medium text-xs">{c.component_name}</td>
                            <td className="whitespace-nowrap px-4 py-2"><span className={`inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium ${TYPE_COLORS[c.component_type]}`}>{c.component_type}</span></td>
                            <td className="whitespace-nowrap px-4 py-2 text-xs text-muted-foreground">{c.component_subtype ?? '—'}</td>
                            <td className="whitespace-nowrap px-4 py-2 text-xs">{c.calculation_method}</td>
                            <td className="whitespace-nowrap px-4 py-2 text-xs">{c.default_value != null ? c.default_value.toLocaleString() : '—'}</td>
                            <td className="whitespace-nowrap px-4 py-2"><Badge variant={c.is_taxable ? 'default' : 'secondary'} className="text-xs">{c.is_taxable ? 'Yes' : 'No'}</Badge></td>
                            <td className="whitespace-nowrap px-4 py-2">
                              <div className="flex justify-end gap-1">
                                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditingComponent(c); setActiveStructureId(c.structure_id); setComponentOpen(true); }}><Pencil className="h-3 w-3" /></Button>
                                <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => setDeleteComponent(c)}><Trash2 className="h-3 w-3" /></Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            )}
          </Card>
        ))}
      </div>

      <StructureDialog
        open={structureOpen}
        onOpenChange={setStructureOpen}
        editing={editingStructure}
        onSaved={loadStructures}
      />

      <ComponentDialog
        open={componentOpen}
        onOpenChange={setComponentOpen}
        structureId={activeStructureId}
        editing={editingComponent}
        onSaved={reloadComponents}
      />

      <AlertDialog open={!!deleteStructure} onOpenChange={o => !o && setDeleteStructure(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader><AlertDialogTitle>Delete Structure</AlertDialogTitle>
            <AlertDialogDescription>Delete <strong>{deleteStructure?.structure_name}</strong> and all its components?</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteStructure} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!deleteComponent} onOpenChange={o => !o && setDeleteComponent(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader><AlertDialogTitle>Delete Component</AlertDialogTitle>
            <AlertDialogDescription>Delete component <strong>{deleteComponent?.component_name}</strong>?</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteComponent} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
