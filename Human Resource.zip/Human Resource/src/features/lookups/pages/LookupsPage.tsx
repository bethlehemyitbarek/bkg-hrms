import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

// ── Reference Data ────────────────────────────────────────────────
import { CountriesTab }       from '../components/tabs/CountriesTab';
import { CurrenciesTab }      from '../components/tabs/CurrenciesTab';
import { ExchangeRatesTab }   from '../components/tabs/ExchangeRatesTab';
import { BanksTab }           from '../components/tabs/BanksTab';
import { BankBranchesTab }    from '../components/tabs/BankBranchesTab';
import { RegionsTab }         from '../components/tabs/RegionsTab';
// ── People & Demographics ─────────────────────────────────────────
import { TitlesTab }          from '../components/tabs/TitlesTab';
import { LanguagesTab }       from '../components/tabs/LanguagesTab';
import { SkillsTab }          from '../components/tabs/SkillsTab';
import { ReligionsTab }       from '../components/tabs/ReligionsTab';
import { EthnicitiesTab }     from '../components/tabs/EthnicitiesTab';
// ── Job Structure ────────────────────────────────────────────────
import { JobFamiliesTab }     from '../components/tabs/JobFamiliesTab';
import { JobTitlesTab }       from '../components/tabs/JobTitlesTab';
import { GradesTab }          from '../components/tabs/GradesTab';
import { StepsTab }           from '../components/tabs/StepsTab';
// ── Tax & Statutory ───────────────────────────────────────────────
import { TaxBracketsTab }         from '../components/tabs/TaxBracketsTab';
import { PensionSchemasTab }      from '../components/tabs/PensionSchemasTab';
import { StatutoryDeductionsTab } from '../components/tabs/StatutoryDeductionsTab';

/* ─── Group / Tab configuration ──────────────────────────────────── */
type TabEntry = { value: string; label: string; component: React.ReactNode };
type Group    = { id: string; label: string; color: string; tabs: TabEntry[] };

const GROUPS: Group[] = [
  {
    id: 'reference',
    label: 'Reference Data',
    color: 'bg-blue-100 text-blue-700',
    tabs: [
      { value: 'countries',      label: 'Countries',      component: <CountriesTab /> },
      { value: 'currencies',     label: 'Currencies',     component: <CurrenciesTab /> },
      { value: 'exchange-rates', label: 'Exchange Rates', component: <ExchangeRatesTab /> },
      { value: 'banks',          label: 'Banks',          component: <BanksTab /> },
      { value: 'bank-branches',  label: 'Bank Branches',  component: <BankBranchesTab /> },
      { value: 'regions',        label: 'Regions',        component: <RegionsTab /> },
    ],
  },
  {
    id: 'people',
    label: 'People & Demographics',
    color: 'bg-green-100 text-green-700',
    tabs: [
      { value: 'titles',       label: 'Titles',       component: <TitlesTab /> },
      { value: 'languages',    label: 'Languages',    component: <LanguagesTab /> },
      { value: 'skills',       label: 'Skills',       component: <SkillsTab /> },
      { value: 'religions',    label: 'Religions',    component: <ReligionsTab /> },
      { value: 'ethnicities',  label: 'Ethnicities',  component: <EthnicitiesTab /> },
    ],
  },
  {
    id: 'job-structure',
    label: 'Job Structure',
    color: 'bg-purple-100 text-purple-700',
    tabs: [
      { value: 'job-families', label: 'Job Families', component: <JobFamiliesTab /> },
      { value: 'job-titles',   label: 'Job Titles',   component: <JobTitlesTab /> },
      { value: 'grades',       label: 'Grades',       component: <GradesTab /> },
      { value: 'steps',        label: 'Grade Steps',  component: <StepsTab /> },
    ],
  },
  {
    id: 'tax-statutory',
    label: 'Tax & Statutory',
    color: 'bg-red-100 text-red-700',
    tabs: [
      { value: 'tax-brackets',         label: 'Tax Brackets',    component: <TaxBracketsTab /> },
      { value: 'pension-schemes',      label: 'Pension Schemes', component: <PensionSchemasTab /> },
      { value: 'statutory-deductions', label: 'Statutory Deduc.',component: <StatutoryDeductionsTab /> },
    ],
  },
];

export function LookupsPage() {
  const [activeGroup, setActiveGroup] = useState<string>(GROUPS[0].id);

  const currentGroup = GROUPS.find(g => g.id === activeGroup) ?? GROUPS[0];

  return (
    <div className="flex flex-col gap-6 p-4 md:p-6 min-h-0">
      {/* Page Header */}
      <div>
        <h1 className="text-xl md:text-2xl font-bold text-balance">Lookup Tables</h1>
        <p className="text-sm text-muted-foreground text-pretty mt-1">
          Manage all reference / master data used across the HRMS — {' '}
          <span className="font-medium text-foreground">18 lookup tables</span> across 4 categories.
        </p>
      </div>

      {/* Group Selector */}
      <div className="flex flex-wrap gap-2">
        {GROUPS.map(g => (
          <button
            key={g.id}
            onClick={() => setActiveGroup(g.id)}
            className={cn(
              'flex items-center gap-2 px-4 py-2 rounded-lg border text-sm font-medium transition-all',
              activeGroup === g.id
                ? 'bg-primary text-primary-foreground border-primary shadow-sm'
                : 'bg-background text-foreground border-border hover:bg-accent hover:text-accent-foreground',
            )}
          >
            {g.label}
            <Badge
              variant="secondary"
              className={cn('text-xs border-0 px-1.5 py-0', activeGroup === g.id ? 'bg-primary-foreground/20 text-primary-foreground' : g.color)}
            >
              {g.tabs.length}
            </Badge>
          </button>
        ))}
      </div>

      {/* Sub-tabs for active group */}
      <Card className="flex-1 h-full">
        <CardContent className="p-0">
          <Tabs defaultValue={currentGroup.tabs[0].value} key={currentGroup.id}>
            {/* Sub-tab strip */}
            <div className="border-b border-border px-4 pt-2 overflow-x-auto">
              <TabsList className="h-auto bg-transparent p-0 gap-0 flex-nowrap w-max">
                {currentGroup.tabs.map(t => (
                  <TabsTrigger
                    key={t.value}
                    value={t.value}
                    className={cn(
                      'relative rounded-none px-4 py-2.5 text-sm font-normal whitespace-nowrap',
                      'data-[state=active]:bg-transparent data-[state=active]:font-semibold',
                      'data-[state=active]:text-foreground data-[state=active]:shadow-none',
                      'text-muted-foreground',
                      'after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5',
                      'data-[state=active]:after:bg-primary after:bg-transparent',
                    )}
                  >
                    {t.label}
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>

            {/* Tab content panels */}
            {currentGroup.tabs.map(t => (
              <TabsContent key={t.value} value={t.value} className="mt-0 p-4 md:p-6">
                {t.component}
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
