import { useState } from 'react';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Pencil, Trash2, Search, Plus } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

export interface ColDef<T> {
  key: keyof T | string;
  label: string;
  render?: (row: T) => React.ReactNode;
  className?: string;
}

interface LookupTableProps<T extends { [k: string]: unknown }> {
  title: string;
  description?: string;
  columns: ColDef<T>[];
  data: T[];
  loading: boolean;
  idKey: keyof T;
  onAdd: () => void;
  onEdit: (row: T) => void;
  onDelete: (id: string) => void;
  searchPlaceholder?: string;
  searchKeys?: (keyof T)[];
}

export function LookupTable<T extends { [k: string]: unknown }>({
  title, description, columns, data, loading, idKey,
  onAdd, onEdit, onDelete,
  searchPlaceholder = 'Search…',
  searchKeys = [],
}: LookupTableProps<T>) {
  const [query, setQuery] = useState('');

  const filtered = query.trim()
    ? data.filter(row =>
        searchKeys.some(k => String(row[k] ?? '').toLowerCase().includes(query.toLowerCase()))
      )
    : data;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold">{title}</h3>
          {description && <p className="text-sm text-muted-foreground text-pretty">{description}</p>}
        </div>
        <Button size="sm" onClick={onAdd} className="shrink-0">
          <Plus className="h-4 w-4 mr-1.5" />Add
        </Button>
      </div>

      {/* Search */}
      {searchKeys.length > 0 && (
        <div className="relative max-w-xs">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            className="pl-8 h-9"
            placeholder={searchPlaceholder}
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
        </div>
      )}

      {/* Table */}
      <div className="w-full overflow-x-auto rounded-md border border-border">
        <Table>
          <TableHeader>
            <TableRow>
              {columns.map(c => (
                <TableHead key={String(c.key)} className={cn('whitespace-nowrap', c.className)}>
                  {c.label}
                </TableHead>
              ))}
              <TableHead className="w-20 whitespace-nowrap text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  {columns.map(c => (
                    <TableCell key={String(c.key)}><Skeleton className="h-4 w-24 bg-muted" /></TableCell>
                  ))}
                  <TableCell><Skeleton className="h-4 w-16 bg-muted ml-auto" /></TableCell>
                </TableRow>
              ))
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={columns.length + 1} className="text-center text-muted-foreground py-10">
                  {query ? 'No results match your search.' : 'No records yet. Click Add to create one.'}
                </TableCell>
              </TableRow>
            ) : (
              filtered.map(row => (
                <TableRow key={String(row[idKey])}>
                  {columns.map(c => (
                    <TableCell key={String(c.key)} className={cn('whitespace-nowrap', c.className)}>
                      {c.render ? c.render(row) : String(row[c.key as keyof T] ?? '—')}
                    </TableCell>
                  ))}
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onEdit(row)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive hover:bg-destructive/10">
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete this record?</AlertDialogTitle>
                            <AlertDialogDescription>This action cannot be undone.</AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              onClick={() => onDelete(String(row[idKey]))}
                            >Delete</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <p className="text-xs text-muted-foreground">
        {loading ? '' : `${filtered.length} record${filtered.length !== 1 ? 's' : ''}`}
      </p>
    </div>
  );
}

// Shared active badge renderer
export function ActiveBadge({ value }: { value: boolean | string | null | undefined }) {
  const active = value === true || value === 'true';
  return (
    <Badge variant="secondary" className={cn(
      'text-xs border-0',
      active ? 'bg-green-100 text-green-700' : 'bg-muted text-muted-foreground',
    )}>
      {active ? 'Active' : 'Inactive'}
    </Badge>
  );
}
