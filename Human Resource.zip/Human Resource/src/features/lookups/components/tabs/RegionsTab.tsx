import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type Region = {
  region_id: string; country_code: string; region_code: string;
  region_name: string; region_level: string; parent_region_id: string | null; is_active: boolean;
};

const LEVEL_OPTIONS = [
  { value: 'REGION',   label: 'Region' },
  { value: 'ZONE',     label: 'Zone' },
  { value: 'WOREDA',   label: 'Woreda' },
  { value: 'KEBELE',   label: 'Kebele' },
  { value: 'STATE',    label: 'State' },
  { value: 'PROVINCE', label: 'Province' },
  { value: 'COUNTY',   label: 'County' },
];

const COLS: ColDef<Region>[] = [
  { key: 'country_code', label: 'Country', className: 'w-20 font-mono' },
  { key: 'region_code',  label: 'Code',    className: 'font-mono' },
  { key: 'region_name',  label: 'Region Name' },
  { key: 'region_level', label: 'Level' },
  { key: 'is_active',    label: 'Status',  render: r => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'country_code', label: 'Country Code',   type: 'text',   required: true, placeholder: 'ETH' },
  { name: 'region_code',  label: 'Region Code',    type: 'text',   required: true },
  { name: 'region_name',  label: 'Region Name',    type: 'text',   required: true },
  { name: 'region_level', label: 'Level',          type: 'select', options: LEVEL_OPTIONS, required: true },
  { name: 'is_active',    label: 'Active',         type: 'switch' },
];

export function RegionsTab() {
  const [data, setData]       = useState<Region[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<Region | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_regions').select('*').eq('is_deleted', false).order('country_code').order('region_name');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_regions').update({ is_deleted: true }).eq('region_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_regions').update(payload).eq('region_id', editing.region_id)
      : await supabase.from('lookup_regions').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Regions" description="Administrative regions / zones / woredas / kebeles for address standardization."
        columns={COLS} data={data} loading={loading} idKey="region_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search regions…" searchKeys={['region_name','region_code']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Region' : 'Add Region'}
        fields={FIELDS}
        defaultValues={editing ?? { country_code: 'ETH', region_level: 'REGION', is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
