import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type Religion = { religion_id: string; religion_name: string; is_active: boolean };

const COLS: ColDef<Religion>[] = [
  { key: 'religion_name', label: 'Religion' },
  { key: 'is_active',     label: 'Status', render: r => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'religion_name', label: 'Religion Name', type: 'text',   required: true },
  { name: 'is_active',     label: 'Active',        type: 'switch' },
];

export function ReligionsTab() {
  const [data, setData]       = useState<Religion[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<Religion | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_religions').select('*').eq('is_deleted', false).order('religion_name');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_religions').update({ is_deleted: true }).eq('religion_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_religions').update(payload).eq('religion_id', editing.religion_id)
      : await supabase.from('lookup_religions').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Religions" description="Religion reference for employee demographics and cultural accommodations."
        columns={COLS} data={data} loading={loading} idKey="religion_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search religions…" searchKeys={['religion_name']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Religion' : 'Add Religion'}
        fields={FIELDS}
        defaultValues={editing ?? { is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
