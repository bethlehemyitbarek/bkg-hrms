import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type Title = { title_id: string; title_code: string; title_name: string; is_active: boolean };

const COLS: ColDef<Title>[] = [
  { key: 'title_code', label: 'Code', className: 'w-20 font-mono' },
  { key: 'title_name', label: 'Title' },
  { key: 'is_active',  label: 'Status', render: r => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'title_code', label: 'Code',       type: 'text',   required: true, placeholder: 'DR' },
  { name: 'title_name', label: 'Title',      type: 'text',   required: true, placeholder: 'Dr.' },
  { name: 'is_active',  label: 'Active',     type: 'switch' },
];

export function TitlesTab() {
  const [data, setData]       = useState<Title[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<Title | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_titles').select('*').order('title_code');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_titles').delete().eq('title_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_titles').update(payload).eq('title_id', editing.title_id)
      : await supabase.from('lookup_titles').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Titles / Salutations" description="Mr., Mrs., Dr., Ato, W/rt, Eng., Prof., etc."
        columns={COLS} data={data} loading={loading} idKey="title_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search titles…" searchKeys={['title_name','title_code']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Title' : 'Add Title'}
        fields={FIELDS}
        defaultValues={editing ?? { is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
