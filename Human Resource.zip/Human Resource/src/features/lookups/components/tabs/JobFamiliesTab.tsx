import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type JobFamily = {
  job_family_id: string; family_code: string; family_name: string;
  description: string; is_active: boolean;
};

const COLS: ColDef<JobFamily>[] = [
  { key: 'family_code', label: 'Code',        className: 'font-mono w-24' },
  { key: 'family_name', label: 'Family Name' },
  { key: 'description', label: 'Description', render: r => <span className="text-muted-foreground text-xs">{r.description || '—'}</span> },
  { key: 'is_active',   label: 'Status',      render: r => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'family_code', label: 'Code',        type: 'text',     required: true, placeholder: 'HR' },
  { name: 'family_name', label: 'Family Name', type: 'text',     required: true },
  { name: 'description', label: 'Description', type: 'textarea' },
  { name: 'is_active',   label: 'Active',      type: 'switch' },
];

export function JobFamiliesTab() {
  const [data, setData]       = useState<JobFamily[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<JobFamily | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_job_families').select('*').eq('is_deleted', false).order('family_name');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_job_families').update({ is_deleted: true }).eq('job_family_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_job_families').update(payload).eq('job_family_id', editing.job_family_id)
      : await supabase.from('lookup_job_families').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Job Families" description="Groups related positions into functional families for career pathing."
        columns={COLS} data={data} loading={loading} idKey="job_family_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search job families…" searchKeys={['family_name', 'family_code']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Job Family' : 'Add Job Family'}
        fields={FIELDS}
        defaultValues={editing ?? { is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
