import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type Language = { language_id: string; language_code: string; language_name: string; is_active: boolean };

const COLS: ColDef<Language>[] = [
  { key: 'language_code', label: 'Code', className: 'w-24 font-mono' },
  { key: 'language_name', label: 'Language' },
  { key: 'is_active',     label: 'Status', render: r => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'language_code', label: 'ISO 639 Code', type: 'text',   required: true, placeholder: 'AMH' },
  { name: 'language_name', label: 'Language Name',type: 'text',   required: true },
  { name: 'is_active',     label: 'Active',       type: 'switch' },
];

export function LanguagesTab() {
  const [data, setData]       = useState<Language[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<Language | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_languages').select('*').order('language_name');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_languages').delete().eq('language_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_languages').update(payload).eq('language_id', editing.language_id)
      : await supabase.from('lookup_languages').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Languages" description="Languages available for employee proficiency tracking."
        columns={COLS} data={data} loading={loading} idKey="language_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search languages…" searchKeys={['language_name','language_code']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Language' : 'Add Language'}
        fields={FIELDS}
        defaultValues={editing ?? { is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
