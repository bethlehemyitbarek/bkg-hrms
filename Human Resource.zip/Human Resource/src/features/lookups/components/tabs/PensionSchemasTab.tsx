import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type PensionSchema = {
  pension_scheme_id: string; scheme_code: string; scheme_name: string;
  employee_contribution_rate: number; employer_contribution_rate: number;
  max_pensionable_salary: number | null; effective_from: string;
  effective_to: string | null; country_code: string; statutory_reference: string; is_active: boolean;
};

const COLS: ColDef<PensionSchema>[] = [
  { key: 'scheme_code',                 label: 'Code',       className: 'font-mono w-28' },
  { key: 'scheme_name',                 label: 'Scheme Name' },
  { key: 'employee_contribution_rate',  label: 'Emp %',      render: r => `${(Number(r.employee_contribution_rate)*100).toFixed(1)}%` },
  { key: 'employer_contribution_rate',  label: 'Emp\'r %',   render: r => `${(Number(r.employer_contribution_rate)*100).toFixed(1)}%` },
  { key: 'country_code',                label: 'Country',    className: 'w-20 font-mono' },
  { key: 'effective_from',              label: 'Effective' },
  { key: 'is_active',                   label: 'Status',     render: r => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'scheme_code',                label: 'Scheme Code',                         type: 'text',   required: true },
  { name: 'scheme_name',                label: 'Scheme Name',                         type: 'text',   required: true },
  { name: 'employee_contribution_rate', label: 'Employee Rate (e.g. 0.07 = 7%)',      type: 'number', required: true },
  { name: 'employer_contribution_rate', label: 'Employer Rate (e.g. 0.11 = 11%)',     type: 'number', required: true },
  { name: 'max_pensionable_salary',     label: 'Max Pensionable Salary (blank = none)',type: 'number' },
  { name: 'country_code',               label: 'Country Code',                        type: 'text',   placeholder: 'ETH' },
  { name: 'effective_from',             label: 'Effective From',                      type: 'date',   required: true },
  { name: 'effective_to',               label: 'Effective To',                        type: 'date' },
  { name: 'statutory_reference',        label: 'Statutory Reference',                 type: 'textarea' },
  { name: 'is_active',                  label: 'Active',                              type: 'switch' },
];

export function PensionSchemasTab() {
  const [data, setData]       = useState<PensionSchema[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<PensionSchema | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_pension_schemas').select('*').eq('is_deleted', false).order('scheme_name');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_pension_schemas').update({ is_deleted: true }).eq('pension_scheme_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = {
      ...values,
      employee_contribution_rate:  Number(values.employee_contribution_rate),
      employer_contribution_rate:  Number(values.employer_contribution_rate),
      max_pensionable_salary:      values.max_pensionable_salary ? Number(values.max_pensionable_salary) : null,
      effective_to:                values.effective_to || null,
      is_active:                   Boolean(values.is_active),
      updated_at:                  new Date().toISOString(),
    };
    const { error } = editing
      ? await supabase.from('lookup_pension_schemas').update(payload).eq('pension_scheme_id', editing.pension_scheme_id)
      : await supabase.from('lookup_pension_schemas').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Pension Schemes" description="Pension scheme configuration for employer and employee contribution rates."
        columns={COLS} data={data} loading={loading} idKey="pension_scheme_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search schemes…" searchKeys={['scheme_name', 'scheme_code']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Pension Scheme' : 'Add Pension Scheme'}
        fields={FIELDS}
        defaultValues={editing ?? { country_code: 'ETH', is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
