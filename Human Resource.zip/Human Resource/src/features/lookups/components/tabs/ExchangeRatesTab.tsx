import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type ExchangeRate = {
  exchange_rate_id: string; from_currency_code: string; to_currency_code: string;
  rate: number; effective_date: string; source: string; is_active: boolean;
};

const COLS: ColDef<ExchangeRate>[] = [
  { key: 'from_currency_code', label: 'From',       className: 'font-mono' },
  { key: 'to_currency_code',   label: 'To',         className: 'font-mono' },
  { key: 'rate',               label: 'Rate',       render: r => Number(r.rate).toFixed(6) },
  { key: 'effective_date',     label: 'Effective Date' },
  { key: 'source',             label: 'Source' },
  { key: 'is_active',          label: 'Status',     render: r => <ActiveBadge value={r.is_active} /> },
];

const SOURCE_OPTIONS = [
  { value: 'MANUAL',               label: 'Manual' },
  { value: 'API',                  label: 'API' },
  { value: 'NATIONAL_BANK_OF_ETHIOPIA', label: 'National Bank of Ethiopia' },
];

const FIELDS: FieldDef[] = [
  { name: 'from_currency_code', label: 'From Currency', type: 'text',   required: true, placeholder: 'ETB' },
  { name: 'to_currency_code',   label: 'To Currency',   type: 'text',   required: true, placeholder: 'USD' },
  { name: 'rate',               label: 'Rate',          type: 'number', required: true, placeholder: '0.018' },
  { name: 'effective_date',     label: 'Effective Date',type: 'date',   required: true },
  { name: 'source',             label: 'Source',        type: 'select', options: SOURCE_OPTIONS },
  { name: 'is_active',          label: 'Active',        type: 'switch' },
];

export function ExchangeRatesTab() {
  const [data, setData]       = useState<ExchangeRate[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<ExchangeRate | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_exchange_rates').select('*').order('effective_date', { ascending: false });
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_exchange_rates').delete().eq('exchange_rate_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, rate: Number(values.rate), is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_exchange_rates').update(payload).eq('exchange_rate_id', editing.exchange_rate_id)
      : await supabase.from('lookup_exchange_rates').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Exchange Rates" description="Currency exchange rates for multi-currency payroll."
        columns={COLS} data={data} loading={loading} idKey="exchange_rate_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search rates…" searchKeys={['from_currency_code','to_currency_code']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Exchange Rate' : 'Add Exchange Rate'}
        fields={FIELDS}
        defaultValues={editing ?? { source: 'MANUAL', is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
