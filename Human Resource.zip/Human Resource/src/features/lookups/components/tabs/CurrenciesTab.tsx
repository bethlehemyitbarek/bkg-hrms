import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type Currency = {
  currency_id: string; currency_code: string; currency_name: string;
  currency_symbol: string; decimal_places: number; is_active: boolean;
};

const COLS: ColDef<Currency>[] = [
  { key: 'currency_code',   label: 'Code',    className: 'w-20 font-mono font-semibold' },
  { key: 'currency_name',   label: 'Name' },
  { key: 'currency_symbol', label: 'Symbol',  className: 'w-16 text-center' },
  { key: 'decimal_places',  label: 'Decimals',className: 'w-20 text-center' },
  { key: 'is_active',       label: 'Status',  render: r => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'currency_code',   label: 'ISO-4217 Code', type: 'text',   required: true, placeholder: 'ETB' },
  { name: 'currency_name',   label: 'Currency Name', type: 'text',   required: true },
  { name: 'currency_symbol', label: 'Symbol',        type: 'text',   placeholder: 'Br' },
  { name: 'decimal_places',  label: 'Decimal Places',type: 'number', placeholder: '2' },
  { name: 'is_active',       label: 'Active',        type: 'switch' },
];

export function CurrenciesTab() {
  const [data, setData]       = useState<Currency[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<Currency | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_currencies').select('*').order('currency_code');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_currencies').delete().eq('currency_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, decimal_places: Number(values.decimal_places ?? 2), is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_currencies').update(payload).eq('currency_id', editing.currency_id)
      : await supabase.from('lookup_currencies').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Currencies" description="ISO 4217 currency reference for payroll and compensation."
        columns={COLS} data={data} loading={loading} idKey="currency_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search currencies…" searchKeys={['currency_code','currency_name']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Currency' : 'Add Currency'}
        fields={FIELDS}
        defaultValues={editing ?? { decimal_places: 2, is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
