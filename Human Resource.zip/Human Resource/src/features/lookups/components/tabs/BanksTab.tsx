﻿import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type Bank = { bank_id: string; bank_name: string; is_active: boolean };

const COLS: ColDef<Bank>[] = [
  { key: 'bank_name', label: 'Bank' },
  { key: 'is_active', label: 'Status', render: (row) => <ActiveBadge value={row.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'bank_name', label: 'Bank', type: 'text', required: true },
  { name: 'is_active', label: 'Active', type: 'switch' },
];

export function BanksTab() {
  const [data, setData] = useState<Bank[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState<Bank | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_banks').select('*').order('bank_name');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_banks').update({ is_deleted: true }).eq('bank_id', id);
    if (error) toast.error(error.message);
    else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_banks').update(payload).eq('bank_id', editing.bank_id)
      : await supabase.from('lookup_banks').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Banks" description="Maintain bank master data for salary and payment routing."
        columns={COLS} data={data} loading={loading} idKey="bank_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={(row) => { setEditing(row); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search banks…" searchKeys={['bank_name']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Bank' : 'Add Bank'}
        fields={FIELDS}
        defaultValues={editing ?? { is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
