import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type TaxBracket = {
  tax_bracket_id: string; tax_jurisdiction: string; bracket_name: string;
  min_income: number; max_income: number | null; tax_rate: number;
  fixed_amount: number; effective_from: string; effective_to: string | null; is_active: boolean;
};

const COLS: ColDef<TaxBracket>[] = [
  { key: 'tax_jurisdiction', label: 'Jurisdiction' },
  { key: 'bracket_name',     label: 'Bracket' },
  { key: 'min_income',       label: 'Min Income',   render: r => Number(r.min_income).toLocaleString() },
  { key: 'max_income',       label: 'Max Income',   render: r => r.max_income ? Number(r.max_income).toLocaleString() : 'Unlimited' },
  { key: 'tax_rate',         label: 'Rate',         render: r => `${(Number(r.tax_rate) * 100).toFixed(0)}%` },
  { key: 'fixed_amount',     label: 'Fixed Amt',    render: r => Number(r.fixed_amount).toLocaleString() },
  { key: 'effective_from',   label: 'Effective' },
  { key: 'is_active',        label: 'Status',       render: r => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'tax_jurisdiction', label: 'Jurisdiction',    type: 'text',   required: true, placeholder: 'ETHIOPIA' },
  { name: 'bracket_name',     label: 'Bracket Name',   type: 'text',   required: true },
  { name: 'min_income',       label: 'Min Income',     type: 'number', required: true },
  { name: 'max_income',       label: 'Max Income (leave blank for unlimited)', type: 'number' },
  { name: 'tax_rate',         label: 'Tax Rate (e.g. 0.10 = 10%)', type: 'number', required: true },
  { name: 'fixed_amount',     label: 'Fixed Amount',   type: 'number' },
  { name: 'effective_from',   label: 'Effective From', type: 'date',   required: true },
  { name: 'effective_to',     label: 'Effective To',   type: 'date' },
  { name: 'is_active',        label: 'Active',         type: 'switch' },
];

export function TaxBracketsTab() {
  const [data, setData]       = useState<TaxBracket[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<TaxBracket | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase
      .from('lookup_tax_brackets').select('*').eq('is_deleted', false)
      .order('tax_jurisdiction').order('min_income');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_tax_brackets').update({ is_deleted: true }).eq('tax_bracket_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = {
      ...values,
      min_income:    Number(values.min_income),
      max_income:    values.max_income    ? Number(values.max_income)    : null,
      tax_rate:      Number(values.tax_rate),
      fixed_amount:  values.fixed_amount  ? Number(values.fixed_amount)  : 0,
      effective_to:  values.effective_to  || null,
      is_active:     Boolean(values.is_active),
      updated_at:    new Date().toISOString(),
    };
    const { error } = editing
      ? await supabase.from('lookup_tax_brackets').update(payload).eq('tax_bracket_id', editing.tax_bracket_id)
      : await supabase.from('lookup_tax_brackets').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Tax Brackets" description="Income tax brackets for payroll tax calculation by jurisdiction."
        columns={COLS} data={data} loading={loading} idKey="tax_bracket_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search brackets…" searchKeys={['tax_jurisdiction', 'bracket_name']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Tax Bracket' : 'Add Tax Bracket'}
        fields={FIELDS}
        defaultValues={editing ?? { tax_jurisdiction: 'ETHIOPIA', fixed_amount: 0, is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
