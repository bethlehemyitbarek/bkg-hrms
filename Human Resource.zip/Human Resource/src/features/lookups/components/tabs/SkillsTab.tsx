import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type Skill = {
  skill_id: string; skill_code: string; skill_name: string;
  skill_category: string; description: string; is_active: boolean;
};

const CATEGORY_OPTIONS = [
  { value: 'TECHNICAL',     label: 'Technical' },
  { value: 'SOFT',          label: 'Soft Skill' },
  { value: 'LEADERSHIP',    label: 'Leadership' },
  { value: 'DOMAIN',        label: 'Domain' },
  { value: 'LANGUAGE',      label: 'Language' },
  { value: 'CERTIFICATION', label: 'Certification' },
];

const COLS: ColDef<Skill>[] = [
  { key: 'skill_code',     label: 'Code',     className: 'font-mono w-28' },
  { key: 'skill_name',     label: 'Skill Name' },
  { key: 'skill_category', label: 'Category' },
  { key: 'is_active',      label: 'Status',   render: r => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'skill_code',     label: 'Skill Code',  type: 'text',   required: true, placeholder: 'PYTHON' },
  { name: 'skill_name',     label: 'Skill Name',  type: 'text',   required: true },
  { name: 'skill_category', label: 'Category',    type: 'select', options: CATEGORY_OPTIONS, required: true },
  { name: 'description',    label: 'Description', type: 'textarea' },
  { name: 'is_active',      label: 'Active',      type: 'switch' },
];

export function SkillsTab() {
  const [data, setData]       = useState<Skill[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<Skill | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_skills').select('*').eq('is_deleted', false).order('skill_name');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_skills').update({ is_deleted: true }).eq('skill_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_skills').update(payload).eq('skill_id', editing.skill_id)
      : await supabase.from('lookup_skills').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Skills" description="Master skill library for competency tracking and recruitment matching."
        columns={COLS} data={data} loading={loading} idKey="skill_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search skills…" searchKeys={['skill_name', 'skill_code', 'skill_category']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Skill' : 'Add Skill'}
        fields={FIELDS}
        defaultValues={editing ?? { skill_category: 'TECHNICAL', is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
