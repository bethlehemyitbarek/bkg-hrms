import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type Bank     = { bank_id: string; bank_name: string };
type Branch   = {
  bank_branch_id: string; bank_id: string; branch_code: string;
  branch_name: string; city: string; address: string; is_active: boolean;
};

export function BankBranchesTab() {
  const [banks, setBanks]     = useState<Bank[]>([]);
  const [data, setData]       = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<Branch | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: bankRows }, { data: rows }] = await Promise.all([
      supabase.from('lookup_banks').select('bank_id, bank_name').eq('is_active', true).order('bank_name'),
      supabase.from('lookup_bank_branches').select('*, lookup_banks(bank_name)').eq('is_deleted', false).order('branch_name'),
    ]);
    setBanks(Array.isArray(bankRows) ? bankRows : []);
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const bankOptions = banks.map(b => ({ value: b.bank_id, label: b.bank_name }));

  const getBankName = (id: string) => banks.find(b => b.bank_id === id)?.bank_name ?? id;

  const COLS: ColDef<Branch>[] = [
    { key: 'bank_id',     label: 'Bank',         render: r => getBankName(r.bank_id) },
    { key: 'branch_code', label: 'Branch Code',  className: 'font-mono' },
    { key: 'branch_name', label: 'Branch Name' },
    { key: 'city',        label: 'City' },
    { key: 'is_active',   label: 'Status',       render: r => <ActiveBadge value={r.is_active} /> },
  ];

  const FIELDS: FieldDef[] = [
    { name: 'bank_id',      label: 'Bank',          type: 'select', options: bankOptions, required: true },
    { name: 'branch_code',  label: 'Branch Code',   type: 'text',   required: true },
    { name: 'branch_name',  label: 'Branch Name',   type: 'text',   required: true },
    { name: 'city',         label: 'City',          type: 'text' },
    { name: 'address',      label: 'Address',       type: 'textarea' },
    { name: 'is_active',    label: 'Active',        type: 'switch' },
  ];

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_bank_branches').update({ is_deleted: true }).eq('bank_branch_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_bank_branches').update(payload).eq('bank_branch_id', editing.bank_branch_id)
      : await supabase.from('lookup_bank_branches').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Bank Branches" description="Bank branch details for precise salary routing."
        columns={COLS} data={data} loading={loading} idKey="bank_branch_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search branches…" searchKeys={['branch_name','branch_code','city']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Bank Branch' : 'Add Bank Branch'}
        fields={FIELDS}
        defaultValues={editing ?? { is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
