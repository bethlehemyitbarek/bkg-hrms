import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type Grade = {
  grade_id: string; grade_code: string; grade_name: string; grade_level: number;
  min_salary: number; mid_salary: number; max_salary: number;
  currency_code: string; effective_from: string; effective_to: string | null; is_active: boolean;
};

const COLS: ColDef<Grade>[] = [
  { key: 'grade_code',     label: 'Code',       className: 'font-mono w-20' },
  { key: 'grade_name',     label: 'Grade Name' },
  { key: 'grade_level',    label: 'Level',      className: 'text-center w-16' },
  { key: 'min_salary',     label: 'Min Salary', render: r => r.min_salary ? Number(r.min_salary).toLocaleString() : '—' },
  { key: 'mid_salary',     label: 'Mid Salary', render: r => r.mid_salary ? Number(r.mid_salary).toLocaleString() : '—' },
  { key: 'max_salary',     label: 'Max Salary', render: r => r.max_salary ? Number(r.max_salary).toLocaleString() : '—' },
  { key: 'currency_code',  label: 'Currency',   className: 'font-mono w-20' },
  { key: 'effective_from', label: 'Effective' },
  { key: 'is_active',      label: 'Status',     render: r => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'grade_code',     label: 'Grade Code',     type: 'text',   required: true, placeholder: 'G5' },
  { name: 'grade_name',     label: 'Grade Name',     type: 'text',   required: true, placeholder: 'Grade 5' },
  { name: 'grade_level',    label: 'Level (number)', type: 'number', required: true, placeholder: '5' },
  { name: 'min_salary',     label: 'Min Salary',     type: 'number' },
  { name: 'mid_salary',     label: 'Mid Salary',     type: 'number' },
  { name: 'max_salary',     label: 'Max Salary',     type: 'number' },
  { name: 'currency_code',  label: 'Currency',       type: 'text',   placeholder: 'ETB' },
  { name: 'effective_from', label: 'Effective From', type: 'date',   required: true },
  { name: 'effective_to',   label: 'Effective To',   type: 'date' },
  { name: 'description',    label: 'Description',    type: 'textarea' },
  { name: 'is_active',      label: 'Active',         type: 'switch' },
];

export function GradesTab() {
  const [data, setData]       = useState<Grade[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<Grade | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_grades').select('*').eq('is_deleted', false).order('grade_level');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_grades').update({ is_deleted: true }).eq('grade_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = {
      ...values,
      grade_level: Number(values.grade_level),
      min_salary:  values.min_salary  ? Number(values.min_salary)  : null,
      mid_salary:  values.mid_salary  ? Number(values.mid_salary)  : null,
      max_salary:  values.max_salary  ? Number(values.max_salary)  : null,
      effective_to: values.effective_to || null,
      is_active: Boolean(values.is_active),
      updated_at: new Date().toISOString(),
    };
    const { error } = editing
      ? await supabase.from('lookup_grades').update(payload).eq('grade_id', editing.grade_id)
      : await supabase.from('lookup_grades').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Grades" description="Master grade / level structure defining hierarchy and associated salary bands."
        columns={COLS} data={data} loading={loading} idKey="grade_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search grades…" searchKeys={['grade_code', 'grade_name']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Grade' : 'Add Grade'}
        fields={FIELDS}
        defaultValues={editing ?? { currency_code: 'ETB', is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
