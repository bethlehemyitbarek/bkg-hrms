﻿import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type JobTitle = { job_title_id: string; job_title_code: string; job_title_name: string; is_active: boolean };

const COLS: ColDef<JobTitle>[] = [
  { key: 'job_title_code', label: 'Code', className: 'font-mono w-24' },
  { key: 'job_title_name', label: 'Job Title' },
  { key: 'is_active', label: 'Status', render: (row) => <ActiveBadge value={row.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'job_title_code', label: 'Code', type: 'text', required: true, placeholder: 'HRBP' },
  { name: 'job_title_name', label: 'Job Title', type: 'text', required: true, placeholder: 'HR Business Partner' },
  { name: 'is_active', label: 'Active', type: 'switch' },
];

export function JobTitlesTab() {
  const [data, setData] = useState<JobTitle[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState<JobTitle | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_job_titles').select('*').order('job_title_code');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_job_titles').update({ is_deleted: true }).eq('job_title_id', id);
    if (error) toast.error(error.message);
    else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_job_titles').update(payload).eq('job_title_id', editing.job_title_id)
      : await supabase.from('lookup_job_titles').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Job Titles" description="Define job titles used by the organization."
        columns={COLS} data={data} loading={loading} idKey="job_title_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={(row) => { setEditing(row); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search job titles…" searchKeys={['job_title_name', 'job_title_code']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Job Title' : 'Add Job Title'}
        fields={FIELDS}
        defaultValues={editing ?? { is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
