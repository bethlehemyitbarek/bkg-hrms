import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type Grade = { grade_id: string; grade_code: string; grade_name: string };
type Step = {
  step_id: string; grade_id: string; step_number: number;
  step_amount: number; years_in_grade_required: number | null;
  effective_from: string; effective_to: string | null; is_active: boolean;
};

export function StepsTab() {
  const [grades, setGrades]   = useState<Grade[]>([]);
  const [data, setData]       = useState<Step[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<Step | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: gradeRows }, { data: rows }] = await Promise.all([
      supabase.from('lookup_grades').select('grade_id, grade_code, grade_name').eq('is_active', true).order('grade_level'),
      supabase.from('lookup_steps').select('*').eq('is_deleted', false).order('grade_id').order('step_number'),
    ]);
    setGrades(Array.isArray(gradeRows) ? gradeRows : []);
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const gradeOptions = grades.map(g => ({ value: g.grade_id, label: `${g.grade_code} – ${g.grade_name}` }));
  const getGradeLabel = (id: string) => {
    const g = grades.find(gr => gr.grade_id === id);
    return g ? `${g.grade_code} – ${g.grade_name}` : id;
  };

  const COLS: ColDef<Step>[] = [
    { key: 'grade_id',               label: 'Grade',            render: r => getGradeLabel(r.grade_id) },
    { key: 'step_number',             label: 'Step',             className: 'text-center w-16' },
    { key: 'step_amount',             label: 'Amount',           render: r => Number(r.step_amount).toLocaleString() },
    { key: 'years_in_grade_required', label: 'Yrs Required',    render: r => r.years_in_grade_required ?? '—' },
    { key: 'effective_from',          label: 'Effective From' },
    { key: 'is_active',               label: 'Status',           render: r => <ActiveBadge value={r.is_active} /> },
  ];

  const FIELDS: FieldDef[] = [
    { name: 'grade_id',               label: 'Grade',                   type: 'select', options: gradeOptions, required: true },
    { name: 'step_number',             label: 'Step Number',             type: 'number', required: true, placeholder: '1' },
    { name: 'step_amount',             label: 'Step Amount',             type: 'number', required: true, placeholder: '5000' },
    { name: 'years_in_grade_required', label: 'Years in Grade Required', type: 'number' },
    { name: 'effective_from',          label: 'Effective From',          type: 'date',   required: true },
    { name: 'effective_to',            label: 'Effective To',            type: 'date' },
    { name: 'is_active',               label: 'Active',                  type: 'switch' },
  ];

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_steps').update({ is_deleted: true }).eq('step_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = {
      ...values,
      step_number:             Number(values.step_number),
      step_amount:             Number(values.step_amount),
      years_in_grade_required: values.years_in_grade_required ? Number(values.years_in_grade_required) : null,
      effective_to:            values.effective_to || null,
      is_active:               Boolean(values.is_active),
      updated_at:              new Date().toISOString(),
    };
    const { error } = editing
      ? await supabase.from('lookup_steps').update(payload).eq('step_id', editing.step_id)
      : await supabase.from('lookup_steps').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Grade Steps" description="Salary steps within a grade for progression within the same level."
        columns={COLS} data={data} loading={loading} idKey="step_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search steps…" searchKeys={[]}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Grade Step' : 'Add Grade Step'}
        fields={FIELDS}
        defaultValues={editing ?? { is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
