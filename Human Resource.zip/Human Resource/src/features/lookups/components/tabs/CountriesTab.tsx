import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type Country = {
  country_id: string; country_code: string; country_code_2: string;
  country_name: string; nationality_name: string; phone_code: string;
  currency_code: string; region_name: string; is_active: boolean;
};

const COLS: ColDef<Country>[] = [
  { key: 'country_code',    label: 'ISO-3', className: 'w-16 font-mono' },
  { key: 'country_code_2',  label: 'ISO-2', className: 'w-14 font-mono' },
  { key: 'country_name',    label: 'Country' },
  { key: 'nationality_name',label: 'Nationality' },
  { key: 'phone_code',      label: 'Dial' },
  { key: 'currency_code',   label: 'Currency', className: 'font-mono' },
  { key: 'region_name',     label: 'Region' },
  { key: 'is_active',       label: 'Status', render: (r: Country) => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'country_code',     label: 'ISO-3 Code',     type: 'text',   required: true, placeholder: 'ETH' },
  { name: 'country_code_2',   label: 'ISO-2 Code',     type: 'text',   required: true, placeholder: 'ET' },
  { name: 'country_name',     label: 'Country Name',   type: 'text',   required: true },
  { name: 'nationality_name', label: 'Nationality',    type: 'text' },
  { name: 'phone_code',       label: 'Phone Code',     type: 'text',   placeholder: '+251' },
  { name: 'currency_code',    label: 'Currency Code',  type: 'text',   placeholder: 'ETB' },
  { name: 'region_name',      label: 'Region',         type: 'text' },
  { name: 'is_active',        label: 'Active',         type: 'switch' },
];

export function CountriesTab() {
  const [data, setData]       = useState<Country[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<Country | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_countries').select('*').order('country_name');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const openAdd  = () => { setEditing(null); setOpen(true); };
  const openEdit = (row: Country) => { setEditing(row); setOpen(true); };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_countries').delete().eq('country_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_countries').update(payload).eq('country_id', editing.country_id)
      : await supabase.from('lookup_countries').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false);
    load();
  };

  return (
    <>
      <LookupTable
        title="Countries" description="ISO country reference used across the system."
        columns={COLS} data={data} loading={loading} idKey="country_id"
        onAdd={openAdd} onEdit={openEdit} onDelete={handleDelete}
        searchPlaceholder="Search countries…" searchKeys={['country_name','country_code']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Country' : 'Add Country'}
        fields={FIELDS}
        defaultValues={editing ?? { is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
