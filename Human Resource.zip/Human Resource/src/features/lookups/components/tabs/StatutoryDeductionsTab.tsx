import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';
import { Badge } from '@/components/ui/badge';

type StatutoryDeduction = {
  deduction_type_id: string; deduction_code: string; deduction_name: string;
  deduction_category: string; calculation_method: string; rate_or_amount: number | null;
  applies_to: string; is_mandatory: boolean; effective_from: string;
  effective_to: string | null; statutory_reference: string; is_active: boolean;
};

const CATEGORY_OPTIONS = [
  { value: 'TAX',               label: 'Tax' },
  { value: 'PENSION',           label: 'Pension' },
  { value: 'SOCIAL_SECURITY',   label: 'Social Security' },
  { value: 'PROFESSIONAL_TAX',  label: 'Professional Tax' },
  { value: 'UNION_FEE',         label: 'Union Fee' },
  { value: 'OTHER_STATUTORY',   label: 'Other Statutory' },
];

const CALC_OPTIONS = [
  { value: 'PERCENTAGE',   label: 'Percentage' },
  { value: 'FIXED',        label: 'Fixed Amount' },
  { value: 'TABLE_LOOKUP', label: 'Table Lookup' },
];

const APPLIES_OPTIONS = [
  { value: 'EMPLOYEE', label: 'Employee' },
  { value: 'EMPLOYER', label: 'Employer' },
  { value: 'BOTH',     label: 'Both' },
];

const CATEGORY_COLORS: Record<string, string> = {
  TAX:              'bg-red-100 text-red-700',
  PENSION:          'bg-blue-100 text-blue-700',
  SOCIAL_SECURITY:  'bg-purple-100 text-purple-700',
  PROFESSIONAL_TAX: 'bg-orange-100 text-orange-700',
  UNION_FEE:        'bg-yellow-100 text-yellow-700',
  OTHER_STATUTORY:  'bg-muted text-muted-foreground',
};

const COLS: ColDef<StatutoryDeduction>[] = [
  { key: 'deduction_code',     label: 'Code',       className: 'font-mono w-28' },
  { key: 'deduction_name',     label: 'Name' },
  { key: 'deduction_category', label: 'Category',
    render: r => (
      <Badge variant="secondary" className={`text-xs border-0 ${CATEGORY_COLORS[r.deduction_category] ?? ''}`}>
        {r.deduction_category.replace(/_/g,' ')}
      </Badge>
    ),
  },
  { key: 'calculation_method', label: 'Method' },
  { key: 'rate_or_amount',     label: 'Rate / Amt', render: r => r.rate_or_amount != null ? Number(r.rate_or_amount).toString() : '—' },
  { key: 'applies_to',         label: 'Applies To' },
  { key: 'is_mandatory',       label: 'Mandatory',  render: r => r.is_mandatory ? <span className="text-primary text-xs font-medium">Yes</span> : <span className="text-muted-foreground text-xs">No</span> },
  { key: 'is_active',          label: 'Status',     render: r => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'deduction_code',     label: 'Deduction Code',    type: 'text',    required: true },
  { name: 'deduction_name',     label: 'Deduction Name',    type: 'text',    required: true },
  { name: 'deduction_category', label: 'Category',          type: 'select',  options: CATEGORY_OPTIONS, required: true },
  { name: 'calculation_method', label: 'Calculation Method',type: 'select',  options: CALC_OPTIONS,     required: true },
  { name: 'rate_or_amount',     label: 'Rate or Amount',    type: 'number',  placeholder: '0.07' },
  { name: 'applies_to',         label: 'Applies To',        type: 'select',  options: APPLIES_OPTIONS },
  { name: 'is_mandatory',       label: 'Mandatory',         type: 'switch' },
  { name: 'effective_from',     label: 'Effective From',    type: 'date',    required: true },
  { name: 'effective_to',       label: 'Effective To',      type: 'date' },
  { name: 'statutory_reference',label: 'Statutory Reference',type:'textarea' },
  { name: 'is_active',          label: 'Active',            type: 'switch' },
];

export function StatutoryDeductionsTab() {
  const [data, setData]       = useState<StatutoryDeduction[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<StatutoryDeduction | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_statutory_deductions').select('*').eq('is_deleted', false).order('deduction_name');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_statutory_deductions').update({ is_deleted: true }).eq('deduction_type_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = {
      ...values,
      rate_or_amount: values.rate_or_amount ? Number(values.rate_or_amount) : null,
      effective_to:   values.effective_to || null,
      is_mandatory:   Boolean(values.is_mandatory),
      is_active:      Boolean(values.is_active),
      updated_at:     new Date().toISOString(),
    };
    const { error } = editing
      ? await supabase.from('lookup_statutory_deductions').update(payload).eq('deduction_type_id', editing.deduction_type_id)
      : await supabase.from('lookup_statutory_deductions').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Statutory Deductions" description="Master list of mandatory deductions (pension, tax, social security, etc.)."
        columns={COLS} data={data} loading={loading} idKey="deduction_type_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search deductions…" searchKeys={['deduction_name', 'deduction_code']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Statutory Deduction' : 'Add Statutory Deduction'}
        fields={FIELDS}
        defaultValues={editing ?? { applies_to: 'BOTH', calculation_method: 'PERCENTAGE', is_mandatory: true, is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
