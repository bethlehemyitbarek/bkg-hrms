import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { LookupTable, ActiveBadge, ColDef } from '../LookupTable';
import { LookupFormDialog, FieldDef } from '../LookupFormDialog';

type Ethnicity = { ethnicity_id: string; ethnicity_name: string; is_active: boolean };

const COLS: ColDef<Ethnicity>[] = [
  { key: 'ethnicity_name', label: 'Ethnicity' },
  { key: 'is_active',      label: 'Status', render: r => <ActiveBadge value={r.is_active} /> },
];

const FIELDS: FieldDef[] = [
  { name: 'ethnicity_name', label: 'Ethnicity Name', type: 'text',   required: true },
  { name: 'is_active',      label: 'Active',         type: 'switch' },
];

export function EthnicitiesTab() {
  const [data, setData]       = useState<Ethnicity[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [editing, setEditing] = useState<Ethnicity | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: rows } = await supabase.from('lookup_ethnicities').select('*').eq('is_deleted', false).order('ethnicity_name');
    setData(Array.isArray(rows) ? rows : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lookup_ethnicities').update({ is_deleted: true }).eq('ethnicity_id', id);
    if (error) toast.error(error.message); else { toast.success('Deleted'); load(); }
  };

  const handleSubmit = async (values: Record<string, unknown>) => {
    setSaving(true);
    const payload = { ...values, is_active: Boolean(values.is_active), updated_at: new Date().toISOString() };
    const { error } = editing
      ? await supabase.from('lookup_ethnicities').update(payload).eq('ethnicity_id', editing.ethnicity_id)
      : await supabase.from('lookup_ethnicities').insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? 'Updated' : 'Created');
    setOpen(false); load();
  };

  return (
    <>
      <LookupTable
        title="Ethnicities" description="Ethnic group reference for demographic reporting."
        columns={COLS} data={data} loading={loading} idKey="ethnicity_id"
        onAdd={() => { setEditing(null); setOpen(true); }}
        onEdit={r => { setEditing(r); setOpen(true); }}
        onDelete={handleDelete}
        searchPlaceholder="Search ethnicities…" searchKeys={['ethnicity_name']}
      />
      <LookupFormDialog
        open={open} onOpenChange={setOpen}
        title={editing ? 'Edit Ethnicity' : 'Add Ethnicity'}
        fields={FIELDS}
        defaultValues={editing ?? { is_active: true }}
        onSubmit={handleSubmit} saving={saving}
      />
    </>
  );
}
