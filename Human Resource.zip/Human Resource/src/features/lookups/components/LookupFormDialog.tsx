import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Form, FormField, FormItem, FormLabel, FormControl, FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Loader2 } from 'lucide-react';

export type FieldDef =
  | { name: string; label: string; type: 'text' | 'number' | 'date'; required?: boolean; placeholder?: string }
  | { name: string; label: string; type: 'textarea'; required?: boolean; placeholder?: string }
  | { name: string; label: string; type: 'select'; options: { value: string; label: string }[]; required?: boolean }
  | { name: string; label: string; type: 'switch' };

interface LookupFormDialogProps {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  title: string;
  fields: FieldDef[];
  defaultValues?: Record<string, unknown>;
  onSubmit: (values: Record<string, unknown>) => Promise<void>;
  saving: boolean;
}

export function LookupFormDialog({
  open, onOpenChange, title, fields, defaultValues, onSubmit, saving,
}: LookupFormDialogProps) {
  const form = useForm<Record<string, unknown>>({ defaultValues: defaultValues ?? {} });

  useEffect(() => {
    if (open) form.reset(defaultValues ?? {});
  }, [open, defaultValues]); // eslint-disable-line react-hooks/exhaustive-deps

  async function handleSubmit(values: Record<string, unknown>) {
    await onSubmit(values);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 py-2">
            {fields.map(field => (
              <FormField
                key={field.name}
                control={form.control}
                name={field.name}
                rules={('required' in field && field.required) ? { required: `${field.label} is required` } : {}}
                render={({ field: f }) => (
                  <FormItem>
                    <FormLabel>{field.label}{('required' in field && field.required) ? ' *' : ''}</FormLabel>
                    <FormControl>
                      {field.type === 'textarea' ? (
                        <Textarea
                          {...f}
                          value={String(f.value ?? '')}
                          placeholder={'placeholder' in field ? field.placeholder : ''}
                          className="resize-none"
                          rows={3}
                        />
                      ) : field.type === 'select' ? (
                        <Select
                          value={String(f.value ?? '')}
                          onValueChange={f.onChange}
                        >
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {field.options.map(o => (
                              <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : field.type === 'switch' ? (
                        <div className="flex items-center h-9">
                          <Switch
                            checked={Boolean(f.value)}
                            onCheckedChange={f.onChange}
                          />
                        </div>
                      ) : (
                        <Input
                          {...f}
                          type={field.type}
                          value={String(f.value ?? '')}
                          placeholder={'placeholder' in field ? field.placeholder : ''}
                        />
                      )}
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            ))}
            <DialogFooter className="pt-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>
                {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Save
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
