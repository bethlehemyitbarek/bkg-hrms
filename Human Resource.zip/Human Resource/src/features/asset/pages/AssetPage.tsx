// AssetPage — Module 8.7 Asset + 8.8 AssetAssignment
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Package, Eye, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

type Asset = {
  id: string; asset_id: string; asset_tag: string; asset_name: string;
  asset_category: string; serial_number?: string; purchase_date?: string;
  asset_status: string; created_at: string;
};
type Assignment = {
  id: string; asset_assignment_id: string; asset_id: string;
  assigned_date: string; returned_date?: string;
  assignment_status: string; condition_notes?: string; created_at: string;
  asset?: { asset_name: string; asset_tag: string; asset_category: string };
  employee?: { first_name: string; last_name: string; employee_no?: string };
};

const ASSET_STATUS_COLORS: Record<string, string> = {
  AVAILABLE: 'bg-green-100 text-green-800',
  ASSIGNED: 'bg-blue-100 text-blue-800',
  MAINTENANCE: 'bg-yellow-100 text-yellow-800',
  RETIRED: 'bg-muted text-muted-foreground',
};
const ASSIGN_STATUS_COLORS: Record<string, string> = {
  ASSIGNED: 'bg-blue-100 text-blue-800',
  RETURNED: 'bg-green-100 text-green-800',
  LOST: 'bg-red-100 text-red-800',
  DAMAGED: 'bg-orange-100 text-orange-800',
};

export function AssetPage() {
  const [tab, setTab] = useState('assets');

  // Assets
  const [assets, setAssets] = useState<Asset[]>([]);
  const [assetsLoading, setAssetsLoading] = useState(true);
  const [assetSearch, setAssetSearch] = useState('');
  const [assetCatFilter, setAssetCatFilter] = useState('all');
  const [assetStatusFilter, setAssetStatusFilter] = useState('all');

  // Assignments
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [assignLoading, setAssignLoading] = useState(false);
  const [assignSearch, setAssignSearch] = useState('');
  const [assignStatusFilter, setAssignStatusFilter] = useState('all');

  // Employees
  const [employees, setEmployees] = useState<{ id: string; first_name: string; last_name: string; employee_no?: string }[]>([]);

  // Create asset dialog
  const [createAssetOpen, setCreateAssetOpen] = useState(false);
  const [assetForm, setAssetForm] = useState({ asset_tag: '', asset_name: '', asset_category: 'LAPTOP', serial_number: '', purchase_date: '' });
  const [assetSaving, setAssetSaving] = useState(false);

  // Create assignment dialog
  const [createAssignOpen, setCreateAssignOpen] = useState(false);
  const [assignForm, setAssignForm] = useState({ asset_id: '', employee_id: '', assigned_date: new Date().toISOString().split('T')[0], condition_notes: '' });
  const [assignSaving, setAssignSaving] = useState(false);

  // Detail dialog
  const [assetDetail, setAssetDetail] = useState<Asset | null>(null);
  const [assetHistory, setAssetHistory] = useState<Assignment[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Stats
  const available = assets.filter(a => a.asset_status === 'AVAILABLE').length;
  const assigned = assets.filter(a => a.asset_status === 'ASSIGNED').length;
  const maintenance = assets.filter(a => a.asset_status === 'MAINTENANCE').length;

  const loadAssets = useCallback(async () => {
    setAssetsLoading(true);
    try {
      let q = sb.from('assets').select('id,asset_id,asset_tag,asset_name,asset_category,serial_number,purchase_date,asset_status,created_at')
        .eq('is_deleted', 0).order('created_at', { ascending: false });
      if (assetCatFilter !== 'all') q = q.eq('asset_category', assetCatFilter);
      if (assetStatusFilter !== 'all') q = q.eq('asset_status', assetStatusFilter);
      const { data, error } = await q;
      if (error) throw error;
      setAssets(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setAssetsLoading(false); }
  }, [assetCatFilter, assetStatusFilter]);

  const loadAssignments = useCallback(async () => {
    setAssignLoading(true);
    try {
      let q = sb.from('asset_assignments')
        .select('id,asset_assignment_id,asset_id,assigned_date,returned_date,assignment_status,condition_notes,created_at,asset:assets(asset_name,asset_tag,asset_category),employee:employees(first_name,last_name,employee_no)')
        .eq('is_deleted', 0).order('created_at', { ascending: false });
      if (assignStatusFilter !== 'all') q = q.eq('assignment_status', assignStatusFilter);
      const { data, error } = await q;
      if (error) throw error;
      setAssignments(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setAssignLoading(false); }
  }, [assignStatusFilter]);

  const loadEmployees = useCallback(async () => {
    const { data } = await sb.from('employees').select('id,first_name,last_name,employee_no').eq('status', 'active').order('first_name').limit(200);
    setEmployees(Array.isArray(data) ? data : []);
  }, []);

  const loadAssetHistory = useCallback(async (assetId: string) => {
    setHistoryLoading(true);
    const { data } = await sb.from('asset_assignments')
      .select('id,asset_assignment_id,assigned_date,returned_date,assignment_status,condition_notes,employee:employees(first_name,last_name,employee_no)')
      .eq('asset_id', assetId).eq('is_deleted', 0).order('assigned_date', { ascending: false });
    setAssetHistory(Array.isArray(data) ? data : []);
    setHistoryLoading(false);
  }, []);

  useEffect(() => { loadAssets(); loadEmployees(); }, [loadAssets, loadEmployees]);
  useEffect(() => { if (tab === 'assignments') loadAssignments(); }, [tab, loadAssignments]);

  const filteredAssets = assets.filter(a =>
    a.asset_name.toLowerCase().includes(assetSearch.toLowerCase()) ||
    a.asset_tag.toLowerCase().includes(assetSearch.toLowerCase()) ||
    (a.serial_number ?? '').toLowerCase().includes(assetSearch.toLowerCase())
  );
  const filteredAssignments = assignments.filter(a => {
    const str = `${a.employee?.first_name ?? ''} ${a.employee?.last_name ?? ''} ${a.asset?.asset_name ?? ''} ${a.asset?.asset_tag ?? ''}`.toLowerCase();
    return str.includes(assignSearch.toLowerCase());
  });

  async function createAsset() {
    if (!assetForm.asset_tag.trim() || !assetForm.asset_name.trim()) { toast.error('Tag and name are required'); return; }
    setAssetSaving(true);
    try {
      const { error } = await sb.from('assets').insert({
        asset_tag: assetForm.asset_tag.trim(),
        asset_name: assetForm.asset_name.trim(),
        asset_category: assetForm.asset_category,
        serial_number: assetForm.serial_number || null,
        purchase_date: assetForm.purchase_date || null,
        asset_status: 'AVAILABLE',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Asset added');
      setCreateAssetOpen(false);
      setAssetForm({ asset_tag: '', asset_name: '', asset_category: 'LAPTOP', serial_number: '', purchase_date: '' });
      loadAssets();
    } catch (e: any) { toast.error(e.message); } finally { setAssetSaving(false); }
  }

  async function createAssignment() {
    if (!assignForm.asset_id || !assignForm.employee_id) { toast.error('Asset and employee are required'); return; }
    setAssignSaving(true);
    try {
      const { error } = await sb.from('asset_assignments').insert({
        asset_id: assignForm.asset_id,
        employee_id: assignForm.employee_id,
        assigned_date: assignForm.assigned_date,
        condition_notes: assignForm.condition_notes || null,
        assignment_status: 'ASSIGNED',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      // Mark asset as ASSIGNED
      await sb.from('assets').update({ asset_status: 'ASSIGNED', updated_at: new Date().toISOString() }).eq('asset_id', assignForm.asset_id);
      toast.success('Asset assigned');
      setCreateAssignOpen(false);
      setAssignForm({ asset_id: '', employee_id: '', assigned_date: new Date().toISOString().split('T')[0], condition_notes: '' });
      loadAssignments(); loadAssets();
    } catch (e: any) { toast.error(e.message); } finally { setAssignSaving(false); }
  }

  async function returnAsset(assignId: string, assetId: string) {
    const { error } = await sb.from('asset_assignments').update({
      assignment_status: 'RETURNED', returned_date: new Date().toISOString().split('T')[0], updated_at: new Date().toISOString()
    }).eq('id', assignId);
    if (error) { toast.error(error.message); return; }
    await sb.from('assets').update({ asset_status: 'AVAILABLE', updated_at: new Date().toISOString() }).eq('asset_id', assetId);
    toast.success('Asset returned');
    loadAssignments(); loadAssets();
  }

  async function updateAssetStatus(assetId: string, newStatus: string) {
    const { error } = await sb.from('assets').update({ asset_status: newStatus, updated_at: new Date().toISOString() }).eq('id', assetId);
    if (error) toast.error(error.message);
    else { toast.success('Status updated'); loadAssets(); }
  }

  return (
    <div className="p-4 md:p-6 space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Asset Management</h1>
          <p className="text-sm text-muted-foreground">Manage company assets and employee assignments</p>
        </div>
        <div className="flex gap-2">
          {tab === 'assets' && <Button size="sm" onClick={() => setCreateAssetOpen(true)}><Plus className="w-4 h-4 mr-1" /> Add Asset</Button>}
          {tab === 'assignments' && <Button size="sm" onClick={() => { setCreateAssignOpen(true); }}><Plus className="w-4 h-4 mr-1" /> Assign Asset</Button>}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Assets', value: assets.length, icon: Package },
          { label: 'Available', value: available, icon: Package },
          { label: 'Assigned', value: assigned, icon: RefreshCw },
          { label: 'Maintenance', value: maintenance, icon: RefreshCw },
        ].map(s => (
          <Card key={s.label} className="h-full">
            <CardContent className="p-4 flex items-center gap-3">
              <s.icon className="w-8 h-8 text-primary shrink-0" />
              <div><p className="text-2xl font-bold">{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="assets">Assets</TabsTrigger>
          <TabsTrigger value="assignments">Assignments</TabsTrigger>
        </TabsList>

        {/* ── Assets Tab ── */}
        <TabsContent value="assets" className="mt-4 space-y-3">
          <div className="flex flex-col md:flex-row gap-2">
            <Input placeholder="Search by name, tag, serial…" value={assetSearch} onChange={e => setAssetSearch(e.target.value)} className="md:max-w-xs" />
            <Select value={assetCatFilter} onValueChange={setAssetCatFilter}>
              <SelectTrigger className="md:w-40"><SelectValue placeholder="All Categories" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {['LAPTOP','DESKTOP','PHONE','CARD','LICENSE','VEHICLE','OTHER'].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={assetStatusFilter} onValueChange={setAssetStatusFilter}>
              <SelectTrigger className="md:w-40"><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {['AVAILABLE','ASSIGNED','MAINTENANCE','RETIRED'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Tag</TableHead>
                  <TableHead className="whitespace-nowrap">Name</TableHead>
                  <TableHead className="whitespace-nowrap">Category</TableHead>
                  <TableHead className="whitespace-nowrap">Serial #</TableHead>
                  <TableHead className="whitespace-nowrap">Purchase Date</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assetsLoading ? (
                  Array.from({ length: 5 }).map((_, i) => <TableRow key={i}><TableCell colSpan={7}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>)
                ) : filteredAssets.length === 0 ? (
                  <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-10">No assets found.</TableCell></TableRow>
                ) : filteredAssets.map(a => (
                  <TableRow key={a.id}>
                    <TableCell className="whitespace-nowrap font-mono text-sm">{a.asset_tag}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">{a.asset_name}</TableCell>
                    <TableCell className="whitespace-nowrap">{a.asset_category}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{a.serial_number ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{a.purchase_date ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${ASSET_STATUS_COLORS[a.asset_status] ?? 'bg-muted text-muted-foreground'}`}>{a.asset_status}</Badge>
                    </TableCell>
                    <TableCell className="text-right whitespace-nowrap">
                      <Button size="sm" variant="ghost" onClick={() => { setAssetDetail(a); loadAssetHistory(a.asset_id); }}><Eye className="w-4 h-4" /></Button>
                      <Select onValueChange={v => updateAssetStatus(a.id, v)}>
                        <SelectTrigger className="h-7 text-xs w-28 inline-flex ml-1"><SelectValue placeholder="Status" /></SelectTrigger>
                        <SelectContent>
                          {['AVAILABLE','ASSIGNED','MAINTENANCE','RETIRED'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* ── Assignments Tab ── */}
        <TabsContent value="assignments" className="mt-4 space-y-3">
          <div className="flex flex-col md:flex-row gap-2">
            <Input placeholder="Search by employee or asset…" value={assignSearch} onChange={e => setAssignSearch(e.target.value)} className="md:max-w-xs" />
            <Select value={assignStatusFilter} onValueChange={setAssignStatusFilter}>
              <SelectTrigger className="md:w-44"><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {['ASSIGNED','RETURNED','LOST','DAMAGED'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Asset</TableHead>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Assigned Date</TableHead>
                  <TableHead className="whitespace-nowrap">Returned Date</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assignLoading ? (
                  Array.from({ length: 5 }).map((_, i) => <TableRow key={i}><TableCell colSpan={6}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>)
                ) : filteredAssignments.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-10">No assignments found.</TableCell></TableRow>
                ) : filteredAssignments.map(a => (
                  <TableRow key={a.id}>
                    <TableCell className="whitespace-nowrap">
                      <div className="font-medium">{a.asset?.asset_name ?? '—'}</div>
                      <div className="text-xs text-muted-foreground">{a.asset?.asset_tag}</div>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {a.employee ? `${a.employee.first_name} ${a.employee.last_name}` : '—'}
                      {a.employee?.employee_no && <span className="ml-1 text-xs text-muted-foreground">({a.employee.employee_no})</span>}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">{a.assigned_date}</TableCell>
                    <TableCell className="whitespace-nowrap">{a.returned_date ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${ASSIGN_STATUS_COLORS[a.assignment_status] ?? 'bg-muted text-muted-foreground'}`}>{a.assignment_status}</Badge>
                    </TableCell>
                    <TableCell className="text-right whitespace-nowrap">
                      {a.assignment_status === 'ASSIGNED' && (
                        <Button size="sm" variant="ghost" onClick={() => returnAsset(a.id, a.asset_id)}>Return</Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      {/* ── Asset Detail Dialog ── */}
      <Dialog open={!!assetDetail} onOpenChange={() => setAssetDetail(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>{assetDetail?.asset_name} — History</DialogTitle></DialogHeader>
          {assetDetail && (
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                <div><p className="text-muted-foreground">Tag</p><p className="font-mono">{assetDetail.asset_tag}</p></div>
                <div><p className="text-muted-foreground">Category</p><p>{assetDetail.asset_category}</p></div>
                <div><p className="text-muted-foreground">Serial #</p><p>{assetDetail.serial_number ?? '—'}</p></div>
                <div><p className="text-muted-foreground">Status</p>
                  <Badge className={`text-xs mt-1 ${ASSET_STATUS_COLORS[assetDetail.asset_status] ?? 'bg-muted text-muted-foreground'}`}>{assetDetail.asset_status}</Badge>
                </div>
              </div>
              <p className="font-medium">Assignment History</p>
              {historyLoading ? <Skeleton className="h-12 w-full bg-muted" /> : assetHistory.length === 0 ? (
                <p className="text-sm text-muted-foreground">No assignment history.</p>
              ) : (
                <div className="border rounded overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="whitespace-nowrap">Employee</TableHead>
                        <TableHead className="whitespace-nowrap">Assigned</TableHead>
                        <TableHead className="whitespace-nowrap">Returned</TableHead>
                        <TableHead className="whitespace-nowrap">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {assetHistory.map(h => (
                        <TableRow key={h.id}>
                          <TableCell className="whitespace-nowrap">{h.employee ? `${h.employee.first_name} ${h.employee.last_name}` : '—'}</TableCell>
                          <TableCell className="whitespace-nowrap">{h.assigned_date}</TableCell>
                          <TableCell className="whitespace-nowrap">{h.returned_date ?? '—'}</TableCell>
                          <TableCell><Badge className={`text-xs ${ASSIGN_STATUS_COLORS[h.assignment_status] ?? 'bg-muted text-muted-foreground'}`}>{h.assignment_status}</Badge></TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ── Create Asset Dialog ── */}
      <Dialog open={createAssetOpen} onOpenChange={setCreateAssetOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add New Asset</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Asset Tag *</Label><Input value={assetForm.asset_tag} onChange={e => setAssetForm(f => ({ ...f, asset_tag: e.target.value }))} placeholder="e.g. LPT-001" /></div>
              <div>
                <Label>Category *</Label>
                <Select value={assetForm.asset_category} onValueChange={v => setAssetForm(f => ({ ...f, asset_category: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['LAPTOP','DESKTOP','PHONE','CARD','LICENSE','VEHICLE','OTHER'].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Asset Name *</Label><Input value={assetForm.asset_name} onChange={e => setAssetForm(f => ({ ...f, asset_name: e.target.value }))} placeholder="e.g. MacBook Pro 14-inch" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Serial Number</Label><Input value={assetForm.serial_number} onChange={e => setAssetForm(f => ({ ...f, serial_number: e.target.value }))} /></div>
              <div><Label>Purchase Date</Label><Input type="date" value={assetForm.purchase_date} onChange={e => setAssetForm(f => ({ ...f, purchase_date: e.target.value }))} /></div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCreateAssetOpen(false)}>Cancel</Button>
              <Button onClick={createAsset} disabled={assetSaving}>{assetSaving ? 'Saving…' : 'Add Asset'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Create Assignment Dialog ── */}
      <Dialog open={createAssignOpen} onOpenChange={setCreateAssignOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Assign Asset to Employee</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div>
              <Label>Asset *</Label>
              <Select value={assignForm.asset_id} onValueChange={v => setAssignForm(f => ({ ...f, asset_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Select available asset" /></SelectTrigger>
                <SelectContent>
                  {assets.filter(a => a.asset_status === 'AVAILABLE').map(a => (
                    <SelectItem key={a.asset_id} value={a.asset_id}>{a.asset_name} ({a.asset_tag})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Employee *</Label>
              <Select value={assignForm.employee_id} onValueChange={v => setAssignForm(f => ({ ...f, employee_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Select employee" /></SelectTrigger>
                <SelectContent>
                  {employees.map(e => <SelectItem key={e.id} value={e.id}>{e.first_name} {e.last_name}{e.employee_no ? ` (${e.employee_no})` : ''}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div><Label>Assigned Date *</Label><Input type="date" value={assignForm.assigned_date} onChange={e => setAssignForm(f => ({ ...f, assigned_date: e.target.value }))} /></div>
            <div><Label>Condition Notes</Label><Input value={assignForm.condition_notes} onChange={e => setAssignForm(f => ({ ...f, condition_notes: e.target.value }))} placeholder="e.g. Brand new, factory sealed" /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCreateAssignOpen(false)}>Cancel</Button>
              <Button onClick={createAssignment} disabled={assignSaving}>{assignSaving ? 'Assigning…' : 'Assign'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
