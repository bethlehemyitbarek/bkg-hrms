import { useState, useCallback, useRef } from 'react';
import { supabase as _supabase } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import {
  RefreshCw, Play, Activity, AlertTriangle, CheckCircle2, Clock,
  Users, Calendar, Loader2, Eye, Lock, BarChart2, ListChecks,
  TrendingUp, XCircle, Info,
} from 'lucide-react';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const supabase = _supabase as any;

// ── Types ────────────────────────────────────────────────────────
interface AttendanceEventRow {
  id: string;
  employee_id: string;
  event_type: 'CHECK_IN' | 'CHECK_OUT';
  event_timestamp: string;
  event_source: string;
  is_current: number;
  is_deleted: number;
  employee?: { id: string; first_name: string; last_name: string; employee_no: string };
}

interface ShiftRow {
  id: string;
  name: string;
  start_time: string;  // HH:MM:SS
  end_time: string;
  break_duration_minutes: number;
  grace_period_minutes: number;
}

interface ComputeResult {
  employee_id: string;
  employee_name: string;
  employee_no: string;
  attendance_date: string;
  first_check_in?: string;
  last_check_out?: string;
  total_worked_hours: number;
  regular_hours: number;
  overtime_hours: number;
  late_minutes: number;
  early_leave_minutes: number;
  attendance_status: string;
  is_anomaly: boolean;
  anomaly_type?: string;
  event_count: number;
  shift_name?: string;
}

// ── Anomaly Detection Logic ──────────────────────────────────────
function detectAnomalies(
  checkIn?: string,
  checkOut?: string,
  workedHours?: number,
  lateMinutes?: number,
  eventCount?: number,
): { is_anomaly: boolean; anomaly_type?: string } {
  const anomalies: string[] = [];

  if (!checkIn && !checkOut) return { is_anomaly: false };
  if (checkIn && !checkOut)    anomalies.push('MISSING_CHECKOUT');
  if (!checkIn && checkOut)    anomalies.push('MISSING_CHECKIN');
  if (eventCount && eventCount > 4) anomalies.push('EXCESSIVE_EVENTS');
  if (workedHours && workedHours > 14) anomalies.push('EXCESSIVE_HOURS');
  if (lateMinutes && lateMinutes > 120) anomalies.push('VERY_LATE');
  if (workedHours && workedHours < 1 && checkIn && checkOut) anomalies.push('VERY_SHORT_SHIFT');

  if (anomalies.length === 0) return { is_anomaly: false };
  return { is_anomaly: true, anomaly_type: anomalies.join(', ') };
}

// ── Compute engine ────────────────────────────────────────────────
function computeSummaryForEmployee(
  empId: string,
  empName: string,
  empNo: string,
  date: string,
  events: AttendanceEventRow[],
  shift?: ShiftRow,
): ComputeResult {
  const ins  = events.filter(e => e.event_type === 'CHECK_IN' ).map(e => new Date(e.event_timestamp));
  const outs = events.filter(e => e.event_type === 'CHECK_OUT').map(e => new Date(e.event_timestamp));

  const firstIn  = ins.length  > 0 ? new Date(Math.min(...ins.map(d => d.getTime())))  : undefined;
  const lastOut  = outs.length > 0 ? new Date(Math.max(...outs.map(d => d.getTime()))) : undefined;

  // Worked hours
  let totalWorkedHours = 0;
  if (firstIn && lastOut) {
    const rawMinutes = (lastOut.getTime() - firstIn.getTime()) / 60000;
    const breakMinutes = shift?.break_duration_minutes ?? 0;
    totalWorkedHours = Math.max(0, (rawMinutes - breakMinutes) / 60);
  }

  // Regular vs overtime (standard day = 8h unless shift defines differently)
  const regularCap = shift ? (() => {
    const [sh, sm] = shift.start_time.split(':').map(Number);
    const [eh, em] = shift.end_time.split(':').map(Number);
    const shiftMinutes = ((eh * 60 + em) - (sh * 60 + sm)) - (shift.break_duration_minutes ?? 0);
    return Math.max(shiftMinutes / 60, 8);
  })() : 8;

  const regularHours  = Math.min(totalWorkedHours, regularCap);
  const overtimeHours = Math.max(0, totalWorkedHours - regularCap);

  // Late minutes
  let lateMinutes = 0;
  if (firstIn && shift) {
    const [sh, sm] = shift.start_time.split(':').map(Number);
    const shiftStart = new Date(date + 'T' + String(sh).padStart(2,'0') + ':' + String(sm).padStart(2,'0') + ':00');
    const grace = shift.grace_period_minutes ?? 0;
    const diff = (firstIn.getTime() - shiftStart.getTime()) / 60000;
    if (diff > grace) lateMinutes = Math.round(diff - grace);
  }

  // Early leave
  let earlyLeaveMinutes = 0;
  if (lastOut && shift) {
    const [eh, em] = shift.end_time.split(':').map(Number);
    const shiftEnd = new Date(date + 'T' + String(eh).padStart(2,'0') + ':' + String(em).padStart(2,'0') + ':00');
    const diff = (shiftEnd.getTime() - lastOut.getTime()) / 60000;
    if (diff > 0) earlyLeaveMinutes = Math.round(diff);
  }

  // Status
  let attendance_status = 'ABSENT';
  if (events.length > 0) {
    if (totalWorkedHours >= (regularCap / 2)) {
      attendance_status = totalWorkedHours >= regularCap * 0.95 ? 'PRESENT' : 'HALF_DAY';
    } else {
      attendance_status = 'HALF_DAY';
    }
  }

  // Anomaly detection
  const { is_anomaly, anomaly_type } = detectAnomalies(
    firstIn?.toISOString(),
    lastOut?.toISOString(),
    totalWorkedHours,
    lateMinutes,
    events.length,
  );

  return {
    employee_id:       empId,
    employee_name:     empName,
    employee_no:       empNo,
    attendance_date:   date,
    first_check_in:    firstIn?.toISOString(),
    last_check_out:    lastOut?.toISOString(),
    total_worked_hours: Math.round(totalWorkedHours * 100) / 100,
    regular_hours:     Math.round(regularHours * 100) / 100,
    overtime_hours:    Math.round(overtimeHours * 100) / 100,
    late_minutes:      lateMinutes,
    early_leave_minutes: earlyLeaveMinutes,
    attendance_status,
    is_anomaly,
    anomaly_type,
    event_count:       events.length,
    shift_name:        shift?.name,
  };
}

// ── Helpers ────────────────────────────────────────────────────
const fmtTime = (ts?: string) =>
  ts ? new Date(ts).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }) : '—';

const fmtHours = (h: number) =>
  h > 0 ? `${Math.floor(h)}h ${Math.round((h % 1) * 60)}m` : '0h';

const STATUS_COLORS: Record<string, string> = {
  PRESENT:  'bg-green-100 text-green-800',
  ABSENT:   'bg-red-100 text-red-800',
  HALF_DAY: 'bg-yellow-100 text-yellow-800',
  ON_LEAVE: 'bg-blue-100 text-blue-800',
  HOLIDAY:  'bg-teal-100 text-teal-800',
  WEEKEND:  'bg-muted text-muted-foreground',
  EXCUSED:  'bg-purple-100 text-purple-800',
};

// ── Main Component ───────────────────────────────────────────────
export function AttendanceAutoComputePage() {
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate,   setEndDate]   = useState(new Date().toISOString().split('T')[0]);
  const [overwrite, setOverwrite] = useState(false);
  const [results,   setResults]   = useState<ComputeResult[]>([]);
  const [computing, setComputing] = useState(false);
  const [saving,    setSaving]    = useState(false);
  const [progress,  setProgress]  = useState(0);
  const [tab,       setTab]       = useState<'results' | 'anomalies' | 'summary'>('results');
  const [viewDetail, setViewDetail] = useState<ComputeResult | null>(null);
  const [search,     setSearch]    = useState('');
  const computingRef = useRef(false);

  // ── Run computation ──────────────────────────────────────────
  const runCompute = useCallback(async () => {
    if (computingRef.current) return;
    if (!startDate || !endDate) { toast.error('Select a date range'); return; }
    if (new Date(endDate) < new Date(startDate)) { toast.error('End date must be after start date'); return; }

    computingRef.current = true;
    setComputing(true);
    setProgress(0);
    setResults([]);

    try {
      // 1. Load all attendance events for the date range
      const { data: eventsRaw, error: evErr } = await supabase
        .from('attendance_events')
        .select('id, employee_id, event_type, event_timestamp, event_source, is_current, is_deleted, employee:employees!attendance_events_employee_id_fkey(id, first_name, last_name, employee_no)')
        .eq('is_current', 1)
        .eq('is_deleted', 0)
        .gte('event_timestamp', startDate + 'T00:00:00')
        .lte('event_timestamp', endDate + 'T23:59:59')
        .order('event_timestamp', { ascending: true });

      if (evErr) throw evErr;
      const events: AttendanceEventRow[] = Array.isArray(eventsRaw) ? eventsRaw : [];

      // 2. Load shifts for grace/break lookup
      const { data: shiftsRaw } = await supabase
        .from('shifts')
        .select('id, name, start_time, end_time, break_duration_minutes, grace_period_minutes')
        .eq('is_deleted', 0)
        .eq('is_active', 1);
      const shiftsArr: ShiftRow[] = Array.isArray(shiftsRaw) ? shiftsRaw : [];
      const defaultShift = shiftsArr[0]; // fallback if no assignment

      // 3. Load employee→shift assignments (daily_attendance_summaries that are locked to get shift_id)
      // Use shift assignments from employee records or use first shift as default
      const { data: assignRaw } = await supabase
        .from('employee_salary_structures')  // proxy: we don't have shift_assignment table, use first shift
        .select('employee_id')
        .limit(1);
      void assignRaw; // we'll use defaultShift for all employees

      // 4. Group events by (employee_id, date)
      type GroupKey = string; // `${employee_id}::${date}`
      const grouped = new Map<GroupKey, { empId: string; empName: string; empNo: string; events: AttendanceEventRow[] }>();

      for (const ev of events) {
        const date = ev.event_timestamp.split('T')[0];
        const key: GroupKey = `${ev.employee_id}::${date}`;
        if (!grouped.has(key)) {
          const emp = ev.employee;
          grouped.set(key, {
            empId: ev.employee_id,
            empName: emp ? `${emp.first_name} ${emp.last_name}` : 'Unknown',
            empNo: emp?.employee_no ?? '—',
            events: [],
          });
        }
        grouped.get(key)!.events.push(ev);
      }

      setProgress(30);

      // 5. Compute summaries for each group
      const computed: ComputeResult[] = [];
      const groups = Array.from(grouped.entries());
      for (let i = 0; i < groups.length; i++) {
        const [key, grp] = groups[i];
        const date = key.split('::')[1];
        const result = computeSummaryForEmployee(
          grp.empId, grp.empName, grp.empNo, date, grp.events, defaultShift,
        );
        computed.push(result);
        setProgress(30 + Math.round(((i + 1) / groups.length) * 60));
      }

      setResults(computed);
      setProgress(100);

      const anomalyCount = computed.filter(r => r.is_anomaly).length;
      toast.success(
        `Computed ${computed.length} summaries · ${anomalyCount} anomal${anomalyCount === 1 ? 'y' : 'ies'} detected`
      );
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Computation failed');
    } finally {
      computingRef.current = false;
      setComputing(false);
    }
  }, [startDate, endDate]);

  // ── Save to database ─────────────────────────────────────────
  const saveResults = useCallback(async () => {
    if (!results.length) return;
    setSaving(true);
    let upserted = 0; let skipped = 0;
    try {
      for (const r of results) {
        // Check existing
        const { data: existing } = await supabase
          .from('daily_attendance_summaries')
          .select('id, is_locked')
          .eq('employee_id', r.employee_id)
          .eq('attendance_date', r.attendance_date)
          .eq('is_current', 1)
          .maybeSingle();

        if (existing?.is_locked && !overwrite) { skipped++; continue; }

        const payload = {
          employee_id:          r.employee_id,
          attendance_date:      r.attendance_date,
          first_check_in:       r.first_check_in ?? null,
          last_check_out:       r.last_check_out ?? null,
          total_worked_hours:   r.total_worked_hours,
          regular_hours:        r.regular_hours,
          overtime_hours:       r.overtime_hours,
          late_minutes:         r.late_minutes,
          early_leave_minutes:  r.early_leave_minutes,
          attendance_status:    r.attendance_status,
          is_anomaly:           r.is_anomaly ? 1 : 0,
          anomaly_type:         r.anomaly_type ?? null,
          effective_from:       r.attendance_date + 'T00:00:00',
          effective_to:         '9999-12-31T23:59:59',
          is_current:           1,
          is_locked:            0,
          is_active:            1,
          is_deleted:           0,
          updated_at:           new Date().toISOString(),
        };

        if (existing) {
          const { error } = await supabase.from('daily_attendance_summaries').update(payload).eq('id', existing.id);
          if (!error) upserted++;
        } else {
          const { error } = await supabase.from('daily_attendance_summaries').insert({
            ...payload,
            summary_id: crypto.randomUUID(),
            row_start:  new Date().toISOString(),
            row_end:    '9999-12-31T23:59:59',
            created_at: new Date().toISOString(),
          });
          if (!error) upserted++;
        }
      }
      toast.success(`Saved ${upserted} summaries${skipped > 0 ? `, ${skipped} skipped (locked)` : ''}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  }, [results, overwrite]);

  // ── Stats ────────────────────────────────────────────────────
  const stats = {
    total:     results.length,
    present:   results.filter(r => r.attendance_status === 'PRESENT').length,
    absent:    results.filter(r => r.attendance_status === 'ABSENT').length,
    halfDay:   results.filter(r => r.attendance_status === 'HALF_DAY').length,
    anomalies: results.filter(r => r.is_anomaly).length,
    avgHours:  results.length > 0
      ? results.reduce((a, r) => a + r.total_worked_hours, 0) / (results.filter(r => r.total_worked_hours > 0).length || 1)
      : 0,
  };

  const filtered = results.filter(r => {
    if (!search) return true;
    return `${r.employee_name} ${r.employee_no}`.toLowerCase().includes(search.toLowerCase());
  });
  const anomalies = results.filter(r => r.is_anomaly);

  // ── JSX ───────────────────────────────────────────────────────
  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-balance">Attendance Auto-Compute</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Compute daily attendance summaries from raw events with anomaly detection, then save to the database.
          </p>
        </div>
      </div>

      {/* Control Panel */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="h-4 w-4 text-primary" />Computation Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4 md:items-end">
            <div className="space-y-1.5">
              <Label>Start Date</Label>
              <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-44" />
            </div>
            <div className="space-y-1.5">
              <Label>End Date</Label>
              <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-44" />
            </div>
            <div className="flex items-center gap-2 h-10 pb-0.5">
              <Switch id="overwrite" checked={overwrite} onCheckedChange={setOverwrite} />
              <Label htmlFor="overwrite" className="text-sm">Overwrite locked records</Label>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button onClick={runCompute} disabled={computing} className="gap-2">
              {computing
                ? <><Loader2 className="h-4 w-4 animate-spin" />Computing…</>
                : <><Play className="h-4 w-4" />Run Computation</>}
            </Button>
            {results.length > 0 && (
              <Button onClick={saveResults} disabled={saving} variant="secondary" className="gap-2">
                {saving
                  ? <><Loader2 className="h-4 w-4 animate-spin" />Saving…</>
                  : <><Lock className="h-4 w-4" />Save {results.length} Summaries</>}
              </Button>
            )}
          </div>

          {computing && (
            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Processing attendance events…</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Anomaly Detection Legend */}
      <Card className="bg-muted/20 border-dashed">
        <CardContent className="p-3">
          <div className="flex items-start gap-2 text-sm text-muted-foreground">
            <Info className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
            <div>
              <span className="font-medium text-foreground">Anomaly Detection Rules: </span>
              Missing check-out · Missing check-in · &gt;14h worked · &gt;4 events/day · Late &gt;2h · Shift &lt;1h
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      {results.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { label: 'Records',   value: stats.total,             icon: ListChecks,   color: 'text-foreground' },
            { label: 'Present',   value: stats.present,           icon: CheckCircle2, color: 'text-green-600' },
            { label: 'Absent',    value: stats.absent,            icon: XCircle,      color: 'text-red-500' },
            { label: 'Half Day',  value: stats.halfDay,           icon: Clock,        color: 'text-yellow-600' },
            { label: 'Anomalies', value: stats.anomalies,         icon: AlertTriangle, color: 'text-orange-500' },
            { label: 'Avg Hours', value: fmtHours(stats.avgHours), icon: TrendingUp,  color: 'text-primary' },
          ].map(s => (
            <Card key={s.label} className="h-full">
              <CardContent className="p-3 flex items-center gap-2.5">
                <s.icon className={`h-4 w-4 shrink-0 ${s.color}`} />
                <div className="min-w-0">
                  <div className={`text-sm font-semibold ${s.color}`}>{s.value}</div>
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Results Tabs */}
      {results.length > 0 && (
        <Tabs value={tab} onValueChange={v => setTab(v as typeof tab)}>
          <TabsList>
            <TabsTrigger value="results">
              <ListChecks className="h-3.5 w-3.5 mr-1.5" />All Results ({results.length})
            </TabsTrigger>
            <TabsTrigger value="anomalies">
              <AlertTriangle className="h-3.5 w-3.5 mr-1.5" />
              Anomalies
              {anomalies.length > 0 && (
                <span className="ml-1.5 h-4 min-w-4 px-1 rounded-full bg-orange-500 text-white text-xs flex items-center justify-center font-semibold">
                  {anomalies.length}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="summary">
              <BarChart2 className="h-3.5 w-3.5 mr-1.5" />Status Summary
            </TabsTrigger>
          </TabsList>

          {/* ── All Results ── */}
          <TabsContent value="results" className="mt-4">
            <div className="flex items-center gap-2 mb-3">
              <Input
                placeholder="Search employee…"
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="max-w-xs"
              />
            </div>
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Employee</TableHead>
                        <TableHead className="whitespace-nowrap">Date</TableHead>
                        <TableHead className="whitespace-nowrap">Check In</TableHead>
                        <TableHead className="whitespace-nowrap">Check Out</TableHead>
                        <TableHead className="whitespace-nowrap">Worked</TableHead>
                        <TableHead className="whitespace-nowrap">OT</TableHead>
                        <TableHead className="whitespace-nowrap">Late</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Anomaly</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filtered.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={10} className="text-center text-muted-foreground py-10">
                            No results match your search
                          </TableCell>
                        </TableRow>
                      ) : filtered.map((r, idx) => (
                        <TableRow key={idx} className={r.is_anomaly ? 'bg-orange-50/50' : ''}>
                          <TableCell className="whitespace-nowrap">
                            <div className="font-medium text-sm">{r.employee_name}</div>
                            <div className="text-xs text-muted-foreground">#{r.employee_no}</div>
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{r.attendance_date}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{fmtTime(r.first_check_in)}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{fmtTime(r.last_check_out)}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm font-medium">
                            {fmtHours(r.total_worked_hours)}
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-sm text-primary">
                            {r.overtime_hours > 0 ? fmtHours(r.overtime_hours) : '—'}
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-sm">
                            {r.late_minutes > 0
                              ? <span className="text-orange-600 font-medium">{r.late_minutes}m</span>
                              : '—'}
                          </TableCell>
                          <TableCell>
                            <Badge className={`text-xs ${STATUS_COLORS[r.attendance_status] ?? 'bg-muted text-muted-foreground'}`}>
                              {r.attendance_status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {r.is_anomaly ? (
                              <Badge className="bg-orange-100 text-orange-800 text-xs gap-1">
                                <AlertTriangle className="h-3 w-3" />Yes
                              </Badge>
                            ) : (
                              <Badge className="bg-muted text-muted-foreground text-xs">—</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => setViewDetail(r)}>
                              <Eye className="h-3.5 w-3.5" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ── Anomalies tab ── */}
          <TabsContent value="anomalies" className="mt-4">
            {anomalies.length === 0 ? (
              <Card>
                <CardContent className="py-14 flex flex-col items-center gap-3 text-center">
                  <CheckCircle2 className="h-10 w-10 text-green-500/60" />
                  <p className="text-muted-foreground font-medium">No anomalies detected in this computation run.</p>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Employee</TableHead>
                          <TableHead className="whitespace-nowrap">Date</TableHead>
                          <TableHead>Anomaly Type(s)</TableHead>
                          <TableHead className="whitespace-nowrap">Check In</TableHead>
                          <TableHead className="whitespace-nowrap">Check Out</TableHead>
                          <TableHead className="whitespace-nowrap">Events</TableHead>
                          <TableHead className="whitespace-nowrap">Worked</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {anomalies.map((r, idx) => (
                          <TableRow key={idx} className="bg-orange-50/50">
                            <TableCell className="whitespace-nowrap">
                              <div className="font-medium text-sm">{r.employee_name}</div>
                              <div className="text-xs text-muted-foreground">#{r.employee_no}</div>
                            </TableCell>
                            <TableCell className="whitespace-nowrap text-sm">{r.attendance_date}</TableCell>
                            <TableCell>
                              <div className="flex flex-wrap gap-1">
                                {(r.anomaly_type ?? '').split(', ').map(a => (
                                  <Badge key={a} className="bg-orange-100 text-orange-800 text-xs">{a}</Badge>
                                ))}
                              </div>
                            </TableCell>
                            <TableCell className="whitespace-nowrap text-sm">{fmtTime(r.first_check_in)}</TableCell>
                            <TableCell className="whitespace-nowrap text-sm">{fmtTime(r.last_check_out)}</TableCell>
                            <TableCell className="text-center font-semibold text-sm">{r.event_count}</TableCell>
                            <TableCell className="whitespace-nowrap text-sm">{fmtHours(r.total_worked_hours)}</TableCell>
                            <TableCell>
                              <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => setViewDetail(r)}>
                                <Eye className="h-3.5 w-3.5" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* ── Status Summary tab ── */}
          <TabsContent value="summary" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Status distribution */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Status Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  {Object.entries(
                    results.reduce((acc, r) => {
                      acc[r.attendance_status] = (acc[r.attendance_status] ?? 0) + 1;
                      return acc;
                    }, {} as Record<string, number>)
                  ).sort((a, b) => b[1] - a[1]).map(([status, count]) => (
                    <div key={status} className="flex items-center gap-3 py-2">
                      <Badge className={`text-xs w-24 justify-center ${STATUS_COLORS[status] ?? 'bg-muted text-muted-foreground'}`}>
                        {status}
                      </Badge>
                      <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                        <div
                          className="h-2 bg-primary rounded-full transition-all"
                          style={{ width: `${(count / results.length) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium w-10 text-right">{count}</span>
                      <span className="text-xs text-muted-foreground w-10 text-right">
                        {((count / results.length) * 100).toFixed(0)}%
                      </span>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Per-employee summary */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Users className="h-4 w-4" />Per-Employee Summary
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="overflow-x-auto max-h-64 overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Employee</TableHead>
                          <TableHead className="whitespace-nowrap text-center">Days</TableHead>
                          <TableHead className="whitespace-nowrap">Total Hours</TableHead>
                          <TableHead className="whitespace-nowrap text-center">Anomalies</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {Object.values(
                          results.reduce((acc, r) => {
                            const k = r.employee_id;
                            if (!acc[k]) acc[k] = { name: r.employee_name, no: r.employee_no, days: 0, hours: 0, anomalies: 0 };
                            acc[k].days++;
                            acc[k].hours += r.total_worked_hours;
                            if (r.is_anomaly) acc[k].anomalies++;
                            return acc;
                          }, {} as Record<string, { name: string; no: string; days: number; hours: number; anomalies: number }>)
                        ).sort((a, b) => b.hours - a.hours).map((emp, idx) => (
                          <TableRow key={idx}>
                            <TableCell className="whitespace-nowrap">
                              <div className="font-medium text-sm">{emp.name}</div>
                              <div className="text-xs text-muted-foreground">#{emp.no}</div>
                            </TableCell>
                            <TableCell className="text-center text-sm">{emp.days}</TableCell>
                            <TableCell className="whitespace-nowrap text-sm">{fmtHours(emp.hours)}</TableCell>
                            <TableCell className="text-center">
                              {emp.anomalies > 0
                                ? <Badge className="bg-orange-100 text-orange-800 text-xs">{emp.anomalies}</Badge>
                                : <span className="text-xs text-muted-foreground">—</span>}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      )}

      {/* Empty state */}
      {!computing && results.length === 0 && (
        <Card>
          <CardContent className="py-16 flex flex-col items-center gap-3 text-center">
            <Calendar className="h-12 w-12 text-muted-foreground/40" />
            <p className="text-muted-foreground">Select a date range and click <strong>Run Computation</strong> to process attendance events.</p>
            <p className="text-xs text-muted-foreground">
              The engine will compute worked hours, detect late arrivals, early departures, overtime, and flag anomalies.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Detail Dialog */}
      <Dialog open={!!viewDetail} onOpenChange={open => { if (!open) setViewDetail(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-primary" />Attendance Detail
            </DialogTitle>
          </DialogHeader>
          {viewDetail && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm bg-muted/30 rounded-lg p-3">
                <div><span className="text-muted-foreground">Employee:</span> <span className="font-medium">{viewDetail.employee_name}</span></div>
                <div><span className="text-muted-foreground">No:</span> <span className="font-medium">#{viewDetail.employee_no}</span></div>
                <div><span className="text-muted-foreground">Date:</span> <span className="font-medium">{viewDetail.attendance_date}</span></div>
                <div><span className="text-muted-foreground">Events:</span> <span className="font-medium">{viewDetail.event_count}</span></div>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><Label className="text-xs text-muted-foreground">Check In</Label><div className="font-medium">{fmtTime(viewDetail.first_check_in)}</div></div>
                <div><Label className="text-xs text-muted-foreground">Check Out</Label><div className="font-medium">{fmtTime(viewDetail.last_check_out)}</div></div>
                <div><Label className="text-xs text-muted-foreground">Worked</Label><div className="font-semibold text-primary">{fmtHours(viewDetail.total_worked_hours)}</div></div>
                <div><Label className="text-xs text-muted-foreground">Overtime</Label><div className="font-medium text-primary">{fmtHours(viewDetail.overtime_hours)}</div></div>
                <div><Label className="text-xs text-muted-foreground">Late</Label><div className={`font-medium ${viewDetail.late_minutes > 0 ? 'text-orange-600' : ''}`}>{viewDetail.late_minutes > 0 ? `${viewDetail.late_minutes}m` : '—'}</div></div>
                <div><Label className="text-xs text-muted-foreground">Early Leave</Label><div className={`font-medium ${viewDetail.early_leave_minutes > 0 ? 'text-orange-600' : ''}`}>{viewDetail.early_leave_minutes > 0 ? `${viewDetail.early_leave_minutes}m` : '—'}</div></div>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={`text-xs ${STATUS_COLORS[viewDetail.attendance_status] ?? 'bg-muted'}`}>
                  {viewDetail.attendance_status}
                </Badge>
                {viewDetail.shift_name && (
                  <Badge className="bg-blue-100 text-blue-800 text-xs">{viewDetail.shift_name}</Badge>
                )}
              </div>
              {viewDetail.is_anomaly && (
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 space-y-1">
                  <div className="flex items-center gap-1.5 font-semibold text-orange-700 text-sm">
                    <AlertTriangle className="h-4 w-4" />Anomaly Detected
                  </div>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {(viewDetail.anomaly_type ?? '').split(', ').map(a => (
                      <Badge key={a} className="bg-orange-100 text-orange-800 text-xs">{a}</Badge>
                    ))}
                  </div>
                </div>
              )}
              <div className="flex justify-end">
                <Button variant="outline" onClick={() => setViewDetail(null)}>Close</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
