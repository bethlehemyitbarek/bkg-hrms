import { useState, useEffect, useCallback, useRef } from 'react';
import Papa from 'papaparse';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { supabase } from '@/db/supabase';
import { attendanceService } from '@/services/attendance.service';
import type { AttendanceRecord } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { RefreshCw, Plus, Clock, Users, UserCheck, UserX, Upload, AlertCircle, FileText, Pencil, MapPin, Timer, BarChart2, AlertTriangle, TrendingUp, Shield, CalendarDays, Download } from 'lucide-react';
import { exportToCsv } from '@/utils/exportUtils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const STATUS_COLORS: Record<string, string> = {
  present: 'bg-green-100 text-green-800',
  absent: 'bg-red-100 text-red-800',
  late: 'bg-orange-100 text-orange-800',
  on_leave: 'bg-blue-100 text-blue-800',
  remote: 'bg-purple-100 text-purple-800',
  holiday: 'bg-teal-100 text-teal-800',
  half_day: 'bg-yellow-100 text-yellow-800',
  early_leave: 'bg-orange-100 text-orange-800',
  weekend: 'bg-muted text-muted-foreground',
};

const STATUSES = ['present','absent','late','remote','on_leave','half_day','early_leave','holiday','weekend'];

const emptyForm = {
  employee_id: '',
  attendance_date: new Date().toISOString().split('T')[0],
  check_in: '',
  check_out: '',
  status: 'present',
  location: '',
  notes: '',
  overtime_minutes: '',
  late_minutes: '',
  early_leave_minutes: '',
};

export function AttendancePage() {
  const [records,    setRecords]    = useState<AttendanceRecord[]>([]);
  const [loading,    setLoading]    = useState(true);
  const [total,      setTotal]      = useState(0);
  const [page,       setPage]       = useState(1);
  const pageSize = 20;
  const [startDate,    setStartDate]    = useState(new Date().toISOString().split('T')[0]);
  const [endDate,      setEndDate]      = useState(new Date().toISOString().split('T')[0]);
  const [statusFilter, setStatusFilter] = useState('all');
  const [stats,        setStats]        = useState({ present: 0, absent: 0, late: 0, on_leave: 0, remote: 0 });

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editRecord, setEditRecord] = useState<AttendanceRecord | null>(null);
  const [saving,     setSaving]     = useState(false);
  const [formData,   setFormData]   = useState({ ...emptyForm });

  const [csvOpen,    setCsvOpen]    = useState(false);
  const [csvRows,    setCsvRows]    = useState<CsvRow[]>([]);
  const [csvErrors,  setCsvErrors]  = useState<string[]>([]);
  const [importing,  setImporting]  = useState(false);
  const [importDone, setImportDone] = useState<{ ok: number; fail: number } | null>(null);
  const fileInputRef                = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const result = await attendanceService.list({ start_date: startDate, end_date: endDate,
        status: statusFilter !== 'all' ? statusFilter : undefined, page, pageSize });
      setRecords(result.data);
      setTotal(result.total);
    } catch { toast.error('Failed to load attendance records'); }
    finally { setLoading(false); }
  }, [startDate, endDate, statusFilter, page, pageSize]);

  const loadStats = useCallback(async () => {
    const s = await attendanceService.getStats(startDate, endDate)
      .catch(() => ({ present: 0, absent: 0, late: 0, on_leave: 0, remote: 0, total: 0 }));
    setStats(s);
  }, [startDate, endDate]);

  useEffect(() => { load(); loadStats(); }, [load, loadStats]);

  const toTimestamp = (date: string, time: string) => time ? `${date}T${time}:00` : undefined;

  const calcWorkMinutes = (date: string, ci: string, co: string) => {
    if (!ci || !co) return undefined;
    return Math.max(0, Math.floor(
      (new Date(`${date}T${co}:00`).getTime() - new Date(`${date}T${ci}:00`).getTime()) / 60000));
  };

  const buildPayload = (f: typeof emptyForm): Record<string, unknown> => {
    const ci = toTimestamp(f.attendance_date, f.check_in);
    const co = toTimestamp(f.attendance_date, f.check_out);
    const wm = calcWorkMinutes(f.attendance_date, f.check_in, f.check_out);
    return {
      employee_id:         f.employee_id,
      attendance_date:     f.attendance_date,
      status:              f.status,
      location:            f.location || null,
      notes:               f.notes   || null,
      overtime_minutes:    f.overtime_minutes    !== '' ? Number(f.overtime_minutes)    : null,
      late_minutes:        f.late_minutes         !== '' ? Number(f.late_minutes)         : null,
      early_leave_minutes: f.early_leave_minutes  !== '' ? Number(f.early_leave_minutes)  : null,
      is_manual: true,
      ...(ci && { check_in: ci }),
      ...(co && { check_out: co }),
      ...(wm !== undefined && { work_minutes: wm }),
    };
  };

  const openCreate = () => {
    setEditRecord(null);
    setFormData({ ...emptyForm, attendance_date: new Date().toISOString().split('T')[0] });
    setDialogOpen(true);
  };

  const openEdit = (r: AttendanceRecord) => {
    setEditRecord(r);
    const toTime = (ts?: string) => ts ? new Date(ts).toTimeString().slice(0, 5) : '';
    setFormData({
      employee_id:         r.employee_id,
      attendance_date:     r.attendance_date,
      check_in:            toTime(r.check_in),
      check_out:           toTime(r.check_out),
      status:              r.status,
      location:            r.location ?? '',
      notes:               r.notes ?? '',
      overtime_minutes:    r.overtime_minutes    != null ? String(r.overtime_minutes)    : '',
      late_minutes:        r.late_minutes         != null ? String(r.late_minutes)         : '',
      early_leave_minutes: r.early_leave_minutes  != null ? String(r.early_leave_minutes)  : '',
    });
    setDialogOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.employee_id || formData.employee_id === 'none') { toast.error('Select an employee'); return; }
    setSaving(true);
    try {
      const payload = buildPayload(formData);
      if (editRecord) {
        await (supabase as any).from('attendance_records').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', editRecord.id);
        toast.success('Record updated');
      } else {
        await attendanceService.create(payload as any);
        toast.success('Record created');
      }
      setDialogOpen(false);
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };

  type CsvRow = {
    employee_no: string; date: string; check_in?: string; check_out?: string; status?: string;
    location?: string; notes?: string; overtime_minutes?: string; late_minutes?: string; early_leave_minutes?: string;
  };

  const handleCsvFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    setCsvErrors([]); setImportDone(null);
    Papa.parse<Record<string, string>>(file, { header: true, skipEmptyLines: true,
      complete: ({ data, errors: pe }) => {
        if (pe.length) { setCsvErrors(pe.map(x => x.message)); return; }
        const errs: string[] = [];
        const rows: CsvRow[] = data.map((row, i) => {
          const r: CsvRow = {
            employee_no:         (row['employee_no'] || '').trim(),
            date:                (row['date'] || row['attendance_date'] || '').trim(),
            check_in:            row['check_in']?.trim() || undefined,
            check_out:           row['check_out']?.trim() || undefined,
            status:              (row['status'] || 'present').trim().toLowerCase(),
            location:            row['location']?.trim() || undefined,
            notes:               row['notes']?.trim() || undefined,
            overtime_minutes:    row['overtime_minutes']?.trim() || undefined,
            late_minutes:        row['late_minutes']?.trim() || undefined,
            early_leave_minutes: row['early_leave_minutes']?.trim() || undefined,
          };
          if (!r.employee_no) errs.push(`Row ${i + 2}: employee_no required`);
          if (!r.date || !/^\d{4}-\d{2}-\d{2}$/.test(r.date)) errs.push(`Row ${i + 2}: date must be YYYY-MM-DD`);
          if (r.check_in  && !/^\d{2}:\d{2}$/.test(r.check_in))  errs.push(`Row ${i + 2}: check_in must be HH:MM`);
          if (r.check_out && !/^\d{2}:\d{2}$/.test(r.check_out)) errs.push(`Row ${i + 2}: check_out must be HH:MM`);
          return r;
        });
        setCsvErrors(errs); setCsvRows(rows);
      },
    });
  };

  const handleImport = async () => {
    if (csvErrors.length > 0 || csvRows.length === 0) return;
    setImporting(true);
    let ok = 0, fail = 0;
    const { data: emps } = await (supabase as any).from('employees').select('id, employee_no');
    const empMap = new Map<string, string>();
    (emps || []).forEach((e: { id: string; employee_no: string }) => empMap.set(e.employee_no, e.id));
    for (const row of csvRows) {
      const employee_id = empMap.get(row.employee_no); if (!employee_id) { fail++; continue; }
      const toTs = (t: string) => `${row.date}T${t}:00`;
      const p: Record<string, unknown> = { employee_id, attendance_date: row.date, status: row.status || 'present', is_manual: true };
      if (row.check_in)  p.check_in  = toTs(row.check_in);
      if (row.check_out) p.check_out = toTs(row.check_out);
      if (row.check_in && row.check_out) {
        const [sh, sm] = row.check_in.split(':').map(Number);
        const [eh, em] = row.check_out.split(':').map(Number);
        p.work_minutes = Math.max(0, (eh * 60 + em) - (sh * 60 + sm));
      }
      if (row.location)            p.location            = row.location;
      if (row.notes)               p.notes               = row.notes;
      if (row.overtime_minutes)    p.overtime_minutes    = Number(row.overtime_minutes);
      if (row.late_minutes)        p.late_minutes        = Number(row.late_minutes);
      if (row.early_leave_minutes) p.early_leave_minutes = Number(row.early_leave_minutes);
      try { await attendanceService.create(p); ok++; } catch { fail++; }
    }
    setImportDone({ ok, fail }); setImporting(false);
    if (ok > 0) { toast.success(`Imported ${ok} record${ok > 1 ? 's' : ''}`); load(); }
    if (fail > 0) toast.warning(`${fail} row${fail > 1 ? 's' : ''} failed`);
  };

  const formatTime = (ts?: string) =>
    ts ? new Date(ts).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) : '—';

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Attendance</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} records</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={() => { load(); loadStats(); }}>
            <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
          </Button>
          {/* CSV import */}
          <Button variant="outline" size="sm" onClick={() => { setCsvRows([]); setCsvErrors([]); setImportDone(null); setCsvOpen(true); }}>
            <Upload className="h-4 w-4 mr-1.5" />Import CSV
          </Button>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1.5" />Add Record</Button>
        </div>
      </div>

      <Tabs defaultValue="records">
        <TabsList className="flex-wrap gap-1 h-auto">
          <TabsTrigger value="records"><Clock className="h-3.5 w-3.5 mr-1.5" />Records</TabsTrigger>
          <TabsTrigger value="daily-report"><BarChart2 className="h-3.5 w-3.5 mr-1.5" />Daily Report</TabsTrigger>
          <TabsTrigger value="late-report"><AlertTriangle className="h-3.5 w-3.5 mr-1.5" />Late Arrivals</TabsTrigger>
          <TabsTrigger value="absence-report"><UserX className="h-3.5 w-3.5 mr-1.5" />Absences</TabsTrigger>
          <TabsTrigger value="overtime-report"><TrendingUp className="h-3.5 w-3.5 mr-1.5" />Overtime</TabsTrigger>
          <TabsTrigger value="anomaly-report"><AlertCircle className="h-3.5 w-3.5 mr-1.5" />Anomalies</TabsTrigger>
          <TabsTrigger value="shift-adherence"><Shield className="h-3.5 w-3.5 mr-1.5" />Shift Adherence</TabsTrigger>
          <TabsTrigger value="monthly-summary"><CalendarDays className="h-3.5 w-3.5 mr-1.5" />Monthly Summary</TabsTrigger>
        </TabsList>

        {/* ── Records tab (existing content) ── */}
        <TabsContent value="records" className="mt-4">

      {/* Create / Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={o => { if (!o) setDialogOpen(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle className="text-base">{editRecord ? 'Edit' : 'Add'} Attendance Record</DialogTitle></DialogHeader>
          <form onSubmit={handleSave} className="space-y-4 mt-1">
            <Tabs defaultValue="basic">
              <TabsList className="h-8">
                <TabsTrigger value="basic"  className="text-xs">Basic</TabsTrigger>
                <TabsTrigger value="time"   className="text-xs">Times</TabsTrigger>
                <TabsTrigger value="extra"  className="text-xs">Minutes</TabsTrigger>
              </TabsList>

              <TabsContent value="basic" className="space-y-4 pt-3">
                <EmployeeSelect value={formData.employee_id} onChange={v => setFormData(p => ({ ...p, employee_id: v }))} required />
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label>Date *</Label>
                    <Input type="date" value={formData.attendance_date}
                      onChange={e => setFormData(p => ({ ...p, attendance_date: e.target.value }))} required />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Status</Label>
                    <Select value={formData.status} onValueChange={v => setFormData(p => ({ ...p, status: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {STATUSES.map(s => <SelectItem key={s} value={s}>{s.replace(/_/g, ' ')}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label>Location</Label>
                  <div className="relative">
                    <MapPin className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
                    <Input className="pl-8" value={formData.location}
                      onChange={e => setFormData(p => ({ ...p, location: e.target.value }))}
                      placeholder="Office / Remote / Site…" />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label>Notes</Label>
                  <Textarea value={formData.notes}
                    onChange={e => setFormData(p => ({ ...p, notes: e.target.value }))} rows={2} />
                </div>
              </TabsContent>

              <TabsContent value="time" className="space-y-4 pt-3">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label>Check In</Label>
                    <Input type="time" value={formData.check_in}
                      onChange={e => setFormData(p => ({ ...p, check_in: e.target.value }))} />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Check Out</Label>
                    <Input type="time" value={formData.check_out}
                      onChange={e => setFormData(p => ({ ...p, check_out: e.target.value }))} />
                  </div>
                </div>
                {formData.check_in && formData.check_out && (() => {
                  const wm = calcWorkMinutes(formData.attendance_date, formData.check_in, formData.check_out);
                  if (wm === undefined) return null;
                  return (
                    <div className="bg-muted/40 rounded-lg p-3 text-sm flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground shrink-0" />
                      Work: <strong>{Math.floor(wm / 60)}h {wm % 60}m</strong> ({wm} min)
                    </div>
                  );
                })()}
              </TabsContent>

              <TabsContent value="extra" className="space-y-4 pt-3">
                <div className="grid grid-cols-3 gap-4">
                  {([
                    ['Overtime (min)', 'overtime_minutes'],
                    ['Late (min)',     'late_minutes'],
                    ['Early Leave (min)', 'early_leave_minutes'],
                  ] as [string, keyof typeof emptyForm][]).map(([label, key]) => (
                    <div key={key} className="space-y-1.5">
                      <Label>{label}</Label>
                      <Input type="number" min="0"
                        value={formData[key] as string}
                        onChange={e => setFormData(p => ({ ...p, [key]: e.target.value }))}
                        placeholder="0" />
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">Used for payroll calculations and reporting.</p>
              </TabsContent>
            </Tabs>
            <div className="flex justify-end gap-2 pt-2 border-t border-border">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : (editRecord ? 'Update' : 'Create')}</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* CSV Dialog */}
      <Dialog open={csvOpen} onOpenChange={o => { if (!o) { setCsvOpen(false); if (fileInputRef.current) fileInputRef.current.value = ''; } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>Bulk Import Attendance (CSV)</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="bg-muted/50 rounded-lg p-3 text-xs space-y-1">
              <p className="font-semibold text-foreground flex items-center gap-1.5"><FileText className="h-3.5 w-3.5" />Columns</p>
              <p className="font-mono text-muted-foreground break-all">
                employee_no*, date* (YYYY-MM-DD), status, check_in (HH:MM), check_out (HH:MM), location, overtime_minutes, late_minutes, early_leave_minutes, notes
              </p>
            </div>
            <input ref={fileInputRef} type="file" accept=".csv" onChange={handleCsvFile}
              className="block w-full text-sm text-muted-foreground file:mr-3 file:py-1.5 file:px-3 file:rounded file:border file:border-border file:bg-card file:text-sm file:font-medium cursor-pointer" />
            {csvErrors.length > 0 && (
              <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>
                <ul className="list-disc list-inside text-xs max-h-32 overflow-y-auto">
                  {csvErrors.map((e, i) => <li key={i}>{e}</li>)}
                </ul>
              </AlertDescription></Alert>
            )}
            {importDone && <Alert><AlertDescription>Done — <strong>{importDone.ok}</strong> ok, <strong>{importDone.fail}</strong> failed.</AlertDescription></Alert>}
            {csvRows.length > 0 && csvErrors.length === 0 && (
              <div className="border border-border rounded-lg overflow-hidden">
                <div className="overflow-x-auto max-h-52">
                  <table className="min-w-max w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>{['emp_no','date','check_in','check_out','status','location','ot','late','el','notes'].map(h =>
                        <th key={h} className="px-3 py-2 text-left font-semibold whitespace-nowrap">{h}</th>)}
                      </tr>
                    </thead>
                    <tbody>
                      {csvRows.slice(0, 8).map((r, i) => (
                        <tr key={i} className="border-t border-border">
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.employee_no}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.date}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.check_in ?? '—'}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.check_out ?? '—'}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.status}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.location ?? '—'}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.overtime_minutes ?? '—'}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.late_minutes ?? '—'}</td>
                          <td className="px-3 py-1.5 whitespace-nowrap">{r.early_leave_minutes ?? '—'}</td>
                          <td className="px-3 py-1.5 max-w-[80px] truncate">{r.notes ?? '—'}</td>
                        </tr>
                      ))}
                      {csvRows.length > 8 && <tr><td colSpan={10} className="px-3 py-1.5 text-center text-muted-foreground">+{csvRows.length - 8} more</td></tr>}
                    </tbody>
                  </table>
                </div>
                <div className="px-3 py-2 border-t border-border bg-muted/20 text-xs text-muted-foreground">{csvRows.length} rows ready</div>
              </div>
            )}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setCsvOpen(false)}>Cancel</Button>
              <Button disabled={csvRows.length === 0 || csvErrors.length > 0 || importing} onClick={handleImport}>
                <Upload className="h-4 w-4 mr-1.5" />{importing ? 'Importing…' : `Import ${csvRows.length} Rows`}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: 'Present',  value: stats.present,  icon: UserCheck, color: 'text-green-600' },
          { label: 'Absent',   value: stats.absent,   icon: UserX,     color: 'text-red-500' },
          { label: 'Late',     value: stats.late,     icon: Clock,     color: 'text-orange-500' },
          { label: 'On Leave', value: stats.on_leave, icon: Users,     color: 'text-blue-500' },
          { label: 'Remote',   value: stats.remote,   icon: Users,     color: 'text-purple-500' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <s.icon className={`h-4 w-4 ${s.color} shrink-0`} />
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className="text-xl font-bold leading-tight">{s.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-end">
        <div className="space-y-1"><Label className="text-xs">From</Label>
          <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-40" /></div>
        <div className="space-y-1"><Label className="text-xs">To</Label>
          <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-40" /></div>
        <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setPage(1); }}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {STATUSES.map(s => <SelectItem key={s} value={s}>{s.replace(/_/g, ' ')}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button onClick={load}>Apply</Button>
      </div>

      {/* Table */}
      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Date</TableHead>
                <TableHead className="whitespace-nowrap">Check In</TableHead>
                <TableHead className="whitespace-nowrap">Check Out</TableHead>
                <TableHead className="whitespace-nowrap">Work (min)</TableHead>
                <TableHead className="whitespace-nowrap">OT (min)</TableHead>
                <TableHead className="whitespace-nowrap">Late (min)</TableHead>
                <TableHead className="whitespace-nowrap">EL (min)</TableHead>
                <TableHead className="whitespace-nowrap">Location</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Notes</TableHead>
                <TableHead className="whitespace-nowrap">Edit</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? Array.from({ length: 8 }).map((_, i) => (
                <TableRow key={i}>{Array.from({ length: 12 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-14 bg-muted" /></TableCell>)}</TableRow>
              )) : records.length === 0 ? (
                <TableRow><TableCell colSpan={12} className="text-center py-10 text-muted-foreground">
                  <Timer className="h-8 w-8 mx-auto mb-2 opacity-40" />No records for this period
                </TableCell></TableRow>
              ) : records.map(r => {
                const emp = r.employee as { first_name: string; last_name: string; employee_no: string } | undefined;
                return (
                  <TableRow key={r.id}>
                    <TableCell className="whitespace-nowrap font-medium text-sm">
                      {emp ? `${emp.first_name} ${emp.last_name}` : r.employee_id.slice(0, 8)}
                      {emp && <span className="text-xs text-muted-foreground ml-1">#{emp.employee_no}</span>}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.attendance_date}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{formatTime(r.check_in)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{formatTime(r.check_out)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.work_minutes ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">
                      {r.overtime_minutes != null
                        ? <Badge variant="secondary" className="text-xs font-mono">{r.overtime_minutes}</Badge>
                        : <span className="text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">
                      {r.late_minutes != null && r.late_minutes > 0
                        ? <Badge className="bg-orange-100 text-orange-800 text-xs font-mono">{r.late_minutes}</Badge>
                        : <span className="text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">
                      {r.early_leave_minutes != null && r.early_leave_minutes > 0
                        ? <Badge className="bg-yellow-100 text-yellow-800 text-xs font-mono">{r.early_leave_minutes}</Badge>
                        : <span className="text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground max-w-[120px] truncate">
                      {r.location
                        ? <span className="flex items-center gap-1"><MapPin className="h-3 w-3 shrink-0" />{r.location}</span>
                        : '—'}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${STATUS_COLORS[r.status] ?? 'bg-muted text-muted-foreground'}`}>
                        {r.status.replace(/_/g, ' ')}
                      </span>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground max-w-[100px] truncate">{r.notes ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openEdit(r)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>
      {Math.ceil(total / pageSize) > 1 && (
        <div className="flex justify-end gap-2">
          <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</Button>
          <span className="text-sm self-center">{page} / {Math.ceil(total / pageSize)}</span>
          <Button size="sm" variant="outline" disabled={page >= Math.ceil(total / pageSize)} onClick={() => setPage(p => p + 1)}>Next</Button>
        </div>
      )}
        </TabsContent>

        {/* ── Report Tabs ── */}
        <TabsContent value="daily-report"    className="mt-4"><AttDailyReportTab /></TabsContent>
        <TabsContent value="late-report"     className="mt-4"><AttLateArrivalTab /></TabsContent>
        <TabsContent value="absence-report"  className="mt-4"><AttAbsenceReportTab /></TabsContent>
        <TabsContent value="overtime-report" className="mt-4"><AttOvertimeReportTab /></TabsContent>
        <TabsContent value="anomaly-report"  className="mt-4"><AttAnomalyTab /></TabsContent>
        <TabsContent value="shift-adherence" className="mt-4"><AttShiftAdherenceTab /></TabsContent>
        <TabsContent value="monthly-summary" className="mt-4"><AttMonthlySummaryTab /></TabsContent>
      </Tabs>
    </div>
  );
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sbAtt = supabase as any;

/* ── FR-ATT-024: Daily Absence Report ── */
function AttDailyReportTab() {
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [rows, setRows] = useState<{ status: string; count: number }[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sbAtt.from('attendance_records')
      .select('status').eq('attendance_date', date).limit(500);
    const map: Record<string, number> = {};
    (data ?? []).forEach((r: { status: string }) => { map[r.status] = (map[r.status] ?? 0) + 1; });
    setRows(Object.entries(map).map(([status, count]) => ({ status, count })).sort((a, b) => b.count - a.count));
    setLoading(false);
  }, [date]);

  useEffect(() => { load(); }, [load]);

  const total = rows.reduce((s, r) => s + r.count, 0);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-3 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><BarChart2 className="h-4 w-4" />Daily Attendance Report</CardTitle>
        <div className="flex items-center gap-2">
          <Input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-36 h-8 text-sm" />
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Button variant="outline" size="sm" onClick={() => exportToCsv(rows as unknown as Record<string,unknown>[], 'Attendance_Daily_Report')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <div className="space-y-2">{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-9 w-full bg-muted"/>)}</div> : (
          <>
            <div className="flex flex-wrap gap-2 mb-4">
              {rows.map(r => (
                <div key={r.status} className="px-4 py-2 rounded-lg bg-muted/50 text-center min-w-[100px]">
                  <p className="text-xl font-bold">{r.count}</p>
                  <p className="text-xs text-muted-foreground capitalize">{r.status.replace('_', ' ')}</p>
                </div>
              ))}
              <div className="px-4 py-2 rounded-lg bg-primary/10 text-center min-w-[100px]">
                <p className="text-xl font-bold text-primary">{total}</p>
                <p className="text-xs text-muted-foreground">Total Records</p>
              </div>
            </div>
            {total === 0 && <p className="text-center text-muted-foreground py-6">No attendance records for {date}.</p>}
          </>
        )}
      </CardContent>
    </Card>
  );
}

/* ── FR-ATT-025: Late Arrival Report ── */
function AttLateArrivalTab() {
  const [month, setMonth] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`; });
  const [rows, setRows] = useState<{ employee_name: string; dept: string; late_count: number; total_late_mins: number; avg_late_mins: number }[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [y, m] = month.split('-').map(Number);
    const start = `${y}-${String(m).padStart(2,'0')}-01`;
    const end   = new Date(y, m, 0).toISOString().split('T')[0];
    const { data } = await sbAtt.from('attendance_records')
      .select('employee_id, late_minutes, employees(full_name, departments(name))')
      .eq('status', 'late').gte('attendance_date', start).lte('attendance_date', end).limit(1000);
    const map: Record<string, { name: string; dept: string; count: number; mins: number }> = {};
    (data ?? []).forEach((r: { employee_id: string; late_minutes: number; employees: { full_name: string; departments: { name: string } } }) => {
      const k = r.employee_id;
      if (!map[k]) map[k] = { name: r.employees?.full_name ?? k.substring(0,8), dept: r.employees?.departments?.name ?? '—', count: 0, mins: 0 };
      map[k].count++; map[k].mins += r.late_minutes ?? 0;
    });
    setRows(Object.values(map).map(v => ({ employee_name: v.name, dept: v.dept, late_count: v.count, total_late_mins: v.mins, avg_late_mins: v.count > 0 ? v.mins / v.count : 0 })).sort((a, b) => b.late_count - a.late_count));
    setLoading(false);
  }, [month]);

  useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-3 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><AlertTriangle className="h-4 w-4" />Late Arrival Report</CardTitle>
        <div className="flex items-center gap-2">
          <input type="month" value={month} onChange={e => setMonth(e.target.value)} className="text-sm border rounded px-2 py-1 bg-background" />
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Button variant="outline" size="sm" onClick={() => exportToCsv(rows as unknown as Record<string,unknown>[], 'Late_Arrivals')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <div className="space-y-2">{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-9 w-full bg-muted"/>)}</div> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Department</TableHead>
                <TableHead className="whitespace-nowrap text-right">Late Days</TableHead>
                <TableHead className="whitespace-nowrap text-right">Total Late Mins</TableHead>
                <TableHead className="whitespace-nowrap text-right">Avg Late Mins</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0
                  ? <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">No late arrivals for {month}.</TableCell></TableRow>
                  : rows.map((r, i) => (
                    <TableRow key={i}>
                      <TableCell className="whitespace-nowrap font-medium">{r.employee_name}</TableCell>
                      <TableCell className="whitespace-nowrap">{r.dept}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">
                        <Badge variant={r.late_count >= 3 ? 'destructive' : 'secondary'}>{r.late_count}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-right">{r.total_late_mins}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">{r.avg_late_mins.toFixed(0)}</TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ── FR-ATT-026: Absence Report ── */
function AttAbsenceReportTab() {
  const [month, setMonth] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`; });
  const [rows, setRows] = useState<{ employee_name: string; dept: string; absent_days: number }[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [y, m] = month.split('-').map(Number);
    const start = `${y}-${String(m).padStart(2,'0')}-01`;
    const end   = new Date(y, m, 0).toISOString().split('T')[0];
    const { data } = await sbAtt.from('attendance_records')
      .select('employee_id, employees(full_name, departments(name))')
      .eq('status', 'absent').gte('attendance_date', start).lte('attendance_date', end).limit(1000);
    const map: Record<string, { name: string; dept: string; count: number }> = {};
    (data ?? []).forEach((r: { employee_id: string; employees: { full_name: string; departments: { name: string } } }) => {
      const k = r.employee_id;
      if (!map[k]) map[k] = { name: r.employees?.full_name ?? k.substring(0,8), dept: r.employees?.departments?.name ?? '—', count: 0 };
      map[k].count++;
    });
    setRows(Object.values(map).map(v => ({ employee_name: v.name, dept: v.dept, absent_days: v.count })).sort((a, b) => b.absent_days - a.absent_days));
    setLoading(false);
  }, [month]);

  useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-3 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><UserX className="h-4 w-4" />Absence Report</CardTitle>
        <div className="flex items-center gap-2">
          <input type="month" value={month} onChange={e => setMonth(e.target.value)} className="text-sm border rounded px-2 py-1 bg-background" />
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Button variant="outline" size="sm" onClick={() => exportToCsv(rows as unknown as Record<string,unknown>[], 'Absences_Report')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <div className="space-y-2">{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-9 w-full bg-muted"/>)}</div> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Department</TableHead>
                <TableHead className="whitespace-nowrap text-right">Absent Days</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0
                  ? <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground py-8">No absences recorded for {month}.</TableCell></TableRow>
                  : rows.map((r, i) => (
                    <TableRow key={i}>
                      <TableCell className="whitespace-nowrap font-medium">{r.employee_name}</TableCell>
                      <TableCell className="whitespace-nowrap">{r.dept}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">
                        <Badge variant={r.absent_days >= 3 ? 'destructive' : 'secondary'}>{r.absent_days}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ── FR-ATT-030: Overtime Report ── */
function AttOvertimeReportTab() {
  const [month, setMonth] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`; });
  const [rows, setRows] = useState<{ employee_name: string; dept: string; ot_days: number; total_ot_mins: number; total_ot_hrs: number }[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [y, m] = month.split('-').map(Number);
    const start = `${y}-${String(m).padStart(2,'0')}-01`;
    const end   = new Date(y, m, 0).toISOString().split('T')[0];
    const { data } = await sbAtt.from('attendance_records')
      .select('employee_id, overtime_minutes, employees(full_name, departments(name))')
      .gt('overtime_minutes', 0).gte('attendance_date', start).lte('attendance_date', end).limit(1000);
    const map: Record<string, { name: string; dept: string; count: number; mins: number }> = {};
    (data ?? []).forEach((r: { employee_id: string; overtime_minutes: number; employees: { full_name: string; departments: { name: string } } }) => {
      const k = r.employee_id;
      if (!map[k]) map[k] = { name: r.employees?.full_name ?? k.substring(0,8), dept: r.employees?.departments?.name ?? '—', count: 0, mins: 0 };
      map[k].count++; map[k].mins += r.overtime_minutes ?? 0;
    });
    setRows(Object.values(map).map(v => ({ employee_name: v.name, dept: v.dept, ot_days: v.count, total_ot_mins: v.mins, total_ot_hrs: v.mins / 60 })).sort((a, b) => b.total_ot_mins - a.total_ot_mins));
    setLoading(false);
  }, [month]);

  useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-3 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><TrendingUp className="h-4 w-4" />Overtime Report</CardTitle>
        <div className="flex items-center gap-2">
          <input type="month" value={month} onChange={e => setMonth(e.target.value)} className="text-sm border rounded px-2 py-1 bg-background" />
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Button variant="outline" size="sm" onClick={() => exportToCsv(rows as unknown as Record<string,unknown>[], 'Overtime_Report')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <div className="space-y-2">{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-9 w-full bg-muted"/>)}</div> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Department</TableHead>
                <TableHead className="whitespace-nowrap text-right">OT Days</TableHead>
                <TableHead className="whitespace-nowrap text-right">Total OT Hrs</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0
                  ? <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-8">No overtime for {month}.</TableCell></TableRow>
                  : rows.map((r, i) => (
                    <TableRow key={i}>
                      <TableCell className="whitespace-nowrap font-medium">{r.employee_name}</TableCell>
                      <TableCell className="whitespace-nowrap">{r.dept}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">{r.ot_days}</TableCell>
                      <TableCell className="whitespace-nowrap text-right font-semibold">{r.total_ot_hrs.toFixed(1)}</TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ── FR-ATT-028: Anomaly Detection ── */
function AttAnomalyTab() {
  const [rows, setRows] = useState<{ employee_name: string; date: string; check_in: string; check_out: string; anomaly: string }[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 30);
    const { data } = await sbAtt.from('attendance_records')
      .select('employee_id, attendance_date, check_in, check_out, work_minutes, late_minutes, employees(full_name)')
      .gte('attendance_date', cutoff.toISOString().split('T')[0]).limit(500);
    const anomalies: typeof rows = [];
    (data ?? []).forEach((r: { employee_id: string; attendance_date: string; check_in: string; check_out: string; work_minutes: number; late_minutes: number; employees: { full_name: string } }) => {
      const name = r.employees?.full_name ?? r.employee_id?.substring(0,8);
      const ci = r.check_in ? new Date(r.check_in).toTimeString().substring(0,5) : '—';
      const co = r.check_out ? new Date(r.check_out).toTimeString().substring(0,5) : '—';
      if (!r.check_in && !r.check_out) anomalies.push({ employee_name: name, date: r.attendance_date, check_in: ci, check_out: co, anomaly: 'Missing check-in & check-out' });
      else if (!r.check_out) anomalies.push({ employee_name: name, date: r.attendance_date, check_in: ci, check_out: co, anomaly: 'Missing check-out' });
      else if ((r.work_minutes ?? 0) > 720) anomalies.push({ employee_name: name, date: r.attendance_date, check_in: ci, check_out: co, anomaly: 'Excessive hours (>12h)' });
      else if ((r.late_minutes ?? 0) > 60) anomalies.push({ employee_name: name, date: r.attendance_date, check_in: ci, check_out: co, anomaly: `Late by ${r.late_minutes} mins` });
    });
    setRows(anomalies.slice(0, 100));
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-3 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><AlertCircle className="h-4 w-4" />Attendance Anomalies (Last 30 Days)</CardTitle>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Button variant="outline" size="sm" onClick={() => exportToCsv(rows as unknown as Record<string,unknown>[], 'Attendance_Anomalies')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <div className="space-y-2">{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-9 w-full bg-muted"/>)}</div> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Date</TableHead>
                <TableHead className="whitespace-nowrap">Check In</TableHead>
                <TableHead className="whitespace-nowrap">Check Out</TableHead>
                <TableHead className="whitespace-nowrap">Anomaly</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0
                  ? <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">No anomalies detected in the last 30 days.</TableCell></TableRow>
                  : rows.map((r, i) => (
                    <TableRow key={i} className="bg-amber-50/20">
                      <TableCell className="whitespace-nowrap font-medium">{r.employee_name}</TableCell>
                      <TableCell className="whitespace-nowrap">{r.date}</TableCell>
                      <TableCell className="whitespace-nowrap">{r.check_in}</TableCell>
                      <TableCell className="whitespace-nowrap">{r.check_out}</TableCell>
                      <TableCell className="whitespace-nowrap"><Badge variant="destructive">{r.anomaly}</Badge></TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ── FR-ATT-029: Shift Adherence ── */
function AttShiftAdherenceTab() {
  const [month, setMonth] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`; });
  const [rows, setRows] = useState<{ employee_name: string; total_days: number; on_time: number; late: number; early_leave: number; adherence_pct: number }[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [y, m] = month.split('-').map(Number);
    const start = `${y}-${String(m).padStart(2,'0')}-01`;
    const end   = new Date(y, m, 0).toISOString().split('T')[0];
    const { data } = await sbAtt.from('attendance_records')
      .select('employee_id, status, late_minutes, early_leave_minutes, employees(full_name)')
      .gte('attendance_date', start).lte('attendance_date', end)
      .in('status', ['present','late','early_leave']).limit(2000);
    const map: Record<string, { name: string; total: number; onTime: number; late: number; early: number }> = {};
    (data ?? []).forEach((r: { employee_id: string; status: string; late_minutes: number; early_leave_minutes: number; employees: { full_name: string } }) => {
      const k = r.employee_id;
      if (!map[k]) map[k] = { name: r.employees?.full_name ?? k.substring(0,8), total: 0, onTime: 0, late: 0, early: 0 };
      map[k].total++;
      if ((r.late_minutes ?? 0) <= 5 && (r.early_leave_minutes ?? 0) <= 5) map[k].onTime++;
      if ((r.late_minutes ?? 0) > 5) map[k].late++;
      if ((r.early_leave_minutes ?? 0) > 5) map[k].early++;
    });
    setRows(Object.values(map).map(v => ({ employee_name: v.name, total_days: v.total, on_time: v.onTime, late: v.late, early_leave: v.early, adherence_pct: v.total > 0 ? (v.onTime / v.total) * 100 : 0 })).sort((a, b) => a.adherence_pct - b.adherence_pct));
    setLoading(false);
  }, [month]);

  useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-3 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><Shield className="h-4 w-4" />Shift Adherence Report</CardTitle>
        <div className="flex items-center gap-2">
          <input type="month" value={month} onChange={e => setMonth(e.target.value)} className="text-sm border rounded px-2 py-1 bg-background" />
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Button variant="outline" size="sm" onClick={() => exportToCsv(rows as unknown as Record<string,unknown>[], 'Shift_Adherence')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <div className="space-y-2">{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-9 w-full bg-muted"/>)}</div> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap text-right">Work Days</TableHead>
                <TableHead className="whitespace-nowrap text-right">On Time</TableHead>
                <TableHead className="whitespace-nowrap text-right">Late</TableHead>
                <TableHead className="whitespace-nowrap text-right">Early Leave</TableHead>
                <TableHead className="whitespace-nowrap text-right">Adherence</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0
                  ? <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No data for {month}.</TableCell></TableRow>
                  : rows.map((r, i) => (
                    <TableRow key={i} className={r.adherence_pct < 80 ? 'bg-red-50/20' : ''}>
                      <TableCell className="whitespace-nowrap font-medium">{r.employee_name}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">{r.total_days}</TableCell>
                      <TableCell className="whitespace-nowrap text-right text-green-600">{r.on_time}</TableCell>
                      <TableCell className="whitespace-nowrap text-right text-amber-600">{r.late}</TableCell>
                      <TableCell className="whitespace-nowrap text-right text-orange-600">{r.early_leave}</TableCell>
                      <TableCell className="whitespace-nowrap text-right">
                        <Badge variant={r.adherence_pct >= 90 ? 'default' : r.adherence_pct >= 75 ? 'secondary' : 'destructive'}>{r.adherence_pct.toFixed(0)}%</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ── Monthly Summary ── */
function AttMonthlySummaryTab() {
  const [month, setMonth] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`; });
  const [stats, setStats] = useState({ present: 0, absent: 0, late: 0, on_leave: 0, remote: 0, total: 0 });
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [y, m] = month.split('-').map(Number);
    const start = `${y}-${String(m).padStart(2,'0')}-01`;
    const end   = new Date(y, m, 0).toISOString().split('T')[0];
    const { data } = await sbAtt.from('attendance_records')
      .select('status').gte('attendance_date', start).lte('attendance_date', end).limit(5000);
    const all = data ?? [];
    setStats({
      present:  all.filter((r: { status: string }) => r.status === 'present').length,
      absent:   all.filter((r: { status: string }) => r.status === 'absent').length,
      late:     all.filter((r: { status: string }) => r.status === 'late').length,
      on_leave: all.filter((r: { status: string }) => r.status === 'on_leave').length,
      remote:   all.filter((r: { status: string }) => r.status === 'remote').length,
      total:    all.length,
    });
    setLoading(false);
  }, [month]);

  useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-3 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><CalendarDays className="h-4 w-4" />Monthly Attendance Summary</CardTitle>
        <div className="flex items-center gap-2">
          <input type="month" value={month} onChange={e => setMonth(e.target.value)} className="text-sm border rounded px-2 py-1 bg-background" />
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh</Button>
          <Button variant="outline" size="sm" onClick={() => exportToCsv([stats] as unknown as Record<string,unknown>[], 'Monthly_Attendance_Summary')}><Download className="h-3.5 w-3.5 mr-1.5" />Export CSV</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <div className="grid grid-cols-2 md:grid-cols-3 gap-3">{Array.from({length:6}).map((_,i)=><Skeleton key={i} className="h-16 bg-muted"/>)}</div> : (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {[
              { label: 'Total Records', value: stats.total,    color: 'text-foreground' },
              { label: 'Present',       value: stats.present,  color: 'text-green-600' },
              { label: 'Absent',        value: stats.absent,   color: 'text-red-600' },
              { label: 'Late',          value: stats.late,     color: 'text-amber-600' },
              { label: 'On Leave',      value: stats.on_leave, color: 'text-blue-600' },
              { label: 'Remote',        value: stats.remote,   color: 'text-purple-600' },
            ].map(({ label, value, color }) => (
              <div key={label} className="p-4 rounded-lg bg-muted/40">
                <p className={`text-2xl font-bold ${color}`}>{value}</p>
                <p className="text-xs text-muted-foreground mt-1">{label}</p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

