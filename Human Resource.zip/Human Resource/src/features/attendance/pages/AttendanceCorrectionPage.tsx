import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import type { AttendanceCorrection, AttendanceExceptionRule } from '@/types/database.types';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Separator } from '@/components/ui/separator';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { Plus, RefreshCw, Pencil, Trash2, ShieldAlert, UserCog, ClipboardEdit } from 'lucide-react';

// ── Correction Types ──────────────────────────────────────────
const CORRECTION_TYPES = ['MISSED_PUNCH', 'TIME_ADJUSTMENT', 'STATUS_OVERRIDE', 'BULK'] as const;
const EXCEPTION_TYPES  = ['EXEMPT_FROM_ATTENDANCE', 'FLEXIBLE_HOURS', 'REMOTE_WORK'] as const;

const CORRECTION_COLORS: Record<string, string> = {
  MISSED_PUNCH:    'bg-red-100 text-red-800',
  TIME_ADJUSTMENT: 'bg-blue-100 text-blue-800',
  STATUS_OVERRIDE: 'bg-orange-100 text-orange-800',
  BULK:            'bg-purple-100 text-purple-800',
};
const EXCEPTION_COLORS: Record<string, string> = {
  EXEMPT_FROM_ATTENDANCE: 'bg-red-100 text-red-800',
  FLEXIBLE_HOURS:         'bg-green-100 text-green-800',
  REMOTE_WORK:            'bg-blue-100 text-blue-800',
};

// ── Schemas ───────────────────────────────────────────────────
const corrSchema = z.object({
  employee_id:     z.string().min(1, 'Required'),
  attendance_date: z.string().min(1, 'Required'),
  correction_type: z.enum(CORRECTION_TYPES),
  original_value:  z.string().optional(),
  corrected_value: z.string().optional(),
  justification:   z.string().min(5, 'Provide a justification (min 5 chars)'),
});
type CorrForm = z.infer<typeof corrSchema>;

const excSchema = z.object({
  employee_id:    z.string().min(1, 'Required'),
  exception_type: z.enum(EXCEPTION_TYPES),
  effective_from: z.string().min(1, 'Required'),
  effective_to:   z.string().min(1, 'Required'),
  reason:         z.string().optional(),
});
type ExcForm = z.infer<typeof excSchema>;

export function AttendanceCorrectionPage() {
  const [tab, setTab] = useState<'corrections' | 'exceptions'>('corrections');

  // Corrections
  const [corrections, setCorrections] = useState<AttendanceCorrection[]>([]);
  const [corrLoading, setCorrLoading] = useState(true);
  const [corrTotal,   setCorrTotal]   = useState(0);
  const [corrPage,    setCorrPage]    = useState(1);
  const [corrDialog,  setCorrDialog]  = useState(false);
  const [editCorr,    setEditCorr]    = useState<AttendanceCorrection | null>(null);
  const [corrSaving,  setCorrSaving]  = useState(false);
  // Server-side agg counts — not limited to current page
  const [corrAgg, setCorrAgg] = useState({ missedPunch: 0, timeAdj: 0 });

  // Exceptions
  const [exceptions, setExceptions] = useState<AttendanceExceptionRule[]>([]);
  const [excLoading,  setExcLoading]  = useState(true);
  const [excDialog,   setExcDialog]   = useState(false);
  const [editExc,     setEditExc]     = useState<AttendanceExceptionRule | null>(null);
  const [excSaving,   setExcSaving]   = useState(false);

  const PAGE = 20;

  const corrForm = useForm<CorrForm>({
    resolver: zodResolver(corrSchema),
    defaultValues: { employee_id: '', attendance_date: '', correction_type: 'MISSED_PUNCH', justification: '' },
  });
  const excForm = useForm<ExcForm>({
    resolver: zodResolver(excSchema),
    defaultValues: { employee_id: '', exception_type: 'FLEXIBLE_HOURS', effective_from: '', effective_to: '' },
  });

  // Load
  const loadCorrections = useCallback(async () => {
    setCorrLoading(true);
    const { data, count, error } = await supabase
      .from('attendance_corrections')
      .select('*, employee:employees!attendance_corrections_employee_id_fkey(id,first_name,last_name,employee_no), corrected_by_employee:employees!attendance_corrections_corrected_by_fkey(id,first_name,last_name)', { count: 'exact' })
      .eq('is_deleted', 0)
      .order('attendance_date', { ascending: false })
      .range((corrPage - 1) * PAGE, corrPage * PAGE - 1);
    if (error) toast.error('Failed to load corrections');
    else { setCorrections((data ?? []) as AttendanceCorrection[]); setCorrTotal(count ?? 0); }
    setCorrLoading(false);
  }, [corrPage]);

  const loadCorrAggStats = useCallback(async () => {
    const { data } = await supabase
      .from('attendance_corrections')
      .select('correction_type')
      .eq('is_deleted', 0);
    const rows = (data ?? []) as { correction_type: string }[];
    setCorrAgg({
      missedPunch: rows.filter(r => r.correction_type === 'MISSED_PUNCH').length,
      timeAdj:     rows.filter(r => r.correction_type === 'TIME_ADJUSTMENT').length,
    });
  }, []);

  const loadExceptions = useCallback(async () => {
    setExcLoading(true);
    const { data, error } = await supabase
      .from('attendance_exception_rules')
      .select('*, employee:employees!attendance_exception_rules_employee_id_fkey(id,first_name,last_name,employee_no)')
      .eq('is_deleted', 0)
      .order('effective_from', { ascending: false });
    if (error) toast.error('Failed to load exception rules');
    else setExceptions((data ?? []) as AttendanceExceptionRule[]);
    setExcLoading(false);
  }, []);

  useEffect(() => { loadCorrections(); }, [loadCorrections]);
  useEffect(() => { loadExceptions(); }, [loadExceptions]);
  useEffect(() => { loadCorrAggStats(); }, [loadCorrAggStats]);

  // Correction CRUD
  const openCreateCorr = () => {
    setEditCorr(null);
    corrForm.reset({ employee_id: '', attendance_date: new Date().toISOString().split('T')[0], correction_type: 'MISSED_PUNCH', justification: '' });
    setCorrDialog(true);
  };
  const openEditCorr = (c: AttendanceCorrection) => {
    setEditCorr(c);
    corrForm.reset({
      employee_id: c.employee_id,
      attendance_date: c.attendance_date,
      correction_type: c.correction_type,
      original_value: c.original_value ?? '',
      corrected_value: c.corrected_value ?? '',
      justification: c.justification,
    });
    setCorrDialog(true);
  };
  const submitCorr = corrForm.handleSubmit(async (vals) => {
    setCorrSaving(true);
    const payload = {
      employee_id:     vals.employee_id,
      attendance_date: vals.attendance_date,
      correction_type: vals.correction_type,
      original_value:  vals.original_value || null,
      corrected_value: vals.corrected_value || null,
      justification:   vals.justification,
      updated_at:      new Date().toISOString(),
    };
    const { error } = editCorr
      ? await supabase.from('attendance_corrections').update(payload).eq('id', editCorr.id)
      : await supabase.from('attendance_corrections').insert(payload);
    if (error) toast.error(error.message);
    else { toast.success(editCorr ? 'Correction updated' : 'Correction logged'); setCorrDialog(false); loadCorrections(); }
    setCorrSaving(false);
  });
  const deleteCorr = async (id: string) => {
    if (!confirm('Delete this correction record?')) return;
    const { error } = await supabase.from('attendance_corrections').update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Correction deleted'); loadCorrections(); }
  };

  // Exception CRUD
  const openCreateExc = () => {
    setEditExc(null);
    excForm.reset({ employee_id: '', exception_type: 'FLEXIBLE_HOURS', effective_from: '', effective_to: '' });
    setExcDialog(true);
  };
  const openEditExc = (e: AttendanceExceptionRule) => {
    setEditExc(e);
    excForm.reset({
      employee_id:    e.employee_id,
      exception_type: e.exception_type,
      effective_from: e.effective_from?.split('T')[0] ?? '',
      effective_to:   e.effective_to === '9999-12-31T23:59:59.999999+00:00' ? '' : (e.effective_to?.split('T')[0] ?? ''),
      reason:         e.reason ?? '',
    });
    setExcDialog(true);
  };
  const submitExc = excForm.handleSubmit(async (vals) => {
    setExcSaving(true);
    const payload = {
      employee_id:    vals.employee_id,
      exception_type: vals.exception_type,
      effective_from: vals.effective_from,
      effective_to:   vals.effective_to || '9999-12-31T23:59:59Z',
      reason:         vals.reason || null,
      updated_at:     new Date().toISOString(),
    };
    const { error } = editExc
      ? await supabase.from('attendance_exception_rules').update(payload).eq('id', editExc.id)
      : await supabase.from('attendance_exception_rules').insert(payload);
    if (error) toast.error(error.message);
    else { toast.success(editExc ? 'Exception updated' : 'Exception rule created'); setExcDialog(false); loadExceptions(); }
    setExcSaving(false);
  });
  const deleteExc = async (id: string) => {
    if (!confirm('Remove this exception rule?')) return;
    const { error } = await supabase.from('attendance_exception_rules').update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Exception removed'); loadExceptions(); }
  };

  const corrPages = Math.ceil(corrTotal / PAGE);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Attendance Corrections & Exceptions</h1>
          <p className="text-sm text-muted-foreground mt-0.5">HR-initiated corrections and employee attendance exception rules</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => { loadCorrections(); loadExceptions(); loadCorrAggStats(); }}>
            <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
          </Button>
          {tab === 'corrections'
            ? <Button size="sm" onClick={openCreateCorr}><Plus className="h-4 w-4 mr-1.5" />Log Correction</Button>
            : <Button size="sm" onClick={openCreateExc}><Plus className="h-4 w-4 mr-1.5" />Add Exception</Button>}
        </div>
      </div>

      {/* Summary row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Corrections',    value: corrTotal,                                                                icon: ClipboardEdit, color: 'text-primary' },
          { label: 'Missed Punches',       value: corrAgg.missedPunch, icon: ShieldAlert,   color: 'text-red-500' },
          { label: 'Time Adjustments',     value: corrAgg.timeAdj,     icon: Pencil,         color: 'text-blue-500' },
          { label: 'Exception Rules',      value: exceptions.length,                                                       icon: UserCog,       color: 'text-green-600' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <s.icon className={`h-4 w-4 ${s.color} shrink-0`} />
            <div><p className="text-xs text-muted-foreground">{s.label}</p><p className="text-xl font-bold">{s.value}</p></div>
          </div>
        ))}
      </div>

      <Tabs value={tab} onValueChange={v => setTab(v as typeof tab)}>
        <TabsList>
          <TabsTrigger value="corrections"><ClipboardEdit className="h-4 w-4 mr-1.5" />Corrections ({corrTotal})</TabsTrigger>
          <TabsTrigger value="exceptions"><UserCog className="h-4 w-4 mr-1.5" />Exception Rules ({exceptions.length})</TabsTrigger>
        </TabsList>

        {/* ── CORRECTIONS ── */}
        <TabsContent value="corrections" className="mt-4 space-y-3">
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Date</TableHead>
                    <TableHead className="whitespace-nowrap">Type</TableHead>
                    <TableHead className="whitespace-nowrap">Original Value</TableHead>
                    <TableHead className="whitespace-nowrap">Corrected Value</TableHead>
                    <TableHead className="whitespace-nowrap">Justification</TableHead>
                    <TableHead className="whitespace-nowrap">Corrected By</TableHead>
                    <TableHead className="whitespace-nowrap">Logged At</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {corrLoading ? Array.from({ length: 6 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 9 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-16 bg-muted" /></TableCell>)}</TableRow>
                  )) : corrections.length === 0 ? (
                    <TableRow><TableCell colSpan={9} className="text-center py-10 text-muted-foreground">
                      <ClipboardEdit className="h-8 w-8 mx-auto mb-2 opacity-40" />No attendance corrections on record
                    </TableCell></TableRow>
                  ) : corrections.map(c => {
                    const emp = c.employee as { first_name: string; last_name: string; employee_no: string } | undefined;
                    const cor = c.corrected_by_employee as { first_name: string; last_name: string } | undefined;
                    return (
                      <TableRow key={c.id}>
                        <TableCell className="whitespace-nowrap font-medium text-sm">
                          {emp ? `${emp.first_name} ${emp.last_name}` : '—'}
                          {emp && <span className="text-xs text-muted-foreground ml-1">#{emp.employee_no}</span>}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{c.attendance_date}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${CORRECTION_COLORS[c.correction_type] ?? 'bg-muted text-muted-foreground'}`}>
                            {c.correction_type.replace('_',' ')}
                          </span>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm max-w-[120px] truncate text-muted-foreground">{c.original_value || '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm max-w-[120px] truncate">{c.corrected_value || '—'}</TableCell>
                        <TableCell className="text-sm max-w-[180px]">
                          <p className="truncate" title={c.justification}>{c.justification}</p>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                          {cor ? `${cor.first_name} ${cor.last_name}` : '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                          {new Date(c.created_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex gap-1.5">
                            <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openEditCorr(c)}><Pencil className="h-3.5 w-3.5" /></Button>
                            <Button size="sm" variant="outline" className="h-7 px-2 text-destructive hover:bg-destructive/10" onClick={() => deleteCorr(c.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
          {corrPages > 1 && (
            <div className="flex justify-end gap-2">
              <Button size="sm" variant="outline" disabled={corrPage <= 1} onClick={() => setCorrPage(p => p - 1)}>Prev</Button>
              <span className="text-sm self-center">{corrPage} / {corrPages}</span>
              <Button size="sm" variant="outline" disabled={corrPage >= corrPages} onClick={() => setCorrPage(p => p + 1)}>Next</Button>
            </div>
          )}
        </TabsContent>

        {/* ── EXCEPTIONS ── */}
        <TabsContent value="exceptions" className="mt-4">
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Exception Type</TableHead>
                    <TableHead className="whitespace-nowrap">Effective From</TableHead>
                    <TableHead className="whitespace-nowrap">Effective To</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Reason</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {excLoading ? Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 7 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-16 bg-muted" /></TableCell>)}</TableRow>
                  )) : exceptions.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">
                      <UserCog className="h-8 w-8 mx-auto mb-2 opacity-40" />No exception rules configured
                    </TableCell></TableRow>
                  ) : exceptions.map(ex => {
                    const emp = ex.employee as { first_name: string; last_name: string; employee_no: string } | undefined;
                    const isActive = ex.is_current === 1 && new Date(ex.effective_from) <= new Date()
                      && (ex.effective_to.startsWith('9999') || new Date(ex.effective_to) >= new Date());
                    return (
                      <TableRow key={ex.id}>
                        <TableCell className="whitespace-nowrap font-medium text-sm">
                          {emp ? `${emp.first_name} ${emp.last_name}` : '—'}
                          {emp && <span className="text-xs text-muted-foreground ml-1">#{emp.employee_no}</span>}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${EXCEPTION_COLORS[ex.exception_type] ?? 'bg-muted text-muted-foreground'}`}>
                            {ex.exception_type.replace(/_/g,' ')}
                          </span>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{ex.effective_from?.split('T')[0] ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">
                          {ex.effective_to?.startsWith('9999') ? 'Indefinite' : (ex.effective_to?.split('T')[0] ?? '—')}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Badge variant={isActive ? 'default' : 'secondary'} className="text-xs">
                            {isActive ? 'Active' : 'Expired'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm max-w-[200px]">
                          <p className="truncate" title={ex.reason ?? ''}>{ex.reason || '—'}</p>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex gap-1.5">
                            <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openEditExc(ex)}><Pencil className="h-3.5 w-3.5" /></Button>
                            <Button size="sm" variant="outline" className="h-7 px-2 text-destructive hover:bg-destructive/10" onClick={() => deleteExc(ex.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* ── Correction Dialog ── */}
      <Dialog open={corrDialog} onOpenChange={o => { if (!o) setCorrDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editCorr ? 'Edit' : 'Log'} Attendance Correction</DialogTitle></DialogHeader>
          <Form {...corrForm}>
            <form onSubmit={submitCorr} className="space-y-4 mt-1">
              <FormField control={corrForm.control} name="employee_id" render={({ field }) => (
                <FormItem><FormLabel>Employee *</FormLabel><FormControl>
                  <EmployeeSelect value={field.value} onChange={field.onChange} required />
                </FormControl><FormMessage /></FormItem>
              )} />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={corrForm.control} name="attendance_date" render={({ field }) => (
                  <FormItem><FormLabel>Date *</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={corrForm.control} name="correction_type" render={({ field }) => (
                  <FormItem><FormLabel>Correction Type *</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        {CORRECTION_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace('_',' ')}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={corrForm.control} name="original_value" render={({ field }) => (
                <FormItem><FormLabel>Original Value</FormLabel><FormControl><Input {...field} placeholder="e.g. 09:30 or ABSENT" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={corrForm.control} name="corrected_value" render={({ field }) => (
                <FormItem><FormLabel>Corrected Value</FormLabel><FormControl><Input {...field} placeholder="e.g. 09:00 or PRESENT" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={corrForm.control} name="justification" render={({ field }) => (
                <FormItem><FormLabel>Justification *</FormLabel><FormControl><Textarea rows={3} {...field} placeholder="Reason for correction…" /></FormControl><FormMessage /></FormItem>
              )} />
              <Separator />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setCorrDialog(false)}>Cancel</Button>
                <Button type="submit" disabled={corrSaving}>{corrSaving ? 'Saving…' : (editCorr ? 'Update' : 'Log Correction')}</Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* ── Exception Dialog ── */}
      <Dialog open={excDialog} onOpenChange={o => { if (!o) setExcDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editExc ? 'Edit' : 'Add'} Exception Rule</DialogTitle></DialogHeader>
          <Form {...excForm}>
            <form onSubmit={submitExc} className="space-y-4 mt-1">
              <FormField control={excForm.control} name="employee_id" render={({ field }) => (
                <FormItem><FormLabel>Employee *</FormLabel><FormControl>
                  <EmployeeSelect value={field.value} onChange={field.onChange} required />
                </FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={excForm.control} name="exception_type" render={({ field }) => (
                <FormItem><FormLabel>Exception Type *</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>
                      {EXCEPTION_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace(/_/g,' ')}</SelectItem>)}
                    </SelectContent>
                  </Select>
                <FormMessage /></FormItem>
              )} />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={excForm.control} name="effective_from" render={({ field }) => (
                  <FormItem><FormLabel>Effective From *</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={excForm.control} name="effective_to" render={({ field }) => (
                  <FormItem><FormLabel>Effective To</FormLabel><FormControl><Input type="date" {...field} placeholder="Leave blank = indefinite" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={excForm.control} name="reason" render={({ field }) => (
                <FormItem><FormLabel>Reason</FormLabel><FormControl><Textarea rows={2} {...field} placeholder="Optional reason…" /></FormControl><FormMessage /></FormItem>
              )} />
              <Separator />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setExcDialog(false)}>Cancel</Button>
                <Button type="submit" disabled={excSaving}>{excSaving ? 'Saving…' : (editExc ? 'Update' : 'Add Rule')}</Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
