import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import type { WorkCalendar, Holiday } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import {
  CalendarDays, Plus, RefreshCw, Pencil, Trash2,
  Calendar, Globe, Clock, AlertCircle, Sun
} from 'lucide-react';

// ── Weekdays ──────────────────────────────────────────────────
const ALL_DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as const;

// ── Schemas ───────────────────────────────────────────────────
const calSchema = z.object({
  calendar_name: z.string().min(1, 'Required'),
  working_days: z.array(z.string()).min(1, 'Select at least one day'),
  daily_hours: z.coerce.number().min(1).max(24),
});
type CalForm = z.infer<typeof calSchema>;

const holidaySchema = z.object({
  holiday_name: z.string().min(1, 'Required'),
  holiday_date: z.string().min(1, 'Required'),
  is_recurring: z.boolean(),
  recurrence_type: z.enum(['NONE', 'YEARLY', 'MONTHLY']),
  work_calendar_id: z.string().optional(),
});
type HolidayForm = z.infer<typeof holidaySchema>;

// ── Helpers ───────────────────────────────────────────────────
const RECURRENCE_LABEL: Record<string, string> = { NONE: 'One-time', YEARLY: 'Yearly', MONTHLY: 'Monthly' };

export function WorkCalendarPage() {
  const [tab, setTab] = useState<'calendars' | 'holidays'>('calendars');

  // Calendars state
  const [calendars, setCalendars] = useState<WorkCalendar[]>([]);
  const [calLoading, setCalLoading] = useState(true);
  const [calDialog, setCalDialog] = useState(false);
  const [editCal, setEditCal] = useState<WorkCalendar | null>(null);
  const [calSaving, setCalSaving] = useState(false);

  // Holidays state
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [holLoading, setHolLoading] = useState(true);
  const [holDialog, setHolDialog] = useState(false);
  const [editHol, setEditHol] = useState<Holiday | null>(null);
  const [holSaving, setHolSaving] = useState(false);
  const [holCalFilter, setHolCalFilter] = useState('all');

  // Forms
  const calForm = useForm<CalForm>({
    resolver: zodResolver(calSchema),
    defaultValues: { calendar_name: '', working_days: ['Mon','Tue','Wed','Thu','Fri'], daily_hours: 8 },
  });
  const holForm = useForm<HolidayForm>({
    resolver: zodResolver(holidaySchema),
    defaultValues: { holiday_name: '', holiday_date: '', is_recurring: false, recurrence_type: 'NONE' },
  });

  // Load
  const loadCalendars = useCallback(async () => {
    setCalLoading(true);
    const { data, error } = await supabase
      .from('work_calendars')
      .select('*')
      .eq('is_deleted', 0)
      .order('created_at', { ascending: false });
    if (error) toast.error('Failed to load calendars');
    else setCalendars((data ?? []) as WorkCalendar[]);
    setCalLoading(false);
  }, []);

  const loadHolidays = useCallback(async () => {
    setHolLoading(true);
    let q = supabase.from('holidays').select('*, work_calendar:work_calendars(id,calendar_name)').eq('is_deleted', 0);
    if (holCalFilter !== 'all') q = q.eq('work_calendar_id', holCalFilter);
    const { data, error } = await q.order('holiday_date', { ascending: true });
    if (error) toast.error('Failed to load holidays');
    else setHolidays((data ?? []) as Holiday[]);
    setHolLoading(false);
  }, [holCalFilter]);

  useEffect(() => { loadCalendars(); }, [loadCalendars]);
  useEffect(() => { loadHolidays(); }, [loadHolidays]);

  // Calendar CRUD
  const openCreateCal = () => {
    setEditCal(null);
    calForm.reset({ calendar_name: '', working_days: ['Mon','Tue','Wed','Thu','Fri'], daily_hours: 8 });
    setCalDialog(true);
  };
  const openEditCal = (c: WorkCalendar) => {
    setEditCal(c);
    calForm.reset({
      calendar_name: c.calendar_name,
      working_days: Array.isArray(c.working_days) ? c.working_days : JSON.parse(String(c.working_days)),
      daily_hours: c.daily_hours,
    });
    setCalDialog(true);
  };
  const submitCal = calForm.handleSubmit(async (vals) => {
    setCalSaving(true);
    const payload = { calendar_name: vals.calendar_name, working_days: vals.working_days, daily_hours: vals.daily_hours, updated_at: new Date().toISOString() };
    const { error } = editCal
      ? await supabase.from('work_calendars').update(payload).eq('id', editCal.id)
      : await supabase.from('work_calendars').insert({ ...payload, effective_from: new Date().toISOString(), effective_to: '9999-12-31T23:59:59Z' });
    if (error) toast.error(error.message);
    else { toast.success(editCal ? 'Calendar updated' : 'Calendar created'); setCalDialog(false); loadCalendars(); }
    setCalSaving(false);
  });
  const deleteCal = async (id: string) => {
    if (!confirm('Delete this calendar?')) return;
    const { error } = await supabase.from('work_calendars').update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Calendar deleted'); loadCalendars(); }
  };

  // Holiday CRUD
  const openCreateHol = () => {
    setEditHol(null);
    holForm.reset({ holiday_name: '', holiday_date: '', is_recurring: false, recurrence_type: 'NONE', work_calendar_id: '' });
    setHolDialog(true);
  };
  const openEditHol = (h: Holiday) => {
    setEditHol(h);
    holForm.reset({
      holiday_name: h.holiday_name,
      holiday_date: h.holiday_date,
      is_recurring: h.is_recurring === 1,
      recurrence_type: h.recurrence_type,
      work_calendar_id: h.work_calendar_id ?? '',
    });
    setHolDialog(true);
  };
  const submitHol = holForm.handleSubmit(async (vals) => {
    setHolSaving(true);
    const payload = {
      holiday_name: vals.holiday_name,
      holiday_date: vals.holiday_date,
      is_recurring: vals.is_recurring ? 1 : 0,
      recurrence_type: vals.recurrence_type,
      work_calendar_id: vals.work_calendar_id || null,
      updated_at: new Date().toISOString(),
    };
    const { error } = editHol
      ? await supabase.from('holidays').update(payload).eq('id', editHol.id)
      : await supabase.from('holidays').insert({ ...payload, effective_from: new Date().toISOString(), effective_to: '9999-12-31T23:59:59Z' });
    if (error) toast.error(error.message);
    else { toast.success(editHol ? 'Holiday updated' : 'Holiday created'); setHolDialog(false); loadHolidays(); }
    setHolSaving(false);
  });
  const deleteHol = async (id: string) => {
    if (!confirm('Delete this holiday?')) return;
    const { error } = await supabase.from('holidays').update({ is_deleted: 1, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Holiday deleted'); loadHolidays(); }
  };

  // Days toggle helper
  const toggleDay = (day: string, current: string[], onChange: (v: string[]) => void) => {
    onChange(current.includes(day) ? current.filter(d => d !== day) : [...current, day]);
  };

  const upcomingHolidays = holidays
    .filter(h => new Date(h.holiday_date) >= new Date())
    .slice(0, 5);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Work Calendars & Holidays</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Configure working days, daily hours and public holidays</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => { loadCalendars(); loadHolidays(); }}>
            <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
          </Button>
          {tab === 'calendars'
            ? <Button size="sm" onClick={openCreateCal}><Plus className="h-4 w-4 mr-1.5" />New Calendar</Button>
            : <Button size="sm" onClick={openCreateHol}><Plus className="h-4 w-4 mr-1.5" />Add Holiday</Button>
          }
        </div>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Calendars', value: calendars.length, icon: Calendar, color: 'text-primary' },
          { label: 'Holidays', value: holidays.length, icon: Sun, color: 'text-amber-500' },
          { label: 'Recurring Holidays', value: holidays.filter(h => h.is_recurring === 1).length, icon: Globe, color: 'text-blue-500' },
          { label: 'Upcoming (30d)', value: holidays.filter(h => { const d = new Date(h.holiday_date); const now = new Date(); const plus30 = new Date(); plus30.setDate(plus30.getDate() + 30); return d >= now && d <= plus30; }).length, icon: AlertCircle, color: 'text-orange-500' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <s.icon className={`h-4 w-4 ${s.color} shrink-0`} />
            <div><p className="text-xs text-muted-foreground">{s.label}</p><p className="text-xl font-bold">{s.value}</p></div>
          </div>
        ))}
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList>
          <TabsTrigger value="calendars"><Calendar className="h-4 w-4 mr-1.5" />Calendars ({calendars.length})</TabsTrigger>
          <TabsTrigger value="holidays"><Sun className="h-4 w-4 mr-1.5" />Holidays ({holidays.length})</TabsTrigger>
        </TabsList>

        {/* ── CALENDARS TAB ── */}
        <TabsContent value="calendars" className="mt-4">
          {calLoading ? (
            <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-40 bg-muted rounded-lg" />)}
            </div>
          ) : calendars.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <Calendar className="h-10 w-10 mx-auto mb-3 opacity-40" />
              <p className="font-medium">No calendars configured</p>
              <p className="text-sm mt-1">Create a work calendar to define working days and hours.</p>
              <Button className="mt-4" onClick={openCreateCal}><Plus className="h-4 w-4 mr-1.5" />Create First Calendar</Button>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {calendars.map(c => {
                const days = Array.isArray(c.working_days) ? c.working_days : (JSON.parse(String(c.working_days || '[]')) as string[]);
                return (
                  <div key={c.id} className="bg-card border border-border rounded-lg p-4 flex flex-col h-full">
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div className="min-w-0">
                        <p className="font-semibold text-sm text-balance">{c.calendar_name}</p>
                        <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                          <Clock className="h-3 w-3" />{c.daily_hours}h per day
                        </p>
                      </div>
                      <Badge variant={c.is_active ? 'default' : 'secondary'} className="text-xs shrink-0">
                        {c.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                    <div className="flex flex-wrap gap-1.5 mb-4">
                      {ALL_DAYS.map(d => (
                        <span key={d} className={`text-xs px-2 py-0.5 rounded font-medium ${days.includes(d) ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground line-through'}`}>
                          {d}
                        </span>
                      ))}
                    </div>
                    <div className="flex gap-2 mt-auto">
                      <Button size="sm" variant="outline" className="flex-1 h-8" onClick={() => openEditCal(c)}>
                        <Pencil className="h-3.5 w-3.5 mr-1" />Edit
                      </Button>
                      <Button size="sm" variant="outline" className="h-8 px-2 text-destructive hover:bg-destructive/10" onClick={() => deleteCal(c.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* ── HOLIDAYS TAB ── */}
        <TabsContent value="holidays" className="mt-4 space-y-4">
          {/* Filter */}
          <div className="flex items-center gap-3">
            <Label className="text-xs shrink-0">Filter by Calendar</Label>
            <Select value={holCalFilter} onValueChange={setHolCalFilter}>
              <SelectTrigger className="w-56 h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Calendars</SelectItem>
                {calendars.map(c => <SelectItem key={c.id} value={c.id}>{c.calendar_name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {/* Upcoming strip */}
          {upcomingHolidays.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 dark:bg-amber-950/20 dark:border-amber-800 rounded-lg px-4 py-3">
              <p className="text-xs font-semibold text-amber-700 dark:text-amber-400 mb-2">Upcoming Holidays</p>
              <div className="flex flex-wrap gap-2">
                {upcomingHolidays.map(h => (
                  <div key={h.id} className="flex items-center gap-1.5 text-xs bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300 px-2 py-1 rounded">
                    <Sun className="h-3 w-3 shrink-0" />
                    <span className="font-medium">{h.holiday_name}</span>
                    <span className="text-amber-600 dark:text-amber-500">{h.holiday_date}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Table */}
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Holiday Name</TableHead>
                    <TableHead className="whitespace-nowrap">Date</TableHead>
                    <TableHead className="whitespace-nowrap">Recurrence</TableHead>
                    <TableHead className="whitespace-nowrap">Calendar</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {holLoading ? Array.from({ length: 6 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 5 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-20 bg-muted" /></TableCell>)}</TableRow>
                  )) : holidays.length === 0 ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-10 text-muted-foreground">
                      <Sun className="h-8 w-8 mx-auto mb-2 opacity-40" />No holidays configured
                    </TableCell></TableRow>
                  ) : holidays.map(h => {
                    const isPast = new Date(h.holiday_date) < new Date();
                    return (
                      <TableRow key={h.id} className={isPast ? 'opacity-60' : ''}>
                        <TableCell className="whitespace-nowrap font-medium text-sm">{h.holiday_name}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{h.holiday_date}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Badge variant={h.is_recurring === 1 ? 'default' : 'secondary'} className="text-xs">
                            {RECURRENCE_LABEL[h.recurrence_type] ?? h.recurrence_type}
                          </Badge>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                          {(h as { work_calendar?: { calendar_name: string } }).work_calendar?.calendar_name ?? '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex gap-1.5">
                            <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openEditHol(h)}>
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button size="sm" variant="outline" className="h-7 px-2 text-destructive hover:bg-destructive/10" onClick={() => deleteHol(h.id)}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* ── Calendar Dialog ── */}
      <Dialog open={calDialog} onOpenChange={o => { if (!o) setCalDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editCal ? 'Edit' : 'New'} Work Calendar</DialogTitle></DialogHeader>
          <Form {...calForm}>
            <form onSubmit={submitCal} className="space-y-4 mt-1">
              <FormField control={calForm.control} name="calendar_name" render={({ field }) => (
                <FormItem><FormLabel>Calendar Name *</FormLabel><FormControl><Input {...field} placeholder="Standard BKG Calendar" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={calForm.control} name="daily_hours" render={({ field }) => (
                <FormItem><FormLabel>Daily Hours *</FormLabel><FormControl><Input type="number" min={1} max={24} step={0.5} {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={calForm.control} name="working_days" render={({ field }) => (
                <FormItem>
                  <FormLabel>Working Days *</FormLabel>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {ALL_DAYS.map(d => (
                      <label key={d} className={`flex items-center gap-1.5 px-3 py-1.5 rounded border cursor-pointer text-sm transition-colors ${
                        field.value.includes(d) ? 'bg-primary/10 border-primary text-primary' : 'border-border text-muted-foreground hover:bg-muted/50'}`}>
                        <Checkbox checked={field.value.includes(d)} onCheckedChange={() => toggleDay(d, field.value, field.onChange)} className="h-3.5 w-3.5" />
                        {d}
                      </label>
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="flex justify-end gap-2 pt-2 border-t border-border">
                <Button type="button" variant="outline" onClick={() => setCalDialog(false)}>Cancel</Button>
                <Button type="submit" disabled={calSaving}>{calSaving ? 'Saving…' : (editCal ? 'Update' : 'Create')}</Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* ── Holiday Dialog ── */}
      <Dialog open={holDialog} onOpenChange={o => { if (!o) setHolDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editHol ? 'Edit' : 'Add'} Holiday</DialogTitle></DialogHeader>
          <Form {...holForm}>
            <form onSubmit={submitHol} className="space-y-4 mt-1">
              <FormField control={holForm.control} name="holiday_name" render={({ field }) => (
                <FormItem><FormLabel>Holiday Name *</FormLabel><FormControl><Input {...field} placeholder="Ethiopian New Year" /></FormControl><FormMessage /></FormItem>
              )} />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={holForm.control} name="holiday_date" render={({ field }) => (
                  <FormItem><FormLabel>Date *</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={holForm.control} name="recurrence_type" render={({ field }) => (
                  <FormItem><FormLabel>Recurrence</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="NONE">One-time</SelectItem>
                        <SelectItem value="YEARLY">Yearly</SelectItem>
                        <SelectItem value="MONTHLY">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={holForm.control} name="work_calendar_id" render={({ field }) => (
                <FormItem><FormLabel>Linked Calendar (optional)</FormLabel>
                  <Select value={field.value ?? ''} onValueChange={v => field.onChange(v === 'none' ? '' : v)}>
                    <FormControl><SelectTrigger><SelectValue placeholder="— All Calendars —" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="none">— All Calendars —</SelectItem>
                      {calendars.map(c => <SelectItem key={c.id} value={c.id}>{c.calendar_name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                <FormMessage /></FormItem>
              )} />
              <FormField control={holForm.control} name="is_recurring" render={({ field }) => (
                <FormItem className="flex items-center gap-2">
                  <FormControl><Checkbox checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                  <FormLabel className="!mt-0">Recurring holiday</FormLabel>
                </FormItem>
              )} />
              <Separator />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setHolDialog(false)}>Cancel</Button>
                <Button type="submit" disabled={holSaving}>{holSaving ? 'Saving…' : (editHol ? 'Update' : 'Add Holiday')}</Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Mini calendar legend */}
      <div className="flex items-center gap-3 text-xs text-muted-foreground">
        <CalendarDays className="h-3.5 w-3.5 shrink-0" />
        <span>Working days are highlighted in each calendar card. Holidays override working day rules.</span>
      </div>
    </div>
  );
}
