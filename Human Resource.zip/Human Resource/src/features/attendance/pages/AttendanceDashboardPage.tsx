import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import type { DailyAttendanceSummary, AttendanceEvent, Shift } from '@/types/database.types';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import {
  RefreshCw, Plus, UserCheck, UserX, Clock, AlertTriangle,
  Lock, Unlock, Activity, MapPin, Smartphone, Monitor, Fingerprint, Pencil, Eye, Download
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

// ── Types ──────────────────────────────────────────────────────
const STATUS_COLORS: Record<string, string> = {
  PRESENT:  'bg-green-100 text-green-800',
  ABSENT:   'bg-red-100 text-red-800',
  HALF_DAY: 'bg-yellow-100 text-yellow-800',
  ON_LEAVE: 'bg-blue-100 text-blue-800',
  HOLIDAY:  'bg-teal-100 text-teal-800',
  WEEKEND:  'bg-muted text-muted-foreground',
  EXCUSED:  'bg-purple-100 text-purple-800',
};
const SOURCE_ICON: Record<string, React.FC<{ className?: string }>> = {
  BIOMETRIC: Fingerprint,
  MOBILE:    Smartphone,
  WEB:       Monitor,
  MANUAL:    Pencil,
};
const STATUSES = ['PRESENT','ABSENT','HALF_DAY','ON_LEAVE','HOLIDAY','WEEKEND','EXCUSED'] as const;

// ── Summary form ───────────────────────────────────────────────
const summarySchema = z.object({
  employee_id:        z.string().min(1, 'Required'),
  attendance_date:    z.string().min(1, 'Required'),
  attendance_status:  z.enum(STATUSES),
  first_check_in:     z.string().optional(),
  last_check_out:     z.string().optional(),
  total_worked_hours: z.coerce.number().min(0).max(24),
  regular_hours:      z.coerce.number().min(0).max(24),
  overtime_hours:     z.coerce.number().min(0).max(24),
  late_minutes:       z.coerce.number().min(0),
  early_leave_minutes:z.coerce.number().min(0),
  shift_id:           z.string().optional(),
  is_anomaly:         z.boolean(),
  anomaly_type:       z.string().optional(),
});
type SummaryForm = z.infer<typeof summarySchema>;

const formatTs = (ts?: string | null) =>
  ts ? new Date(ts).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) : '—';

export function AttendanceDashboardPage() {
  const [tab, setTab] = useState<'summary' | 'events'>('summary');

  // Summary
  const [summaries, setSummaries] = useState<DailyAttendanceSummary[]>([]);
  const [sumLoading, setSumLoading] = useState(true);
  const [sumTotal, setSumTotal] = useState(0);
  const [sumPage, setSumPage] = useState(1);
  const PAGE = 25;

  // Events
  const [events, setEvents] = useState<AttendanceEvent[]>([]);
  const [evtLoading, setEvtLoading] = useState(true);
  const [evtTotal, setEvtTotal] = useState(0);
  const [evtPage, setEvtPage] = useState(1);

  // Server-side aggregate stats (not page-limited)
  const [aggStats, setAggStats] = useState({ present: 0, absent: 0, late: 0, locked: 0, anomalies: 0 });

  // Late arrivals trend chart data
  const [lateChartData, setLateChartData] = useState<{ date: string; late: number }[]>([]);

  // Filters
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate,   setEndDate]   = useState(new Date().toISOString().split('T')[0]);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [empFilter,    setEmpFilter]    = useState('');
  const [evtSource,    setEvtSource]    = useState('all');

  // Dialog
  const [dialog,     setDialog]    = useState(false);
  const [editSum,    setEditSum]   = useState<DailyAttendanceSummary | null>(null);
  const [saving,     setSaving]    = useState(false);
  const [detailOpen, setDetailOpen]= useState(false);
  const [detailRec,  setDetailRec] = useState<DailyAttendanceSummary | null>(null);
  const [shifts,     setShifts]    = useState<Pick<Shift,'id'|'name'>[]>([]);

  const form = useForm<SummaryForm>({
    resolver: zodResolver(summarySchema),
    defaultValues: {
      employee_id: '', attendance_date: new Date().toISOString().split('T')[0],
      attendance_status: 'PRESENT', total_worked_hours: 0, regular_hours: 0,
      overtime_hours: 0, late_minutes: 0, early_leave_minutes: 0, is_anomaly: false,
    },
  });

  // Load server-side aggregate stats (independent of pagination)
  const loadAggStats = useCallback(async () => {
    let q = supabase.from('daily_attendance_summaries')
      .select('attendance_status, late_minutes, is_locked, is_anomaly')
      .gte('attendance_date', startDate)
      .lte('attendance_date', endDate);
    if (empFilter) q = q.eq('employee_id', empFilter);
    const { data } = await q;
    const rows = (data ?? []) as { attendance_status: string; late_minutes: number; is_locked: number; is_anomaly: number }[];
    setAggStats({
      present:   rows.filter(r => r.attendance_status === 'PRESENT').length,
      absent:    rows.filter(r => r.attendance_status === 'ABSENT').length,
      late:      rows.filter(r => (r.late_minutes ?? 0) > 0).length,
      locked:    rows.filter(r => r.is_locked === 1).length,
      anomalies: rows.filter(r => r.is_anomaly === 1).length,
    });
  }, [startDate, endDate, empFilter]);

  // Late arrivals trend — group by date over the selected range
  const loadLateChartData = useCallback(async () => {
    let q = supabase.from('daily_attendance_summaries')
      .select('attendance_date, late_minutes')
      .gte('attendance_date', startDate)
      .lte('attendance_date', endDate);
    if (empFilter) q = q.eq('employee_id', empFilter);
    const { data } = await q;
    const rows = (data ?? []) as { attendance_date: string; late_minutes: number }[];
    // Aggregate late count per date
    const byDate: Record<string, number> = {};
    for (const r of rows) {
      byDate[r.attendance_date] = (byDate[r.attendance_date] ?? 0) + ((r.late_minutes ?? 0) > 0 ? 1 : 0);
    }
    const sorted = Object.entries(byDate)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, late]) => ({ date, late }));
    setLateChartData(sorted);
  }, [startDate, endDate, empFilter]);

  // CSV export — fetches all records for the current filter (no pagination)
  const exportCsv = useCallback(async () => {
    let q = supabase.from('daily_attendance_summaries')
      .select('attendance_date, attendance_status, first_check_in, last_check_out, total_worked_hours, regular_hours, overtime_hours, late_minutes, early_leave_minutes, is_anomaly, anomaly_type, employee:employees!daily_attendance_summaries_employee_id_fkey(first_name,last_name,employee_no)')
      .gte('attendance_date', startDate)
      .lte('attendance_date', endDate)
      .order('attendance_date', { ascending: false });
    if (statusFilter !== 'all') q = q.eq('attendance_status', statusFilter);
    if (empFilter) q = q.eq('employee_id', empFilter);
    const { data, error } = await q;
    if (error) { toast.error('Export failed'); return; }
    type AttendanceExportRow = {
  attendance_date: string;
  attendance_status: string;
  first_check_in: string | null;
  last_check_out: string | null;
  total_worked_hours: number | null;
  regular_hours: number | null;
  overtime_hours: number | null;
  late_minutes: number | null;
  early_leave_minutes: number | null;
  is_anomaly: number;
  anomaly_type: string | null;

  employee: {
    first_name: string;
    last_name: string;
    employee_no: string;
  }[];
};

const rows = (data ?? []) as AttendanceExportRow[];
    const header = ['Date','Employee','No','Status','Check In','Check Out','Worked (h)','Regular (h)','OT (h)','Late (m)','Early Leave (m)','Anomaly','Anomaly Type'];
    const fmt = (ts?: string | null) => ts ? new Date(ts).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }) : '';
    const csvRows = [
      header.join(','),
      ...rows.map(r => [
        r.attendance_date,
        r.employee && r.employee.length > 0 ? `${r.employee[0].first_name} ${r.employee[0].last_name}` : '',
        r.employee && r.employee.length > 0 ? r.employee[0].employee_no : '',
        r.attendance_status,
        fmt(r.first_check_in),
        fmt(r.last_check_out),
        r.total_worked_hours?.toFixed(2) ?? '',
        r.regular_hours?.toFixed(2) ?? '',
        r.overtime_hours?.toFixed(2) ?? '',
        r.late_minutes ?? 0,
        r.early_leave_minutes ?? 0,
        r.is_anomaly === 1 ? 'Yes' : 'No',
        r.anomaly_type ?? '',
      ].map(v => `"${String(v).replace(/"/g, '""')}"`).join(','))
    ];
    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `attendance_summaries_${startDate}_to_${endDate}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${rows.length} records`);
  }, [startDate, endDate, statusFilter, empFilter]);

  // Load summaries
  const loadSummaries = useCallback(async () => {
    setSumLoading(true);
    let q = supabase.from('daily_attendance_summaries')
      .select('*, employee:employees!daily_attendance_summaries_employee_id_fkey(id,first_name,last_name,employee_no,department_id), shift:shifts!daily_attendance_summaries_shift_id_fkey(id,name)', { count: 'exact' })
      .gte('attendance_date', startDate)
      .lte('attendance_date', endDate)
      .order('attendance_date', { ascending: false })
      .order('created_at', { ascending: false })
      .range((sumPage - 1) * PAGE, sumPage * PAGE - 1);
    if (statusFilter !== 'all') q = q.eq('attendance_status', statusFilter);
    if (empFilter) q = q.eq('employee_id', empFilter);
    const { data, count, error } = await q;
    if (error) toast.error('Failed to load summaries');
    else { setSummaries((data ?? []) as DailyAttendanceSummary[]); setSumTotal(count ?? 0); }
    setSumLoading(false);
  }, [startDate, endDate, statusFilter, empFilter, sumPage]);

  // Load events
  const loadEvents = useCallback(async () => {
    setEvtLoading(true);
    let q = supabase.from('attendance_events')
      .select('*, employee:employees!attendance_events_employee_id_fkey(id,first_name,last_name,employee_no)', { count: 'exact' })
      .gte('event_timestamp', `${startDate}T00:00:00`)
      .lte('event_timestamp', `${endDate}T23:59:59`)
      .order('event_timestamp', { ascending: false })
      .range((evtPage - 1) * PAGE, evtPage * PAGE - 1);
    if (evtSource !== 'all') q = q.eq('event_source', evtSource);
    if (empFilter) q = q.eq('employee_id', empFilter);
    const { data, count, error } = await q;
    if (error) toast.error('Failed to load events');
    else { setEvents((data ?? []) as AttendanceEvent[]); setEvtTotal(count ?? 0); }
    setEvtLoading(false);
  }, [startDate, endDate, evtSource, empFilter, evtPage]);

  const loadShifts = useCallback(async () => {
    const { data } = await supabase.from('shifts').select('id,name').eq('is_active', true).order('name');
    setShifts((data ?? []) as Pick<Shift,'id'|'name'>[]);
  }, []);

  useEffect(() => { loadSummaries(); }, [loadSummaries]);
  useEffect(() => { loadEvents(); }, [loadEvents]);
  useEffect(() => { loadShifts(); }, [loadShifts]);
  useEffect(() => { loadAggStats(); }, [loadAggStats]);
  useEffect(() => { loadLateChartData(); }, [loadLateChartData]);

  // Open create/edit
  const openCreate = () => {
    setEditSum(null);
    form.reset({ employee_id: '', attendance_date: new Date().toISOString().split('T')[0], attendance_status: 'PRESENT', total_worked_hours: 0, regular_hours: 0, overtime_hours: 0, late_minutes: 0, early_leave_minutes: 0, is_anomaly: false });
    setDialog(true);
  };
  const openEdit = (s: DailyAttendanceSummary) => {
    setEditSum(s);
    const toTime = (ts?: string | null) => ts ? new Date(ts).toTimeString().slice(0,5) : '';
    form.reset({
      employee_id:         s.employee_id,
      attendance_date:     s.attendance_date,
      attendance_status:   s.attendance_status,
      first_check_in:      toTime(s.first_check_in),
      last_check_out:      toTime(s.last_check_out),
      total_worked_hours:  s.total_worked_hours ?? 0,
      regular_hours:       s.regular_hours ?? 0,
      overtime_hours:      s.overtime_hours ?? 0,
      late_minutes:        s.late_minutes ?? 0,
      early_leave_minutes: s.early_leave_minutes ?? 0,
      shift_id:            s.shift_id ?? '',
      is_anomaly:          s.is_anomaly === 1,
      anomaly_type:        s.anomaly_type ?? '',
    });
    setDialog(true);
  };

  const handleSave = form.handleSubmit(async (vals) => {
    setSaving(true);
    const payload: Record<string, unknown> = {
      employee_id:         vals.employee_id,
      attendance_date:     vals.attendance_date,
      attendance_status:   vals.attendance_status,
      total_worked_hours:  vals.total_worked_hours,
      regular_hours:       vals.regular_hours,
      overtime_hours:      vals.overtime_hours,
      late_minutes:        vals.late_minutes,
      early_leave_minutes: vals.early_leave_minutes,
      shift_id:            vals.shift_id || null,
      is_anomaly:          vals.is_anomaly ? 1 : 0,
      anomaly_type:        vals.anomaly_type || null,
      updated_at:          new Date().toISOString(),
    };
    if (vals.first_check_in) payload.first_check_in = `${vals.attendance_date}T${vals.first_check_in}:00`;
    if (vals.last_check_out) payload.last_check_out = `${vals.attendance_date}T${vals.last_check_out}:00`;

    const { error } = editSum
      ? await supabase.from('daily_attendance_summaries').update(payload).eq('id', editSum.id)
      : await supabase.from('daily_attendance_summaries').insert({ ...payload, effective_from: new Date().toISOString(), effective_to: '9999-12-31T23:59:59Z' });
    if (error) toast.error(error.message);
    else { toast.success(editSum ? 'Summary updated' : 'Summary created'); setDialog(false); loadSummaries(); }
    setSaving(false);
  });

  const toggleLock = async (s: DailyAttendanceSummary) => {
    const newLock = s.is_locked === 1 ? 0 : 1;
    const { error } = await supabase.from('daily_attendance_summaries').update({ is_locked: newLock, updated_at: new Date().toISOString() }).eq('id', s.id);
    if (error) toast.error(error.message);
    else { toast.success(newLock ? 'Record locked' : 'Record unlocked'); loadSummaries(); }
  };

  const sumPages = Math.ceil(sumTotal / PAGE);
  const evtPages = Math.ceil(evtTotal / PAGE);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Attendance Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Attendance events log and daily summaries</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => { loadSummaries(); loadEvents(); loadAggStats(); loadLateChartData(); }}>
            <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
          </Button>
          <Button variant="outline" size="sm" onClick={exportCsv}><Download className="h-4 w-4 mr-1.5" />Export CSV</Button>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1.5" />Add Summary</Button>
        </div>
      </div>

      {/* Stats — server-side aggregates for the selected date range */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: 'Present',   value: aggStats.present,   icon: UserCheck,    color: 'text-green-600' },
          { label: 'Absent',    value: aggStats.absent,    icon: UserX,        color: 'text-red-500' },
          { label: 'Late',      value: aggStats.late,      icon: Clock,        color: 'text-orange-500' },
          { label: 'Anomalies', value: aggStats.anomalies, icon: AlertTriangle, color: 'text-yellow-500' },
          { label: 'Locked',    value: aggStats.locked,    icon: Lock,         color: 'text-muted-foreground' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <s.icon className={`h-4 w-4 ${s.color} shrink-0`} />
            <div><p className="text-xs text-muted-foreground">{s.label}</p><p className="text-xl font-bold">{s.value}</p></div>
          </div>
        ))}
      </div>


      {/* Late Arrivals Trend Chart */}
      {lateChartData.length > 0 && (
        <div className="bg-card border border-border rounded-lg p-4 space-y-2">
          <p className="text-sm font-medium text-foreground flex items-center gap-1.5">
            <Clock className="h-4 w-4 text-orange-500" />Late Arrivals per Day
          </p>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={lateChartData} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis
                dataKey="date"
                tick={{ fontSize: 11 }}
                tickFormatter={d => d.slice(5)}
                interval="preserveStartEnd"
              />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip
                labelFormatter={l => `Date: ${l}`}
                formatter={(v: number) => [`${v} late`, 'Late arrivals']}
                contentStyle={{ fontSize: 12 }}
              />
              <Bar dataKey="late" fill="#f97316" radius={[3, 3, 0, 0]} maxBarSize={40} name="Late" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap items-end gap-3">
        <div className="space-y-1"><Label className="text-xs">From</Label>
          <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-38" /></div>
        <div className="space-y-1"><Label className="text-xs">To</Label>
          <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-38" /></div>
        <div className="space-y-1 min-w-[180px]"><Label className="text-xs">Employee</Label>
          {/* Bug fix: allowEmpty lets the user clear the employee filter */}
          <EmployeeSelect value={empFilter} onChange={v => setEmpFilter(v === 'none' ? '' : v)} allowEmpty emptyLabel="All Employees" /></div>
        <Button onClick={() => { loadSummaries(); loadEvents(); loadAggStats(); loadLateChartData(); setSumPage(1); setEvtPage(1); }}>Apply</Button>
      </div>

      <Tabs value={tab} onValueChange={v => setTab(v as typeof tab)}>
        <TabsList>
          <TabsTrigger value="summary"><Activity className="h-4 w-4 mr-1.5" />Daily Summaries ({sumTotal})</TabsTrigger>
          <TabsTrigger value="events"><Clock className="h-4 w-4 mr-1.5" />Punch Events ({evtTotal})</TabsTrigger>
        </TabsList>

        {/* ── DAILY SUMMARIES ── */}
        <TabsContent value="summary" className="mt-4 space-y-3">
          <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setSumPage(1); }}>
            <SelectTrigger className="w-48 h-8 text-xs"><SelectValue placeholder="All Statuses" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {STATUSES.map(s => <SelectItem key={s} value={s}>{s.replace('_',' ')}</SelectItem>)}
            </SelectContent>
          </Select>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Date</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Check In</TableHead>
                    <TableHead className="whitespace-nowrap">Check Out</TableHead>
                    <TableHead className="whitespace-nowrap">Worked (h)</TableHead>
                    <TableHead className="whitespace-nowrap">OT (h)</TableHead>
                    <TableHead className="whitespace-nowrap">Late (m)</TableHead>
                    <TableHead className="whitespace-nowrap">EL (m)</TableHead>
                    <TableHead className="whitespace-nowrap">Anomaly</TableHead>
                    <TableHead className="whitespace-nowrap">Lock</TableHead>
                    <TableHead className="whitespace-nowrap">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sumLoading ? Array.from({ length: 8 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 12 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-14 bg-muted" /></TableCell>)}</TableRow>
                  )) : summaries.length === 0 ? (
                    <TableRow><TableCell colSpan={12} className="text-center py-10 text-muted-foreground">
                      <Activity className="h-8 w-8 mx-auto mb-2 opacity-40" />No attendance summaries for this period
                    </TableCell></TableRow>
                  ) : summaries.map(s => {
                    const emp = s.employee as { first_name: string; last_name: string; employee_no: string } | undefined;
                    return (
                      <TableRow key={s.id} className={s.is_anomaly === 1 ? 'bg-yellow-50/50 dark:bg-yellow-900/10' : ''}>
                        <TableCell className="whitespace-nowrap font-medium text-sm">
                          {emp ? `${emp.first_name} ${emp.last_name}` : '—'}
                          {emp && <span className="text-xs text-muted-foreground ml-1">#{emp.employee_no}</span>}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{s.attendance_date}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[s.attendance_status] ?? 'bg-muted text-muted-foreground'}`}>
                            {s.attendance_status.replace('_',' ')}
                          </span>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{formatTs(s.first_check_in)}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{formatTs(s.last_check_out)}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm font-medium">{s.total_worked_hours?.toFixed(1) ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">
                          {(s.overtime_hours ?? 0) > 0 ? <Badge variant="secondary" className="text-xs">{s.overtime_hours?.toFixed(1)}</Badge> : '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">
                          {(s.late_minutes ?? 0) > 0 ? <span className="text-orange-600 font-medium">{s.late_minutes}</span> : '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">
                          {(s.early_leave_minutes ?? 0) > 0 ? <span className="text-yellow-600 font-medium">{s.early_leave_minutes}</span> : '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          {s.is_anomaly === 1
                            ? <Badge className="bg-yellow-100 text-yellow-800 text-xs">{s.anomaly_type ?? 'Yes'}</Badge>
                            : <span className="text-muted-foreground text-xs">—</span>}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Button size="sm" variant="ghost" className="h-7 px-1.5" onClick={() => toggleLock(s)} title={s.is_locked ? 'Unlock' : 'Lock'}>
                            {s.is_locked === 1 ? <Lock className="h-3.5 w-3.5 text-muted-foreground" /> : <Unlock className="h-3.5 w-3.5 text-muted-foreground" />}
                          </Button>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex gap-1.5">
                            <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => { setDetailRec(s); setDetailOpen(true); }}><Eye className="h-3.5 w-3.5" /></Button>
                            <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => openEdit(s)}><Pencil className="h-3.5 w-3.5" /></Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
          {sumPages > 1 && (
            <div className="flex justify-end gap-2">
              <Button size="sm" variant="outline" disabled={sumPage <= 1} onClick={() => setSumPage(p => p - 1)}>Prev</Button>
              <span className="text-sm self-center">{sumPage} / {sumPages}</span>
              <Button size="sm" variant="outline" disabled={sumPage >= sumPages} onClick={() => setSumPage(p => p + 1)}>Next</Button>
            </div>
          )}
        </TabsContent>

        {/* ── PUNCH EVENTS ── */}
        <TabsContent value="events" className="mt-4 space-y-3">
          <Select value={evtSource} onValueChange={v => { setEvtSource(v); setEvtPage(1); }}>
            <SelectTrigger className="w-48 h-8 text-xs"><SelectValue placeholder="All Sources" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sources</SelectItem>
              <SelectItem value="BIOMETRIC">Biometric</SelectItem>
              <SelectItem value="MOBILE">Mobile</SelectItem>
              <SelectItem value="WEB">Web</SelectItem>
              <SelectItem value="MANUAL">Manual</SelectItem>
            </SelectContent>
          </Select>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Employee</TableHead>
                    <TableHead className="whitespace-nowrap">Timestamp</TableHead>
                    <TableHead className="whitespace-nowrap">Type</TableHead>
                    <TableHead className="whitespace-nowrap">Source</TableHead>
                    <TableHead className="whitespace-nowrap">Device</TableHead>
                    <TableHead className="whitespace-nowrap">GPS</TableHead>
                    <TableHead className="whitespace-nowrap">Corrected</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {evtLoading ? Array.from({ length: 8 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 7 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-16 bg-muted" /></TableCell>)}</TableRow>
                  )) : events.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">
                      <Clock className="h-8 w-8 mx-auto mb-2 opacity-40" />No punch events for this period
                    </TableCell></TableRow>
                  ) : events.map(ev => {
                    const emp = ev.employee as { first_name: string; last_name: string; employee_no: string } | undefined;
                    const SrcIcon = SOURCE_ICON[ev.event_source] ?? Activity;
                    return (
                      <TableRow key={ev.id}>
                        <TableCell className="whitespace-nowrap font-medium text-sm">
                          {emp ? `${emp.first_name} ${emp.last_name}` : '—'}
                          {emp && <span className="text-xs text-muted-foreground ml-1">#{emp.employee_no}</span>}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{new Date(ev.event_timestamp).toLocaleString()}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Badge variant={ev.event_type === 'CHECK_IN' ? 'default' : 'secondary'} className="text-xs">
                            {ev.event_type.replace('_',' ')}
                          </Badge>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex items-center gap-1.5 text-sm">
                            <SrcIcon className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                            {ev.event_source}
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{ev.device_id ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">
                          {ev.gps_latitude && ev.gps_longitude
                            ? <span className="flex items-center gap-1 text-xs"><MapPin className="h-3 w-3" />{ev.gps_latitude.toFixed(4)}, {ev.gps_longitude.toFixed(4)}</span>
                            : '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          {ev.is_corrected === 1 ? <Badge variant="outline" className="text-xs text-orange-600">Corrected</Badge> : '—'}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
          {evtPages > 1 && (
            <div className="flex justify-end gap-2">
              <Button size="sm" variant="outline" disabled={evtPage <= 1} onClick={() => setEvtPage(p => p - 1)}>Prev</Button>
              <span className="text-sm self-center">{evtPage} / {evtPages}</span>
              <Button size="sm" variant="outline" disabled={evtPage >= evtPages} onClick={() => setEvtPage(p => p + 1)}>Next</Button>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* ── Summary Form Dialog ── */}
      <Dialog open={dialog} onOpenChange={o => { if (!o) setDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle>{editSum ? 'Edit' : 'Add'} Daily Attendance Summary</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={handleSave} className="space-y-4 mt-1">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <FormField control={form.control} name="employee_id" render={({ field }) => (
                    <FormItem><FormLabel>Employee *</FormLabel><FormControl>
                      <EmployeeSelect value={field.value} onChange={field.onChange} required />
                    </FormControl><FormMessage /></FormItem>
                  )} />
                </div>
                <FormField control={form.control} name="attendance_date" render={({ field }) => (
                  <FormItem><FormLabel>Date *</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="attendance_status" render={({ field }) => (
                  <FormItem><FormLabel>Status *</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{s.replace('_',' ')}</SelectItem>)}</SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="first_check_in" render={({ field }) => (
                  <FormItem><FormLabel>First Check-In</FormLabel><FormControl><Input type="time" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="last_check_out" render={({ field }) => (
                  <FormItem><FormLabel>Last Check-Out</FormLabel><FormControl><Input type="time" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="total_worked_hours" render={({ field }) => (
                  <FormItem><FormLabel>Total Worked (h)</FormLabel><FormControl><Input type="number" min={0} max={24} step={0.25} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="regular_hours" render={({ field }) => (
                  <FormItem><FormLabel>Regular Hours</FormLabel><FormControl><Input type="number" min={0} max={24} step={0.25} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="overtime_hours" render={({ field }) => (
                  <FormItem><FormLabel>Overtime Hours</FormLabel><FormControl><Input type="number" min={0} max={24} step={0.25} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="late_minutes" render={({ field }) => (
                  <FormItem><FormLabel>Late (min)</FormLabel><FormControl><Input type="number" min={0} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="early_leave_minutes" render={({ field }) => (
                  <FormItem><FormLabel>Early Leave (min)</FormLabel><FormControl><Input type="number" min={0} {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="shift_id" render={({ field }) => (
                  <FormItem><FormLabel>Shift</FormLabel>
                    <Select value={field.value ?? ''} onValueChange={v => field.onChange(v === 'none' ? '' : v)}>
                      <FormControl><SelectTrigger><SelectValue placeholder="— None —" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">— None —</SelectItem>
                        {shifts.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
                {/* Bug fix: is_anomaly checkbox was missing from the form */}
                <FormField control={form.control} name="is_anomaly" render={({ field }) => (
                  <FormItem className="flex items-center gap-2 pt-1">
                    <FormControl>
                      <Checkbox checked={field.value} onCheckedChange={field.onChange} id="is_anomaly" />
                    </FormControl>
                    <FormLabel htmlFor="is_anomaly" className="!mt-0 cursor-pointer">Flag as Anomaly</FormLabel>
                  </FormItem>
                )} />
                {form.watch('is_anomaly') && (
                  <FormField control={form.control} name="anomaly_type" render={({ field }) => (
                    <FormItem><FormLabel>Anomaly Type</FormLabel>
                      <FormControl><Input placeholder="e.g. MISSED_PUNCH, EARLY_DEPARTURE…" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                )}
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-border">
                <Button type="button" variant="outline" onClick={() => setDialog(false)}>Cancel</Button>
                <Button type="submit" disabled={saving}>{saving ? 'Saving…' : (editSum ? 'Update' : 'Create')}</Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* ── Detail Dialog ── */}
      <Dialog open={detailOpen} onOpenChange={o => { if (!o) setDetailOpen(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Attendance Detail</DialogTitle></DialogHeader>
          {detailRec && (
            <div className="space-y-3 mt-2">
              {[
                ['Date', detailRec.attendance_date],
                ['Status', detailRec.attendance_status],
                ['First Check-In', formatTs(detailRec.first_check_in)],
                ['Last Check-Out', formatTs(detailRec.last_check_out)],
                ['Worked Hours', `${detailRec.total_worked_hours?.toFixed(1) ?? 0}h`],
                ['Regular Hours', `${detailRec.regular_hours?.toFixed(1) ?? 0}h`],
                ['Overtime', `${detailRec.overtime_hours?.toFixed(1) ?? 0}h (${detailRec.overtime_type ?? '—'})`],
                ['Late', `${detailRec.late_minutes ?? 0} min`],
                ['Early Leave', `${detailRec.early_leave_minutes ?? 0} min`],
                ['Anomaly', detailRec.is_anomaly === 1 ? (detailRec.anomaly_type ?? 'Yes') : 'No'],
                ['Locked', detailRec.is_locked === 1 ? 'Yes (Payroll)' : 'No'],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between gap-2 text-sm border-b border-border pb-2 last:border-0">
                  <span className="text-muted-foreground font-medium">{k}</span>
                  <span className="text-foreground">{String(v)}</span>
                </div>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
