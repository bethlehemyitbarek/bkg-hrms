import { useState, useEffect, useCallback } from 'react';
import {
  ShieldAlert, RefreshCw, Download, ChevronDown, ChevronRight, Search, Unlock,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { auditLogService } from '@/services/audit-log.service';
import type { AuditLog, AuditModule, AuditActionType } from '@/types/database.types';

const ACTION_COLORS: Record<AuditActionType, string> = {
  CREATE:  'bg-emerald-100 text-emerald-800',
  READ:    'bg-slate-100 text-slate-600',
  UPDATE:  'bg-blue-100 text-blue-800',
  DELETE:  'bg-red-100 text-red-800',
  EXPORT:  'bg-purple-100 text-purple-800',
  MERGE:   'bg-amber-100 text-amber-800',
  ASSIGN:  'bg-cyan-100 text-cyan-800',
  IMPORT:  'bg-indigo-100 text-indigo-800',
  ARCHIVE: 'bg-slate-200 text-slate-700',
  RESTORE: 'bg-teal-100 text-teal-800',
};

const ALL_MODULES: AuditModule[] = [
  'ORG_STRUCTURE','EMPLOYEE','PAYROLL','LEAVE','ATTENDANCE',
  'RECRUITMENT','ONBOARDING','OFFBOARDING','TRAINING','PERFORMANCE',
  'COMPENSATION','BENEFITS','LOAN','TRANSFER','COMPLIANCE',
  'DOCUMENT','TIMESHEET','USER_AUTH','REPORTING','INTEGRATION',
];

const ALL_ACTIONS: AuditActionType[] = [
  'CREATE','READ','UPDATE','DELETE','EXPORT','MERGE','ASSIGN','IMPORT','ARCHIVE','RESTORE',
];

function JsonPreview({ value }: { value: Record<string, unknown> | undefined }) {
  const [open, setOpen] = useState(false);
  if (!value) return <span className="text-muted-foreground text-xs">—</span>;
  return (
    <div>
      <Button size="sm" variant="ghost" className="h-5 px-1 text-xs" onClick={() => setOpen(o => !o)}>
        {open ? <ChevronDown className="h-3 w-3 mr-0.5" /> : <ChevronRight className="h-3 w-3 mr-0.5" />}
        JSON
      </Button>
      {open && (
        <pre className="mt-1 text-[10px] bg-muted rounded p-2 max-w-xs max-h-40 overflow-auto">
          {JSON.stringify(value, null, 2)}
        </pre>
      )}
    </div>
  );
}

export default function AuditLogPage() {
  const [rows, setRows]       = useState<AuditLog[]>([]);
  const [total, setTotal]     = useState(0);
  const [loading, setLoading] = useState(false);
  const [page, setPage]       = useState(1);
  const pageSize              = 50;

  const [filterModule,      setFilterModule]      = useState('all');
  const [filterAction,      setFilterAction]      = useState('all');
  const [filterEntityType,  setFilterEntityType]  = useState('');
  const [filterDateFrom,    setFilterDateFrom]     = useState('');
  const [filterDateTo,      setFilterDateTo]       = useState('');
  const [exporting, setExporting] = useState(false);

  // Quick-filter: Timesheet Unlocks
  const applyTimesheetUnlockFilter = () => {
    setFilterModule('TIMESHEET');
    setFilterAction('UPDATE');
    setFilterEntityType('timesheet');
    setPage(1);
  };
  const clearFilters = () => {
    setFilterModule('all'); setFilterAction('all');
    setFilterEntityType(''); setFilterDateFrom(''); setFilterDateTo('');
    setPage(1);
  };

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data, total: t } = await auditLogService.list({
        module:      filterModule      !== 'all' ? filterModule      : undefined,
        action_type: filterAction      !== 'all' ? filterAction      : undefined,
        entity_type: filterEntityType  || undefined,
        date_from:   filterDateFrom    || undefined,
        date_to:     filterDateTo      || undefined,
        page,
        pageSize,
      });
      setRows(data as AuditLog[]);
      setTotal(t);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to load audit logs');
    } finally { setLoading(false); }
  }, [filterModule, filterAction, filterEntityType, filterDateFrom, filterDateTo, page]);

  useEffect(() => { load(); }, [load]);

  const exportCsv = async () => {
    setExporting(true);
    try {
      const { data } = await auditLogService.list({
        module:      filterModule      !== 'all' ? filterModule      : undefined,
        action_type: filterAction      !== 'all' ? filterAction      : undefined,
        entity_type: filterEntityType  || undefined,
        date_from:   filterDateFrom    || undefined,
        date_to:     filterDateTo      || undefined,
        page: 1, pageSize: 5000,
      });
      const header = ['event_timestamp','module','entity_type','entity_id','action_type','performed_by','reason'];
      const csvRows = (data as AuditLog[]).map(r => [
        r.event_timestamp,
        r.module,
        r.entity_type,
        r.entity_id ?? '',
        r.action_type,
        (r.performer as { full_name?: string } | null)?.full_name ?? r.performed_by ?? '',
        r.reason ?? '',
      ]);
      const csv = [header, ...csvRows].map(row => row.map(c => `"${String(c).replace(/"/g,'""')}"`).join(',')).join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href = url; a.download = `audit_log_${new Date().toISOString().slice(0,10)}.csv`;
      a.click(); URL.revokeObjectURL(url);
      toast.success('Audit log exported');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Export failed');
    } finally { setExporting(false); }
  };

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <ShieldAlert className="h-5 w-5 text-primary" />
          <h1 className="text-xl font-semibold">Audit Log</h1>
          <Badge variant="secondary" className="ml-1">{total.toLocaleString()} entries</Badge>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Quick filter */}
          <Button variant="outline" size="sm" onClick={applyTimesheetUnlockFilter} title="Filter to timesheet unlock events">
            <Unlock className="h-3.5 w-3.5 mr-1.5" />Timesheet Unlocks
          </Button>
          <Button variant="outline" size="sm" onClick={clearFilters}>Clear Filters</Button>
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${loading ? 'animate-spin' : ''}`} />Refresh
          </Button>
          <Button variant="outline" size="sm" onClick={exportCsv} disabled={exporting || loading}>
            <Download className="h-3.5 w-3.5 mr-1.5" />{exporting ? 'Exporting…' : 'Export CSV'}
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader className="pb-2 pt-4">
          <CardTitle className="text-sm text-muted-foreground font-normal">Filters</CardTitle>
        </CardHeader>
        <CardContent className="pb-4">
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3">
            <div className="space-y-1">
              <Label className="text-xs">Module</Label>
              <Select value={filterModule} onValueChange={v => { setFilterModule(v); setPage(1); }}>
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Modules</SelectItem>
                  {ALL_MODULES.map(m => <SelectItem key={m} value={m}>{m.replace(/_/g,' ')}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Action</Label>
              <Select value={filterAction} onValueChange={v => { setFilterAction(v); setPage(1); }}>
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Actions</SelectItem>
                  {ALL_ACTIONS.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Entity Type</Label>
              <div className="relative">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
                <Input className="h-8 text-xs pl-7" placeholder="e.g. timesheet"
                  value={filterEntityType} onChange={e => { setFilterEntityType(e.target.value); setPage(1); }} />
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Date From</Label>
              <Input type="date" className="h-8 text-xs" value={filterDateFrom}
                onChange={e => { setFilterDateFrom(e.target.value); setPage(1); }} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Date To</Label>
              <Input type="date" className="h-8 text-xs" value={filterDateTo}
                onChange={e => { setFilterDateTo(e.target.value); setPage(1); }} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <div className="w-full overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Timestamp</TableHead>
                  <TableHead className="whitespace-nowrap">Module</TableHead>
                  <TableHead className="whitespace-nowrap">Entity</TableHead>
                  <TableHead className="whitespace-nowrap">Action</TableHead>
                  <TableHead className="whitespace-nowrap">Performed By</TableHead>
                  <TableHead className="whitespace-nowrap">Details</TableHead>
                  <TableHead className="whitespace-nowrap">Reason</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 8 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 7 }).map((__,j) => (
                        <TableCell key={j}><Skeleton className="h-4 w-20 bg-muted" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : rows.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="py-16 text-center text-muted-foreground">
                      <ShieldAlert className="h-10 w-10 mx-auto mb-2 opacity-30" />
                      No audit log entries found
                    </TableCell>
                  </TableRow>
                ) : rows.map(r => {
                  const performer = r.performer as { full_name?: string; email?: string } | null;
                  return (
                    <TableRow key={r.audit_id}>
                      <TableCell className="whitespace-nowrap text-xs font-mono text-muted-foreground">
                        {new Date(r.event_timestamp).toLocaleString()}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge variant="outline" className="text-xs font-mono">{r.module}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="text-sm">{r.entity_type}</div>
                        {r.entity_id && (
                          <div className="text-[10px] font-mono text-muted-foreground">{String(r.entity_id).slice(0,8)}…</div>
                        )}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={`text-xs ${ACTION_COLORS[r.action_type as AuditActionType] ?? 'bg-muted text-muted-foreground'}`}>
                          {r.action_type}
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">
                        {performer?.full_name
                          ? performer.full_name
                          : performer?.email
                            ? <span className="text-xs text-muted-foreground">{performer.email}</span>
                            : r.performed_by
                              ? <span className="font-mono text-xs text-muted-foreground">{String(r.performed_by).slice(0,8)}…</span>
                              : '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <JsonPreview value={r.new_value as Record<string,unknown> | undefined} />
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-xs text-muted-foreground max-w-[160px] truncate">
                        {r.reason ?? '—'}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <p className="text-xs text-muted-foreground">
                {(page-1)*pageSize+1}–{Math.min(page*pageSize,total)} of {total}
              </p>
              <div className="flex gap-2 items-center">
                <Button size="sm" variant="outline" className="h-7 text-xs" disabled={page<=1} onClick={() => setPage(p=>p-1)}>Prev</Button>
                <span className="text-xs text-muted-foreground">Page {page}/{totalPages}</span>
                <Button size="sm" variant="outline" className="h-7 text-xs" disabled={page>=totalPages} onClick={() => setPage(p=>p+1)}>Next</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
