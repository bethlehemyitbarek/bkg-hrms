import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase as _sb } from '@/db/supabase';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const supabase = _sb as any;
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { RefreshCw, Bell, CheckCheck, Settings } from 'lucide-react';

export function NotificationPage() {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [showUnread, setShowUnread] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      let q = supabase
        .from('notifications')
        .select('*', { count: 'exact' });
      if (showUnread) q = q.eq('is_read', false);
      const { data, count, error } = await q.order('created_at', { ascending: false }).range(0, 49);
      if (error) throw error;
      setNotifications((data || []) as Record<string, unknown>[]);
      setTotal(count || 0);
    } catch { toast.error('Failed to load notifications'); }
    finally { setLoading(false); }
  }, [showUnread]);

  useEffect(() => { load(); }, [load]);

  const markAllRead = async () => {
    try {
      const { error } = await supabase.from('notifications').update({ is_read: true }).eq('is_read', false);
      if (error) throw error;
      toast.success('All notifications marked as read');
      load();
    } catch { toast.error('Failed to mark as read'); }
  };

  const MODULE_COLORS: Record<string, string> = {
    dsar:        'bg-blue-100 text-blue-800',
    timesheet:   'bg-indigo-100 text-indigo-800',
    leave:       'bg-green-100 text-green-800',
    payroll:     'bg-amber-100 text-amber-800',
    performance: 'bg-purple-100 text-purple-800',
    training:    'bg-teal-100 text-teal-800',
    expense:     'bg-orange-100 text-orange-800',
    documents:   'bg-slate-100 text-slate-700',
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-bold flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />Notifications
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} {showUnread ? 'unread' : 'total'}</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={() => setShowUnread(v => !v)}>
            {showUnread ? 'Show All' : 'Unread Only'}
          </Button>
          <Button variant="outline" size="sm" onClick={markAllRead}>
            <CheckCheck className="h-4 w-4 mr-1.5" />Mark All Read
          </Button>
          <Button variant="outline" size="sm" onClick={load}>
            <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
          </Button>
          <Button variant="outline" size="sm" onClick={() => navigate('/notifications/preferences')}>
            <Settings className="h-4 w-4 mr-1.5" />Preferences
          </Button>
        </div>
      </div>

      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead className="whitespace-nowrap">Module</TableHead>
              <TableHead className="whitespace-nowrap">Title</TableHead>
              <TableHead className="whitespace-nowrap">Message</TableHead>
              <TableHead className="whitespace-nowrap">Status</TableHead>
              <TableHead className="whitespace-nowrap">Date</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {loading
                ? Array.from({ length: 6 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 5 }).map((__,j) => (
                        <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                : notifications.length === 0
                  ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-10 text-muted-foreground">
                        <Bell className="h-8 w-8 mx-auto mb-2 opacity-40" />No notifications found
                      </TableCell>
                    </TableRow>
                  )
                  : notifications.map((n, i) => {
                    const mod = String(n.module ?? '');
                    return (
                      <TableRow key={String(n.id ?? i)} className={!n.is_read ? 'bg-blue-50/40 dark:bg-blue-950/20' : ''}>
                        <TableCell className="whitespace-nowrap">
                          {mod
                            ? <Badge className={`text-xs ${MODULE_COLORS[mod] ?? 'bg-muted text-muted-foreground'}`}>{mod}</Badge>
                            : '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap font-medium text-sm">{String(n.title ?? '')}</TableCell>
                        <TableCell className="text-sm text-muted-foreground max-w-64 truncate whitespace-nowrap">{String(n.message ?? '')}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">
                          {n.is_read
                            ? <span className="text-muted-foreground">✓ Read</span>
                            : <span className="text-primary font-medium">● Unread</span>}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-xs text-muted-foreground font-mono">
                          {n.created_at ? new Date(String(n.created_at)).toLocaleString() : '—'}
                        </TableCell>
                      </TableRow>
                    );
                  })}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}

