import { useState, useEffect } from 'react';
import { Bell, BellOff, Save, RefreshCw, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import {
  notifPrefsService,
  ALL_NOTIF_MODULES,
  type NotifModuleKey,
} from '@/services/notification-preferences.service';

export function NotificationPreferencesPage() {
  const [prefs, setPrefs]       = useState<Record<NotifModuleKey, boolean> | null>(null);
  const [loading, setLoading]   = useState(true);
  const [saving, setSaving]     = useState(false);
  const [dirty, setDirty]       = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const data = await notifPrefsService.list();
      setPrefs(data);
      setDirty(false);
    } catch {
      toast.error('Failed to load preferences');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const toggle = (key: NotifModuleKey, value: boolean) => {
    setPrefs(prev => prev ? { ...prev, [key]: value } : prev);
    setDirty(true);
  };

  const enableAll = () => {
    if (!prefs) return;
    const next = {} as Record<NotifModuleKey, boolean>;
    for (const m of ALL_NOTIF_MODULES) next[m.key] = true;
    setPrefs(next);
    setDirty(true);
  };

  const disableAll = () => {
    if (!prefs) return;
    const next = {} as Record<NotifModuleKey, boolean>;
    for (const m of ALL_NOTIF_MODULES) next[m.key] = false;
    setPrefs(next);
    setDirty(true);
  };

  const save = async () => {
    if (!prefs) return;
    setSaving(true);
    try {
      await notifPrefsService.saveAll(prefs as Record<string, boolean>);
      setDirty(false);
      toast.success('Notification preferences saved');
    } catch {
      toast.error('Failed to save preferences');
    } finally {
      setSaving(false);
    }
  };

  const enabledCount = prefs ? Object.values(prefs).filter(Boolean).length : 0;
  const totalCount   = ALL_NOTIF_MODULES.length;

  return (
    <div className="max-w-2xl mx-auto space-y-6 p-4 md:p-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            Notification Preferences
          </h1>
          <p className="text-sm text-muted-foreground mt-1 text-pretty">
            Choose which types of notifications you want to receive in-app.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {!loading && prefs && (
            <Badge variant="secondary" className="text-xs">
              {enabledCount}/{totalCount} enabled
            </Badge>
          )}
          <Button variant="outline" size="sm" onClick={load} disabled={loading || saving}>
            <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${loading ? 'animate-spin' : ''}`} />
            Reset
          </Button>
          <Button size="sm" onClick={save} disabled={!dirty || saving || loading}>
            <Save className="h-3.5 w-3.5 mr-1.5" />
            {saving ? 'Saving…' : 'Save Changes'}
          </Button>
        </div>
      </div>

      {/* Info banner */}
      <div className="flex gap-2 p-3 rounded-lg bg-primary/5 border border-primary/20 text-sm text-foreground">
        <Info className="h-4 w-4 text-primary shrink-0 mt-0.5" />
        <p className="text-pretty">
          These preferences control in-app notification delivery only. 
          Disabling a category will hide those notifications from your panel and 
          will not affect email or system-level alerts.
        </p>
      </div>

      {/* Bulk actions */}
      {!loading && (
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={enableAll}>
            <Bell className="h-3.5 w-3.5 mr-1.5" />Enable All
          </Button>
          <Button variant="outline" size="sm" onClick={disableAll}>
            <BellOff className="h-3.5 w-3.5 mr-1.5" />Disable All
          </Button>
        </div>
      )}

      {/* Preferences list */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Notification Categories</CardTitle>
          <CardDescription>Toggle each category on or off to control what you see.</CardDescription>
        </CardHeader>
        <CardContent className="divide-y divide-border">
          {loading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between py-4 gap-4">
                <div className="space-y-1.5 flex-1">
                  <Skeleton className="h-4 w-40 bg-muted" />
                  <Skeleton className="h-3 w-64 bg-muted" />
                </div>
                <Skeleton className="h-6 w-11 rounded-full bg-muted shrink-0" />
              </div>
            ))
          ) : prefs && ALL_NOTIF_MODULES.map(mod => {
            const enabled = prefs[mod.key];
            return (
              <div
                key={mod.key}
                className="flex items-start justify-between py-4 gap-4 group"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className={`text-sm font-medium ${!enabled ? 'text-muted-foreground' : ''}`}>
                      {mod.label}
                    </p>
                    {!enabled && (
                      <Badge variant="secondary" className="text-[10px] px-1.5 py-0">Muted</Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5 text-pretty">
                    {mod.description}
                  </p>
                </div>
                <Switch
                  checked={enabled}
                  onCheckedChange={val => toggle(mod.key, val)}
                  aria-label={`Toggle ${mod.label} notifications`}
                  className="shrink-0 mt-0.5"
                />
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Save reminder */}
      {dirty && (
        <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200 dark:bg-amber-900/20 dark:border-amber-800">
          <p className="text-sm text-amber-800 dark:text-amber-200">You have unsaved changes.</p>
          <Button size="sm" onClick={save} disabled={saving}>
            {saving ? 'Saving…' : 'Save Now'}
          </Button>
        </div>
      )}
    </div>
  );
}
