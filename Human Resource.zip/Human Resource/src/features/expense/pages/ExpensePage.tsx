import { useState, useEffect, useCallback } from 'react';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { expenseService } from '@/services/modules.service';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Plus, RefreshCw, Calculator } from 'lucide-react';

const STATUS_COLORS: Record<string, string> = {
  draft: 'bg-muted text-muted-foreground',
  submitted: 'bg-blue-100 text-blue-800',
  approved: 'bg-green-100 text-green-800',
  rejected: 'bg-red-100 text-red-800',
  paid: 'bg-teal-100 text-teal-800',
};

const fmt = (n: number) => new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB', maximumFractionDigits: 0 }).format(n);

export function ExpensePage() {
  const [reports, setReports] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [statusFilter, setStatusFilter] = useState('all');
  const [dialog, setDialog] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ employee_id: '', title: '', description: '', total_amount: '', currency: 'THB', status: 'draft' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await expenseService.list({ status: statusFilter !== 'all' ? statusFilter : undefined, page: 1, pageSize: 30 });
      setReports(res.data as Record<string, unknown>[]);
      setTotal(res.total);
    } catch { toast.error('Failed to load expense reports'); }
    finally { setLoading(false); }
  }, [statusFilter]);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.employee_id || form.employee_id === 'none') { toast.error('Please select an employee'); return; }
    setSaving(true);
    try {
      await expenseService.create({ ...form, total_amount: Number(form.total_amount) });
      toast.success('Expense report created');
      setDialog(false);
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Expenses</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} reports</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
          <Dialog open={dialog} onOpenChange={setDialog}>
            <DialogTrigger asChild><Button size="sm"><Plus className="h-4 w-4 mr-1.5" />New Report</Button></DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>Create Expense Report</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 mt-2">
                <EmployeeSelect value={form.employee_id} onChange={v => setForm(p => ({ ...p, employee_id: v }))} required />
                <div className="space-y-1.5"><Label>Report Title *</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} required /></div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5"><Label>Total Amount *</Label><Input type="number" step="0.01" value={form.total_amount} onChange={e => setForm(p => ({ ...p, total_amount: e.target.value }))} required /></div>
                  <div className="space-y-1.5"><Label>Status</Label>
                    <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="submitted">Submitted</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setDialog(false)}>Cancel</Button>
                  <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Create'}</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      <div className="flex gap-3">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="submitted">Submitted</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead className="whitespace-nowrap">Employee</TableHead>
              <TableHead className="whitespace-nowrap">Title</TableHead>
              <TableHead className="whitespace-nowrap">Amount</TableHead>
              <TableHead className="whitespace-nowrap">Submitted</TableHead>
              <TableHead className="whitespace-nowrap">Status</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {loading ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 5 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
              : reports.length === 0 ? <TableRow><TableCell colSpan={5} className="text-center py-10 text-muted-foreground"><Calculator className="h-8 w-8 mx-auto mb-2 opacity-40" />No expense reports found</TableCell></TableRow>
              : reports.map((r, i) => {
                const emp = r.employee as { first_name?: string; last_name?: string } | undefined;
                return (
                  <TableRow key={String(r.id ?? i)}>
                    <TableCell className="whitespace-nowrap text-sm">{emp ? `${emp.first_name} ${emp.last_name}` : String(r.employee_id ?? '').slice(0, 8)}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium text-sm">{String(r.title ?? '')}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm font-medium">{r.total_amount != null ? fmt(Number(r.total_amount)) : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.claim_date ? String(r.claim_date) : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap"><span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${STATUS_COLORS[String(r.status ?? '')] ?? 'bg-muted text-muted-foreground'}`}>{String(r.status ?? '')}</span></TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
