import { useState, useEffect, useCallback } from 'react';
import { supabase as _supabase } from '@/db/supabase';
import { leaveService, patchLeaveRequest } from '@/services/attendance.service';
import { employeeService } from '@/services/employee.service';
import type { LeaveRequest, LeaveType, Employee } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import {
  RefreshCw, Plus, CalendarDays, CheckCircle2, XCircle, Clock,
  Eye, User, Send, X, Check, AlertCircle, Loader2, FileText,
  ChevronLeft, ChevronRight,
} from 'lucide-react';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const supabase = _supabase as any;

// ── Helpers ─────────────────────────────────────────────────────
const fmtDate = (d?: string) =>
  d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

const STATUS_COLORS: Record<string, string> = {
  pending:   'bg-yellow-100 text-yellow-800',
  submitted: 'bg-blue-100 text-blue-800',
  approved:  'bg-green-100 text-green-800',
  rejected:  'bg-red-100 text-red-800',
  cancelled: 'bg-muted text-muted-foreground',
  withdrawn: 'bg-muted text-muted-foreground',
  DRAFT:     'bg-muted text-muted-foreground',
  SUBMITTED: 'bg-blue-100 text-blue-800',
  APPROVED:  'bg-green-100 text-green-800',
  REJECTED:  'bg-red-100 text-red-800',
  CANCELLED: 'bg-muted text-muted-foreground',
  WITHDRAWN: 'bg-muted text-muted-foreground',
};

const STATUS_ICON: Record<string, React.FC<{ className?: string }>> = {
  pending:   Clock,
  submitted: Clock,
  approved:  CheckCircle2,
  rejected:  XCircle,
  SUBMITTED: Clock,
  APPROVED:  CheckCircle2,
  REJECTED:  XCircle,
};

const CATEGORY_COLORS: Record<string, string> = {
  ANNUAL:      'bg-blue-100 text-blue-800',
  SICK:        'bg-red-100 text-red-800',
  MATERNITY:   'bg-pink-100 text-pink-800',
  PATERNITY:   'bg-purple-100 text-purple-800',
  UNPAID:      'bg-muted text-muted-foreground',
  SPECIAL:     'bg-teal-100 text-teal-800',
  COMPASSIONATE:'bg-orange-100 text-orange-800',
};

// ── Form schema ──────────────────────────────────────────────────
const requestSchema = z.object({
  employee_id:    z.string().min(1, 'Select employee'),
  leave_type_id:  z.string().min(1, 'Select leave type'),
  start_date:     z.string().min(1, 'Required'),
  end_date:       z.string().min(1, 'Required'),
  reason:         z.string().min(5, 'Provide a reason (min 5 chars)'),
  contact_info:   z.string().optional(),
  substitute_employee_id: z.string().optional(),
}).refine(d => new Date(d.end_date) >= new Date(d.start_date), {
  message: 'End date must be after start date',
  path: ['end_date'],
});
type RequestForm = z.infer<typeof requestSchema>;

const rejectSchema = z.object({ rejection_reason: z.string().min(5, 'Provide a reason') });
type RejectForm = z.infer<typeof rejectSchema>;

// ── Component ────────────────────────────────────────────────────
export function EssLeaveWorkflowPage() {
  const [tab, setTab] = useState<'employee' | 'manager'>('employee');

  // Data
  const [requests,   setRequests]   = useState<LeaveRequest[]>([]);
  const [leaveTypes, setLeaveTypes] = useState<LeaveType[]>([]);
  const [employees,  setEmployees]  = useState<Employee[]>([]);
  const [loading,    setLoading]    = useState(true);
  const [total,      setTotal]      = useState(0);
  const [page,       setPage]       = useState(1);
  const PAGE = 20;

  // Manager queue
  const [pending,    setPending]    = useState<LeaveRequest[]>([]);
  const [pendLoading, setPendLoading] = useState(false);

  // Dialogs
  const [createOpen, setCreateOpen] = useState(false);
  const [viewReq,    setViewReq]    = useState<LeaveRequest | null>(null);
  const [rejectOpen, setRejectOpen] = useState<LeaveRequest | null>(null);

  // Filter
  const [statusFilter, setStatusFilter] = useState('all');
  const [empFilter,    setEmpFilter]    = useState('all');
  const [saving,       setSaving]       = useState(false);
  const [approving,    setApproving]    = useState<string | null>(null);

  const form = useForm<RequestForm>({
    resolver: zodResolver(requestSchema),
    defaultValues: {
      employee_id: '', leave_type_id: '', start_date: '', end_date: '', reason: '', contact_info: '',
    },
  });

  const rejectForm = useForm<RejectForm>({
    resolver: zodResolver(rejectSchema),
    defaultValues: { rejection_reason: '' },
  });

  // ── Load data ─────────────────────────────────────────────────
  const load = useCallback(async () => {
    setLoading(true);
    try {
      let q = supabase
        .from('leave_requests')
        .select(
          '*, employee:employees!leave_requests_employee_id_fkey(id, first_name, last_name, employee_no, department_id), leave_type:leave_types(id, code, name, leave_category, is_paid)',
          { count: 'exact' }
        )
        .eq('is_deleted', 0)
        .order('created_at', { ascending: false })
        .range((page - 1) * PAGE, page * PAGE - 1);
      if (statusFilter !== 'all') q = q.eq('status', statusFilter);
      if (empFilter && empFilter !== 'all') q = q.eq('employee_id', empFilter);
      const { data, error, count } = await q;
      if (error) throw error;
      setRequests((data ?? []) as LeaveRequest[]);
      setTotal(count ?? 0);
    } catch { toast.error('Failed to load leave requests'); }
    finally { setLoading(false); }
  }, [page, statusFilter, empFilter]);

  const loadPending = useCallback(async () => {
    setPendLoading(true);
    try {
      const { data, error } = await supabase
        .from('leave_requests')
        .select('*, employee:employees!leave_requests_employee_id_fkey(id, first_name, last_name, employee_no), leave_type:leave_types(id, code, name, leave_category)')
        .in('status', ['pending', 'submitted', 'SUBMITTED'])
        .eq('is_deleted', 0)
        .order('created_at', { ascending: true });
      if (error) throw error;
      setPending((data ?? []) as LeaveRequest[]);
    } catch { toast.error('Failed to load pending approvals'); }
    finally { setPendLoading(false); }
  }, []);

  const loadBase = useCallback(async () => {
    const [typesRes, empRes] = await Promise.all([
      leaveService.listTypes().catch(() => [] as LeaveType[]),
      employeeService.list({ page: 1, pageSize: 500, employment_status: 'active' }),
    ]);
    setLeaveTypes(Array.isArray(typesRes) ? typesRes : []);
    setEmployees(Array.isArray(empRes.data) ? empRes.data : []);
  }, []);

  useEffect(() => { loadBase(); }, [loadBase]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { if (tab === 'manager') loadPending(); }, [tab, loadPending]);

  // ── Derived stats ─────────────────────────────────────────────
  const stats = {
    total:    total,
    pending:  requests.filter(r => ['pending', 'submitted', 'SUBMITTED', 'DRAFT'].includes(r.status ?? '')).length,
    approved: requests.filter(r => ['approved', 'APPROVED'].includes(r.status ?? '')).length,
    rejected: requests.filter(r => ['rejected', 'REJECTED'].includes(r.status ?? '')).length,
  };

  // ── Compute days ──────────────────────────────────────────────
  const calcDays = (s: string, e: string) =>
    s && e ? Math.max(1, Math.round((new Date(e).getTime() - new Date(s).getTime()) / 86400000) + 1) : 0;

  const watchStart = form.watch('start_date');
  const watchEnd   = form.watch('end_date');
  const previewDays = calcDays(watchStart, watchEnd);

  // ── Submit leave request ───────────────────────────────────────
  const handleSubmit = async (vals: RequestForm) => {
    setSaving(true);
    try {
      await leaveService.createRequest({
        employee_id:   vals.employee_id,
        leave_type_id: vals.leave_type_id,
        start_date:    vals.start_date,
        end_date:      vals.end_date,
        total_days:    calcDays(vals.start_date, vals.end_date),
        reason:        vals.reason,
        contact_info:  vals.contact_info || undefined,
        substitute_employee_id: vals.substitute_employee_id || undefined,
        status:        'pending' as LeaveRequest['status'],
        request_status: 'SUBMITTED',
        is_deleted: 0,
      });
      toast.success('Leave request submitted successfully');
      setCreateOpen(false);
      form.reset();
      load();
      loadPending();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to submit request');
    } finally {
      setSaving(false);
    }
  };

  // ── Approve ───────────────────────────────────────────────────
  const handleApprove = async (req: LeaveRequest) => {
    setApproving(req.id);
    try {
      await leaveService.approveRequest(req.id);
      toast.success(`Leave request for ${req.employee?.first_name ?? 'employee'} approved`);
      load();
      loadPending();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Approval failed');
    } finally {
      setApproving(null);
    }
  };

  // ── Reject ────────────────────────────────────────────────────
  const handleReject = async (vals: RejectForm) => {
    if (!rejectOpen) return;
    setSaving(true);
    try {
      await leaveService.rejectRequest(rejectOpen.id, vals.rejection_reason);
      toast.success('Leave request rejected');
      setRejectOpen(null);
      rejectForm.reset();
      load();
      loadPending();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Rejection failed');
    } finally {
      setSaving(false);
    }
  };

  // ── Cancel request ─────────────────────────────────────────────
  const handleCancel = async (req: LeaveRequest) => {
    try {
      await patchLeaveRequest(req.id, { status: 'cancelled', request_status: 'CANCELLED' });
      toast.success('Request cancelled');
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Cancel failed');
    }
  };

  // ── JSX ────────────────────────────────────────────────────────
  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-balance">Leave Request Workflow</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Employee self-service leave submission and manager approval workflow.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Button variant="outline" size="sm" onClick={() => { load(); loadPending(); }}>
            <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
          </Button>
          <Button size="sm" className="gap-1.5" onClick={() => { form.reset(); setCreateOpen(true); }}>
            <Plus className="h-4 w-4" />New Request
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Requests', value: stats.total,    icon: FileText,     color: 'text-foreground' },
          { label: 'Pending Approval', value: pending.length, icon: Clock,      color: 'text-yellow-600' },
          { label: 'Approved',        value: stats.approved, icon: CheckCircle2, color: 'text-green-600' },
          { label: 'Rejected',        value: stats.rejected, icon: XCircle,      color: 'text-red-500' },
        ].map(s => (
          <Card key={s.label} className="h-full">
            <CardContent className="p-3 flex items-center gap-2.5">
              <s.icon className={`h-5 w-5 shrink-0 ${s.color}`} />
              <div>
                <div className={`text-xl font-bold ${s.color}`}>{s.value}</div>
                <div className="text-xs text-muted-foreground">{s.label}</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Tabs */}
      <Tabs value={tab} onValueChange={v => setTab(v as typeof tab)}>
        <TabsList>
          <TabsTrigger value="employee"><CalendarDays className="h-3.5 w-3.5 mr-1.5" />All Requests</TabsTrigger>
          <TabsTrigger value="manager">
            <User className="h-3.5 w-3.5 mr-1.5" />
            Manager Approval
            {pending.length > 0 && (
              <span className="ml-1.5 h-4 w-4 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-semibold">
                {pending.length}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        {/* ── All Requests tab ── */}
        <TabsContent value="employee" className="mt-4 space-y-3">
          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-2">
            <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setPage(1); }}>
              <SelectTrigger className="md:w-44">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            <Select value={empFilter} onValueChange={v => { setEmpFilter(v); setPage(1); }}>
              <SelectTrigger className="md:w-56">
                <SelectValue placeholder="All Employees" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Employees</SelectItem>
                {employees.map(e => (
                  <SelectItem key={e.id} value={e.id}>
                    {e.first_name} {e.last_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead>Leave Type</TableHead>
                      <TableHead className="whitespace-nowrap">Start Date</TableHead>
                      <TableHead className="whitespace-nowrap">End Date</TableHead>
                      <TableHead className="whitespace-nowrap text-center">Days</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 6 }).map((_, i) => (
                        <TableRow key={i}><TableCell colSpan={8}><Skeleton className="h-8 w-full" /></TableCell></TableRow>
                      ))
                    ) : requests.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center text-muted-foreground py-12">
                          <CalendarDays className="h-8 w-8 mx-auto mb-2 opacity-30" />
                          No leave requests found
                        </TableCell>
                      </TableRow>
                    ) : requests.map(req => {
                      const status = (req.request_status ?? req.status ?? 'pending') as string;
                      const StatusIco = STATUS_ICON[status] ?? AlertCircle;
                      return (
                        <TableRow key={req.id}>
                          <TableCell className="whitespace-nowrap">
                            <div className="font-medium text-sm">
                              {req.employee?.first_name} {req.employee?.last_name}
                            </div>
                            <div className="text-xs text-muted-foreground">#{req.employee?.employee_no}</div>
                          </TableCell>
                          <TableCell className="whitespace-nowrap">
                            <div className="text-sm">{req.leave_type?.name ?? '—'}</div>
                            {req.leave_type?.leave_category && (
                              <Badge className={`text-xs mt-0.5 ${CATEGORY_COLORS[req.leave_type.leave_category] ?? 'bg-muted text-muted-foreground'}`}>
                                {req.leave_type.leave_category}
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{fmtDate(req.start_date)}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{fmtDate(req.end_date)}</TableCell>
                          <TableCell className="text-center font-semibold text-sm">{req.total_days}</TableCell>
                          <TableCell>
                            <Badge className={`gap-1 text-xs capitalize ${STATUS_COLORS[status] ?? 'bg-muted text-muted-foreground'}`}>
                              <StatusIco className="h-3 w-3" />
                              {status.toLowerCase()}
                            </Badge>
                          </TableCell>
                          <TableCell className="max-w-[140px]">
                            <span className="text-xs text-muted-foreground truncate block">{req.reason ?? '—'}</span>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => setViewReq(req)}>
                                <Eye className="h-3.5 w-3.5" />
                              </Button>
                              {['pending', 'submitted', 'SUBMITTED', 'DRAFT'].includes(status) && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-7 px-2 text-red-600 hover:text-red-700"
                                  onClick={() => handleCancel(req)}
                                >
                                  <X className="h-3.5 w-3.5" />
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
              {/* Pagination */}
              {total > PAGE && (
                <div className="flex items-center justify-between px-4 py-3 border-t border-border text-sm text-muted-foreground">
                  <span>Showing {(page - 1) * PAGE + 1}–{Math.min(page * PAGE, total)} of {total}</span>
                  <div className="flex items-center gap-1">
                    <Button size="sm" variant="outline" className="h-7 w-7 p-0" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>
                      <ChevronLeft className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 w-7 p-0" disabled={page * PAGE >= total} onClick={() => setPage(p => p + 1)}>
                      <ChevronRight className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Manager Approval tab ── */}
        <TabsContent value="manager" className="mt-4">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Pending Approval Queue</CardTitle>
                <Badge className="bg-yellow-100 text-yellow-800">{pending.length} pending</Badge>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead>Leave Type</TableHead>
                      <TableHead className="whitespace-nowrap">Period</TableHead>
                      <TableHead className="whitespace-nowrap text-center">Days</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead className="whitespace-nowrap">Submitted</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendLoading ? (
                      Array.from({ length: 4 }).map((_, i) => (
                        <TableRow key={i}><TableCell colSpan={7}><Skeleton className="h-8 w-full" /></TableCell></TableRow>
                      ))
                    ) : pending.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-muted-foreground py-12">
                          <CheckCircle2 className="h-8 w-8 mx-auto mb-2 text-green-500/40" />
                          No pending requests — all caught up!
                        </TableCell>
                      </TableRow>
                    ) : pending.map(req => (
                      <TableRow key={req.id}>
                        <TableCell className="whitespace-nowrap">
                          <div className="font-medium text-sm">{req.employee?.first_name} {req.employee?.last_name}</div>
                          <div className="text-xs text-muted-foreground">#{req.employee?.employee_no}</div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="text-sm">{req.leave_type?.name ?? '—'}</div>
                          {req.leave_type?.leave_category && (
                            <Badge className={`text-xs mt-0.5 ${CATEGORY_COLORS[req.leave_type.leave_category] ?? 'bg-muted text-muted-foreground'}`}>
                              {req.leave_type.leave_category}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">
                          {fmtDate(req.start_date)} — {fmtDate(req.end_date)}
                        </TableCell>
                        <TableCell className="text-center font-semibold text-sm">{req.total_days}</TableCell>
                        <TableCell className="max-w-[160px]">
                          <span className="text-xs text-muted-foreground truncate block">{req.reason ?? '—'}</span>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                          {fmtDate(req.created_at)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1.5">
                            <Button
                              size="sm"
                              className="h-7 px-2.5 gap-1 bg-green-600 hover:bg-green-700 text-white"
                              disabled={approving === req.id}
                              onClick={() => handleApprove(req)}
                            >
                              {approving === req.id
                                ? <Loader2 className="h-3 w-3 animate-spin" />
                                : <Check className="h-3.5 w-3.5" />}
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 px-2.5 gap-1 text-red-600 border-red-200 hover:bg-red-50"
                              onClick={() => { setRejectOpen(req); rejectForm.reset(); }}
                            >
                              <X className="h-3.5 w-3.5" />Reject
                            </Button>
                            <Button size="sm" variant="outline" className="h-7 w-7 p-0" onClick={() => setViewReq(req)}>
                              <Eye className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ── Create Request Dialog ── */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarDays className="h-5 w-5 text-primary" />New Leave Request
            </DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="employee_id" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Employee</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select employee…" /></SelectTrigger></FormControl>
                      <SelectContent>
                        {employees.map(e => (
                          <SelectItem key={e.id} value={e.id}>
                            {e.first_name} {e.last_name} ({e.employee_no})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="leave_type_id" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Leave Type</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select type…" /></SelectTrigger></FormControl>
                      <SelectContent>
                        {leaveTypes.map(t => (
                          <SelectItem key={t.id} value={t.id}>
                            {t.leave_name ?? t.name}
                            {t.leave_category && ` · ${t.leave_category}`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="start_date" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Date</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="end_date" render={({ field }) => (
                  <FormItem>
                    <FormLabel>End Date</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              {previewDays > 0 && (
                <div className="bg-primary/5 border border-primary/20 rounded-lg px-3 py-2 text-sm font-medium text-primary">
                  Duration: {previewDays} working day{previewDays !== 1 ? 's' : ''}
                </div>
              )}

              <FormField control={form.control} name="reason" render={({ field }) => (
                <FormItem>
                  <FormLabel>Reason</FormLabel>
                  <FormControl><Textarea rows={3} placeholder="Reason for leave…" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="contact_info" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contact During Leave <span className="text-muted-foreground text-xs">(optional)</span></FormLabel>
                    <FormControl><Input placeholder="Phone or email…" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="substitute_employee_id" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Substitute <span className="text-muted-foreground text-xs">(optional)</span></FormLabel>
                    <Select value={field.value ?? 'none'} onValueChange={v => field.onChange(v === 'none' ? undefined : v)}>
                      <FormControl><SelectTrigger><SelectValue placeholder="None" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {employees.map(e => (
                          <SelectItem key={e.id} value={e.id}>
                            {e.first_name} {e.last_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={saving} className="gap-2">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  Submit Request
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* ── View Request Dialog ── */}
      <Dialog open={!!viewReq} onOpenChange={open => { if (!open) setViewReq(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />Leave Request Detail
            </DialogTitle>
          </DialogHeader>
          {viewReq && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm bg-muted/30 rounded-lg p-3">
                <div><Label className="text-xs text-muted-foreground">Employee</Label>
                  <div className="font-medium">{viewReq.employee?.first_name} {viewReq.employee?.last_name}</div>
                </div>
                <div><Label className="text-xs text-muted-foreground">Employee No</Label>
                  <div className="font-medium">#{viewReq.employee?.employee_no}</div>
                </div>
                <div><Label className="text-xs text-muted-foreground">Leave Type</Label>
                  <div className="font-medium">{viewReq.leave_type?.name ?? '—'}</div>
                </div>
                <div><Label className="text-xs text-muted-foreground">Days</Label>
                  <div className="font-bold text-primary">{viewReq.total_days}</div>
                </div>
                <div><Label className="text-xs text-muted-foreground">Start Date</Label>
                  <div className="font-medium">{fmtDate(viewReq.start_date)}</div>
                </div>
                <div><Label className="text-xs text-muted-foreground">End Date</Label>
                  <div className="font-medium">{fmtDate(viewReq.end_date)}</div>
                </div>
              </div>
              <Separator />
              <div>
                <Label className="text-xs text-muted-foreground">Status</Label>
                <div className="mt-1">
                  {(() => {
                    const s = (viewReq.request_status ?? viewReq.status ?? 'pending') as string;
                    const Ico = STATUS_ICON[s] ?? AlertCircle;
                    return (
                      <Badge className={`gap-1.5 capitalize text-sm ${STATUS_COLORS[s]}`}>
                        <Ico className="h-3.5 w-3.5" />{s.toLowerCase()}
                      </Badge>
                    );
                  })()}
                </div>
              </div>
              {viewReq.reason && (
                <div>
                  <Label className="text-xs text-muted-foreground">Reason</Label>
                  <p className="mt-1 text-sm">{viewReq.reason}</p>
                </div>
              )}
              {viewReq.rejection_reason && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <Label className="text-xs text-red-600 font-semibold">Rejection Reason</Label>
                  <p className="mt-1 text-sm text-red-700">{viewReq.rejection_reason}</p>
                </div>
              )}
              {viewReq.contact_info && (
                <div>
                  <Label className="text-xs text-muted-foreground">Contact During Leave</Label>
                  <p className="mt-1 text-sm">{viewReq.contact_info}</p>
                </div>
              )}
              <div className="flex justify-between gap-2 pt-1">
                <div className="flex gap-2">
                  {['pending', 'submitted', 'SUBMITTED', 'DRAFT'].includes((viewReq.request_status ?? viewReq.status ?? '') as string) && (
                    <>
                      <Button
                        size="sm"
                        className="gap-1.5 bg-green-600 hover:bg-green-700 text-white"
                        disabled={approving === viewReq.id}
                        onClick={() => { handleApprove(viewReq); setViewReq(null); }}
                      >
                        <Check className="h-3.5 w-3.5" />Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="gap-1.5 text-red-600 border-red-200"
                        onClick={() => { setRejectOpen(viewReq); setViewReq(null); rejectForm.reset(); }}
                      >
                        <X className="h-3.5 w-3.5" />Reject
                      </Button>
                    </>
                  )}
                </div>
                <Button variant="outline" onClick={() => setViewReq(null)}>Close</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ── Reject Dialog ── */}
      <Dialog open={!!rejectOpen} onOpenChange={open => { if (!open) setRejectOpen(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <XCircle className="h-5 w-5 text-red-500" />Reject Leave Request
            </DialogTitle>
          </DialogHeader>
          {rejectOpen && (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Rejecting request for <strong>{rejectOpen.employee?.first_name} {rejectOpen.employee?.last_name}</strong>
                {' '}— {rejectOpen.total_days} day{rejectOpen.total_days !== 1 ? 's' : ''} from {fmtDate(rejectOpen.start_date)}.
              </p>
              <Form {...rejectForm}>
                <form onSubmit={rejectForm.handleSubmit(handleReject)} className="space-y-4">
                  <FormField control={rejectForm.control} name="rejection_reason" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Rejection Reason</FormLabel>
                      <FormControl><Textarea rows={3} placeholder="Provide a reason…" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setRejectOpen(null)}>Cancel</Button>
                    <Button type="submit" variant="destructive" disabled={saving} className="gap-2">
                      {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <XCircle className="h-4 w-4" />}
                      Confirm Reject
                    </Button>
                  </div>
                </form>
              </Form>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
