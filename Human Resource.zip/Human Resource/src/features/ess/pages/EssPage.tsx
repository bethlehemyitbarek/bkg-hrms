import { useState, useEffect, useCallback } from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '@/app/store';
import { employeeService } from '@/services/employee.service';
import { leaveService, attendanceService } from '@/services/attendance.service';
import { payrollService } from '@/services/payroll.service';
import type { LeaveType, AttendanceRecord, LeaveRequest } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import {
  RefreshCw, User, Calendar, Clock, FileText,
  Plus, Wallet, CheckCircle2, XCircle, Timer, Download, Mail, Loader2,
  ShieldCheck, Megaphone, DatabaseZap, TrendingUp, Banknote, Star,
  Receipt, TicketCheck, HandCoins,
} from 'lucide-react';
import jsPDF from 'jspdf';
import { hrPolicyService, policyAckService, dsarService } from '@/services/compliance.service';
import { announcementService } from '@/services/announcement.service';
import type { HrPolicy, PolicyAcknowledgment, DataSubjectAccessRequest, Announcement, AnnouncementPriority } from '@/types/database.types';

const fmtCurrencyPdf = (n: unknown) =>
  `ብር ${Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}`;

/** Convert an image URL → base64 data URI, returns null on failure */
async function imgUrlToBase64(url: string): Promise<string | null> {
  try {
    const res  = await fetch(url, { mode: 'cors' });
    if (!res.ok) return null;
    const blob = await res.blob();
    return await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload  = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch { return null; }
}

async function exportPayslipPdf(
  payslip: Record<string, unknown>,
  employeeName: string,
  employee?: Record<string, unknown> | null,
) {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const W      = doc.internal.pageSize.getWidth();
  const margin = 48;
  let y = 48;

  // Attempt to load images in parallel
  const logoUrl  = '/images/logo/auth-logo.svg';
  const photoUrl = employee?.profile_photo_url ? String(employee.profile_photo_url) : null;
  const [logoB64, photoB64] = await Promise.all([
    imgUrlToBase64(logoUrl),
    photoUrl ? imgUrlToBase64(photoUrl) : Promise.resolve(null),
  ]);

  // ── Header band ─────────────────────────────────────────────
  doc.setFillColor(37, 99, 235);
  doc.rect(0, 0, W, 80, 'F');

  // Company logo (left side of header)
  if (logoB64) {
    try { doc.addImage(logoB64, 'SVG', margin, 12, 120, 40); }
    catch { /* fallback to text */ doc.setTextColor(255,255,255); doc.setFont('helvetica','bold'); doc.setFontSize(18); doc.text('BKG Company', margin, 36); }
  } else {
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.text('BKG Company', margin, 36);
  }

  // "PAYSLIP" label top-right of header
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text('PAYSLIP', W - margin, 28, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  const period = payslip.payroll_period as { name?: string } | undefined;
  doc.text(period?.name ?? '', W - margin, 46, { align: 'right' });

  y = 100;
  doc.setTextColor(30, 30, 30);

  // ── Employee row (photo left + name/details right) ───────────
  const photoSize = 52;
  if (photoB64) {
    try {
      doc.addImage(photoB64, 'JPEG', margin, y - 6, photoSize, photoSize);
    } catch { /* skip photo if format unsupported */ }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.text(employeeName, margin + photoSize + 12, y + 8);
    // Employee # and dept if available
    const empNo   = employee?.employee_no   ? `#${employee.employee_no}`   : '';
    const deptName = (employee?.department as { name?: string } | undefined)?.name ?? '';
    if (empNo || deptName) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(100, 116, 139);
      doc.text([empNo, deptName].filter(Boolean).join('  ·  '), margin + photoSize + 12, y + 24);
      doc.setTextColor(30, 30, 30);
    }
    y += photoSize + 16;
  } else {
    // No photo — draw a colored circle with initials
    const initials = employeeName.split(' ').map(w => w[0] ?? '').join('').slice(0, 2).toUpperCase();
    doc.setFillColor(219, 234, 254);
    doc.circle(margin + photoSize / 2, y + photoSize / 2 - 6, photoSize / 2, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.setTextColor(37, 99, 235);
    doc.text(initials, margin + photoSize / 2, y + photoSize / 2 + 2, { align: 'center' });
    doc.setTextColor(30, 30, 30);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.text(employeeName, margin + photoSize + 12, y + 8);
    const empNo   = employee?.employee_no   ? `#${employee.employee_no}`   : '';
    const deptName = (employee?.department as { name?: string } | undefined)?.name ?? '';
    if (empNo || deptName) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(100, 116, 139);
      doc.text([empNo, deptName].filter(Boolean).join('  ·  '), margin + photoSize + 12, y + 24);
      doc.setTextColor(30, 30, 30);
    }
    y += photoSize + 16;
  }

  const drawDivider = () => {
    doc.setDrawColor(220, 220, 220);
    doc.line(margin, y, W - margin, y);
    y += 12;
  };

  const drawRow = (label: string, value: string, bold = false, color?: [number, number, number]) => {
    doc.setFont('helvetica', bold ? 'bold' : 'normal');
    doc.setFontSize(10);
    if (color) doc.setTextColor(...color);
    else doc.setTextColor(30, 30, 30);
    doc.text(label, margin, y);
    doc.text(value, W - margin, y, { align: 'right' });
    doc.setTextColor(30, 30, 30);
    y += 18;
  };

  const drawSection = (title: string) => {
    drawDivider();
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.text(title.toUpperCase(), margin, y);
    doc.setTextColor(30, 30, 30);
    y += 16;
  };

  // ── Earnings ─────────────────────────────────────────────────
  drawSection('Earnings');
  drawRow('Basic Salary',  fmtCurrencyPdf(payslip.basic_salary));
  drawRow('Overtime Pay',  fmtCurrencyPdf(payslip.overtime_pay));
  drawRow('Allowances',    fmtCurrencyPdf(payslip.allowances));
  drawRow('Gross Pay',     fmtCurrencyPdf(payslip.gross_pay), true);

  // ── Deductions ───────────────────────────────────────────────
  drawSection('Deductions');
  drawRow('Income Tax',        fmtCurrencyPdf(payslip.tax_deduction));
  drawRow('Social Security',   fmtCurrencyPdf(payslip.social_security));
  drawRow('Provident Fund',    fmtCurrencyPdf(payslip.provident_fund));
  drawRow('Other Deductions',  fmtCurrencyPdf(payslip.other_deductions));
  drawRow('Total Deductions',  fmtCurrencyPdf(payslip.total_deductions), true, [220, 38, 38]);

  // ── Net Pay band ─────────────────────────────────────────────
  y += 6;
  doc.setFillColor(239, 246, 255);
  doc.roundedRect(margin, y - 4, W - margin * 2, 30, 4, 4, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(37, 99, 235);
  doc.text('Net Pay', margin + 12, y + 16);
  doc.text(fmtCurrencyPdf(payslip.net_pay), W - margin - 12, y + 16, { align: 'right' });
  y += 44;

  // ── Status ───────────────────────────────────────────────────
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  const status = String(payslip.payment_status ?? 'pending');
  const payDate = payslip.payment_date ? `  ·  Paid on ${new Date(String(payslip.payment_date)).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}` : '';
  doc.text(`Status: ${status.charAt(0).toUpperCase() + status.slice(1)}${payDate}`, margin, y);

  // ── Footer ───────────────────────────────────────────────────
  const pageH = doc.internal.pageSize.getHeight();
  doc.setFontSize(8);
  doc.setTextColor(180, 180, 180);
  doc.text('Generated by BKG HRMS', W / 2, pageH - 24, { align: 'center' });

  const filename = `payslip_${(period?.name ?? 'export').replace(/\s+/g, '_')}_${employeeName.replace(/\s+/g, '_')}.pdf`;
  doc.save(filename);
  // Return base64 string (without data: prefix) for email sending
  return { base64: doc.output('datauristring'), filename, periodName: period?.name ?? '' };
}


const STATUS_BADGE: Record<string, string> = {
  present:     'bg-green-100 text-green-800',
  absent:      'bg-red-100 text-red-800',
  late:        'bg-yellow-100 text-yellow-800',
  early_leave: 'bg-orange-100 text-orange-800',
  half_day:    'bg-blue-100 text-blue-800',
  on_leave:    'bg-purple-100 text-purple-800',
  holiday:     'bg-teal-100 text-teal-800',
  weekend:     'bg-muted text-muted-foreground',
  remote:      'bg-indigo-100 text-indigo-800',
};
const LEAVE_STATUS_BADGE: Record<string, string> = {
  pending:   'bg-yellow-100 text-yellow-800',
  approved:  'bg-green-100 text-green-800',
  rejected:  'bg-red-100 text-red-800',
  cancelled: 'bg-muted text-muted-foreground',
  withdrawn: 'bg-muted text-muted-foreground',
};

const fmtCurrency = (n: number | string) =>
  `ብር ${Number(n||0).toLocaleString('en-US',{maximumFractionDigits:0})}`;

const fmtTime = (ts?: string | null) => {
  if (!ts) return '—';
  const t = ts.includes('T') ? ts.split('T')[1] : ts;
  return t.slice(0, 5);
};

const fmtDate = (d?: string) =>
  d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

const calcWorkedHours = (r: AttendanceRecord) => {
  if (r.work_minutes && r.work_minutes > 0) return `${(r.work_minutes / 60).toFixed(1)} hrs`;
  if (r.check_in && r.check_out) {
    const inT  = r.check_in.includes('T')  ? r.check_in.split('T')[1]  : r.check_in;
    const outT = r.check_out.includes('T') ? r.check_out.split('T')[1] : r.check_out;
    const [ih, im] = inT.split(':').map(Number);
    const [oh, om] = outT.split(':').map(Number);
    const mins = (oh * 60 + om) - (ih * 60 + im);
    if (mins > 0) return `${(mins / 60).toFixed(1)} hrs`;
  }
  return '—';
};

export function EssPage() {
  const authUser = useSelector((state: RootState) => state.auth.user);

  // Profile
  const [employee, setEmployee] = useState<Record<string, unknown> | null>(null);
  const [leaveBalances, setLeaveBalances] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);

  // Attendance
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [attLoading, setAttLoading] = useState(false);
  const [attTotal, setAttTotal] = useState(0);
  const [attPage, setAttPage] = useState(1);
  const attPageSize = 15;

  // Leave requests
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>([]);
  const [leaveTypes, setLeaveTypes] = useState<LeaveType[]>([]);
  const [leaveLoading, setLeaveLoading] = useState(false);
  const [leaveTotal, setLeaveTotal] = useState(0);
  const [leavePage, setLeavePage] = useState(1);
  const leavePageSize = 10;
  const [leaveDialogOpen, setLeaveDialogOpen] = useState(false);
  const [savingLeave, setSavingLeave] = useState(false);
  const [leaveForm, setLeaveForm] = useState({ leave_type_id: '', start_date: '', end_date: '', reason: '' });

  // Payslips
  const [payslips, setPayslips] = useState<Record<string, unknown>[]>([]);
  const [payslipLoading, setPayslipLoading] = useState(false);
  const [selectedPayslip, setSelectedPayslip] = useState<Record<string, unknown> | null>(null);
  const [emailDialog, setEmailDialog]   = useState(false);
  const [emailTo,     setEmailTo]       = useState('');
  const [sendingEmail, setSendingEmail] = useState(false);
  const [emailLogs,   setEmailLogs]    = useState<{id:string;sent_to:string;sent_at:string;status:string;error_msg?:string}[]>([]);
  const [logsLoading,    setLogsLoading]    = useState(false);
  const [resendingLogId, setResendingLogId] = useState<string | null>(null);

  // ── Policies (ESS) ──
  const [policies,        setPolicies]        = useState<HrPolicy[]>([]);
  const [policyAcks,      setPolicyAcks]      = useState<Record<string, PolicyAcknowledgment>>({});
  const [policiesLoading, setPoliciesLoading] = useState(false);
  const [ackBusy,         setAckBusy]         = useState<string | null>(null);

  // ── Announcements (ESS) ──
  const [announcements,      setAnnouncements]      = useState<Announcement[]>([]);
  const [annLoading,         setAnnLoading]         = useState(false);

  // ── DSAR (ESS) ──
  const [dsarRequests, setDsarRequests]  = useState<DataSubjectAccessRequest[]>([]);
  const [dsarLoading,  setDsarLoading]   = useState(false);
  const [dsarForm,     setDsarForm]      = useState({ request_type: 'ACCESS', description: '' });
  const [dsarSaving,   setDsarSaving]    = useState(false);

  const loadEmailLogs = useCallback(async (payrollRecordId: string) => {
    if (!payrollRecordId) return;
    setLogsLoading(true);
    try {
      const { supabase } = await import('@/db/supabase');
      const { data } = await (supabase as any)
        .from('payslip_email_logs')
        .select('id, sent_to, sent_at, status, error_msg')
        .eq('payroll_record_id', payrollRecordId)
        .order('sent_at', { ascending: false })
        .limit(20);
      setEmailLogs(Array.isArray(data) ? data : []);
    } catch { /* silent */ }
    finally { setLogsLoading(false); }
  }, []);

  /* ── Load Profile & Balances ── */
  const loadProfile = useCallback(async () => {
    setLoading(true);
    try {
      const empRes = await employeeService.list({ page: 1, pageSize: 1 });
      const emp = empRes.data?.[0] as unknown as Record<string, unknown> | undefined;
      if (emp) {
        setEmployee(emp);
        const year = new Date().getFullYear();
        const balances = await leaveService.getBalances(String(emp.id), year);
        setLeaveBalances(balances as unknown as Record<string, unknown>[]);
      }
    } catch { toast.error('Failed to load profile'); }
    finally { setLoading(false); }
  }, []);

  /* ── Load Attendance ── */
  const loadAttendance = useCallback(async () => {
    setAttLoading(true);
    try {
      const res = await attendanceService.list({ page: attPage, pageSize: attPageSize });
      setAttendance(res.data);
      setAttTotal(res.total);
    } catch { toast.error('Failed to load attendance'); }
    finally { setAttLoading(false); }
  }, [attPage]);

  /* ── Load Leave Requests ── */
  const loadLeaveRequests = useCallback(async () => {
    setLeaveLoading(true);
    try {
      const res = await leaveService.listRequests({ page: leavePage, pageSize: leavePageSize });
      setLeaveRequests(res.data);
      setLeaveTotal(res.total);
    } catch { toast.error('Failed to load leave requests'); }
    finally { setLeaveLoading(false); }
  }, [leavePage]);

  /* ── Load Payslips ── */
  const loadPayslips = useCallback(async () => {
    setPayslipLoading(true);
    try {
      const res = await payrollService.listRecords({ page: 1, pageSize: 20 });
      setPayslips(res.data as unknown as Record<string, unknown>[]);
    } catch { toast.error('Failed to load payslips'); }
    finally { setPayslipLoading(false); }
  }, []);

  useEffect(() => {
    loadProfile();
    leaveService.listTypes().then(setLeaveTypes).catch(() => {});
  }, [loadProfile]);

  useEffect(() => { loadAttendance(); }, [loadAttendance]);
  useEffect(() => { loadLeaveRequests(); }, [loadLeaveRequests]);
  useEffect(() => { loadPayslips(); }, [loadPayslips]);
  useEffect(() => {
    if (selectedPayslip?.id) loadEmailLogs(String(selectedPayslip.id));
    else setEmailLogs([]);
  }, [selectedPayslip, loadEmailLogs]);

  // ── Policies loader ──
  const loadPolicies = useCallback(async () => {
    setPoliciesLoading(true);
    try {
      const { data } = await hrPolicyService.list({ distribution_status: 'PUBLISHED', page: 1, pageSize: 50 });
      setPolicies(data as HrPolicy[]);
      // Load acks for current employee
      if (employee?.id) {
        const ackMap: Record<string, PolicyAcknowledgment> = {};
        for (const pol of data as HrPolicy[]) {
          const acks = await policyAckService.list(pol.policy_id);
          const mine = (acks as PolicyAcknowledgment[]).find(a => a.employee_id === String(employee.id));
          if (mine) ackMap[pol.policy_id] = mine;
        }
        setPolicyAcks(ackMap);
      }
    } catch { /* silent */ }
    finally { setPoliciesLoading(false); }
  }, [employee?.id]);

  // ── Announcements loader ──
  const loadAnnouncements = useCallback(async () => {
    setAnnLoading(true);
    try {
      const data = await announcementService.listPublished();
      setAnnouncements(data as Announcement[]);
    } catch { /* silent */ }
    finally { setAnnLoading(false); }
  }, []);

  // ── DSAR loader ──
  const loadDsar = useCallback(async () => {
    setDsarLoading(true);
    try {
      const { data } = await dsarService.list({ employee_id: employee?.id ? String(employee.id) : undefined, page: 1, pageSize: 20 });
      setDsarRequests(data as DataSubjectAccessRequest[]);
    } catch { /* silent */ }
    finally { setDsarLoading(false); }
  }, [employee?.id]);

  useEffect(() => {
    if (employee?.id) { loadPolicies(); loadAnnouncements(); loadDsar(); }
  }, [employee?.id, loadPolicies, loadAnnouncements, loadDsar]);

  const handleAcknowledge = async (policy: HrPolicy) => {
    if (!employee?.id) return;
    setAckBusy(policy.policy_id);
    try {
      await policyAckService.upsert(policy.policy_id, String(employee.id));
      toast.success('Policy acknowledged');
      loadPolicies();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Acknowledge failed'); }
    finally { setAckBusy(null); }
  };

  const handleSubmitDsar = async () => {
    if (!dsarForm.description.trim()) { toast.error('Please describe your request'); return; }
    if (!employee?.id) { toast.error('Employee profile not loaded'); return; }
    setDsarSaving(true);
    try {
      await dsarService.create({
        employee_id: String(employee.id),
        request_type: dsarForm.request_type,
        request_date: new Date().toISOString().slice(0, 10),
        request_status: 'SUBMITTED',
      });
      toast.success('DSAR submitted successfully');
      setDsarForm({ request_type: 'ACCESS', description: '' });
      loadDsar();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Submission failed'); }
    finally { setDsarSaving(false); }
  };

  const calculateDays = (s: string, e: string) => {
    if (!s || !e) return 0;
    return Math.max(1, Math.round((new Date(e).getTime() - new Date(s).getTime()) / 86400000) + 1);
  };

  const handleLeaveSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!leaveForm.leave_type_id) { toast.error('Select a leave type'); return; }
    if (!leaveForm.start_date || !leaveForm.end_date) { toast.error('Select start and end dates'); return; }
    setSavingLeave(true);
    try {
      await leaveService.createRequest({
        ...leaveForm,
        total_days: calculateDays(leaveForm.start_date, leaveForm.end_date),
        is_half_day: false,
        status: 'pending',
        employee_id: String(employee?.id ?? ''),
      });
      toast.success('Leave request submitted');
      setLeaveDialogOpen(false);
      setLeaveForm({ leave_type_id: '', start_date: '', end_date: '', reason: '' });
      loadLeaveRequests();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to submit'); }
    finally { setSavingLeave(false); }
  };

  /* ── Summary bar ── */
  const totalLeaveRemaining = leaveBalances.reduce(
    (s, b) => s + Number((b as Record<string, unknown>).remaining_days ?? 0), 0
  );
  const presentDays = attendance.filter(a => a.status === 'present' || a.status === 'remote').length;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-balance">Employee Self Service</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Welcome, {authUser?.email ?? 'employee'}</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => { loadProfile(); loadAttendance(); loadLeaveRequests(); loadPayslips(); }}>
          <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
        </Button>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Leave Remaining', value: totalLeaveRemaining + ' days', icon: Calendar,   color: 'text-blue-600' },
          { label: 'Present (loaded)', value: presentDays + ' days',        icon: CheckCircle2, color: 'text-green-600' },
          { label: 'Pending Requests', value: leaveRequests.filter(r => r.status === 'pending').length, icon: Timer, color: 'text-yellow-600' },
          { label: 'Payslips',         value: payslips.length,              icon: Wallet,      color: 'text-primary' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <s.icon className={`h-5 w-5 shrink-0 ${s.color}`} />
            <div className="min-w-0">
              <p className="text-[11px] text-muted-foreground leading-tight">{s.label}</p>
              <p className="text-lg font-bold leading-tight">{s.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Main tabs */}
      <Tabs defaultValue="profile">
        <TabsList className="h-9 flex-wrap">
          <TabsTrigger value="profile"><User className="h-3.5 w-3.5 mr-1.5" />Profile</TabsTrigger>
          <TabsTrigger value="leave"><Calendar className="h-3.5 w-3.5 mr-1.5" />Leave</TabsTrigger>
          <TabsTrigger value="attendance"><Clock className="h-3.5 w-3.5 mr-1.5" />Attendance</TabsTrigger>
          <TabsTrigger value="payslips"><Wallet className="h-3.5 w-3.5 mr-1.5" />Payslips</TabsTrigger>
          <TabsTrigger value="policies"><ShieldCheck className="h-3.5 w-3.5 mr-1.5" />Policies</TabsTrigger>
          <TabsTrigger value="announcements"><Megaphone className="h-3.5 w-3.5 mr-1.5" />Announcements</TabsTrigger>
          <TabsTrigger value="dsar"><DatabaseZap className="h-3.5 w-3.5 mr-1.5" />Data Requests</TabsTrigger>
          <TabsTrigger value="performance"><Star className="h-3.5 w-3.5 mr-1.5" />Performance</TabsTrigger>
          <TabsTrigger value="transfers"><TrendingUp className="h-3.5 w-3.5 mr-1.5" />Transfers</TabsTrigger>
          <TabsTrigger value="loans"><Banknote className="h-3.5 w-3.5 mr-1.5" />Loans</TabsTrigger>
          <TabsTrigger value="benefits-enroll"><HandCoins className="h-3.5 w-3.5 mr-1.5" />Benefits</TabsTrigger>
          <TabsTrigger value="expense"><Receipt className="h-3.5 w-3.5 mr-1.5" />Expenses</TabsTrigger>
          <TabsTrigger value="tickets"><TicketCheck className="h-3.5 w-3.5 mr-1.5" />HR Tickets</TabsTrigger>
        </TabsList>

        {/* ── Profile tab ── */}
        <TabsContent value="profile" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><User className="h-4 w-4" />My Profile</CardTitle></CardHeader>
              <CardContent>
                {loading ? <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-4 w-full bg-muted" />)}</div>
                : employee ? (
                  <dl className="space-y-2 text-sm">
                    {[
                      ['Name', `${employee.first_name ?? ''} ${employee.last_name ?? ''}`],
                      ['Employee #', String(employee.employee_no ?? '—')],
                      ['Department', (employee.department as { name?: string })?.name ?? '—'],
                      ['Position', (employee.position as { title?: string })?.title ?? '—'],
                      ['Status', String(employee.employment_status ?? '—')],
                    ].map(([label, value]) => (
                      <div key={label} className="flex justify-between gap-2">
                        <dt className="text-muted-foreground shrink-0">{label}</dt>
                        <dd className="font-medium text-right truncate">{value}</dd>
                      </div>
                    ))}
                  </dl>
                ) : <p className="text-sm text-muted-foreground">No profile found</p>}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><Calendar className="h-4 w-4" />Leave Balances</CardTitle></CardHeader>
              <CardContent>
                {loading ? <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-4 w-full bg-muted" />)}</div>
                : leaveBalances.length === 0 ? <p className="text-sm text-muted-foreground">No leave balances found</p>
                : <dl className="space-y-2 text-sm">
                    {leaveBalances.map((b, i) => {
                      const lt = (b as Record<string, unknown>).leave_type as { name?: string } | undefined;
                      const remaining = Number((b as Record<string, unknown>).entitled_days ?? 0) - Number((b as Record<string, unknown>).used_days ?? 0) - Number((b as Record<string, unknown>).pending_days ?? 0);
                      return (
                        <div key={i} className="flex justify-between items-center gap-2">
                          <dt className="text-muted-foreground truncate">{lt?.name ?? `Leave ${i + 1}`}</dt>
                          <dd className="font-semibold shrink-0">{Math.max(0, remaining)} <span className="text-muted-foreground font-normal text-xs">/ {String((b as Record<string, unknown>).entitled_days ?? '')} days</span></dd>
                        </div>
                      );
                    })}
                  </dl>}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ── Leave tab ── */}
        <TabsContent value="leave" className="mt-4 space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">{leaveTotal} request(s)</p>
            <Dialog open={leaveDialogOpen} onOpenChange={setLeaveDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" disabled={!employee}><Plus className="h-4 w-4 mr-1.5" />New Request</Button>
              </DialogTrigger>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                <DialogHeader><DialogTitle>Submit Leave Request</DialogTitle></DialogHeader>
                <form onSubmit={handleLeaveSubmit} className="space-y-4 mt-2">
                  <div className="space-y-1.5">
                    <Label>Leave Type *</Label>
                    <Select value={leaveForm.leave_type_id} onValueChange={v => setLeaveForm(p => ({ ...p, leave_type_id: v }))}>
                      <SelectTrigger><SelectValue placeholder="Select leave type" /></SelectTrigger>
                      <SelectContent>
                        {leaveTypes.map(lt => <SelectItem key={lt.id} value={lt.id}>{lt.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Start Date *</Label>
                      <Input type="date" value={leaveForm.start_date} onChange={e => setLeaveForm(p => ({ ...p, start_date: e.target.value }))} required />
                    </div>
                    <div className="space-y-1.5">
                      <Label>End Date *</Label>
                      <Input type="date" value={leaveForm.end_date} onChange={e => setLeaveForm(p => ({ ...p, end_date: e.target.value }))} required />
                    </div>
                  </div>
                  {leaveForm.start_date && leaveForm.end_date && (
                    <p className="text-sm text-muted-foreground">Total: <strong>{calculateDays(leaveForm.start_date, leaveForm.end_date)} day(s)</strong></p>
                  )}
                  <div className="space-y-1.5">
                    <Label>Reason</Label>
                    <Textarea value={leaveForm.reason} onChange={e => setLeaveForm(p => ({ ...p, reason: e.target.value }))} rows={3} placeholder="Reason for leave…" />
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setLeaveDialogOpen(false)}>Cancel</Button>
                    <Button type="submit" disabled={savingLeave}>{savingLeave ? 'Submitting…' : 'Submit'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Leave Type</TableHead>
                    <TableHead className="whitespace-nowrap">Start</TableHead>
                    <TableHead className="whitespace-nowrap">End</TableHead>
                    <TableHead className="whitespace-nowrap">Days</TableHead>
                    <TableHead className="whitespace-nowrap">Reason</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {leaveLoading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <TableRow key={i}>{Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>
                    ))
                  ) : leaveRequests.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground"><Calendar className="h-8 w-8 mx-auto mb-2 opacity-40" />No leave requests</TableCell></TableRow>
                  ) : leaveRequests.map(r => (
                    <TableRow key={r.id}>
                      <TableCell className="whitespace-nowrap text-sm">{(r.leave_type as { name?: string })?.name ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{fmtDate(r.start_date)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{fmtDate(r.end_date)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-medium">{r.total_days}</TableCell>
                      <TableCell className="text-sm max-w-[160px] truncate">{r.reason ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${LEAVE_STATUS_BADGE[r.status] ?? 'bg-muted text-muted-foreground'}`}>{r.status}</span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
          {Math.ceil(leaveTotal / leavePageSize) > 1 && (
            <div className="flex justify-end gap-2">
              <Button size="sm" variant="outline" disabled={leavePage <= 1} onClick={() => setLeavePage(p => p - 1)}>Prev</Button>
              <span className="text-sm self-center">{leavePage} / {Math.ceil(leaveTotal / leavePageSize)}</span>
              <Button size="sm" variant="outline" disabled={leavePage >= Math.ceil(leaveTotal / leavePageSize)} onClick={() => setLeavePage(p => p + 1)}>Next</Button>
            </div>
          )}
        </TabsContent>

        {/* ── Attendance tab ── */}
        <TabsContent value="attendance" className="mt-4 space-y-4">
          <p className="text-sm text-muted-foreground">{attTotal} total records</p>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Date</TableHead>
                    <TableHead className="whitespace-nowrap">Check In</TableHead>
                    <TableHead className="whitespace-nowrap">Check Out</TableHead>
                    <TableHead className="whitespace-nowrap">Worked</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attLoading ? (
                    Array.from({ length: 8 }).map((_, i) => (
                      <TableRow key={i}>{Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>
                    ))
                  ) : attendance.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground"><Clock className="h-8 w-8 mx-auto mb-2 opacity-40" />No attendance records</TableCell></TableRow>
                  ) : attendance.map(a => (
                    <TableRow key={a.id}>
                      <TableCell className="whitespace-nowrap font-medium text-sm">{fmtDate(a.attendance_date)}</TableCell>
                      <TableCell className="whitespace-nowrap font-mono text-sm">{fmtTime(a.check_in)}</TableCell>
                      <TableCell className="whitespace-nowrap font-mono text-sm">{fmtTime(a.check_out)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{calcWorkedHours(a)}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${STATUS_BADGE[a.status] ?? 'bg-muted text-muted-foreground'}`}>{a.status?.replace('_', ' ')}</span>
                      </TableCell>
                      <TableCell className="text-sm max-w-[140px] truncate text-muted-foreground">{a.notes ?? '—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
          {Math.ceil(attTotal / attPageSize) > 1 && (
            <div className="flex justify-end gap-2">
              <Button size="sm" variant="outline" disabled={attPage <= 1} onClick={() => setAttPage(p => p - 1)}>Prev</Button>
              <span className="text-sm self-center">{attPage} / {Math.ceil(attTotal / attPageSize)}</span>
              <Button size="sm" variant="outline" disabled={attPage >= Math.ceil(attTotal / attPageSize)} onClick={() => setAttPage(p => p + 1)}>Next</Button>
            </div>
          )}
        </TabsContent>

        {/* ── Payslips tab ── */}
        <TabsContent value="payslips" className="mt-4 space-y-4">
          <p className="text-sm text-muted-foreground">{payslips.length} payslip(s)</p>
          {payslipLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-lg bg-muted" />)}
            </div>
          ) : payslips.length === 0 ? (
            <div className="border border-border rounded-lg py-14 text-center text-muted-foreground">
              <Wallet className="h-10 w-10 mx-auto mb-2 opacity-40" />No payslips available
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {payslips.map((p, i) => {
                  const period = p.payroll_period as { name?: string; period_code?: string; payment_date?: string } | undefined;
                  return (
                    <button
                      key={i}
                      onClick={() => setSelectedPayslip(p)}
                      className="bg-card border border-border rounded-lg p-4 text-left hover:border-primary/40 hover:shadow-sm transition-all w-full"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="font-semibold text-sm">{period?.name ?? period?.period_code ?? `Period ${i + 1}`}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Payment: {period?.payment_date ? fmtDate(period.payment_date) : '—'}
                          </p>
                        </div>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${p.payment_status === 'paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                          {String(p.payment_status ?? 'pending')}
                        </span>
                      </div>
                      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                        {([['Gross', p.gross_pay], ['Deductions', p.total_deductions], ['Net Pay', p.net_pay]] as [string, unknown][]).map(([label, val]) => (
                          <div key={label as string}>
                            <p className="text-[10px] text-muted-foreground">{label}</p>
                            <p className="text-sm font-bold">{fmtCurrency(Number(val) || 0)}</p>
                          </div>
                        ))}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Payslip detail dialog */}
              <Dialog open={!!selectedPayslip} onOpenChange={o => { if (!o) setSelectedPayslip(null); }}>
                <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      Payslip — {(() => {
                        const period = selectedPayslip?.payroll_period as { name?: string } | undefined;
                        return period?.name ?? 'Details';
                      })()}
                    </DialogTitle>
                  </DialogHeader>
                  {selectedPayslip && (
                    <div className="space-y-4 mt-2">
                      <div className="grid grid-cols-2 gap-3">
                        {([
                          ['Basic Salary', selectedPayslip.basic_salary],
                          ['Overtime Pay', selectedPayslip.overtime_pay],
                          ['Allowances', selectedPayslip.allowances],
                          ['Gross Pay', selectedPayslip.gross_pay],
                        ] as [string, unknown][]).map(([label, val]) => (
                          <div key={label as string} className="bg-muted/40 rounded-lg p-3">
                            <p className="text-xs text-muted-foreground">{label}</p>
                            <p className="text-base font-bold">{fmtCurrency(Number(val) || 0)}</p>
                          </div>
                        ))}
                      </div>
                      <div className="border-t border-border pt-3 space-y-1.5 text-sm">
                        <p className="font-medium text-muted-foreground text-xs mb-2">Deductions</p>
                        {([
                          ['Income Tax', selectedPayslip.tax_deduction],
                          ['Social Security', selectedPayslip.social_security],
                          ['Provident Fund', selectedPayslip.provident_fund],
                          ['Other Deductions', selectedPayslip.other_deductions],
                          ['Total Deductions', selectedPayslip.total_deductions],
                        ] as [string, unknown][]).map(([label, val]) => (
                          <div key={label as string} className="flex justify-between">
                            <span className={`text-muted-foreground ${label === 'Total Deductions' ? 'font-semibold text-foreground' : ''}`}>{label}</span>
                            <span className={`font-medium ${label === 'Total Deductions' ? 'text-red-600' : ''}`}>{fmtCurrency(Number(val) || 0)}</span>
                          </div>
                        ))}
                      </div>
                      <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 flex justify-between items-center">
                        <span className="font-semibold text-foreground">Net Pay</span>
                        <span className="text-xl font-bold text-primary">{fmtCurrency(Number(selectedPayslip.net_pay) || 0)}</span>
                      </div>
                      {selectedPayslip.notes != null && (
                        <p className="text-xs text-muted-foreground border-t border-border pt-2">{String(selectedPayslip.notes)}</p>
                      )}
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        {String(selectedPayslip.payment_status ?? '') === 'paid'
                          ? <CheckCircle2 className="h-3.5 w-3.5 text-green-600" />
                          : <XCircle className="h-3.5 w-3.5 text-yellow-600" />}
                        Status: <span className="capitalize font-medium">{String(selectedPayslip.payment_status ?? 'pending')}</span>
                        {selectedPayslip.payment_date != null && <span>· Paid on {fmtDate(String(selectedPayslip.payment_date))}</span>}
                      </div>
                      {/* PDF + Email actions */}
                      <div className="pt-2 border-t border-border space-y-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full gap-2"
                          onClick={async () => {
                            const empName = employee
                              ? `${String(employee.first_name ?? '')} ${String(employee.last_name ?? '')}`.trim()
                              : 'Employee';
                            await exportPayslipPdf(selectedPayslip, empName, employee);
                          }}
                        >
                          <Download className="h-4 w-4" />
                          Download PDF
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full gap-2"
                          onClick={() => {
                            // Pre-fill with employee email if available
                            const empEmail = employee?.work_email
                              ? String(employee.work_email)
                              : employee?.personal_email
                                ? String(employee.personal_email)
                                : '';
                            setEmailTo(empEmail);
                            setEmailDialog(true);
                          }}
                        >
                          <Mail className="h-4 w-4" />
                          Send via Email
                        </Button>
                      </div>

                      {/* ── Email Send History ── */}
                      {(logsLoading || emailLogs.length > 0) && (
                        <div className="pt-2 border-t border-border space-y-1.5">
                          <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                            <Mail className="h-3 w-3" />Email History
                          </p>
                          {logsLoading ? (
                            <div className="space-y-1.5">
                              {[1,2].map(i => <div key={i} className="h-7 rounded bg-muted animate-pulse" />)}
                            </div>
                          ) : (
                            <div className="space-y-1 max-h-36 overflow-y-auto">
                              {emailLogs.map(log => (
                                <div key={log.id} className="flex items-center gap-2 text-xs py-1 px-2 rounded-md bg-muted/40">
                                  <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${log.status === 'success' ? 'bg-green-500' : 'bg-red-500'}`} />
                                  <span className="flex-1 min-w-0 truncate text-muted-foreground">{log.sent_to}</span>
                                  <span className="shrink-0 text-muted-foreground">{new Date(log.sent_at).toLocaleDateString()}</span>
                                  <span className={`shrink-0 font-medium ${log.status === 'success' ? 'text-green-600' : 'text-red-500'}`}>
                                    {log.status === 'success' ? '✓' : '✗'}
                                  </span>
                                  {log.status === 'failed' && (
                                    <button
                                      className="shrink-0 text-primary underline hover:no-underline disabled:opacity-50 disabled:cursor-not-allowed text-xs"
                                      disabled={resendingLogId === log.id}
                                      title={log.error_msg ?? 'Retry sending'}
                                      onClick={async () => {
                                        if (!selectedPayslip || resendingLogId) return;
                                        setResendingLogId(log.id);
                                        try {
                                          const empName = employee
                                            ? `${String(employee.first_name ?? '')} ${String(employee.last_name ?? '')}`.trim()
                                            : 'Employee';
                                          const { supabase } = await import('@/db/supabase');
                                          const period = selectedPayslip.payroll_period as { name?: string } | undefined;
                                          const result = await exportPayslipPdf(selectedPayslip, empName, employee);
                                          const { error } = await supabase.functions.invoke('send-payslip-email', {
                                            body: {
                                              to_email:          log.sent_to,
                                              employee_name:     empName,
                                              period_name:       period?.name ?? '',
                                              pdf_base64:        result.base64,
                                              net_pay:           Number(selectedPayslip.net_pay) || undefined,
                                              currency:          'ETB',
                                              payroll_record_id: String(selectedPayslip.id ?? ''),
                                              employee_id:       String(selectedPayslip.employee_id ?? ''),
                                            },
                                          });
                                          if (error) {
                                            const msg = await error?.context?.text?.();
                                            throw new Error(msg || error.message);
                                          }
                                          toast.success(`Payslip re-sent to ${log.sent_to}`);
                                          loadEmailLogs(String(selectedPayslip.id ?? ''));
                                        } catch (err) {
                                          toast.error(err instanceof Error ? err.message : 'Resend failed');
                                        } finally {
                                          setResendingLogId(null);
                                        }
                                      }}
                                    >
                                      {resendingLogId === log.id ? '…' : 'Resend'}
                                    </button>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </DialogContent>
              </Dialog>

              {/* ── Send Email Dialog ── */}
              <Dialog open={emailDialog} onOpenChange={o => { if (!o) { setEmailDialog(false); } }}>
                <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-primary" />
                      Email Payslip
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 mt-2">
                    <div className="space-y-1.5">
                      <Label>Recipient Email *</Label>
                      <Input
                        type="email"
                        value={emailTo}
                        onChange={e => setEmailTo(e.target.value)}
                        placeholder="employee@company.com"
                      />
                      <p className="text-xs text-muted-foreground">
                        The payslip PDF will be attached to this email.
                      </p>
                    </div>
                    {selectedPayslip && (
                      <div className="bg-muted/40 rounded-lg p-3 text-xs space-y-1">
                        <p><span className="text-muted-foreground">Period: </span>
                          <strong>{String((selectedPayslip.payroll_period as {name?:string}|undefined)?.name ?? '—')}</strong>
                        </p>
                        <p><span className="text-muted-foreground">Employee: </span>
                          <strong>{employee ? `${String(employee.first_name ?? '')} ${String(employee.last_name ?? '')}`.trim() : '—'}</strong>
                        </p>
                      </div>
                    )}
                    <div className="flex justify-end gap-2 pt-1">
                      <Button variant="outline" size="sm" onClick={() => setEmailDialog(false)}>Cancel</Button>
                      <Button
                        size="sm"
                        className="gap-2"
                        disabled={!emailTo || sendingEmail}
                        onClick={async () => {
                          if (!selectedPayslip || !emailTo) return;
                          setSendingEmail(true);
                          try {
                            const empName = employee
                              ? `${String(employee.first_name ?? '')} ${String(employee.last_name ?? '')}`.trim()
                              : 'Employee';
                            const result = await exportPayslipPdf(selectedPayslip, empName, employee);
                            const { supabase } = await import('@/db/supabase');
                            const period = selectedPayslip.payroll_period as { name?: string } | undefined;
                            const { error } = await supabase.functions.invoke('send-payslip-email', {
                              body: {
                                to_email:          emailTo,
                                employee_name:     empName,
                                period_name:       period?.name ?? '',
                                pdf_base64:        result.base64,
                                net_pay:           Number(selectedPayslip.net_pay) || undefined,
                                currency:          'ETB',
                                payroll_record_id: String(selectedPayslip.id ?? ''),
                                employee_id:       String(selectedPayslip.employee_id ?? ''),
                              },
                            });
                            if (error) {
                              const msg = await error?.context?.text?.();
                              throw new Error(msg || error.message);
                            }
                            toast.success(`Payslip emailed to ${emailTo}`);
                            setEmailDialog(false);
                            loadEmailLogs(String(selectedPayslip.id ?? ''));
                          } catch (err) {
                            toast.error(err instanceof Error ? err.message : 'Failed to send email');
                          } finally {
                            setSendingEmail(false);
                          }
                        }}
                      >
                        {sendingEmail
                          ? <><Loader2 className="h-4 w-4 animate-spin" />Sending…</>
                          : <><Mail className="h-4 w-4" />Send Email</>}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </>
          )}
        </TabsContent>

        {/* ── Policies tab ── */}
        <TabsContent value="policies" className="mt-4 space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">{policies.length} published policy(ies)</p>
            <Button variant="outline" size="sm" onClick={loadPolicies} disabled={policiesLoading}>
              <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${policiesLoading ? 'animate-spin' : ''}`} />Refresh
            </Button>
          </div>
          {policiesLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-lg bg-muted" />)}
            </div>
          ) : policies.length === 0 ? (
            <div className="border border-border rounded-lg py-14 text-center text-muted-foreground">
              <ShieldCheck className="h-10 w-10 mx-auto mb-2 opacity-40" />No policies to acknowledge at this time
            </div>
          ) : (
            <div className="space-y-3">
              {policies.map(pol => {
                const ack = policyAcks[pol.policy_id];
                const isAcked = !!ack;
                return (
                  <Card key={pol.policy_id} className={`border ${isAcked ? 'border-emerald-200 bg-emerald-50/30' : 'border-border'}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="font-semibold text-sm text-foreground">{pol.policy_title}</p>
                            {pol.policy_category && (
                              <Badge variant="outline" className="text-xs">{pol.policy_category}</Badge>
                            )}
                            {isAcked && (
                              <Badge className="text-xs bg-emerald-100 text-emerald-800 flex items-center gap-1">
                                <CheckCircle2 className="h-3 w-3" />Acknowledged
                              </Badge>
                            )}
                          </div>
                          {isAcked && ack.acknowledged_at && (
                            <p className="text-xs text-muted-foreground mt-1">
                              Acknowledged on {new Date(ack.acknowledged_at).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                        {!isAcked && (
                          <Button
                            size="sm"
                            className="shrink-0"
                            disabled={ackBusy === pol.policy_id}
                            onClick={() => handleAcknowledge(pol)}
                          >
                            {ackBusy === pol.policy_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5 mr-1.5" />}
                            Acknowledge
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* ── Announcements tab ── */}
        <TabsContent value="announcements" className="mt-4 space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">{announcements.length} active announcement(s)</p>
            <Button variant="outline" size="sm" onClick={loadAnnouncements} disabled={annLoading}>
              <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${annLoading ? 'animate-spin' : ''}`} />Refresh
            </Button>
          </div>
          {annLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-lg bg-muted" />)}
            </div>
          ) : announcements.length === 0 ? (
            <div className="border border-border rounded-lg py-14 text-center text-muted-foreground">
              <Megaphone className="h-10 w-10 mx-auto mb-2 opacity-40" />No announcements right now
            </div>
          ) : (
            <div className="space-y-3">
              {announcements.map(ann => {
                const PRIORITY_STYLES: Record<AnnouncementPriority, string> = {
                  LOW:    'border-l-slate-300',
                  NORMAL: 'border-l-blue-300',
                  HIGH:   'border-l-amber-400',
                  URGENT: 'border-l-red-500',
                };
                const TYPE_BADGE: Record<string, string> = {
                  INFORMATIVE: 'bg-blue-100 text-blue-800',
                  EMERGENCY:   'bg-red-100 text-red-800',
                  PERSONAL:    'bg-purple-100 text-purple-800',
                };
                const PRIORITY_BADGE: Record<string, string> = {
                  LOW: 'bg-slate-100 text-slate-600', NORMAL: 'bg-slate-100 text-slate-600',
                  HIGH: 'bg-amber-100 text-amber-800', URGENT: 'bg-red-100 text-red-800',
                };
                return (
                  <Card key={ann.id} className={`border-l-4 ${PRIORITY_STYLES[ann.priority]}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Megaphone className="h-4 w-4 shrink-0 mt-0.5 text-muted-foreground" />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap mb-1">
                            <p className="font-semibold text-sm text-balance">{ann.title}</p>
                            <Badge className={`text-xs ${TYPE_BADGE[ann.type] ?? ''}`}>{ann.type}</Badge>
                            {ann.priority !== 'NORMAL' && ann.priority !== 'LOW' && (
                              <Badge className={`text-xs ${PRIORITY_BADGE[ann.priority]}`}>{ann.priority}</Badge>
                            )}
                          </div>
                          {ann.description && (
                            <p className="text-sm text-muted-foreground text-pretty">{ann.description}</p>
                          )}
                          <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                            {ann.published_at && <span>Posted {new Date(ann.published_at).toLocaleDateString()}</span>}
                            {ann.expiry_date && <span>Expires {new Date(ann.expiry_date).toLocaleDateString()}</span>}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* ── DSAR tab ── */}
        <TabsContent value="dsar" className="mt-4 space-y-4">
          {/* Submit form */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <DatabaseZap className="h-4 w-4" />Submit a Data Request (DSAR)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Request Type</Label>
                  <select
                    className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
                    value={dsarForm.request_type}
                    onChange={e => setDsarForm(p => ({ ...p, request_type: e.target.value }))}
                  >
                    <option value="ACCESS">Access — Request a copy of my data</option>
                    <option value="RECTIFICATION">Rectification — Correct inaccurate data</option>
                    <option value="DELETION">Deletion — Erase my personal data</option>
                    <option value="PORTABILITY">Portability — Export my data</option>
                  </select>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Description <span className="text-destructive">*</span></Label>
                <textarea
                  className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring min-h-[80px] resize-none"
                  placeholder="Please describe your request in detail…"
                  value={dsarForm.description}
                  onChange={e => setDsarForm(p => ({ ...p, description: e.target.value }))}
                />
              </div>
              <Button onClick={handleSubmitDsar} disabled={dsarSaving || !dsarForm.description.trim()}>
                {dsarSaving ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Submitting…</> : <>Submit Request</>}
              </Button>
              <p className="text-xs text-muted-foreground">
                Your request will be processed within 30 days. You will be notified via email once completed.
              </p>
            </CardContent>
          </Card>

          {/* Submission history */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">My Requests</CardTitle>
                <Button variant="outline" size="sm" onClick={loadDsar} disabled={dsarLoading}>
                  <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${dsarLoading ? 'animate-spin' : ''}`} />Refresh
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {dsarLoading ? (
                <div className="p-4 space-y-2">
                  {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-10 w-full bg-muted" />)}
                </div>
              ) : dsarRequests.length === 0 ? (
                <div className="py-10 text-center text-muted-foreground">
                  <DatabaseZap className="h-8 w-8 mx-auto mb-2 opacity-30" />No requests submitted yet
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="whitespace-nowrap">Type</TableHead>
                        <TableHead className="whitespace-nowrap">Status</TableHead>
                        <TableHead className="whitespace-nowrap">Date</TableHead>
                        <TableHead className="whitespace-nowrap">Deadline</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {dsarRequests.map(r => {
                        const STATUS_COLOR: Record<string, string> = {
                          SUBMITTED:   'bg-blue-100 text-blue-800',
                          IN_PROGRESS: 'bg-amber-100 text-amber-800',
                          COMPLETED:   'bg-emerald-100 text-emerald-800',
                          OVERDUE:     'bg-red-100 text-red-800',
                        };
                        return (
                          <TableRow key={r.dsar_id}>
                            <TableCell className="whitespace-nowrap font-medium text-sm">{r.request_type}</TableCell>
                            <TableCell className="whitespace-nowrap">
                              <Badge className={`text-xs ${STATUS_COLOR[r.request_status] ?? ''}`}>{r.request_status}</Badge>
                            </TableCell>
                            <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                              {r.request_date ? new Date(r.request_date).toLocaleDateString() : '—'}
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground max-w-[240px] truncate">
                              {r.deadline_date ? new Date(r.deadline_date).toLocaleDateString() : '—'}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── FR-ESS-009: Performance Review View ─────────────────────── */}
        <TabsContent value="performance" className="mt-4">
          <EssPerformanceTab employeeId={employee?.id as string | undefined} />
        </TabsContent>

        {/* ── FR-ESS-010: Transfer & Promotion Status View ────────────── */}
        <TabsContent value="transfers" className="mt-4">
          <EssTransfersTab employeeId={employee?.id as string | undefined} />
        </TabsContent>

        {/* ── FR-ESS-011: Loan Application / FR-ESS-016/017/018 ────────── */}
        <TabsContent value="loans" className="mt-4">
          <EssLoansTab employeeId={employee?.id as string | undefined} />
        </TabsContent>

        {/* ── FR-ESS-012: Benefit Enrollment ──────────────────────────── */}
        <TabsContent value="benefits-enroll" className="mt-4">
          <EssBenefitsTab employeeId={employee?.id as string | undefined} />
        </TabsContent>

        {/* ── FR-ESS-013/016/017/018: Expense / Reimbursement ─────────── */}
        <TabsContent value="expense" className="mt-4">
          <EssExpenseTab employeeId={employee?.id as string | undefined} />
        </TabsContent>

        {/* ── FR-ESS-021: HR Request Ticket Submission ────────────────── */}
        <TabsContent value="tickets" className="mt-4">
          <EssTicketsTab employeeId={employee?.id as string | undefined} />
        </TabsContent>

      </Tabs>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-ESS-009: Performance Review View
   ═══════════════════════════════════════════════════════════════════════════ */
function EssPerformanceTab({ employeeId }: { employeeId?: string }) {
  const [reviews, setReviews] = useState<Record<string,unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const sb = (window as unknown as Record<string, unknown>).__supabase__ as typeof import('@/db/supabase').supabase;

  useEffect(() => {
    if (!employeeId) return;
    setLoading(true);
    import('@/db/supabase').then(({ supabase }) => {
      (supabase as unknown as Record<string, (t: string) => unknown>).from('performance_reviews')
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      ; void sb;
      (supabase as any).from('performance_reviews')
        .select('id, review_period, review_type, status, overall_rating, reviewer_comments, created_at, updated_at')
        .eq('employee_id', employeeId)
        .order('created_at', { ascending: false })
        .limit(20)
        .then(({ data }: { data: unknown }) => { setReviews((data as Record<string,unknown>[]) || []); setLoading(false); });
    });
  }, [employeeId, sb]);

  const STATUS_COLOR: Record<string,string> = {
    pending:'bg-yellow-100 text-yellow-800', self_assessment:'bg-blue-100 text-blue-800',
    manager_review:'bg-purple-100 text-purple-800', completed:'bg-emerald-100 text-emerald-800',
    acknowledged:'bg-teal-100 text-teal-800',
  };

  return (
    <Card>
      <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><Star className="h-4 w-4" />My Performance Reviews</CardTitle></CardHeader>
      <CardContent>
        {loading ? <div className="space-y-2">{Array.from({length:3}).map((_,i)=><Skeleton key={i} className="h-12 bg-muted"/>)}</div>
        : reviews.length === 0 ? (
          <div className="py-10 text-center text-muted-foreground"><Star className="h-8 w-8 mx-auto mb-2 opacity-30"/>No performance reviews found</div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Period</TableHead>
                <TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Rating</TableHead>
                <TableHead className="whitespace-nowrap">Comments</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {reviews.map(r=>(
                  <TableRow key={r.id as string}>
                    <TableCell className="whitespace-nowrap text-sm font-medium">{r.review_period as string||'—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.review_type as string||'—'}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${STATUS_COLOR[r.status as string]||''}`}>{r.status as string}</Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.overall_rating!=null?String(r.overall_rating):'—'}</TableCell>
                    <TableCell className="text-sm text-muted-foreground max-w-[200px] truncate">{r.reviewer_comments as string||'—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-ESS-010: Transfer & Promotion Status View
   ═══════════════════════════════════════════════════════════════════════════ */
function EssTransfersTab({ employeeId }: { employeeId?: string }) {
  const [transfers, setTransfers]   = useState<Record<string,unknown>[]>([]);
  const [promotions, setPromotions] = useState<Record<string,unknown>[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!employeeId) return;
    setLoading(true);
    import('@/db/supabase').then(({ supabase }) => {
      const sb2 = supabase as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      Promise.all([
        sb2.from('transfer_requests').select('id,transfer_type,status,from_department_id,to_department_id,effective_date,reason,created_at').eq('employee_id', employeeId).order('created_at',{ascending:false}).limit(10),
        sb2.from('promotion_requests').select('id,status,current_grade,proposed_grade,effective_date,justification,created_at').eq('employee_id', employeeId).order('created_at',{ascending:false}).limit(10),
      ]).then(([t,p]: [{data:unknown},{data:unknown}]) => {
        setTransfers((t.data as Record<string,unknown>[])||[]);
        setPromotions((p.data as Record<string,unknown>[])||[]);
        setLoading(false);
      });
    });
  }, [employeeId]);

  const STATUS_CLR: Record<string,string> = {
    DRAFT:'bg-slate-100 text-slate-700', SUBMITTED:'bg-blue-100 text-blue-800',
    APPROVED:'bg-emerald-100 text-emerald-800', REJECTED:'bg-red-100 text-red-800',
    EXECUTED:'bg-teal-100 text-teal-800',
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><TrendingUp className="h-4 w-4"/>Transfer Requests</CardTitle></CardHeader>
        <CardContent>
          {loading ? <Skeleton className="h-20 bg-muted"/> : transfers.length===0 ? (
            <p className="text-sm text-muted-foreground py-6 text-center">No transfer requests</p>
          ):(
            <div className="overflow-x-auto"><Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Effective Date</TableHead>
                <TableHead className="whitespace-nowrap">Reason</TableHead>
              </TableRow></TableHeader>
              <TableBody>{transfers.map(t=>(
                <TableRow key={t.id as string}>
                  <TableCell className="text-sm">{t.transfer_type as string||'—'}</TableCell>
                  <TableCell><Badge className={`text-xs ${STATUS_CLR[t.status as string]||''}`}>{t.status as string}</Badge></TableCell>
                  <TableCell className="whitespace-nowrap text-sm">{t.effective_date?new Date(t.effective_date as string).toLocaleDateString():'—'}</TableCell>
                  <TableCell className="text-sm text-muted-foreground max-w-[180px] truncate">{t.reason as string||'—'}</TableCell>
                </TableRow>
              ))}</TableBody>
            </Table></div>
          )}
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><TrendingUp className="h-4 w-4"/>Promotion Requests</CardTitle></CardHeader>
        <CardContent>
          {loading ? <Skeleton className="h-20 bg-muted"/> : promotions.length===0 ? (
            <p className="text-sm text-muted-foreground py-6 text-center">No promotion requests</p>
          ):(
            <div className="overflow-x-auto"><Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">From Grade</TableHead>
                <TableHead className="whitespace-nowrap">To Grade</TableHead>
                <TableHead className="whitespace-nowrap">Effective</TableHead>
              </TableRow></TableHeader>
              <TableBody>{promotions.map(p=>(
                <TableRow key={p.id as string}>
                  <TableCell><Badge className={`text-xs ${STATUS_CLR[p.status as string]||''}`}>{p.status as string}</Badge></TableCell>
                  <TableCell className="text-sm">{p.current_grade as string||'—'}</TableCell>
                  <TableCell className="text-sm">{p.proposed_grade as string||'—'}</TableCell>
                  <TableCell className="whitespace-nowrap text-sm">{p.effective_date?new Date(p.effective_date as string).toLocaleDateString():'—'}</TableCell>
                </TableRow>
              ))}</TableBody>
            </Table></div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-ESS-011 / FR-ESS-016 / FR-ESS-017 / FR-ESS-018: Loans & Reimbursements
   ═══════════════════════════════════════════════════════════════════════════ */
function EssLoansTab({ employeeId }: { employeeId?: string }) {
  const [loans, setLoans]     = useState<Record<string,unknown>[]>([]);
  const [policies, setPolicies] = useState<Record<string,unknown>[]>([]);
  const [open, setOpen]       = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm]       = useState({ loan_policy_id:'', requested_amount:'', loan_duration_months:'', purpose:'' });

  useEffect(()=>{
    if (!employeeId) return;
    setLoading(true);
    import('@/db/supabase').then(({supabase})=>{
      const sb2 = supabase as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      Promise.all([
        sb2.from('loan_requests').select('id,loan_type,requested_amount,status,created_at,loan_policy_id,loan_policies(policy_name)').eq('employee_id',employeeId).order('created_at',{ascending:false}).limit(20),
        sb2.from('loan_policies').select('id,policy_name,loan_type,max_amount').eq('is_active',true).limit(20),
      ]).then(([l,p]:[{data:unknown},{data:unknown}])=>{
        setLoans((l.data as Record<string,unknown>[])||[]);
        setPolicies((p.data as Record<string,unknown>[])||[]);
        setLoading(false);
      });
    });
  },[employeeId]);

  const submit = async () => {
    if (!employeeId||!form.loan_policy_id||!form.requested_amount) { toast.error('Fill required fields'); return; }
    setSubmitting(true);
    try {
      const {supabase} = await import('@/db/supabase');
      const sb2 = supabase as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      const { error } = await sb2.from('loan_requests').insert({
        employee_id: employeeId, loan_policy_id: form.loan_policy_id,
        requested_amount: Number(form.requested_amount),
        loan_duration_months: form.loan_duration_months ? Number(form.loan_duration_months) : null,
        purpose: form.purpose || null, status: 'SUBMITTED',
        loan_type: policies.find(p=>p.id===form.loan_policy_id)?.loan_type as string||'LOAN',
        application_date: new Date().toISOString().slice(0,10),
      });
      if (error) throw error;
      toast.success('Loan application submitted');
      setOpen(false); setForm({loan_policy_id:'',requested_amount:'',loan_duration_months:'',purpose:''});
      setLoans(prev=>[{id:Date.now().toString(),status:'SUBMITTED',requested_amount:Number(form.requested_amount),created_at:new Date().toISOString()},...prev]);
    } catch(e) { toast.error(e instanceof Error?e.message:'Submit failed'); }
    finally { setSubmitting(false); }
  };

  const STATUS_CLR: Record<string,string> = {
    DRAFT:'bg-slate-100 text-slate-700', SUBMITTED:'bg-blue-100 text-blue-800',
    APPROVED:'bg-emerald-100 text-emerald-800', REJECTED:'bg-red-100 text-red-800',
    DISBURSED:'bg-teal-100 text-teal-800', REPAYING:'bg-purple-100 text-purple-800',
    SETTLED:'bg-gray-100 text-gray-700',
  };

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-base flex items-center gap-2"><Banknote className="h-4 w-4"/>Loan Applications (FR-ESS-011)</CardTitle>
        <Button size="sm" className="h-8" onClick={()=>setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1"/>Apply</Button>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-20 bg-muted"/>
        : loans.length===0 ? <div className="py-8 text-center text-muted-foreground"><Banknote className="h-8 w-8 mx-auto mb-2 opacity-30"/>No loan applications</div>
        :(
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow>
              <TableHead className="whitespace-nowrap">Type</TableHead>
              <TableHead className="whitespace-nowrap">Amount</TableHead>
              <TableHead className="whitespace-nowrap">Status</TableHead>
              <TableHead className="whitespace-nowrap">Date</TableHead>
            </TableRow></TableHeader>
            <TableBody>{loans.map(l=>(
              <TableRow key={l.id as string}>
                <TableCell className="text-sm">{((l.loan_policies as Record<string,unknown>)?.policy_name as string)||l.loan_type as string||'—'}</TableCell>
                <TableCell className="text-sm font-medium">${Number(l.requested_amount||0).toLocaleString()}</TableCell>
                <TableCell><Badge className={`text-xs ${STATUS_CLR[l.status as string]||''}`}>{l.status as string}</Badge></TableCell>
                <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{l.created_at?new Date(l.created_at as string).toLocaleDateString():'—'}</TableCell>
              </TableRow>
            ))}</TableBody>
          </Table></div>
        )}
      </CardContent>

      {/* Apply dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Loan Application</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-sm font-normal">Loan Policy *</Label>
              <Select value={form.loan_policy_id} onValueChange={v=>setForm(p=>({...p,loan_policy_id:v}))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select policy"/></SelectTrigger>
                <SelectContent>{policies.map(p=><SelectItem key={p.id as string} value={p.id as string}>{p.policy_name as string}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-normal">Amount Requested *</Label>
              <Input type="number" min="0" placeholder="e.g. 5000" className="mt-1" value={form.requested_amount} onChange={e=>setForm(p=>({...p,requested_amount:e.target.value}))} />
            </div>
            <div>
              <Label className="text-sm font-normal">Duration (months)</Label>
              <Input type="number" min="1" placeholder="e.g. 12" className="mt-1" value={form.loan_duration_months} onChange={e=>setForm(p=>({...p,loan_duration_months:e.target.value}))} />
            </div>
            <div>
              <Label className="text-sm font-normal">Purpose</Label>
              <Textarea className="mt-1" rows={2} placeholder="Reason for the loan…" value={form.purpose} onChange={e=>setForm(p=>({...p,purpose:e.target.value}))}/>
            </div>
            <Button className="w-full" onClick={submit} disabled={submitting}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin"/>}Submit Application
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-ESS-012: Benefit Enrollment
   ═══════════════════════════════════════════════════════════════════════════ */
function EssBenefitsTab({ employeeId }: { employeeId?: string }) {
  const [plans, setPlans]       = useState<Record<string,unknown>[]>([]);
  const [enrolled, setEnrolled] = useState<Record<string,unknown>[]>([]);
  const [loading, setLoading]   = useState(false);
  const [enrolling, setEnrolling] = useState<string>('');

  useEffect(()=>{
    if (!employeeId) return;
    setLoading(true);
    import('@/db/supabase').then(({supabase})=>{
      const sb2 = supabase as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      Promise.all([
        sb2.from('benefit_plans').select('benefit_plan_id,plan_name,plan_type,employee_contribution,employer_contribution,is_active').eq('is_active',true).limit(20),
        sb2.from('benefit_enrollments').select('benefit_enrollment_id,benefit_plan_id,enrollment_status,effective_date,benefit_plans(plan_name,plan_type)').eq('employee_id',employeeId).limit(20),
      ]).then(([pl,en]:[{data:unknown},{data:unknown}])=>{
        setPlans((pl.data as Record<string,unknown>[])||[]);
        setEnrolled((en.data as Record<string,unknown>[])||[]);
        setLoading(false);
      });
    });
  },[employeeId]);

  const enroll = async (planId: string) => {
    if (!employeeId) return;
    setEnrolling(planId);
    try {
      const {supabase} = await import('@/db/supabase');
      const sb2 = supabase as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      const { error } = await sb2.from('benefit_enrollments').insert({
        employee_id: employeeId, benefit_plan_id: planId,
        enrollment_status: 'PENDING', effective_date: new Date().toISOString().slice(0,10),
        life_event_type: 'NEW_HIRE',
      });
      if (error) throw error;
      toast.success('Enrollment submitted');
      setEnrolled(prev=>[...prev,{benefit_enrollment_id:Date.now().toString(),benefit_plan_id:planId,enrollment_status:'PENDING'}]);
    } catch(e){ toast.error(e instanceof Error?e.message:'Failed'); }
    finally { setEnrolling(''); }
  };

  const enrolledIds = new Set(enrolled.map(e=>e.benefit_plan_id as string));

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><HandCoins className="h-4 w-4"/>Available Benefit Plans</CardTitle></CardHeader>
        <CardContent>
          {loading ? <Skeleton className="h-28 bg-muted"/> : plans.length===0 ? (
            <p className="text-sm text-muted-foreground py-6 text-center">No active benefit plans</p>
          ):(
            <div className="space-y-2">
              {plans.map(p=>(
                <div key={p.benefit_plan_id as string} className="flex items-center justify-between border rounded-lg px-3 py-2">
                  <div>
                    <p className="text-sm font-medium">{p.plan_name as string}</p>
                    <p className="text-xs text-muted-foreground">{p.plan_type as string} · Employee: ${Number(p.employee_contribution||0).toLocaleString()} · Employer: ${Number(p.employer_contribution||0).toLocaleString()}</p>
                  </div>
                  {enrolledIds.has(p.benefit_plan_id as string) ? (
                    <Badge className="text-xs bg-emerald-100 text-emerald-800">Enrolled</Badge>
                  ) : (
                    <Button size="sm" variant="outline" className="h-7 text-xs" disabled={!!enrolling} onClick={()=>enroll(p.benefit_plan_id as string)}>
                      {enrolling===p.benefit_plan_id?<Loader2 className="h-3 w-3 animate-spin"/>:'Enroll'}
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      {enrolled.length>0&&(
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">My Enrollments</CardTitle></CardHeader>
          <CardContent>
            <div className="overflow-x-auto"><Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Plan</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Effective</TableHead>
              </TableRow></TableHeader>
              <TableBody>{enrolled.map(e=>(
                <TableRow key={e.benefit_enrollment_id as string}>
                  <TableCell className="text-sm">{((e.benefit_plans as Record<string,unknown>)?.plan_name as string)||'—'}</TableCell>
                  <TableCell><Badge className="text-xs">{e.enrollment_status as string}</Badge></TableCell>
                  <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{e.effective_date?new Date(e.effective_date as string).toLocaleDateString():'—'}</TableCell>
                </TableRow>
              ))}</TableBody>
            </Table></div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-ESS-013/016/017/018: Expense Claim Submission + Tracking
   ═══════════════════════════════════════════════════════════════════════════ */
function EssExpenseTab({ employeeId }: { employeeId?: string }) {
  const [claims, setClaims]   = useState<Record<string,unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen]       = useState(false);
  const [submitting, setSub]  = useState(false);
  const [form, setForm]       = useState({ category:'', amount:'', description:'', claim_date:new Date().toISOString().slice(0,10) });

  useEffect(()=>{
    if (!employeeId) return;
    setLoading(true);
    import('@/db/supabase').then(({supabase})=>{
      const sb2 = supabase as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      sb2.from('expense_claims').select('id,claim_number,category,amount,status,claim_date,description,created_at').eq('employee_id',employeeId).order('created_at',{ascending:false}).limit(20)
        .then(({data}:{data:unknown})=>{ setClaims((data as Record<string,unknown>[])||[]); setLoading(false); });
    });
  },[employeeId]);

  const submit = async()=>{
    if (!employeeId||!form.category||!form.amount){toast.error('Fill required fields');return;}
    setSub(true);
    try{
      const {supabase}=await import('@/db/supabase');
      const sb2=supabase as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      const ref=`EXP-${Date.now().toString().slice(-6)}`;
      const {error}=await sb2.from('expense_claims').insert({
        employee_id:employeeId, claim_number:ref, category:form.category,
        amount:Number(form.amount), description:form.description||null,
        claim_date:form.claim_date, status:'pending',
      });
      if(error) throw error;
      toast.success(`Expense claim ${ref} submitted`);
      setOpen(false); setForm({category:'',amount:'',description:'',claim_date:new Date().toISOString().slice(0,10)});
      setClaims(prev=>[{id:Date.now().toString(),claim_number:ref,status:'pending',amount:Number(form.amount),category:form.category,claim_date:form.claim_date,created_at:new Date().toISOString()},...prev]);
    }catch(e){toast.error(e instanceof Error?e.message:'Submit failed');}
    finally{setSub(false);}
  };

  const STATUS_CLR:Record<string,string>={pending:'bg-yellow-100 text-yellow-800',approved:'bg-emerald-100 text-emerald-800',rejected:'bg-red-100 text-red-800',paid:'bg-blue-100 text-blue-800'};
  const CATEGORIES=['TRANSPORT','MEALS','ACCOMMODATION','OFFICE_SUPPLIES','TRAINING','MEDICAL','ENTERTAINMENT','OTHER'];

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-base flex items-center gap-2"><Receipt className="h-4 w-4"/>Expense Claims (FR-ESS-013/016)</CardTitle>
        <Button size="sm" className="h-8" onClick={()=>setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1"/>New Claim</Button>
      </CardHeader>
      <CardContent>
        {loading?<Skeleton className="h-20 bg-muted"/>:claims.length===0?(
          <div className="py-8 text-center text-muted-foreground"><Receipt className="h-8 w-8 mx-auto mb-2 opacity-30"/>No expense claims</div>
        ):(
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow>
              <TableHead className="whitespace-nowrap">Ref#</TableHead>
              <TableHead className="whitespace-nowrap">Category</TableHead>
              <TableHead className="whitespace-nowrap">Amount</TableHead>
              <TableHead className="whitespace-nowrap">Status</TableHead>
              <TableHead className="whitespace-nowrap">Date</TableHead>
            </TableRow></TableHeader>
            <TableBody>{claims.map(c=>(
              <TableRow key={c.id as string}>
                <TableCell className="text-sm font-medium">{c.claim_number as string||'—'}</TableCell>
                <TableCell className="text-sm">{c.category as string||'—'}</TableCell>
                <TableCell className="text-sm font-medium">${Number(c.amount||0).toLocaleString()}</TableCell>
                <TableCell><Badge className={`text-xs ${STATUS_CLR[c.status as string]||''}`}>{c.status as string}</Badge></TableCell>
                <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{c.claim_date?new Date(c.claim_date as string).toLocaleDateString():'—'}</TableCell>
              </TableRow>
            ))}</TableBody>
          </Table></div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Expense Claim</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-sm font-normal">Category *</Label>
              <Select value={form.category} onValueChange={v=>setForm(p=>({...p,category:v}))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select category"/></SelectTrigger>
                <SelectContent>{CATEGORIES.map(c=><SelectItem key={c} value={c}>{c.replace('_',' ')}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-normal">Amount *</Label>
              <Input type="number" min="0" step="0.01" placeholder="0.00" className="mt-1" value={form.amount} onChange={e=>setForm(p=>({...p,amount:e.target.value}))}/>
            </div>
            <div>
              <Label className="text-sm font-normal">Claim Date *</Label>
              <Input type="date" className="mt-1" value={form.claim_date} onChange={e=>setForm(p=>({...p,claim_date:e.target.value}))}/>
            </div>
            <div>
              <Label className="text-sm font-normal">Description</Label>
              <Textarea className="mt-1" rows={2} placeholder="Describe the expense…" value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))}/>
            </div>
            <Button className="w-full" onClick={submit} disabled={submitting}>
              {submitting&&<Loader2 className="h-4 w-4 mr-2 animate-spin"/>}Submit Claim
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-ESS-021: HR Request Ticket Submission
   ═══════════════════════════════════════════════════════════════════════════ */
function EssTicketsTab({ employeeId }: { employeeId?: string }) {
  const [tickets, setTickets] = useState<Record<string,unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen]       = useState(false);
  const [submitting, setSub]  = useState(false);
  const [form, setForm]       = useState({ category:'', subject:'', description:'' });

  useEffect(()=>{
    if (!employeeId) return;
    setLoading(true);
    import('@/db/supabase').then(({supabase})=>{
      const sb2=supabase as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      sb2.from('hr_request_tickets').select('id,ticket_number,category,subject,status,created_at,updated_at').eq('employee_id',employeeId).order('created_at',{ascending:false}).limit(20)
        .then(({data}:{data:unknown})=>{ setTickets((data as Record<string,unknown>[])||[]); setLoading(false); });
    });
  },[employeeId]);

  const submit=async()=>{
    if(!employeeId||!form.category||!form.subject||!form.description){toast.error('Fill all required fields');return;}
    setSub(true);
    try{
      const {supabase}=await import('@/db/supabase');
      const sb2=supabase as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      const ref=`TKT-${Date.now().toString().slice(-6)}`;
      const {error}=await sb2.from('hr_request_tickets').insert({
        employee_id:employeeId, ticket_number:ref,
        category:form.category, subject:form.subject, description:form.description, status:'OPEN',
      });
      if(error) throw error;
      toast.success(`Ticket ${ref} submitted to HR`);
      setOpen(false); setForm({category:'',subject:'',description:''});
      setTickets(prev=>[{id:Date.now().toString(),ticket_number:ref,status:'OPEN',category:form.category,subject:form.subject,created_at:new Date().toISOString()},...prev]);
    }catch(e){toast.error(e instanceof Error?e.message:'Submit failed');}
    finally{setSub(false);}
  };

  const STATUS_CLR:Record<string,string>={OPEN:'bg-blue-100 text-blue-800',IN_PROGRESS:'bg-yellow-100 text-yellow-800',RESOLVED:'bg-emerald-100 text-emerald-800',CLOSED:'bg-gray-100 text-gray-700'};
  const CATS=['DOCUMENT_REQUEST','PAYROLL_QUERY','LEAVE_QUERY','ATTENDANCE_CORRECTION','POLICY_INQUIRY','SYSTEM_ACCESS','GENERAL'];

  return(
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-base flex items-center gap-2"><TicketCheck className="h-4 w-4"/>HR Request Tickets (FR-ESS-021)</CardTitle>
        <Button size="sm" className="h-8" onClick={()=>setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1"/>New Ticket</Button>
      </CardHeader>
      <CardContent>
        {loading?<Skeleton className="h-20 bg-muted"/>:tickets.length===0?(
          <div className="py-8 text-center text-muted-foreground"><TicketCheck className="h-8 w-8 mx-auto mb-2 opacity-30"/>No HR tickets submitted yet</div>
        ):(
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow>
              <TableHead className="whitespace-nowrap">Ticket#</TableHead>
              <TableHead className="whitespace-nowrap">Category</TableHead>
              <TableHead className="whitespace-nowrap">Subject</TableHead>
              <TableHead className="whitespace-nowrap">Status</TableHead>
              <TableHead className="whitespace-nowrap">Date</TableHead>
            </TableRow></TableHeader>
            <TableBody>{tickets.map(t=>(
              <TableRow key={t.id as string}>
                <TableCell className="text-sm font-medium">{t.ticket_number as string||'—'}</TableCell>
                <TableCell className="text-sm">{(t.category as string||'').replace('_',' ')}</TableCell>
                <TableCell className="text-sm max-w-[160px] truncate">{t.subject as string||'—'}</TableCell>
                <TableCell><Badge className={`text-xs ${STATUS_CLR[t.status as string]||''}`}>{t.status as string}</Badge></TableCell>
                <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{t.created_at?new Date(t.created_at as string).toLocaleDateString():'—'}</TableCell>
              </TableRow>
            ))}</TableBody>
          </Table></div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New HR Request Ticket</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-sm font-normal">Category *</Label>
              <Select value={form.category} onValueChange={v=>setForm(p=>({...p,category:v}))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select category"/></SelectTrigger>
                <SelectContent>{CATS.map(c=><SelectItem key={c} value={c}>{c.replace(/_/g,' ')}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-normal">Subject *</Label>
              <Input className="mt-1" placeholder="Brief subject…" value={form.subject} onChange={e=>setForm(p=>({...p,subject:e.target.value}))}/>
            </div>
            <div>
              <Label className="text-sm font-normal">Description *</Label>
              <Textarea className="mt-1" rows={3} placeholder="Describe your request in detail…" value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))}/>
            </div>
            <Button className="w-full" onClick={submit} disabled={submitting}>
              {submitting&&<Loader2 className="h-4 w-4 mr-2 animate-spin"/>}Submit Ticket
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
