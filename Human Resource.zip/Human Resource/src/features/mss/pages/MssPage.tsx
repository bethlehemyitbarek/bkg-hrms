import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { employeeService } from '@/services/employee.service';
import { leaveService, attendanceService } from '@/services/attendance.service';
import { timesheetService } from '@/services/modules.service';
import { notificationEngine } from '@/services/notification-engine.service';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { RefreshCw, Users, Calendar, CheckCheck, Clock, CheckCircle2, XCircle, ClipboardList, Eye, Star, Banknote, BarChart3 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';

const sb = _sb as any; // eslint-disable-line @typescript-eslint/no-explicit-any

type OTRequest = {
  id: string;
  employee_id: string;
  requested_date: string;
  start_time?: string;
  end_time?: string;
  hours: number;
  reason?: string;
  status: string;
  notes?: string;
  employee?: { first_name: string; last_name: string; employee_no?: string };
};

const OT_STATUS_COLORS: Record<string, string> = {
  pending:  'bg-yellow-100 text-yellow-800',
  approved: 'bg-green-100 text-green-800',
  rejected: 'bg-red-100 text-red-800',
};

export function MssPage() {
  const [employees, setEmployees] = useState<Record<string, unknown>[]>([]);
  const [pendingLeaves, setPendingLeaves] = useState<Record<string, unknown>[]>([]);
  const [teamAttendance, setTeamAttendance] = useState<Record<string, unknown>[]>([]);
  const [otRequests, setOtRequests] = useState<OTRequest[]>([]);
  const [otFilter, setOtFilter] = useState<'pending' | 'approved' | 'rejected' | 'all'>('pending');
  const [loading, setLoading] = useState(true);
  const [otLoading, setOtLoading] = useState(false);
  const [selectedOtIds, setSelectedOtIds] = useState<Set<string>>(new Set());
  const [bulkBusy, setBulkBusy] = useState(false);
  const [empSearch, setEmpSearch] = useState('');

  // Review dialog (OT)
  const [reviewOt, setReviewOt] = useState<OTRequest | null>(null);
  const [reviewAction, setReviewAction] = useState<'approve' | 'reject' | null>(null);
  const [reviewNotes, setReviewNotes] = useState('');
  const [reviewBusy, setReviewBusy] = useState(false);

  // ── Timesheet Approval State ──────────────────────────────────────────────
  type TimesheetRow = Record<string, unknown> & {
    id: string;
    employee_id: string;
    period_start: string;
    period_end: string;
    status: string;
    total_hours: number;
    overtime_hours: number;
    rejection_reason?: string;
    employee?: { first_name: string; last_name: string; employee_no?: string };
  };

  const [timesheets, setTimesheets] = useState<TimesheetRow[]>([]);
  const [tsTotal, setTsTotal] = useState(0);
  const [tsLoading, setTsLoading] = useState(false);
  const [tsStatusFilter, setTsStatusFilter] = useState('submitted');
  const [tsPage, setTsPage] = useState(1);
  const TS_PAGE_SIZE = 15;

  // Timesheet detail dialog
  const [tsDetail, setTsDetail] = useState<TimesheetRow | null>(null);
  const [tsEntries, setTsEntries] = useState<Record<string, unknown>[]>([]);
  const [tsDetailOpen, setTsDetailOpen] = useState(false);
  const [tsAction, setTsAction] = useState<'approve' | 'reject' | null>(null);
  const [tsRejReason, setTsRejReason] = useState('');
  const [tsActBusy, setTsActBusy] = useState(false);

  const loadOT = useCallback(async () => {
    setOtLoading(true);
    try {
      let q = sb.from('overtime_requests')
        .select('*, employee:employees!overtime_requests_employee_id_fkey(first_name,last_name,employee_no)')
        .order('requested_date', { ascending: false })
        .limit(50);
      if (otFilter !== 'all') q = q.eq('status', otFilter);
      const { data, error } = await q;
      if (error) throw error;
      setOtRequests(Array.isArray(data) ? data : []);
      setSelectedOtIds(new Set());
    } catch { toast.error('Failed to load OT requests'); }
    finally { setOtLoading(false); }
  }, [otFilter]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [empRes, leaveRes, attRes] = await Promise.all([
        employeeService.list({ search: empSearch || undefined, page: 1, pageSize: 20 }),
        leaveService.listRequests({ status: 'pending', page: 1, pageSize: 20 }),
        attendanceService.list({ start_date: new Date().toISOString().split('T')[0], page: 1, pageSize: 30 }),
      ]);
      setEmployees(empRes.data as unknown as Record<string, unknown>[]);
      setPendingLeaves(leaveRes.data as unknown as Record<string, unknown>[]);
      setTeamAttendance(attRes.data as unknown as Record<string, unknown>[]);
    } catch { toast.error('Failed to load MSS data'); }
    finally { setLoading(false); }
  }, [empSearch]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { loadOT(); }, [loadOT]);

  // ── Timesheet load ────────────────────────────────────────────────────────
  const loadTimesheets = useCallback(async () => {
    setTsLoading(true);
    try {
      const res = await timesheetService.listForApproval({
        status: tsStatusFilter !== 'all' ? tsStatusFilter : undefined,
        page: tsPage,
        pageSize: TS_PAGE_SIZE,
      });
      setTimesheets(res.data as TimesheetRow[]);
      setTsTotal(res.total);
    } catch { toast.error('Failed to load timesheets'); }
    finally { setTsLoading(false); }
  }, [tsStatusFilter, tsPage]);

  useEffect(() => { loadTimesheets(); }, [loadTimesheets]);

  const openTsDetail = async (ts: TimesheetRow) => {
    setTsDetail(ts);
    setTsAction(null);
    setTsRejReason('');
    setTsDetailOpen(true);
    try {
      const entries = await timesheetService.getEntries(ts.id);
      setTsEntries(entries as Record<string, unknown>[]);
    } catch { setTsEntries([]); }
  };

  const handleTsApprove = async () => {
    if (!tsDetail) return;
    setTsActBusy(true);
    try {
      const result = await timesheetService.approve(tsDetail.id, 'current-manager');
      await notificationEngine.onTimesheetApproved({
        id: tsDetail.id,
        employee_id: tsDetail.employee_id,
        period_start: tsDetail.period_start,
        period_end: tsDetail.period_end,
      });
      toast.success(`Timesheet approved and locked for ${tsDetail.employee?.first_name ?? 'employee'}`);
      setTsDetailOpen(false);
      loadTimesheets();
      return result;
    } catch { toast.error('Failed to approve timesheet'); }
    finally { setTsActBusy(false); }
  };

  const handleTsReject = async () => {
    if (!tsDetail || !tsRejReason.trim()) { toast.error('Rejection reason is required'); return; }
    setTsActBusy(true);
    try {
      await timesheetService.reject(tsDetail.id, 'current-manager', tsRejReason.trim());
      await notificationEngine.onTimesheetRejected({
        id: tsDetail.id,
        employee_id: tsDetail.employee_id,
        period_start: tsDetail.period_start,
        period_end: tsDetail.period_end,
        rejection_reason: tsRejReason.trim(),
      });
      toast.success('Timesheet rejected — employee notified');
      setTsDetailOpen(false);
      loadTimesheets();
    } catch { toast.error('Failed to reject timesheet'); }
    finally { setTsActBusy(false); }
  };

  const pendingTs = timesheets.filter(t => t.status === 'submitted').length;

  const approveLeave = async (id: string) => {
    try {
      await leaveService.updateRequest(id, { status: 'approved' });
      toast.success('Leave approved');
      load();
    } catch { toast.error('Failed to approve leave'); }
  };

  const rejectLeave = async (id: string) => {
    try {
      await leaveService.updateRequest(id, { status: 'rejected' });
      toast.success('Leave rejected');
      load();
    } catch { toast.error('Failed to reject leave'); }
  };

  const openReview = (ot: OTRequest, action: 'approve' | 'reject') => {
    setReviewOt(ot);
    setReviewAction(action);
    setReviewNotes('');
  };

  const bulkAction = async (action: 'approve' | 'reject', notes = '') => {
    if (selectedOtIds.size === 0) return;
    if (action === 'reject' && !notes.trim()) {
      toast.error('Rejection reason required for bulk reject');
      return;
    }
    setBulkBusy(true);
    try {
      const ids = Array.from(selectedOtIds);
      const newStatus = action === 'approve' ? 'approved' : 'rejected';
      const { error } = await sb.from('overtime_requests').update({
        status: newStatus,
        notes: notes || null,
        approved_at: action === 'approve' ? new Date().toISOString() : null,
        updated_at: new Date().toISOString(),
      }).in('id', ids);
      if (error) throw error;
      toast.success(`${ids.length} OT request${ids.length > 1 ? 's' : ''} ${newStatus}`);
      setSelectedOtIds(new Set());
      loadOT();
    } catch (e) { toast.error((e as Error).message); }
    finally { setBulkBusy(false); }
  };

  const submitReview = async () => {
    if (!reviewOt || !reviewAction) return;
    setReviewBusy(true);
    try {
      const newStatus = reviewAction === 'approve' ? 'approved' : 'rejected';
      const { error } = await sb.from('overtime_requests').update({
        status: newStatus,
        notes: reviewNotes || null,
        approved_at: reviewAction === 'approve' ? new Date().toISOString() : null,
        updated_at: new Date().toISOString(),
      }).eq('id', reviewOt.id);
      if (error) throw error;
      toast.success(`OT request ${newStatus}`);
      setReviewOt(null);
      setReviewAction(null);
      loadOT();
    } catch (e) { toast.error((e as Error).message); }
    finally { setReviewBusy(false); }
  };

  const pendingOt = otRequests.filter(r => r.status === 'pending').length;

  return (
    <div className="space-y-5 p-4 md:p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Manager Self Service</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage your team, leave and overtime approvals</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => { load(); loadOT(); }} className="gap-1.5">
          <RefreshCw className="h-4 w-4" />Refresh
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card><CardContent className="p-4 flex items-center gap-3">
          <Users className="h-8 w-8 text-primary shrink-0" />
          <div><p className="text-2xl font-bold">{employees.length}</p><p className="text-xs text-muted-foreground">Team Members</p></div>
        </CardContent></Card>
        <Card><CardContent className="p-4 flex items-center gap-3">
          <Calendar className="h-8 w-8 text-yellow-600 shrink-0" />
          <div><p className="text-2xl font-bold text-yellow-600">{pendingLeaves.length}</p><p className="text-xs text-muted-foreground">Pending Leaves</p></div>
        </CardContent></Card>
        <Card><CardContent className="p-4 flex items-center gap-3">
          <Clock className="h-8 w-8 text-orange-500 shrink-0" />
          <div><p className="text-2xl font-bold text-orange-500">{pendingOt}</p><p className="text-xs text-muted-foreground">Pending OT Requests</p></div>
        </CardContent></Card>
        <Card><CardContent className="p-4 flex items-center gap-3">
          <CheckCheck className="h-8 w-8 text-green-600 shrink-0" />
          <div><p className="text-2xl font-bold text-green-600">{teamAttendance.filter(a => a.status === 'present').length}</p><p className="text-xs text-muted-foreground">Present Today</p></div>
        </CardContent></Card>
      </div>

      <Tabs defaultValue="leave">
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="leave" className="gap-1.5">
            <Calendar className="h-3.5 w-3.5" />Leave Approvals
            {pendingLeaves.length > 0 && <span className="ml-1 px-1.5 py-0.5 rounded-full bg-yellow-500 text-white text-xs font-bold">{pendingLeaves.length}</span>}
          </TabsTrigger>
          <TabsTrigger value="overtime" className="gap-1.5">
            <Clock className="h-3.5 w-3.5" />OT Approvals
            {pendingOt > 0 && <span className="ml-1 px-1.5 py-0.5 rounded-full bg-orange-500 text-white text-xs font-bold">{pendingOt}</span>}
          </TabsTrigger>
          <TabsTrigger value="team" className="gap-1.5">
            <Users className="h-3.5 w-3.5" />My Team
          </TabsTrigger>
          <TabsTrigger value="attendance" className="gap-1.5">
            <CheckCheck className="h-3.5 w-3.5" />Today's Attendance
          </TabsTrigger>
          <TabsTrigger value="timesheets" className="gap-1.5">
            <ClipboardList className="h-3.5 w-3.5" />Timesheet Approvals
            {pendingTs > 0 && <span className="ml-1 px-1.5 py-0.5 rounded-full bg-blue-500 text-white text-xs font-bold">{pendingTs}</span>}
          </TabsTrigger>
          <TabsTrigger value="performance-init" className="gap-1.5">
            <Star className="h-3.5 w-3.5" />Performance
          </TabsTrigger>
          <TabsTrigger value="loan-approval" className="gap-1.5">
            <Banknote className="h-3.5 w-3.5" />Loan Approvals
          </TabsTrigger>
          <TabsTrigger value="workforce-metrics" className="gap-1.5">
            <BarChart3 className="h-3.5 w-3.5" />Workforce Metrics
          </TabsTrigger>
        </TabsList>

        {/* ─── Leave Approvals ─── */}
        <TabsContent value="leave" className="mt-4">
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Leave Type</TableHead>
                  <TableHead className="whitespace-nowrap">From</TableHead>
                  <TableHead className="whitespace-nowrap">To</TableHead>
                  <TableHead className="whitespace-nowrap">Days</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 4 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                  : pendingLeaves.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      <Calendar className="h-8 w-8 mx-auto mb-2 opacity-40" />No pending leave requests
                    </TableCell></TableRow>
                  ) : pendingLeaves.map((l, i) => {
                    const emp = l.employee as { first_name?: string; last_name?: string } | undefined;
                    const lt = l.leave_type as { name?: string } | undefined;
                    return (
                      <TableRow key={String(l.id ?? i)}>
                        <TableCell className="whitespace-nowrap font-medium text-sm">{emp ? `${emp.first_name} ${emp.last_name}` : '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{lt?.name ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{String(l.start_date ?? '')}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{String(l.end_date ?? '')}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{String(l.total_days ?? '—')}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex gap-1.5">
                            <Button size="sm" variant="outline" className="h-7 text-xs border-green-600 text-green-700 hover:bg-green-50 gap-1" onClick={() => approveLeave(String(l.id))}>
                              <CheckCircle2 className="h-3.5 w-3.5" />Approve
                            </Button>
                            <Button size="sm" variant="outline" className="h-7 text-xs border-red-500 text-red-600 hover:bg-red-50 gap-1" onClick={() => rejectLeave(String(l.id))}>
                              <XCircle className="h-3.5 w-3.5" />Reject
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ─── OT Approvals ─── */}
        <TabsContent value="overtime" className="mt-4 space-y-4">
          {/* Filter + Bulk toolbar */}
          <div className="flex items-center gap-2 flex-wrap justify-between">
            <div className="flex gap-2 flex-wrap">
              {(['pending', 'approved', 'rejected', 'all'] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setOtFilter(f)}
                  className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                    otFilter === f
                      ? 'bg-primary text-primary-foreground border-primary'
                      : 'bg-card text-muted-foreground border-border hover:border-primary/50'
                  }`}
                >
                  {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
                  {f === 'pending' && pendingOt > 0 && ` (${pendingOt})`}
                </button>
              ))}
            </div>

            {/* Bulk actions — shown when items are selected */}
            {selectedOtIds.size > 0 && (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-muted/60 rounded-lg border border-border">
                <span className="text-xs font-medium text-muted-foreground">{selectedOtIds.size} selected</span>
                <Button
                  size="sm"
                  disabled={bulkBusy}
                  className="h-7 text-xs bg-green-600 hover:bg-green-700 text-white gap-1"
                  onClick={() => bulkAction('approve')}
                >
                  <CheckCircle2 className="h-3.5 w-3.5" />Approve All
                </Button>
                <Button
                  size="sm"
                  disabled={bulkBusy}
                  className="h-7 text-xs bg-red-600 hover:bg-red-700 text-white gap-1"
                  onClick={() => {
                    const note = window.prompt('Rejection reason (required):');
                    if (note && note.trim()) bulkAction('reject', note.trim());
                    else if (note !== null) toast.error('Rejection reason required');
                  }}
                >
                  <XCircle className="h-3.5 w-3.5" />Reject All
                </Button>
                <button className="text-xs text-muted-foreground hover:text-foreground ml-1" onClick={() => setSelectedOtIds(new Set())}>✕</button>
              </div>
            )}
          </div>

          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  {otFilter !== 'approved' && otFilter !== 'rejected' && (
                    <TableHead className="w-8 pl-3">
                      <input
                        type="checkbox"
                        className="h-4 w-4 rounded border-border cursor-pointer accent-primary"
                        checked={
                          otRequests.filter(r => r.status === 'pending').length > 0 &&
                          otRequests.filter(r => r.status === 'pending').every(r => selectedOtIds.has(r.id))
                        }
                        onChange={e => {
                          const pendingIds = otRequests.filter(r => r.status === 'pending').map(r => r.id);
                          setSelectedOtIds(e.target.checked ? new Set(pendingIds) : new Set());
                        }}
                        title="Select all pending"
                      />
                    </TableHead>
                  )}
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Date</TableHead>
                  <TableHead className="whitespace-nowrap">Time</TableHead>
                  <TableHead className="whitespace-nowrap text-center">Hours</TableHead>
                  <TableHead className="whitespace-nowrap">Reason</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {otLoading ? Array.from({ length: 4 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 8 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>
                  )) : otRequests.length === 0 ? (
                    <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                      <Clock className="h-8 w-8 mx-auto mb-2 opacity-40" />
                      No {otFilter !== 'all' ? otFilter : ''} OT requests
                    </TableCell></TableRow>
                  ) : otRequests.map(ot => {
                    const isPending = ot.status === 'pending';
                    const isChecked = selectedOtIds.has(ot.id);
                    return (
                      <TableRow key={ot.id} className={isChecked ? 'bg-primary/5' : undefined}>
                        {otFilter !== 'approved' && otFilter !== 'rejected' && (
                          <TableCell className="pl-3 w-8">
                            {isPending && (
                              <input
                                type="checkbox"
                                className="h-4 w-4 rounded border-border cursor-pointer accent-primary"
                                checked={isChecked}
                                onChange={e => {
                                  setSelectedOtIds(prev => {
                                    const next = new Set(prev);
                                    e.target.checked ? next.add(ot.id) : next.delete(ot.id);
                                    return next;
                                  });
                                }}
                              />
                            )}
                          </TableCell>
                        )}
                        <TableCell className="whitespace-nowrap font-medium text-sm">
                          {ot.employee ? `${ot.employee.first_name} ${ot.employee.last_name}` : ot.employee_id.slice(0, 8)}
                          {ot.employee?.employee_no && <span className="text-xs text-muted-foreground ml-1">#{ot.employee.employee_no}</span>}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{ot.requested_date}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">
                          {ot.start_time && ot.end_time ? `${ot.start_time} – ${ot.end_time}` : '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-center font-medium">{Number(ot.hours || 0).toFixed(1)}</TableCell>
                        <TableCell className="text-sm max-w-[180px] truncate" title={ot.reason ?? ''}>{ot.reason ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Badge className={OT_STATUS_COLORS[ot.status] ?? 'bg-muted text-muted-foreground'}>
                            {ot.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          {isPending ? (
                            <div className="flex gap-1.5">
                              <Button size="sm" variant="outline" className="h-7 text-xs border-green-600 text-green-700 hover:bg-green-50 gap-1" onClick={() => openReview(ot, 'approve')}>
                                <CheckCircle2 className="h-3.5 w-3.5" />Approve
                              </Button>
                              <Button size="sm" variant="outline" className="h-7 text-xs border-red-500 text-red-600 hover:bg-red-50 gap-1" onClick={() => openReview(ot, 'reject')}>
                                <XCircle className="h-3.5 w-3.5" />Reject
                              </Button>
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground">{ot.notes ? `Note: ${ot.notes}` : '—'}</span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ─── My Team ─── */}
        <TabsContent value="team" className="mt-4">
          <div className="mb-3">
            <Input placeholder="Search employees…" value={empSearch} onChange={e => setEmpSearch(e.target.value)} className="max-w-xs h-9" />
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Employee #</TableHead>
                  <TableHead className="whitespace-nowrap">Name</TableHead>
                  <TableHead className="whitespace-nowrap">Position</TableHead>
                  <TableHead className="whitespace-nowrap">Department</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 5 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                  : employees.length === 0 ? <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No employees found</TableCell></TableRow>
                  : employees.map((e, i) => {
                    const dept = e.department as { name?: string } | undefined;
                    const pos  = e.position  as { title?: string } | undefined;
                    return (
                      <TableRow key={String(e.id ?? i)}>
                        <TableCell className="whitespace-nowrap font-mono text-xs">{String(e.employee_no ?? '')}</TableCell>
                        <TableCell className="whitespace-nowrap font-medium text-sm">{String(e.first_name ?? '')} {String(e.last_name ?? '')}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{pos?.title ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{dept?.name ?? '—'}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Badge variant="outline" className="capitalize text-xs">{String(e.employment_status ?? '')}</Badge>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ─── Attendance ─── */}
        <TabsContent value="attendance" className="mt-4">
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Check In</TableHead>
                  <TableHead className="whitespace-nowrap">Check Out</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {loading ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 4 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                  : teamAttendance.length === 0 ? <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No attendance records for today</TableCell></TableRow>
                  : teamAttendance.map((a, i) => {
                    const emp = a.employee as { first_name?: string; last_name?: string } | undefined;
                    return (
                      <TableRow key={String(a.id ?? i)}>
                        <TableCell className="whitespace-nowrap font-medium text-sm">{emp ? `${emp.first_name} ${emp.last_name}` : '—'}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{String(a.check_in_time ?? '—')}</TableCell>
                        <TableCell className="whitespace-nowrap text-sm">{String(a.check_out_time ?? '—')}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Badge variant="outline" className="capitalize text-xs">{String(a.status ?? '')}</Badge>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ─── Timesheet Approvals ─── */}
        <TabsContent value="timesheets" className="mt-4 space-y-4">
          {/* Filters */}
          <div className="flex flex-wrap items-center gap-3">
            <Select value={tsStatusFilter} onValueChange={v => { setTsStatusFilter(v); setTsPage(1); }}>
              <SelectTrigger className="w-44 h-9">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="submitted">Submitted</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={loadTimesheets} className="gap-1.5">
              <RefreshCw className="h-3.5 w-3.5" />Refresh
            </Button>
            <p className="text-sm text-muted-foreground ml-auto">{tsTotal} total</p>
          </div>

          {/* Table */}
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/40">
                    <TableHead>Employee</TableHead>
                    <TableHead>Period</TableHead>
                    <TableHead>Total Hours</TableHead>
                    <TableHead>Overtime</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tsLoading
                    ? Array.from({ length: 5 }).map((_, i) => (
                      <TableRow key={i}>
                        {Array.from({ length: 6 }).map((__, j) => (
                          <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>
                        ))}
                      </TableRow>
                    ))
                    : timesheets.length === 0
                    ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                          <ClipboardList className="h-8 w-8 mx-auto mb-2 opacity-30" />
                          No timesheets found
                        </TableCell>
                      </TableRow>
                    )
                    : timesheets.map(ts => {
                      const emp = ts.employee;
                      const statusColors: Record<string, string> = {
                        submitted: 'bg-blue-100 text-blue-700',
                        approved:  'bg-green-100 text-green-700',
                        rejected:  'bg-red-100 text-red-700',
                        open:      'bg-gray-100 text-gray-700',
                      };
                      return (
                        <TableRow key={ts.id} className="cursor-pointer hover:bg-muted/40" onClick={() => openTsDetail(ts)}>
                          <TableCell>
                            <p className="font-medium">{emp ? `${emp.first_name} ${emp.last_name}` : '—'}</p>
                            {emp?.employee_no && <p className="text-xs text-muted-foreground">{emp.employee_no}</p>}
                          </TableCell>
                          <TableCell className="text-sm whitespace-nowrap">{ts.period_start} – {ts.period_end}</TableCell>
                          <TableCell className="font-semibold text-primary">{Number(ts.total_hours).toFixed(1)}h</TableCell>
                          <TableCell className="text-orange-600">{Number(ts.overtime_hours).toFixed(1)}h</TableCell>
                          <TableCell>
                            <span className={`px-2.5 py-1 rounded-full text-xs font-semibold capitalize ${statusColors[ts.status] ?? 'bg-gray-100 text-gray-700'}`}>
                              {ts.status}
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button size="sm" variant="ghost" className="gap-1.5" onClick={e => { e.stopPropagation(); openTsDetail(ts); }}>
                              <Eye className="h-4 w-4" />View
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  }
                </TableBody>
              </Table>
            </div>
            {/* Pagination */}
            {Math.ceil(tsTotal / TS_PAGE_SIZE) > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t">
                <p className="text-sm text-muted-foreground">Page {tsPage} of {Math.ceil(tsTotal / TS_PAGE_SIZE)}</p>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" disabled={tsPage === 1} onClick={() => setTsPage(p => p - 1)}>Prev</Button>
                  <Button variant="outline" size="sm" disabled={tsPage >= Math.ceil(tsTotal / TS_PAGE_SIZE)} onClick={() => setTsPage(p => p + 1)}>Next</Button>
                </div>
              </div>
            )}
          </div>
        </TabsContent>

        {/* ─── FR-MSS-004: Performance Review Initiation ─── */}
        <TabsContent value="performance-init" className="mt-4">
          <MssPerformanceTab managerEmployeeId={undefined} />
        </TabsContent>

        {/* ─── FR-MSS-006: Loan Approval ─── */}
        <TabsContent value="loan-approval" className="mt-4">
          <MssLoanApprovalTab managerEmployeeId={undefined} />
        </TabsContent>

        {/* ─── FR-MSS-007: Workforce Metrics Dashboard ─── */}
        <TabsContent value="workforce-metrics" className="mt-4">
          <MssWorkforceMetricsTab />
        </TabsContent>

      </Tabs>

      {/* ─── Timesheet Approval Dialog ─── */}
      <Dialog open={tsDetailOpen} onOpenChange={o => { if (!o) setTsDetailOpen(false); }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {tsDetail && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <ClipboardList className="h-5 w-5 text-primary" />
                  Timesheet — {tsDetail.employee?.first_name} {tsDetail.employee?.last_name}
                </DialogTitle>
              </DialogHeader>

              {/* Info */}
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide mb-0.5">Period</p>
                  <p className="font-medium">{tsDetail.period_start} – {tsDetail.period_end}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide mb-0.5">Total Hours</p>
                  <p className="font-bold text-primary">{Number(tsDetail.total_hours).toFixed(1)}h</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide mb-0.5">Overtime</p>
                  <p className="font-medium text-orange-600">{Number(tsDetail.overtime_hours).toFixed(1)}h</p>
                </div>
              </div>

              {/* Entries */}
              {tsEntries.length > 0 && (
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/40">
                        <TableHead>Date</TableHead>
                        <TableHead>Regular</TableHead>
                        <TableHead>Overtime</TableHead>
                        <TableHead>Billable</TableHead>
                        <TableHead>Notes</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {tsEntries.map((e, i) => (
                        <TableRow key={i}>
                          <TableCell className="text-sm">{String(e.work_date ?? e.entry_date ?? '')}</TableCell>
                          <TableCell className="text-sm">{Number(e.regular_hours ?? e.hours_logged ?? 0).toFixed(1)}h</TableCell>
                          <TableCell className="text-sm">{Number(e.overtime_hours ?? 0).toFixed(1)}h</TableCell>
                          <TableCell>{e.is_billable ? <Badge variant="outline" className="text-xs text-green-600 border-green-300">Yes</Badge> : <span className="text-xs text-muted-foreground">No</span>}</TableCell>
                          <TableCell className="text-xs text-muted-foreground max-w-[200px] truncate">{String(e.task_description ?? e.remark ?? '')}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              {/* Action */}
              {tsDetail.status === 'submitted' && (
                <div className="space-y-3 border-t pt-4">
                  {tsAction === null && (
                    <div className="flex gap-3">
                      <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white gap-1.5" onClick={() => setTsAction('approve')}>
                        <CheckCircle2 className="h-4 w-4" />Approve
                      </Button>
                      <Button variant="outline" className="flex-1 text-destructive border-destructive hover:bg-destructive hover:text-white gap-1.5" onClick={() => setTsAction('reject')}>
                        <XCircle className="h-4 w-4" />Reject
                      </Button>
                    </div>
                  )}
                  {tsAction === 'approve' && (
                    <div className="space-y-3">
                      <p className="text-sm font-medium text-green-700">Confirm timesheet approval — entries will be locked.</p>
                      <div className="flex gap-2">
                        <Button className="bg-green-600 hover:bg-green-700 text-white gap-1.5" disabled={tsActBusy} onClick={handleTsApprove}>
                          <CheckCircle2 className="h-4 w-4" />{tsActBusy ? 'Approving…' : 'Confirm Approve'}
                        </Button>
                        <Button variant="outline" onClick={() => setTsAction(null)}>Cancel</Button>
                      </div>
                    </div>
                  )}
                  {tsAction === 'reject' && (
                    <div className="space-y-3">
                      <div className="space-y-1.5">
                        <Label htmlFor="ts-rej-reason">Rejection Reason <span className="text-destructive">*</span></Label>
                        <Textarea
                          id="ts-rej-reason"
                          value={tsRejReason}
                          onChange={e => setTsRejReason(e.target.value)}
                          placeholder="Explain why this timesheet is being rejected…"
                          rows={3}
                          className="resize-none"
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button className="bg-red-600 hover:bg-red-700 text-white gap-1.5" disabled={tsActBusy || !tsRejReason.trim()} onClick={handleTsReject}>
                          <XCircle className="h-4 w-4" />{tsActBusy ? 'Rejecting…' : 'Confirm Reject'}
                        </Button>
                        <Button variant="outline" onClick={() => setTsAction(null)}>Cancel</Button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {tsDetail.status === 'approved' && (
                <div className="flex items-center gap-2 p-3 bg-green-50 text-green-700 rounded-lg text-sm border border-green-200">
                  <CheckCircle2 className="h-4 w-4 shrink-0" />
                  This timesheet has been approved and locked.
                </div>
              )}
              {tsDetail.status === 'rejected' && (
                <div className="space-y-1 p-3 bg-red-50 text-red-700 rounded-lg text-sm border border-red-200">
                  <div className="flex items-center gap-2 font-medium"><XCircle className="h-4 w-4" />Rejected</div>
                  {tsDetail.rejection_reason && <p className="text-xs">{tsDetail.rejection_reason}</p>}
                </div>
              )}

              <DialogFooter>
                <Button variant="outline" onClick={() => setTsDetailOpen(false)}>Close</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
      <Dialog open={!!reviewOt} onOpenChange={o => { if (!o) { setReviewOt(null); setReviewAction(null); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          {reviewOt && reviewAction && (
            <>
              <DialogHeader>
                <DialogTitle className={reviewAction === 'approve' ? 'text-green-700' : 'text-red-600'}>
                  {reviewAction === 'approve' ? '✓ Approve' : '✗ Reject'} OT Request
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-2">
                {/* Summary */}
                <div className="bg-muted/40 rounded-lg p-3 space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Employee</span>
                    <span className="font-medium">{reviewOt.employee ? `${reviewOt.employee.first_name} ${reviewOt.employee.last_name}` : '—'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Date</span>
                    <span className="font-medium">{reviewOt.requested_date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Hours</span>
                    <span className="font-bold text-primary">{Number(reviewOt.hours || 0).toFixed(1)}h</span>
                  </div>
                  {reviewOt.start_time && reviewOt.end_time && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Time</span>
                      <span>{reviewOt.start_time} – {reviewOt.end_time}</span>
                    </div>
                  )}
                  {reviewOt.reason && (
                    <div className="flex justify-between gap-4">
                      <span className="text-muted-foreground shrink-0">Reason</span>
                      <span className="text-right">{reviewOt.reason}</span>
                    </div>
                  )}
                </div>

                {/* Notes */}
                <div className="space-y-1.5">
                  <Label>
                    {reviewAction === 'reject' ? 'Rejection Reason *' : 'Notes (optional)'}
                  </Label>
                  <Textarea
                    rows={3}
                    value={reviewNotes}
                    onChange={e => setReviewNotes(e.target.value)}
                    placeholder={reviewAction === 'approve' ? 'Optional note for employee…' : 'Explain rejection reason…'}
                  />
                </div>

                <div className="flex justify-end gap-2 pt-1">
                  <Button variant="outline" onClick={() => { setReviewOt(null); setReviewAction(null); }}>Cancel</Button>
                  <Button
                    onClick={submitReview}
                    disabled={reviewBusy || (reviewAction === 'reject' && !reviewNotes.trim())}
                    className={reviewAction === 'approve' ? 'bg-green-600 hover:bg-green-700 text-white' : 'bg-red-600 hover:bg-red-700 text-white'}
                  >
                    {reviewBusy ? 'Saving…' : reviewAction === 'approve' ? 'Approve OT' : 'Reject OT'}
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-MSS-004: Performance Review Initiation
   ═══════════════════════════════════════════════════════════════════════════ */
function MssPerformanceTab({ managerEmployeeId }: { managerEmployeeId: string | undefined }) {
  void managerEmployeeId;
  const [reviews, setReviews]     = useState<Record<string, unknown>[]>([]);
  const [employees, setEmployees] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading]     = useState(false);
  const [open, setOpen]           = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm]           = useState({ employee_id: '', review_period: '', review_type: 'ANNUAL', appraisal_notes: '' });

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [revRes, empRes] = await Promise.all([
        _sb.from('performance_reviews')
          .select('id, review_period, review_type, status, overall_rating, created_at, employee:employees!performance_reviews_employee_id_fkey(first_name,last_name,employee_no)')
          .order('created_at', { ascending: false })
          .limit(30),
        _sb.from('employees')
          .select('id, first_name, last_name, employee_no')
          .eq('employment_status', 'active')
          .order('first_name')
          .limit(100),
      ]);
      setReviews(Array.isArray(revRes.data) ? revRes.data as Record<string, unknown>[] : []);
      setEmployees(Array.isArray(empRes.data) ? empRes.data as Record<string, unknown>[] : []);
    } catch { toast.error('Failed to load performance data'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const submit = async () => {
    if (!form.employee_id || !form.review_period) { toast.error('Select employee and review period'); return; }
    setSubmitting(true);
    try {
      const { error } = await _sb.from('performance_reviews').insert({
        employee_id: form.employee_id,
        review_period: form.review_period,
        review_type: form.review_type,
        status: 'pending',
        reviewer_comments: form.appraisal_notes || null,
      });
      if (error) throw error;
      toast.success('Performance review initiated');
      setOpen(false);
      setForm({ employee_id: '', review_period: '', review_type: 'ANNUAL', appraisal_notes: '' });
      loadData();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Failed'); }
    finally { setSubmitting(false); }
  };

  const STATUS_CLR: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    self_assessment: 'bg-blue-100 text-blue-800',
    manager_review: 'bg-purple-100 text-purple-800',
    completed: 'bg-emerald-100 text-emerald-800',
    acknowledged: 'bg-teal-100 text-teal-800',
  };

  return (
    <Card>
      <CardContent className="pt-4">
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm font-semibold flex items-center gap-2"><Star className="h-4 w-4" />Performance Reviews (FR-MSS-004)</p>
          <Button size="sm" className="h-8" onClick={() => setOpen(true)}>
            <Star className="h-3.5 w-3.5 mr-1" />Initiate Review
          </Button>
        </div>

        {loading ? (
          <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 bg-muted" />)}</div>
        ) : reviews.length === 0 ? (
          <div className="py-10 text-center text-muted-foreground"><Star className="h-8 w-8 mx-auto mb-2 opacity-30" />No reviews initiated yet</div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Period</TableHead>
                  <TableHead className="whitespace-nowrap">Type</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Rating</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reviews.map(r => {
                  const emp = r.employee as Record<string, unknown> | null;
                  return (
                    <TableRow key={r.id as string}>
                      <TableCell className="whitespace-nowrap text-sm font-medium">
                        {emp ? `${emp.first_name} ${emp.last_name}` : '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.review_period as string || '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.review_type as string || '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={`text-xs ${STATUS_CLR[r.status as string] || ''}`}>{r.status as string}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.overall_rating != null ? String(r.overall_rating) : '—'}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Initiate Performance Review</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-sm font-normal">Employee *</Label>
              <Select value={form.employee_id} onValueChange={v => setForm(p => ({ ...p, employee_id: v }))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select employee" /></SelectTrigger>
                <SelectContent>
                  {employees.map(e => (
                    <SelectItem key={e.id as string} value={e.id as string}>
                      {e.first_name as string} {e.last_name as string} ({e.employee_no as string || '—'})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-normal">Review Period *</Label>
              <Input className="mt-1" placeholder="e.g. 2025-H1" value={form.review_period} onChange={e => setForm(p => ({ ...p, review_period: e.target.value }))} />
            </div>
            <div>
              <Label className="text-sm font-normal">Review Type</Label>
              <Select value={form.review_type} onValueChange={v => setForm(p => ({ ...p, review_type: v }))}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['ANNUAL', 'MID_YEAR', 'PROBATION', 'QUARTERLY', 'PROJECT'].map(t => (
                    <SelectItem key={t} value={t}>{t.replace('_', ' ')}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-normal">Initial Notes</Label>
              <Textarea className="mt-1" rows={2} placeholder="Optional notes for this review cycle…" value={form.appraisal_notes} onChange={e => setForm(p => ({ ...p, appraisal_notes: e.target.value }))} />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={submit} disabled={submitting}>{submitting ? 'Initiating…' : 'Initiate Review'}</Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-MSS-006: Loan Approval
   ═══════════════════════════════════════════════════════════════════════════ */
function MssLoanApprovalTab({ managerEmployeeId }: { managerEmployeeId: string | undefined }) {
  void managerEmployeeId;
  const [loans, setLoans]     = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [actBusy, setActBusy] = useState<string>('');
  const [detailOpen, setDetailOpen] = useState(false);
  const [selected, setSelected]     = useState<Record<string, unknown> | null>(null);
  const [comment, setComment]       = useState('');

  const loadLoans = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await _sb.from('loan_requests')
        .select('id, loan_type, requested_amount, status, application_date, purpose, loan_duration_months, created_at, employee:employees!loan_requests_employee_id_fkey(first_name,last_name,employee_no), loan_policy:loan_policies!loan_requests_loan_policy_id_fkey(policy_name,max_amount)')
        .in('status', ['SUBMITTED', 'APPROVED', 'REJECTED'])
        .order('created_at', { ascending: false })
        .limit(40);
      if (error) throw error;
      setLoans(Array.isArray(data) ? data as Record<string, unknown>[] : []);
    } catch { toast.error('Failed to load loan requests'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadLoans(); }, [loadLoans]);

  const act = async (id: string, action: 'APPROVED' | 'REJECTED') => {
    setActBusy(id);
    try {
      const { error } = await _sb.from('loan_requests')
        .update({ status: action, remarks: comment || null, approved_at: action === 'APPROVED' ? new Date().toISOString() : null })
        .eq('id', id);
      if (error) throw error;
      toast.success(`Loan ${action.toLowerCase()}`);
      setDetailOpen(false); setSelected(null); setComment('');
      setLoans(prev => prev.map(l => l.id === id ? { ...l, status: action } : l));
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Action failed'); }
    finally { setActBusy(''); }
  };

  const STATUS_CLR: Record<string, string> = {
    SUBMITTED: 'bg-blue-100 text-blue-800',
    APPROVED: 'bg-emerald-100 text-emerald-800',
    REJECTED: 'bg-red-100 text-red-800',
    DISBURSED: 'bg-teal-100 text-teal-800',
  };

  return (
    <Card>
      <CardContent className="pt-4">
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm font-semibold flex items-center gap-2"><Banknote className="h-4 w-4" />Loan Approval Queue (FR-MSS-006)</p>
          <Button size="sm" variant="outline" className="h-8" onClick={loadLoans}>
            <RefreshCw className="h-3.5 w-3.5 mr-1" />Refresh
          </Button>
        </div>

        {loading ? (
          <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 bg-muted" />)}</div>
        ) : loans.length === 0 ? (
          <div className="py-10 text-center text-muted-foreground"><Banknote className="h-8 w-8 mx-auto mb-2 opacity-30" />No loan requests to review</div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Policy</TableHead>
                  <TableHead className="whitespace-nowrap">Amount</TableHead>
                  <TableHead className="whitespace-nowrap">Duration</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Date</TableHead>
                  <TableHead className="whitespace-nowrap">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loans.map(l => {
                  const emp = l.employee as Record<string, unknown> | null;
                  const pol = l.loan_policy as Record<string, unknown> | null;
                  const isPending = l.status === 'SUBMITTED';
                  return (
                    <TableRow key={l.id as string}>
                      <TableCell className="whitespace-nowrap text-sm font-medium">
                        {emp ? `${emp.first_name} ${emp.last_name}` : '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{pol?.policy_name as string || l.loan_type as string || '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-medium">${Number(l.requested_amount || 0).toLocaleString()}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{l.loan_duration_months ? `${l.loan_duration_months} mo` : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={`text-xs ${STATUS_CLR[l.status as string] || ''}`}>{l.status as string}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                        {l.application_date ? new Date(l.application_date as string).toLocaleDateString() : '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        {isPending ? (
                          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => { setSelected(l); setComment(''); setDetailOpen(true); }}>
                            Review
                          </Button>
                        ) : <span className="text-xs text-muted-foreground">—</span>}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={detailOpen} onOpenChange={o => { if (!o) { setDetailOpen(false); setSelected(null); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Loan Request — Review</DialogTitle></DialogHeader>
          {selected && (() => {
            const emp = selected.employee as Record<string, unknown> | null;
            const pol = selected.loan_policy as Record<string, unknown> | null;
            return (
              <div className="space-y-4 py-2">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div><p className="text-muted-foreground text-xs">Employee</p><p className="font-medium">{emp ? `${emp.first_name} ${emp.last_name}` : '—'}</p></div>
                  <div><p className="text-muted-foreground text-xs">Policy</p><p className="font-medium">{pol?.policy_name as string || '—'}</p></div>
                  <div><p className="text-muted-foreground text-xs">Amount</p><p className="font-medium">${Number(selected.requested_amount || 0).toLocaleString()}</p></div>
                  <div><p className="text-muted-foreground text-xs">Duration</p><p className="font-medium">{selected.loan_duration_months ? `${selected.loan_duration_months} months` : '—'}</p></div>
                  <div className="col-span-2"><p className="text-muted-foreground text-xs">Purpose</p><p>{selected.purpose as string || '—'}</p></div>
                </div>
                <div>
                  <Label className="text-sm font-normal">Comment / Remarks</Label>
                  <Textarea className="mt-1" rows={2} placeholder="Optional remarks…" value={comment} onChange={e => setComment(e.target.value)} />
                </div>
                <DialogFooter className="gap-2">
                  <Button variant="outline" onClick={() => setDetailOpen(false)}>Cancel</Button>
                  <Button className="bg-red-600 hover:bg-red-700 text-white" disabled={!!actBusy} onClick={() => act(selected.id as string, 'REJECTED')}>
                    {actBusy === selected.id ? 'Saving…' : 'Reject'}
                  </Button>
                  <Button className="bg-green-600 hover:bg-green-700 text-white" disabled={!!actBusy} onClick={() => act(selected.id as string, 'APPROVED')}>
                    {actBusy === selected.id ? 'Saving…' : 'Approve'}
                  </Button>
                </DialogFooter>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   FR-MSS-007: Workforce Metrics Dashboard
   ═══════════════════════════════════════════════════════════════════════════ */
function MssWorkforceMetricsTab() {
  const [metrics, setMetrics] = useState<{
    active: number; onLeave: number; attrition: number; avgRating: number;
    deptData: { name: string; count: number }[];
    attendance: { status: string; count: number }[];
  } | null>(null);
  const [loading, setLoading] = useState(false);

  const loadMetrics = useCallback(async () => {
    setLoading(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      const [empRes, attRes, perfRes, deptRes] = await Promise.all([
        _sb.from('employees').select('employment_status').limit(500),
        _sb.from('daily_attendance_summaries').select('attendance_status').eq('attendance_date', today).limit(200),
        _sb.from('performance_reviews').select('overall_rating').not('overall_rating', 'is', null).limit(200),
        _sb.from('employees').select('employment_status, department_id, departments(name)').eq('employment_status', 'active').limit(200),
      ]);

      const emps = (empRes.data || []) as Record<string, unknown>[];
      const active  = emps.filter(e => e.employment_status === 'active').length;
      const onLeave = emps.filter(e => e.employment_status === 'on_leave').length;
      const termed  = emps.filter(e => ['terminated', 'resigned'].includes(e.employment_status as string)).length;
      const attrition = emps.length > 0 ? Math.round((termed / emps.length) * 100) : 0;

      const attRows = (attRes.data || []) as Record<string, unknown>[];
      const attMap: Record<string, number> = {};
      attRows.forEach(a => { const s = a.attendance_status as string; attMap[s] = (attMap[s] || 0) + 1; });
      const attendance = Object.entries(attMap).map(([status, count]) => ({ status, count }));

      const perfRows = (perfRes.data || []) as Record<string, unknown>[];
      const avgRating = perfRows.length > 0
        ? Math.round((perfRows.reduce((s, r) => s + Number(r.overall_rating), 0) / perfRows.length) * 10) / 10
        : 0;

      const deptMap: Record<string, number> = {};
      ((deptRes.data || []) as Record<string, unknown>[]).forEach(e => {
        const d = (e.departments as Record<string, unknown>)?.name as string || 'Unknown';
        deptMap[d] = (deptMap[d] || 0) + 1;
      });
      const deptData = Object.entries(deptMap).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([name, count]) => ({ name, count }));

      setMetrics({ active, onLeave, attrition, avgRating, deptData, attendance });
    } catch { toast.error('Failed to load workforce metrics'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadMetrics(); }, [loadMetrics]);

  // Import recharts — ESM imports at top of file
  const COLORS = ['#6366f1', '#22c55e', '#f59e0b', '#ec4899', '#14b8a6', '#8b5cf6', '#ef4444', '#3b82f6'];
  const ATT_CLR: Record<string, string> = { present: '#22c55e', absent: '#ef4444', late: '#f59e0b', on_leave: '#6366f1', holiday: '#8b5cf6', remote: '#14b8a6' };

  const kpis = [
    { label: 'Active Employees', value: metrics?.active ?? '—', color: 'bg-indigo-500' },
    { label: 'On Leave',         value: metrics?.onLeave ?? '—', color: 'bg-amber-500' },
    { label: 'Attrition Rate',   value: metrics ? `${metrics.attrition}%` : '—', color: 'bg-rose-500' },
    { label: 'Avg Performance',  value: metrics?.avgRating ?? '—', color: 'bg-purple-500' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold flex items-center gap-2"><BarChart3 className="h-4 w-4" />Workforce Metrics (FR-MSS-007)</p>
        <Button size="sm" variant="outline" className="h-8" onClick={loadMetrics} disabled={loading}>
          <RefreshCw className={`h-3.5 w-3.5 mr-1 ${loading ? 'animate-spin' : ''}`} />Refresh
        </Button>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {kpis.map(k => (
          <Card key={k.label}>
            <CardContent className="p-3">
              <div className={`w-2 h-2 rounded-full ${k.color} mb-2`} />
              {loading ? <Skeleton className="h-6 w-16 bg-muted mb-1" /> : <p className="text-xl font-bold">{k.value}</p>}
              <p className="text-xs text-muted-foreground text-pretty">{k.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Headcount by Dept */}
        <Card>
          <CardContent className="pt-4">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Headcount by Department</p>
            {loading ? <Skeleton className="h-40 bg-muted" /> : (
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={metrics?.deptData || []} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" tick={{ fontSize: 11 }} />
                  <YAxis dataKey="name" type="category" width={90} tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#6366f1" radius={[0, 3, 3, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Today's Attendance Distribution */}
        <Card>
          <CardContent className="pt-4">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Today's Attendance Distribution</p>
            {loading ? <Skeleton className="h-40 bg-muted" /> : (
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={metrics?.attendance || []} dataKey="count" nameKey="status" cx="50%" cy="50%" outerRadius={65}>
                    {(metrics?.attendance || []).map((a, i) => (
                      <Cell key={i} fill={ATT_CLR[a.status] || COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend layout="horizontal" iconSize={10} wrapperStyle={{ fontSize: 11, paddingTop: 8 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
