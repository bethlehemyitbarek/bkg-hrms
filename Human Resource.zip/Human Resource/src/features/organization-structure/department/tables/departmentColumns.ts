export const departmentColumns = [
  { key: 'name', header: 'Name' },
  { key: 'code', header: 'Code' },
  { key: 'description', header: 'Description' },
  { key: 'isActive', header: 'Status' },
];
