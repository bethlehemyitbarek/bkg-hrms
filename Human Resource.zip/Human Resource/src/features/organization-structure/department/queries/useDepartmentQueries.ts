import { useApiQuery } from '@/shared/hooks/useApiQuery';
import { useApiMutation } from '@/shared/hooks/useApiMutation';
import { departmentApi } from '../api/departmentApi';
import { queryKeys } from '@/shared/query/queryKeys';

export function useDepartments() {
  return useApiQuery(queryKeys.departments, () => departmentApi.getAll());
}

export function useDepartment(id: string) {
  return useApiQuery(queryKeys.department(id), () => departmentApi.getById(id));
}

export function useCreateDepartment() {
  return useApiMutation((data: Record<string, unknown>) => departmentApi.create(data));
}

export function useUpdateDepartment() {
  return useApiMutation(({ id, data }: { id: string; data: Record<string, unknown> }) =>
    departmentApi.update(id, data)
  );
}

export function useDeleteDepartment() {
  return useApiMutation((id: string) => departmentApi.delete(id));
}
