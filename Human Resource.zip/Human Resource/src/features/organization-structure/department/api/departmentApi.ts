import { apiGet, apiPost, apiPut, apiDelete } from '@/shared/api/httpClient';
import { API_ROUTES } from '@/contracts/routes';

export const departmentApi = {
  getAll: () => apiGet<unknown[]>(API_ROUTES.DEPARTMENTS),
  getById: (id: string) => apiGet<unknown>(`${API_ROUTES.DEPARTMENTS}/${id}`),
  create: (data: Record<string, unknown>) => apiPost<unknown>(API_ROUTES.DEPARTMENTS, data),
  update: (id: string, data: Record<string, unknown>) => apiPut<unknown>(`${API_ROUTES.DEPARTMENTS}/${id}`, data),
  delete: (id: string) => apiDelete<unknown>(`${API_ROUTES.DEPARTMENTS}/${id}`),
};
