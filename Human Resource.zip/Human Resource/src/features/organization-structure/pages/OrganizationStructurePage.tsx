import { useState, useEffect } from 'react';
import { supabase as _supabase } from '@/db/supabase';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const _sb = _supabase as any;
import { departmentService, divisionService, businessUnitService, positionService, locationService } from '@/services/organization.service';
import type { Department, Division, BusinessUnit, Position, Location } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from "@/db/supabase";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Plus, Building2, Layers, MapPin, RefreshCw, Briefcase, SplitSquareHorizontal, Landmark, Coins, BookOpen, Route, Network, GitMerge, Loader2, Download } from 'lucide-react';
import { exportToCsv, exportToPdf } from '@/lib/exportUtils';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { OrgRestructuringPage } from './OrgRestructuringPage';

function TableSkeleton({ cols }: { cols: number }) {
  return (
    <>
      {Array.from({ length: 5 }).map((_, i) => (
        <TableRow key={i}>
          {Array.from({ length: cols }).map((__, j) => (
            <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>
          ))}
        </TableRow>
      ))}
    </>
  );
}

export function OrganizationStructurePage() {
  const [departments, setDepartments] = useState<(Department & { headcount?: number })[]>([]);
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [businessUnits, setBusinessUnits] = useState<BusinessUnit[]>([]);
  const [positions, setPositions] = useState<Position[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);

  const [deptDialog, setDeptDialog] = useState(false);
  const [divDialog, setDivDialog] = useState(false);
  const [divForm, setDivForm] = useState({ code: "", name: "", business_unit_id: "", is_active: true });
  const [posDialog, setPosDialog] = useState(false);
  const [locDialog, setLocDialog] = useState(false);

  const [deptForm, setDeptForm] = useState({ code: '', name: '', description: '', division_id: '' });
  const [posForm, setPosForm] = useState({ code: '', title: '', description: '', department_id: '', is_managerial: false });
  const [locForm, setLocForm] = useState({ code: '', name: '', address: '', city: '', country: 'TH', timezone: 'Asia/Bangkok' });
  const [saving, setSaving] = useState(false);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [deptStats, divs, bus, pos, locs] = await Promise.all([
        departmentService.getStats(),
        divisionService.list(),
        businessUnitService.list(),
        positionService.list(),
        locationService.list(),
      ]);
      setDepartments(deptStats);
      setDivisions(divs);
      setBusinessUnits(bus);
      setPositions(pos);
      setLocations(locs);
    } catch {
      toast.error('Failed to load organization data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadAll(); }, []);

  const handleCreateDiv = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      await divisionService.create(divForm);
      toast.success('Division created successfully');
      setDivDialog(false);
      setDivForm({ code: '', name: '', business_unit_id: '', is_active: true });
      loadAll();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleCreateDept = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await departmentService.create(deptForm);
      toast.success('Department created');
      setDeptDialog(false);
      setDeptForm({ code: '', name: '', description: '', division_id: '' });
      loadAll();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed');
    } finally {
      setSaving(false);
    }
  };

  const handleCreatePos = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await positionService.create(posForm);
      toast.success('Position created');
      setPosDialog(false);
      setPosForm({ code: '', title: '', description: '', department_id: '', is_managerial: false });
      loadAll();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed');
    } finally {
      setSaving(false);
    }
  };

  const handleCreateLoc = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await locationService.create(locForm);
      toast.success('Location created');
      setLocDialog(false);
      setLocForm({ code: '', name: '', address: '', city: '', country: 'TH', timezone: 'Asia/Bangkok' });
      loadAll();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed');
    } finally {
      setSaving(false);
    }
  };

  const handleExportCsv = () => {
    const exportData = departments.map(d => ({
      Code: d.code,
      Name: d.name,
      Division: (d as Department & { division?: { name: string } }).division?.name ?? '',
      Headcount: d.headcount ?? 0,
      Status: d.is_active ? 'Active' : 'Inactive'
    }));
    exportToCsv('organization_departments.csv', exportData);
  };

  const handleExportPdf = () => {
    exportToPdf('organization_departments.pdf');
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Organization Structure</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage BUs, Divisions, Departments, Positions and Locations</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-1.5" /> Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleExportCsv}>Export as CSV</DropdownMenuItem>
              <DropdownMenuItem onClick={handleExportPdf}>Export as PDF</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button variant="outline" size="sm" onClick={loadAll}>
            <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
          </Button>
        </div>
      </div>

      <Tabs defaultValue="departments">
        <TabsList className="h-9">
          <TabsTrigger value="departments" className="text-xs md:text-sm"><Building2 className="h-3.5 w-3.5 mr-1.5" />Departments</TabsTrigger>
          <TabsTrigger value="divisions" className="text-xs md:text-sm"><Building2 className="h-3.5 w-3.5 mr-1.5" />Divisions</TabsTrigger>
          <TabsTrigger value="business-units" className="text-xs md:text-sm"><Layers className="h-3.5 w-3.5 mr-1.5" />Business Units</TabsTrigger>
          <TabsTrigger value="positions" className="text-xs md:text-sm"><Briefcase className="h-3.5 w-3.5 mr-1.5" />Positions</TabsTrigger>
          <TabsTrigger value="locations" className="text-xs md:text-sm"><MapPin className="h-3.5 w-3.5 mr-1.5" />Locations</TabsTrigger>
          <TabsTrigger value="sections" className="text-xs md:text-sm"><SplitSquareHorizontal className="h-3.5 w-3.5 mr-1.5" />Sections</TabsTrigger>
          <TabsTrigger value="branches" className="text-xs md:text-sm"><Landmark className="h-3.5 w-3.5 mr-1.5" />Branches</TabsTrigger>
          <TabsTrigger value="cost-centers" className="text-xs md:text-sm"><Coins className="h-3.5 w-3.5 mr-1.5" />Cost Centers</TabsTrigger>
          <TabsTrigger value="job-architecture" className="text-xs md:text-sm"><BookOpen className="h-3.5 w-3.5 mr-1.5" />Job Architecture</TabsTrigger>
          <TabsTrigger value="career-paths" className="text-xs md:text-sm"><Route className="h-3.5 w-3.5 mr-1.5" />Career Paths</TabsTrigger>
          <TabsTrigger value="org-chart" className="text-xs md:text-sm"><Network className="h-3.5 w-3.5 mr-1.5" />Org Chart</TabsTrigger>
          <TabsTrigger value="restructuring" className="text-xs md:text-sm"><GitMerge className="h-3.5 w-3.5 mr-1.5" />Restructuring</TabsTrigger>
        </TabsList>

        
        {/* Divisions */}
        <TabsContent value="divisions" className="mt-4">
          <div className="flex justify-end mb-3">
            <Dialog open={divDialog} onOpenChange={setDivDialog}>
              <DialogTrigger asChild>
                <Button size="sm"><Plus className="h-4 w-4 mr-1.5" />Add Division</Button>
              </DialogTrigger>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                <DialogHeader><DialogTitle>Add Division</DialogTitle></DialogHeader>
                <form onSubmit={handleCreateDiv} className="space-y-4 mt-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Code *</Label>
                      <Input value={divForm.code} onChange={e => setDivForm(p => ({ ...p, code: e.target.value }))} required />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Name *</Label>
                      <Input value={divForm.name} onChange={e => setDivForm(p => ({ ...p, name: e.target.value }))} required />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Business Unit *</Label>
                      <Select value={divForm.business_unit_id} onValueChange={v => setDivForm(p => ({ ...p, business_unit_id: v }))}>
                        <SelectTrigger><SelectValue placeholder="Select business unit" /></SelectTrigger>
                        <SelectContent>
                          {businessUnits.map(bu => (
                            <SelectItem key={bu.id} value={bu.id}>{bu.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setDivDialog(false)}>Cancel</Button>
                    <Button type="submit">Save</Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Business Unit</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? <TableSkeleton cols={4} /> : divisions.length === 0 ? (
                  <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground">No divisions found</TableCell></TableRow>
                ) : divisions.map(d => (
                  <TableRow key={d.id}>
                    <TableCell className="font-medium">{d.code}</TableCell>
                    <TableCell>{d.name}</TableCell>
                    <TableCell>{d.business_unit?.name || '-'}</TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${d.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {d.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* Departments */}
        <TabsContent value="departments" className="mt-4">
          <div className="flex justify-end mb-3">
            <Dialog open={deptDialog} onOpenChange={setDeptDialog}>
              <DialogTrigger asChild>
                <Button size="sm"><Plus className="h-4 w-4 mr-1.5" />Add Department</Button>
              </DialogTrigger>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                <DialogHeader><DialogTitle>Add Department</DialogTitle></DialogHeader>
                <form onSubmit={handleCreateDept} className="space-y-4 mt-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Code *</Label>
                      <Input value={deptForm.code} onChange={e => setDeptForm(p => ({ ...p, code: e.target.value }))} required />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Name *</Label>
                      <Input value={deptForm.name} onChange={e => setDeptForm(p => ({ ...p, name: e.target.value }))} required />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Division</Label>
                    <Select value={deptForm.division_id} onValueChange={v => setDeptForm(p => ({ ...p, division_id: v }))}>
                      <SelectTrigger><SelectValue placeholder="Select division" /></SelectTrigger>
                      <SelectContent>
                        {divisions.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Description</Label>
                    <Input value={deptForm.description} onChange={e => setDeptForm(p => ({ ...p, description: e.target.value }))} />
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setDeptDialog(false)}>Cancel</Button>
                    <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Create'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Code</TableHead>
                    <TableHead className="whitespace-nowrap">Name</TableHead>
                    <TableHead className="whitespace-nowrap">Division</TableHead>
                    <TableHead className="whitespace-nowrap">Headcount</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? <TableSkeleton cols={5} /> : departments.map(d => (
                    <TableRow key={d.id}>
                      <TableCell className="whitespace-nowrap font-mono text-xs">{d.code}</TableCell>
                      <TableCell className="whitespace-nowrap font-medium">{d.name}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{(d as Department & { division?: { name: string } }).division?.name ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">{d.headcount ?? 0}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${d.is_active ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}`}>
                          {d.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* Business Units */}
        <TabsContent value="business-units" className="mt-4">
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Code</TableHead>
                    <TableHead className="whitespace-nowrap">Name</TableHead>
                    <TableHead className="whitespace-nowrap">Description</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? <TableSkeleton cols={4} /> : businessUnits.map(bu => (
                    <TableRow key={bu.id}>
                      <TableCell className="whitespace-nowrap font-mono text-xs">{bu.code}</TableCell>
                      <TableCell className="whitespace-nowrap font-medium">{bu.name}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{bu.description ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${bu.is_active ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}`}>
                          {bu.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* Positions */}
        <TabsContent value="positions" className="mt-4">
          <div className="flex justify-end mb-3">
            <Dialog open={posDialog} onOpenChange={setPosDialog}>
              <DialogTrigger asChild>
                <Button size="sm"><Plus className="h-4 w-4 mr-1.5" />Add Position</Button>
              </DialogTrigger>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                <DialogHeader><DialogTitle>Add Position</DialogTitle></DialogHeader>
                <form onSubmit={handleCreatePos} className="space-y-4 mt-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Code *</Label>
                      <Input value={posForm.code} onChange={e => setPosForm(p => ({ ...p, code: e.target.value }))} required />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Title *</Label>
                      <Input value={posForm.title} onChange={e => setPosForm(p => ({ ...p, title: e.target.value }))} required />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Department</Label>
                    <Select value={posForm.department_id} onValueChange={v => setPosForm(p => ({ ...p, department_id: v }))}>
                      <SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger>
                      <SelectContent>
                        {departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Description</Label>
                    <Input value={posForm.description} onChange={e => setPosForm(p => ({ ...p, description: e.target.value }))} />
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setPosDialog(false)}>Cancel</Button>
                    <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Create'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Code</TableHead>
                    <TableHead className="whitespace-nowrap">Title</TableHead>
                    <TableHead className="whitespace-nowrap">Department</TableHead>
                    <TableHead className="whitespace-nowrap">Grade</TableHead>
                    <TableHead className="whitespace-nowrap">Managerial</TableHead>
                    <TableHead className="whitespace-nowrap">Headcount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? <TableSkeleton cols={6} /> : positions.map(p => (
                    <TableRow key={p.id}>
                      <TableCell className="whitespace-nowrap font-mono text-xs">{p.code}</TableCell>
                      <TableCell className="whitespace-nowrap font-medium">{p.title}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{(p as Position & { department?: { name: string } }).department?.name ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{(p as Position & { job_grade?: { name: string } }).job_grade?.name ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">{p.is_managerial ? 'Yes' : 'No'}</TableCell>
                      <TableCell className="whitespace-nowrap">{p.headcount}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* Locations */}
        <TabsContent value="locations" className="mt-4">
          <div className="flex justify-end mb-3">
            <Dialog open={locDialog} onOpenChange={setLocDialog}>
              <DialogTrigger asChild>
                <Button size="sm"><Plus className="h-4 w-4 mr-1.5" />Add Location</Button>
              </DialogTrigger>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                <DialogHeader><DialogTitle>Add Location</DialogTitle></DialogHeader>
                <form onSubmit={handleCreateLoc} className="space-y-4 mt-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Code *</Label>
                      <Input value={locForm.code} onChange={e => setLocForm(p => ({ ...p, code: e.target.value }))} required />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Name *</Label>
                      <Input value={locForm.name} onChange={e => setLocForm(p => ({ ...p, name: e.target.value }))} required />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Address</Label>
                    <Input value={locForm.address} onChange={e => setLocForm(p => ({ ...p, address: e.target.value }))} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>City</Label>
                      <Input value={locForm.city} onChange={e => setLocForm(p => ({ ...p, city: e.target.value }))} />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Country</Label>
                      <Input value={locForm.country} onChange={e => setLocForm(p => ({ ...p, country: e.target.value }))} />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setLocDialog(false)}>Cancel</Button>
                    <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Create'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Code</TableHead>
                    <TableHead className="whitespace-nowrap">Name</TableHead>
                    <TableHead className="whitespace-nowrap">City</TableHead>
                    <TableHead className="whitespace-nowrap">Country</TableHead>
                    <TableHead className="whitespace-nowrap">Timezone</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? <TableSkeleton cols={6} /> : locations.map(l => (
                    <TableRow key={l.id}>
                      <TableCell className="whitespace-nowrap font-mono text-xs">{l.code}</TableCell>
                      <TableCell className="whitespace-nowrap font-medium">{l.name}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{l.city ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{l.country}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{l.timezone}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${l.is_active ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}`}>
                          {l.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        {/* ── FR-OSM-004: Sections ── */}
        <TabsContent value="sections" className="mt-4">
          <OrgSectionTab />
        </TabsContent>

        {/* ── FR-OSM-005: Branches ── */}
        <TabsContent value="branches" className="mt-4">
          <OrgSimpleTable entity="branches" label="Branch" columns={['code','name','location','branch_manager']} />
        </TabsContent>

        {/* ── FR-OSM-006: Cost Centers ── */}
        <TabsContent value="cost-centers" className="mt-4">
          <OrgCostCenterTab />
        </TabsContent>

        {/* ── FR-OSM-009: Job Architecture ── */}
        <TabsContent value="job-architecture" className="mt-4">
          <OrgJobArchitectureTab />
        </TabsContent>

        {/* ── FR-OSM-010: Career Paths & Succession ── */}
        <TabsContent value="career-paths" className="mt-4">
          <OrgCareerPathTab />
        </TabsContent>

        {/* ── FR-OSM-011: Org Chart Visualization ── */}
        <TabsContent value="org-chart" className="mt-4">
          <OrgChartTab />
        </TabsContent>

        {/* ── Restructuring ── */}
        <TabsContent value="restructuring" className="mt-4">
          <OrgRestructuringPage />
        </TabsContent>

      </Tabs>
    </div>
  );
}

/* ─── FR-OSM-004: Sections ── */
function OrgSectionTab() {
  const [rows, setRows]       = useState<Record<string, unknown>[]>([]);
  const [departments, setDepartments] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen]       = useState(false);
  const [form, setForm]       = useState({ code: '', name: '', department_id: '' });
  const [saving, setSaving]   = useState(false);

  const load = async () => {
    setLoading(true);
    const [secRes, depRes] = await Promise.all([
      _sb.from('sections').select('id, code, name, department_id, departments(name)').order('name', { ascending: true }).limit(100),
      _sb.from('departments').select('id, name').order('name', { ascending: true })
    ]);
    setRows((secRes.data as Record<string, unknown>[]) || []);
    setDepartments((depRes.data as Record<string, unknown>[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const save = async () => {
    if (!form.code || !form.name || !form.department_id) {
      toast.error('Code, Name, and Department are required');
      return;
    }
    setSaving(true);
    const { error } = await _sb.from('sections').insert({
      code: form.code,
      name: form.name,
      department_id: form.department_id,
    });
    if (error) { toast.error(error.message); setSaving(false); return; }
    toast.success('Section added'); setOpen(false); setForm({ code: '', name: '', department_id: '' }); load();
    setSaving(false);
  };

  return (
    <div>
      <div className="flex justify-end mb-3">
        <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-4 w-4 mr-1.5" />Add Section</Button>
      </div>
      {loading ? <Skeleton className="h-24 bg-muted" /> : rows.length === 0 ? (
        <div className="py-10 text-center text-muted-foreground text-sm">No sections found</div>
      ) : (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Code</TableHead>
                <TableHead className="whitespace-nowrap">Name</TableHead>
                <TableHead className="whitespace-nowrap">Department</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map(r => (
                <TableRow key={r.id as string}>
                  <TableCell className="text-sm font-medium">{r.code as string || '—'}</TableCell>
                  <TableCell className="text-sm">{r.name as string || '—'}</TableCell>
                  <TableCell className="text-sm">{(r.departments as Record<string, unknown>)?.name as string || '—'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Add Section</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <Label className="text-sm font-normal">Code *</Label>
              <Input className="mt-1" value={form.code} onChange={e => setForm(p => ({ ...p, code: e.target.value }))} />
            </div>
            <div>
              <Label className="text-sm font-normal">Name *</Label>
              <Input className="mt-1" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
            </div>
            <div>
              <Label className="text-sm font-normal">Department *</Label>
              <Select value={form.department_id} onValueChange={v => setForm(p => ({ ...p, department_id: v }))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select department" /></SelectTrigger>
                <SelectContent>
                  {departments.map(d => <SelectItem key={d.id as string} value={d.id as string}>{d.name as string}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Button className="w-full" onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Add Section'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─── Generic simple table for Branches ──────────────────────── */
function OrgSimpleTable({ entity, label, columns }: { entity: string; label: string; columns: string[] }) {
  const [rows, setRows]       = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen]       = useState(false);
  const [form, setForm]       = useState<Record<string, string>>({});
  const [saving, setSaving]   = useState(false);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const supabase = _supabase as any;

  const load = async () => {
    setLoading(true);
    const { data } = await _sb.from(entity).select('*').order('name', { ascending: true }).limit(100);
    setRows((data as Record<string, unknown>[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const save = async () => {
    setSaving(true);
    const { error } = await _sb.from(entity).insert(form);
    if (error) { toast.error(error.message); setSaving(false); return; }
    toast.success(`${label} added`); setOpen(false); setForm({}); load();
    setSaving(false);
  };

  return (
    <div>
      <div className="flex justify-end mb-3">
        <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-4 w-4 mr-1.5" />Add {label}</Button>
      </div>
      {loading ? <Skeleton className="h-24 bg-muted" /> : rows.length === 0 ? (
        <div className="py-10 text-center text-muted-foreground text-sm">No {label.toLowerCase()}s found</div>
      ) : (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>{columns.map(c => <TableHead key={c} className="whitespace-nowrap capitalize">{c.replace('_', ' ')}</TableHead>)}</TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((r, i) => (
                <TableRow key={i}>
                  {columns.map(c => <TableCell key={c} className="whitespace-nowrap text-sm">{String(r[c] ?? '—')}</TableCell>)}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add {label}</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            {columns.map(c => (
              <div key={c}>
                <Label className="text-sm font-normal capitalize">{c.replace('_', ' ')}</Label>
                <Input className="mt-1" value={form[c] || ''} onChange={e => setForm(p => ({ ...p, [c]: e.target.value }))} />
              </div>
            ))}
            <Button className="w-full" onClick={save} disabled={saving}>{saving ? 'Saving…' : `Add ${label}`}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─── FR-OSM-006: Cost Centers ────────────────────────────────────────────── */
function OrgCostCenterTab() {
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [departments, setDepartments] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    code: '',
    name: '',
    description: '',
    department_id: ''
  });

  const load = async () => {
    setLoading(true);

    const [ccRes, depRes] = await Promise.all([
      _sb
        .from('cost_centers')
        .select('id, code, name, description, department_id, departments(name)')
        .order('code', { ascending: true })
        .limit(100),

      _sb
        .from('departments')
        .select('id, name')
        .order('name', { ascending: true })
    ]);

    setRows((ccRes.data as Record<string, unknown>[]) || []);
    setDepartments((depRes.data as Record<string, unknown>[]) || []);

    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const save = async () => {
    if (!form.code || !form.name) {
      toast.error('Code and Name required');
      return;
    }

    setSaving(true);

    // ✅ STEP 2: check duplicate code
    const { data: existing, error: checkError } = await _sb
      .from('cost_centers')
      .select('id')
      .eq('code', form.code)
      .maybeSingle();

    if (checkError) {
      toast.error(checkError.message);
      setSaving(false);
      return;
    }

    if (existing) {
      toast.error('Cost center code already exists');
      setSaving(false);
      return;
    }

    // ✅ INSERT
    const { error } = await _sb.from('cost_centers').insert({
      code: form.code,
      name: form.name,
      description: form.description || null,
      department_id: form.department_id || null
    });

    if (error) {
      toast.error(error.message);
      setSaving(false);
      return;
    }

    toast.success('Cost center added');
    setOpen(false);

    setForm({
      code: '',
      name: '',
      description: '',
      department_id: ''
    });

    load();
    setSaving(false);
  };

  return (
    <div>
      {/* Header */}
      <div className="flex justify-end mb-3">
        <Button size="sm" onClick={() => setOpen(true)}>
          <Plus className="h-4 w-4 mr-1.5" />
          Add Cost Center
        </Button>
      </div>

      {/* Table */}
      {loading ? (
        <Skeleton className="h-24 bg-muted" />
      ) : rows.length === 0 ? (
        <div className="py-10 text-center text-muted-foreground text-sm">
          No cost centers defined
        </div>
      ) : (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Description</TableHead>
              </TableRow>
            </TableHeader>

            <TableBody>
              {rows.map(r => (
                <TableRow key={r.id as string}>
                  <TableCell className="font-medium">
                    {r.code as string}
                  </TableCell>

                  <TableCell>{r.name as string}</TableCell>

                  <TableCell>
                    {(r.departments as any)?.name ?? '—'}
                  </TableCell>

                  <TableCell className="text-muted-foreground">
                    {(r.description as string) || '—'}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle>Add Cost Center</DialogTitle>
          </DialogHeader>

          <div className="space-y-3 py-2">
            {/* Code */}
            <div>
              <Label>Code *</Label>
              <Input
                className="mt-1"
                value={form.code}
                onChange={e =>
                  setForm(p => ({ ...p, code: e.target.value }))
                }
              />
            </div>

            {/* Name */}
            <div>
              <Label>Name *</Label>
              <Input
                className="mt-1"
                value={form.name}
                onChange={e =>
                  setForm(p => ({ ...p, name: e.target.value }))
                }
              />
            </div>

            {/* Department */}
            <div>
              <Label>Department</Label>
              <Select
                value={form.department_id}
                onValueChange={v =>
                  setForm(p => ({ ...p, department_id: v }))
                }
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>

                <SelectContent>
                  {departments.map((d: any) => (
                    <SelectItem key={d.id} value={d.id}>
                      {d.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Description */}
            <div>
              <Label>Description</Label>
              <Input
                className="mt-1"
                value={form.description}
                onChange={e =>
                  setForm(p => ({
                    ...p,
                    description: e.target.value
                  }))
                }
              />
            </div>

            <Button
              className="w-full"
              onClick={save}
              disabled={saving}
            >
              {saving ? 'Saving…' : 'Add Cost Center'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─── FR-OSM-009: Job Architecture ────────────────────────────────────────── */
function OrgJobArchitectureTab() {
  const [families, setFamilies] = useState<Record<string, unknown>[]>([]);
  const [titles, setTitles]     = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading]   = useState(false);
  const [openFamily, setOpenFamily] = useState(false);
  const [openTitle, setOpenTitle]   = useState(false);
  const [fForm, setFForm] = useState({ code: '', name: '', description: '' });
  const [tForm, setTForm] = useState({ code: '', title: '', job_family_id: '', job_level: '', job_grade: '' });
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    const [fRes, tRes] = await Promise.all([
      _sb.from('job_families').select('id, code, name, description').order('name', { ascending: true }).limit(50),
      _sb.from('job_titles').select('id, code, title, job_level, job_grade, job_family_id, job_families(name)').order('title', { ascending: true }).limit(100),
    ]);
    setFamilies((fRes.data as Record<string, unknown>[]) || []);
    setTitles((tRes.data as Record<string, unknown>[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const saveFamily = async () => {
    if (!fForm.code || !fForm.name) { toast.error('Code and Name required'); return; }
    setSaving(true);
    const { error } = await _sb.from('job_families').insert(fForm);
    if (error) { toast.error(error.message); setSaving(false); return; }
    toast.success('Job family added'); setOpenFamily(false); setFForm({ code: '', name: '', description: '' }); load();
    setSaving(false);
  };

  const saveTitle = async () => {
    if (!tForm.title) { toast.error('Title required'); return; }
    setSaving(true);
    const { error } = await _sb.from('job_titles').insert({ ...tForm, job_family_id: tForm.job_family_id || null });
    if (error) { toast.error(error.message); setSaving(false); return; }
    toast.success('Job title added'); setOpenTitle(false); setTForm({ code: '', title: '', job_family_id: '', job_level: '', job_grade: '' }); load();
    setSaving(false);
  };

  return (
    <div className="space-y-4">
      {/* Job Families */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm font-semibold">Job Families</p>
          <Button size="sm" onClick={() => setOpenFamily(true)}><Plus className="h-4 w-4 mr-1" />Add Family</Button>
        </div>
        {loading ? <Skeleton className="h-20 bg-muted" /> : families.length === 0 ? (
          <p className="text-sm text-muted-foreground py-4 text-center">No job families defined</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Code</TableHead>
                <TableHead className="whitespace-nowrap">Name</TableHead>
                <TableHead className="whitespace-nowrap">Description</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {families.map(f => (
                  <TableRow key={f.id as string}>
                    <TableCell className="text-sm font-medium">{f.code as string || '—'}</TableCell>
                    <TableCell className="text-sm">{f.name as string || '—'}</TableCell>
                    <TableCell className="text-sm text-muted-foreground max-w-[200px] truncate">{f.description as string || '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      {/* Job Titles */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm font-semibold">Job Titles</p>
          <Button size="sm" onClick={() => setOpenTitle(true)}><Plus className="h-4 w-4 mr-1" />Add Title</Button>
        </div>
        {loading ? <Skeleton className="h-20 bg-muted" /> : titles.length === 0 ? (
          <p className="text-sm text-muted-foreground py-4 text-center">No job titles defined</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Code</TableHead>
                <TableHead className="whitespace-nowrap">Title</TableHead>
                <TableHead className="whitespace-nowrap">Family</TableHead>
                <TableHead className="whitespace-nowrap">Level</TableHead>
                <TableHead className="whitespace-nowrap">Grade</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {titles.map(t => (
                  <TableRow key={t.id as string}>
                    <TableCell className="text-sm font-medium">{t.code as string || '—'}</TableCell>
                    <TableCell className="text-sm">{t.title as string || '—'}</TableCell>
                    <TableCell className="text-sm">{(t.job_families as Record<string, unknown>)?.name as string || '—'}</TableCell>
                    <TableCell className="text-sm">{t.job_level as string || '—'}</TableCell>
                    <TableCell className="text-sm">{t.job_grade as string || '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      {/* Add Family Dialog */}
      <Dialog open={openFamily} onOpenChange={setOpenFamily}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Add Job Family</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            {[{ k: 'code', l: 'Code *' }, { k: 'name', l: 'Name *' }, { k: 'description', l: 'Description' }].map(({ k, l }) => (
              <div key={k}><Label className="text-sm font-normal">{l}</Label>
                <Input className="mt-1" value={fForm[k as keyof typeof fForm]} onChange={e => setFForm(p => ({ ...p, [k]: e.target.value }))} />
              </div>
            ))}
            <Button className="w-full" onClick={saveFamily} disabled={saving}>{saving ? 'Saving…' : 'Add Family'}</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Title Dialog */}
      <Dialog open={openTitle} onOpenChange={setOpenTitle}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Add Job Title</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div><Label className="text-sm font-normal">Job Family</Label>
              <Select value={tForm.job_family_id} onValueChange={v => setTForm(p => ({ ...p, job_family_id: v }))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select family" /></SelectTrigger>
                <SelectContent>{families.map(f => <SelectItem key={f.id as string} value={f.id as string}>{f.name as string}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {[{ k: 'code', l: 'Code' }, { k: 'title', l: 'Title *' }, { k: 'job_level', l: 'Job Level' }, { k: 'job_grade', l: 'Job Grade' }].map(({ k, l }) => (
              <div key={k}><Label className="text-sm font-normal">{l}</Label>
                <Input className="mt-1" value={tForm[k as keyof typeof tForm]} onChange={e => setTForm(p => ({ ...p, [k]: e.target.value }))} />
              </div>
            ))}
            <Button className="w-full" onClick={saveTitle} disabled={saving}>{saving ? 'Saving…' : 'Add Title'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─── FR-OSM-010: Career Paths & Succession ───────────────────────────────── */
function OrgCareerPathTab() {
  const [paths, setPaths]     = useState<Record<string, unknown>[]>([]);
  const [positions, setPositions] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen]       = useState(false);
  const [saving, setSaving]   = useState(false);
  const [form, setForm]       = useState({ name: '', from_position_id: '', to_position_id: '', requirements: '', min_years: '' });

  const load = async () => {
    setLoading(true);
    const [pathRes, posRes] = await Promise.all([
      _sb.from('career_paths').select('id, name, from_position:positions!from_position_id(id, title), to_position:positions!to_position_id(id, title), requirements, min_years_experience, created_at').order('name', { ascending: true }).limit(50),
      _sb.from('positions').select('id, title').order('title', { ascending: true })
    ]);
    setPaths((pathRes.data as Record<string, unknown>[]) || []);
    setPositions((posRes.data as Record<string, unknown>[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const save = async () => {
    if (!form.name) { toast.error('Path name required'); return; }
    setSaving(true);
    const { error } = await _sb.from('career_paths').insert({
      name: form.name, 
      from_position_id: form.from_position_id || null,
      to_position_id: form.to_position_id || null, 
      requirements: form.requirements || null,
      min_years_experience: form.min_years ? Number(form.min_years) : null,
    });
    if (error) { toast.error(error.message); setSaving(false); return; }
    toast.success('Career path added'); setOpen(false); setForm({ name: '', from_position_id: '', to_position_id: '', requirements: '', min_years: '' }); load();
    setSaving(false);
  };

  return (
    <div>
      <div className="flex justify-end mb-3">
        <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-4 w-4 mr-1.5" />Add Career Path</Button>
      </div>
      {loading ? <Skeleton className="h-24 bg-muted" /> : paths.length === 0 ? (
        <div className="py-10 text-center text-muted-foreground text-sm">No career paths defined</div>
      ) : (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead className="whitespace-nowrap">Path Name</TableHead>
              <TableHead className="whitespace-nowrap">From Position</TableHead>
              <TableHead className="whitespace-nowrap">To Position</TableHead>
              <TableHead className="whitespace-nowrap">Min Years</TableHead>
              <TableHead className="whitespace-nowrap">Requirements</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {paths.map(p => (
                <TableRow key={p.id as string}>
                  <TableCell className="text-sm font-medium">{p.name as string || '—'}</TableCell>
                  <TableCell className="text-sm">{(p.from_position as Record<string, unknown>)?.title as string || '—'}</TableCell>
                  <TableCell className="text-sm">{(p.to_position as Record<string, unknown>)?.title as string || '—'}</TableCell>
                  <TableCell className="text-sm">{p.min_years_experience != null ? String(p.min_years_experience) : '—'}</TableCell>
                  <TableCell className="text-sm text-muted-foreground max-w-[200px] truncate">{p.requirements as string || '—'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>Add Career Path</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <Label className="text-sm font-normal">Path Name *</Label>
              <Input className="mt-1" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
            </div>
            
            <div>
              <Label className="text-sm font-normal">From Position</Label>
              <Select value={form.from_position_id} onValueChange={v => setForm(p => ({ ...p, from_position_id: v }))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select position" /></SelectTrigger>
                <SelectContent>
                  {positions.map(pos => <SelectItem key={pos.id as string} value={pos.id as string}>{pos.title as string}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm font-normal">To Position</Label>
              <Select value={form.to_position_id} onValueChange={v => setForm(p => ({ ...p, to_position_id: v }))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select position" /></SelectTrigger>
                <SelectContent>
                  {positions.map(pos => <SelectItem key={pos.id as string} value={pos.id as string}>{pos.title as string}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm font-normal">Min Years Experience</Label>
              <Input className="mt-1" type="number" value={form.min_years} onChange={e => setForm(p => ({ ...p, min_years: e.target.value }))} />
            </div>

            <div>
              <Label className="text-sm font-normal">Requirements</Label>
              <Input className="mt-1" value={form.requirements} onChange={e => setForm(p => ({ ...p, requirements: e.target.value }))} />
            </div>

            <Button className="w-full" onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Add Career Path'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─── FR-OSM-011: Org Chart Visualization ────────────────────────────────── */
function OrgChartTab() {
  const [nodes, setNodes]     = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data } = await _sb.from('employees')
      .select('id, first_name, last_name, employee_no, job_title, department_id, manager_id, departments(name)')
      .eq('employment_status', 'active')
      .order('first_name', { ascending: true })
      .limit(200);
    setNodes((data as Record<string, unknown>[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Build tree: group by department then show manager → reports
  const deptMap: Record<string, Record<string, unknown>[]> = {};
  nodes.forEach(n => {
    const dept = (n.departments as Record<string, unknown>)?.name as string || 'No Department';
    if (!deptMap[dept]) deptMap[dept] = [];
    deptMap[dept].push(n);
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">Org chart grouped by department — {nodes.length} active employees</p>
        <Button size="sm" variant="outline" className="h-8" onClick={load} disabled={loading}>
          <RefreshCw className={`h-3.5 w-3.5 mr-1 ${loading ? 'animate-spin' : ''}`} />Refresh
        </Button>
      </div>

      {loading ? (
        <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-16 bg-muted" />)}</div>
      ) : (
        <div className="space-y-4">
          {Object.entries(deptMap).map(([dept, emps]) => (
            <div key={dept} className="border rounded-lg p-3">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2 flex items-center gap-1.5">
                <Building2 className="h-3 w-3" />{dept} <span className="font-normal normal-case tracking-normal">({emps.length})</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {emps.map(e => (
                  <div key={e.id as string} className="border rounded-md px-2.5 py-1.5 bg-card text-xs min-w-[120px]">
                    <p className="font-medium truncate">{e.first_name as string} {e.last_name as string}</p>
                    <p className="text-muted-foreground truncate">{e.job_title as string || 'No title'}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
