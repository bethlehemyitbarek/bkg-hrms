import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { Building2, Plus, RefreshCw, Loader2, GitMerge } from 'lucide-react';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = _sb as any;

type RestructureRow = {
  restructure_id?: string;
  title: string;
  restructure_type: string;
  effective_date?: string;
  status?: string;
  scope?: string;
  rationale?: string;
  approved_by?: string;
  created_at?: string;
};

type AffectedUnit = {
  unit_id?: string;
  restructure_id?: string;
  unit_type: string;
  unit_name: string;
  action: string;
  new_name?: string;
  new_parent?: string;
  employee_count?: number;
  notes?: string;
};

const STATUS_BADGE: Record<string, string> = {
  DRAFT: 'bg-muted text-muted-foreground',
  PENDING_APPROVAL: 'bg-yellow-100 text-yellow-800',
  APPROVED: 'bg-green-100 text-green-800',
  IN_PROGRESS: 'bg-blue-100 text-blue-800',
  COMPLETED: 'bg-green-200 text-green-900',
  CANCELLED: 'bg-red-100 text-red-800',
};

export function OrgRestructuringPage() {
  const [rows, setRows] = useState<RestructureRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState<RestructureRow | null>(null);
  const [units, setUnits] = useState<AffectedUnit[]>([]);
  const [loadingUnits, setLoadingUnits] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [addUnitOpen, setAddUnitOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ title: '', restructure_type: 'REORGANIZATION', effective_date: '', scope: '', rationale: '' });
  const [unitForm, setUnitForm] = useState({ unit_type: 'DEPARTMENT', unit_name: '', action: 'MERGE', new_name: '', new_parent: '', employee_count: '', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('org_restructuring').select('*').order('created_at', { ascending: false }).limit(50);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const loadUnits = async (restructureId: string) => {
    setLoadingUnits(true);
    const { data } = await sb.from('org_restructuring_units').select('*').eq('restructure_id', restructureId).order('action');
    setUnits(data || []);
    setLoadingUnits(false);
  };

  const selectRestructure = (r: RestructureRow) => {
    setSelected(r);
    if (r.restructure_id) loadUnits(r.restructure_id);
  };

  const createRestructure = async () => {
    if (!form.title.trim()) { toast.error('Title required'); return; }
    setSaving(true);
    const { error } = await sb.from('org_restructuring').insert({ title: form.title, restructure_type: form.restructure_type, effective_date: form.effective_date || null, scope: form.scope || null, rationale: form.rationale || null, status: 'DRAFT' });
    if (error) toast.error(error.message); else { toast.success('Restructuring plan created'); setCreateOpen(false); setForm({ title: '', restructure_type: 'REORGANIZATION', effective_date: '', scope: '', rationale: '' }); load(); }
    setSaving(false);
  };

  const addUnit = async () => {
    if (!selected?.restructure_id || !unitForm.unit_name.trim()) { toast.error('Unit name required'); return; }
    setSaving(true);
    const { error } = await sb.from('org_restructuring_units').insert({ restructure_id: selected.restructure_id, unit_type: unitForm.unit_type, unit_name: unitForm.unit_name, action: unitForm.action, new_name: unitForm.new_name || null, new_parent: unitForm.new_parent || null, employee_count: unitForm.employee_count ? Number(unitForm.employee_count) : null, notes: unitForm.notes || null });
    if (error) toast.error(error.message); else { toast.success('Unit added'); setAddUnitOpen(false); loadUnits(selected.restructure_id); }
    setSaving(false);
  };

  const updateStatus = async (id: string, status: string) => {
    const { error } = await sb.from('org_restructuring').update({ status }).eq('restructure_id', id);
    if (error) toast.error(error.message); else { toast.success('Status updated'); load(); if (selected?.restructure_id === id) setSelected(r => r ? { ...r, status } : r); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2"><Building2 className="h-6 w-6 text-primary" />Org Restructuring (FR-OSM-012)</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage organizational restructuring plans and affected units</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-4 w-4 mr-1.5" />Refresh</Button>
          <Button size="sm" onClick={() => setCreateOpen(true)}><Plus className="h-4 w-4 mr-1.5" />New Plan</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
        {/* Left: Plans list */}
        <div className="lg:col-span-2 space-y-3">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-sm">Restructuring Plans ({rows.length})</CardTitle></CardHeader>
            <CardContent className="p-0">
              {loading ? <div className="p-4"><Skeleton className="h-32 bg-muted" /></div> : rows.length === 0 ? (
                <p className="text-sm text-muted-foreground p-4 text-center">No restructuring plans</p>
              ) : (
                <div className="divide-y divide-border">
                  {rows.map(r => (
                    <div key={r.restructure_id} className={`p-3 cursor-pointer hover:bg-muted/50 transition-colors ${selected?.restructure_id === r.restructure_id ? 'bg-primary/5 border-l-2 border-primary' : ''}`} onClick={() => selectRestructure(r)}>
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <p className="font-medium text-sm truncate">{r.title}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">{r.restructure_type?.replace(/_/g, ' ')} • {r.effective_date || 'No date'}</p>
                        </div>
                        <Badge className={STATUS_BADGE[r.status || 'DRAFT'] || 'bg-muted'} style={{ whiteSpace: 'nowrap' }}>{r.status || 'DRAFT'}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right: Detail */}
        <div className="lg:col-span-3 space-y-4">
          {!selected ? (
            <Card>
              <CardContent className="pt-12 pb-12 text-center text-muted-foreground">
                <GitMerge className="h-10 w-10 mx-auto mb-3 opacity-30" />
                <p className="text-sm">Select a restructuring plan to view details</p>
              </CardContent>
            </Card>
          ) : (
            <>
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-base">{selected.title}</CardTitle>
                      <Badge className={`mt-1 ${STATUS_BADGE[selected.status || 'DRAFT']}`}>{selected.status}</Badge>
                    </div>
                    <Select value={selected.status || 'DRAFT'} onValueChange={v => updateStatus(selected.restructure_id!, v)}>
                      <SelectTrigger className="w-44 h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {Object.keys(STATUS_BADGE).map(s => <SelectItem key={s} value={s}>{s.replace(/_/g, ' ')}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div><span className="text-muted-foreground">Type:</span> <span className="font-medium">{selected.restructure_type?.replace(/_/g, ' ')}</span></div>
                    <div><span className="text-muted-foreground">Effective:</span> <span className="font-medium">{selected.effective_date || '—'}</span></div>
                    <div className="col-span-2"><span className="text-muted-foreground">Scope:</span> <span>{selected.scope || '—'}</span></div>
                    {selected.rationale && <div className="col-span-2"><span className="text-muted-foreground">Rationale:</span> <span>{selected.rationale}</span></div>}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">Affected Units ({units.length})</CardTitle>
                    <Button size="sm" onClick={() => setAddUnitOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Add Unit</Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {loadingUnits ? <Skeleton className="h-24 bg-muted" /> : units.length === 0 ? (
                    <p className="text-sm text-muted-foreground py-4 text-center">No affected units added yet</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader><TableRow>
                          <TableHead className="whitespace-nowrap">Unit</TableHead>
                          <TableHead className="whitespace-nowrap">Type</TableHead>
                          <TableHead className="whitespace-nowrap">Action</TableHead>
                          <TableHead className="whitespace-nowrap">New Name</TableHead>
                          <TableHead className="whitespace-nowrap">Employees</TableHead>
                        </TableRow></TableHeader>
                        <TableBody>
                          {units.map((u, i) => (
                            <TableRow key={u.unit_id || i}>
                              <TableCell className="whitespace-nowrap font-medium">{u.unit_name}</TableCell>
                              <TableCell><Badge variant="outline">{u.unit_type}</Badge></TableCell>
                              <TableCell><Badge className={u.action === 'MERGE' ? 'bg-blue-100 text-blue-800' : u.action === 'SPLIT' ? 'bg-purple-100 text-purple-800' : u.action === 'CLOSE' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}>{u.action}</Badge></TableCell>
                              <TableCell className="whitespace-nowrap">{u.new_name || '—'}</TableCell>
                              <TableCell className="whitespace-nowrap">{u.employee_count ?? '—'}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>

      {/* Create Plan Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Restructuring Plan</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Title *</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} placeholder="e.g. Q3 2025 Department Realignment" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Type</Label>
                <Select value={form.restructure_type} onValueChange={v => setForm(p => ({ ...p, restructure_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="REORGANIZATION">Reorganization</SelectItem>
                    <SelectItem value="MERGER">Merger</SelectItem>
                    <SelectItem value="ACQUISITION">Acquisition</SelectItem>
                    <SelectItem value="DOWNSIZING">Downsizing</SelectItem>
                    <SelectItem value="EXPANSION">Expansion</SelectItem>
                    <SelectItem value="DEPARTMENT_SPLIT">Department Split</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Effective Date</Label><Input type="date" value={form.effective_date} onChange={e => setForm(p => ({ ...p, effective_date: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Scope</Label><Input value={form.scope} onChange={e => setForm(p => ({ ...p, scope: e.target.value }))} placeholder="e.g. All departments in Region A" /></div>
            <div className="space-y-1.5"><Label>Rationale</Label><Textarea rows={3} value={form.rationale} onChange={e => setForm(p => ({ ...p, rationale: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button onClick={createRestructure} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Create Plan</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Unit Dialog */}
      <Dialog open={addUnitOpen} onOpenChange={setAddUnitOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add Affected Unit</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Unit Type</Label>
                <Select value={unitForm.unit_type} onValueChange={v => setUnitForm(p => ({ ...p, unit_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DEPARTMENT">Department</SelectItem>
                    <SelectItem value="DIVISION">Division</SelectItem>
                    <SelectItem value="TEAM">Team</SelectItem>
                    <SelectItem value="BRANCH">Branch</SelectItem>
                    <SelectItem value="POSITION">Position</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Unit Name *</Label><Input value={unitForm.unit_name} onChange={e => setUnitForm(p => ({ ...p, unit_name: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Action</Label>
                <Select value={unitForm.action} onValueChange={v => setUnitForm(p => ({ ...p, action: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="MERGE">Merge</SelectItem>
                    <SelectItem value="SPLIT">Split</SelectItem>
                    <SelectItem value="RENAME">Rename</SelectItem>
                    <SelectItem value="MOVE">Move / Re-parent</SelectItem>
                    <SelectItem value="CLOSE">Close</SelectItem>
                    <SelectItem value="CREATE">Create New</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Employees Affected</Label><Input type="number" value={unitForm.employee_count} onChange={e => setUnitForm(p => ({ ...p, employee_count: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>New Name (if renamed)</Label><Input value={unitForm.new_name} onChange={e => setUnitForm(p => ({ ...p, new_name: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>New Parent Unit</Label><Input value={unitForm.new_parent} onChange={e => setUnitForm(p => ({ ...p, new_parent: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Notes</Label><Textarea rows={2} value={unitForm.notes} onChange={e => setUnitForm(p => ({ ...p, notes: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setAddUnitOpen(false)}>Cancel</Button>
            <Button onClick={addUnit} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Add Unit</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default OrgRestructuringPage;
