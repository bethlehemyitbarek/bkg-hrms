import { useState, useEffect, useCallback } from 'react';
import { dashboardService, type DashboardStats, type HeadcountByDept, type PayrollTrend, type RecruitmentFunnel, type IncidentStatusChart } from '@/services/dashboard.service';
import { supabase as _supabase } from '@/db/supabase';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from 'recharts';
import {
  Users, Clock, CalendarDays, Wallet, UserPlus, BarChart3,
  TrendingUp, TrendingDown, AlertCircle, GraduationCap, Calculator,
  RefreshCw, CheckCircle2, Activity, ArrowRight, Sparkles,
  FileText, ClipboardList, Bell, Zap, Star, Shield,
  Building2, ChevronRight, AlertTriangle, Network
} from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

const supabase = _supabase as any; // eslint-disable-line @typescript-eslint/no-explicit-any

/* ─── Gradient KPI Card ─────────────────────────────────────────────────── */
interface GradientKpiProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ElementType;
  gradient: string;
  iconBg: string;
  trend?: string;
  trendUp?: boolean;
  loading?: boolean;
  onClick?: () => void;
}

function GradientKpiCard({ title, value, subtitle, icon: Icon, gradient, iconBg, trend, trendUp, loading, onClick }: GradientKpiProps) {
  return (
    <div
      className={`relative overflow-hidden rounded-2xl ${gradient} p-5 shadow-lg cursor-pointer group transition-all hover:shadow-xl hover:-translate-y-0.5`}
      onClick={onClick}
    >
      {/* Decorative circle */}
      <div className="absolute -right-4 -top-4 h-20 w-20 rounded-full bg-white/10" />
      <div className="absolute -right-2 -bottom-6 h-28 w-28 rounded-full bg-white/5" />

      <div className="relative">
        <div className="flex items-start justify-between mb-3">
          <div className={`p-2.5 rounded-xl ${iconBg} shadow-sm`}>
            <Icon className="h-5 w-5 text-white" />
          </div>
          <ChevronRight className="h-4 w-4 text-white/50 group-hover:text-white/80 transition-colors mt-0.5" />
        </div>

        {loading ? (
          <Skeleton className="h-8 w-20 mb-1 bg-white/20" />
        ) : (
          <p className="text-2xl font-bold text-white leading-none mb-1">{value}</p>
        )}
        <p className="text-xs font-semibold text-white/70 uppercase tracking-wide">{title}</p>
        {subtitle && !loading && (
          <p className="text-xs text-white/60 mt-1.5 line-clamp-1">{subtitle}</p>
        )}
        {trend && !loading && (
          <div className="flex items-center gap-1 mt-2">
            {trendUp
              ? <TrendingUp className="h-3 w-3 text-white/80" />
              : <TrendingDown className="h-3 w-3 text-white/80" />}
            <span className="text-xs font-medium text-white/80">{trend}</span>
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── Section Card ─────────────────────────────────────────────────────── */
function SectionCard({ title, description, icon: Icon, children }: {
  title: string; description?: string; icon?: React.ElementType; children: React.ReactNode;
}) {
  return (
    <Card className="border-0 shadow-md rounded-2xl overflow-hidden bg-card">
      <CardHeader className="pb-3 border-b border-border/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            {Icon && (
              <div className="p-1.5 rounded-lg bg-primary/10">
                <Icon className="h-4 w-4 text-primary" />
              </div>
            )}
            <div>
              <CardTitle className="text-sm font-semibold">{title}</CardTitle>
              {description && <CardDescription className="text-xs mt-0.5">{description}</CardDescription>}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4">{children}</CardContent>
    </Card>
  );
}

/* ─── Attendance Donut ──────────────────────────────────────────────────── */
function AttendanceDonut({ stats, loading }: { stats: DashboardStats | null; loading: boolean }) {
  if (loading) return <Skeleton className="h-52 w-full" />;
  if (!stats) return null;
  const { present_today, absent_today, late_today, on_leave_today } = stats.attendance;
  const data = [
    { name: 'Present',  value: present_today,  fill: '#22c55e' },
    { name: 'Absent',   value: absent_today,   fill: '#ef4444' },
    { name: 'Late',     value: late_today,     fill: '#f59e0b' },
    { name: 'On Leave', value: on_leave_today, fill: '#3b82f6' },
  ].filter(d => d.value > 0);
  if (!data.length) return (
    <div className="flex flex-col items-center justify-center h-40 text-muted-foreground">
      <Activity className="h-8 w-8 mb-2 opacity-30" />
      <p className="text-sm">No attendance data for today</p>
    </div>
  );
  return (
    <ResponsiveContainer width="100%" height={200}>
      <PieChart>
        <Pie data={data} cx="50%" cy="50%" innerRadius={52} outerRadius={80} paddingAngle={4} dataKey="value">
          {data.map((e, i) => <Cell key={i} fill={e.fill} strokeWidth={0} />)}
        </Pie>
        <Tooltip formatter={(v) => [`${v} employees`, '']} />
        <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8, fontSize: 12 }} />
      </PieChart>
    </ResponsiveContainer>
  );
}

/* ─── Headcount Bar Chart ─────────────────────────────────────────────── */
function HeadcountChart({ data, loading }: { data: HeadcountByDept[]; loading: boolean }) {
  if (loading) return <Skeleton className="h-52 w-full" />;
  if (!data.length) return <p className="text-sm text-muted-foreground text-center py-10">No headcount data.</p>;
  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={data} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
        <defs>
          <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={1} />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0.6} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
        <XAxis dataKey="department" tick={{ fontSize: 10 }} tickLine={false} axisLine={false}
          tickFormatter={v => v.length > 7 ? v.slice(0, 7) + '…' : v} />
        <YAxis tick={{ fontSize: 10 }} tickLine={false} axisLine={false} allowDecimals={false} />
        <Tooltip
          contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 4px 24px rgba(0,0,0,0.12)', fontSize: 12 }}
          formatter={(v) => [`${v} employees`, 'Headcount']}
        />
        <Bar dataKey="count" fill="url(#barGrad)" radius={[6, 6, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

/* ─── Payroll Trend Area Chart ────────────────────────────────────────── */
function PayrollTrendChart({ data, loading }: { data: PayrollTrend[]; loading: boolean }) {
  if (loading) return <Skeleton className="h-52 w-full" />;
  if (!data.length) return <p className="text-sm text-muted-foreground text-center py-10">No payroll history yet.</p>;
  const fmt = (v: number) => `฿${(v / 1000).toFixed(0)}k`;
  return (
    <ResponsiveContainer width="100%" height={220}>
      <AreaChart data={data} margin={{ top: 4, right: 8, left: -8, bottom: 0 }}>
        <defs>
          <linearGradient id="grossGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor="hsl(var(--primary))" stopOpacity={0.3} />
            <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="netGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor="#22c55e" stopOpacity={0.3} />
            <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
        <XAxis dataKey="month" tick={{ fontSize: 10 }} tickLine={false} axisLine={false}
          tickFormatter={v => v.length > 9 ? v.slice(0, 9) + '…' : v} />
        <YAxis tick={{ fontSize: 10 }} tickLine={false} axisLine={false} tickFormatter={fmt} />
        <Tooltip
          contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 4px 24px rgba(0,0,0,0.12)', fontSize: 12 }}
          formatter={(v: number) => [fmt(v), '']}
        />
        <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8, fontSize: 12 }} />
        <Area type="monotone" dataKey="gross_pay" name="Gross Pay" stroke="hsl(var(--primary))" fill="url(#grossGrad)" strokeWidth={2.5} dot={false} />
        <Area type="monotone" dataKey="net_pay"   name="Net Pay"   stroke="#22c55e"               fill="url(#netGrad)"   strokeWidth={2.5} dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

/* ─── Recruitment Funnel ──────────────────────────────────────────────── */
function RecruitmentFunnelChart({ data, loading }: { data: RecruitmentFunnel[]; loading: boolean }) {
  if (loading) return <Skeleton className="h-44 w-full" />;
  if (!data.length) return <p className="text-sm text-muted-foreground text-center py-10">No candidates yet.</p>;
  return (
    <ResponsiveContainer width="100%" height={200}>
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 24, left: 16, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" horizontal={false} />
        <XAxis type="number" tick={{ fontSize: 10 }} tickLine={false} axisLine={false} allowDecimals={false} />
        <YAxis type="category" dataKey="stage" tick={{ fontSize: 10 }} tickLine={false} axisLine={false} width={72} />
        <Tooltip contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 4px 24px rgba(0,0,0,0.12)', fontSize: 12 }} />
        <Bar dataKey="count" radius={[0, 6, 6, 0]}>
          {data.map((_, i) => {
            const colors = ['#6366f1', '#8b5cf6', '#a78bfa', '#c4b5fd', '#ddd6fe'];
            return <Cell key={i} fill={colors[i % colors.length]} />;
          })}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

/* ─── Training Pie ────────────────────────────────────────────────────── */
function TrainingPieChart({ data, loading }: { data: { name: string; value: number; fill: string }[]; loading: boolean }) {
  if (loading) return <Skeleton className="h-44 w-full" />;
  if (!data.length) return <p className="text-sm text-muted-foreground text-center py-10">No enrollment data.</p>;
  return (
    <ResponsiveContainer width="100%" height={200}>
      <PieChart>
        <Pie data={data} cx="50%" cy="50%" outerRadius={72} paddingAngle={4} dataKey="value">
          {data.map((e, i) => <Cell key={i} fill={e.fill} strokeWidth={0} />)}
        </Pie>
        <Tooltip contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 4px 24px rgba(0,0,0,0.12)', fontSize: 12 }} />
        <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8, fontSize: 12 }} />
      </PieChart>
    </ResponsiveContainer>
  );
}

/* ─── Incident Status Pie ────────────────────────────────────────────────────── */
function IncidentStatusPieChart({ data, loading }: { data: IncidentStatusChart[]; loading: boolean }) {
  if (loading) return <Skeleton className="h-44 w-full" />;
  if (!data.length) return <p className="text-sm text-muted-foreground text-center py-10">No incident reports.</p>;
  return (
    <ResponsiveContainer width="100%" height={200}>
      <PieChart>
        <Pie data={data} cx="50%" cy="50%" outerRadius={72} paddingAngle={4} dataKey="value">
          {data.map((e, i) => <Cell key={i} fill={e.fill} strokeWidth={0} />)}
        </Pie>
        <Tooltip contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 4px 24px rgba(0,0,0,0.12)', fontSize: 12 }} />
        <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8, fontSize: 12 }} />
      </PieChart>
    </ResponsiveContainer>
  );
}

/* ─── Quick Action Button ─────────────────────────────────────────────── */
function QuickAction({ icon: Icon, label, description, color, onClick }: {
  icon: React.ElementType; label: string; description: string; color: string; onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-3 w-full p-3 rounded-xl border border-border/60 hover:border-primary/40 hover:bg-primary/5 transition-all group text-left"
    >
      <div className={`p-2 rounded-lg ${color} shrink-0`}>
        <Icon className="h-4 w-4 text-white" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium leading-none mb-0.5">{label}</p>
        <p className="text-xs text-muted-foreground truncate">{description}</p>
      </div>
      <ArrowRight className="h-3.5 w-3.5 text-muted-foreground/50 group-hover:text-primary transition-colors shrink-0" />
    </button>
  );
}

/* ─── Status Row ──────────────────────────────────────────────────────── */
function StatusRow({ label, right }: { label: string; right: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 py-2 border-b border-border/40 last:border-0">
      <span className="text-sm text-muted-foreground flex items-center gap-2">
        <CheckCircle2 className="h-3.5 w-3.5 text-green-500 shrink-0" />
        {label}
      </span>
      <div className="shrink-0">{right}</div>
    </div>
  );
}

/* ─── Alert Row ───────────────────────────────────────────────────────── */
function AlertItem({ icon: Icon, title, subtitle, color }: {
  icon: React.ElementType; title: string; subtitle: string; color: string;
}) {
  return (
    <div className={`flex items-start gap-3 p-3 rounded-xl ${color} mb-2 last:mb-0`}>
      <Icon className="h-4 w-4 mt-0.5 shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-xs font-semibold leading-tight">{title}</p>
        <p className="text-xs opacity-80 mt-0.5">{subtitle}</p>
      </div>
    </div>
  );
}

/* ─── Main Dashboard ────────────────────────────────────────────────────── */
export function DashboardPage() {
  const navigate = useNavigate();
  const [stats, setStats]               = useState<DashboardStats | null>(null);
  const [headcount, setHeadcount]       = useState<HeadcountByDept[]>([]);
  const [payrollTrend, setPayrollTrend] = useState<PayrollTrend[]>([]);
  const [funnel, setFunnel]             = useState<RecruitmentFunnel[]>([]);
  const [trainData, setTrainData]       = useState<{ name: string; value: number; fill: string }[]>([]);
  const [incidentChart, setIncidentChart] = useState<IncidentStatusChart[]>([]);
  const [loading, setLoading]           = useState(true);
  const [chartsLoading, setChartsLoading] = useState(true);
  const [lastUpdated, setLastUpdated]   = useState<Date | null>(null);

  const loadStats = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const data = await dashboardService.getStats();
      setStats(data);
      setLastUpdated(new Date());
    } catch {
      if (!silent) toast.error('Failed to load dashboard stats.');
    } finally {
      if (!silent) setLoading(false);
    }
  }, []);

  const loadCharts = useCallback(async () => {
    setChartsLoading(true);
    try {
      const [hc, pt, rf, td, inc] = await Promise.all([
        dashboardService.getHeadcountByDept(),
        dashboardService.getPayrollTrend(),
        dashboardService.getRecruitmentFunnel(),
        dashboardService.getTrainingStatus(),
        dashboardService.getIncidentStatusChart(),
      ]);
      setHeadcount(hc);
      setPayrollTrend(pt);
      setFunnel(rf);
      setTrainData(td);
      setIncidentChart(inc);
    } finally {
      setChartsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStats();
    loadCharts();
    const channel = supabase.channel('dashboard-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'employees' },          () => loadStats(true))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'attendance_records' }, () => loadStats(true))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'leave_requests' },     () => loadStats(true))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'payroll_records' },    () => loadStats(true))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'candidates' },         () => loadStats(true))
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [loadStats, loadCharts]);

  const fmtCurrency = (v: number) =>
    new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB', maximumFractionDigits: 0 }).format(v);

  const statusBadge = (s: string | null) => {
    if (!s) return null;
    const map: Record<string, string> = {
      paid: 'bg-green-100 text-green-700 border-green-200',
      processing: 'bg-yellow-100 text-yellow-700 border-yellow-200',
      draft: 'bg-muted text-muted-foreground',
    };
    return (
      <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full capitalize border ${map[s] ?? 'bg-muted text-muted-foreground'}`}>
        {s}
      </span>
    );
  };

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <div className="space-y-6 pb-6">

      {/* ── Hero Header ─────────────────────────────────────────────────── */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-primary via-primary/90 to-indigo-600 p-6 shadow-xl">
        {/* decorative orbs */}
        <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-white/10 blur-xl" />
        <div className="absolute right-20 bottom-0 h-24 w-24 rounded-full bg-white/5 blur-md" />
        <div className="relative flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="h-4 w-4 text-white/70" />
              <span className="text-xs font-medium text-white/70 uppercase tracking-widest">BKG HRMS</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white">
              {greeting()}, HR Team 👋
            </h1>
            <p className="text-white/70 text-sm mt-1">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
            {lastUpdated && (
              <p className="text-white/50 text-xs mt-2">
                Last synced {lastUpdated.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
              </p>
            )}
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => { loadStats(); loadCharts(); }}
              disabled={loading}
              className="bg-white/20 hover:bg-white/30 text-white border-white/20 backdrop-blur-sm gap-1.5"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>
      </div>

      {/* ── KPI Row 1: People & Attendance ──────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <GradientKpiCard
          title="Total Employees"
          value={stats?.employees.total ?? '—'}
          subtitle={`${stats?.employees.active ?? 0} active · ${stats?.employees.new_this_month ?? 0} new`}
          icon={Users}
          gradient="bg-gradient-to-br from-blue-500 to-blue-700"
          iconBg="bg-blue-400/40"
          trend={stats?.employees.new_this_month ? `+${stats.employees.new_this_month} this month` : undefined}
          trendUp
          loading={loading}
          onClick={() => navigate('/employees')}
        />
        <GradientKpiCard
          title="Attendance Rate"
          value={loading ? '—' : `${stats?.attendance.attendance_rate ?? 0}%`}
          subtitle={`${stats?.attendance.present_today ?? 0} present · ${stats?.attendance.late_today ?? 0} late`}
          icon={Clock}
          gradient="bg-gradient-to-br from-emerald-500 to-emerald-700"
          iconBg="bg-emerald-400/40"
          trend={stats ? (stats.attendance.attendance_rate >= 90 ? 'On target' : 'Below target') : undefined}
          trendUp={stats ? stats.attendance.attendance_rate >= 90 : true}
          loading={loading}
          onClick={() => navigate('/attendance')}
        />
        <GradientKpiCard
          title="Pending Leave"
          value={stats?.leave.pending_requests ?? '—'}
          subtitle="Awaiting approval"
          icon={CalendarDays}
          gradient="bg-gradient-to-br from-amber-500 to-orange-600"
          iconBg="bg-amber-400/40"
          loading={loading}
          onClick={() => navigate('/leave')}
        />
        <GradientKpiCard
          title="Open Positions"
          value={stats?.recruitment.open_postings ?? '—'}
          subtitle={`${stats?.recruitment.in_pipeline ?? 0} in pipeline`}
          icon={UserPlus}
          gradient="bg-gradient-to-br from-violet-500 to-purple-700"
          iconBg="bg-violet-400/40"
          loading={loading}
          onClick={() => navigate('/recruitment')}
        />
      </div>

      {/* ── KPI Row 2: Finance & Performance ────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <GradientKpiCard
          title="Net Payroll"
          value={loading ? '—' : fmtCurrency(stats?.payroll.total_net_pay ?? 0)}
          subtitle={stats?.payroll.period_name ?? 'Current period'}
          icon={Wallet}
          gradient="bg-gradient-to-br from-rose-500 to-pink-700"
          iconBg="bg-rose-400/40"
          loading={loading}
          onClick={() => navigate('/payroll')}
        />
        <GradientKpiCard
          title="Performance"
          value={loading ? '—' : `${stats?.performance.avg_rating ?? 0}/5`}
          subtitle={`${stats?.performance.pending_reviews ?? 0} reviews pending`}
          icon={Star}
          gradient="bg-gradient-to-br from-yellow-400 to-amber-600"
          iconBg="bg-yellow-300/40"
          loading={loading}
          onClick={() => navigate('/performance')}
        />
        <GradientKpiCard
          title="Training"
          value={stats?.training.enrollments_this_month ?? '—'}
          subtitle={`${stats?.training.completed_this_month ?? 0} completed this month`}
          icon={GraduationCap}
          gradient="bg-gradient-to-br from-teal-500 to-cyan-700"
          iconBg="bg-teal-400/40"
          loading={loading}
          onClick={() => navigate('/training')}
        />
        <GradientKpiCard
          title="Pending Expenses"
          value={loading ? '—' : fmtCurrency(stats?.expenses.pending_amount ?? 0)}
          subtitle={`${stats?.expenses.pending_count ?? 0} claims`}
          icon={Calculator}
          gradient="bg-gradient-to-br from-slate-500 to-slate-700"
          iconBg="bg-slate-400/40"
          loading={loading}
          onClick={() => navigate('/expenses')}
        />
      </div>

      {/* ── KPI Row 3: Organization & Incidents ─────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <GradientKpiCard
          title="Departments"
          value={stats?.organization.total_departments ?? '—'}
          subtitle={`${stats?.organization.total_divisions ?? 0} divisions`}
          icon={Building2}
          gradient="bg-gradient-to-br from-indigo-500 to-indigo-700"
          iconBg="bg-indigo-400/40"
          loading={loading}
          onClick={() => navigate('/organization')}
        />
        <GradientKpiCard
          title="Business Units"
          value={stats?.organization.total_business_units ?? '—'}
          subtitle="Top level entities"
          icon={Network}
          gradient="bg-gradient-to-br from-sky-500 to-cyan-700"
          iconBg="bg-sky-400/40"
          loading={loading}
          onClick={() => navigate('/organization')}
        />
        <GradientKpiCard
          title="Active Incidents"
          value={stats?.incidents.active_count ?? '—'}
          subtitle="Awaiting resolution"
          icon={AlertTriangle}
          gradient="bg-gradient-to-br from-red-500 to-rose-700"
          iconBg="bg-red-400/40"
          loading={loading}
          onClick={() => {}}
        />
        <GradientKpiCard
          title="Total Incidents"
          value={stats?.incidents.total_count ?? '—'}
          subtitle={`${stats?.incidents.resolved_count ?? 0} resolved`}
          icon={Shield}
          gradient="bg-gradient-to-br from-slate-600 to-gray-800"
          iconBg="bg-slate-500/40"
          loading={loading}
          onClick={() => {}}
        />
      </div>

      {/* ── Row 4: Charts ────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <SectionCard title="Today's Attendance" description="Breakdown by status" icon={Activity}>
          <AttendanceDonut stats={stats} loading={loading} />
        </SectionCard>
        <SectionCard title="Headcount by Department" description="Active employees per department" icon={Building2}>
          <HeadcountChart data={headcount} loading={chartsLoading} />
        </SectionCard>
      </div>

      {/* ── Row 5: Payroll Trend + Quick Actions ─────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2">
          <SectionCard title="Payroll Trend" description="Gross vs net pay over recent periods" icon={Wallet}>
            <PayrollTrendChart data={payrollTrend} loading={chartsLoading} />
          </SectionCard>
        </div>
        <SectionCard title="Quick Actions" description="Common tasks" icon={Zap}>
          <div className="space-y-2">
            <QuickAction icon={FileText}     label="Run Payroll"        description="Start payroll for this month"   color="bg-rose-500"    onClick={() => navigate('/payroll')} />
            <QuickAction icon={UserPlus}     label="Add Employee"       description="Onboard a new team member"       color="bg-blue-500"    onClick={() => navigate('/employees')} />
            <QuickAction icon={CalendarDays} label="Leave Approvals"    description="Review pending leave requests"   color="bg-amber-500"   onClick={() => navigate('/mss')} />
            <QuickAction icon={ClipboardList} label="Timesheet Review"  description="Approve submitted timesheets"    color="bg-violet-500"  onClick={() => navigate('/mss')} />
            <QuickAction icon={Bell}         label="Announcements"      description="Post a company announcement"     color="bg-teal-500"    onClick={() => navigate('/governance/announcements')} />
            <QuickAction icon={Shield}       label="DSAR Requests"      description="Process data access requests"    color="bg-slate-500"   onClick={() => navigate('/compliance/dsar-admin')} />
          </div>
        </SectionCard>
      </div>

      {/* ── Row 6: Recruitment + Training + Incidents ───────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <SectionCard title="Recruitment Pipeline" description="Candidates by stage" icon={UserPlus}>
          <RecruitmentFunnelChart data={funnel} loading={chartsLoading} />
        </SectionCard>
        <SectionCard title="Training Status" description="Enrollment breakdown" icon={GraduationCap}>
          <TrainingPieChart data={trainData} loading={chartsLoading} />
        </SectionCard>
        <SectionCard title="Incident Reports" description="Incidents by status" icon={Shield}>
          <IncidentStatusPieChart data={incidentChart} loading={chartsLoading} />
        </SectionCard>
      </div>
      
      {/* ── Row 7: Module Health ───────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mt-5">
        <SectionCard title="Module Health" description="Key metrics at a glance" icon={BarChart3}>
          <div className="space-y-0.5">
            {loading
              ? Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-8 w-full my-1" />)
              : stats
              ? (
                <>
                  <StatusRow label="Payroll Period"      right={statusBadge(stats.payroll.current_period_status)} />
                  <StatusRow label="Leave Requests"      right={<Badge variant="secondary">{stats.leave.pending_requests} pending</Badge>} />
                  <StatusRow label="Active Loans"        right={<Badge variant="secondary">{stats.loans.active_count} active</Badge>} />
                  <StatusRow label="Pending Expenses"    right={<Badge variant="secondary">{stats.expenses.pending_count} claims</Badge>} />
                  <StatusRow label="Performance Rating"  right={<span className="text-sm font-semibold text-foreground">{stats.performance.avg_rating > 0 ? `${stats.performance.avg_rating}/5` : '—'}</span>} />
                  <StatusRow label="On Probation"        right={<Badge variant="outline">{stats.employees.probation}</Badge>} />
                </>
              )
              : null
            }
          </div>

          {/* Alerts */}
          {stats && (
            <div className="mt-4 space-y-0">
              {stats.leave.pending_requests > 10 && (
                <AlertItem icon={AlertCircle} title="High leave volume" subtitle={`${stats.leave.pending_requests} requests need approval`} color="bg-amber-50 text-amber-700 border border-amber-200" />
              )}
              {stats.attendance.attendance_rate < 85 && (
                <AlertItem icon={AlertCircle} title="Low attendance" subtitle={`${stats.attendance.attendance_rate}% — below 85% threshold`} color="bg-red-50 text-red-700 border border-red-200" />
              )}
              {stats.recruitment.open_postings > 0 && (
                <AlertItem icon={AlertCircle} title="Open positions" subtitle={`${stats.recruitment.open_postings} role${stats.recruitment.open_postings > 1 ? 's' : ''} actively recruiting`} color="bg-blue-50 text-blue-700 border border-blue-200" />
              )}
            </div>
          )}

          <Button
            variant="outline"
            size="sm"
            className="w-full mt-4 gap-1.5 text-primary border-primary/30 hover:bg-primary/5"
            onClick={() => navigate('/audit-log')}
          >
            <BarChart3 className="h-3.5 w-3.5" />
            View Audit Logs
            <ArrowRight className="h-3.5 w-3.5 ml-auto" />
          </Button>
        </SectionCard>
      </div>
    </div>
  );
}

