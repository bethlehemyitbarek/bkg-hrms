import { useState, useEffect, useCallback } from 'react';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { supabase as _supabase } from '@/db/supabase';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Plus, RefreshCw, Clock, Check, X, Timer } from 'lucide-react';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const supabase = _supabase as any;

type OvertimeRequest = {
  id: string;
  employee_id: string;
  requested_date: string;
  start_time: string;
  end_time: string;
  hours: number;
  reason: string;
  status: string;
  approved_by?: string | null;
  approved_at?: string | null;
  notes?: string | null;
  created_at: string;
  updated_at: string;
  employee?: { first_name: string; last_name: string; employee_no: string } | null;
};

const STATUS_COLORS: Record<string, string> = {
  pending:   'bg-yellow-100 text-yellow-800',
  approved:  'bg-green-100 text-green-800',
  rejected:  'bg-red-100 text-red-800',
  cancelled: 'bg-muted text-muted-foreground',
};

function calcHours(start: string, end: string): number {
  if (!start || !end) return 0;
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  const mins = (eh * 60 + em) - (sh * 60 + sm);
  return Math.max(0, Math.round((mins / 60) * 100) / 100);
}

export function OvertimePage() {
  const [requests, setRequests] = useState<OvertimeRequest[]>([]);
  const [loading, setLoading]   = useState(true);
  const [total, setTotal]       = useState(0);
  const [page, setPage]         = useState(1);
  const pageSize = 20;
  const [statusFilter, setStatusFilter] = useState('all');
  const [createOpen, setCreateOpen]     = useState(false);
  const [saving, setSaving]             = useState(false);
  const [stats, setStats] = useState({ pending: 0, approved: 0, total_hours: 0 });

  const [form, setForm] = useState({
    employee_id:    '',
    requested_date: new Date().toISOString().split('T')[0],
    start_time:     '',
    end_time:       '',
    reason:         '',
  });

  const computedHours = calcHours(form.start_time, form.end_time);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const from = (page - 1) * pageSize;
      const to   = from + pageSize - 1;
      let q = supabase
        .from('overtime_requests')
        .select(
          '*, employee:employees!overtime_requests_employee_id_fkey(first_name, last_name, employee_no)',
          { count: 'exact' }
        );
      if (statusFilter !== 'all') q = q.eq('status', statusFilter);
      const { data, error, count } = await q
        .order('requested_date', { ascending: false })
        .range(from, to);
      if (error) throw error;
      setRequests((data as OvertimeRequest[]) || []);
      setTotal(count || 0);
    } catch {
      toast.error('Failed to load overtime requests');
    } finally {
      setLoading(false);
    }
  }, [page, statusFilter]);

  const loadStats = useCallback(async () => {
    const { data } = await supabase
      .from('overtime_requests')
      .select('status, hours');
    const rows = data || [];
    setStats({
      pending:     rows.filter((r: OvertimeRequest) => r.status === 'pending').length,
      approved:    rows.filter((r: OvertimeRequest) => r.status === 'approved').length,
      total_hours: rows
        .filter((r: OvertimeRequest) => r.status === 'approved')
        .reduce((s: number, r: OvertimeRequest) => s + Number(r.hours || 0), 0),
    });
  }, []);

  useEffect(() => { load(); loadStats(); }, [load, loadStats]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.employee_id || form.employee_id === 'none') {
      toast.error('Please select an employee'); return;
    }
    if (!form.start_time || !form.end_time) {
      toast.error('Start and end time are required'); return;
    }
    const hours = calcHours(form.start_time, form.end_time);
    if (hours <= 0) { toast.error('End time must be after start time'); return; }
    setSaving(true);
    try {
      const { error } = await supabase.from('overtime_requests').insert({
        employee_id:    form.employee_id,
        requested_date: form.requested_date,
        start_time:     form.start_time,
        end_time:       form.end_time,
        hours,
        reason:  form.reason,
        status:  'pending',
      });
      if (error) throw error;
      toast.success('Overtime request created');
      setCreateOpen(false);
      setForm({ employee_id: '', requested_date: new Date().toISOString().split('T')[0], start_time: '', end_time: '', reason: '' });
      load(); loadStats();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to create');
    } finally {
      setSaving(false);
    }
  };

  const handleApprove = async (id: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    const payload: Record<string, unknown> = {
      status: 'approved',
      approved_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    if (user?.id) payload.approved_by = user.id;
    const { error } = await supabase.from('overtime_requests').update(payload).eq('id', id);
    if (error) { toast.error('Failed to approve'); return; }
    toast.success('Overtime request approved');
    load(); loadStats();
  };

  const handleReject = async (id: string) => {
    const { error } = await supabase
      .from('overtime_requests')
      .update({ status: 'rejected', updated_at: new Date().toISOString() })
      .eq('id', id);
    if (error) { toast.error('Failed to reject'); return; }
    toast.success('Overtime request rejected');
    load(); loadStats();
  };

  const fmtDate = (d: string) =>
    new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Overtime Requests</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} total requests</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => { load(); loadStats(); }}>
            <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
          </Button>
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button size="sm"><Plus className="h-4 w-4 mr-1.5" />New Request</Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>Create Overtime Request</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 mt-2">
                <EmployeeSelect
                  value={form.employee_id}
                  onChange={v => setForm(p => ({ ...p, employee_id: v }))}
                  required
                />
                <div className="space-y-1.5">
                  <Label>Requested Date *</Label>
                  <Input
                    type="date"
                    value={form.requested_date}
                    onChange={e => setForm(p => ({ ...p, requested_date: e.target.value }))}
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label>Start Time *</Label>
                    <Input
                      type="time"
                      value={form.start_time}
                      onChange={e => setForm(p => ({ ...p, start_time: e.target.value }))}
                      required
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>End Time *</Label>
                    <Input
                      type="time"
                      value={form.end_time}
                      onChange={e => setForm(p => ({ ...p, end_time: e.target.value }))}
                      required
                    />
                  </div>
                </div>
                {computedHours > 0 && (
                  <div className="flex items-center gap-2 text-sm bg-primary/5 border border-primary/20 rounded-lg px-3 py-2">
                    <Timer className="h-4 w-4 text-primary shrink-0" />
                    <span className="text-muted-foreground">Calculated OT:</span>
                    <span className="font-semibold text-foreground">{computedHours} hrs</span>
                  </div>
                )}
                <div className="space-y-1.5">
                  <Label>Reason *</Label>
                  <Textarea
                    value={form.reason}
                    onChange={e => setForm(p => ({ ...p, reason: e.target.value }))}
                    rows={3}
                    placeholder="Reason for overtime…"
                    required
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
                  <Button type="submit" disabled={saving}>{saving ? 'Submitting…' : 'Submit Request'}</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Pending',        value: stats.pending,     icon: Clock,  color: 'text-yellow-600' },
          { label: 'Approved',       value: stats.approved,    icon: Check,  color: 'text-green-600'  },
          { label: 'Approved Hours', value: `${stats.total_hours.toFixed(1)} hrs`, icon: Timer, color: 'text-primary' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-4 flex items-center gap-3">
            <s.icon className={`h-5 w-5 ${s.color} shrink-0`} />
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className="text-xl font-bold leading-tight">{s.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setPage(1); }}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Date</TableHead>
                <TableHead className="whitespace-nowrap">Start</TableHead>
                <TableHead className="whitespace-nowrap">End</TableHead>
                <TableHead className="whitespace-nowrap">Hours</TableHead>
                <TableHead className="whitespace-nowrap">Reason</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <TableRow key={i}>
                    {Array.from({ length: 8 }).map((__, j) => (
                      <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>
                    ))}
                  </TableRow>
                ))
              ) : requests.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-12 text-muted-foreground">
                    <Clock className="h-10 w-10 mx-auto mb-2 opacity-40" />
                    No overtime requests found
                  </TableCell>
                </TableRow>
              ) : requests.map(r => {
                const emp = r.employee;
                return (
                  <TableRow key={r.id}>
                    <TableCell className="whitespace-nowrap font-medium">
                      {emp ? `${emp.first_name} ${emp.last_name}` : r.employee_id.slice(0, 8)}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{fmtDate(r.requested_date)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm font-mono">{r.start_time.slice(0, 5)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm font-mono">{r.end_time.slice(0, 5)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm font-semibold">{Number(r.hours).toFixed(1)}</TableCell>
                    <TableCell className="text-sm max-w-[200px] truncate" title={r.reason}>{r.reason}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs capitalize ${STATUS_COLORS[r.status] ?? 'bg-muted text-muted-foreground'}`}>
                        {r.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {r.status === 'pending' && (
                        <div className="flex items-center gap-1">
                          <Button
                            size="sm" variant="outline"
                            className="h-7 px-2 text-green-600 border-green-200 hover:bg-green-50"
                            onClick={() => handleApprove(r.id)}
                          >
                            <Check className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            size="sm" variant="outline"
                            className="h-7 px-2 text-red-500 border-red-200 hover:bg-red-50"
                            onClick={() => handleReject(r.id)}
                          >
                            <X className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>

      {Math.ceil(total / pageSize) > 1 && (
        <div className="flex justify-end gap-2">
          <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</Button>
          <span className="text-sm self-center">{page} / {Math.ceil(total / pageSize)}</span>
          <Button size="sm" variant="outline" disabled={page >= Math.ceil(total / pageSize)} onClick={() => setPage(p => p + 1)}>Next</Button>
        </div>
      )}
    </div>
  );
}
