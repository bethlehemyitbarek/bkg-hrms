import { useState, useEffect, useCallback } from 'react';
import {
  Megaphone, Plus, Pencil, Trash2, RefreshCw,
  Send, Archive, Eye, AlertTriangle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { announcementService } from '@/services/announcement.service';
import type { Announcement, AnnouncementType, AnnouncementTargets, AnnouncementPriority, AnnouncementStatus } from '@/types/database.types';

const TYPE_COLORS: Record<AnnouncementType, string> = {
  INFORMATIVE: 'bg-blue-100 text-blue-800',
  EMERGENCY:   'bg-red-100 text-red-800',
  PERSONAL:    'bg-purple-100 text-purple-800',
};

const PRIORITY_COLORS: Record<AnnouncementPriority, string> = {
  LOW:    'bg-slate-100 text-slate-700',
  NORMAL: 'bg-slate-100 text-slate-700',
  HIGH:   'bg-amber-100 text-amber-800',
  URGENT: 'bg-red-100 text-red-800',
};

const STATUS_COLORS: Record<AnnouncementStatus, string> = {
  DRAFT:     'bg-slate-100 text-slate-600',
  PUBLISHED: 'bg-emerald-100 text-emerald-800',
  ARCHIVED:  'bg-slate-200 text-slate-500',
};

const BLANK = {
  title: '', description: '', type: 'INFORMATIVE' as AnnouncementType,
  targets: 'ALL' as AnnouncementTargets, priority: 'NORMAL' as AnnouncementPriority,
  expiry_date: '', announcement_status: 'DRAFT' as AnnouncementStatus,
};

export default function AnnouncementPage() {
  const [rows, setRows]           = useState<Announcement[]>([]);
  const [total, setTotal]         = useState(0);
  const [loading, setLoading]     = useState(false);
  const [page, setPage]           = useState(1);
  const pageSize                  = 20;

  const [filterStatus, setFilterStatus]   = useState('all');
  const [filterType, setFilterType]       = useState('all');
  const [filterPriority, setFilterPriority] = useState('all');

  const [dialogOpen, setDialogOpen]       = useState(false);
  const [editRow, setEditRow]             = useState<Announcement | null>(null);
  const [form, setForm]                   = useState({ ...BLANK });
  const [saving, setSaving]               = useState(false);

  const [viewRow, setViewRow]             = useState<Announcement | null>(null);
  const [deleteTarget, setDeleteTarget]   = useState<Announcement | null>(null);
  const [actionTarget, setActionTarget]   = useState<{ row: Announcement; action: 'publish' | 'archive' } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data, total: t } = await announcementService.list({
        announcement_status: filterStatus,
        type: filterType,
        priority: filterPriority,
        page,
        pageSize,
      });
      setRows(data as Announcement[]);
      setTotal(t);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to load announcements');
    } finally {
      setLoading(false);
    }
  }, [filterStatus, filterType, filterPriority, page]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setEditRow(null); setForm({ ...BLANK }); setDialogOpen(true); };
  const openEdit   = (r: Announcement) => {
    setEditRow(r);
    setForm({
      title: r.title, description: r.description ?? '',
      type: r.type, targets: r.targets, priority: r.priority,
      expiry_date: r.expiry_date ? r.expiry_date.slice(0, 10) : '',
      announcement_status: r.announcement_status,
    });
    setDialogOpen(true);
  };

  const save = async () => {
    if (!form.title.trim()) { toast.error('Title is required'); return; }
    setSaving(true);
    try {
      const payload = {
        ...form,
        expiry_date: form.expiry_date || null,
      };
      if (editRow) {
        await announcementService.update(editRow.id, payload);
        toast.success('Announcement updated');
      } else {
        await announcementService.create(payload);
        toast.success('Announcement created');
      }
      setDialogOpen(false);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleAction = async () => {
    if (!actionTarget) return;
    try {
      if (actionTarget.action === 'publish') {
        await announcementService.publish(actionTarget.row.id);
        toast.success('Announcement published');
      } else {
        await announcementService.archive(actionTarget.row.id);
        toast.success('Announcement archived');
      }
      setActionTarget(null);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Action failed');
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await announcementService.delete(deleteTarget.id);
      toast.success('Announcement deleted');
      setDeleteTarget(null);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Delete failed');
    }
  };

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <Megaphone className="h-5 w-5 text-primary" />
          <h1 className="text-xl font-semibold text-foreground">Announcements</h1>
          <Badge variant="secondary" className="ml-1">{total}</Badge>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${loading ? 'animate-spin' : ''}`} />Refresh
          </Button>
          <Button size="sm" onClick={openCreate}>
            <Plus className="h-3.5 w-3.5 mr-1.5" />New Announcement
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-4 pb-3">
          <div className="flex flex-wrap gap-3">
            <div className="flex items-center gap-2">
              <Label className="text-xs shrink-0">Status</Label>
              <Select value={filterStatus} onValueChange={v => { setFilterStatus(v); setPage(1); }}>
                <SelectTrigger className="h-8 w-32 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="DRAFT">Draft</SelectItem>
                  <SelectItem value="PUBLISHED">Published</SelectItem>
                  <SelectItem value="ARCHIVED">Archived</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Label className="text-xs shrink-0">Type</Label>
              <Select value={filterType} onValueChange={v => { setFilterType(v); setPage(1); }}>
                <SelectTrigger className="h-8 w-36 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="INFORMATIVE">Informative</SelectItem>
                  <SelectItem value="EMERGENCY">Emergency</SelectItem>
                  <SelectItem value="PERSONAL">Personal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Label className="text-xs shrink-0">Priority</Label>
              <Select value={filterPriority} onValueChange={v => { setFilterPriority(v); setPage(1); }}>
                <SelectTrigger className="h-8 w-28 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="LOW">Low</SelectItem>
                  <SelectItem value="NORMAL">Normal</SelectItem>
                  <SelectItem value="HIGH">High</SelectItem>
                  <SelectItem value="URGENT">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Announcement List</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="w-full overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Title</TableHead>
                  <TableHead className="whitespace-nowrap">Type</TableHead>
                  <TableHead className="whitespace-nowrap">Priority</TableHead>
                  <TableHead className="whitespace-nowrap">Targets</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Published At</TableHead>
                  <TableHead className="whitespace-nowrap">Expiry</TableHead>
                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 8 }).map((__, j) => (
                        <TableCell key={j}><Skeleton className="h-4 w-20 bg-muted" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : rows.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="py-16 text-center text-muted-foreground">
                      <Megaphone className="h-10 w-10 mx-auto mb-2 opacity-30" />
                      No announcements found
                    </TableCell>
                  </TableRow>
                ) : rows.map(r => (
                  <TableRow key={r.id}>
                    <TableCell className="whitespace-nowrap font-medium max-w-[220px] truncate">{r.title}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${TYPE_COLORS[r.type]}`}>{r.type}</Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${PRIORITY_COLORS[r.priority]}`}>{r.priority}</Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.targets}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${STATUS_COLORS[r.announcement_status]}`}>{r.announcement_status}</Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                      {r.published_at ? new Date(r.published_at).toLocaleDateString() : '—'}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                      {r.expiry_date ? new Date(r.expiry_date).toLocaleDateString() : '—'}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0" title="View" onClick={() => setViewRow(r)}>
                          <Eye className="h-3.5 w-3.5" />
                        </Button>
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0" title="Edit" onClick={() => openEdit(r)}>
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        {r.announcement_status === 'DRAFT' && (
                          <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-emerald-600" title="Publish"
                            onClick={() => setActionTarget({ row: r, action: 'publish' })}>
                            <Send className="h-3.5 w-3.5" />
                          </Button>
                        )}
                        {r.announcement_status === 'PUBLISHED' && (
                          <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-slate-500" title="Archive"
                            onClick={() => setActionTarget({ row: r, action: 'archive' })}>
                            <Archive className="h-3.5 w-3.5" />
                          </Button>
                        )}
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive" title="Delete"
                          onClick={() => setDeleteTarget(r)}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <p className="text-xs text-muted-foreground">
                {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, total)} of {total}
              </p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="h-7 text-xs" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</Button>
                <Button size="sm" variant="outline" className="h-7 text-xs" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create / Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editRow ? 'Edit Announcement' : 'New Announcement'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label>Title <span className="text-destructive">*</span></Label>
              <Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))}
                placeholder="Announcement title" maxLength={100} />
            </div>
            <div className="space-y-1.5">
              <Label>Description</Label>
              <Textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
                placeholder="Announcement details..." rows={4} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Type</Label>
                <Select value={form.type} onValueChange={v => setForm(p => ({ ...p, type: v as AnnouncementType }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="INFORMATIVE">Informative</SelectItem>
                    <SelectItem value="EMERGENCY">Emergency</SelectItem>
                    <SelectItem value="PERSONAL">Personal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Priority</Label>
                <Select value={form.priority} onValueChange={v => setForm(p => ({ ...p, priority: v as AnnouncementPriority }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="LOW">Low</SelectItem>
                    <SelectItem value="NORMAL">Normal</SelectItem>
                    <SelectItem value="HIGH">High</SelectItem>
                    <SelectItem value="URGENT">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Targets</Label>
                <Select value={form.targets} onValueChange={v => setForm(p => ({ ...p, targets: v as AnnouncementTargets }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ALL">All Employees</SelectItem>
                    <SelectItem value="DEPARTMENT">Department</SelectItem>
                    <SelectItem value="LOCATION">Location</SelectItem>
                    <SelectItem value="ROLE">Role</SelectItem>
                    <SelectItem value="CUSTOM">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Expiry Date</Label>
                <Input type="date" value={form.expiry_date}
                  onChange={e => setForm(p => ({ ...p, expiry_date: e.target.value }))} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Save'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      {viewRow && (
        <Dialog open={!!viewRow} onOpenChange={() => setViewRow(null)}>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Badge className={`text-xs ${TYPE_COLORS[viewRow.type]}`}>{viewRow.type}</Badge>
                <span className="text-balance">{viewRow.title}</span>
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-3 py-2">
              <div className="flex flex-wrap gap-2">
                <Badge className={`text-xs ${PRIORITY_COLORS[viewRow.priority]}`}>{viewRow.priority}</Badge>
                <Badge className={`text-xs ${STATUS_COLORS[viewRow.announcement_status]}`}>{viewRow.announcement_status}</Badge>
                <Badge variant="outline" className="text-xs">{viewRow.targets}</Badge>
              </div>
              {viewRow.description && (
                <p className="text-sm text-muted-foreground leading-relaxed text-pretty">{viewRow.description}</p>
              )}
              <div className="text-xs text-muted-foreground space-y-1 pt-1">
                {viewRow.published_at && <p>Published: {new Date(viewRow.published_at).toLocaleString()}</p>}
                {viewRow.expiry_date   && <p>Expires: {new Date(viewRow.expiry_date).toLocaleDateString()}</p>}
                <p>Created: {new Date(viewRow.created_at).toLocaleDateString()}</p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setViewRow(null)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Publish / Archive Confirm */}
      <AlertDialog open={!!actionTarget} onOpenChange={o => { if (!o) setActionTarget(null); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              {actionTarget?.action === 'publish' ? 'Publish Announcement?' : 'Archive Announcement?'}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {actionTarget?.action === 'publish'
                ? 'This will make the announcement visible to all targeted employees.'
                : 'This will hide the announcement from employees.'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleAction}>
              {actionTarget?.action === 'publish' ? 'Publish' : 'Archive'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={o => { if (!o) setDeleteTarget(null); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Announcement?</AlertDialogTitle>
            <AlertDialogDescription>
              <strong>"{deleteTarget?.title}"</strong> will be permanently removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
