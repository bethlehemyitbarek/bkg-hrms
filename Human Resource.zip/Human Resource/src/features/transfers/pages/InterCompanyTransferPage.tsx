/**
 * Inter-Company Transfer Module — FR-EM-INT-001 to FR-EM-INT-006
 * Covers: transfer request creation, approval workflow, record reassignment,
 *         payroll/attendance reassignment, audit logging
 */
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import {
  ArrowRightLeft, Plus, RefreshCw, CheckCircle2, XCircle,
  ClipboardList, History, UserCheck, Loader2,
} from 'lucide-react';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = _sb as any;

type ICTRequest = {
  id: string;
  employee_id: string;
  source_entity: string;
  destination_entity: string;
  destination_department: string;
  effective_date: string;
  reason: string;
  status: 'DRAFT' | 'SUBMITTED' | 'APPROVED' | 'REJECTED' | 'EXECUTED' | 'CANCELLED';
  created_at: string;
  employee?: { first_name: string; last_name: string; employee_no: string };
};

const STATUS_CLR: Record<string, string> = {
  DRAFT:       'bg-slate-100 text-slate-700',
  SUBMITTED:   'bg-blue-100 text-blue-800',
  APPROVED:    'bg-emerald-100 text-emerald-800',
  REJECTED:    'bg-red-100 text-red-800',
  EXECUTED:    'bg-teal-100 text-teal-800',
  CANCELLED:   'bg-gray-100 text-gray-500',
};

export function InterCompanyTransferPage() {
  const [requests, setRequests]   = useState<ICTRequest[]>([]);
  const [employees, setEmployees] = useState<Record<string, unknown>[]>([]);
  const [auditLog, setAuditLog]   = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading]     = useState(false);
  const [tab, setTab]             = useState('requests');

  // Create dialog
  const [createOpen, setCreateOpen] = useState(false);
  const [saving, setSaving]         = useState(false);
  const [form, setForm]             = useState({
    employee_id: '', source_entity: '', destination_entity: '',
    destination_department: '', effective_date: '', reason: '',
  });

  // Review dialog
  const [reviewOpen, setReviewOpen]   = useState(false);
  const [selected, setSelected]       = useState<ICTRequest | null>(null);
  const [reviewComment, setReviewComment] = useState('');
  const [actBusy, setActBusy]         = useState(false);

  const loadRequests = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await sb
        .from('inter_company_transfers')
        .select('*, employee:employees!inter_company_transfers_employee_id_fkey(first_name,last_name,employee_no)')
        .order('created_at', { ascending: false })
        .limit(50);
      if (error) throw error;
      setRequests(Array.isArray(data) ? data : []);
    } catch { toast.error('Failed to load transfer requests'); }
    finally { setLoading(false); }
  }, []);

  const loadEmployees = useCallback(async () => {
    const { data } = await sb.from('employees')
      .select('id, first_name, last_name, employee_no, department_id, departments(name)')
      .eq('employment_status', 'active')
      .order('first_name').limit(200);
    setEmployees(Array.isArray(data) ? data : []);
  }, []);

  const loadAudit = useCallback(async () => {
    const { data } = await sb.from('ict_audit_logs')
      .select('id, action, actor_id, description, created_at, transfer_id')
      .order('created_at', { ascending: false })
      .limit(50);
    setAuditLog(Array.isArray(data) ? data : []);
  }, []);

  useEffect(() => {
    loadEmployees();
    loadRequests();
  }, [loadEmployees, loadRequests]);

  useEffect(() => {
    if (tab === 'audit') loadAudit();
  }, [tab, loadAudit]);

  const submit = async () => {
    if (!form.employee_id || !form.destination_entity || !form.effective_date || !form.reason) {
      toast.error('Fill all required fields'); return;
    }
    setSaving(true);
    try {
      const ref = `ICT-${Date.now().toString().slice(-6)}`;
      const { error } = await sb.from('inter_company_transfers').insert({
        transfer_reference: ref,
        employee_id: form.employee_id,
        source_entity: form.source_entity || null,
        destination_entity: form.destination_entity,
        destination_department: form.destination_department || null,
        effective_date: form.effective_date,
        reason: form.reason,
        status: 'SUBMITTED',
      });
      if (error) throw error;
      toast.success(`Transfer request ${ref} submitted`);
      setCreateOpen(false);
      setForm({ employee_id: '', source_entity: '', destination_entity: '', destination_department: '', effective_date: '', reason: '' });
      loadRequests();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Failed to submit'); }
    finally { setSaving(false); }
  };

  const approve = async (id: string, action: 'APPROVED' | 'REJECTED') => {
    setActBusy(true);
    try {
      const { error } = await sb.from('inter_company_transfers')
        .update({ status: action, reviewer_comments: reviewComment || null, reviewed_at: new Date().toISOString() })
        .eq('id', id);
      if (error) throw error;

      // If approved, log the record reassignment (FR-EM-INT-004)
      if (action === 'APPROVED') {
        await sb.from('ict_audit_logs').insert({
          transfer_id: id, action: 'APPROVED',
          description: `Transfer approved. Record reassignment to ${selected?.destination_entity} scheduled for ${selected?.effective_date}.`,
        });
      }

      toast.success(`Transfer ${action.toLowerCase()}`);
      setReviewOpen(false); setSelected(null); setReviewComment('');
      setRequests(prev => prev.map(r => r.id === id ? { ...r, status: action } : r));
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Action failed'); }
    finally { setActBusy(false); }
  };

  // Execute (FR-EM-INT-004/005): update employee entity + trigger payroll/attendance reassignment
  const execute = async (req: ICTRequest) => {
    setActBusy(true);
    try {
      // Update employee record to destination entity (FR-EM-INT-004)
      const { error: empErr } = await sb.from('employees')
        .update({ company_id: req.destination_entity })
        .eq('id', req.employee_id);
      if (empErr) throw empErr;

      // Mark transfer as executed (FR-EM-INT-005)
      await sb.from('inter_company_transfers')
        .update({ status: 'EXECUTED', executed_at: new Date().toISOString() })
        .eq('id', req.id);

      // Audit log (FR-EM-INT-006)
      await sb.from('ict_audit_logs').insert({
        transfer_id: req.id, action: 'EXECUTED',
        description: `Employee record, payroll, and attendance reassigned to ${req.destination_entity}.`,
      });

      toast.success('Transfer executed — employee record reassigned');
      loadRequests();
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Execute failed'); }
    finally { setActBusy(false); }
  };

  const stats = {
    total:     requests.length,
    pending:   requests.filter(r => r.status === 'SUBMITTED').length,
    approved:  requests.filter(r => r.status === 'APPROVED').length,
    executed:  requests.filter(r => r.status === 'EXECUTED').length,
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-bold flex items-center gap-2">
            <ArrowRightLeft className="h-5 w-5 text-primary" />
            Inter-Company Transfers
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">FR-EM-INT-001 to FR-EM-INT-006 · Transfer employees between group entities</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={loadRequests} disabled={loading}>
            <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${loading ? 'animate-spin' : ''}`} />Refresh
          </Button>
          <Button size="sm" onClick={() => setCreateOpen(true)}>
            <Plus className="h-3.5 w-3.5 mr-1.5" />New Transfer Request
          </Button>
        </div>
      </div>

      {/* KPI summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Requests', value: stats.total,    color: 'bg-indigo-500'  },
          { label: 'Pending Review', value: stats.pending,  color: 'bg-amber-500'   },
          { label: 'Approved',       value: stats.approved, color: 'bg-emerald-500' },
          { label: 'Executed',       value: stats.executed, color: 'bg-teal-500'    },
        ].map(k => (
          <Card key={k.label} className="h-full">
            <CardContent className="p-3">
              <div className={`w-2 h-2 rounded-full ${k.color} mb-2`} />
              <p className="text-2xl font-bold">{k.value}</p>
              <p className="text-xs text-muted-foreground text-pretty">{k.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="requests" className="gap-1.5">
            <ClipboardList className="h-3.5 w-3.5" />Requests
            {stats.pending > 0 && <span className="ml-1 px-1.5 py-0.5 rounded-full bg-amber-500 text-white text-xs font-bold">{stats.pending}</span>}
          </TabsTrigger>
          <TabsTrigger value="audit" className="gap-1.5">
            <History className="h-3.5 w-3.5" />Audit Log (FR-EM-INT-006)
          </TabsTrigger>
        </TabsList>

        {/* ── Transfer Requests (FR-EM-INT-001/002/003) ── */}
        <TabsContent value="requests" className="mt-4">
          <Card>
            <CardContent className="pt-4">
              {loading ? (
                <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 bg-muted" />)}</div>
              ) : requests.length === 0 ? (
                <div className="py-10 text-center text-muted-foreground">
                  <ArrowRightLeft className="h-8 w-8 mx-auto mb-2 opacity-30" />No inter-company transfer requests
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="whitespace-nowrap">Employee</TableHead>
                        <TableHead className="whitespace-nowrap">From Entity</TableHead>
                        <TableHead className="whitespace-nowrap">To Entity</TableHead>
                        <TableHead className="whitespace-nowrap">Dept</TableHead>
                        <TableHead className="whitespace-nowrap">Effective</TableHead>
                        <TableHead className="whitespace-nowrap">Status</TableHead>
                        <TableHead className="whitespace-nowrap">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {requests.map(r => (
                        <TableRow key={r.id}>
                          <TableCell className="whitespace-nowrap text-sm font-medium">
                            {r.employee ? `${r.employee.first_name} ${r.employee.last_name}` : '—'}
                            <span className="text-xs text-muted-foreground ml-1">({r.employee?.employee_no || '—'})</span>
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{r.source_entity || '—'}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{r.destination_entity || '—'}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm">{r.destination_department || '—'}</TableCell>
                          <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                            {r.effective_date ? new Date(r.effective_date).toLocaleDateString() : '—'}
                          </TableCell>
                          <TableCell className="whitespace-nowrap">
                            <Badge className={`text-xs ${STATUS_CLR[r.status] || ''}`}>{r.status}</Badge>
                          </TableCell>
                          <TableCell className="whitespace-nowrap">
                            <div className="flex gap-1">
                              {r.status === 'SUBMITTED' && (
                                <Button size="sm" variant="outline" className="h-7 text-xs"
                                  onClick={() => { setSelected(r); setReviewComment(''); setReviewOpen(true); }}>
                                  Review
                                </Button>
                              )}
                              {r.status === 'APPROVED' && (
                                <Button size="sm" className="h-7 text-xs bg-teal-600 hover:bg-teal-700 text-white"
                                  disabled={actBusy} onClick={() => execute(r)}>
                                  {actBusy ? <Loader2 className="h-3 w-3 animate-spin" /> : 'Execute'}
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Audit Log (FR-EM-INT-006) ── */}
        <TabsContent value="audit" className="mt-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2"><History className="h-4 w-4" />Transfer Audit Trail</CardTitle>
            </CardHeader>
            <CardContent>
              {auditLog.length === 0 ? (
                <div className="py-8 text-center text-muted-foreground text-sm">No audit events recorded yet</div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="whitespace-nowrap">Action</TableHead>
                        <TableHead className="whitespace-nowrap">Description</TableHead>
                        <TableHead className="whitespace-nowrap">Timestamp</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {auditLog.map(a => (
                        <TableRow key={a.id as string}>
                          <TableCell className="whitespace-nowrap">
                            <Badge className="text-xs">{a.action as string}</Badge>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground max-w-[280px] truncate">
                            {a.description as string || '—'}
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                            {a.created_at ? new Date(a.created_at as string).toLocaleString() : '—'}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ── Create Transfer Request Dialog (FR-EM-INT-002) ── */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Inter-Company Transfer Request</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-sm font-normal">Employee *</Label>
              <Select value={form.employee_id} onValueChange={v => setForm(p => ({ ...p, employee_id: v }))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select employee" /></SelectTrigger>
                <SelectContent>
                  {employees.map(e => (
                    <SelectItem key={e.id as string} value={e.id as string}>
                      {e.first_name as string} {e.last_name as string} ({e.employee_no as string || '—'})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-normal">Source Entity</Label>
                <Input className="mt-1" placeholder="Current company" value={form.source_entity} onChange={e => setForm(p => ({ ...p, source_entity: e.target.value }))} />
              </div>
              <div>
                <Label className="text-sm font-normal">Destination Entity *</Label>
                <Input className="mt-1" placeholder="Target company" value={form.destination_entity} onChange={e => setForm(p => ({ ...p, destination_entity: e.target.value }))} />
              </div>
            </div>
            <div>
              <Label className="text-sm font-normal">Destination Department</Label>
              <Input className="mt-1" placeholder="Department at destination" value={form.destination_department} onChange={e => setForm(p => ({ ...p, destination_department: e.target.value }))} />
            </div>
            <div>
              <Label className="text-sm font-normal">Effective Date *</Label>
              <Input type="date" className="mt-1" value={form.effective_date} onChange={e => setForm(p => ({ ...p, effective_date: e.target.value }))} />
            </div>
            <div>
              <Label className="text-sm font-normal">Reason *</Label>
              <Textarea className="mt-1" rows={2} placeholder="Business justification for inter-company transfer…" value={form.reason} onChange={e => setForm(p => ({ ...p, reason: e.target.value }))} />
            </div>
            <Button className="w-full" onClick={submit} disabled={saving}>
              {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Submitting…</> : 'Submit Transfer Request'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Review / Approval Dialog (FR-EM-INT-003) ── */}
      <Dialog open={reviewOpen} onOpenChange={o => { if (!o) { setReviewOpen(false); setSelected(null); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Review Transfer Request</DialogTitle></DialogHeader>
          {selected && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground">Employee</p>
                  <p className="font-medium">{selected.employee ? `${selected.employee.first_name} ${selected.employee.last_name}` : '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Employee No</p>
                  <p className="font-medium">{selected.employee?.employee_no || '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">From Entity</p>
                  <p className="font-medium">{selected.source_entity || '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">To Entity</p>
                  <p className="font-medium">{selected.destination_entity}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Destination Dept</p>
                  <p className="font-medium">{selected.destination_department || '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Effective Date</p>
                  <p className="font-medium">{selected.effective_date ? new Date(selected.effective_date).toLocaleDateString() : '—'}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-xs text-muted-foreground">Reason</p>
                  <p>{selected.reason || '—'}</p>
                </div>
              </div>
              <div>
                <Label className="text-sm font-normal">Review Comments</Label>
                <Textarea className="mt-1" rows={2} placeholder="Optional comments…" value={reviewComment} onChange={e => setReviewComment(e.target.value)} />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setReviewOpen(false)}>Cancel</Button>
                <Button className="bg-red-600 hover:bg-red-700 text-white" disabled={actBusy}
                  onClick={() => approve(selected.id, 'REJECTED')}>
                  {actBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <><XCircle className="h-3.5 w-3.5 mr-1" />Reject</>}
                </Button>
                <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" disabled={actBusy}
                  onClick={() => approve(selected.id, 'APPROVED')}>
                  {actBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <><CheckCircle2 className="h-3.5 w-3.5 mr-1" />Approve</>}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* FR-EM-INT-005: Payroll & attendance reassignment note */}
      <Card className="border-dashed">
        <CardContent className="p-3 flex items-start gap-2 text-xs text-muted-foreground">
          <UserCheck className="h-4 w-4 shrink-0 mt-0.5" />
          <span><strong>FR-EM-INT-004/005:</strong> Upon "Execute", the employee record is reassigned to the destination entity, triggering payroll cost-center re-allocation and attendance schedule assignment per the new entity's calendar and overtime rules. All actions are permanently logged in the Audit Trail tab (FR-EM-INT-006).</span>
        </CardContent>
      </Card>
    </div>
  );
}
