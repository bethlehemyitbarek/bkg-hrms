import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { loginSuccess } from '@/app/store/slices/authSlice';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/shared/auth/useAuth';
import { supabase } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Loader2, Building2, AlertCircle, Shield, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';

type Mode = 'login' | 'register' | 'mfa';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [mode, setMode] = useState<Mode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [mfaCode, setMfaCode] = useState('');
  const [mfaFactorId, setMfaFactorId] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const clearError = () => setError('');

  /* ── Login ── */
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    setLoading(true);
    try {
      await login(email, password);
      // Check MFA requirement
      const { data: aal } = await (supabase as any).auth.mfa.getAuthenticatorAssuranceLevel();
      if (aal?.nextLevel === 'aal2' && aal?.currentLevel === 'aal1') {
        const { data: factors } = await (supabase as any).auth.mfa.listFactors();
        const totp = factors?.totp?.[0];
        if (totp) {
          setMfaFactorId(totp.id);
          setMode('mfa');
          setLoading(false);
          return;
        }
      }
      toast.success('Welcome back!');
      navigate('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  /* ── Register ── */
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    if (!agreed) { setError('Please agree to the User Agreement and Privacy Policy.'); return; }
    if (password !== confirmPassword) { setError('Passwords do not match.'); return; }
    if (password.length < 8) { setError('Password must be at least 8 characters.'); return; }
    setLoading(true);
    try {
      const { error: signUpError } = await (supabase as any).auth.signUp({ email, password });
      if (signUpError) throw signUpError;
      toast.success('Account created! You are now signed in.');
      navigate('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  /* ── MFA Verify ── */
  const handleMfa = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    setLoading(true);
    try {
      const { data: challenge } = await (supabase as any).auth.mfa.challenge({ factorId: mfaFactorId });
      const { error: verifyErr } = await (supabase as any).auth.mfa.verify({
        factorId: mfaFactorId,
        challengeId: challenge.id,
        code: mfaCode,
      });
      if (verifyErr) throw verifyErr;
      // Hydrate Redux with the elevated aal2 session
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        dispatch(loginSuccess({
          token: session.access_token,
          user: {
            id:       session.user.id,
            username: session.user.email?.split('@')[0] || '',
            email:    session.user.email || '',
            roles:    (session.user.user_metadata?.roles as string[]) || ['employee'],
          },
        }));
      }
      toast.success('MFA verified. Welcome back!');
      navigate('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invalid verification code.');
    } finally {
      setLoading(false);
    }
  };

  /* ── MFA Screen ── */
  if (mode === 'mfa') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
        <div className="w-full max-w-sm">
          <div className="bg-card border border-border rounded-xl shadow-sm p-8">
            <div className="flex flex-col items-center mb-6">
              <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-primary/10 mb-3">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h1 className="text-xl font-bold text-foreground">Two-Factor Verification</h1>
              <p className="text-sm text-muted-foreground mt-1 text-center text-balance">
                Enter the 6-digit code from your authenticator app
              </p>
            </div>
            <form onSubmit={handleMfa} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              <div className="space-y-1.5">
                <Label htmlFor="mfa-code">Verification Code</Label>
                <Input
                  id="mfa-code"
                  placeholder="000000"
                  maxLength={6}
                  value={mfaCode}
                  onChange={e => setMfaCode(e.target.value.replace(/\D/g, ''))}
                  className="text-center tracking-widest text-lg font-mono"
                  required
                  autoFocus
                  disabled={loading}
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading || mfaCode.length !== 6}>
                {loading ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Verifying…</> : 'Verify Code'}
              </Button>
              <button
                type="button"
                onClick={() => { setMode('login'); clearError(); setMfaCode(''); }}
                className="w-full text-sm text-muted-foreground hover:text-foreground transition-colors text-center"
              >
                ← Back to login
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <div className="w-full max-w-md">
        <div className="bg-card border border-border rounded-xl shadow-sm p-8">
          {/* Logo */}
          <div className="flex flex-col items-center mb-7">
            <div className="flex items-center justify-center w-14 h-14 rounded-xl bg-primary mb-4">
              <Building2 className="h-7 w-7 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">BKG HRMS</h1>
            <p className="text-sm text-muted-foreground mt-1">Human Resource Management System</p>
          </div>

          {/* Tab toggle */}
          <div className="flex bg-muted rounded-lg p-1 mb-6">
            {(['login', 'register'] as const).map(m => (
              <button
                key={m}
                type="button"
                onClick={() => { setMode(m); clearError(); }}
                className={`flex-1 text-sm font-medium py-1.5 rounded-md transition-colors ${
                  mode === m
                    ? 'bg-card shadow-sm text-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {m === 'login' ? 'Sign In' : 'Register'}
              </button>
            ))}
          </div>

          {mode === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              <div className="space-y-1.5">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@bkg.co.th"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  required
                  autoComplete="email"
                  disabled={loading}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    required
                    autoComplete="current-password"
                    disabled={loading}
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(p => !p)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Signing in…</> : 'Sign In'}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              <div className="space-y-1.5">
                <Label htmlFor="reg-email">Email Address</Label>
                <Input
                  id="reg-email"
                  type="email"
                  placeholder="you@bkg.co.th"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  required
                  disabled={loading}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="reg-password">Password</Label>
                <div className="relative">
                  <Input
                    id="reg-password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Min. 8 characters"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    required
                    minLength={8}
                    disabled={loading}
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(p => !p)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="confirm-password">Confirm Password</Label>
                <Input
                  id="confirm-password"
                  type="password"
                  placeholder="Repeat password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  required
                  disabled={loading}
                />
              </div>
              <div className="flex items-start gap-2.5 pt-1">
                <Checkbox
                  id="agree"
                  checked={agreed}
                  onCheckedChange={v => setAgreed(!!v)}
                  disabled={loading}
                  className="mt-0.5"
                />
                <label htmlFor="agree" className="text-sm text-muted-foreground leading-snug cursor-pointer">
                  I agree to the{' '}
                  <span className="text-primary underline">User Agreement</span>
                  {' '}and{' '}
                  <span className="text-primary underline">Privacy Policy</span>
                </label>
              </div>
              <Button type="submit" className="w-full" disabled={loading || !agreed}>
                {loading ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Creating account…</> : 'Create Account'}
              </Button>
            </form>
          )}

          <Separator className="my-5" />
          <p className="text-xs text-center text-muted-foreground">
            BKG Group — Internal HR Portal. Unauthorized access is prohibited.
          </p>
        </div>
      </div>
    </div>
  );
}
