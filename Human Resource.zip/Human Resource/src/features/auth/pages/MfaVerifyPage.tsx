import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { loginSuccess } from '@/app/store/slices/authSlice';
import { supabase } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Loader2, AlertCircle, KeyRound } from 'lucide-react';
import { toast } from 'sonner';

export default function MfaVerifyPage() {
  const navigate   = useNavigate();
  const dispatch   = useDispatch();
  const [code,     setCode]    = useState('');
  const [loading,  setLoading] = useState(false);
  const [error,    setError]   = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const mfa = (supabase as any).auth.mfa;

      const { data: factors } = await mfa.listFactors();
      const totp = factors?.totp?.[0];
      if (!totp) throw new Error('No MFA factor enrolled.');

      const { data: challenge } = await mfa.challenge({ factorId: totp.id });
      const { error: verifyErr } = await mfa.verify({
        factorId:    totp.id,
        challengeId: challenge.id,
        code,
      });
      if (verifyErr) throw verifyErr;

      // Hydrate Redux with the now-elevated session
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        dispatch(loginSuccess({
          token: session.access_token,
          user: {
            id:       session.user.id,
            username: session.user.email?.split('@')[0] || '',
            email:    session.user.email || '',
            roles:    (session.user.user_metadata?.roles as string[]) || ['employee'],
          },
        }));
      }

      toast.success('Identity verified. Welcome back!');
      navigate('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Verification failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <div className="w-full max-w-sm">
        <div className="bg-card border border-border rounded-xl shadow-sm p-8">
          {/* Header */}
          <div className="flex flex-col items-center mb-6">
            <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-primary/10 mb-3">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-xl font-bold text-foreground text-balance text-center">Two-Factor Verification</h1>
            <p className="text-sm text-muted-foreground mt-1 text-center text-pretty">
              Your account has two-factor authentication enabled. Enter the 6-digit code from your authenticator app to continue.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="mfa-code" className="flex items-center gap-1.5">
                <KeyRound className="h-3.5 w-3.5" />Authenticator Code
              </Label>
              <Input
                id="mfa-code"
                inputMode="numeric"
                placeholder="000000"
                maxLength={6}
                value={code}
                onChange={e => setCode(e.target.value.replace(/\D/g, ''))}
                className="text-center tracking-[0.4em] text-lg font-mono h-12"
                required
                autoFocus
                autoComplete="one-time-code"
                disabled={loading}
              />
              <p className="text-xs text-muted-foreground text-center">
                Open your authenticator app and enter the current code
              </p>
            </div>

            <Button
              type="submit"
              className="w-full h-10"
              disabled={loading || code.length !== 6}
            >
              {loading
                ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Verifying…</>
                : 'Verify & Continue'}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
