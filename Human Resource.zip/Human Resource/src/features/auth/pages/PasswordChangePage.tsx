import { useState } from 'react';
import { Input } from '@/shared/ui/Input/Input';
import { Button } from '@/shared/ui/Button/Button';

export default function PasswordChangePage() {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Password change simulated');
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-center mb-6">Change Password</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input label="Current Password" type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
        <Input label="New Password" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
        <Button type="submit" className="w-full">Update Password</Button>
      </form>
    </div>
  );
}
