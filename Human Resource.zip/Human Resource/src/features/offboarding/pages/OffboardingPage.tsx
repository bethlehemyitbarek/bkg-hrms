import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, LogOut, RefreshCw, Users, CheckCircle2, ClipboardList, Eye, Trash2, BarChart3, BookOpen, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line @typescript-eslint/no-explicit-any

const STATUS_COLORS: Record<string, string> = {
  initiated:   'bg-blue-100 text-blue-800',
  in_progress: 'bg-yellow-100 text-yellow-800',
  completed:   'bg-green-100 text-green-800',
  cancelled:   'bg-muted text-muted-foreground',
};

type Checklist = { id: string; name: string; description?: string; applicable_to?: string; is_active: boolean };
type Task = { id: string; checklist_id: string; title: string; description?: string; responsible?: string; due_days_before_last_day?: number; is_mandatory: boolean; sequence: number };
type Offboarding = {
  id: string; employee_id: string; checklist_id?: string;
  resignation_date?: string; last_working_date?: string;
  exit_interview_date?: string; exit_interview_done: boolean;
  clearance_it: boolean; clearance_finance: boolean; clearance_hr: boolean; clearance_assets: boolean;
  status: string; progress_percentage: number; reason?: string; notes?: string;
  employee?: { first_name: string; last_name: string; employee_no?: string };
  checklist?: Checklist & { tasks?: Task[] };
};
type Completion = { id: string; offboarding_id: string; task_id: string; completed: boolean; completed_at?: string };

const emptyForm = {
  employee_id: '', checklist_id: '', resignation_date: '', last_working_date: '',
  exit_interview_date: '', reason: '', notes: '', status: 'initiated',
};

export function OffboardingPage() {
  const [tab, setTab] = useState('records');
  const [records, setRecords] = useState<Offboarding[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [checklists, setChecklists] = useState<Checklist[]>([]);
  const [detail, setDetail] = useState<Offboarding | null>(null);
  const [completions, setCompletions] = useState<Completion[]>([]);
  const [completionsLoading, setCompletionsLoading] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ ...emptyForm });
  const [saving, setSaving] = useState(false);
  const [clDialog, setClDialog] = useState(false);
  const [clForm, setClForm] = useState({ name: '', description: '', applicable_to: 'all', is_active: true });
  const [clSaving, setClSaving] = useState(false);
  const [expandedCl, setExpandedCl] = useState<string | null>(null);
  const [addingTask, setAddingTask] = useState<string | null>(null);
  const [taskForm, setTaskForm] = useState({ title: '', responsible: '', due_days_before_last_day: '', is_mandatory: true, sequence: '' });
  const [taskSaving, setTaskSaving] = useState(false);
  const [clearanceSaving, setClearanceSaving] = useState<string | null>(null);

  const loadRecords = useCallback(async () => {
    setLoading(true);
    try {
      let q = sb.from('employee_offboarding')
        .select('*, employee:employees!employee_offboarding_employee_id_fkey(first_name,last_name,employee_no), checklist:offboarding_checklists(id,name,description,tasks:offboarding_tasks(*))')
        .order('created_at', { ascending: false });
      if (statusFilter !== 'all') q = q.eq('status', statusFilter);
      const { data, error } = await q;
      if (error) throw error;
      setRecords(data ?? []);
    } catch { toast.error('Failed to load offboarding records'); }
    finally { setLoading(false); }
  }, [statusFilter]);

  const loadChecklists = useCallback(async () => {
    try {
      const { data } = await sb.from('offboarding_checklists').select('*, tasks:offboarding_tasks(*)').order('name');
      setChecklists(Array.isArray(data) ? data : []);
    } catch { /* silent */ }
  }, []);

  const loadCompletions = useCallback(async (offboardingId: string) => {
    setCompletionsLoading(true);
    try {
      const { data } = await sb.from('offboarding_task_completions').select('*').eq('offboarding_id', offboardingId);
      setCompletions(Array.isArray(data) ? data : []);
    } catch { /* silent */ }
    finally { setCompletionsLoading(false); }
  }, []);

  useEffect(() => { loadRecords(); }, [loadRecords]);
  useEffect(() => { loadChecklists(); }, [loadChecklists]);
  useEffect(() => { if (detail?.id) loadCompletions(detail.id); }, [detail, loadCompletions]);

  const filtered = useMemo(() => {
    if (!search) return records;
    const s = search.toLowerCase();
    return records.filter(r => {
      const name = `${r.employee?.first_name ?? ''} ${r.employee?.last_name ?? ''}`.toLowerCase();
      return name.includes(s) || r.status.includes(s);
    });
  }, [records, search]);

  const handleCreate = async () => {
    if (!form.employee_id) { toast.error('Employee is required'); return; }
    setSaving(true);
    try {
      const { error } = await sb.from('employee_offboarding').insert({
        employee_id: form.employee_id,
        checklist_id: form.checklist_id || null,
        resignation_date: form.resignation_date || null,
        last_working_date: form.last_working_date || null,
        exit_interview_date: form.exit_interview_date || null,
        reason: form.reason || null,
        notes: form.notes || null,
        status: form.status,
        progress_percentage: 0,
      });
      if (error) throw error;
      toast.success('Offboarding record created');
      setCreateOpen(false);
      setForm({ ...emptyForm });
      loadRecords();
    } catch (e) { toast.error((e as Error).message); }
    finally { setSaving(false); }
  };

  const handleToggleTask = async (taskId: string) => {
    if (!detail) return;
    const existing = completions.find(c => c.task_id === taskId);
    try {
      if (existing) {
        const newCompleted = !existing.completed;
        await sb.from('offboarding_task_completions').update({
          completed: newCompleted,
          completed_at: newCompleted ? new Date().toISOString() : null,
        }).eq('id', existing.id);
        setCompletions(cs => cs.map(c => c.id === existing.id ? { ...c, completed: newCompleted } : c));
      } else {
        const { data } = await sb.from('offboarding_task_completions').insert({
          offboarding_id: detail.id, task_id: taskId, completed: true, completed_at: new Date().toISOString(),
        }).select('*').maybeSingle();
        if (data) setCompletions(cs => [...cs, data]);
      }
      const tasks = detail.checklist?.tasks ?? [];
      if (tasks.length > 0) {
        const doneCount = completions.filter(c => {
          if (c.task_id === taskId) return existing ? !existing.completed : true;
          return c.completed;
        }).length;
        const pct = Math.round((doneCount / tasks.length) * 100);
        const newStatus = pct === 100 ? 'completed' : pct > 0 ? 'in_progress' : 'initiated';
        await sb.from('employee_offboarding').update({ progress_percentage: pct, status: newStatus }).eq('id', detail.id);
        setDetail(d => d ? { ...d, progress_percentage: pct, status: newStatus } : d);
        setRecords(rs => rs.map(r => r.id === detail.id ? { ...r, progress_percentage: pct, status: newStatus } : r));
      }
    } catch { toast.error('Failed to update task'); }
  };

  const handleToggleClearance = async (field: string, currentVal: boolean) => {
    if (!detail) return;
    setClearanceSaving(field);
    try {
      await sb.from('employee_offboarding').update({ [field]: !currentVal }).eq('id', detail.id);
      const updated = { ...detail, [field]: !currentVal };
      setDetail(updated);
      setRecords(rs => rs.map(r => r.id === detail.id ? { ...r, [field]: !currentVal } : r));
    } catch { toast.error('Failed to update clearance'); }
    finally { setClearanceSaving(null); }
  };

  const handleDeleteTask = async (taskId: string) => {
    try {
      const { error } = await sb.from('offboarding_tasks').delete().eq('id', taskId);
      if (error) throw error;
      toast.success('Task deleted');
      loadChecklists();
    } catch (e) { toast.error((e as Error).message); }
  };

  const handleAddTask = async (checklistId: string, existingCount: number) => {
    if (!taskForm.title.trim()) { toast.error('Task title required'); return; }
    setTaskSaving(true);
    try {
      const { error } = await sb.from('offboarding_tasks').insert({
        checklist_id: checklistId,
        title: taskForm.title.trim(),
        responsible: taskForm.responsible || null,
        due_days_before_last_day: taskForm.due_days_before_last_day ? Number(taskForm.due_days_before_last_day) : null,
        is_mandatory: taskForm.is_mandatory,
        sequence: taskForm.sequence ? Number(taskForm.sequence) : existingCount + 1,
      });
      if (error) throw error;
      toast.success('Task added');
      setAddingTask(null);
      setTaskForm({ title: '', responsible: '', due_days_before_last_day: '', is_mandatory: true, sequence: '' });
      loadChecklists();
    } catch (e) { toast.error((e as Error).message); }
    finally { setTaskSaving(false); }
  };

  const handleCreateChecklist = async () => {
    if (!clForm.name) { toast.error('Name required'); return; }
    setClSaving(true);
    try {
      const { error } = await sb.from('offboarding_checklists').insert(clForm);
      if (error) throw error;
      toast.success('Checklist created');
      setClDialog(false);
      setClForm({ name: '', description: '', applicable_to: 'all', is_active: true });
      loadChecklists();
    } catch (e) { toast.error((e as Error).message); }
    finally { setClSaving(false); }
  };

  const stats = useMemo(() => ({
    total:      records.length,
    initiated:  records.filter(r => r.status === 'initiated').length,
    in_progress:records.filter(r => r.status === 'in_progress').length,
    completed:  records.filter(r => r.status === 'completed').length,
  }), [records]);

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <LogOut className="h-6 w-6 text-primary" />Offboarding
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage employee exit checklists, clearance, and exit interviews</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => { loadRecords(); loadChecklists(); }} className="gap-1.5">
            <RefreshCw className="h-4 w-4" />Refresh
          </Button>
          <Button size="sm" onClick={() => setCreateOpen(true)} className="gap-1.5">
            <Plus className="h-4 w-4" />New Offboarding
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total', value: stats.total, icon: Users, color: 'text-primary' },
          { label: 'Initiated', value: stats.initiated, icon: ClipboardList, color: 'text-blue-600' },
          { label: 'In Progress', value: stats.in_progress, icon: RefreshCw, color: 'text-yellow-600' },
          { label: 'Completed', value: stats.completed, icon: CheckCircle2, color: 'text-green-600' },
        ].map(s => (
          <Card key={s.label} className="h-full">
            <CardContent className="p-4 flex items-center gap-3">
              <s.icon className={`h-8 w-8 ${s.color} shrink-0`} />
              <div>
                <p className="text-2xl font-bold">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="h-9">
          <TabsTrigger value="records">Records</TabsTrigger>
          <TabsTrigger value="checklists">Checklist Templates</TabsTrigger>
          <TabsTrigger value="analytics" className="gap-1.5"><BarChart3 className="h-3.5 w-3.5" />Analytics</TabsTrigger>
          <TabsTrigger value="knowledge" className="gap-1.5"><BookOpen className="h-3.5 w-3.5" />Knowledge Transfer</TabsTrigger>
        </TabsList>

        <TabsContent value="records" className="mt-4 space-y-4">
          <div className="flex flex-wrap gap-3">
            <Input placeholder="Search employee…" value={search} onChange={e => setSearch(e.target.value)} className="max-w-xs h-9" />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-36 h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="initiated">Initiated</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="rounded-lg border border-border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Last Working Day</TableHead>
                  <TableHead className="whitespace-nowrap">Exit Interview</TableHead>
                  <TableHead className="whitespace-nowrap">Clearance</TableHead>
                  <TableHead className="whitespace-nowrap">Progress</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? Array.from({ length: 4 }).map((_, i) => (
                  <TableRow key={i}>{Array.from({ length: 7 }).map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>
                )) : filtered.length === 0 ? (
                  <TableRow><TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                    <LogOut className="h-10 w-10 mx-auto mb-2 opacity-40" />No offboarding records found
                  </TableCell></TableRow>
                ) : filtered.map(r => {
                  const cleared = [r.clearance_it, r.clearance_finance, r.clearance_hr, r.clearance_assets].filter(Boolean).length;
                  return (
                    <TableRow key={r.id}>
                      <TableCell className="whitespace-nowrap font-medium">
                        {r.employee ? `${r.employee.first_name} ${r.employee.last_name}` : r.employee_id.slice(0, 8)}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{r.last_working_date ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={r.exit_interview_done ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}>
                          {r.exit_interview_done ? 'Done' : 'Pending'}
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{cleared}/4</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex items-center gap-2 min-w-[100px]">
                          <Progress value={Number(r.progress_percentage) || 0} className="h-1.5 flex-1" />
                          <span className="text-xs text-muted-foreground shrink-0">{Number(r.progress_percentage) || 0}%</span>
                        </div>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={STATUS_COLORS[r.status] ?? 'bg-muted'}>{r.status.replace('_', ' ')}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="outline" size="sm" className="h-7 gap-1" onClick={() => setDetail(r)}>
                          <Eye className="h-3.5 w-3.5" />View
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="checklists" className="mt-4 space-y-4">
          <div className="flex justify-end">
            <Button size="sm" onClick={() => setClDialog(true)} className="gap-1.5">
              <Plus className="h-4 w-4" />New Checklist
            </Button>
          </div>
          {checklists.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">No checklist templates yet.</div>
          ) : (
            <div className="space-y-3">
              {checklists.map(cl => {
                const tasks = (cl as any).tasks as Task[] ?? [];
                const isExpanded = expandedCl === cl.id;
                const isAddingHere = addingTask === cl.id;
                return (
                  <Card key={cl.id} className="h-full">
                    <CardHeader className="pb-2 pt-4 px-4">
                      <div className="flex items-start justify-between gap-2">
                        <button className="flex-1 text-left" onClick={() => setExpandedCl(isExpanded ? null : cl.id)}>
                          <CardTitle className="text-base text-balance hover:text-primary transition-colors">{cl.name}</CardTitle>
                        </button>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <Badge className={cl.is_active ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}>
                            {cl.is_active ? 'Active' : 'Inactive'}
                          </Badge>
                          <Button size="sm" variant="outline" className="h-7 px-2 text-xs gap-1" onClick={() => { setAddingTask(isAddingHere ? null : cl.id); setExpandedCl(cl.id); }}>
                            <Plus className="h-3 w-3" />{isAddingHere ? 'Cancel' : 'Add Task'}
                          </Button>
                        </div>
                      </div>
                      {cl.description && <p className="text-xs text-muted-foreground text-pretty">{cl.description}</p>}
                    </CardHeader>
                    <CardContent className="px-4 pb-4">
                      <p className="text-xs text-muted-foreground mb-2 cursor-pointer hover:text-foreground" onClick={() => setExpandedCl(isExpanded ? null : cl.id)}>
                        {tasks.length} task{tasks.length !== 1 ? 's' : ''} {isExpanded ? '▲' : '▼'}
                      </p>
                      {isExpanded && (
                        <div className="space-y-1 mb-3">
                          {tasks.sort((a: Task, b: Task) => a.sequence - b.sequence).map((t: Task, i: number) => (
                            <div key={t.id} className="flex items-center gap-2 text-xs py-1 px-2 rounded bg-muted/40 group">
                              <span className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 font-medium text-[10px]">{i + 1}</span>
                              <span className="flex-1 min-w-0 truncate font-medium">{t.title}{t.is_mandatory && <span className="text-red-500 ml-0.5">*</span>}</span>
                              {t.responsible && <span className="text-muted-foreground shrink-0">👤 {t.responsible}</span>}
                              {t.due_days_before_last_day != null && <span className="text-muted-foreground shrink-0">{t.due_days_before_last_day}d before last day</span>}
                              <button
                                className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity p-0.5 rounded hover:bg-red-100 text-red-500"
                                title="Delete task"
                                onClick={() => handleDeleteTask(t.id)}
                              >
                                <Trash2 className="h-3 w-3" />
                              </button>
                            </div>
                          ))}
                          {tasks.length === 0 && <p className="text-xs text-muted-foreground py-2 text-center">No tasks yet. Add the first task below.</p>}
                        </div>
                      )}
                      {!isExpanded && tasks.length > 0 && (
                        <div className="space-y-1">
                          {tasks.slice(0, 3).map((t: Task, i: number) => (
                            <div key={t.id} className="flex items-center gap-2 text-xs">
                              <span className="w-4 h-4 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 font-medium">{i + 1}</span>
                              <span className="flex-1 min-w-0 truncate">{t.title}</span>
                              <span className="text-muted-foreground shrink-0">{t.responsible}</span>
                            </div>
                          ))}
                          {tasks.length > 3 && <p className="text-xs text-muted-foreground pl-6">+{tasks.length - 3} more tasks</p>}
                        </div>
                      )}
                      {/* ── Inline Add Task Form ── */}
                      {isAddingHere && (
                        <div className="mt-3 p-3 border border-dashed border-primary/40 rounded-lg bg-primary/5 space-y-2">
                          <p className="text-xs font-semibold text-primary">New Task</p>
                          <input
                            className="w-full h-8 px-2 text-sm rounded-md border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30"
                            placeholder="Task title *"
                            value={taskForm.title}
                            onChange={e => setTaskForm(f => ({ ...f, title: e.target.value }))}
                          />
                          <div className="grid grid-cols-2 gap-2">
                            <input
                              className="h-8 px-2 text-sm rounded-md border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30"
                              placeholder="Responsible (e.g. IT)"
                              value={taskForm.responsible}
                              onChange={e => setTaskForm(f => ({ ...f, responsible: e.target.value }))}
                            />
                            <input
                              type="number"
                              className="h-8 px-2 text-sm rounded-md border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30"
                              placeholder="Days before last day"
                              value={taskForm.due_days_before_last_day}
                              onChange={e => setTaskForm(f => ({ ...f, due_days_before_last_day: e.target.value }))}
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <label className="flex items-center gap-2 text-xs cursor-pointer">
                              <Checkbox checked={taskForm.is_mandatory} onCheckedChange={v => setTaskForm(f => ({ ...f, is_mandatory: !!v }))} />
                              Mandatory
                            </label>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => { setAddingTask(null); setTaskForm({ title: '', responsible: '', due_days_before_last_day: '', is_mandatory: true, sequence: '' }); }}>
                                Cancel
                              </Button>
                              <Button size="sm" className="h-7 text-xs" disabled={taskSaving} onClick={() => handleAddTask(cl.id, tasks.length)}>
                                {taskSaving ? '…' : 'Add'}
                              </Button>
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* ── FR-OFF-016: Offboarding Analytics ── */}
        <TabsContent value="analytics" className="mt-4">
          <OffboardingAnalyticsTab />
        </TabsContent>

        {/* ── FR-OFF-016: Knowledge Transfer ── */}
        <TabsContent value="knowledge" className="mt-4">
          <KnowledgeTransferTab />
        </TabsContent>

      </Tabs>

      {/* Create Dialog */}
      <Dialog open={createOpen} onOpenChange={o => { if (!o) { setCreateOpen(false); setForm({ ...emptyForm }); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Offboarding Record</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label>Employee *</Label>
              <EmployeeSelect value={form.employee_id} onChange={v => setForm(f => ({ ...f, employee_id: v }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Checklist Template</Label>
              <Select value={form.checklist_id} onValueChange={v => setForm(f => ({ ...f, checklist_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Select checklist…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {checklists.filter(c => c.is_active).map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Resignation Date</Label>
                <Input type="date" value={form.resignation_date} onChange={e => setForm(f => ({ ...f, resignation_date: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Last Working Day</Label>
                <Input type="date" value={form.last_working_date} onChange={e => setForm(f => ({ ...f, last_working_date: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Exit Interview Date</Label>
              <Input type="date" value={form.exit_interview_date} onChange={e => setForm(f => ({ ...f, exit_interview_date: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Reason</Label>
              <Select value={form.reason} onValueChange={v => setForm(f => ({ ...f, reason: v }))}>
                <SelectTrigger><SelectValue placeholder="Select reason…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="resignation">Resignation</SelectItem>
                  <SelectItem value="retirement">Retirement</SelectItem>
                  <SelectItem value="termination">Termination</SelectItem>
                  <SelectItem value="contract_end">Contract End</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Textarea rows={2} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={saving}>{saving ? 'Creating…' : 'Create'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={!!detail} onOpenChange={o => { if (!o) setDetail(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          {detail && (
            <>
              <DialogHeader>
                <DialogTitle>
                  {detail.employee ? `${detail.employee.first_name} ${detail.employee.last_name}` : 'Offboarding'}
                  {detail.last_working_date ? ` — Last Day: ${detail.last_working_date}` : ''}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-2 max-h-[70vh] overflow-y-auto pr-1">
                {/* Progress */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Overall Progress</span>
                    <span className="text-muted-foreground">{Number(detail.progress_percentage) || 0}%</span>
                  </div>
                  <Progress value={Number(detail.progress_percentage) || 0} className="h-2" />
                  <Badge className={STATUS_COLORS[detail.status] ?? 'bg-muted'}>{detail.status.replace('_', ' ')}</Badge>
                </div>

                {/* Clearance */}
                <div className="space-y-2">
                  <p className="text-sm font-medium">Clearance Status</p>
                  <div className="grid grid-cols-2 gap-2">
                    {([
                      { field: 'clearance_it', label: 'IT' },
                      { field: 'clearance_finance', label: 'Finance' },
                      { field: 'clearance_hr', label: 'HR' },
                      { field: 'clearance_assets', label: 'Assets' },
                    ] as { field: keyof Offboarding; label: string }[]).map(({ field, label }) => (
                      <div key={field} className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer ${detail[field] ? 'bg-green-50 border-green-200 dark:bg-green-900/10 dark:border-green-900' : 'bg-card border-border'}`}
                        onClick={() => handleToggleClearance(field, detail[field] as boolean)}>
                        <Checkbox
                          checked={detail[field] as boolean}
                          disabled={clearanceSaving === field}
                          onCheckedChange={() => handleToggleClearance(field, detail[field] as boolean)}
                        />
                        <span className="text-sm font-medium">{label}</span>
                        {detail[field] && <CheckCircle2 className="h-3.5 w-3.5 text-green-600 ml-auto" />}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Exit interview */}
                <div className="flex items-center justify-between p-3 rounded-lg border border-border bg-card">
                  <div>
                    <p className="text-sm font-medium">Exit Interview</p>
                    {detail.exit_interview_date && <p className="text-xs text-muted-foreground">Scheduled: {detail.exit_interview_date}</p>}
                  </div>
                  <Badge className={detail.exit_interview_done ? 'bg-green-100 text-green-800' : 'bg-muted text-muted-foreground'}>
                    {detail.exit_interview_done ? 'Completed' : 'Pending'}
                  </Badge>
                </div>

                {/* Checklist tasks */}
                {detail.checklist && (
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Checklist: {detail.checklist.name}</p>
                    {completionsLoading ? (
                      <div className="space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-10 rounded" />)}</div>
                    ) : (
                      (detail.checklist.tasks ?? []).sort((a, b) => a.sequence - b.sequence).map(task => {
                        const comp = completions.find(c => c.task_id === task.id);
                        const done = comp?.completed ?? false;
                        return (
                          <div key={task.id} className={`flex items-start gap-3 p-3 rounded-lg border ${done ? 'bg-green-50/50 border-green-200 dark:bg-green-900/10 dark:border-green-800' : 'bg-card border-border'}`}>
                            <Checkbox id={`off-${task.id}`} checked={done} onCheckedChange={() => handleToggleTask(task.id)} className="mt-0.5" />
                            <div className="flex-1 min-w-0">
                              <label htmlFor={`off-${task.id}`} className={`text-sm font-medium cursor-pointer ${done ? 'line-through text-muted-foreground' : ''}`}>
                                {task.title}
                                {task.is_mandatory && <span className="text-red-500 ml-1">*</span>}
                              </label>
                              <div className="flex gap-3 mt-0.5 text-xs text-muted-foreground">
                                {task.responsible && <span>👤 {task.responsible}</span>}
                                {task.due_days_before_last_day != null && <span>📅 {task.due_days_before_last_day} days before last day</span>}
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                )}

                {detail.reason && (
                  <div className="bg-muted/40 rounded-lg p-3 text-sm">
                    <p className="text-xs text-muted-foreground mb-1">Reason</p>
                    <p>{detail.reason}</p>
                  </div>
                )}
                {detail.notes && (
                  <div className="bg-muted/40 rounded-lg p-3 text-sm">
                    <p className="text-xs text-muted-foreground mb-1">Notes</p>
                    <p>{detail.notes}</p>
                  </div>
                )}
                <div className="flex justify-end pt-1">
                  <Button variant="outline" onClick={() => setDetail(null)}>Close</Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* New Checklist Dialog */}
      <Dialog open={clDialog} onOpenChange={o => { if (!o) setClDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>New Offboarding Checklist</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label>Name *</Label>
              <Input value={clForm.name} onChange={e => setClForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Description</Label>
              <Textarea rows={2} value={clForm.description} onChange={e => setClForm(f => ({ ...f, description: e.target.value }))} />
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setClDialog(false)}>Cancel</Button>
              <Button onClick={handleCreateChecklist} disabled={clSaving}>{clSaving ? 'Saving…' : 'Create'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-OFF-016 – Offboarding Analytics
   ───────────────────────────────────────────────────────────────────────── */
function OffboardingAnalyticsTab() {
  const [stats, setStats] = useState({ total: 0, completed: 0, inProgress: 0, avgDays: 0 });
  const [byReason, setByReason] = useState<{ reason: string; count: number }[]>([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('offboarding_records').select('status, exit_reason, last_working_day, created_at').limit(500);
    if (data) {
      const total = data.length;
      const completed = data.filter((r: Record<string, unknown>) => r.status === 'completed').length;
      const inProgress = data.filter((r: Record<string, unknown>) => r.status === 'in_progress').length;
      const daysArr = (data as Record<string, unknown>[]).filter(r => r.last_working_day && r.created_at).map(r => {
        const d = (new Date(String(r.last_working_day)).getTime() - new Date(String(r.created_at)).getTime()) / 86400000;
        return d > 0 ? d : 0;
      });
      const avgDays = daysArr.length ? Math.round(daysArr.reduce((s, d) => s + d, 0) / daysArr.length) : 0;
      const reasonMap: Record<string, number> = {};
      for (const r of data as Record<string, unknown>[]) { const k = String(r.exit_reason || 'Not Specified'); reasonMap[k] = (reasonMap[k] || 0) + 1; }
      setStats({ total, completed, inProgress, avgDays });
      setByReason(Object.entries(reasonMap).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([reason, count]) => ({ reason, count })));
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Offboardings', value: stats.total, color: 'text-foreground' },
          { label: 'Completed', value: stats.completed, color: 'text-green-700' },
          { label: 'In Progress', value: stats.inProgress, color: 'text-blue-700' },
          { label: 'Avg. Days to Complete', value: `${stats.avgDays}d`, color: 'text-primary' },
        ].map(s => (
          <Card key={s.label} className="h-full">
            <CardContent className="pt-4 pb-4">
              {loading ? <Skeleton className="h-10 bg-muted" /> : (
                <><p className={`text-2xl font-bold ${s.color}`}>{s.value}</p><p className="text-xs text-muted-foreground mt-1">{s.label}</p></>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">Exits by Reason</CardTitle></CardHeader>
        <CardContent>
          {loading ? <Skeleton className="h-32 bg-muted" /> : byReason.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">No data available</p>
          ) : (
            <div className="space-y-2">
              {byReason.map((r, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-xs w-4 text-muted-foreground shrink-0">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm font-medium truncate">{r.reason}</p>
                      <span className="text-xs text-muted-foreground ml-2 shrink-0">{r.count}</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                      <div className="h-full bg-primary rounded-full" style={{ width: `${Math.round((r.count / (byReason[0]?.count || 1)) * 100)}%` }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-OFF-016 – Knowledge Transfer
   ───────────────────────────────────────────────────────────────────────── */
type KTRow = { kt_id?: string; offboarding_id?: string; employee_name?: string; topic: string; transferee?: string; transfer_date?: string; format?: string; status?: string; notes?: string };

function KnowledgeTransferTab() {
  const [rows, setRows] = useState<KTRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ employee_name: '', topic: '', transferee: '', transfer_date: '', format: 'DOCUMENT', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await sb.from('knowledge_transfer').select('*').order('transfer_date', { ascending: false }).limit(100);
    setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.topic.trim()) { toast.error('Topic is required'); return; }
    setSaving(true);
    const { error } = await sb.from('knowledge_transfer').insert({ employee_name: form.employee_name || null, topic: form.topic, transferee: form.transferee || null, transfer_date: form.transfer_date || new Date().toISOString().slice(0, 10), format: form.format, notes: form.notes || null, status: 'PENDING' });
    if (error) toast.error(error.message); else { toast.success('Knowledge transfer logged'); setOpen(false); load(); }
    setSaving(false);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><BookOpen className="h-4 w-4" />Knowledge Transfer (FR-OFF-016)</CardTitle>
          <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5 mr-1" />Log Transfer</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-24 bg-muted" /> : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Topic</TableHead>
                <TableHead className="whitespace-nowrap">Transferee</TableHead>
                <TableHead className="whitespace-nowrap">Format</TableHead>
                <TableHead className="whitespace-nowrap">Date</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-6 text-sm">No knowledge transfers logged</TableCell></TableRow>}
                {rows.map((r, i) => (
                  <TableRow key={r.kt_id || i}>
                    <TableCell className="whitespace-nowrap">{r.employee_name || '—'}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">{r.topic}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.transferee || '—'}</TableCell>
                    <TableCell><Badge variant="outline">{r.format || '—'}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap">{r.transfer_date || '—'}</TableCell>
                    <TableCell><Badge className={r.status === 'COMPLETED' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>{r.status || 'PENDING'}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Log Knowledge Transfer</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Departing Employee</Label><Input value={form.employee_name} onChange={e => setForm(p => ({ ...p, employee_name: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>Transferee</Label><Input value={form.transferee} onChange={e => setForm(p => ({ ...p, transferee: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Topic *</Label><Input value={form.topic} onChange={e => setForm(p => ({ ...p, topic: e.target.value }))} placeholder="e.g. System admin credentials, Client contacts…" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Format</Label>
                <Select value={form.format} onValueChange={v => setForm(p => ({ ...p, format: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DOCUMENT">Document</SelectItem>
                    <SelectItem value="MEETING">Meeting / Handover</SelectItem>
                    <SelectItem value="VIDEO">Video Recording</SelectItem>
                    <SelectItem value="SHADOWING">Job Shadowing</SelectItem>
                    <SelectItem value="WIKI">Wiki / Confluence</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Transfer Date</Label><Input type="date" value={form.transfer_date} onChange={e => setForm(p => ({ ...p, transfer_date: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Notes</Label><Textarea rows={2} value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
