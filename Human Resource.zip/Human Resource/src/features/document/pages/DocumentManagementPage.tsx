import { useState, useEffect, useCallback } from 'react';
import {
  FolderOpen, Plus, Pencil, Trash2, RefreshCw, History,
  Files, Tag, Settings2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import {
  documentCategoryService,
  documentTypeConfigService,
  hrDocumentService,
} from '@/services/document-management.service';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Row = Record<string, any>;

function fmtDate(v?: string | null) {
  if (!v) return '—';
  return new Date(v).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

const SKEL = (cols: number, rows = 5) =>
  Array.from({ length: rows }).map((_, i) => (
    <TableRow key={i}>
      {Array.from({ length: cols }).map((__, j) => (
        <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>
      ))}
    </TableRow>
  ));

const EMPTY = (cols: number, msg: string) => (
  <TableRow>
    <TableCell colSpan={cols} className="text-center py-12 text-muted-foreground text-sm">{msg}</TableCell>
  </TableRow>
);

const REVIEW_COLORS: Record<string, string> = {
  PENDING:  'bg-yellow-100 text-yellow-700',
  VERIFIED: 'bg-blue-100 text-blue-700',
  APPROVED: 'bg-green-100 text-green-700',
  REJECTED: 'bg-red-100 text-red-700',
};

const CONF_COLORS: Record<string, string> = {
  PUBLIC:       'bg-green-100 text-green-700',
  INTERNAL:     'bg-blue-100 text-blue-700',
  CONFIDENTIAL: 'bg-orange-100 text-orange-700',
  RESTRICTED:   'bg-red-100 text-red-700',
};

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 1 — Documents
// ═══════════════════════════════════════════════════════════════════════════════
function DocumentsTab({
  categories,
  typeConfigs,
}: {
  categories: Row[];
  typeConfigs: Row[];
}) {
  const [rows, setRows]           = useState<Row[]>([]);
  const [loading, setLoading]     = useState(true);
  const [total, setTotal]         = useState(0);
  const [ownerFilter, setOwnerFilter]   = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [catFilter, setCatFilter]       = useState('all');
  const [open, setOpen]           = useState(false);
  const [editing, setEditing]     = useState<Row | null>(null);
  const [deleting, setDeleting]   = useState<Row | null>(null);
  const [histTarget, setHistTarget] = useState<Row | null>(null);
  const [versions, setVersions]   = useState<Row[]>([]);
  const [saving, setSaving]       = useState(false);
  const [form, setForm]           = useState({
    owner_type: 'EMPLOYEE', owner_id: '',
    document_name: '', document_type_id: '', category_id: '',
    file_name: '', file_path: '', file_hash: '', mime_type: 'application/pdf',
    version_no: '1', review_status: 'PENDING', tags: '', expiry_date: '',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await hrDocumentService.list({
        owner_type:    ownerFilter !== 'all' ? ownerFilter : undefined,
        review_status: statusFilter !== 'all' ? statusFilter : undefined,
        category_id:   catFilter !== 'all' ? catFilter : undefined,
        page: 1, pageSize: 50,
      });
      setRows(r.data); setTotal(r.total);
    } catch { toast.error('Failed to load documents'); }
    finally { setLoading(false); }
  }, [ownerFilter, statusFilter, catFilter]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm({ owner_type: 'EMPLOYEE', owner_id: '', document_name: '', document_type_id: '', category_id: '', file_name: '', file_path: '', file_hash: '', mime_type: 'application/pdf', version_no: '1', review_status: 'PENDING', tags: '', expiry_date: '' });
    setOpen(true);
  };
  const openEdit = (r: Row) => {
    setEditing(r);
    setForm({
      owner_type: r.owner_type ?? 'EMPLOYEE', owner_id: r.owner_id ?? '',
      document_name: r.document_name ?? '', document_type_id: r.document_type_id ?? '',
      category_id: r.category_id ?? '', file_name: r.file_name ?? '',
      file_path: r.file_path ?? '', file_hash: r.file_hash ?? '',
      mime_type: r.mime_type ?? 'application/pdf', version_no: String(r.version_no ?? 1),
      review_status: r.review_status ?? 'PENDING', tags: r.tags ?? '', expiry_date: r.expiry_date ?? '',
    });
    setOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.document_name || !form.file_name || !form.file_path) { toast.error('Name, file name, and file path are required'); return; }
    setSaving(true);
    try {
      const payload = {
        ...form,
        version_no: Number(form.version_no) || 1,
        document_type_id: form.document_type_id || null,
        category_id:      form.category_id || null,
        expiry_date:      form.expiry_date || null,
        tags:             form.tags || null,
        file_hash:        form.file_hash || 'placeholder',
      };
      if (editing) await hrDocumentService.update(editing.document_id, payload);
      else await hrDocumentService.create(payload);
      toast.success(editing ? 'Document updated' : 'Document created');
      setOpen(false); load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  const loadVersions = async (r: Row) => {
    setHistTarget(r);
    try {
      const v = await hrDocumentService.listVersions(r.document_id);
      setVersions(v);
    } catch { toast.error('Failed to load version history'); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <p className="text-sm text-muted-foreground">{total} documents</p>
        <div className="flex items-center gap-2 flex-wrap">
          <Select value={ownerFilter} onValueChange={setOwnerFilter}>
            <SelectTrigger className="h-8 w-32 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Owner Types</SelectItem>
              <SelectItem value="EMPLOYEE">Employee</SelectItem>
              <SelectItem value="CANDIDATE">Candidate</SelectItem>
              <SelectItem value="ONBOARDING">Onboarding</SelectItem>
              <SelectItem value="GUARANTOR">Guarantor</SelectItem>
              <SelectItem value="TRAINING">Training</SelectItem>
              <SelectItem value="OTHER">Other</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-8 w-32 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="PENDING">Pending</SelectItem>
              <SelectItem value="VERIFIED">Verified</SelectItem>
              <SelectItem value="APPROVED">Approved</SelectItem>
              <SelectItem value="REJECTED">Rejected</SelectItem>
            </SelectContent>
          </Select>
          <Select value={catFilter} onValueChange={setCatFilter}>
            <SelectTrigger className="h-8 w-36 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(c => <SelectItem key={c.category_id} value={c.category_id}>{c.category_name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button size="sm" className="h-8" onClick={openCreate}><Plus className="h-3.5 w-3.5 mr-1" />Add Document</Button>
          <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={load}><RefreshCw className="h-3.5 w-3.5" /></Button>
        </div>
      </div>

      <div className="rounded border border-border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="text-xs">
              <TableHead className="whitespace-nowrap">Name</TableHead>
              <TableHead className="whitespace-nowrap">Owner Type</TableHead>
              <TableHead className="whitespace-nowrap">Category</TableHead>
              <TableHead className="whitespace-nowrap">Type</TableHead>
              <TableHead className="whitespace-nowrap">Version</TableHead>
              <TableHead className="whitespace-nowrap">Review</TableHead>
              <TableHead className="whitespace-nowrap">Expiry</TableHead>
              <TableHead className="whitespace-nowrap w-24">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? SKEL(8) : rows.length === 0 ? EMPTY(8, 'No documents found') : rows.map(r => (
              <TableRow key={r.document_id} className="text-sm">
                <TableCell className="whitespace-nowrap font-medium max-w-[180px] truncate">{r.document_name || '—'}</TableCell>
                <TableCell className="whitespace-nowrap text-xs">{r.owner_type || '—'}</TableCell>
                <TableCell className="whitespace-nowrap text-xs">{r.category?.category_name || '—'}</TableCell>
                <TableCell className="whitespace-nowrap text-xs">{r.doc_type?.type_name || '—'}</TableCell>
                <TableCell className="whitespace-nowrap text-center text-xs">v{r.version_no}</TableCell>
                <TableCell className="whitespace-nowrap"><Badge className={`text-xs ${REVIEW_COLORS[r.review_status] ?? 'bg-muted'}`}>{r.review_status}</Badge></TableCell>
                <TableCell className="whitespace-nowrap text-xs">{fmtDate(r.expiry_date)}</TableCell>
                <TableCell className="whitespace-nowrap">
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => loadVersions(r)} title="Version history"><History className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleting(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Create / Edit */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editing ? 'Edit Document' : 'Add Document'}</DialogTitle></DialogHeader>
          <form onSubmit={handleSave} className="space-y-4 py-1">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Owner Type</Label>
                <Select value={form.owner_type} onValueChange={v => setForm(p => ({ ...p, owner_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="EMPLOYEE">Employee</SelectItem>
                    <SelectItem value="CANDIDATE">Candidate</SelectItem>
                    <SelectItem value="ONBOARDING">Onboarding</SelectItem>
                    <SelectItem value="GUARANTOR">Guarantor</SelectItem>
                    <SelectItem value="TRAINING">Training</SelectItem>
                    <SelectItem value="OTHER">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                {form.owner_type === 'EMPLOYEE' ? (
                  <><Label>Employee</Label><EmployeeSelect value={form.owner_id} onChange={v => setForm(p => ({ ...p, owner_id: v }))} /></>
                ) : (
                  <><Label>Owner ID</Label><Input value={form.owner_id} onChange={e => setForm(p => ({ ...p, owner_id: e.target.value }))} placeholder="UUID" /></>
                )}
              </div>
              <div className="space-y-1.5 col-span-2"><Label>Document Name <span className="text-destructive">*</span></Label><Input value={form.document_name} onChange={e => setForm(p => ({ ...p, document_name: e.target.value }))} required /></div>
              <div className="space-y-1.5">
                <Label>Category</Label>
                <Select value={form.category_id || 'none'} onValueChange={v => setForm(p => ({ ...p, category_id: v === 'none' ? '' : v }))}>
                  <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">— None —</SelectItem>
                    {categories.map(c => <SelectItem key={c.category_id} value={c.category_id}>{c.category_name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Document Type</Label>
                <Select value={form.document_type_id || 'none'} onValueChange={v => setForm(p => ({ ...p, document_type_id: v === 'none' ? '' : v }))}>
                  <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">— None —</SelectItem>
                    {typeConfigs.map(t => <SelectItem key={t.document_type_id} value={t.document_type_id}>{t.type_name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>File Name <span className="text-destructive">*</span></Label><Input value={form.file_name} onChange={e => setForm(p => ({ ...p, file_name: e.target.value }))} required placeholder="document.pdf" /></div>
              <div className="space-y-1.5"><Label>File Path <span className="text-destructive">*</span></Label><Input value={form.file_path} onChange={e => setForm(p => ({ ...p, file_path: e.target.value }))} required placeholder="/uploads/..." /></div>
              <div className="space-y-1.5"><Label>MIME Type</Label><Input value={form.mime_type} onChange={e => setForm(p => ({ ...p, mime_type: e.target.value }))} placeholder="application/pdf" /></div>
              <div className="space-y-1.5"><Label>Version No</Label><Input type="number" min={1} value={form.version_no} onChange={e => setForm(p => ({ ...p, version_no: e.target.value }))} /></div>
              <div className="space-y-1.5">
                <Label>Review Status</Label>
                <Select value={form.review_status} onValueChange={v => setForm(p => ({ ...p, review_status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PENDING">Pending</SelectItem>
                    <SelectItem value="VERIFIED">Verified</SelectItem>
                    <SelectItem value="APPROVED">Approved</SelectItem>
                    <SelectItem value="REJECTED">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Expiry Date</Label><Input type="date" value={form.expiry_date} onChange={e => setForm(p => ({ ...p, expiry_date: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>Tags</Label><Input value={form.tags} onChange={e => setForm(p => ({ ...p, tags: e.target.value }))} placeholder="comma-separated tags" /></div>
            <DialogFooter>
              <Button variant="outline" type="button" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Version history */}
      <Dialog open={!!histTarget} onOpenChange={o => !o && setHistTarget(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Version History — {histTarget?.document_name}</DialogTitle></DialogHeader>
          <div className="rounded border border-border overflow-x-auto max-h-80">
            <Table>
              <TableHeader>
                <TableRow className="text-xs">
                  <TableHead className="whitespace-nowrap">Version</TableHead>
                  <TableHead className="whitespace-nowrap">File</TableHead>
                  <TableHead className="whitespace-nowrap">Review</TableHead>
                  <TableHead className="whitespace-nowrap">Created</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {versions.length === 0 ? EMPTY(4, 'No version history') : versions.map(v => (
                  <TableRow key={v.document_id} className="text-sm">
                    <TableCell className="whitespace-nowrap font-mono">v{v.version_no}</TableCell>
                    <TableCell className="whitespace-nowrap text-xs max-w-[160px] truncate">{v.file_name}</TableCell>
                    <TableCell><Badge className={`text-xs ${REVIEW_COLORS[v.review_status] ?? 'bg-muted'}`}>{v.review_status}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap text-xs">{fmtDate(v.created_at)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setHistTarget(null)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader><AlertDialogTitle>Delete Document</AlertDialogTitle><AlertDialogDescription>Delete <strong>{deleting?.document_name}</strong>?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive hover:bg-destructive/90" onClick={async () => { if (deleting) { await hrDocumentService.delete(deleting.document_id); toast.success('Document deleted'); setDeleting(null); load(); } }}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 2 — Categories
// ═══════════════════════════════════════════════════════════════════════════════
function CategoriesTab({ onReload }: { onReload: () => void }) {
  const [rows, setRows]         = useState<Row[]>([]);
  const [loading, setLoading]   = useState(true);
  const [open, setOpen]         = useState(false);
  const [editing, setEditing]   = useState<Row | null>(null);
  const [deleting, setDeleting] = useState<Row | null>(null);
  const [saving, setSaving]     = useState(false);
  const [form, setForm]         = useState({ category_name: '', category_code: '', description: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try { setRows(await documentCategoryService.list()); }
    catch { toast.error('Failed to load categories'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setEditing(null); setForm({ category_name: '', category_code: '', description: '' }); setOpen(true); };
  const openEdit   = (r: Row) => { setEditing(r); setForm({ category_name: r.category_name, category_code: r.category_code ?? '', description: r.description ?? '' }); setOpen(true); };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.category_name) { toast.error('Name is required'); return; }
    setSaving(true);
    try {
      const payload = { ...form, category_code: form.category_code || null, description: form.description || null };
      if (editing) await documentCategoryService.update(editing.category_id, payload);
      else await documentCategoryService.create(payload);
      toast.success(editing ? 'Category updated' : 'Category created');
      setOpen(false); load(); onReload();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">{rows.length} categories</p>
        <div className="flex gap-2">
          <Button size="sm" className="h-8" onClick={openCreate}><Plus className="h-3.5 w-3.5 mr-1" />Add Category</Button>
          <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={load}><RefreshCw className="h-3.5 w-3.5" /></Button>
        </div>
      </div>

      <div className="rounded border border-border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="text-xs">
              <TableHead className="whitespace-nowrap">Name</TableHead>
              <TableHead className="whitespace-nowrap">Code</TableHead>
              <TableHead className="whitespace-nowrap">Description</TableHead>
              <TableHead className="whitespace-nowrap">Created</TableHead>
              <TableHead className="whitespace-nowrap w-20">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? SKEL(5) : rows.length === 0 ? EMPTY(5, 'No categories yet') : rows.map(r => (
              <TableRow key={r.category_id} className="text-sm">
                <TableCell className="whitespace-nowrap font-medium">{r.category_name}</TableCell>
                <TableCell className="whitespace-nowrap font-mono text-xs">{r.category_code || '—'}</TableCell>
                <TableCell className="max-w-[240px] truncate text-xs text-muted-foreground">{r.description || '—'}</TableCell>
                <TableCell className="whitespace-nowrap text-xs">{fmtDate(r.created_at)}</TableCell>
                <TableCell className="whitespace-nowrap">
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleting(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>{editing ? 'Edit Category' : 'New Document Category'}</DialogTitle></DialogHeader>
          <form onSubmit={handleSave} className="space-y-4 py-1">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5 col-span-2"><Label>Name <span className="text-destructive">*</span></Label><Input value={form.category_name} onChange={e => setForm(p => ({ ...p, category_name: e.target.value }))} required /></div>
              <div className="space-y-1.5"><Label>Code</Label><Input value={form.category_code} onChange={e => setForm(p => ({ ...p, category_code: e.target.value }))} placeholder="e.g. CAT-001" /></div>
            </div>
            <div className="space-y-1.5"><Label>Description</Label><Textarea rows={2} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} className="resize-none" /></div>
            <DialogFooter>
              <Button variant="outline" type="button" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader><AlertDialogTitle>Delete Category</AlertDialogTitle><AlertDialogDescription>Delete <strong>{deleting?.category_name}</strong>? Documents in this category will lose their category link.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive hover:bg-destructive/90" onClick={async () => { if (deleting) { await documentCategoryService.delete(deleting.category_id); toast.success('Category deleted'); setDeleting(null); load(); onReload(); } }}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 3 — Type Configurations
// ═══════════════════════════════════════════════════════════════════════════════
function TypeConfigsTab({ onReload }: { onReload: () => void }) {
  const [rows, setRows]         = useState<Row[]>([]);
  const [loading, setLoading]   = useState(true);
  const [total, setTotal]       = useState(0);
  const [open, setOpen]         = useState(false);
  const [editing, setEditing]   = useState<Row | null>(null);
  const [deleting, setDeleting] = useState<Row | null>(null);
  const [saving, setSaving]     = useState(false);
  const [form, setForm]         = useState({
    type_name: '', type_code: '', requires_approval: '0',
    default_confidentiality: 'INTERNAL', default_retention_months: '',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await documentTypeConfigService.list({ page: 1, pageSize: 50 });
      setRows(r.data); setTotal(r.total);
    } catch { toast.error('Failed to load type configs'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setEditing(null); setForm({ type_name: '', type_code: '', requires_approval: '0', default_confidentiality: 'INTERNAL', default_retention_months: '' }); setOpen(true); };
  const openEdit   = (r: Row) => {
    setEditing(r);
    setForm({ type_name: r.type_name, type_code: r.type_code, requires_approval: String(r.requires_approval ?? 0), default_confidentiality: r.default_confidentiality ?? 'INTERNAL', default_retention_months: String(r.default_retention_months ?? '') });
    setOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.type_name || !form.type_code) { toast.error('Name and code are required'); return; }
    setSaving(true);
    try {
      const payload = { ...form, requires_approval: Number(form.requires_approval), default_retention_months: form.default_retention_months ? Number(form.default_retention_months) : null };
      if (editing) await documentTypeConfigService.update(editing.document_type_id, payload);
      else await documentTypeConfigService.create(payload);
      toast.success(editing ? 'Type config updated' : 'Type config created');
      setOpen(false); load(); onReload();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">{total} document types</p>
        <div className="flex gap-2">
          <Button size="sm" className="h-8" onClick={openCreate}><Plus className="h-3.5 w-3.5 mr-1" />Add Type</Button>
          <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={load}><RefreshCw className="h-3.5 w-3.5" /></Button>
        </div>
      </div>

      <div className="rounded border border-border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="text-xs">
              <TableHead className="whitespace-nowrap">Name</TableHead>
              <TableHead className="whitespace-nowrap">Code</TableHead>
              <TableHead className="whitespace-nowrap">Needs Approval</TableHead>
              <TableHead className="whitespace-nowrap">Confidentiality</TableHead>
              <TableHead className="whitespace-nowrap">Retention (mo)</TableHead>
              <TableHead className="whitespace-nowrap w-20">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? SKEL(6) : rows.length === 0 ? EMPTY(6, 'No document types configured') : rows.map(r => (
              <TableRow key={r.document_type_id} className="text-sm">
                <TableCell className="whitespace-nowrap font-medium">{r.type_name}</TableCell>
                <TableCell className="whitespace-nowrap font-mono text-xs">{r.type_code}</TableCell>
                <TableCell className="whitespace-nowrap text-center">{r.requires_approval ? <Badge className="bg-blue-100 text-blue-700 text-xs">Yes</Badge> : <span className="text-muted-foreground text-xs">No</span>}</TableCell>
                <TableCell className="whitespace-nowrap"><Badge className={`text-xs ${CONF_COLORS[r.default_confidentiality] ?? 'bg-muted'}`}>{r.default_confidentiality}</Badge></TableCell>
                <TableCell className="whitespace-nowrap text-center text-xs">{r.default_retention_months ?? '—'}</TableCell>
                <TableCell className="whitespace-nowrap">
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleting(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>{editing ? 'Edit Type Config' : 'New Document Type'}</DialogTitle></DialogHeader>
          <form onSubmit={handleSave} className="space-y-4 py-1">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5 col-span-2"><Label>Type Name <span className="text-destructive">*</span></Label><Input value={form.type_name} onChange={e => setForm(p => ({ ...p, type_name: e.target.value }))} required /></div>
              <div className="space-y-1.5"><Label>Type Code <span className="text-destructive">*</span></Label><Input value={form.type_code} onChange={e => setForm(p => ({ ...p, type_code: e.target.value }))} required placeholder="e.g. NID" /></div>
              <div className="space-y-1.5"><Label>Retention Months</Label><Input type="number" min={1} value={form.default_retention_months} onChange={e => setForm(p => ({ ...p, default_retention_months: e.target.value }))} /></div>
              <div className="space-y-1.5">
                <Label>Confidentiality</Label>
                <Select value={form.default_confidentiality} onValueChange={v => setForm(p => ({ ...p, default_confidentiality: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PUBLIC">Public</SelectItem>
                    <SelectItem value="INTERNAL">Internal</SelectItem>
                    <SelectItem value="CONFIDENTIAL">Confidential</SelectItem>
                    <SelectItem value="RESTRICTED">Restricted</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Requires Approval</Label>
                <Select value={form.requires_approval} onValueChange={v => setForm(p => ({ ...p, requires_approval: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">No</SelectItem>
                    <SelectItem value="1">Yes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" type="button" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader><AlertDialogTitle>Delete Type Config</AlertDialogTitle><AlertDialogDescription>Delete <strong>{deleting?.type_name}</strong>?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive hover:bg-destructive/90" onClick={async () => { if (deleting) { await documentTypeConfigService.delete(deleting.document_type_id); toast.success('Type deleted'); setDeleting(null); load(); onReload(); } }}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROOT PAGE
// ═══════════════════════════════════════════════════════════════════════════════
export function DocumentManagementPage() {
  const [categories, setCategories]   = useState<Row[]>([]);
  const [typeConfigs, setTypeConfigs] = useState<Row[]>([]);

  const reloadMeta = useCallback(async () => {
    try {
      const [cats, types] = await Promise.all([
        documentCategoryService.list(),
        documentTypeConfigService.list({ page: 1, pageSize: 100 }).then(r => r.data),
      ]);
      setCategories(cats);
      setTypeConfigs(types);
    } catch { /* silent — individual tabs handle errors */ }
  }, []);

  useEffect(() => { reloadMeta(); }, [reloadMeta]);

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2">
        <FolderOpen className="h-5 w-5 text-primary shrink-0" />
        <div>
          <h1 className="text-xl font-bold text-foreground leading-tight">Document Management</h1>
          <p className="text-sm text-muted-foreground">Unified document store with version history, categories, and type configuration</p>
        </div>
      </div>

      <Tabs defaultValue="documents" className="space-y-4">
        <TabsList className="h-9 gap-1">
          <TabsTrigger value="documents" className="text-xs h-7 px-3 gap-1.5"><Files className="h-3.5 w-3.5" />Documents</TabsTrigger>
          <TabsTrigger value="categories" className="text-xs h-7 px-3 gap-1.5"><Tag className="h-3.5 w-3.5" />Categories</TabsTrigger>
          <TabsTrigger value="types" className="text-xs h-7 px-3 gap-1.5"><Settings2 className="h-3.5 w-3.5" />Type Configs</TabsTrigger>
        </TabsList>

        <TabsContent value="documents">
          <DocumentsTab categories={categories} typeConfigs={typeConfigs} />
        </TabsContent>
        <TabsContent value="categories">
          <CategoriesTab onReload={reloadMeta} />
        </TabsContent>
        <TabsContent value="types">
          <TypeConfigsTab onReload={reloadMeta} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default DocumentManagementPage;
