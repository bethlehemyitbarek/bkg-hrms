import { useState, useEffect, useCallback } from 'react';
import { documentService } from '@/services/modules.service';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, FileText } from 'lucide-react';
import { toast } from 'sonner';

const STATUS_COLORS: Record<string, string> = {
  active: 'bg-green-100 text-green-800',
  expired: 'bg-red-100 text-red-800',
  archived: 'bg-muted text-muted-foreground',
};

export function DocumentPage() {
  const [docs, setDocs] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [typeFilter, setTypeFilter] = useState('all');
  const [dialog, setDialog] = useState(false);
  const [saving, setSaving] = useState(false);
  // DB columns: employee_id, title, document_type, category, file_url, file_name, file_size, mime_type, version, is_confidential, expiry_date, uploaded_by, status
  const [form, setForm] = useState({
    employee_id: '', title: '',
    document_type: 'id_card', category: 'personal',
    expiry_date: '', status: 'active',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await documentService.list({
        document_type: typeFilter !== 'all' ? typeFilter : undefined,
        status: undefined, // show all statuses
        page: 1, pageSize: 30,
      });
      setDocs(res.data as Record<string, unknown>[]);
      setTotal(res.total);
    } catch { toast.error('Failed to load documents'); }
    finally { setLoading(false); }
  }, [typeFilter]);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.employee_id || form.employee_id === 'none') { toast.error('Please select an employee'); return; }
    setSaving(true);
    try {
      await documentService.create({
        employee_id: form.employee_id,
        title: form.title,
        document_type: form.document_type,
        category: form.category,
        expiry_date: form.expiry_date || null,
        status: form.status,
        is_confidential: false,
      });
      toast.success('Document record added');
      setDialog(false);
      setForm({ employee_id: '', title: '', document_type: 'id_card', category: 'personal', expiry_date: '', status: 'active' });
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to add document'); }
    finally { setSaving(false); }
  };

  const emp = (r: Record<string, unknown>) => {
    const e = r.employee as Record<string, unknown> | undefined;
    return e ? `${e.first_name} ${e.last_name}` : '—';
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2"><FileText className="h-5 w-5 text-primary" />Documents</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} documents</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-36 h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="id_card">ID Card</SelectItem>
              <SelectItem value="passport">Passport</SelectItem>
              <SelectItem value="contract">Contract</SelectItem>
              <SelectItem value="certificate">Certificate</SelectItem>
              <SelectItem value="medical">Medical</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
          <Dialog open={dialog} onOpenChange={setDialog}>
            <DialogTrigger asChild>
              <Button size="sm"><Plus className="h-4 w-4 mr-1.5" />Add Document</Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>Add Document Record</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 mt-2">
                <EmployeeSelect value={form.employee_id} onChange={v => setForm(p => ({ ...p, employee_id: v }))} required />
                <div className="space-y-1.5"><Label>Document Title *</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} required placeholder="e.g. Thai National ID" /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Document Type *</Label>
                    <Select value={form.document_type} onValueChange={v => setForm(p => ({ ...p, document_type: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="id_card">ID Card</SelectItem>
                        <SelectItem value="passport">Passport</SelectItem>
                        <SelectItem value="contract">Contract</SelectItem>
                        <SelectItem value="certificate">Certificate</SelectItem>
                        <SelectItem value="medical">Medical</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Category</Label>
                    <Select value={form.category} onValueChange={v => setForm(p => ({ ...p, category: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="personal">Personal</SelectItem>
                        <SelectItem value="employment">Employment</SelectItem>
                        <SelectItem value="financial">Financial</SelectItem>
                        <SelectItem value="legal">Legal</SelectItem>
                        <SelectItem value="training">Training</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5"><Label>Expiry Date</Label><Input type="date" value={form.expiry_date} onChange={e => setForm(p => ({ ...p, expiry_date: e.target.value }))} /></div>
                  <div className="space-y-1.5">
                    <Label>Status</Label>
                    <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="expired">Expired</SelectItem>
                        <SelectItem value="archived">Archived</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button type="submit" className="w-full" disabled={saving}>{saving ? 'Saving…' : 'Add Document'}</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Title</TableHead>
                <TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">Category</TableHead>
                <TableHead className="whitespace-nowrap">Expiry Date</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                : docs.length === 0 ? <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No documents found</TableCell></TableRow>
                : docs.map(d => (
                  <TableRow key={String(d.id)}>
                    <TableCell className="whitespace-nowrap font-medium">{emp(d)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{String(d.title)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm capitalize">{String(d.document_type).replace('_', ' ')}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm capitalize">{d.category ? String(d.category) : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{d.expiry_date ? String(d.expiry_date) : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={STATUS_COLORS[String(d.status)] || 'bg-muted'}>{String(d.status)}</Badge></TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
export default DocumentPage;
