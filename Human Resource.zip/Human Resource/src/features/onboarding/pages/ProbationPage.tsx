// ProbationPage — Module 8.9 ProbationPeriod + 8.10 ProbationEvaluation
import { useState, useEffect, useCallback } from 'react';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Eye, Users, CheckCircle2, Clock, XCircle, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

type ProbationPeriod = {
  id: string; probation_period_id: string;
  start_date: string; end_date: string;
  probation_status: string; created_at: string;
  employee?: { first_name: string; last_name: string; employee_no?: string };
  evaluations?: ProbationEval[];
};
type ProbationEval = {
  id: string; probation_evaluation_id: string;
  evaluation_score?: number; recommendation: string;
  comments?: string; evaluation_date: string;
  evaluator?: { first_name: string; last_name: string };
};

const STATUS_COLORS: Record<string, string> = {
  ONGOING: 'bg-blue-100 text-blue-800',
  CONFIRMED: 'bg-green-100 text-green-800',
  EXTENDED: 'bg-yellow-100 text-yellow-800',
  TERMINATED: 'bg-red-100 text-red-800',
};
const REC_COLORS: Record<string, string> = {
  CONFIRM: 'bg-green-100 text-green-800',
  EXTEND: 'bg-yellow-100 text-yellow-800',
  TERMINATE: 'bg-red-100 text-red-800',
};

export function ProbationPage() {
  const [probations, setProbations] = useState<ProbationPeriod[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Detail dialog
  const [detail, setDetail] = useState<ProbationPeriod | null>(null);
  const [evalLoading, setEvalLoading] = useState(false);

  // Create probation dialog
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ employee_id: '', start_date: '', end_date: '' });
  const [saving, setSaving] = useState(false);

  // Add evaluation dialog
  const [addEvalOpen, setAddEvalOpen] = useState(false);
  const [evalForm, setEvalForm] = useState({ evaluation_score: '', recommendation: 'CONFIRM', comments: '', evaluation_date: new Date().toISOString().split('T')[0] });
  const [evalSaving, setEvalSaving] = useState(false);

  // Employees for select
  const [employees, setEmployees] = useState<{ id: string; employee_id?: string; first_name: string; last_name: string; employee_no?: string }[]>([]);

  // Stats
  const ongoing = probations.filter(p => p.probation_status === 'ONGOING').length;
  const confirmed = probations.filter(p => p.probation_status === 'CONFIRMED').length;
  const extended = probations.filter(p => p.probation_status === 'EXTENDED').length;
  const terminated = probations.filter(p => p.probation_status === 'TERMINATED').length;

  const loadProbations = useCallback(async () => {
    setLoading(true);
    try {
      let q = sb.from('probation_periods')
        .select('id,probation_period_id,start_date,end_date,probation_status,created_at,employee:employees(first_name,last_name,employee_no)')
        .eq('is_deleted', 0).order('created_at', { ascending: false });
      if (statusFilter !== 'all') q = q.eq('probation_status', statusFilter);
      const { data, error } = await q;
      if (error) throw error;
      setProbations(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setLoading(false); }
  }, [statusFilter]);

  const loadEmployees = useCallback(async () => {
    const { data } = await sb.from('employees').select('id,first_name,last_name,employee_no').eq('status', 'active').order('first_name').limit(200);
    setEmployees(Array.isArray(data) ? data : []);
  }, []);

  const loadEvaluations = useCallback(async (probationId: string) => {
    setEvalLoading(true);
    try {
      const { data, error } = await sb.from('probation_evaluations')
        .select('id,probation_evaluation_id,evaluation_score,recommendation,comments,evaluation_date,evaluator:employees!probation_evaluations_evaluator_id_fkey(first_name,last_name)')
        .eq('probation_period_id', probationId)
        .eq('is_deleted', 0)
        .order('evaluation_date', { ascending: false });
      if (error) throw error;
      setDetail(prev => prev ? { ...prev, evaluations: Array.isArray(data) ? data : [] } : prev);
    } catch (e: any) { toast.error(e.message); } finally { setEvalLoading(false); }
  }, []);

  useEffect(() => { loadProbations(); loadEmployees(); }, [loadProbations, loadEmployees]);

  const openDetail = useCallback(async (p: ProbationPeriod) => {
    setDetail(p);
    loadEvaluations(p.probation_period_id);
  }, [loadEvaluations]);

  const filtered = probations.filter(p => {
    const name = `${p.employee?.first_name ?? ''} ${p.employee?.last_name ?? ''} ${p.employee?.employee_no ?? ''}`.toLowerCase();
    return name.includes(search.toLowerCase());
  });

  async function createProbation() {
    if (!form.employee_id || !form.start_date || !form.end_date) { toast.error('Employee, start and end date are required'); return; }
    setSaving(true);
    try {
      const { error } = await sb.from('probation_periods').insert({
        employee_id: form.employee_id,
        start_date: form.start_date,
        end_date: form.end_date,
        probation_status: 'ONGOING',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Probation period created');
      setCreateOpen(false);
      setForm({ employee_id: '', start_date: '', end_date: '' });
      loadProbations();
    } catch (e: any) { toast.error(e.message); } finally { setSaving(false); }
  }

  async function addEvaluation() {
    if (!detail || !evalForm.evaluation_date) { toast.error('Evaluation date required'); return; }
    setEvalSaving(true);
    try {
      const { error } = await sb.from('probation_evaluations').insert({
        probation_period_id: detail.probation_period_id,
        evaluator_id: employees[0]?.id ?? null, // placeholder — in a real app use current user id
        evaluation_score: evalForm.evaluation_score ? parseFloat(evalForm.evaluation_score) : null,
        recommendation: evalForm.recommendation,
        comments: evalForm.comments || null,
        evaluation_date: evalForm.evaluation_date,
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Evaluation added');
      setAddEvalOpen(false);
      setEvalForm({ evaluation_score: '', recommendation: 'CONFIRM', comments: '', evaluation_date: new Date().toISOString().split('T')[0] });
      loadEvaluations(detail.probation_period_id);
    } catch (e: any) { toast.error(e.message); } finally { setEvalSaving(false); }
  }

  async function updateStatus(periodId: string, newStatus: string) {
    const { error } = await sb.from('probation_periods').update({ probation_status: newStatus, updated_at: new Date().toISOString() }).eq('id', periodId);
    if (error) toast.error(error.message);
    else {
      toast.success('Status updated');
      loadProbations();
      if (detail?.id === periodId) setDetail(d => d ? { ...d, probation_status: newStatus } : d);
    }
  }

  return (
    <div className="p-4 md:p-6 space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Probation Management</h1>
          <p className="text-sm text-muted-foreground">Track post-hire probation periods and evaluations</p>
        </div>
        <Button size="sm" onClick={() => setCreateOpen(true)}><Plus className="w-4 h-4 mr-1" /> New Probation</Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Ongoing', value: ongoing, icon: Clock, color: 'text-blue-600' },
          { label: 'Confirmed', value: confirmed, icon: CheckCircle2, color: 'text-green-600' },
          { label: 'Extended', value: extended, icon: RefreshCw, color: 'text-yellow-600' },
          { label: 'Terminated', value: terminated, icon: XCircle, color: 'text-red-600' },
        ].map(s => (
          <Card key={s.label} className="h-full">
            <CardContent className="p-4 flex items-center gap-3">
              <s.icon className={`w-8 h-8 shrink-0 ${s.color}`} />
              <div><p className="text-2xl font-bold">{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-2">
        <Input placeholder="Search by employee name…" value={search} onChange={e => setSearch(e.target.value)} className="md:max-w-xs" />
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="md:w-44"><SelectValue placeholder="All Statuses" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="ONGOING">Ongoing</SelectItem>
            <SelectItem value="CONFIRMED">Confirmed</SelectItem>
            <SelectItem value="EXTENDED">Extended</SelectItem>
            <SelectItem value="TERMINATED">Terminated</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <div className="border rounded-lg overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="whitespace-nowrap">Employee</TableHead>
              <TableHead className="whitespace-nowrap">Start Date</TableHead>
              <TableHead className="whitespace-nowrap">End Date</TableHead>
              <TableHead className="whitespace-nowrap">Status</TableHead>
              <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}><TableCell colSpan={5}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>
              ))
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-10">No probation records found.</TableCell></TableRow>
            ) : filtered.map(p => (
              <TableRow key={p.id}>
                <TableCell className="whitespace-nowrap font-medium">
                  {p.employee ? `${p.employee.first_name} ${p.employee.last_name}` : '—'}
                  {p.employee?.employee_no && <span className="ml-1 text-xs text-muted-foreground">({p.employee.employee_no})</span>}
                </TableCell>
                <TableCell className="whitespace-nowrap">{p.start_date}</TableCell>
                <TableCell className="whitespace-nowrap">{p.end_date}</TableCell>
                <TableCell className="whitespace-nowrap">
                  <Badge className={`text-xs ${STATUS_COLORS[p.probation_status] ?? 'bg-muted text-muted-foreground'}`}>{p.probation_status}</Badge>
                </TableCell>
                <TableCell className="text-right whitespace-nowrap">
                  <Button size="sm" variant="ghost" onClick={() => openDetail(p)}><Eye className="w-4 h-4" /></Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* ── Detail / Evaluations Dialog ── */}
      <Dialog open={!!detail} onOpenChange={() => setDetail(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {detail?.employee ? `${detail.employee.first_name} ${detail.employee.last_name} — Probation` : 'Probation Detail'}
            </DialogTitle>
          </DialogHeader>
          {detail && (
            <div className="space-y-4 pt-2">
              {/* Summary */}
              <div className="grid grid-cols-3 gap-3 text-sm">
                <div><p className="text-muted-foreground">Start</p><p className="font-medium">{detail.start_date}</p></div>
                <div><p className="text-muted-foreground">End</p><p className="font-medium">{detail.end_date}</p></div>
                <div>
                  <p className="text-muted-foreground">Status</p>
                  <Badge className={`text-xs mt-1 ${STATUS_COLORS[detail.probation_status] ?? 'bg-muted text-muted-foreground'}`}>{detail.probation_status}</Badge>
                </div>
              </div>
              {/* Status actions */}
              {detail.probation_status === 'ONGOING' && (
                <div className="flex gap-2 flex-wrap">
                  <Button size="sm" onClick={() => updateStatus(detail.id, 'CONFIRMED')}>Confirm</Button>
                  <Button size="sm" variant="outline" onClick={() => updateStatus(detail.id, 'EXTENDED')}>Extend</Button>
                  <Button size="sm" variant="outline" onClick={() => updateStatus(detail.id, 'TERMINATED')} className="text-destructive border-destructive hover:bg-destructive/10">Terminate</Button>
                </div>
              )}
              {/* Evaluations */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="font-medium">Evaluations</p>
                  <Button size="sm" variant="outline" onClick={() => setAddEvalOpen(true)}><Plus className="w-4 h-4 mr-1" /> Add</Button>
                </div>
                {evalLoading ? <Skeleton className="h-16 w-full bg-muted" /> : (
                  (!detail.evaluations || detail.evaluations.length === 0)
                    ? <p className="text-sm text-muted-foreground">No evaluations yet.</p>
                    : (
                      <div className="border rounded overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="whitespace-nowrap">Date</TableHead>
                              <TableHead className="whitespace-nowrap">Evaluator</TableHead>
                              <TableHead className="whitespace-nowrap">Score</TableHead>
                              <TableHead className="whitespace-nowrap">Recommendation</TableHead>
                              <TableHead className="whitespace-nowrap">Comments</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {detail.evaluations.map(ev => (
                              <TableRow key={ev.id}>
                                <TableCell className="whitespace-nowrap">{ev.evaluation_date}</TableCell>
                                <TableCell className="whitespace-nowrap">{ev.evaluator ? `${ev.evaluator.first_name} ${ev.evaluator.last_name}` : '—'}</TableCell>
                                <TableCell className="whitespace-nowrap">{ev.evaluation_score ?? '—'}</TableCell>
                                <TableCell className="whitespace-nowrap">
                                  <Badge className={`text-xs ${REC_COLORS[ev.recommendation] ?? 'bg-muted text-muted-foreground'}`}>{ev.recommendation}</Badge>
                                </TableCell>
                                <TableCell className="max-w-[200px] truncate text-sm">{ev.comments ?? '—'}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ── Add Evaluation Dialog ── */}
      <Dialog open={addEvalOpen} onOpenChange={setAddEvalOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add Probation Evaluation</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div><Label>Evaluation Date *</Label><Input type="date" value={evalForm.evaluation_date} onChange={e => setEvalForm(f => ({ ...f, evaluation_date: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Score (0–100)</Label><Input type="number" min="0" max="100" step="0.01" value={evalForm.evaluation_score} onChange={e => setEvalForm(f => ({ ...f, evaluation_score: e.target.value }))} placeholder="e.g. 85.50" /></div>
              <div>
                <Label>Recommendation *</Label>
                <Select value={evalForm.recommendation} onValueChange={v => setEvalForm(f => ({ ...f, recommendation: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="CONFIRM">Confirm</SelectItem>
                    <SelectItem value="EXTEND">Extend</SelectItem>
                    <SelectItem value="TERMINATE">Terminate</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Comments</Label><Textarea value={evalForm.comments} onChange={e => setEvalForm(f => ({ ...f, comments: e.target.value }))} rows={3} /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setAddEvalOpen(false)}>Cancel</Button>
              <Button onClick={addEvaluation} disabled={evalSaving}>{evalSaving ? 'Saving…' : 'Save Evaluation'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Create Probation Dialog ── */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Probation Period</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div>
              <Label>Employee *</Label>
              <Select value={form.employee_id} onValueChange={v => setForm(f => ({ ...f, employee_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Select employee" /></SelectTrigger>
                <SelectContent>
                  {employees.map(e => <SelectItem key={e.id} value={e.id}>{e.first_name} {e.last_name}{e.employee_no ? ` (${e.employee_no})` : ''}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Start Date *</Label><Input type="date" value={form.start_date} onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))} /></div>
              <div><Label>End Date *</Label><Input type="date" value={form.end_date} onChange={e => setForm(f => ({ ...f, end_date: e.target.value }))} /></div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
              <Button onClick={createProbation} disabled={saving}>{saving ? 'Creating…' : 'Create'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
