// OnboardingPage — Module 8: Onboarding (8.1 Templates, 8.2 Task Templates, 8.3 Processes, 8.4 Tasks)
import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Eye, UserCheck, ClipboardList, Layers, RefreshCw, ChevronDown, ChevronRight, Trash2, FileBarChart2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { ROUTES } from '@/app/routes';

const sb = _sb as any; // eslint-disable-line

// ─── Types ───────────────────────────────────────────────────────────────────
type Template = {
  id: string; onboarding_template_id: string; template_name: string;
  role_code?: string; version_number: number; template_status: string;
  created_at: string;
  department?: { name: string };
  task_templates?: TaskTemplate[];
};
type TaskTemplate = {
  id: string; task_template_id: string; task_name: string;
  assigned_role: string; default_sla_days: number; is_mandatory: number;
  sequence_order: number;
};
type Process = {
  id: string; onboarding_process_id: string; process_number: string;
  process_status: string; conversion_status: string;
  proposed_start_date?: string; actual_start_date?: string;
  expected_completion_date?: string; probation_end_date?: string;
  created_at: string;
  candidate?: { first_name: string; last_name: string };
  employee?: { first_name: string; last_name: string; employee_no?: string };
  template?: { template_name: string };
};

// ─── Helpers ─────────────────────────────────────────────────────────────────
const PROCESS_STATUS_COLORS: Record<string, string> = {
  INITIATED: 'bg-blue-100 text-blue-800',
  IN_PROGRESS: 'bg-yellow-100 text-yellow-800',
  COMPLETED: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-red-100 text-red-800',
};
const CONVERSION_COLORS: Record<string, string> = {
  NOT_STARTED: 'bg-muted text-muted-foreground',
  PENDING_APPROVAL: 'bg-yellow-100 text-yellow-800',
  APPROVED: 'bg-blue-100 text-blue-800',
  CONVERTED: 'bg-green-100 text-green-800',
  REJECTED: 'bg-red-100 text-red-800',
};
const TMPL_COLORS: Record<string, string> = {
  DRAFT: 'bg-muted text-muted-foreground',
  ACTIVE: 'bg-green-100 text-green-800',
  ARCHIVED: 'bg-yellow-100 text-yellow-800',
};

export function OnboardingPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState('processes');

  // ── Processes ──
  const [processes, setProcesses] = useState<Process[]>([]);
  const [procLoading, setProcLoading] = useState(true);
  const [procSearch, setProcSearch] = useState('');
  const [procStatusFilter, setProcStatusFilter] = useState('all');

  // ── Templates ──
  const [templates, setTemplates] = useState<Template[]>([]);
  const [tmplLoading, setTmplLoading] = useState(false);
  const [tmplSearch, setTmplSearch] = useState('');
  const [expandedTmpl, setExpandedTmpl] = useState<string | null>(null);

  // ── Create Process dialog ──
  const [createProcOpen, setCreateProcOpen] = useState(false);
  const [procForm, setProcForm] = useState({
    template_id: '', proposed_start_date: '', expected_completion_date: '',
    probation_end_date: '', candidate_name: '', notes: '',
  });
  const [procSaving, setProcSaving] = useState(false);

  // ── Create Template dialog ──
  const [createTmplOpen, setCreateTmplOpen] = useState(false);
  const [tmplForm, setTmplForm] = useState({ template_name: '', role_code: '', template_status: 'DRAFT' });
  const [tmplSaving, setTmplSaving] = useState(false);

  // ── Add Task Template dialog ──
  const [addTaskOpen, setAddTaskOpen] = useState<string | null>(null); // template_id
  const [taskForm, setTaskForm] = useState({ task_name: '', assigned_role: 'HR', default_sla_days: '3', is_mandatory: '1', sequence_order: '1' });
  const [taskSaving, setTaskSaving] = useState(false);

  // ── Stats ──
  const initiated = processes.filter(p => p.process_status === 'INITIATED').length;
  const inProgress = processes.filter(p => p.process_status === 'IN_PROGRESS').length;
  const completed = processes.filter(p => p.process_status === 'COMPLETED').length;

  const loadProcesses = useCallback(async () => {
    setProcLoading(true);
    try {
      let q = sb.from('onboarding_processes')
        .select('id,onboarding_process_id,process_number,process_status,conversion_status,proposed_start_date,actual_start_date,expected_completion_date,probation_end_date,created_at,candidate:candidates(first_name,last_name),employee:employees(first_name,last_name,employee_no),template:onboarding_templates(template_name)')
        .eq('is_deleted', 0).order('created_at', { ascending: false });
      if (procStatusFilter !== 'all') q = q.eq('process_status', procStatusFilter);
      const { data, error } = await q;
      if (error) throw error;
      setProcesses(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setProcLoading(false); }
  }, [procStatusFilter]);

  const loadTemplates = useCallback(async () => {
    setTmplLoading(true);
    try {
      const { data, error } = await sb.from('onboarding_templates')
        .select('id,onboarding_template_id,template_name,role_code,version_number,template_status,created_at,department:departments(name),task_templates:onboarding_task_templates(id,task_template_id,task_name,assigned_role,default_sla_days,is_mandatory,sequence_order)')
        .eq('is_deleted', 0).order('created_at', { ascending: false });
      if (error) throw error;
      setTemplates(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setTmplLoading(false); }
  }, []);

  useEffect(() => { loadProcesses(); }, [loadProcesses]);
  useEffect(() => { if (tab === 'templates') loadTemplates(); }, [tab, loadTemplates]);

  const filteredProcesses = processes.filter(p => {
    const name = `${p.candidate?.first_name ?? ''} ${p.candidate?.last_name ?? ''} ${p.employee?.first_name ?? ''} ${p.employee?.last_name ?? ''} ${p.process_number}`.toLowerCase();
    return name.includes(procSearch.toLowerCase());
  });

  const filteredTemplates = templates.filter(t =>
    t.template_name.toLowerCase().includes(tmplSearch.toLowerCase()) ||
    (t.role_code ?? '').toLowerCase().includes(tmplSearch.toLowerCase())
  );

  async function createProcess() {
    if (!procForm.proposed_start_date) { toast.error('Start date is required'); return; }
    setProcSaving(true);
    try {
      const payload: Record<string, any> = {
        process_status: 'INITIATED', conversion_status: 'NOT_STARTED',
        proposed_start_date: procForm.proposed_start_date || null,
        expected_completion_date: procForm.expected_completion_date || null,
        probation_end_date: procForm.probation_end_date || null,
        updated_at: new Date().toISOString(),
      };
      if (procForm.template_id) payload.template_id = procForm.template_id;
      const { data: newProc, error } = await sb.from('onboarding_processes').insert(payload).select('id,onboarding_process_id').maybeSingle();
      if (error) throw error;

      // Auto-populate tasks from template
      if (procForm.template_id && newProc) {
        const { data: taskTemplates } = await sb.from('onboarding_task_templates')
          .select('task_name,assigned_role,default_sla_days,is_mandatory,sequence_order,description')
          .eq('onboarding_template_id', procForm.template_id)
          .eq('is_deleted', 0)
          .order('sequence_order', { ascending: true });

        if (Array.isArray(taskTemplates) && taskTemplates.length > 0) {
          const startDate = new Date(procForm.proposed_start_date);
          const tasks = taskTemplates.map((tt: any) => ({
            onboarding_process_id: newProc.onboarding_process_id,
            task_name: tt.task_name,
            description: tt.description ?? null,
            assigned_role: tt.assigned_role ?? 'HR',
            task_status: 'PENDING',
            is_mandatory: tt.is_mandatory ?? 1,
            sequence_order: tt.sequence_order ?? 1,
            due_date: tt.default_sla_days
              ? new Date(startDate.getTime() + tt.default_sla_days * 86400000).toISOString().split('T')[0]
              : null,
            updated_at: new Date().toISOString(),
          }));
          const { error: tasksErr } = await sb.from('onboarding_tasks').insert(tasks);
          if (tasksErr) toast.warning(`Process created but tasks auto-populate failed: ${tasksErr.message}`);
          else toast.success(`Onboarding process created with ${tasks.length} tasks auto-populated`);
        } else {
          toast.success('Onboarding process created');
        }
      } else {
        toast.success('Onboarding process created');
      }

      setCreateProcOpen(false);
      setProcForm({ template_id: '', proposed_start_date: '', expected_completion_date: '', probation_end_date: '', candidate_name: '', notes: '' });
      loadProcesses();
    } catch (e: any) { toast.error(e.message); } finally { setProcSaving(false); }
  }

  async function createTemplate() {
    if (!tmplForm.template_name.trim()) { toast.error('Template name required'); return; }
    setTmplSaving(true);
    try {
      const { error } = await sb.from('onboarding_templates').insert({
        template_name: tmplForm.template_name.trim(),
        role_code: tmplForm.role_code || null,
        template_status: tmplForm.template_status,
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Template created');
      setCreateTmplOpen(false);
      setTmplForm({ template_name: '', role_code: '', template_status: 'DRAFT' });
      loadTemplates();
    } catch (e: any) { toast.error(e.message); } finally { setTmplSaving(false); }
  }

  async function addTaskTemplate() {
    if (!taskForm.task_name.trim() || !addTaskOpen) { toast.error('Task name required'); return; }
    setTaskSaving(true);
    try {
      const { error } = await sb.from('onboarding_task_templates').insert({
        onboarding_template_id: addTaskOpen,
        task_name: taskForm.task_name.trim(),
        assigned_role: taskForm.assigned_role,
        default_sla_days: parseInt(taskForm.default_sla_days) || 3,
        is_mandatory: parseInt(taskForm.is_mandatory),
        sequence_order: parseInt(taskForm.sequence_order) || 1,
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Task added');
      setAddTaskOpen(null);
      setTaskForm({ task_name: '', assigned_role: 'HR', default_sla_days: '3', is_mandatory: '1', sequence_order: '1' });
      loadTemplates();
    } catch (e: any) { toast.error(e.message); } finally { setTaskSaving(false); }
  }

  async function deleteTaskTemplate(id: string) {
    const { error } = await sb.from('onboarding_task_templates').update({ is_deleted: 1 }).eq('id', id);
    if (error) toast.error(error.message);
    else { toast.success('Task removed'); loadTemplates(); }
  }

  async function activateTemplate(tmplId: string) {
    const { error } = await sb.from('onboarding_templates').update({ template_status: 'ACTIVE', updated_at: new Date().toISOString() }).eq('id', tmplId);
    if (error) toast.error(error.message);
    else { toast.success('Template activated'); loadTemplates(); }
  }

  return (
    <div className="p-4 md:p-6 space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold text-foreground">Onboarding</h1>
          <p className="text-sm text-muted-foreground">Manage onboarding processes and workflow templates</p>
        </div>
        <div className="flex gap-2">
          {tab === 'processes' && (
            <Button size="sm" onClick={() => setCreateProcOpen(true)}>
              <Plus className="w-4 h-4 mr-1" /> New Process
            </Button>
          )}
          {tab === 'templates' && (
            <Button size="sm" onClick={() => setCreateTmplOpen(true)}>
              <Plus className="w-4 h-4 mr-1" /> New Template
            </Button>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total', value: processes.length, icon: ClipboardList },
          { label: 'Initiated', value: initiated, icon: UserCheck },
          { label: 'In Progress', value: inProgress, icon: RefreshCw },
          { label: 'Completed', value: completed, icon: Layers },
        ].map(s => (
          <Card key={s.label} className="h-full">
            <CardContent className="p-4 flex items-center gap-3">
              <s.icon className="w-8 h-8 text-primary shrink-0" />
              <div><p className="text-2xl font-bold">{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="processes">Processes</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="reports" className="gap-1.5"><FileBarChart2 className="h-3.5 w-3.5" />Reports</TabsTrigger>
        </TabsList>

        {/* ── Processes Tab ── */}
        <TabsContent value="processes" className="mt-4 space-y-3">
          <div className="flex flex-col md:flex-row gap-2">
            <Input placeholder="Search by name or number…" value={procSearch} onChange={e => setProcSearch(e.target.value)} className="md:max-w-xs" />
            <Select value={procStatusFilter} onValueChange={setProcStatusFilter}>
              <SelectTrigger className="md:w-44"><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="INITIATED">Initiated</SelectItem>
                <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
                <SelectItem value="COMPLETED">Completed</SelectItem>
                <SelectItem value="CANCELLED">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Process #</TableHead>
                  <TableHead className="whitespace-nowrap">Candidate / Employee</TableHead>
                  <TableHead className="whitespace-nowrap">Template</TableHead>
                  <TableHead className="whitespace-nowrap">Start Date</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Conversion</TableHead>
                  <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {procLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}><TableCell colSpan={7}><Skeleton className="h-8 w-full bg-muted" /></TableCell></TableRow>
                  ))
                ) : filteredProcesses.length === 0 ? (
                  <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-10">No onboarding processes found.</TableCell></TableRow>
                ) : filteredProcesses.map(p => (
                  <TableRow key={p.id}>
                    <TableCell className="whitespace-nowrap font-mono text-sm">{p.process_number}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      {p.candidate ? `${p.candidate.first_name} ${p.candidate.last_name}` :
                        p.employee ? `${p.employee.first_name} ${p.employee.last_name} (${p.employee.employee_no ?? ''})` : '—'}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">{p.template?.template_name ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">{p.proposed_start_date ?? '—'}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${PROCESS_STATUS_COLORS[p.process_status] ?? 'bg-muted text-muted-foreground'}`}>{p.process_status}</Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge className={`text-xs ${CONVERSION_COLORS[p.conversion_status] ?? 'bg-muted text-muted-foreground'}`}>{p.conversion_status.replace(/_/g, ' ')}</Badge>
                    </TableCell>
                    <TableCell className="text-right whitespace-nowrap">
                      <Button size="sm" variant="ghost" onClick={() => navigate(`/onboarding/${p.onboarding_process_id}`)}>
                        <Eye className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* ── Templates Tab ── */}
        <TabsContent value="templates" className="mt-4 space-y-3">
          <Input placeholder="Search templates…" value={tmplSearch} onChange={e => setTmplSearch(e.target.value)} className="max-w-xs" />
          {tmplLoading ? (
            <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 w-full bg-muted" />)}</div>
          ) : filteredTemplates.length === 0 ? (
            <p className="text-center text-muted-foreground py-10">No templates found.</p>
          ) : (
            <div className="space-y-2">
              {filteredTemplates.map(t => (
                <Card key={t.id} className="h-full">
                  <CardHeader className="py-3 px-4">
                    <div className="flex items-center justify-between gap-2">
                      <button className="flex items-center gap-2 text-left flex-1 min-w-0" onClick={() => setExpandedTmpl(expandedTmpl === t.id ? null : t.id)}>
                        {expandedTmpl === t.id ? <ChevronDown className="w-4 h-4 shrink-0" /> : <ChevronRight className="w-4 h-4 shrink-0" />}
                        <span className="font-medium truncate">{t.template_name}</span>
                        {t.role_code && <span className="text-xs text-muted-foreground shrink-0">({t.role_code})</span>}
                        <Badge className={`text-xs shrink-0 ${TMPL_COLORS[t.template_status] ?? 'bg-muted'}`}>{t.template_status}</Badge>
                      </button>
                      <div className="flex gap-1 shrink-0">
                        {t.template_status === 'DRAFT' && (
                          <Button size="sm" variant="ghost" onClick={() => activateTemplate(t.id)} className="text-xs">Activate</Button>
                        )}
                        <Button size="sm" variant="ghost" onClick={() => { setAddTaskOpen(t.onboarding_template_id); setTaskForm({ task_name: '', assigned_role: 'HR', default_sla_days: '3', is_mandatory: '1', sequence_order: String((t.task_templates?.length ?? 0) + 1) }); }}>
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  {expandedTmpl === t.id && (
                    <CardContent className="pt-0 pb-3 px-4">
                      {(!t.task_templates || t.task_templates.length === 0) ? (
                        <p className="text-sm text-muted-foreground">No tasks defined yet.</p>
                      ) : (
                        <div className="border rounded overflow-x-auto">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead className="whitespace-nowrap w-10">#</TableHead>
                                <TableHead className="whitespace-nowrap">Task</TableHead>
                                <TableHead className="whitespace-nowrap">Role</TableHead>
                                <TableHead className="whitespace-nowrap">SLA (days)</TableHead>
                                <TableHead className="whitespace-nowrap">Mandatory</TableHead>
                                <TableHead className="whitespace-nowrap text-right">Del</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {[...t.task_templates].sort((a, b) => a.sequence_order - b.sequence_order).map(tt => (
                                <TableRow key={tt.id}>
                                  <TableCell className="whitespace-nowrap text-muted-foreground">{tt.sequence_order}</TableCell>
                                  <TableCell className="whitespace-nowrap">{tt.task_name}</TableCell>
                                  <TableCell className="whitespace-nowrap">{tt.assigned_role}</TableCell>
                                  <TableCell className="whitespace-nowrap">{tt.default_sla_days}</TableCell>
                                  <TableCell className="whitespace-nowrap">{tt.is_mandatory ? 'Yes' : 'No'}</TableCell>
                                  <TableCell className="text-right whitespace-nowrap">
                                    <Button size="sm" variant="ghost" onClick={() => deleteTaskTemplate(tt.id)}><Trash2 className="w-3 h-3 text-destructive" /></Button>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      )}
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ── FR-ONB-015 to 019: Onboarding Reports ── */}
        <TabsContent value="reports" className="mt-4">
          <OnboardingReportsTab />
        </TabsContent>

      </Tabs>

      {/* ── Create Process Dialog ── */}
      <Dialog open={createProcOpen} onOpenChange={setCreateProcOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Onboarding Process</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div>
              <Label>Template</Label>
              <Select value={procForm.template_id} onValueChange={v => setProcForm(f => ({ ...f, template_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Select template (optional)" /></SelectTrigger>
                <SelectContent>{templates.filter(t => t.template_status === 'ACTIVE').map(t => <SelectItem key={t.onboarding_template_id} value={t.onboarding_template_id}>{t.template_name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Proposed Start Date *</Label><Input type="date" value={procForm.proposed_start_date} onChange={e => setProcForm(f => ({ ...f, proposed_start_date: e.target.value }))} /></div>
              <div><Label>Expected Completion</Label><Input type="date" value={procForm.expected_completion_date} onChange={e => setProcForm(f => ({ ...f, expected_completion_date: e.target.value }))} /></div>
            </div>
            <div><Label>Probation End Date</Label><Input type="date" value={procForm.probation_end_date} onChange={e => setProcForm(f => ({ ...f, probation_end_date: e.target.value }))} /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCreateProcOpen(false)}>Cancel</Button>
              <Button onClick={createProcess} disabled={procSaving}>{procSaving ? 'Creating…' : 'Create'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Create Template Dialog ── */}
      <Dialog open={createTmplOpen} onOpenChange={setCreateTmplOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>New Onboarding Template</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div><Label>Template Name *</Label><Input value={tmplForm.template_name} onChange={e => setTmplForm(f => ({ ...f, template_name: e.target.value }))} placeholder="e.g. Software Engineer Onboarding" /></div>
            <div><Label>Role Code</Label><Input value={tmplForm.role_code} onChange={e => setTmplForm(f => ({ ...f, role_code: e.target.value }))} placeholder="e.g. SWE-001" /></div>
            <div>
              <Label>Status</Label>
              <Select value={tmplForm.template_status} onValueChange={v => setTmplForm(f => ({ ...f, template_status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="DRAFT">Draft</SelectItem>
                  <SelectItem value="ACTIVE">Active</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCreateTmplOpen(false)}>Cancel</Button>
              <Button onClick={createTemplate} disabled={tmplSaving}>{tmplSaving ? 'Saving…' : 'Create'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Add Task Template Dialog ── */}
      <Dialog open={!!addTaskOpen} onOpenChange={() => setAddTaskOpen(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add Task to Template</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div><Label>Task Name *</Label><Input value={taskForm.task_name} onChange={e => setTaskForm(f => ({ ...f, task_name: e.target.value }))} placeholder="e.g. Complete tax forms" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Assigned Role</Label>
                <Select value={taskForm.assigned_role} onValueChange={v => setTaskForm(f => ({ ...f, assigned_role: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['HR','Manager','IT','Employee','Finance','Legal'].map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>SLA (days)</Label><Input type="number" min="1" value={taskForm.default_sla_days} onChange={e => setTaskForm(f => ({ ...f, default_sla_days: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Mandatory</Label>
                <Select value={taskForm.is_mandatory} onValueChange={v => setTaskForm(f => ({ ...f, is_mandatory: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="1">Yes</SelectItem><SelectItem value="0">No</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label>Sequence Order</Label><Input type="number" min="1" value={taskForm.sequence_order} onChange={e => setTaskForm(f => ({ ...f, sequence_order: e.target.value }))} /></div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setAddTaskOpen(null)}>Cancel</Button>
              <Button onClick={addTaskTemplate} disabled={taskSaving}>{taskSaving ? 'Saving…' : 'Add Task'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   FR-ONB-015 to 019 – Onboarding Reports
   ───────────────────────────────────────────────────────────────────────── */
type ONBReport = { id: string; label: string; description: string };
const ONB_REPORTS: ONBReport[] = [
  { id: 'completion', label: 'Task Completion Report', description: 'FR-ONB-015: Shows completion % per employee and by task type' },
  { id: 'duration', label: 'Time-to-Productive Report', description: 'FR-ONB-016: Average days from start date to onboarding completion' },
  { id: 'overdue', label: 'Overdue Tasks Report', description: 'FR-ONB-017: All tasks past their due date grouped by process' },
  { id: 'buddy', label: 'Buddy Assignment Report', description: 'FR-ONB-018: Buddy pairing efficiency and completion tracking' },
  { id: 'department', label: 'Onboarding by Department', description: 'FR-ONB-019: Headcount onboarded per department per period' },
];

function OnboardingReportsTab() {
  const [selected, setSelected] = useState<string | null>(null);
  const [data, setData] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);

  const runReport = async (reportId: string) => {
    setSelected(reportId);
    setLoading(true);
    let query;
    if (reportId === 'completion') {
      query = sb.from('onboarding_processes').select('id, status, progress_pct:tasks_completed, employee_id').limit(100);
    } else if (reportId === 'overdue') {
      query = sb.from('onboarding_tasks').select('title, due_date, status, process_id').eq('status', 'pending').lt('due_date', new Date().toISOString().slice(0, 10)).limit(100);
    } else if (reportId === 'department') {
      query = sb.from('onboarding_processes').select('department, status, created_at').limit(200);
    } else {
      query = sb.from('onboarding_processes').select('*').limit(100);
    }
    const { data: rows } = await query;
    setData(rows || []);
    setLoading(false);
  };

  const selectedReport = ONB_REPORTS.find(r => r.id === selected);
  const columns = data.length > 0 ? Object.keys(data[0]) : [];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {ONB_REPORTS.map(r => (
          <Card key={r.id} className={`h-full cursor-pointer border-2 transition-colors ${selected === r.id ? 'border-primary' : 'border-border hover:border-primary/50'}`} onClick={() => runReport(r.id)}>
            <CardContent className="pt-4 pb-4">
              <div className="flex items-start gap-2.5">
                <FileBarChart2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="font-semibold text-sm text-balance">{r.label}</p>
                  <p className="text-xs text-muted-foreground mt-1 text-pretty">{r.description}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {selected && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">{selectedReport?.label}</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? <Skeleton className="h-32 bg-muted" /> : data.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">No data for this report</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader><TableRow>{columns.map(c => <TableHead key={c} className="whitespace-nowrap capitalize">{c.replace(/_/g, ' ')}</TableHead>)}</TableRow></TableHeader>
                  <TableBody>
                    {data.map((row, i) => (
                      <TableRow key={i}>
                        {columns.map(c => <TableCell key={c} className="whitespace-nowrap text-sm">{String(row[c] ?? '—')}</TableCell>)}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
