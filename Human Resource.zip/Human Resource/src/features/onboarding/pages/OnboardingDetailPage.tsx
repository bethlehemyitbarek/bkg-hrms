// OnboardingDetailPage — Module 8 (8.3 Process + 8.4 Tasks + 8.5 ContractSignature + 8.6 EquipmentProvisioning)
import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase as _sb } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft, Plus, CheckCircle2, Circle, AlertCircle, FileSignature, Package } from 'lucide-react';
import { toast } from 'sonner';

const sb = _sb as any; // eslint-disable-line

// ─── Types ───────────────────────────────────────────────────────────────────
type Process = {
  id: string; onboarding_process_id: string; process_number: string;
  process_status: string; conversion_status: string;
  proposed_start_date?: string; actual_start_date?: string;
  expected_completion_date?: string; actual_completion_date?: string;
  probation_end_date?: string; created_at: string;
  candidate?: { first_name: string; last_name: string; email?: string };
  employee?: { first_name: string; last_name: string; employee_no?: string };
  template?: { template_name: string };
};
type Task = {
  id: string; onboarding_task_id: string; task_name: string;
  task_type?: string; assigned_role?: string; task_status: string;
  priority: string; sla_status: string; due_date?: string;
  completed_at?: string; notes?: string;
  assigned_to?: { first_name: string; last_name: string };
};
type ContractSig = {
  id: string; contract_signature_id: string; signed_by_name: string;
  signature_status: string; signed_at?: string; document_hash?: string;
  created_at: string;
};
type Equipment = {
  id: string; equipment_provisioning_id: string;
  asset_category_requested: string; provisioning_status: string;
  created_at: string;
  fulfilled_asset?: { asset_name: string; asset_tag: string };
};

const STATUS_COLOR: Record<string, string> = {
  PENDING: 'bg-muted text-muted-foreground',
  IN_PROGRESS: 'bg-blue-100 text-blue-800',
  COMPLETED: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-red-100 text-red-800',
  WITHIN_SLA: 'bg-green-100 text-green-800',
  BREACHED: 'bg-red-100 text-red-800',
  ESCALATED: 'bg-orange-100 text-orange-800',
  REQUESTED: 'bg-blue-100 text-blue-800',
  APPROVED: 'bg-green-100 text-green-800',
  REJECTED: 'bg-red-100 text-red-800',
  FULFILLED: 'bg-green-100 text-green-800',
  PENDING_SIG: 'bg-yellow-100 text-yellow-800',
  SIGNED: 'bg-green-100 text-green-800',
  REVOKED: 'bg-red-100 text-red-800',
  FAILED: 'bg-red-100 text-red-800',
};

const PRIORITY_ICON: Record<string, React.ReactNode> = {
  CRITICAL: <AlertCircle className="w-4 h-4 text-red-500" />,
  HIGH: <AlertCircle className="w-4 h-4 text-orange-500" />,
  MEDIUM: <Circle className="w-4 h-4 text-yellow-500" />,
  LOW: <Circle className="w-4 h-4 text-muted-foreground" />,
};

export function OnboardingDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [process, setProcess] = useState<Process | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('tasks');

  // Tasks
  const [tasks, setTasks] = useState<Task[]>([]);
  const [tasksLoading, setTasksLoading] = useState(false);
  const [addTaskOpen, setAddTaskOpen] = useState(false);
  const [taskForm, setTaskForm] = useState({ task_name: '', task_type: 'OTHER', assigned_role: 'HR', priority: 'MEDIUM', due_date: '', notes: '' });
  const [taskSaving, setTaskSaving] = useState(false);

  // Contract Signatures
  const [signatures, setSignatures] = useState<ContractSig[]>([]);
  const [sigsLoading, setSigsLoading] = useState(false);
  const [addSigOpen, setAddSigOpen] = useState(false);
  const [sigForm, setSigForm] = useState({ signed_by_name: '' });
  const [sigSaving, setSigSaving] = useState(false);

  // Equipment
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [equipLoading, setEquipLoading] = useState(false);
  const [addEquipOpen, setAddEquipOpen] = useState(false);
  const [equipForm, setEquipForm] = useState({ asset_category_requested: '' });
  const [equipSaving, setEquipSaving] = useState(false);

  const loadProcess = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const { data, error } = await sb.from('onboarding_processes')
        .select('id,onboarding_process_id,process_number,process_status,conversion_status,proposed_start_date,actual_start_date,expected_completion_date,actual_completion_date,probation_end_date,created_at,candidate:candidates(first_name,last_name,email),employee:employees(first_name,last_name,employee_no),template:onboarding_templates(template_name)')
        .eq('onboarding_process_id', id)
        .eq('is_deleted', 0)
        .maybeSingle();
      if (error) throw error;
      setProcess(data);
    } catch (e: any) { toast.error(e.message); } finally { setLoading(false); }
  }, [id]);

  const loadTasks = useCallback(async () => {
    if (!id) return;
    setTasksLoading(true);
    try {
      const { data, error } = await sb.from('onboarding_tasks')
        .select('id,onboarding_task_id,task_name,task_type,assigned_role,task_status,priority,sla_status,due_date,completed_at,notes,assigned_to:employees(first_name,last_name)')
        .eq('onboarding_process_id', id)
        .eq('is_deleted', 0)
        .order('created_at', { ascending: true });
      if (error) throw error;
      setTasks(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setTasksLoading(false); }
  }, [id]);

  const loadSignatures = useCallback(async () => {
    if (!id) return;
    setSigsLoading(true);
    try {
      const { data, error } = await sb.from('contract_signatures')
        .select('id,contract_signature_id,signed_by_name,signature_status,signed_at,document_hash,created_at')
        .eq('onboarding_process_id', id)
        .eq('is_deleted', 0)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setSignatures(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setSigsLoading(false); }
  }, [id]);

  const loadEquipment = useCallback(async () => {
    if (!id) return;
    setEquipLoading(true);
    try {
      const { data, error } = await sb.from('equipment_provisionings')
        .select('id,equipment_provisioning_id,asset_category_requested,provisioning_status,created_at,fulfilled_asset:assets(asset_name,asset_tag)')
        .eq('onboarding_process_id', id)
        .eq('is_deleted', 0)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setEquipment(Array.isArray(data) ? data : []);
    } catch (e: any) { toast.error(e.message); } finally { setEquipLoading(false); }
  }, [id]);

  useEffect(() => { loadProcess(); }, [loadProcess]);
  useEffect(() => {
    if (tab === 'tasks') loadTasks();
    else if (tab === 'contracts') loadSignatures();
    else if (tab === 'equipment') loadEquipment();
  }, [tab, loadTasks, loadSignatures, loadEquipment]);

  async function updateTaskStatus(taskId: string, newStatus: string) {
    const update: Record<string, any> = { task_status: newStatus, updated_at: new Date().toISOString() };
    if (newStatus === 'COMPLETED') update.completed_at = new Date().toISOString();
    const { error } = await sb.from('onboarding_tasks').update(update).eq('id', taskId);
    if (error) toast.error(error.message);
    else { toast.success('Task updated'); loadTasks(); }
  }

  async function addTask() {
    if (!taskForm.task_name.trim()) { toast.error('Task name required'); return; }
    setTaskSaving(true);
    try {
      const { error } = await sb.from('onboarding_tasks').insert({
        onboarding_process_id: id,
        task_name: taskForm.task_name.trim(),
        task_type: taskForm.task_type,
        assigned_role: taskForm.assigned_role,
        priority: taskForm.priority,
        due_date: taskForm.due_date || null,
        notes: taskForm.notes || null,
        task_status: 'PENDING',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Task added');
      setAddTaskOpen(false);
      setTaskForm({ task_name: '', task_type: 'OTHER', assigned_role: 'HR', priority: 'MEDIUM', due_date: '', notes: '' });
      loadTasks();
    } catch (e: any) { toast.error(e.message); } finally { setTaskSaving(false); }
  }

  async function addSignature() {
    if (!sigForm.signed_by_name.trim()) { toast.error('Signer name required'); return; }
    setSigSaving(true);
    try {
      const { error } = await sb.from('contract_signatures').insert({
        onboarding_process_id: id,
        signed_by_name: sigForm.signed_by_name.trim(),
        signature_status: 'PENDING',
        effective_from: new Date().toISOString(),
        effective_to: '9999-12-31T00:00:00Z',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Signature record created');
      setAddSigOpen(false);
      setSigForm({ signed_by_name: '' });
      loadSignatures();
    } catch (e: any) { toast.error(e.message); } finally { setSigSaving(false); }
  }

  async function markSigned(sigId: string) {
    const { error } = await sb.from('contract_signatures').update({ signature_status: 'SIGNED', signed_at: new Date().toISOString(), updated_at: new Date().toISOString() }).eq('id', sigId);
    if (error) toast.error(error.message);
    else { toast.success('Marked as signed'); loadSignatures(); }
  }

  async function addEquipmentRequest() {
    if (!equipForm.asset_category_requested.trim()) { toast.error('Category required'); return; }
    setEquipSaving(true);
    try {
      const { error } = await sb.from('equipment_provisionings').insert({
        onboarding_process_id: id,
        asset_category_requested: equipForm.asset_category_requested.trim(),
        provisioning_status: 'REQUESTED',
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      toast.success('Equipment request created');
      setAddEquipOpen(false);
      setEquipForm({ asset_category_requested: '' });
      loadEquipment();
    } catch (e: any) { toast.error(e.message); } finally { setEquipSaving(false); }
  }

  async function updateEquipStatus(eqId: string, newStatus: string) {
    const { error } = await sb.from('equipment_provisionings').update({ provisioning_status: newStatus, updated_at: new Date().toISOString() }).eq('id', eqId);
    if (error) toast.error(error.message);
    else { toast.success('Status updated'); loadEquipment(); }
  }

  async function updateProcessStatus(newStatus: string) {
    const { error } = await sb.from('onboarding_processes').update({ process_status: newStatus, updated_at: new Date().toISOString() }).eq('onboarding_process_id', id);
    if (error) toast.error(error.message);
    else { toast.success('Process status updated'); loadProcess(); }
  }

  const completedTasks = tasks.filter(t => t.task_status === 'COMPLETED').length;
  const totalTasks = tasks.length;

  if (loading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-64 bg-muted" />
        <Skeleton className="h-32 w-full bg-muted" />
        <Skeleton className="h-64 w-full bg-muted" />
      </div>
    );
  }

  if (!process) {
    return (
      <div className="p-6">
        <Button variant="ghost" onClick={() => navigate('/onboarding')}><ArrowLeft className="w-4 h-4 mr-1" /> Back</Button>
        <p className="text-muted-foreground mt-4">Onboarding process not found.</p>
      </div>
    );
  }

  const displayName = process.candidate
    ? `${process.candidate.first_name} ${process.candidate.last_name}`
    : process.employee
    ? `${process.employee.first_name} ${process.employee.last_name}`
    : process.process_number;

  return (
    <div className="p-4 md:p-6 space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
        <div>
          <Button variant="ghost" size="sm" className="mb-2 -ml-2" onClick={() => navigate('/onboarding')}>
            <ArrowLeft className="w-4 h-4 mr-1" /> Back to Onboarding
          </Button>
          <h1 className="text-xl font-semibold">{displayName}</h1>
          <p className="text-sm text-muted-foreground font-mono">{process.process_number}</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {process.process_status === 'INITIATED' && (
            <Button size="sm" variant="outline" onClick={() => updateProcessStatus('IN_PROGRESS')}>Mark In Progress</Button>
          )}
          {process.process_status === 'IN_PROGRESS' && (
            <Button size="sm" onClick={() => updateProcessStatus('COMPLETED')}>Mark Completed</Button>
          )}
        </div>
      </div>

      {/* Process Summary Card */}
      <Card className="h-full">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div><p className="text-muted-foreground">Status</p>
              <Badge className={`mt-1 text-xs ${STATUS_COLOR[process.process_status] ?? 'bg-muted text-muted-foreground'}`}>{process.process_status}</Badge>
            </div>
            <div><p className="text-muted-foreground">Conversion</p>
              <Badge className="mt-1 text-xs bg-muted text-muted-foreground">{process.conversion_status.replace(/_/g, ' ')}</Badge>
            </div>
            <div><p className="text-muted-foreground">Template</p><p className="font-medium">{process.template?.template_name ?? '—'}</p></div>
            <div><p className="text-muted-foreground">Start Date</p><p className="font-medium">{process.proposed_start_date ?? '—'}</p></div>
            <div><p className="text-muted-foreground">Expected Completion</p><p className="font-medium">{process.expected_completion_date ?? '—'}</p></div>
            <div><p className="text-muted-foreground">Probation End</p><p className="font-medium">{process.probation_end_date ?? '—'}</p></div>
            <div><p className="text-muted-foreground">Task Progress</p>
              <p className="font-medium">{completedTasks} / {totalTasks} tasks</p>
            </div>
            <div><p className="text-muted-foreground">Email</p><p className="font-medium truncate">{process.candidate?.email ?? '—'}</p></div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="tasks">Tasks ({totalTasks})</TabsTrigger>
          <TabsTrigger value="contracts">Contracts</TabsTrigger>
          <TabsTrigger value="equipment">Equipment</TabsTrigger>
        </TabsList>

        {/* ── Tasks ── */}
        <TabsContent value="tasks" className="mt-4 space-y-3">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">{completedTasks} of {totalTasks} completed</p>
            <Button size="sm" onClick={() => setAddTaskOpen(true)}><Plus className="w-4 h-4 mr-1" /> Add Task</Button>
          </div>
          {tasksLoading ? (
            <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-12 w-full bg-muted" />)}</div>
          ) : tasks.length === 0 ? (
            <p className="text-center text-muted-foreground py-10">No tasks yet.</p>
          ) : (
            <div className="border rounded-lg overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap w-8"></TableHead>
                    <TableHead className="whitespace-nowrap">Task</TableHead>
                    <TableHead className="whitespace-nowrap">Type</TableHead>
                    <TableHead className="whitespace-nowrap">Role</TableHead>
                    <TableHead className="whitespace-nowrap">Due</TableHead>
                    <TableHead className="whitespace-nowrap">Priority</TableHead>
                    <TableHead className="whitespace-nowrap">SLA</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tasks.map(t => (
                    <TableRow key={t.id} className={t.task_status === 'COMPLETED' ? 'opacity-60' : ''}>
                      <TableCell>
                        {t.task_status === 'COMPLETED'
                          ? <CheckCircle2 className="w-5 h-5 text-green-600" />
                          : <Circle className="w-5 h-5 text-muted-foreground" />}
                      </TableCell>
                      <TableCell className="whitespace-nowrap font-medium">{t.task_name}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{t.task_type ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{t.assigned_role ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{t.due_date ?? '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <span className="flex items-center gap-1">{PRIORITY_ICON[t.priority]}<span className="text-xs">{t.priority}</span></span>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={`text-xs ${STATUS_COLOR[t.sla_status] ?? 'bg-muted text-muted-foreground'}`}>{t.sla_status}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={`text-xs ${STATUS_COLOR[t.task_status] ?? 'bg-muted text-muted-foreground'}`}>{t.task_status}</Badge>
                      </TableCell>
                      <TableCell className="text-right whitespace-nowrap">
                        <Select value={t.task_status} onValueChange={v => updateTaskStatus(t.id, v)}>
                          <SelectTrigger className="h-7 text-xs w-32"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="PENDING">Pending</SelectItem>
                            <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
                            <SelectItem value="COMPLETED">Completed</SelectItem>
                            <SelectItem value="CANCELLED">Cancelled</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>

        {/* ── Contracts ── */}
        <TabsContent value="contracts" className="mt-4 space-y-3">
          <div className="flex justify-end">
            <Button size="sm" onClick={() => setAddSigOpen(true)}><Plus className="w-4 h-4 mr-1" /> Add Signature</Button>
          </div>
          {sigsLoading ? (
            <Skeleton className="h-24 w-full bg-muted" />
          ) : signatures.length === 0 ? (
            <div className="flex flex-col items-center py-12 gap-2 text-muted-foreground">
              <FileSignature className="w-10 h-10" />
              <p>No contract signatures yet.</p>
            </div>
          ) : (
            <div className="border rounded-lg overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Signed By</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Signed At</TableHead>
                    <TableHead className="whitespace-nowrap">Document Hash</TableHead>
                    <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {signatures.map(s => (
                    <TableRow key={s.id}>
                      <TableCell className="whitespace-nowrap font-medium">{s.signed_by_name}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={`text-xs ${STATUS_COLOR[s.signature_status] ?? 'bg-muted text-muted-foreground'}`}>{s.signature_status}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{s.signed_at ? new Date(s.signed_at).toLocaleDateString() : '—'}</TableCell>
                      <TableCell className="whitespace-nowrap text-xs font-mono truncate max-w-[160px]">{s.document_hash ?? '—'}</TableCell>
                      <TableCell className="text-right whitespace-nowrap">
                        {s.signature_status === 'PENDING' && (
                          <Button size="sm" variant="ghost" onClick={() => markSigned(s.id)}>Mark Signed</Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>

        {/* ── Equipment ── */}
        <TabsContent value="equipment" className="mt-4 space-y-3">
          <div className="flex justify-end">
            <Button size="sm" onClick={() => setAddEquipOpen(true)}><Plus className="w-4 h-4 mr-1" /> Request Equipment</Button>
          </div>
          {equipLoading ? (
            <Skeleton className="h-24 w-full bg-muted" />
          ) : equipment.length === 0 ? (
            <div className="flex flex-col items-center py-12 gap-2 text-muted-foreground">
              <Package className="w-10 h-10" />
              <p>No equipment requests yet.</p>
            </div>
          ) : (
            <div className="border rounded-lg overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Category Requested</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Fulfilled Asset</TableHead>
                    <TableHead className="whitespace-nowrap">Requested At</TableHead>
                    <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {equipment.map(e => (
                    <TableRow key={e.id}>
                      <TableCell className="whitespace-nowrap font-medium">{e.asset_category_requested}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge className={`text-xs ${STATUS_COLOR[e.provisioning_status] ?? 'bg-muted text-muted-foreground'}`}>{e.provisioning_status}</Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">
                        {e.fulfilled_asset ? `${e.fulfilled_asset.asset_name} (${e.fulfilled_asset.asset_tag})` : '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{new Date(e.created_at).toLocaleDateString()}</TableCell>
                      <TableCell className="text-right whitespace-nowrap">
                        {e.provisioning_status === 'REQUESTED' && (
                          <Select onValueChange={v => updateEquipStatus(e.id, v)}>
                            <SelectTrigger className="h-7 text-xs w-28"><SelectValue placeholder="Update" /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="APPROVED">Approve</SelectItem>
                              <SelectItem value="REJECTED">Reject</SelectItem>
                              <SelectItem value="FULFILLED">Fulfilled</SelectItem>
                              <SelectItem value="CANCELLED">Cancel</SelectItem>
                            </SelectContent>
                          </Select>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* ── Add Task Dialog ── */}
      <Dialog open={addTaskOpen} onOpenChange={setAddTaskOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add Onboarding Task</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div><Label>Task Name *</Label><Input value={taskForm.task_name} onChange={e => setTaskForm(f => ({ ...f, task_name: e.target.value }))} placeholder="e.g. Complete employee handbook review" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Task Type</Label>
                <Select value={taskForm.task_type} onValueChange={v => setTaskForm(f => ({ ...f, task_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['DOCUMENT','TRAINING','POLICY','EQUIPMENT','IT_ACCESS','MEDICAL','COMPLIANCE','OTHER'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Assigned Role</Label>
                <Select value={taskForm.assigned_role} onValueChange={v => setTaskForm(f => ({ ...f, assigned_role: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['HR','Manager','IT','Employee','Finance','Legal'].map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Priority</Label>
                <Select value={taskForm.priority} onValueChange={v => setTaskForm(f => ({ ...f, priority: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{['LOW','MEDIUM','HIGH','CRITICAL'].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Due Date</Label><Input type="date" value={taskForm.due_date} onChange={e => setTaskForm(f => ({ ...f, due_date: e.target.value }))} /></div>
            </div>
            <div><Label>Notes</Label><Textarea value={taskForm.notes} onChange={e => setTaskForm(f => ({ ...f, notes: e.target.value }))} rows={2} /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setAddTaskOpen(false)}>Cancel</Button>
              <Button onClick={addTask} disabled={taskSaving}>{taskSaving ? 'Saving…' : 'Add Task'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Add Signature Dialog ── */}
      <Dialog open={addSigOpen} onOpenChange={setAddSigOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Add Contract Signature</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div><Label>Signer Full Name *</Label><Input value={sigForm.signed_by_name} onChange={e => setSigForm({ signed_by_name: e.target.value })} placeholder="Full legal name of the signer" /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setAddSigOpen(false)}>Cancel</Button>
              <Button onClick={addSignature} disabled={sigSaving}>{sigSaving ? 'Saving…' : 'Create'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Add Equipment Dialog ── */}
      <Dialog open={addEquipOpen} onOpenChange={setAddEquipOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Request Equipment</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <div>
              <Label>Category Requested *</Label>
              <Select value={equipForm.asset_category_requested} onValueChange={v => setEquipForm({ asset_category_requested: v })}>
                <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                <SelectContent>
                  {['LAPTOP','DESKTOP','PHONE','CARD','LICENSE','VEHICLE','OTHER'].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setAddEquipOpen(false)}>Cancel</Button>
              <Button onClick={addEquipmentRequest} disabled={equipSaving}>{equipSaving ? 'Requesting…' : 'Submit Request'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
