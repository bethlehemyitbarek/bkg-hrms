import { useState, useEffect, useCallback } from 'react';
import { useSelector } from 'react-redux';
import type { RootState } from '@/app/store';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { timesheetService } from '@/services/modules.service';
import { projectService, projectTaskService } from '@/services/project.service';
import { supabase as _supabase } from '@/db/supabase';
import type { Timesheet, Project, ProjectTask } from '@/types/database.types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import {
  RefreshCw, Plus, Clock, CheckCircle2, XCircle, Send, Eye,
  FileText, Lock, AlertCircle, ChevronRight, ChevronDown, Pencil, Trash2, ListChecks,
} from 'lucide-react';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = _supabase as any;

const STATUS_META: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  draft:     { label: 'Draft',     color: 'bg-muted text-muted-foreground',   icon: FileText },
  submitted: { label: 'Submitted', color: 'bg-blue-100 text-blue-800',        icon: Send },
  approved:  { label: 'Approved',  color: 'bg-green-100 text-green-800',      icon: CheckCircle2 },
  rejected:  { label: 'Rejected',  color: 'bg-red-100 text-red-800',          icon: XCircle },
  locked:    { label: 'Locked',    color: 'bg-purple-100 text-purple-800',    icon: Lock },
};

type FormData = {
  employee_id: string; period_start: string; period_end: string;
  regular_hours: string; overtime_hours: string; notes: string;
};
const emptyForm: FormData = {
  employee_id: '', period_start: '', period_end: '',
  regular_hours: '', overtime_hours: '0', notes: '',
};

interface TimesheetEntry {
  id: string; timesheet_id: string; work_date: string;
  hours_logged: number; regular_hours?: number; overtime_hours?: number;
  is_billable: number; project_id?: string; task_id?: string;
  remark?: string; task_description?: string;
  project?: { project_name: string; project_code: string };
  task?: { task_name: string };
}
const BLANK_ENTRY = {
  work_date: '', hours_logged: '', is_billable: '0',
  project_id: '', task_id: '', remark: '',
};

export function TimesheetPage() {
  const authUser = useSelector((s: RootState) => s.auth?.user);

  const [timesheets,   setTimesheets]   = useState<Timesheet[]>([]);
  const [loading,      setLoading]      = useState(true);
  const [total,        setTotal]        = useState(0);
  const [page,         setPage]         = useState(1);
  const pageSize = 20;

  const [statusFilter, setStatusFilter] = useState('all');
  const [empFilter,    setEmpFilter]    = useState('');
  const [createOpen,   setCreateOpen]   = useState(false);
  const [viewSheet,    setViewSheet]    = useState<Timesheet | null>(null);
  const [rejectId,     setRejectId]     = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [saving,       setSaving]       = useState(false);
  const [actionBusy,   setActionBusy]   = useState<string | null>(null);
  const [formData,     setFormData]     = useState<FormData>({ ...emptyForm });

  // Entry sub-panel
  const [expandedId,     setExpandedId]     = useState<string | null>(null);
  const [entries,        setEntries]        = useState<TimesheetEntry[]>([]);
  const [loadingEntries, setLoadingEntries] = useState(false);
  const [allProjects,    setAllProjects]    = useState<Project[]>([]);
  const [projectTasks,   setProjectTasks]   = useState<ProjectTask[]>([]);
  const [entryDialog,    setEntryDialog]    = useState(false);
  const [editEntry,      setEditEntry]      = useState<TimesheetEntry | null>(null);
  const [entryForm,      setEntryForm]      = useState({ ...BLANK_ENTRY });
  const [savingEntry,    setSavingEntry]    = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const result = await timesheetService.list({
        status:      statusFilter !== 'all' ? statusFilter : undefined,
        employee_id: empFilter || undefined,
        page, pageSize,
      });
      setTimesheets(result.data as Timesheet[]);
      setTotal(result.total);
    } catch { toast.error('Failed to load timesheets'); }
    finally { setLoading(false); }
  }, [statusFilter, empFilter, page]);

  useEffect(() => { load(); }, [load]);

  // Load projects once for dropdowns
  useEffect(() => {
    projectService.listAll()
      .then(d => setAllProjects(d as Project[]))
      .catch(() => {});
  }, []);

  // When project changes in entry form, load its tasks
  useEffect(() => {
    if (!entryForm.project_id) { setProjectTasks([]); return; }
    projectTaskService.listByProject(entryForm.project_id)
      .then(d => setProjectTasks(d as ProjectTask[]))
      .catch(() => setProjectTasks([]));
  }, [entryForm.project_id]);

  const loadEntries = useCallback(async (tsId: string) => {
    setLoadingEntries(true);
    try {
      const { data, error } = await db.from('timesheet_entries')
        .select('*, project:projects!timesheet_entries_project_id_fkey(project_name,project_code), task:project_tasks!timesheet_entries_task_id_fkey(task_name)')
        .eq('timesheet_id', tsId)
        .order('work_date', { ascending: true });
      if (error) throw error;
      setEntries(Array.isArray(data) ? data : []);
    } catch { toast.error('Failed to load entries'); }
    finally { setLoadingEntries(false); }
  }, []);

  const toggleExpand = (id: string) => {
    if (expandedId === id) { setExpandedId(null); setEntries([]); }
    else { setExpandedId(id); loadEntries(id); }
  };

  const calcTotal = (regular: string, overtime: string) =>
    (Number(regular) || 0) + (Number(overtime) || 0);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.employee_id || formData.employee_id === 'none') { toast.error('Select an employee'); return; }
    if (!formData.period_start || !formData.period_end) { toast.error('Set period dates'); return; }
    if (formData.period_end < formData.period_start) { toast.error('End date must be after start date'); return; }
    if (!formData.regular_hours) { toast.error('Enter regular hours'); return; }
    setSaving(true);
    try {
      const regular  = Number(formData.regular_hours);
      const overtime = Number(formData.overtime_hours) || 0;
      await timesheetService.create({
        employee_id: formData.employee_id,
        period_start: formData.period_start, period_end: formData.period_end,
        regular_hours: regular, overtime_hours: overtime,
        total_hours: regular + overtime, status: 'draft',
        notes: formData.notes || null,
      });
      toast.success('Timesheet created');
      setCreateOpen(false);
      setFormData({ ...emptyForm });
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed'); }
    finally { setSaving(false); }
  };

  const handleSubmit = async (id: string) => {
    setActionBusy(id);
    try { await timesheetService.submit(id); toast.success('Timesheet submitted for approval'); load(); }
    catch { toast.error('Failed to submit'); }
    finally { setActionBusy(null); }
  };

  const handleApprove = async (id: string) => {
    setActionBusy(id);
    try { await timesheetService.approve(id, authUser?.id ?? ''); toast.success('Timesheet approved'); load(); }
    catch { toast.error('Failed to approve'); }
    finally { setActionBusy(null); }
  };

  const handleRejectConfirm = async () => {
    if (!rejectId) return;
    setActionBusy(rejectId);
    try {
      await db.from('timesheets').update({
        status: 'rejected', rejection_reason: rejectReason || null,
        updated_at: new Date().toISOString(),
      }).eq('id', rejectId);
      toast.success('Timesheet rejected');
      setRejectId(null); setRejectReason(''); load();
    } catch { toast.error('Failed to reject'); }
    finally { setActionBusy(null); }
  };

  // Entry CRUD
  const openCreateEntry = () => {
    setEditEntry(null);
    setEntryForm({ ...BLANK_ENTRY });
    setEntryDialog(true);
  };
  const openEditEntry = (e: TimesheetEntry) => {
    setEditEntry(e);
    setEntryForm({
      work_date: e.work_date ?? '',
      hours_logged: String(e.hours_logged ?? ''),
      is_billable: String(e.is_billable ?? '0'),
      project_id: e.project_id ?? '',
      task_id: e.task_id ?? '',
      remark: e.remark ?? '',
    });
    setEntryDialog(true);
  };
  const saveEntry = async () => {
    if (!entryForm.work_date) { toast.error('Work date is required'); return; }
    if (!entryForm.hours_logged) { toast.error('Hours logged is required'); return; }
    if (!expandedId) return;
    setSavingEntry(true);
    try {
      const payload = {
        timesheet_id: expandedId,
        work_date: entryForm.work_date,
        hours_logged: Number(entryForm.hours_logged),
        is_billable: Number(entryForm.is_billable),
        project_id: entryForm.project_id || null,
        task_id: entryForm.task_id || null,
        remark: entryForm.remark || null,
        updated_at: new Date().toISOString(),
      };
      if (editEntry) {
        await db.from('timesheet_entries').update(payload).eq('id', editEntry.id);
        toast.success('Entry updated');
      } else {
        await db.from('timesheet_entries').insert({ ...payload, created_at: new Date().toISOString() });
        toast.success('Entry added');
      }
      setEntryDialog(false);
      loadEntries(expandedId);
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Save failed'); }
    finally { setSavingEntry(false); }
  };
  const deleteEntry = async (id: string) => {
    if (!expandedId) return;
    try {
      await db.from('timesheet_entries').delete().eq('id', id);
      toast.success('Entry deleted');
      loadEntries(expandedId);
    } catch { toast.error('Failed to delete entry'); }
  };

  const fmtDate = (d: string) => new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  const totalHoursInPeriod = (start: string, end: string) => {
    if (!start || !end) return null;
    const days = Math.floor((new Date(end).getTime() - new Date(start).getTime()) / 86400000) + 1;
    return `${days} day${days > 1 ? 's' : ''}`;
  };

  const stats = {
    total: timesheets.length,
    draft: timesheets.filter(t => t.status === 'draft').length,
    submitted: timesheets.filter(t => t.status === 'submitted').length,
    approved: timesheets.filter(t => t.status === 'approved').length,
    totalHours: timesheets.reduce((s, t) => s + (t.total_hours || 0), 0),
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Timesheets</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} records</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1.5 ${loading ? 'animate-spin' : ''}`} />Refresh
          </Button>
          <Button size="sm" onClick={() => { setFormData({ ...emptyForm }); setCreateOpen(true); }}>
            <Plus className="h-4 w-4 mr-1.5" />New Timesheet
          </Button>
        </div>
      </div>

      {/* Create Dialog */}
      <Dialog open={createOpen} onOpenChange={o => { if (!o) setCreateOpen(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>Create Timesheet</DialogTitle></DialogHeader>
          <form onSubmit={handleCreate} className="space-y-4 mt-2">
            <EmployeeSelect value={formData.employee_id} onChange={v => setFormData(p => ({ ...p, employee_id: v }))} required />
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Period Start *</Label>
                <Input type="date" value={formData.period_start}
                  onChange={e => setFormData(p => ({ ...p, period_start: e.target.value }))} required />
              </div>
              <div className="space-y-1.5">
                <Label>Period End *</Label>
                <Input type="date" value={formData.period_end}
                  onChange={e => setFormData(p => ({ ...p, period_end: e.target.value }))} required />
              </div>
            </div>
            {formData.period_start && formData.period_end && formData.period_end >= formData.period_start && (
              <p className="text-xs text-muted-foreground">Period: <strong>{totalHoursInPeriod(formData.period_start, formData.period_end)}</strong></p>
            )}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Regular Hours *</Label>
                <Input type="number" min="0" step="0.5" value={formData.regular_hours}
                  onChange={e => setFormData(p => ({ ...p, regular_hours: e.target.value }))}
                  placeholder="e.g. 40" required />
              </div>
              <div className="space-y-1.5">
                <Label>Overtime Hours</Label>
                <Input type="number" min="0" step="0.5" value={formData.overtime_hours}
                  onChange={e => setFormData(p => ({ ...p, overtime_hours: e.target.value }))} placeholder="0" />
              </div>
            </div>
            {(formData.regular_hours || formData.overtime_hours) && (
              <div className="bg-muted/40 rounded-lg px-3 py-2 text-sm flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground shrink-0" />
                Total: <strong>{calcTotal(formData.regular_hours, formData.overtime_hours)}h</strong>
                {Number(formData.overtime_hours) > 0 && (
                  <span className="text-muted-foreground">(incl. {formData.overtime_hours}h OT)</span>
                )}
              </div>
            )}
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Textarea value={formData.notes}
                onChange={e => setFormData(p => ({ ...p, notes: e.target.value }))}
                rows={2} placeholder="Optional notes…" />
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Create Timesheet'}</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Entry Add/Edit Dialog */}
      <Dialog open={entryDialog} onOpenChange={o => { if (!o) setEntryDialog(false); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle>{editEntry ? 'Edit Entry' : 'Add Time Entry'}</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Work Date *</Label>
                <Input type="date" value={entryForm.work_date}
                  onChange={e => setEntryForm(p => ({ ...p, work_date: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Hours Logged *</Label>
                <Input type="number" min="0.5" max="24" step="0.5" value={entryForm.hours_logged}
                  onChange={e => setEntryForm(p => ({ ...p, hours_logged: e.target.value }))} placeholder="e.g. 8" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Project</Label>
              <Select value={entryForm.project_id || 'none'}
                onValueChange={v => setEntryForm(p => ({ ...p, project_id: v === 'none' ? '' : v, task_id: '' }))}>
                <SelectTrigger><SelectValue placeholder="Select project (optional)" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No project</SelectItem>
                  {allProjects.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.project_code} – {p.project_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {entryForm.project_id && (
              <div className="space-y-1.5">
                <Label>Task</Label>
                <Select value={entryForm.task_id || 'none'}
                  onValueChange={v => setEntryForm(p => ({ ...p, task_id: v === 'none' ? '' : v }))}>
                  <SelectTrigger><SelectValue placeholder="Select task (optional)" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No specific task</SelectItem>
                    {projectTasks.map(t => (
                      <SelectItem key={t.id} value={t.id}>{t.task_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-1.5">
              <Label>Billable</Label>
              <Select value={entryForm.is_billable}
                onValueChange={v => setEntryForm(p => ({ ...p, is_billable: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Non-billable</SelectItem>
                  <SelectItem value="1">Billable</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Remark</Label>
              <Textarea value={entryForm.remark}
                onChange={e => setEntryForm(p => ({ ...p, remark: e.target.value }))}
                rows={2} placeholder="What did you work on?" />
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setEntryDialog(false)}>Cancel</Button>
              <Button onClick={saveEntry} disabled={savingEntry}>{savingEntry ? 'Saving…' : 'Save Entry'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Detail Dialog */}
      {viewSheet && (
        <Dialog open onOpenChange={o => { if (!o) setViewSheet(null); }}>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
            <DialogHeader><DialogTitle>Timesheet Details</DialogTitle></DialogHeader>
            <div className="space-y-4 mt-2 text-sm">
              {(() => {
                const emp = viewSheet.employee as { first_name: string; last_name: string; employee_no: string } | undefined;
                const sm  = STATUS_META[viewSheet.status] ?? STATUS_META.draft;
                return (
                  <>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${sm.color}`}>{sm.label}</span>
                      {(viewSheet.status === 'approved' || viewSheet.status === 'locked' || !!(viewSheet as unknown as { is_locked?: number }).is_locked) && (
                        <span className="flex items-center gap-1 text-xs text-purple-700 bg-purple-50 border border-purple-200 px-2 py-1 rounded-full font-medium">
                          <Lock className="h-3 w-3" /> Approved & Locked — no edits allowed
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        ['Employee',       emp ? `${emp.first_name} ${emp.last_name} (#${emp.employee_no})` : '—'],
                        ['Period Start',   fmtDate(viewSheet.period_start)],
                        ['Period End',     fmtDate(viewSheet.period_end)],
                        ['Regular Hours',  `${viewSheet.regular_hours}h`],
                        ['Overtime Hours', `${viewSheet.overtime_hours}h`],
                        ['Total Hours',    `${viewSheet.total_hours}h`],
                        ['Approved By',    viewSheet.approved_by ?? '—'],
                        ['Approved At',    viewSheet.approved_at ? new Date(viewSheet.approved_at).toLocaleString() : '—'],
                      ].map(([l, v]) => (
                        <div key={l} className="bg-muted/40 rounded-lg p-2.5">
                          <p className="text-xs text-muted-foreground">{l}</p>
                          <p className="font-medium">{v}</p>
                        </div>
                      ))}
                    </div>
                    {viewSheet.notes && (
                      <div className="space-y-1">
                        <p className="text-xs font-medium text-muted-foreground">Notes</p>
                        <p className="bg-muted/40 rounded-lg p-2.5">{viewSheet.notes}</p>
                      </div>
                    )}
                    {viewSheet.rejection_reason && (
                      <div className="space-y-1">
                        <p className="text-xs font-medium text-red-500">Rejection Reason</p>
                        <p className="bg-red-50 text-red-700 rounded-lg p-2.5">{viewSheet.rejection_reason}</p>
                      </div>
                    )}
                  </>
                );
              })()}
              <div className="flex justify-end">
                <Button variant="outline" onClick={() => setViewSheet(null)}>Close</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Reject Dialog */}
      <Dialog open={!!rejectId} onOpenChange={o => { if (!o) { setRejectId(null); setRejectReason(''); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle>Reject Timesheet</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label>Rejection Reason</Label>
              <Textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)}
                rows={3} placeholder="Optional reason…" />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => { setRejectId(null); setRejectReason(''); }}>Cancel</Button>
              <Button variant="destructive" onClick={handleRejectConfirm} disabled={!!actionBusy}>Confirm Reject</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: 'Total',       value: stats.total,             icon: FileText,     color: 'text-muted-foreground' },
          { label: 'Draft',       value: stats.draft,             icon: AlertCircle,  color: 'text-muted-foreground' },
          { label: 'Submitted',   value: stats.submitted,         icon: Send,         color: 'text-blue-500' },
          { label: 'Approved',    value: stats.approved,          icon: CheckCircle2, color: 'text-green-600' },
          { label: 'Total Hours', value: `${stats.totalHours}h`,  icon: Clock,        color: 'text-primary' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <s.icon className={`h-4 w-4 ${s.color} shrink-0`} />
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className="text-xl font-bold leading-tight">{s.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-end">
        <div className="space-y-1 min-w-[200px]">
          <Label className="text-xs">Employee</Label>
          <EmployeeSelect value={empFilter} onChange={v => { setEmpFilter(v === 'none' ? '' : v); setPage(1); }} />
        </div>
        <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setPage(1); }}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {Object.entries(STATUS_META).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button onClick={load}>Apply</Button>
        {(statusFilter !== 'all' || empFilter) && (
          <Button variant="ghost" size="sm" onClick={() => { setStatusFilter('all'); setEmpFilter(''); setPage(1); }}>Clear</Button>
        )}
      </div>

      {/* Table with expand-for-entries */}
      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap w-8"></TableHead>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Period Start</TableHead>
                <TableHead className="whitespace-nowrap">Period End</TableHead>
                <TableHead className="whitespace-nowrap">Regular (h)</TableHead>
                <TableHead className="whitespace-nowrap">OT (h)</TableHead>
                <TableHead className="whitespace-nowrap">Total (h)</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? Array.from({ length: 8 }).map((_, i) => (
                <TableRow key={i}>
                  {Array.from({ length: 9 }).map((__, j) => (
                    <TableCell key={j}><Skeleton className="h-4 w-16 bg-muted" /></TableCell>
                  ))}
                </TableRow>
              )) : timesheets.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-12 text-muted-foreground">
                    <Clock className="h-10 w-10 mx-auto mb-2 opacity-40" />No timesheets found
                  </TableCell>
                </TableRow>
              ) : timesheets.map(ts => {
                const emp  = ts.employee as { first_name: string; last_name: string; employee_no: string } | undefined;
                const sm   = STATUS_META[ts.status] ?? STATUS_META.draft;
                const busy = actionBusy === ts.id;
                const expanded = expandedId === ts.id;
                const isLocked = ts.status === 'approved' || ts.status === 'locked' || !!(ts as unknown as { is_locked?: number }).is_locked;
                return (
                  <>
                    <TableRow key={ts.id} className={expanded ? 'bg-muted/20' : ''}>
                      <TableCell className="whitespace-nowrap w-8">
                        <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => toggleExpand(ts.id)}>
                          {expanded ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
                        </Button>
                      </TableCell>
                      <TableCell className="whitespace-nowrap font-medium text-sm">
                        {emp ? `${emp.first_name} ${emp.last_name}` : ts.employee_id.slice(0, 8)}
                        {emp && <span className="text-xs text-muted-foreground ml-1">#{emp.employee_no}</span>}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{fmtDate(ts.period_start)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">{fmtDate(ts.period_end)}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-mono">{ts.regular_hours}</TableCell>
                      <TableCell className="whitespace-nowrap text-sm">
                        {ts.overtime_hours > 0
                          ? <Badge variant="secondary" className="font-mono text-xs">{ts.overtime_hours}</Badge>
                          : <span className="text-muted-foreground">—</span>}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm font-semibold">{ts.total_hours}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${sm.color}`}>{sm.label}</span>
                          {isLocked && (
                            <span title="Locked — approved by manager" className="text-purple-600">
                              <Lock className="h-3.5 w-3.5" />
                            </span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex items-center gap-1">
                          <Button size="sm" variant="outline" className="h-7 px-2" title="View details" onClick={() => setViewSheet(ts)}>
                            <Eye className="h-3.5 w-3.5" />
                          </Button>
                          {!isLocked && ts.status === 'draft' && (
                            <Button size="sm" variant="outline" className="h-7 px-2 text-blue-600 border-blue-200 hover:bg-blue-50"
                              disabled={busy} onClick={() => handleSubmit(ts.id)} title="Submit for approval">
                              <Send className="h-3.5 w-3.5" />
                            </Button>
                          )}
                          {!isLocked && ts.status === 'submitted' && (
                            <>
                              <Button size="sm" variant="outline" className="h-7 px-2 text-green-600 border-green-200 hover:bg-green-50"
                                disabled={busy} onClick={() => handleApprove(ts.id)} title="Approve">
                                <CheckCircle2 className="h-3.5 w-3.5" />
                              </Button>
                              <Button size="sm" variant="outline" className="h-7 px-2 text-red-500 border-red-200 hover:bg-red-50"
                                disabled={busy} onClick={() => { setRejectId(ts.id); setRejectReason(''); }} title="Reject">
                                <XCircle className="h-3.5 w-3.5" />
                              </Button>
                            </>
                          )}
                          {isLocked && (
                            <span className="flex items-center gap-1 text-xs text-purple-600 px-2 py-0.5 bg-purple-50 rounded border border-purple-200" title="Approved & locked — no edits allowed">
                              <Lock className="h-3 w-3" /> Locked
                            </span>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>

                    {/* Entries sub-panel */}
                    {expanded && (
                      <TableRow key={`${ts.id}-entries`}>
                        <TableCell colSpan={9} className="p-0 bg-muted/10">
                          <div className="border-t border-border px-6 py-4 space-y-3">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-medium flex items-center gap-1.5">
                                <ListChecks className="h-4 w-4 text-muted-foreground" />
                                Time Entries
                                {isLocked && (
                                  <span className="flex items-center gap-1 text-xs text-purple-600 font-normal">
                                    <Lock className="h-3 w-3" /> Read-only
                                  </span>
                                )}
                              </p>
                              {ts.status === 'draft' && !isLocked && (
                                <Button size="sm" variant="outline" className="h-7 text-xs" onClick={openCreateEntry}>
                                  <Plus className="h-3 w-3 mr-1" />Add Entry
                                </Button>
                              )}
                            </div>

                            {loadingEntries ? (
                              <div className="space-y-2">
                                {Array.from({ length: 3 }).map((_, i) => (
                                  <Skeleton key={i} className="h-8 w-full bg-muted" />
                                ))}
                              </div>
                            ) : entries.length === 0 ? (
                              <p className="text-xs text-muted-foreground py-4 text-center">
                                No time entries yet.
                                {ts.status === 'draft' ? ' Click "Add Entry" to log your time.' : ''}
                              </p>
                            ) : (
                              <div className="overflow-x-auto">
                                <Table>
                                  <TableHeader>
                                    <TableRow>
                                      <TableHead className="whitespace-nowrap text-xs">Date</TableHead>
                                      <TableHead className="whitespace-nowrap text-xs">Hours</TableHead>
                                      <TableHead className="whitespace-nowrap text-xs">Project</TableHead>
                                      <TableHead className="whitespace-nowrap text-xs">Task</TableHead>
                                      <TableHead className="whitespace-nowrap text-xs">Billable</TableHead>
                                      <TableHead className="whitespace-nowrap text-xs">Remark</TableHead>
                                      {ts.status === 'draft' && !isLocked && (
                                        <TableHead className="whitespace-nowrap text-xs text-right">Actions</TableHead>
                                      )}
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {entries.map(en => (
                                      <TableRow key={en.id}>
                                        <TableCell className="whitespace-nowrap text-xs">{fmtDate(en.work_date)}</TableCell>
                                        <TableCell className="whitespace-nowrap text-xs font-mono font-semibold">{en.hours_logged}h</TableCell>
                                        <TableCell className="whitespace-nowrap text-xs">
                                          {en.project ? (
                                            <span className="font-mono text-muted-foreground">
                                              {en.project.project_code}
                                            </span>
                                          ) : '—'}
                                        </TableCell>
                                        <TableCell className="whitespace-nowrap text-xs">
                                          {en.task?.task_name ?? '—'}
                                        </TableCell>
                                        <TableCell className="whitespace-nowrap text-xs">
                                          {en.is_billable
                                            ? <Badge className="text-xs bg-emerald-100 text-emerald-800">Billable</Badge>
                                            : <span className="text-muted-foreground">Non-billable</span>}
                                        </TableCell>
                                        <TableCell className="whitespace-nowrap text-xs text-muted-foreground max-w-[140px] truncate">
                                          {en.remark ?? '—'}
                                        </TableCell>
                                        {ts.status === 'draft' && !isLocked && (
                                          <TableCell className="whitespace-nowrap text-right">
                                            <div className="flex items-center justify-end gap-1">
                                              <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => openEditEntry(en)}>
                                                <Pencil className="h-3 w-3" />
                                              </Button>
                                              <Button size="sm" variant="ghost" className="h-6 w-6 p-0 text-destructive" onClick={() => deleteEntry(en.id)}>
                                                <Trash2 className="h-3 w-3" />
                                              </Button>
                                            </div>
                                          </TableCell>
                                        )}
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                              </div>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>

      {Math.ceil(total / pageSize) > 1 && (
        <div className="flex justify-end gap-2">
          <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</Button>
          <span className="text-sm self-center">{page} / {Math.ceil(total / pageSize)}</span>
          <Button size="sm" variant="outline" disabled={page >= Math.ceil(total / pageSize)} onClick={() => setPage(p => p + 1)}>Next</Button>
        </div>
      )}
    </div>
  );
}
