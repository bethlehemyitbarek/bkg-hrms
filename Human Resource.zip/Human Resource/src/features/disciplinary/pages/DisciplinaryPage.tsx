import { useState, useEffect, useCallback } from 'react';
import { disciplinaryService } from '@/services/modules.service';
import { EmployeeSelect } from '@/components/shared/EmployeeSelect';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, ShieldAlert } from 'lucide-react';
import { toast } from 'sonner';

const STATUS_COLORS: Record<string, string> = {
  open: 'bg-red-100 text-red-800',
  under_review: 'bg-yellow-100 text-yellow-800',
  closed: 'bg-green-100 text-green-800',
  appealed: 'bg-blue-100 text-blue-800',
};

const SEVERITY_COLORS: Record<string, string> = {
  minor: 'bg-yellow-100 text-yellow-800',
  moderate: 'bg-orange-100 text-orange-800',
  major: 'bg-red-100 text-red-800',
  gross_misconduct: 'bg-red-200 text-red-900',
};

export function DisciplinaryPage() {
  const [records, setRecords] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [dialog, setDialog] = useState(false);
  const [saving, setSaving] = useState(false);
  // DB columns: employee_id, incident_date, report_date, category, severity, description, action_taken, action_date, status
  const [form, setForm] = useState({
    employee_id: '', incident_date: '',
    category: 'misconduct', severity: 'minor',
    description: '', action_taken: '', status: 'open',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await disciplinaryService.list({ page: 1, pageSize: 30 });
      setRecords(res.data as Record<string, unknown>[]);
      setTotal(res.total);
    } catch { toast.error('Failed to load disciplinary records'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.employee_id || form.employee_id === 'none') { toast.error('Please select an employee'); return; }
    setSaving(true);
    try {
      await disciplinaryService.create({
        employee_id: form.employee_id,
        incident_date: form.incident_date,
        report_date: new Date().toISOString().split('T')[0],
        category: form.category,
        severity: form.severity,
        description: form.description,
        action_taken: form.action_taken || null,
        status: form.status,
      });
      toast.success('Disciplinary action recorded');
      setDialog(false);
      setForm({ employee_id: '', incident_date: '', category: 'misconduct', severity: 'minor', description: '', action_taken: '', status: 'open' });
      load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to record disciplinary action'); }
    finally { setSaving(false); }
  };

  const emp = (r: Record<string, unknown>) => {
    const e = r.employee as Record<string, unknown> | undefined;
    return e ? `${e.first_name} ${e.last_name}` : '—';
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2"><ShieldAlert className="h-5 w-5 text-primary" />Disciplinary Cases</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{total} cases</p>
        </div>
        <Dialog open={dialog} onOpenChange={setDialog}>
          <DialogTrigger asChild>
            <Button size="sm"><Plus className="h-4 w-4 mr-1.5" />Disciplinary Action</Button>
          </DialogTrigger>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
            <DialogHeader><DialogTitle>Record Disciplinary Action</DialogTitle></DialogHeader>
            <form onSubmit={handleCreate} className="space-y-4 mt-2">
              <EmployeeSelect value={form.employee_id} onChange={v => setForm(p => ({ ...p, employee_id: v }))} required />
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Category *</Label>
                  <Select value={form.category} onValueChange={v => setForm(p => ({ ...p, category: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="misconduct">Misconduct</SelectItem>
                      <SelectItem value="attendance">Attendance</SelectItem>
                      <SelectItem value="performance">Performance</SelectItem>
                      <SelectItem value="policy_violation">Policy Violation</SelectItem>
                      <SelectItem value="harassment">Harassment</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Severity *</Label>
                  <Select value={form.severity} onValueChange={v => setForm(p => ({ ...p, severity: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="minor">Minor</SelectItem>
                      <SelectItem value="moderate">Moderate</SelectItem>
                      <SelectItem value="major">Major</SelectItem>
                      <SelectItem value="gross_misconduct">Gross Misconduct</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1.5"><Label>Incident Date *</Label><Input type="date" value={form.incident_date} onChange={e => setForm(p => ({ ...p, incident_date: e.target.value }))} required /></div>
              <div className="space-y-1.5"><Label>Description *</Label><Textarea rows={3} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} required /></div>
              <div className="space-y-1.5"><Label>Action Taken</Label><Textarea rows={2} value={form.action_taken} onChange={e => setForm(p => ({ ...p, action_taken: e.target.value }))} /></div>
              <Button type="submit" className="w-full" disabled={saving}>{saving ? 'Saving…' : 'Record Action'}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="whitespace-nowrap">Case #</TableHead>
                <TableHead className="whitespace-nowrap">Employee</TableHead>
                <TableHead className="whitespace-nowrap">Category</TableHead>
                <TableHead className="whitespace-nowrap">Severity</TableHead>
                <TableHead className="whitespace-nowrap">Incident Date</TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? Array.from({ length: 5 }).map((_, i) => <TableRow key={i}>{Array.from({ length: 6 }).map((__, j) => <TableCell key={j}><Skeleton className="h-4 w-full bg-muted" /></TableCell>)}</TableRow>)
                : records.length === 0 ? <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No disciplinary cases found</TableCell></TableRow>
                : records.map(r => (
                  <TableRow key={String(r.id)}>
                    <TableCell className="whitespace-nowrap text-sm font-mono">{r.case_number ? String(r.case_number) : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap font-medium">{emp(r)}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm capitalize">{String(r.category).replace('_', ' ')}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={SEVERITY_COLORS[String(r.severity)] || 'bg-muted'}>{String(r.severity).replace('_', ' ')}</Badge></TableCell>
                    <TableCell className="whitespace-nowrap text-sm">{r.incident_date ? String(r.incident_date) : '—'}</TableCell>
                    <TableCell className="whitespace-nowrap"><Badge className={STATUS_COLORS[String(r.status)] || 'bg-muted'}>{String(r.status).replace('_', ' ')}</Badge></TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
export default DisciplinaryPage;
