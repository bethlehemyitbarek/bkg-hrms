export const HEADERS = {
  CORRELATION_ID: 'x-correlation-id',
  TENANT_ID: 'x-tenant-id',
  REQUEST_ID: 'x-request-id',
  USER_ID: 'x-user-id',
  USER_ROLES: 'x-user-roles',
  IDEMPOTENCY_KEY: 'x-idempotency-key',
} as const;
