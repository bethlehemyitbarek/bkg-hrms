import { z } from 'zod';

export const employeeSchema = z.object({
  id: z.string().uuid().optional(),
  employeeNumber: z.string().min(1).max(50),
  firstName: z.string().min(1).max(100),
  middleName: z.string().max(100).optional(),
  lastName: z.string().min(1).max(100),
  email: z.string().email(),
  phone: z.string().max(50).optional(),
  dateOfBirth: z.string().optional(),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER']).optional(),
  maritalStatus: z.string().optional(),
  nationality: z.string().optional(),
  hireDate: z.string().optional(),
  terminationDate: z.string().optional(),
  departmentId: z.string().uuid().optional(),
  positionId: z.string().uuid().optional(),
  employmentStatus: z.enum(['ACTIVE', 'INACTIVE', 'TERMINATED', 'SUSPENDED']).default('ACTIVE'),
  employmentType: z.enum(['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERN', 'TEMPORARY']).default('FULL_TIME'),
  tenantId: z.string().uuid().optional(),
});
