import { z } from 'zod';

export const workflowSchema = z.object({
  id: z.string().uuid().optional(),
  type: z.string().min(1),
  status: z.enum(['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED']).default('PENDING'),
  requesterId: z.string().uuid(),
  approverId: z.string().uuid().optional(),
  entityType: z.string(),
  entityId: z.string().uuid(),
  comments: z.string().optional(),
  tenantId: z.string().uuid().optional(),
});
