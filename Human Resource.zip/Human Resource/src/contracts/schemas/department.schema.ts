import { z } from 'zod';

export const departmentSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(1).max(200),
  code: z.string().min(1).max(50),
  description: z.string().optional(),
  parentId: z.string().uuid().optional(),
  managerId: z.string().uuid().optional(),
  costCenterId: z.string().uuid().optional(),
  isActive: z.boolean().default(true),
  tenantId: z.string().uuid().optional(),
});
