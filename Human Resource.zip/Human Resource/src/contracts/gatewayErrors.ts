export const GATEWAY_ERRORS: Record<string, string> = {
  'gateway.timeout': 'Request timed out. Please try again.',
  'gateway.unavailable': 'Service temporarily unavailable.',
};
