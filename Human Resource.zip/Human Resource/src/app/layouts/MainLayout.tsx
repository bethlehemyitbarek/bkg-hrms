import { useState, useEffect, useRef } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/shared/auth/useAuth';
import { useTenant } from '@/shared/tenant/useTenant';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  LayoutDashboard, Users, Building2, Clock, CalendarDays, Wallet, BarChart3,
  UserPlus, UserCheck, BookOpen, GraduationCap, ClipboardCheck, HandCoins, Briefcase, ArrowRightLeft,
  FileCheck, FileText, ClipboardList, Bell, Settings, LogOut, ChevronDown, ChevronRight,
  ShieldAlert, Package, MapPin, Layers, Calculator, Monitor,
  Menu, UserCircle, Shield, AlarmClock, ListChecks, DollarSign, CheckSquare,
  BarChart2, Percent, UserCog, Zap, Activity, CalendarCheck,
  Tag, LayoutList, Gift, ShieldCheck, Banknote, MoveRight, TrendingUp,
  FolderOpen, Megaphone, FolderKanban, ScrollText, CheckCheck, BellOff, RefreshCw,
  Scale, PieChart, History, LibraryBig,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { notificationEngine } from '@/services/notification-engine.service';

/* ─── Nav structure ────────────────────────────────────────────────────────
   Each entry is either a plain link  { label, path, icon, group }
   or a collapsible parent            { label, icon, group, children: [...] }
──────────────────────────────────────────────────────────────────────────── */
type NavLeaf   = { label: string; path: string; icon: React.ElementType; group: string; children?: undefined };
type NavParent = { label: string; icon: React.ElementType; group: string; children: NavLeaf[]; path?: undefined };
type NavItem   = NavLeaf | NavParent;

const nav: NavItem[] = [
  // ── Core ──────────────────────────────────────────────────────────────
  { label: 'Dashboard',    path: '/',              icon: LayoutDashboard, group: 'Core' },
  {
    label: 'Organization', icon: Building2, group: 'Core',
    children: [
      { label: 'Overview',  path: '/organization', icon: Building2, group: 'Core' },
    ],
  },
  {
    label: 'Employees', icon: Users, group: 'Core',
    children: [
      { label: 'All Employees', path: '/employees', icon: Users, group: 'Core' },
    ],
  },

  // ── Time ──────────────────────────────────────────────────────────────
  {
    label: 'Attendance', icon: Clock, group: 'Time',
    children: [
      { label: 'Overview',       path: '/attendance',                  icon: Clock,           group: 'Time' },
      { label: 'Dashboard',      path: '/attendance/dashboard',        icon: LayoutDashboard, group: 'Time' },
      { label: 'Work Calendar',  path: '/attendance/work-calendar',    icon: CalendarDays,    group: 'Time' },
      { label: 'Corrections',    path: '/attendance/corrections',      icon: ClipboardCheck,  group: 'Time' },
      { label: 'Auto-Compute',   path: '/attendance/auto-compute',     icon: Activity,        group: 'Time' },
    ],
  },
  {
    label: 'Leave', icon: CalendarDays, group: 'Time',
    children: [
      { label: 'Overview',    path: '/leave',               icon: CalendarDays, group: 'Time' },
      { label: 'Leave Report',path: '/leave/report',        icon: BarChart2,    group: 'Time' },
      { label: 'Leave Config',path: '/leave/config',        icon: FileCheck,    group: 'Time' },
      { label: 'Balances',    path: '/leave/balances',      icon: ListChecks,   group: 'Time' },
    ],
  },
  {
    label: 'Timesheets', icon: ClipboardList, group: 'Time',
    children: [
      { label: 'Overview', path: '/timesheets',          icon: ClipboardList, group: 'Time' },
      { label: 'Projects', path: '/timesheets/projects', icon: FolderKanban,  group: 'Time' },
    ],
  },
  {
    label: 'Shifts', icon: Layers, group: 'Time',
    children: [
      { label: 'Overview',    path: '/shifts',             icon: Layers,   group: 'Time' },
      { label: 'Shift Mgmt',  path: '/shifts/management',  icon: UserCog,  group: 'Time' },
    ],
  },
  { label: 'Overtime', path: '/overtime', icon: AlarmClock, group: 'Time' },

  // ── Finance ───────────────────────────────────────────────────────────
  {
    label: 'Payroll', icon: Wallet, group: 'Finance',
    children: [
      { label: 'Overview',        path: '/payroll',                    icon: Wallet,     group: 'Finance' },
      { label: 'Computation',     path: '/payroll/computation',        icon: Zap,        group: 'Finance' },
      { label: 'Runs',            path: '/payroll/runs',               icon: ListChecks, group: 'Finance' },
      { label: 'Components',      path: '/payroll/components',         icon: DollarSign, group: 'Finance' },
      { label: 'Salary Assign',   path: '/payroll/salary-assignment',  icon: UserCog,    group: 'Finance' },
      { label: 'Approval',        path: '/payroll/approval',           icon: CheckSquare,group: 'Finance' },
      { label: 'Reports',         path: '/payroll/reports',            icon: BarChart2,  group: 'Finance' },
      { label: 'Settings',        path: '/payroll/settings',           icon: Percent,    group: 'Finance' },
    ],
  },
  { label: 'Expenses', path: '/expenses', icon: Calculator, group: 'Finance' },
  {
    label: 'Benefits', icon: HandCoins, group: 'Finance',
    children: [
      { label: 'Overview',          path: '/benefits',                         icon: HandCoins,  group: 'Finance' },
      { label: 'Allowance Types',   path: '/benefits/allowance-types',         icon: Tag,        group: 'Finance' },
      { label: 'Comp. Structures',  path: '/benefits/compensation-structures', icon: LayoutList, group: 'Finance' },
      { label: 'Emp. Compensation', path: '/benefits/employee-compensation',   icon: DollarSign, group: 'Finance' },
      { label: 'Benefit Plans',     path: '/benefits/benefit-plans',           icon: Shield,     group: 'Finance' },
      { label: 'Enrollments',       path: '/benefits/enrollments',             icon: Users,      group: 'Finance' },
      { label: 'Bonus Config',      path: '/benefits/bonus-config',            icon: Gift,       group: 'Finance' },

    ],
  },
  { label: 'Compensation', path: '/compensation', icon: Scale, group: 'Finance' },
  {
    label: 'Loans', icon: Briefcase, group: 'Finance',
    children: [
      { label: 'Overview',      path: '/loans',           icon: Briefcase,  group: 'Finance' },
      { label: 'Loan Policies', path: '/loans/policy',    icon: ShieldCheck,group: 'Finance' },
      { label: 'Loan Requests', path: '/loans/requests',  icon: Banknote,   group: 'Finance' },
    ],
  },

  // ── Talent ────────────────────────────────────────────────────────────
  { label: 'Performance', path: '/performance', icon: BarChart3, group: 'Talent' },
  {
    label: 'Recruitment', icon: UserPlus, group: 'Talent',
    children: [
      { label: 'Overview',    path: '/recruitment',               icon: UserPlus,      group: 'Talent' },
      { label: 'Candidates',  path: '/recruitment/candidates',    icon: Users,         group: 'Talent' },
      { label: 'Exams',       path: '/recruitment/exams',         icon: GraduationCap, group: 'Talent' },
      { label: 'Interviews',  path: '/recruitment/interviews',    icon: CalendarDays,  group: 'Talent' },
      { label: 'Offers',      path: '/recruitment/offers',        icon: FileText,      group: 'Talent' },
    ],
  },
  {
    label: 'Training', icon: GraduationCap, group: 'Talent',
    children: [
      { label: 'Overview',  path: '/training',           icon: GraduationCap, group: 'Talent' },
      { label: 'Programs',  path: '/training/programs',  icon: BookOpen,      group: 'Talent' },
    ],
  },
  {
    label: 'Transfers', icon: ArrowRightLeft, group: 'Talent',
    children: [
      { label: 'Overview',         path: '/transfers',                icon: ArrowRightLeft, group: 'Talent' },
      { label: 'Transfer Req.',    path: '/transfers/requests',       icon: MoveRight,      group: 'Talent' },
      { label: 'Promotions',       path: '/promotions/requests',      icon: TrendingUp,     group: 'Talent' },
    ],
  },

  // ── Lifecycle ─────────────────────────────────────────────────────────
  {
    label: 'Onboarding', icon: ClipboardCheck, group: 'Lifecycle',
    children: [
      { label: 'Overview',  path: '/onboarding',           icon: ClipboardCheck, group: 'Lifecycle' },
      { label: 'Probation', path: '/onboarding/probation', icon: UserCheck,      group: 'Lifecycle' },
    ],
  },
  { label: 'Offboarding', path: '/offboarding', icon: Monitor,  group: 'Lifecycle' },
  { label: 'Separations', path: '/separations', icon: LogOut,   group: 'Lifecycle' },

  // ── Governance ────────────────────────────────────────────────────────
  { label: 'Grievances',     path: '/grievances',               icon: ShieldAlert,  group: 'Governance' },
  {
    label: 'Compliance', icon: ShieldCheck, group: 'Governance',
    children: [
      { label: 'Compliance Hub', path: '/governance/compliance',  icon: ShieldCheck,  group: 'Governance' },
      { label: 'DSAR Admin',     path: '/compliance/dsar-admin',  icon: FolderKanban, group: 'Governance' },
    ],
  },
  { label: 'Document Mgmt',  path: '/governance/documents',     icon: FolderOpen,   group: 'Governance' },
  { label: 'Assets',         path: '/assets',                   icon: Package,      group: 'Governance' },
  { label: 'Announcements',  path: '/announcements',            icon: Megaphone,    group: 'Governance' },
  { label: 'Audit Log',      path: '/audit-log',                icon: ScrollText,   group: 'Governance' },

  // ── Self Service ──────────────────────────────────────────────────────
  {
    label: 'ESS', icon: UserCircle, group: 'Self Service',
    children: [
      { label: 'Overview',        path: '/ess',                icon: UserCircle,   group: 'Self Service' },
      { label: 'Leave Workflow',  path: '/ess/leave-workflow', icon: CalendarCheck,group: 'Self Service' },
    ],
  },
  { label: 'MSS',           path: '/mss',           icon: Shield,         group: 'Self Service' },
  { label: 'Workflow',      path: '/workflow',       icon: ClipboardCheck, group: 'Self Service' },

  // ── System ────────────────────────────────────────────────────────────
  { label: 'Lookups',  path: '/lookups',  icon: LibraryBig, group: 'System' },
  { label: 'Settings', path: '/settings', icon: Settings,   group: 'System' },
];

const groups = ['Core', 'Time', 'Finance', 'Talent', 'Lifecycle', 'Governance', 'Self Service', 'System'];

/* ─── Collapsible nav item ─────────────────────────────────────────────── */
function NavParentItem({ item, onNavigate }: { item: NavParent; onNavigate?: () => void }) {
  const location = useLocation();
  const isChildActive = item.children.some(c =>
    c.path === '/' ? location.pathname === '/' : location.pathname === c.path
  );
  const [open, setOpen] = useState(isChildActive);
  const Icon = item.icon;

  return (
    <div className="mb-0.5">
      <button
        onClick={() => setOpen(o => !o)}
        className={cn(
          'flex items-center gap-2.5 px-3 py-1.5 rounded-md text-sm transition-colors w-full text-left',
          isChildActive
            ? 'bg-primary/10 text-primary font-medium'
            : 'text-foreground/80 hover:bg-muted hover:text-foreground'
        )}
      >
        <Icon className="h-4 w-4 shrink-0" />
        <span className="flex-1 truncate">{item.label}</span>
        {open
          ? <ChevronDown className="h-3.5 w-3.5 shrink-0 opacity-60" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />}
      </button>
      {open && (
        <div className="mt-0.5 ml-3 pl-3 border-l border-border/60 space-y-0.5">
          {item.children.map(child => {
            const CIcon = child.icon;
            const isActive = child.path === '/'
              ? location.pathname === '/'
              : location.pathname === child.path;
            return (
              <Link
                key={child.path}
                to={child.path}
                onClick={onNavigate}
                className={cn(
                  'flex items-center gap-2 px-2.5 py-1.5 rounded-md text-sm transition-colors',
                  isActive
                    ? 'bg-primary text-primary-foreground font-medium'
                    : 'text-foreground/70 hover:bg-muted hover:text-foreground'
                )}
              >
                <CIcon className="h-3.5 w-3.5 shrink-0" />
                <span className="truncate">{child.label}</span>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ─── NavContent (sidebar body) ────────────────────────────────────────── */
interface NavContentProps { onNavigate?: () => void; }

function NavContent({ onNavigate }: NavContentProps) {
  const { logout, user } = useAuth();
  const { tenantName } = useTenant();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    toast.success('Signed out successfully.');
    navigate('/login');
  };

  const userInitials = user?.username
    ? user.username.slice(0, 2).toUpperCase()
    : user?.email?.slice(0, 2).toUpperCase() ?? 'HR';

  return (
    <div className="flex flex-col h-full">
      {/* Brand */}
      <div className="px-4 py-4 border-b border-border shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shrink-0">
            <Building2 className="h-4 w-4 text-primary-foreground" />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-bold text-foreground truncate">BKG HRMS</p>
            {tenantName && <p className="text-xs text-muted-foreground truncate">{tenantName}</p>}
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-2 py-2">
        {groups.map(group => {
          const items = nav.filter(l => l.group === group);
          return (
            <div key={group} className="mb-3">
              <p className="px-3 mb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                {group}
              </p>
              {items.map(item => {
                if (item.children) {
                  return <NavParentItem key={item.label} item={item} onNavigate={onNavigate} />;
                }
                const Icon = item.icon;
                const isActive = item.path === '/'
                  ? location.pathname === '/'
                  : location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={onNavigate}
                    className={cn(
                      'flex items-center gap-2.5 px-3 py-1.5 rounded-md text-sm transition-colors mb-0.5',
                      isActive
                        ? 'bg-primary text-primary-foreground font-medium'
                        : 'text-foreground/80 hover:bg-muted hover:text-foreground'
                    )}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </Link>
                );
              })}
            </div>
          );
        })}
      </nav>

      {/* User footer */}
      <div className="px-2 py-3 border-t border-border shrink-0">
        <div className="flex items-center gap-2.5 px-2 mb-2">
          <Avatar className="h-7 w-7 shrink-0">
            <AvatarFallback className="text-xs bg-primary/10 text-primary">{userInitials}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-foreground truncate">{user?.username || user?.email || 'User'}</p>
            <p className="text-[10px] text-muted-foreground truncate">{user?.roles?.[0] ?? 'Employee'}</p>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2.5 px-3 py-1.5 w-full text-sm text-destructive hover:bg-destructive/10 rounded-md transition-colors"
        >
          <LogOut className="h-4 w-4 shrink-0" />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );
}

/* ─── Notification Dropdown ─────────────────────────────────────────────── */
type NotifRow = Record<string, unknown> & {
  id: string;
  title: string;
  message: string;
  notification_type?: string;
  module?: string;
  is_read: boolean;
  created_at: string;
  action_url?: string;
};

const NOTIF_TABS = [
  { key: 'all',       label: 'All' },
  { key: 'unread',    label: 'Unread' },
  { key: 'dsar',      label: 'DSAR' },
  { key: 'timesheet', label: 'Timesheet' },
  { key: 'leave',     label: 'Leave' },
  { key: 'payroll',   label: 'Payroll' },
] as const;
type NotifTabKey = typeof NOTIF_TABS[number]['key'];

function NotificationDropdown({
  unreadCount,
  onCountChange,
}: {
  unreadCount: number;
  onCountChange: (n: number) => void;
}) {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<NotifTabKey>('all');
  const [items, setItems] = useState<NotifRow[]>([]);
  const [loading, setLoading] = useState(false);
  const ref         = useRef<HTMLDivElement>(null);
  const listRef     = useRef<HTMLDivElement>(null);
  const savedScroll = useRef(0);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => {
    if (listRef.current && savedScroll.current > 0) {
      listRef.current.scrollTop = savedScroll.current;
    }
  }, [items]);

  const loadNotifs = async (tab: NotifTabKey = activeTab) => {
    setLoading(true);
    savedScroll.current = 0;
    try {
      const moduleMap: Partial<Record<NotifTabKey, string>> = {
        dsar: 'dsar', timesheet: 'timesheet', leave: 'leave', payroll: 'payroll',
      };
      const rows = await notificationEngine.getFiltered({
        unread_only: tab === 'unread',
        module: moduleMap[tab],
        limit: 30,
      });
      setItems(rows as NotifRow[]);
    } catch { /* silent */ }
    finally { setLoading(false); }
  };

  const handleTabChange = (tab: NotifTabKey) => {
    setActiveTab(tab);
    loadNotifs(tab);
  };

  const handleOpen = () => {
    const willOpen = !open;
    setOpen(willOpen);
    if (willOpen) loadNotifs(activeTab);
  };

  const markOne = async (id: string) => {
    savedScroll.current = listRef.current?.scrollTop ?? 0;
    setItems(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
    onCountChange(Math.max(0, unreadCount - 1));
    notificationEngine.markRead(id).catch(() => {/* silent */});
  };

  const markAll = async () => {
    savedScroll.current = listRef.current?.scrollTop ?? 0;
    setItems(prev => prev.map(n => ({ ...n, is_read: true })));
    onCountChange(0);
    notificationEngine.markAllRead(undefined as unknown as string).catch(() => {/* silent */});
  };

  const timeAgo = (iso: string) => {
    const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
    if (diff < 60)   return `${diff}s ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  };

  const typeColor: Record<string, string> = {
    POLICY_PUBLISHED:       'bg-blue-500',
    ANNOUNCEMENT_PUBLISHED: 'bg-violet-500',
    TIMESHEET_APPROVED:     'bg-green-500',
    TIMESHEET_REJECTED:     'bg-red-500',
    TIMESHEET_UNLOCKED:     'bg-purple-500',
    DSAR_STATUS_UPDATED:    'bg-amber-500',
    DSAR_CRON_FAILED:       'bg-red-600',
    info: 'bg-blue-400', warning: 'bg-amber-400', success: 'bg-green-400',
    error: 'bg-red-400', reminder: 'bg-purple-400', approval: 'bg-teal-400',
  };

  const filteredItems = items;
  const unreadInView = filteredItems.filter(n => !n.is_read).length;

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={handleOpen}
        className="relative flex h-9 w-9 items-center justify-center rounded-lg hover:bg-muted transition-colors"
        aria-label="Notifications"
      >
        <Bell className="h-4 w-4" />
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-white leading-none shadow-sm">
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-11 z-50 w-80 rounded-xl border border-border bg-card shadow-xl overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <div className="flex items-center gap-2">
              <Bell className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold">Notifications</span>
              {unreadCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-destructive text-white text-[10px] font-bold">
                  {unreadCount}
                </span>
              )}
            </div>
            <div className="flex items-center gap-1">
              {unreadInView > 0 && (
                <button
                  onClick={markAll}
                  className="flex items-center gap-1 text-xs text-primary hover:underline px-1.5 py-1 rounded hover:bg-primary/10 transition-colors"
                  title="Mark all as read"
                >
                  <CheckCheck className="h-3.5 w-3.5" />
                  All read
                </button>
              )}
              <button
                onClick={() => { savedScroll.current = 0; loadNotifs(activeTab); }}
                disabled={loading}
                className="flex items-center justify-center h-6 w-6 rounded hover:bg-muted transition-colors text-muted-foreground hover:text-foreground disabled:opacity-40"
                title="Refresh notifications"
              >
                <RefreshCw className={cn('h-3.5 w-3.5', loading && 'animate-spin')} />
              </button>
            </div>
          </div>

          {/* Filter Tabs */}
          <div className="flex gap-0 border-b border-border overflow-x-auto scrollbar-none">
            {NOTIF_TABS.map(tab => (
              <button
                key={tab.key}
                onClick={() => handleTabChange(tab.key)}
                className={cn(
                  'whitespace-nowrap px-3 py-2 text-xs font-medium transition-colors shrink-0',
                  activeTab === tab.key
                    ? 'border-b-2 border-primary text-primary'
                    : 'text-muted-foreground hover:text-foreground'
                )}
              >
                {tab.label}
                {tab.key === 'unread' && unreadCount > 0 && (
                  <span className="ml-1 px-1 py-0.5 rounded-full bg-destructive text-white text-[9px] font-bold leading-none">
                    {unreadCount}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* List */}
          <div ref={listRef} className="max-h-72 overflow-y-auto divide-y divide-border/40">
            {loading ? (
              <div className="p-4 space-y-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="flex gap-3">
                    <Skeleton className="h-8 w-8 rounded-full shrink-0" />
                    <div className="flex-1 space-y-1.5">
                      <Skeleton className="h-3 w-3/4" />
                      <Skeleton className="h-3 w-full" />
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
                <BellOff className="h-8 w-8 mb-2 opacity-30" />
                <p className="text-sm">
                  {activeTab === 'unread' ? 'All caught up!' : 'No notifications'}
                </p>
              </div>
            ) : (
              filteredItems.map(n => (
                <div
                  key={n.id}
                  className={cn(
                    'flex gap-3 px-4 py-3 hover:bg-muted/50 transition-colors cursor-pointer group',
                    !n.is_read && 'bg-primary/5'
                  )}
                  onClick={() => {
                    if (!n.is_read) markOne(n.id);
                    if (n.action_url) { navigate(n.action_url as string); setOpen(false); }
                  }}
                >
                  <div className="mt-1.5 shrink-0">
                    <div className={cn(
                      'h-2 w-2 rounded-full',
                      !n.is_read
                        ? (typeColor[n.notification_type ?? ''] ?? 'bg-primary')
                        : 'bg-muted-foreground/30'
                    )} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={cn('text-xs font-semibold leading-snug', n.is_read && 'text-muted-foreground')}>
                      {n.title}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.message}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-[10px] text-muted-foreground/60">{timeAgo(n.created_at)}</p>
                      {n.module && (
                        <span className="text-[9px] font-medium px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground uppercase tracking-wide">
                          {String(n.module)}
                        </span>
                      )}
                    </div>
                  </div>
                  {!n.is_read && (
                    <button
                      onClick={e => { e.stopPropagation(); markOne(n.id); }}
                      className="opacity-0 group-hover:opacity-100 transition-opacity shrink-0 mt-1 p-1 rounded hover:bg-muted"
                      title="Mark as read"
                    >
                      <CheckCheck className="h-3 w-3 text-primary" />
                    </button>
                  )}
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="border-t border-border px-4 py-2.5 flex items-center justify-between gap-2">
            <button
              onClick={() => { navigate('/notifications'); setOpen(false); }}
              className="text-xs text-primary hover:underline"
            >
              View all →
            </button>
            <button
              onClick={() => { navigate('/notifications/preferences'); setOpen(false); }}
              className="text-xs text-muted-foreground hover:text-foreground hover:underline"
            >
              ⚙ Preferences
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── MainLayout ────────────────────────────────────────────────────────── */
export function MainLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  const [unreadCount, setUnreadCount] = useState(0);

  // Poll unread notification count every 30s
  useEffect(() => {
    let cancelled = false;
    const fetchUnread = async () => {
      try {
        const count = await notificationEngine.getUnreadCount();
        if (!cancelled) setUnreadCount(count);
      } catch { /* silent */ }
    };
    fetchUnread();
    const timer = setInterval(fetchUnread, 30_000);
    return () => { cancelled = true; clearInterval(timer); };
  }, []);

  const userInitials = user?.username
    ? user.username.slice(0, 2).toUpperCase()
    : user?.email?.slice(0, 2).toUpperCase() ?? 'HR';

  return (
    <div className="flex min-h-screen w-full">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-60 shrink-0 border-r border-border bg-card">
        <NavContent />
      </aside>

      {/* Main content column */}
      <div className="flex-1 min-w-0 flex flex-col overflow-x-hidden">

        {/* ── Top bar ──────────────────────────────────────────────── */}
        <header className="flex items-center gap-3 px-4 py-2.5 border-b border-border bg-card/95 backdrop-blur-sm shrink-0 sticky top-0 z-30">
          {/* Mobile menu */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden shrink-0 h-8 w-8">
                <Menu className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-60 p-0 bg-card">
              <NavContent onNavigate={() => setMobileOpen(false)} />
            </SheetContent>
          </Sheet>

          <span className="hidden lg:block text-sm font-bold text-primary tracking-tight">BKG HRMS</span>
          <span className="lg:hidden font-semibold text-foreground flex-1 min-w-0 truncate">BKG HRMS</span>
          <div className="flex-1" />

          {/* Notification dropdown */}
          <NotificationDropdown
            unreadCount={unreadCount}
            onCountChange={setUnreadCount}
          />

          {/* User avatar */}
          <Avatar
            className="h-8 w-8 shrink-0 cursor-pointer ring-2 ring-transparent hover:ring-primary/40 transition-all"
            onClick={() => navigate('/settings')}
          >
            <AvatarFallback className="text-xs bg-primary/10 text-primary font-semibold">{userInitials}</AvatarFallback>
          </Avatar>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-background">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
