import { Outlet } from 'react-router-dom';

// Auth pages (LoginPage, MfaVerifyPage, etc.) manage their own full-screen layout.
// This layout is a transparent pass-through.
export function AuthLayout() {
  return <Outlet />;
}
