import { combineReducers } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import tenantReducer from './slices/tenantSlice';

export const rootReducer = combineReducers({
  auth: authReducer,
  tenant: tenantReducer,
});
