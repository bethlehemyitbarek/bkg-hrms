import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface TenantState {
  tenantId: string | null;
  tenantName: string | null;
  isLoaded: boolean;
}

const initialState: TenantState = {
  tenantId: localStorage.getItem('tenant_id'),
  tenantName: localStorage.getItem('tenant_name'),
  isLoaded: true,
};

const tenantSlice = createSlice({
  name: 'tenant',
  initialState,
  reducers: {
    setTenant(state, action: PayloadAction<{ tenantId: string; tenantName: string }>) {
      state.tenantId = action.payload.tenantId;
      state.tenantName = action.payload.tenantName;
      localStorage.setItem('tenant_id', action.payload.tenantId);
      localStorage.setItem('tenant_name', action.payload.tenantName);
    },
    clearTenant(state) {
      state.tenantId = null;
      state.tenantName = null;
      localStorage.removeItem('tenant_id');
      localStorage.removeItem('tenant_name');
    },
  },
});

export const { setTenant, clearTenant } = tenantSlice.actions;
export default tenantSlice.reducer;
