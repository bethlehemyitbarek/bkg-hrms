import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { StoreProvider } from './providers/StoreProvider';
import { QueryProvider } from './providers/QueryProvider';
import { MainLayout } from './layouts/MainLayout';
import { AuthLayout } from './layouts/AuthLayout';
import { ProtectedRoute } from './providers/ProtectedRoute';
import { IdleTimeout } from './providers/IdleTimeout';
import { RootState } from './store';
import { ROUTES } from './routes';

import LoginPage from '@/features/auth/pages/LoginPage';
import MfaVerifyPage from '@/features/auth/pages/MfaVerifyPage';
import PasswordChangePage from '@/features/auth/pages/PasswordChangePage';
import UnauthorizedPage from '@/features/auth/pages/UnauthorizedPage';

import { DashboardPage } from '@/features/dashboard/pages/DashboardPage';
import { OrganizationStructurePage } from '@/features/organization-structure/pages/OrganizationStructurePage';
import { EmployeeListPage } from '@/features/employee-manageme/employee/pages/EmployeeListPage';
import { EmployeeProfilePage } from '@/features/employee-manageme/employee/pages/EmployeeProfilePage';
import { AttendancePage } from '@/features/attendance/pages/AttendancePage';
import { WorkCalendarPage } from '@/features/attendance/pages/WorkCalendarPage';
import { AttendanceDashboardPage } from '@/features/attendance/pages/AttendanceDashboardPage';
import { AttendanceCorrectionPage } from '@/features/attendance/pages/AttendanceCorrectionPage';
import { AttendanceAutoComputePage } from '@/features/attendance/pages/AttendanceAutoComputePage';
import { LeavePage } from '@/features/leave/pages/LeavePage';
import { LeaveReportPage } from '@/features/leave/pages/LeaveReportPage';
import { LeaveManagementConfigPage } from '@/features/leave/pages/LeaveManagementConfigPage';
import { LeaveBalanceRequestPage } from '@/features/leave/pages/LeaveBalanceRequestPage';
import { PayrollPage } from '@/features/payroll/pages/PayrollPage';
import { PayrollRunsPage } from '@/features/payroll/pages/PayrollRunsPage';
import { PayrollRunDetailPage } from '@/features/payroll/pages/PayrollRunDetailPage';
import { PayrollComponentsPage } from '@/features/payroll/pages/PayrollComponentsPage';
import { PayrollApprovalPage } from '@/features/payroll/pages/PayrollApprovalPage';
import { PayrollReportsPage } from '@/features/payroll/pages/PayrollReportsPage';
import { PayrollSettingsPage } from '@/features/payroll/pages/PayrollSettingsPage';
import { SalaryAssignmentPage } from '@/features/payroll/pages/SalaryAssignmentPage';
import { PayrollComputationPage } from '@/features/payroll/pages/PayrollComputationPage';
import { PerformancePage } from '@/features/performance/pages/PerformancePage';
import { RecruitmentPage } from '@/features/recruitment/pages/RecruitmentPage';
import { VacancyDetailPage } from '@/features/recruitment/pages/VacancyDetailPage';
import { CandidatesPage } from '@/features/recruitment/pages/CandidatesPage';
import { ExamsPage } from '@/features/recruitment/pages/ExamsPage';
import { InterviewsPage } from '@/features/recruitment/pages/InterviewsPage';
import { OffersPage } from '@/features/recruitment/pages/OffersPage';
import { OnboardingPage } from '@/features/onboarding/pages/OnboardingPage';
import { OnboardingDetailPage } from '@/features/onboarding/pages/OnboardingDetailPage';
import { ProbationPage } from '@/features/onboarding/pages/ProbationPage';
import { TrainingPage } from '@/features/training/pages/TrainingPage';
import { TrainingProgramsPage } from '@/features/training/pages/TrainingProgramsPage';
import { TrainingSessionDetailPage } from '@/features/training/pages/TrainingSessionDetailPage';
import { OffboardingPage } from '@/features/offboarding/pages/OffboardingPage';
import { BenefitsPage } from '@/features/benefits/pages/BenefitsPage';
import { AllowanceTypesPage } from '@/features/benefits/pages/AllowanceTypesPage';
import { CompensationStructurePage } from '@/features/benefits/pages/CompensationStructurePage';
import { EmployeeCompensationPage } from '@/features/benefits/pages/EmployeeCompensationPage';
import { BenefitPlansPage } from '@/features/benefits/pages/BenefitPlansPage';
import { BenefitEnrollmentPage } from '@/features/benefits/pages/BenefitEnrollmentPage';
import { BonusConfigPage } from '@/features/benefits/pages/BonusConfigPage';
import { LoanDashboardPage } from '@/features/loan/pages/LoanDashboardPage';
import { LoanPage } from '@/features/loan/pages/LoanPage';
import { LoanPolicyPage } from '@/features/loan/pages/LoanPolicyPage';
import { LoanRequestPage } from '@/features/loan/pages/LoanRequestPage';
import { TransferPromotionPage } from '@/features/transfer-promotion/pages/TransferPromotionPage';
import { TransferRequestPage } from '@/features/transfer-promotion/pages/TransferRequestPage';
import { PromotionRequestPage } from '@/features/transfer-promotion/pages/PromotionRequestPage';
import { CompliancePage } from '@/features/compliance/pages/CompliancePage';
import { ComplianceHubPage } from '@/features/compliance/pages/ComplianceHubPage';
import { DocumentPage } from '@/features/document/pages/DocumentPage';
import { DocumentManagementPage } from '@/features/document/pages/DocumentManagementPage';
import { TimesheetPage } from '@/features/timesheet/pages/TimesheetPage';
import { DisciplinaryPage } from '@/features/disciplinary/pages/DisciplinaryPage';
import { GrievancePage } from '@/features/grievance/pages/GrievancePage';
import { AssetPage } from '@/features/asset/pages/AssetPage';
import { PositionPage } from '@/features/position/pages/PositionPage';
import { ShiftPage } from '@/features/shift/pages/ShiftPage';
import { ShiftManagementPage } from '@/features/shift/pages/ShiftManagementPage';
import { ExpensePage } from '@/features/expense/pages/ExpensePage';
import { SeparationPage } from '@/features/separation/pages/SeparationPage';
import { EssPage } from '@/features/ess/pages/EssPage';
import { EssLeaveWorkflowPage } from '@/features/ess/pages/EssLeaveWorkflowPage';
import { MssPage } from '@/features/mss/pages/MssPage';
import { NotificationPage } from '@/features/notifications/pages/NotificationPage';
import { SettingsPage } from '@/features/settings/pages/SettingsPage';
import { WorkflowPage } from '@/features/workflow/pages/WorkflowPage';
import { OvertimePage } from '@/features/overtime/pages/OvertimePage';
import AuditLogPage from '@/features/audit-log/pages/AuditLogPage';
import { DsarAdminPage } from '@/features/compliance/pages/DsarAdminPage';
import { CompensationHubPage } from '@/features/benefits/pages/CompensationHubPage';
import AnnouncementPage from '@/features/announcements/pages/AnnouncementPage';
import ProjectsPage from '@/features/projects/pages/ProjectsPage';
import { NotificationPreferencesPage } from '@/features/notifications/pages/NotificationPreferencesPage';
import { LookupsPage } from '@/features/lookups/pages/LookupsPage';

/** Inner shell — must live inside StoreProvider to access Redux state */
function AppShell() {
  const isAuthenticated = useSelector((state: RootState) => state.auth.isAuthenticated);

  return (
    <>
      {/* Idle timeout: silently watches activity, auto-signs-out after 30 min */}
      <IdleTimeout active={isAuthenticated} />
      <Routes>
        <Route element={<AuthLayout />}>
          <Route path={ROUTES.LOGIN} element={<LoginPage />} />
          <Route path={ROUTES.MFA_VERIFY} element={<MfaVerifyPage />} />
          <Route path={ROUTES.PASSWORD_CHANGE} element={<PasswordChangePage />} />
          <Route path={ROUTES.UNAUTHORIZED} element={<UnauthorizedPage />} />
        </Route>
            <Route
              element={
                <ProtectedRoute>
                  <MainLayout />
                </ProtectedRoute>
              }
            >
              <Route path={ROUTES.HOME} element={<DashboardPage />} />
              <Route path={ROUTES.ORGANIZATION} element={<OrganizationStructurePage />} />
              <Route path={ROUTES.EMPLOYEES} element={<EmployeeListPage />} />
              <Route path={ROUTES.EMPLOYEE_PROFILE} element={<EmployeeProfilePage />} />
              <Route path={ROUTES.ATTENDANCE} element={<AttendancePage />} />
              <Route path={ROUTES.WORK_CALENDAR} element={<WorkCalendarPage />} />
              <Route path={ROUTES.ATTENDANCE_DASHBOARD} element={<AttendanceDashboardPage />} />
              <Route path={ROUTES.ATTENDANCE_CORRECTIONS} element={<AttendanceCorrectionPage />} />
              <Route path={ROUTES.ATTENDANCE_AUTO_COMPUTE} element={<AttendanceAutoComputePage />} />
              <Route path={ROUTES.LEAVE} element={<LeavePage />} />
              <Route path={ROUTES.LEAVE_REPORT} element={<LeaveReportPage />} />
              <Route path={ROUTES.LEAVE_CONFIG} element={<LeaveManagementConfigPage />} />
              <Route path={ROUTES.LEAVE_BALANCES} element={<LeaveBalanceRequestPage />} />
              <Route path={ROUTES.PAYROLL} element={<PayrollPage />} />
              <Route path={ROUTES.PAYROLL_RUNS} element={<PayrollRunsPage />} />
              <Route path={ROUTES.PAYROLL_RUN_DETAIL} element={<PayrollRunDetailPage />} />
              <Route path={ROUTES.PAYROLL_COMPONENTS} element={<PayrollComponentsPage />} />
              <Route path={ROUTES.PAYROLL_APPROVAL} element={<PayrollApprovalPage />} />
              <Route path={ROUTES.PAYROLL_REPORTS} element={<PayrollReportsPage />} />
              <Route path={ROUTES.PAYROLL_SETTINGS} element={<PayrollSettingsPage />} />
              <Route path={ROUTES.PAYROLL_SALARY_ASSIGNMENT} element={<SalaryAssignmentPage />} />
              <Route path={ROUTES.PAYROLL_COMPUTATION} element={<PayrollComputationPage />} />
              <Route path={ROUTES.PERFORMANCE} element={<PerformancePage />} />
              <Route path={ROUTES.RECRUITMENT} element={<RecruitmentPage />} />
              <Route path={ROUTES.RECRUITMENT_VACANCY} element={<VacancyDetailPage />} />
              <Route path={ROUTES.RECRUITMENT_CANDIDATES} element={<CandidatesPage />} />
              <Route path={ROUTES.RECRUITMENT_EXAMS} element={<ExamsPage />} />
              <Route path={ROUTES.RECRUITMENT_INTERVIEWS} element={<InterviewsPage />} />
              <Route path={ROUTES.RECRUITMENT_OFFERS} element={<OffersPage />} />
              <Route path={ROUTES.ONBOARDING} element={<OnboardingPage />} />
              <Route path={ROUTES.ONBOARDING_PROBATION} element={<ProbationPage />} />
              <Route path={ROUTES.ONBOARDING_DETAIL} element={<OnboardingDetailPage />} />
              <Route path={ROUTES.TRAINING} element={<TrainingPage />} />
              <Route path={ROUTES.TRAINING_PROGRAMS} element={<TrainingProgramsPage />} />
              <Route path={ROUTES.TRAINING_SESSION_DETAIL} element={<TrainingSessionDetailPage />} />
              <Route path={ROUTES.OFFBOARDING} element={<OffboardingPage />} />
              <Route path={ROUTES.BENEFITS} element={<BenefitsPage />} />
              <Route path={ROUTES.BENEFITS_ALLOWANCE_TYPES} element={<AllowanceTypesPage />} />
              <Route path={ROUTES.BENEFITS_COMPENSATION_STRUCTURES} element={<CompensationStructurePage />} />
              <Route path={ROUTES.BENEFITS_EMPLOYEE_COMPENSATION} element={<EmployeeCompensationPage />} />
              <Route path={ROUTES.BENEFITS_BENEFIT_PLANS} element={<BenefitPlansPage />} />
              <Route path={ROUTES.BENEFITS_ENROLLMENTS} element={<BenefitEnrollmentPage />} />
              <Route path={ROUTES.BENEFITS_BONUS_CONFIG} element={<BonusConfigPage />} />
              <Route path={ROUTES.LOANS} element={<LoanDashboardPage />} />
              <Route path={ROUTES.LOANS_POLICY} element={<LoanPolicyPage />} />
              <Route path={ROUTES.LOANS_REQUESTS} element={<LoanRequestPage />} />
              <Route path={ROUTES.TRANSFERS} element={<TransferPromotionPage />} />
              <Route path={ROUTES.TRANSFERS_REQUESTS} element={<TransferRequestPage />} />
              <Route path={ROUTES.PROMOTION_REQUESTS} element={<PromotionRequestPage />} />
              <Route path={ROUTES.COMPLIANCE} element={<CompliancePage />} />
              <Route path={ROUTES.COMPLIANCE_HUB} element={<ComplianceHubPage />} />
              <Route path={ROUTES.DOCUMENTS} element={<DocumentPage />} />
              <Route path={ROUTES.DOCUMENT_MANAGEMENT} element={<DocumentManagementPage />} />
              <Route path={ROUTES.TIMESHEETS} element={<TimesheetPage />} />
              <Route path={ROUTES.DISCIPLINARY} element={<DisciplinaryPage />} />
              <Route path={ROUTES.GRIEVANCES} element={<GrievancePage />} />
              <Route path={ROUTES.ASSETS} element={<AssetPage />} />
              <Route path={ROUTES.POSITIONS} element={<PositionPage />} />
              <Route path={ROUTES.SHIFTS} element={<ShiftPage />} />
              <Route path={ROUTES.SHIFT_MANAGEMENT} element={<ShiftManagementPage />} />
              <Route path={ROUTES.EXPENSES} element={<ExpensePage />} />
              <Route path={ROUTES.SEPARATIONS} element={<SeparationPage />} />
              <Route path={ROUTES.ESS} element={<EssPage />} />
              <Route path={ROUTES.ESS_LEAVE_WORKFLOW} element={<EssLeaveWorkflowPage />} />
              <Route path={ROUTES.MSS} element={<MssPage />} />
              <Route path={ROUTES.NOTIFICATIONS} element={<NotificationPage />} />
              <Route path={ROUTES.SETTINGS} element={<SettingsPage />} />
              <Route path={ROUTES.OVERTIME} element={<OvertimePage />} />
              <Route path={ROUTES.WORKFLOW} element={<WorkflowPage />} />
              <Route path={ROUTES.AUDIT_LOG} element={<AuditLogPage />} />
              <Route path={ROUTES.COMPENSATION} element={<CompensationHubPage />} />
              <Route path={ROUTES.DSAR_ADMIN} element={<DsarAdminPage />} />
              <Route path={ROUTES.ANNOUNCEMENTS} element={<AnnouncementPage />} />
              <Route path={ROUTES.TIMESHEETS_PROJECTS} element={<ProjectsPage />} />
              <Route path={ROUTES.NOTIFICATION_PREFERENCES} element={<NotificationPreferencesPage />} />
              <Route path={ROUTES.LOOKUPS} element={<LookupsPage />} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
    </>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <QueryProvider>
        <BrowserRouter>
          <AppShell />
        </BrowserRouter>
      </QueryProvider>
    </StoreProvider>
  );
}
