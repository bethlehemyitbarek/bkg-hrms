import { useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';
import { store } from '../store';
import { logout } from '../store/slices/authSlice';
import { ROUTES } from '@/app/routes';

/** User-activity events that reset the idle timer */
const ACTIVITY_EVENTS: (keyof WindowEventMap)[] = [
  'mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'click',
];

const IDLE_MS        = 30 * 60 * 1000; // 30 minutes
const WARNING_MS     = 29 * 60 * 1000; // warn at 29 min (1 min before logout)

interface IdleTimeoutProps {
  /** Whether the current user is authenticated — hook is a no-op when false */
  active: boolean;
}

/**
 * Mounts an invisible activity watcher.
 * After 29 min of inactivity a toast warning is shown;
 * after 30 min the user is signed out and redirected to /login.
 */
export function IdleTimeout({ active }: IdleTimeoutProps) {
  const navigate         = useNavigate();
  const idleTimer        = useRef<ReturnType<typeof setTimeout> | null>(null);
  const warnTimer        = useRef<ReturnType<typeof setTimeout> | null>(null);
  const warnToastId      = useRef<string | number | null>(null);

  const clearTimers = useCallback(() => {
    if (idleTimer.current)  { clearTimeout(idleTimer.current);  idleTimer.current  = null; }
    if (warnTimer.current)  { clearTimeout(warnTimer.current);  warnTimer.current  = null; }
    if (warnToastId.current !== null) {
      toast.dismiss(warnToastId.current);
      warnToastId.current = null;
    }
  }, []);

  const signOut = useCallback(async () => {
    clearTimers();
    await supabase.auth.signOut();
    store.dispatch(logout());
    toast.info('You were signed out due to inactivity.');
    navigate(ROUTES.LOGIN, { replace: true });
  }, [clearTimers, navigate]);

  const resetTimers = useCallback(() => {
    clearTimers();

    // Warning toast at 29 min
    warnTimer.current = setTimeout(() => {
      warnToastId.current = toast.warning(
        'Your session will expire in 1 minute due to inactivity.',
        { duration: 60_000, id: 'idle-warning' },
      );
    }, WARNING_MS);

    // Auto-logout at 30 min
    idleTimer.current = setTimeout(signOut, IDLE_MS);
  }, [clearTimers, signOut]);

  useEffect(() => {
    if (!active) {
      clearTimers();
      return;
    }

    // Start timers and bind activity listeners
    resetTimers();

    const handleActivity = () => resetTimers();
    ACTIVITY_EVENTS.forEach(evt => window.addEventListener(evt, handleActivity, { passive: true }));

    return () => {
      clearTimers();
      ACTIVITY_EVENTS.forEach(evt => window.removeEventListener(evt, handleActivity));
    };
  }, [active, resetTimers, clearTimers]);

  // Purely behavioral — renders nothing
  return null;
}
