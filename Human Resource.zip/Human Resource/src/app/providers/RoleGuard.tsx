import { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { RootState } from '@/app/store';
import { ROUTES } from '@/app/routes';

interface RoleGuardProps {
  /** One or more roles that are permitted to access the guarded route */
  allowedRoles: string[];
  children: ReactNode;
}

/**
 * Wraps a route and redirects to /unauthorized when the authenticated user
 * does not hold at least one of the `allowedRoles`.
 *
 * Usage in App.tsx:
 *   <Route path={ROUTES.PAYROLL} element={
 *     <RoleGuard allowedRoles={['admin', 'hr_manager', 'payroll_officer']}>
 *       <PayrollPage />
 *     </RoleGuard>
 *   } />
 */
export function RoleGuard({ allowedRoles, children }: RoleGuardProps) {
  const userRoles = useSelector((state: RootState) => state.auth.user?.roles ?? []);

  const hasRole = allowedRoles.some(role => userRoles.includes(role));

  if (!hasRole) {
    return <Navigate to={ROUTES.UNAUTHORIZED} replace />;
  }

  return <>{children}</>;
}
