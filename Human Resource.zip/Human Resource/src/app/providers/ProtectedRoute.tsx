import { ReactNode, useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { Session } from '@supabase/supabase-js';
import { store } from '../store';
import { loginSuccess, logout } from '../store/slices/authSlice';
import { supabase } from '@/db/supabase';
import { ROUTES } from '@/app/routes';

interface ProtectedRouteProps {
  children: ReactNode;
}

type CheckState = 'loading' | 'needs_mfa' | 'authenticated' | 'unauthenticated';

/**
 * Evaluates a Supabase session and updates both Redux store and local state.
 * Returns the resolved CheckState so callers can decide whether to re-render.
 */
async function applySession(
  session: Session | null,
  setCheckState: (s: CheckState) => void,
) {
  if (!session?.user) {
    store.dispatch(logout());
    setCheckState('unauthenticated');
    return;
  }

  // Enforce TOTP: if user has an enrolled TOTP factor but current session
  // is only aal1, gate them at the MFA verify screen before entering the app.
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: aal } = await (supabase as any).auth.mfa.getAuthenticatorAssuranceLevel();
    if (aal?.nextLevel === 'aal2' && aal?.currentLevel !== 'aal2') {
      setCheckState('needs_mfa');
      return;
    }
  } catch {
    // MFA API unavailable or no factors enrolled — proceed normally
  }

  store.dispatch(loginSuccess({
    token: session.access_token,
    user: {
      id: session.user.id,
      username: session.user.email?.split('@')[0] || '',
      email: session.user.email || '',
      roles: (session.user.user_metadata?.roles as string[]) || ['employee'],
    },
  }));
  setCheckState('authenticated');
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const [checkState, setCheckState] = useState<CheckState>('loading');

  useEffect(() => {
    // 1. Check the current session immediately on mount.
    supabase.auth.getSession().then(({ data: { session } }) => {
      applySession(session, setCheckState);
    });

    // 2. Subscribe to all future auth state changes:
    //    - TOKEN_REFRESHED  → silently update the Redux token
    //    - SIGNED_IN        → re-evaluate MFA gate and sync Redux
    //    - SIGNED_OUT       → clear Redux and redirect to login
    //    - USER_UPDATED     → sync refreshed user metadata to Redux
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        applySession(session, setCheckState);
      },
    );

    // Cleanup: unsubscribe when the component unmounts.
    return () => { subscription.unsubscribe(); };
  }, []);

  if (checkState === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 rounded-full border-2 border-primary border-t-transparent animate-spin" />
          <p className="text-sm text-muted-foreground">Loading HRMS…</p>
        </div>
      </div>
    );
  }

  if (checkState === 'needs_mfa') {
    return <Navigate to={ROUTES.MFA_VERIFY} replace />;
  }

  if (checkState === 'unauthenticated') {
    return <Navigate to={ROUTES.LOGIN} replace />;
  }

  return <>{children}</>;
}
