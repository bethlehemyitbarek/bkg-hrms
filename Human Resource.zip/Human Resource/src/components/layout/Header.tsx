export function Header() {
  return <header className="h-16 border-b bg-background flex items-center px-4">BKG HRMS</header>;
}
