import type { ElementType, ReactNode } from 'react';

interface NavItem {
  value: string;
  label: string;
  icon?: ElementType;
}

interface ModuleRightNavProps {
  items: NavItem[];
  active: string;
  onChange: (value: string) => void;
  children: ReactNode;
}

/**
 * Wraps module content with a right-side vertical navigation panel.
 * Layout: [content flex-1] | [right nav 160px]
 */
export function ModuleRightNav({ items, active, onChange, children }: ModuleRightNavProps) {
  return (
    <div className="flex gap-3 items-start min-h-0">
      {/* Main content */}
      <div className="flex-1 min-w-0">{children}</div>

      {/* Right secondary nav */}
      <aside className="w-40 shrink-0 rounded-xl border border-border bg-card overflow-hidden">
        <nav className="flex flex-col">
          {items.map((item, i) => {
            const Icon = item.icon;
            const isActive = item.value === active;
            return (
              <button
                key={item.value}
                onClick={() => onChange(item.value)}
                className={[
                  'flex items-center gap-2 px-3 py-2.5 text-left text-sm transition-colors',
                  i !== 0 ? 'border-t border-border' : '',
                  isActive
                    ? 'bg-primary text-primary-foreground font-medium'
                    : 'hover:bg-muted text-foreground',
                ].join(' ')}
              >
                {Icon && <Icon className="h-3.5 w-3.5 shrink-0" />}
                <span className="truncate leading-tight">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </aside>
    </div>
  );
}
