export function getWsAuthToken(): string {
  return localStorage.getItem('access_token') || '';
}
