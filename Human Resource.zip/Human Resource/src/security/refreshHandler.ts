import { httpClient } from '@/shared/api/httpClient';

export async function refreshToken() {
  const response = await httpClient.post('/auth/refresh');
  const { token } = response.data;
  localStorage.setItem('access_token', token);
  return token;
}
