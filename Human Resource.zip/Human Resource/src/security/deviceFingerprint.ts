export function getDeviceFingerprint(): string {
  return navigator.userAgent + window.screen.width + window.screen.height;
}
