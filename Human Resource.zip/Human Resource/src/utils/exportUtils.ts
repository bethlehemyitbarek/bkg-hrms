/**
 * Shared export utilities — CSV download (no external deps, uses papaparse for unparse)
 * Filename convention: <tabName>_YYYY-MM-DD.csv
 */
import Papa from 'papaparse';

function todayStr(): string {
  return new Date().toISOString().split('T')[0];
}

/**
 * Sanitise a filename segment: strip spaces/slashes/special chars.
 */
function toFilename(label: string): string {
  return label.replace(/[^a-zA-Z0-9_-]/g, '_');
}

/**
 * Export an array of plain objects to a CSV file and trigger browser download.
 * @param rows   Array of row objects (keys become headers)
 * @param label  Human-readable tab/report name — used in the filename
 */
export function exportToCsv(rows: Record<string, unknown>[], label: string): void {
  if (rows.length === 0) {
    // Still download an empty file so the user knows it worked
    rows = [{}];
  }
  const csv = Papa.unparse(rows);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `${toFilename(label)}_${todayStr()}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Convenience alias kept for future xlsx upgrade — currently delegates to CSV.
 */
export const exportToExcel = exportToCsv;
