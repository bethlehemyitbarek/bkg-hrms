import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface PayslipEmployee {
  name: string;
  employee_no: string;
  department?: string;
  position?: string;
}

interface PayslipData {
  employee: PayslipEmployee;
  period_label: string;  // e.g. "May 2026"
  basic_salary: number;
  overtime_pay: number;
  allowances: number;
  gross_pay: number;
  tax_deduction: number;
  social_security: number;
  provident_fund: number;
  other_deductions: number;
  loan_deductions: number;
  total_deductions: number;
  net_pay: number;
}

function fmtN(n: number): string {
  return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function generatePayslipPdf(d: PayslipData): void {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const primaryRgb: [number, number, number] = [15, 23, 42];   // #0F172A
  const accentRgb: [number, number, number]  = [16, 185, 129]; // #10B981
  const lightGray: [number, number, number]  = [248, 250, 252];
  const borderGray: [number, number, number] = [226, 232, 240];

  // ── Header band ────────────────────────────────────────────────────────────
  doc.setFillColor(...primaryRgb);
  doc.rect(0, 0, W, 28, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('BKG GROUP', 14, 12);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text('Human Resources Department', 14, 18);
  doc.text('Confidential — Employee Payslip', 14, 23);

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('PAYSLIP', W - 14, 14, { align: 'right' });
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(`Pay Period: ${d.period_label}`, W - 14, 20, { align: 'right' });

  // ── Employee details card ──────────────────────────────────────────────────
  let y = 34;
  doc.setFillColor(...lightGray);
  doc.roundedRect(10, y, W - 20, 24, 2, 2, 'F');
  doc.setDrawColor(...borderGray);
  doc.roundedRect(10, y, W - 20, 24, 2, 2, 'S');

  doc.setTextColor(...primaryRgb);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(d.employee.name, 16, y + 8);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`Employee No: ${d.employee.employee_no}`, 16, y + 14);
  if (d.employee.department) doc.text(`Department: ${d.employee.department}`, 16, y + 19);
  if (d.employee.position)   doc.text(`Position: ${d.employee.position}`, 100, y + 14);

  // ── Green accent divider ───────────────────────────────────────────────────
  y += 30;
  doc.setFillColor(...accentRgb);
  doc.rect(10, y, W - 20, 0.8, 'F');
  y += 4;

  // ── Earnings table ─────────────────────────────────────────────────────────
  doc.setTextColor(...primaryRgb);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('EARNINGS', 14, y + 4);
  y += 2;

  autoTable(doc, {
    startY: y + 4,
    head: [['Description', 'Amount (ብር)']],
    body: [
      ['Basic Salary', fmtN(d.basic_salary)],
      ['Overtime Pay', fmtN(d.overtime_pay)],
      ['Allowances', fmtN(d.allowances)],
      [{ content: 'GROSS PAY', styles: { fontStyle: 'bold' } }, { content: fmtN(d.gross_pay), styles: { fontStyle: 'bold' } }],
    ],
    theme: 'grid',
    headStyles: { fillColor: primaryRgb, textColor: [255, 255, 255], fontSize: 8, fontStyle: 'bold' },
    bodyStyles: { fontSize: 8, textColor: primaryRgb },
    columnStyles: { 0: { cellWidth: 110 }, 1: { cellWidth: 60, halign: 'right' } },
    alternateRowStyles: { fillColor: lightGray },
    margin: { left: 14, right: 14 },
    rowPageBreak: 'avoid',
  });

  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 6;

  // ── Deductions table ───────────────────────────────────────────────────────
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...primaryRgb);
  doc.text('DEDUCTIONS', 14, y + 4);
  y += 2;

  autoTable(doc, {
    startY: y + 4,
    head: [['Description', 'Amount (ብር)']],
    body: [
      ['Income Tax', fmtN(d.tax_deduction)],
      ['Social Security', fmtN(d.social_security)],
      ['Provident Fund', fmtN(d.provident_fund)],
      ['Loan Repayments', fmtN(d.loan_deductions)],
      ['Other Deductions', fmtN(d.other_deductions)],
      [{ content: 'TOTAL DEDUCTIONS', styles: { fontStyle: 'bold', textColor: [220, 38, 38] } }, { content: fmtN(d.total_deductions), styles: { fontStyle: 'bold', textColor: [220, 38, 38] } }],
    ],
    theme: 'grid',
    headStyles: { fillColor: primaryRgb, textColor: [255, 255, 255], fontSize: 8, fontStyle: 'bold' },
    bodyStyles: { fontSize: 8, textColor: primaryRgb },
    columnStyles: { 0: { cellWidth: 110 }, 1: { cellWidth: 60, halign: 'right' } },
    alternateRowStyles: { fillColor: lightGray },
    margin: { left: 14, right: 14 },
    rowPageBreak: 'avoid',
  });

  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 6;

  // ── Net Pay highlight band ─────────────────────────────────────────────────
  doc.setFillColor(...accentRgb);
  doc.roundedRect(10, y, W - 20, 16, 2, 2, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('NET PAY', 16, y + 10);
  doc.text(`ብር ${fmtN(d.net_pay)}`, W - 16, y + 10, { align: 'right' });

  // ── Footer ─────────────────────────────────────────────────────────────────
  const pageH = doc.internal.pageSize.getHeight();
  doc.setFontSize(7);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(148, 163, 184);
  doc.text(
    'This is a computer-generated payslip and does not require a signature. BKG Group HR — Confidential.',
    W / 2, pageH - 8, { align: 'center' },
  );

  const fileName = `payslip_${d.employee.employee_no}_${d.period_label.replace(/\s/g, '_')}.pdf`;
  doc.save(fileName);
}

/** Build the same payslip PDF but return raw base64 instead of triggering a download. */
export function generatePayslipPdfBase64(d: PayslipData): string {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const primaryRgb: [number, number, number] = [15, 23, 42];
  const accentRgb: [number, number, number]  = [16, 185, 129];
  const lightGray: [number, number, number]  = [248, 250, 252];
  const borderGray: [number, number, number] = [226, 232, 240];

  doc.setFillColor(...primaryRgb);
  doc.rect(0, 0, W, 28, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14); doc.setFont('helvetica', 'bold');
  doc.text('BKG GROUP', 14, 12);
  doc.setFontSize(8); doc.setFont('helvetica', 'normal');
  doc.text('Human Resources Department', 14, 18);
  doc.text('Confidential — Employee Payslip', 14, 23);
  doc.setFontSize(12); doc.setFont('helvetica', 'bold');
  doc.text('PAYSLIP', W - 14, 14, { align: 'right' });
  doc.setFontSize(8); doc.setFont('helvetica', 'normal');
  doc.text(`Pay Period: ${d.period_label}`, W - 14, 20, { align: 'right' });

  let y = 34;
  doc.setFillColor(...lightGray);
  doc.roundedRect(10, y, W - 20, 24, 2, 2, 'F');
  doc.setDrawColor(...borderGray);
  doc.roundedRect(10, y, W - 20, 24, 2, 2, 'S');
  doc.setTextColor(...primaryRgb); doc.setFontSize(11); doc.setFont('helvetica', 'bold');
  doc.text(d.employee.name, 16, y + 8);
  doc.setFontSize(8); doc.setFont('helvetica', 'normal'); doc.setTextColor(100, 116, 139);
  doc.text(`Employee No: ${d.employee.employee_no}`, 16, y + 14);
  if (d.employee.department) doc.text(`Department: ${d.employee.department}`, 16, y + 19);

  y += 30;
  doc.setFillColor(...accentRgb); doc.rect(10, y, W - 20, 0.8, 'F'); y += 4;
  doc.setTextColor(...primaryRgb); doc.setFontSize(9); doc.setFont('helvetica', 'bold');
  doc.text('EARNINGS', 14, y + 4); y += 2;

  autoTable(doc, {
    startY: y + 4,
    head: [['Description', 'Amount (ብር)']],
    body: [
      ['Basic Salary', fmtN(d.basic_salary)],
      ['Overtime Pay', fmtN(d.overtime_pay)],
      ['Allowances', fmtN(d.allowances)],
      [{ content: 'GROSS PAY', styles: { fontStyle: 'bold' } }, { content: fmtN(d.gross_pay), styles: { fontStyle: 'bold' } }],
    ],
    theme: 'grid',
    headStyles: { fillColor: primaryRgb, textColor: [255, 255, 255], fontSize: 8, fontStyle: 'bold' },
    bodyStyles: { fontSize: 8, textColor: primaryRgb },
    columnStyles: { 0: { cellWidth: 110 }, 1: { cellWidth: 60, halign: 'right' } },
    alternateRowStyles: { fillColor: lightGray },
    margin: { left: 14, right: 14 },
  });

  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 6;
  doc.setFontSize(9); doc.setFont('helvetica', 'bold'); doc.setTextColor(...primaryRgb);
  doc.text('DEDUCTIONS', 14, y + 4); y += 2;

  autoTable(doc, {
    startY: y + 4,
    head: [['Description', 'Amount (ብር)']],
    body: [
      ['Income Tax', fmtN(d.tax_deduction)],
      ['Social Security', fmtN(d.social_security)],
      ['Provident Fund', fmtN(d.provident_fund)],
      ['Loan Repayments', fmtN(d.loan_deductions)],
      ['Other Deductions', fmtN(d.other_deductions)],
      [{ content: 'TOTAL DEDUCTIONS', styles: { fontStyle: 'bold', textColor: [220, 38, 38] } }, { content: fmtN(d.total_deductions), styles: { fontStyle: 'bold', textColor: [220, 38, 38] } }],
    ],
    theme: 'grid',
    headStyles: { fillColor: primaryRgb, textColor: [255, 255, 255], fontSize: 8, fontStyle: 'bold' },
    bodyStyles: { fontSize: 8, textColor: primaryRgb },
    columnStyles: { 0: { cellWidth: 110 }, 1: { cellWidth: 60, halign: 'right' } },
    alternateRowStyles: { fillColor: lightGray },
    margin: { left: 14, right: 14 },
  });

  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 6;
  doc.setFillColor(...accentRgb); doc.roundedRect(10, y, W - 20, 16, 2, 2, 'F');
  doc.setTextColor(255, 255, 255); doc.setFontSize(11); doc.setFont('helvetica', 'bold');
  doc.text('NET PAY', 16, y + 10);
  doc.text(`ብር ${fmtN(d.net_pay)}`, W - 16, y + 10, { align: 'right' });

  const pageH = doc.internal.pageSize.getHeight();
  doc.setFontSize(7); doc.setFont('helvetica', 'normal'); doc.setTextColor(148, 163, 184);
  doc.text('This is a computer-generated payslip and does not require a signature. BKG Group HR — Confidential.', W / 2, pageH - 8, { align: 'center' });

  // Return raw base64 (no data URI prefix)
  return doc.output('datauristring').split(',')[1];
}
