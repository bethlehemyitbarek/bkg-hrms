export function logEvent(level: 'info' | 'warn' | 'error', message: string, meta?: Record<string, unknown>) {
  console[level](`[${level.toUpperCase()}]`, message, meta || '');
}
