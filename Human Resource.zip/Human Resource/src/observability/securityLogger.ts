export function logSecurityEvent(event: string, details: Record<string, unknown>) {
  console.warn(`[Security] ${event}`, details);
}
