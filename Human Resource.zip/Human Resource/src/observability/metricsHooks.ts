import { useEffect } from 'react';

export function usePageViewMetric(pageName: string) {
  useEffect(() => {
    console.log(`[Metric] Page view: ${pageName}`);
  }, [pageName]);
}
