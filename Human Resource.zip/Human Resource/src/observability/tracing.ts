export function getTraceId(): string {
  return crypto.randomUUID();
}
