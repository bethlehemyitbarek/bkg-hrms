import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import IntersectObserver from '@/components/common/IntersectObserver';
import { ErrorBoundary } from '@/components/common/ErrorBoundary';
import { Toaster } from '@/components/ui/sonner';
import { MainLayout } from '@/app/layouts/MainLayout';
import { routes, layoutRoutes } from './routes';

const App: React.FC = () => {
  const standaloneRoutes = routes.filter(r => r.path !== '/');

  return (
    <Router>
      <IntersectObserver />
      <div className="flex flex-col min-h-screen">
        <main className="flex-grow">
          <Routes>
            {/* Standalone routes (no MainLayout) */}
            {standaloneRoutes.map((route, index) => (
              <Route key={index} path={route.path} element={route.element} />
            ))}

            {/* All HRMS routes wrapped in MainLayout */}
            <Route element={<MainLayout />}>
              {layoutRoutes.map((route, index) => (
                <Route
                  key={index}
                  path={route.path}
                  element={<ErrorBoundary>{route.element}</ErrorBoundary>}
                />
              ))}
            </Route>

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
      <Toaster />
    </Router>
  );
};

export default App;
