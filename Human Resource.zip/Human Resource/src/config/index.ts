export const appConfig = {
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api/v1',
  appName: 'BKG HRMS',
  version: '1.0.0',
  defaultLanguage: 'en',
  dateFormat: 'yyyy-MM-dd',
  currency: 'ETB',
  maxUploadSize: 10 * 1024 * 1024,
};
