/**
 * dsar-deadline-reminder
 *
 * Scans all open DSAR requests that are approaching their deadline with no
 * response and sends an email reminder to HR admin.
 *
 * Trigger modes:
 *   1. Cron / scheduled:  POST {} (no body) – scans ALL tenants
 *   2. Manual / test:     POST { "tenant_id": "..." } – scans one tenant
 *
 * Warning windows (configurable):
 *   - 7 days before deadline  → first warning
 *   - 3 days before deadline  → urgent warning
 *   - 1 day  before deadline  → critical warning
 *   - Overdue (past deadline) → overdue alert
 *
 * A request is eligible if:
 *   - request_status IN ('SUBMITTED', 'IN_REVIEW')
 *   - completion_date IS NULL
 *   - deadline_date falls within any warning window
 */

import { serve } from 'https://xigclauqapehgdiylkoj.supabase.co';
import { createClient } from 'npm:@supabase/supabase-js@2';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const JSON_HEADERS = { ...CORS, 'Content-Type': 'application/json' };

/* ── Warning windows in days before deadline ─────────────────────────────── */
const WARNING_WINDOWS = [
  { days: 7,  label: 'First Warning',    urgency: 'warning'  },
  { days: 3,  label: 'Urgent Warning',   urgency: 'urgent'   },
  { days: 1,  label: 'Critical Warning', urgency: 'critical' },
];

/* ── Email builder ───────────────────────────────────────────────────────── */
function buildReminderEmail(params: {
  hr_name: string;
  dsar_id: string;
  employee_name: string;
  request_type: string;
  request_date: string;
  deadline_date: string;
  days_remaining: number;
  urgency: string;
}): { subject: string; html: string } {
  const {
    hr_name, dsar_id, employee_name, request_type,
    request_date, deadline_date, days_remaining, urgency,
  } = params;

  const urgencyColors: Record<string, { bg: string; text: string; label: string }> = {
    warning:  { bg: '#fef3c7', text: '#92400e', label: '⚠️ Action Required' },
    urgent:   { bg: '#fed7aa', text: '#9a3412', label: '🔴 Urgent — 3 Days Left' },
    critical: { bg: '#fee2e2', text: '#991b1b', label: '🚨 Critical — 1 Day Left' },
    overdue:  { bg: '#fce7f3', text: '#831843', label: '🔥 OVERDUE — Past Deadline' },
  };

  const u = urgencyColors[urgency] ?? urgencyColors.warning;
  const daysText = days_remaining < 0
    ? `<strong style="color:#dc2626">${Math.abs(days_remaining)} day(s) OVERDUE</strong>`
    : days_remaining === 0
      ? `<strong style="color:#dc2626">Due TODAY</strong>`
      : `<strong>${days_remaining} day(s) remaining</strong>`;

  const subject = days_remaining < 0
    ? `[OVERDUE] DSAR Request #${dsar_id.slice(0, 8)} — ${Math.abs(days_remaining)} day(s) past deadline`
    : `[DSAR Reminder] ${u.label} — Request #${dsar_id.slice(0, 8)} due in ${days_remaining} day(s)`;

  const html = `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#1e293b;max-width:600px;margin:0 auto;padding:20px">
  <div style="border-radius:8px;overflow:hidden;border:1px solid #e2e8f0">
    <!-- Header -->
    <div style="background:${u.bg};padding:16px 24px;border-bottom:1px solid #e2e8f0">
      <h2 style="margin:0;color:${u.text};font-size:18px">${u.label}</h2>
      <p style="margin:4px 0 0;color:${u.text};font-size:13px">DSAR Deadline Reminder — BKG HRMS</p>
    </div>

    <!-- Body -->
    <div style="padding:24px;background:#fff">
      <p>Dear <strong>${hr_name}</strong>,</p>
      <p>
        The following Data Subject Access Request requires your attention.
        The response deadline is ${daysText}.
      </p>

      <!-- Request details table -->
      <table style="width:100%;border-collapse:collapse;margin:16px 0;font-size:14px">
        <tr style="background:#f8fafc">
          <td style="padding:8px 12px;font-weight:600;width:40%">Request ID</td>
          <td style="padding:8px 12px;font-family:monospace">${dsar_id}</td>
        </tr>
        <tr>
          <td style="padding:8px 12px;font-weight:600;background:#f8fafc">Employee</td>
          <td style="padding:8px 12px">${employee_name}</td>
        </tr>
        <tr style="background:#f8fafc">
          <td style="padding:8px 12px;font-weight:600">Request Type</td>
          <td style="padding:8px 12px">${request_type.replace(/_/g, ' ')}</td>
        </tr>
        <tr>
          <td style="padding:8px 12px;font-weight:600;background:#f8fafc">Submitted On</td>
          <td style="padding:8px 12px">${request_date}</td>
        </tr>
        <tr style="background:${u.bg}">
          <td style="padding:8px 12px;font-weight:700;color:${u.text}">Deadline</td>
          <td style="padding:8px 12px;font-weight:700;color:${u.text}">${deadline_date} (${daysText})</td>
        </tr>
      </table>

      <p>
        Please log in to the <strong>DSAR Admin</strong> module to review and respond to this request
        before the deadline to maintain compliance.
      </p>

      <div style="margin:20px 0">
        <a href="/compliance/dsar-admin"
           style="display:inline-block;background:#1d4ed8;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px">
          Open DSAR Admin →
        </a>
      </div>
    </div>

    <!-- Footer -->
    <div style="background:#f8fafc;padding:12px 24px;border-top:1px solid #e2e8f0">
      <p style="margin:0;color:#64748b;font-size:12px">
        This is an automated reminder from BKG HRMS · Compliance &amp; Governance
      </p>
    </div>
  </div>
</body>
</html>`;

  return { subject, html };
}

/* ── Send email via Resend ───────────────────────────────────────────────── */
async function sendEmail(params: {
  to: string;
  subject: string;
  html: string;
  resendKey: string;
}): Promise<{ ok: boolean; id?: string; error?: string }> {
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${params.resendKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: 'BKG HR Compliance <noreply@bkggroup.hr>',
      to: [params.to],
      subject: params.subject,
      html: params.html,
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    return { ok: false, error: errText };
  }
  const data = await res.json();
  return { ok: true, id: data.id };
}

/* ── Main handler ────────────────────────────────────────────────────────── */
serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: CORS });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SERVICE_KEY  = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const RESEND_KEY   = Deno.env.get('RESEND_API_KEY') ?? '';

    const supabase = createClient(SUPABASE_URL, SERVICE_KEY, {
      auth: { persistSession: false },
    });

    // Optional: filter to a single tenant
    let tenantFilter: string | null = null;
    try {
      const body = await req.json();
      tenantFilter = body?.tenant_id ?? null;
    } catch { /* no body */ }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Build list of dates we care about: today (overdue) + warning window days
    const checkDates: Array<{ date: Date; days_remaining: number; urgency: string }> = [
      { date: today, days_remaining: 0, urgency: 'critical' }, // due today
    ];

    // Add past days (overdue): 1–30 days ago
    for (let d = 1; d <= 30; d++) {
      const dt = new Date(today);
      dt.setDate(today.getDate() - d);
      checkDates.push({ date: dt, days_remaining: -d, urgency: 'overdue' });
    }

    // Add future warning windows
    for (const w of WARNING_WINDOWS) {
      const dt = new Date(today);
      dt.setDate(today.getDate() + w.days);
      checkDates.push({ date: dt, days_remaining: w.days, urgency: w.urgency });
    }

    // Query open DSARs in these deadline buckets
    const deadlineDates = checkDates.map(cd => cd.date.toISOString().slice(0, 10));

    let query = supabase
      .from('data_subject_access_requests')
      .select(`
        row_id,
        dsar_id,
        tenant_id,
        employee_id,
        request_type,
        request_date,
        deadline_date,
        request_status,
        completion_date,
        employees!employee_id ( first_name, last_name, email, work_email )
      `)
      .in('request_status', ['SUBMITTED', 'IN_REVIEW'])
      .is('completion_date', null)
      .in('deadline_date', deadlineDates)
      .eq('is_deleted', 0);

    if (tenantFilter) query = query.eq('tenant_id', tenantFilter);

    const { data: dsars, error: qErr } = await query;
    if (qErr) throw new Error(`DB query failed: ${qErr.message}`);
    if (!dsars || dsars.length === 0) {
      return new Response(
        JSON.stringify({ success: true, processed: 0, message: 'No DSARs approaching deadline.' }),
        { status: 200, headers: JSON_HEADERS },
      );
    }

    // Fetch HR admin emails per tenant
    const tenantIds = [...new Set(dsars.map((d: Record<string, unknown>) => d.tenant_id as string))];
    const { data: hrAdmins } = await supabase
      .from('user_roles')
      .select('user_id, tenant_id, profiles!user_id ( email, full_name )')
      .in('tenant_id', tenantIds)
      .in('role_name', ['hr_admin', 'hr_manager', 'super_admin'])
      .eq('is_active', true);

    // Map tenantId → HR admin contacts
    const hrByTenant: Record<string, Array<{ email: string; name: string }>> = {};
    for (const r of (hrAdmins ?? [])) {
      const row = r as Record<string, unknown>;
      const tid = row.tenant_id as string;
      const profile = row.profiles as { email?: string; full_name?: string } | null;
      if (!profile?.email) continue;
      if (!hrByTenant[tid]) hrByTenant[tid] = [];
      hrByTenant[tid].push({ email: profile.email, name: profile.full_name ?? 'HR Admin' });
    }

    // Dev-mode fallback: log without sending if RESEND_KEY missing
    const devMode = !RESEND_KEY;
    if (devMode) {
      console.warn('[dsar-deadline-reminder] RESEND_API_KEY not set — emails will be logged only.');
    }

    const results: Array<{ dsar_id: string; emails_sent: number; urgency: string; days_remaining: number }> = [];

    for (const dsar of dsars) {
      const d = dsar as Record<string, unknown>;
      const deadlineStr = d.deadline_date as string;
      const match = checkDates.find(cd => cd.date.toISOString().slice(0, 10) === deadlineStr);
      if (!match) continue;

      const { days_remaining, urgency } = match;
      const emp = d.employees as { first_name?: string; last_name?: string; email?: string; work_email?: string } | null;
      const employeeName = emp ? `${emp.first_name ?? ''} ${emp.last_name ?? ''}`.trim() : 'Unknown Employee';

      const hrContacts = hrByTenant[d.tenant_id as string] ?? [];
      if (hrContacts.length === 0) {
        console.warn(`[dsar-deadline-reminder] No HR admins found for tenant ${d.tenant_id}`);
        continue;
      }

      let emailsSent = 0;
      for (const hr of hrContacts) {
        const { subject, html } = buildReminderEmail({
          hr_name:       hr.name,
          dsar_id:       d.dsar_id as string,
          employee_name: employeeName,
          request_type:  d.request_type as string,
          request_date:  d.request_date as string,
          deadline_date: deadlineStr,
          days_remaining,
          urgency,
        });

        if (devMode) {
          console.log(`[DEV] Would send email to ${hr.email}: ${subject}`);
          emailsSent++;
        } else {
          const sent = await sendEmail({ to: hr.email, subject, html, resendKey: RESEND_KEY });
          if (sent.ok) {
            emailsSent++;
            console.log(`[dsar-deadline-reminder] Sent reminder to ${hr.email} for DSAR ${d.dsar_id} (${urgency})`);
          } else {
            console.error(`[dsar-deadline-reminder] Failed to send to ${hr.email}: ${sent.error}`);
          }
        }
      }

      results.push({
        dsar_id:       d.dsar_id as string,
        emails_sent:   emailsSent,
        urgency,
        days_remaining,
      });
    }

    return new Response(
      JSON.stringify({
        success: true,
        dev_mode: devMode,
        processed: results.length,
        results,
      }),
      { status: 200, headers: JSON_HEADERS },
    );

  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error('[dsar-deadline-reminder] Fatal error:', msg);

    // Send in-app notification to all HR admins so they're aware the cron failed
    try {
      const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
      const SERVICE_KEY  = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
      const supabase = createClient(SUPABASE_URL, SERVICE_KEY, {
        auth: { persistSession: false },
      });

      // Fetch all HR admin profile IDs
      const { data: hrProfiles } = await supabase
        .from('profiles')
        .select('id')
        .in('role', ['hr_admin', 'hr_manager', 'super_admin']);

      if (hrProfiles && hrProfiles.length > 0) {
        const rows = hrProfiles.map((p: { id: string }) => ({
          recipient_id:      p.id,
          title:             '⚠️ DSAR Cron Job Failed',
          message:           `The DSAR deadline reminder job failed: ${msg.slice(0, 200)}`,
          notification_type: 'DSAR_CRON_FAILED',
          module:            'dsar',
          is_read:           false,
          created_at:        new Date().toISOString(),
          action_url:        '/compliance/dsar-admin',
        }));
        await supabase.from('notifications').insert(rows);
        console.log(`[dsar-deadline-reminder] Failure notification sent to ${rows.length} HR admin(s).`);
      }
    } catch (notifErr) {
      console.error('[dsar-deadline-reminder] Failed to send failure notification:', notifErr);
    }

    return new Response(
      JSON.stringify({ error: 'Internal server error', detail: msg }),
      { status: 500, headers: JSON_HEADERS },
    );
  }
});
