import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

interface SendPayslipRequest {
  to_email: string;
  employee_name: string;
  period_name: string;
  pdf_base64: string; // base64-encoded PDF (data:application/pdf;base64,... or raw base64)
  net_pay?: number;
  currency?: string;
  payroll_record_id?: string;
  employee_id?: string;
}

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: CORS_HEADERS });
  }

  try {
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    if (!resendApiKey) {
      return new Response(
        JSON.stringify({ error: 'Email service not configured. Please add RESEND_API_KEY.' }),
        { status: 503, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } },
      );
    }

    // Init Supabase admin client for logging
    const supabaseUrl     = Deno.env.get('SUPABASE_URL') ?? '';
    const supabaseService = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
    const supabase = createClient(supabaseUrl, supabaseService);

    const body: SendPayslipRequest = await req.json();
    const { to_email, employee_name, period_name, pdf_base64, net_pay, currency = 'USD', payroll_record_id, employee_id } = body;

    if (!to_email || !employee_name || !period_name || !pdf_base64) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: to_email, employee_name, period_name, pdf_base64' }),
        { status: 400, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } },
      );
    }

    // Strip data URI prefix if present
    const rawBase64 = pdf_base64.includes(',') ? pdf_base64.split(',')[1] : pdf_base64;

    const netPayStr = net_pay != null
      ? new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(net_pay)
      : '';

    const emailHtml = `
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,sans-serif">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding:32px 16px">
    <tr><td align="center">
      <table width="100%" style="max-width:560px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.08)">
        <!-- Header -->
        <tr><td style="background:#2563EB;padding:28px 32px">
          <h1 style="margin:0;color:#ffffff;font-size:22px;font-weight:700">BKG Company</h1>
          <p style="margin:6px 0 0;color:#93c5fd;font-size:13px">Payslip Notification</p>
        </td></tr>
        <!-- Body -->
        <tr><td style="padding:32px">
          <p style="margin:0 0 16px;font-size:15px;color:#374151">Dear <strong>${employee_name}</strong>,</p>
          <p style="margin:0 0 24px;font-size:14px;color:#6b7280;line-height:1.6">
            Your payslip for <strong>${period_name}</strong> is attached to this email as a PDF.
            ${netPayStr ? `Your net pay for this period is <strong style="color:#2563EB">${netPayStr}</strong>.` : ''}
          </p>
          <table width="100%" style="background:#eff6ff;border-radius:8px;padding:16px;border:1px solid #bfdbfe">
            <tr>
              <td style="font-size:13px;color:#1d4ed8"><strong>Period:</strong> ${period_name}</td>
            </tr>
            ${netPayStr ? `<tr><td style="font-size:13px;color:#1d4ed8;padding-top:8px"><strong>Net Pay:</strong> ${netPayStr}</td></tr>` : ''}
          </table>
          <p style="margin:24px 0 0;font-size:13px;color:#9ca3af;line-height:1.6">
            Please review the attached payslip. If you have any questions, contact your HR department.
          </p>
        </td></tr>
        <!-- Footer -->
        <tr><td style="background:#f9fafb;padding:16px 32px;border-top:1px solid #e5e7eb">
          <p style="margin:0;font-size:12px;color:#9ca3af;text-align:center">
            This is an automated email from BKG HRMS. Please do not reply directly to this email.
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;

    const filename = `payslip_${period_name.replace(/\s+/g, '_')}_${employee_name.replace(/\s+/g, '_')}.pdf`;

    const resendPayload = {
      from:    'BKG HRMS <onboarding@resend.dev>',
      to:      [to_email],
      subject: `Your Payslip — ${period_name}`,
      html:    emailHtml,
      attachments: [
        {
          filename,
          content: rawBase64,
        },
      ],
    };

    const resendRes = await fetch('https://api.resend.com/emails', {
      method:  'POST',
      headers: {
        'Authorization': `Bearer ${resendApiKey}`,
        'Content-Type':  'application/json',
      },
      body: JSON.stringify(resendPayload),
    });

    if (!resendRes.ok) {
      const errText = await resendRes.text();
      console.error('Resend error:', errText);

      // Log failure
      if (payroll_record_id && employee_id) {
        await supabase.from('payslip_email_logs').insert({
          payroll_record_id,
          employee_id,
          sent_to:     to_email,
          period_name,
          status:      'failed',
          error_msg:   errText,
        });
      }

      return new Response(
        JSON.stringify({ error: `Email delivery failed: ${errText}` }),
        { status: 502, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } },
      );
    }

    const result = await resendRes.json();

    // Log success
    if (payroll_record_id && employee_id) {
      await supabase.from('payslip_email_logs').insert({
        payroll_record_id,
        employee_id,
        sent_to:     to_email,
        period_name,
        status:      'success',
      });
    }

    return new Response(
      JSON.stringify({ success: true, id: result.id, message: `Payslip sent to ${to_email}` }),
      { status: 200, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } },
    );

  } catch (err) {
    console.error('send-payslip-email error:', err);
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : 'Internal server error' }),
      { status: 500, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } },
    );
  }
});
