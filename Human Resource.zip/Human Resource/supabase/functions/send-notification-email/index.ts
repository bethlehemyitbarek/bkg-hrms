import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

type NotificationType =
  | 'LOAN_OVERDUE_REMINDER'
  | 'PROMOTION_DEPT_APPROVED'
  | 'PROMOTION_DEPT_REJECTED'
  | 'PROMOTION_APPROVED'
  | 'PROMOTION_REJECTED'
  | 'PROMOTION_EXECUTED'
  | 'SHIFT_SWAP_SUBMITTED'
  | 'SHIFT_SWAP_APPROVED'
  | 'SHIFT_SWAP_REJECTED';

interface EmailPayload {
  notification_type: NotificationType;
  recipient_email: string;
  employee_name: string;
  data?: Record<string, string | number>;
}

function buildEmail(p: EmailPayload): { subject: string; html: string } {
  const { notification_type, employee_name, data = {} } = p;
  const company = 'BKG Group HR';

  switch (notification_type) {
    case 'LOAN_OVERDUE_REMINDER':
      return {
        subject: `Overdue Loan Installment Reminder — ${data.loan_ref ?? ''}`,
        html: `
          <p>Dear <strong>${employee_name}</strong>,</p>
          <p>This is a reminder that your loan installment is <strong>${data.days_overdue} day(s) overdue</strong>.</p>
          <table style="border-collapse:collapse;width:100%;max-width:480px">
            <tr><td style="padding:6px 12px;background:#f8fafc;font-weight:600">Loan Reference</td><td style="padding:6px 12px">${data.loan_ref ?? '—'}</td></tr>
            <tr><td style="padding:6px 12px;background:#f8fafc;font-weight:600">Due Date</td><td style="padding:6px 12px">${data.due_date ?? '—'}</td></tr>
            <tr><td style="padding:6px 12px;background:#f8fafc;font-weight:600">Amount Due</td><td style="padding:6px 12px">${data.amount ?? '—'}</td></tr>
            <tr><td style="padding:6px 12px;background:#fef2f2;font-weight:700;color:#dc2626">Days Overdue</td><td style="padding:6px 12px;color:#dc2626;font-weight:700">${data.days_overdue}</td></tr>
          </table>
          <p>Please arrange payment at the earliest to avoid further action.</p>
          <p style="color:#64748b;font-size:12px">— ${company}</p>`,
      };

    case 'PROMOTION_DEPT_APPROVED':
      return {
        subject: `Your Promotion Request — Approved by Department Manager`,
        html: `
          <p>Dear <strong>${employee_name}</strong>,</p>
          <p>Your promotion request has been <strong style="color:#059669">approved by your Department Manager</strong>.</p>
          <p>It is now pending final HR review.</p>
          ${data.comment ? `<blockquote style="border-left:3px solid #e2e8f0;margin:12px 0;padding:8px 16px;color:#475569"><em>${data.comment}</em></blockquote>` : ''}
          <p style="color:#64748b;font-size:12px">— ${company}</p>`,
      };

    case 'PROMOTION_DEPT_REJECTED':
      return {
        subject: `Your Promotion Request — Not Approved by Department Manager`,
        html: `
          <p>Dear <strong>${employee_name}</strong>,</p>
          <p>We regret to inform you that your promotion request has been <strong style="color:#dc2626">not approved by your Department Manager</strong>.</p>
          ${data.comment ? `<blockquote style="border-left:3px solid #e2e8f0;margin:12px 0;padding:8px 16px;color:#475569"><em>${data.comment}</em></blockquote>` : ''}
          <p>Please speak to your Department Manager or HR for further guidance.</p>
          <p style="color:#64748b;font-size:12px">— ${company}</p>`,
      };

    case 'PROMOTION_APPROVED':
      return {
        subject: `Your Promotion Request — Approved by HR`,
        html: `
          <p>Dear <strong>${employee_name}</strong>,</p>
          <p>Congratulations! Your promotion request has been <strong style="color:#059669">approved by HR</strong>.</p>
          ${data.comment ? `<blockquote style="border-left:3px solid #e2e8f0;margin:12px 0;padding:8px 16px;color:#475569"><em>${data.comment}</em></blockquote>` : ''}
          <p>Your promotion will be executed shortly. Please stay in touch with HR for the effective date.</p>
          <p style="color:#64748b;font-size:12px">— ${company}</p>`,
      };

    case 'PROMOTION_REJECTED':
      return {
        subject: `Your Promotion Request — Not Approved by HR`,
        html: `
          <p>Dear <strong>${employee_name}</strong>,</p>
          <p>We regret to inform you that your promotion request has been <strong style="color:#dc2626">not approved by HR</strong>.</p>
          ${data.comment ? `<blockquote style="border-left:3px solid #e2e8f0;margin:12px 0;padding:8px 16px;color:#475569"><em>${data.comment}</em></blockquote>` : ''}
          <p>For further information, please contact HR.</p>
          <p style="color:#64748b;font-size:12px">— ${company}</p>`,
      };

    case 'PROMOTION_EXECUTED':
      return {
        subject: `Your Promotion Has Been Executed — Effective ${data.execution_date ?? ''}`,
        html: `
          <p>Dear <strong>${employee_name}</strong>,</p>
          <p>🎉 Your promotion has been <strong style="color:#059669">officially executed</strong> effective <strong>${data.execution_date ?? '—'}</strong>.</p>
          ${data.new_grade ? `<p>New Grade: <strong>${data.new_grade}</strong></p>` : ''}
          ${data.new_salary ? `<p>New Salary: <strong>${data.new_salary}</strong></p>` : ''}
          <p>Welcome to your new role! Please coordinate with HR for any paperwork.</p>
          <p style="color:#64748b;font-size:12px">— ${company}</p>`,
      };

    // ── Shift Swap notifications ─────────────────────────────────
    case 'SHIFT_SWAP_SUBMITTED':
      return {
        subject: `Shift Swap Request Submitted — ${data.swap_date ?? ''}`,
        html: `
          <div style="font-family:sans-serif;max-width:560px">
            <div style="background:#0f172a;padding:16px 20px;border-radius:8px 8px 0 0">
              <h2 style="color:#fff;margin:0;font-size:16px">🔄 New Shift Swap Request</h2>
              <p style="color:#94a3b8;margin:4px 0 0;font-size:12px">BKG Group — Shift Management</p>
            </div>
            <div style="padding:20px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 8px 8px">
              <p>Dear <strong>HR Team</strong>,</p>
              <p>A new shift swap request has been submitted and requires your attention.</p>
              <table style="border-collapse:collapse;width:100%;margin:16px 0">
                <tr style="background:#f8fafc"><td style="padding:8px 14px;font-weight:600;border:1px solid #e2e8f0;width:40%">Requesting Employee</td><td style="padding:8px 14px;border:1px solid #e2e8f0">${data.requester_name ?? '—'}</td></tr>
                <tr><td style="padding:8px 14px;font-weight:600;border:1px solid #e2e8f0;background:#f8fafc">Swap With</td><td style="padding:8px 14px;border:1px solid #e2e8f0">${data.target_name ?? '—'}</td></tr>
                <tr style="background:#f8fafc"><td style="padding:8px 14px;font-weight:600;border:1px solid #e2e8f0">Shift</td><td style="padding:8px 14px;border:1px solid #e2e8f0">${data.shift_name ?? '—'}</td></tr>
                <tr><td style="padding:8px 14px;font-weight:600;border:1px solid #e2e8f0;background:#f8fafc">Swap Date</td><td style="padding:8px 14px;border:1px solid #e2e8f0">${data.swap_date ?? '—'}</td></tr>
                ${data.reason ? `<tr style="background:#f8fafc"><td style="padding:8px 14px;font-weight:600;border:1px solid #e2e8f0">Reason</td><td style="padding:8px 14px;border:1px solid #e2e8f0;font-style:italic">${data.reason}</td></tr>` : ''}
              </table>
              <p>Please log in to the <strong>Shift Management</strong> module to review and approve or reject this request.</p>
              <p style="color:#64748b;font-size:12px;margin-top:20px">— ${company} · This is an automated notification</p>
            </div>
          </div>`,
      };

    case 'SHIFT_SWAP_APPROVED':
      return {
        subject: `Your Shift Swap Request Approved — ${data.swap_date ?? ''}`,
        html: `
          <div style="font-family:sans-serif;max-width:560px">
            <div style="background:#059669;padding:16px 20px;border-radius:8px 8px 0 0">
              <h2 style="color:#fff;margin:0;font-size:16px">✅ Shift Swap Approved</h2>
              <p style="color:#d1fae5;margin:4px 0 0;font-size:12px">BKG Group — Shift Management</p>
            </div>
            <div style="padding:20px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 8px 8px">
              <p>Dear <strong>${employee_name}</strong>,</p>
              <p>Your shift swap request has been <strong style="color:#059669">approved by HR</strong>.</p>
              <table style="border-collapse:collapse;width:100%;margin:16px 0">
                <tr style="background:#f0fdf4"><td style="padding:8px 14px;font-weight:600;border:1px solid #e2e8f0;width:40%">Swap With</td><td style="padding:8px 14px;border:1px solid #e2e8f0">${data.target_name ?? '—'}</td></tr>
                <tr><td style="padding:8px 14px;font-weight:600;border:1px solid #e2e8f0;background:#f0fdf4">Shift</td><td style="padding:8px 14px;border:1px solid #e2e8f0">${data.shift_name ?? '—'}</td></tr>
                <tr style="background:#f0fdf4"><td style="padding:8px 14px;font-weight:600;border:1px solid #e2e8f0">Effective Date</td><td style="padding:8px 14px;border:1px solid #e2e8f0;font-weight:700">${data.swap_date ?? '—'}</td></tr>
              </table>
              <p>Please coordinate with <strong>${data.target_name ?? 'your colleague'}</strong> to confirm the swap arrangement.</p>
              <p style="color:#64748b;font-size:12px;margin-top:20px">— ${company} · This is an automated notification</p>
            </div>
          </div>`,
      };

    case 'SHIFT_SWAP_REJECTED':
      return {
        subject: `Your Shift Swap Request — Not Approved`,
        html: `
          <div style="font-family:sans-serif;max-width:560px">
            <div style="background:#dc2626;padding:16px 20px;border-radius:8px 8px 0 0">
              <h2 style="color:#fff;margin:0;font-size:16px">❌ Shift Swap Not Approved</h2>
              <p style="color:#fee2e2;margin:4px 0 0;font-size:12px">BKG Group — Shift Management</p>
            </div>
            <div style="padding:20px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 8px 8px">
              <p>Dear <strong>${employee_name}</strong>,</p>
              <p>Your shift swap request for <strong>${data.swap_date ?? '—'}</strong> has been <strong style="color:#dc2626">not approved</strong>.</p>
              ${data.reason ? `<blockquote style="border-left:3px solid #fca5a5;margin:12px 0;padding:8px 16px;color:#475569"><em>${data.reason}</em></blockquote>` : ''}
              <p>Please contact HR or your manager if you have questions about this decision.</p>
              <p style="color:#64748b;font-size:12px;margin-top:20px">— ${company} · This is an automated notification</p>
            </div>
          </div>`,
      };

    default:
      return { subject: 'HR Notification', html: `<p>Dear ${employee_name}, you have a new HR notification.</p>` };
  }
}

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: CORS });
  }

  try {
    const payload: EmailPayload = await req.json();
    const { recipient_email, notification_type, employee_name } = payload;

    if (!recipient_email || !notification_type || !employee_name) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: recipient_email, notification_type, employee_name' }),
        { status: 400, headers: { ...CORS, 'Content-Type': 'application/json' } },
      );
    }

    const { subject, html } = buildEmail(payload);
    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');

    if (!RESEND_API_KEY) {
      // Fallback: log and return success without sending (dev mode)
      console.warn('[send-notification-email] RESEND_API_KEY not set — email not sent', { to: recipient_email, subject });
      return new Response(
        JSON.stringify({ success: true, dev_mode: true, message: 'Email logged (RESEND_API_KEY not configured)' }),
        { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } },
      );
    }

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'BKG HR <noreply@bkggroup.hr>',
        to: [recipient_email],
        subject,
        html,
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error('[send-notification-email] Resend error:', errText);
      return new Response(
        JSON.stringify({ error: 'Email delivery failed', detail: errText }),
        { status: 502, headers: { ...CORS, 'Content-Type': 'application/json' } },
      );
    }

    const result = await res.json();
    return new Response(
      JSON.stringify({ success: true, email_id: result.id }),
      { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } },
    );
  } catch (err) {
    console.error('[send-notification-email] Unexpected error:', err);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...CORS, 'Content-Type': 'application/json' } },
    );
  }
});
