
-- Payroll Components
CREATE TABLE payroll_components (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  component_type text NOT NULL CHECK (component_type IN ('earning','deduction','benefit')),
  calculation_method text NOT NULL DEFAULT 'fixed' CHECK (calculation_method IN ('fixed','percentage','formula')),
  is_taxable boolean NOT NULL DEFAULT false,
  is_active boolean NOT NULL DEFAULT true,
  description text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Salary Structures
CREATE TABLE salary_structures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Salary Structure Components (junction)
CREATE TABLE salary_structure_components (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salary_structure_id uuid NOT NULL REFERENCES salary_structures(id) ON DELETE CASCADE,
  payroll_component_id uuid NOT NULL REFERENCES payroll_components(id) ON DELETE CASCADE,
  amount numeric(15,2),
  rate numeric(8,4),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (salary_structure_id, payroll_component_id)
);

-- Employee Salary Structure Assignment
CREATE TABLE employee_salary_structures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  salary_structure_id uuid NOT NULL REFERENCES salary_structures(id) ON DELETE RESTRICT,
  effective_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (employee_id)
);

-- Payroll Settings (single-row config)
CREATE TABLE payroll_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pay_frequency text NOT NULL DEFAULT 'monthly' CHECK (pay_frequency IN ('weekly','bi_weekly','monthly')),
  currency text NOT NULL DEFAULT 'USD',
  cut_off_day integer NOT NULL DEFAULT 25 CHECK (cut_off_day BETWEEN 1 AND 31),
  payment_day integer NOT NULL DEFAULT 5 CHECK (payment_day BETWEEN 1 AND 31),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Statutory Deductions
CREATE TABLE statutory_deductions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deduction_type text NOT NULL CHECK (deduction_type IN ('income_tax','social_insurance','provident_fund','other')),
  name text NOT NULL,
  rate numeric(8,4),
  threshold numeric(15,2),
  max_amount numeric(15,2),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- RLS: authenticated users can manage all payroll config tables
ALTER TABLE payroll_components ENABLE ROW LEVEL SECURITY;
ALTER TABLE salary_structures ENABLE ROW LEVEL SECURITY;
ALTER TABLE salary_structure_components ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_salary_structures ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE statutory_deductions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth_all_payroll_components" ON payroll_components FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_salary_structures" ON salary_structures FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_ssc" ON salary_structure_components FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_ess_assign" ON employee_salary_structures FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_payroll_settings" ON payroll_settings FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_statutory_deductions" ON statutory_deductions FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Seed default payroll components
INSERT INTO payroll_components (name, component_type, calculation_method, is_taxable, description) VALUES
  ('Basic Salary',           'earning',   'fixed',      true,  'Base monthly salary'),
  ('Housing Allowance',      'earning',   'fixed',      false, 'Monthly housing allowance'),
  ('Transport Allowance',    'earning',   'fixed',      false, 'Monthly transport allowance'),
  ('Meal Allowance',         'earning',   'fixed',      false, 'Monthly meal allowance'),
  ('Overtime Pay',           'earning',   'fixed',      true,  'Additional compensation for overtime hours'),
  ('Performance Bonus',      'earning',   'fixed',      true,  'Discretionary performance bonus'),
  ('Income Tax',             'deduction', 'percentage', false, 'Statutory income tax deduction'),
  ('Social Insurance',       'deduction', 'percentage', false, 'Employee social insurance contribution'),
  ('Provident Fund',         'deduction', 'percentage', false, 'Employee provident fund contribution'),
  ('Loan Repayment',         'deduction', 'fixed',      false, 'Monthly loan repayment deduction');

-- Seed default statutory deductions
INSERT INTO statutory_deductions (deduction_type, name, rate, threshold, max_amount) VALUES
  ('income_tax',       'Income Tax (Standard)',         0.1500, 5000.00,  null),
  ('social_insurance', 'Social Insurance (Employee)',   0.0500, null,     500.00),
  ('provident_fund',   'Provident Fund (Employee)',     0.0300, null,     null);

-- Seed default salary structure
INSERT INTO salary_structures (name, description) VALUES
  ('Standard Monthly', 'Default monthly salary structure for regular employees'),
  ('Executive Package', 'Enhanced package for senior management');

-- Default payroll settings
INSERT INTO payroll_settings (pay_frequency, currency, cut_off_day, payment_day) VALUES ('monthly', 'USD', 25, 5);

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE payroll_components, salary_structures, payroll_settings, statutory_deductions;
