
-- Shift Roster: weekly employee-shift assignments
CREATE TABLE shift_roster (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id  uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  shift_id     uuid NOT NULL REFERENCES shifts(id)    ON DELETE CASCADE,
  week_start   date NOT NULL,
  notes        text,
  created_by   uuid REFERENCES employees(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (employee_id, week_start)
);

ALTER TABLE shift_roster ENABLE ROW LEVEL SECURITY;

CREATE POLICY "roster_select_all" ON shift_roster
  FOR SELECT USING (true);

CREATE POLICY "roster_insert_auth" ON shift_roster
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "roster_update_auth" ON shift_roster
  FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "roster_delete_auth" ON shift_roster
  FOR DELETE USING (auth.role() = 'authenticated');

-- Shift Swap Requests
CREATE TABLE shift_swap_requests (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id   uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  target_id      uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  shift_id       uuid NOT NULL REFERENCES shifts(id)    ON DELETE CASCADE,
  swap_date      date NOT NULL,
  reason         text,
  status         text NOT NULL DEFAULT 'pending'
                   CHECK (status IN ('pending','approved','rejected')),
  reviewed_by    uuid REFERENCES employees(id),
  reviewed_at    timestamptz,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE shift_swap_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "swaps_select_all" ON shift_swap_requests
  FOR SELECT USING (true);

CREATE POLICY "swaps_insert_auth" ON shift_swap_requests
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "swaps_update_auth" ON shift_swap_requests
  FOR UPDATE USING (auth.role() = 'authenticated');

-- Trigger: keep updated_at current on both tables
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TRIGGER trg_shift_roster_updated_at
  BEFORE UPDATE ON shift_roster
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_shift_swap_updated_at
  BEFORE UPDATE ON shift_swap_requests
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable Realtime for live swap request updates
ALTER PUBLICATION supabase_realtime ADD TABLE shift_swap_requests;
