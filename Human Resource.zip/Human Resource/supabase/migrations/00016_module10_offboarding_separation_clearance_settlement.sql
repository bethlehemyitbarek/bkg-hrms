
-- ─────────────────────────────────────────────────────────────────────────────
-- 10.1 SeparationNotice
-- ─────────────────────────────────────────────────────────────────────────────
CREATE SEQUENCE separation_notice_seq START 1;

CREATE TABLE separation_notices (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  separation_notice_id     UUID NOT NULL DEFAULT gen_random_uuid(),
  notice_number            VARCHAR(30) NOT NULL DEFAULT 'SPN-0001',
  employee_id              UUID NOT NULL REFERENCES employees(id),
  offboarding_id           UUID REFERENCES employee_offboarding(id),
  separation_type          VARCHAR(30) NOT NULL
                             CHECK (separation_type IN ('RESIGNATION','TERMINATION','RETIREMENT','CONTRACT_END','REDUNDANCY','DEATH','OTHER')),
  notice_date              DATE NOT NULL DEFAULT CURRENT_DATE,
  last_working_day         DATE NOT NULL,
  reason                   VARCHAR(4000),
  notice_status            VARCHAR(20) NOT NULL DEFAULT 'SUBMITTED'
                             CHECK (notice_status IN ('SUBMITTED','ACKNOWLEDGED','APPROVED','REJECTED','WITHDRAWN')),
  acknowledged_at          TIMESTAMPTZ,
  approved_at              TIMESTAMPTZ,
  approved_by_id           UUID REFERENCES employees(id),
  rejection_reason         VARCHAR(2000),
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_separation_notice_id     UNIQUE (separation_notice_id),
  CONSTRAINT uq_separation_notice_number UNIQUE (notice_number)
);
CREATE INDEX idx_sep_notice_employee ON separation_notices (employee_id)               WHERE is_deleted = 0;
CREATE INDEX idx_sep_notice_status   ON separation_notices (notice_status, notice_date) WHERE is_deleted = 0;

CREATE OR REPLACE FUNCTION generate_separation_notice_number()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.notice_number := 'SPN-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(NEXTVAL('separation_notice_seq')::TEXT, 5, '0');
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_separation_notice_number
  BEFORE INSERT ON separation_notices
  FOR EACH ROW EXECUTE FUNCTION generate_separation_notice_number();

-- ─────────────────────────────────────────────────────────────────────────────
-- 10.2 ClearanceWorkflow
-- ─────────────────────────────────────────────────────────────────────────────
CREATE SEQUENCE clearance_workflow_seq START 1;

CREATE TABLE clearance_workflows (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  clearance_workflow_id    UUID NOT NULL DEFAULT gen_random_uuid(),
  clearance_number         VARCHAR(30) NOT NULL DEFAULT 'CLR-0001',
  employee_id              UUID NOT NULL REFERENCES employees(id),
  separation_notice_id     UUID REFERENCES separation_notices(separation_notice_id),
  offboarding_id           UUID REFERENCES employee_offboarding(id),
  overall_status           VARCHAR(20) NOT NULL DEFAULT 'PENDING'
                             CHECK (overall_status IN ('PENDING','IN_PROGRESS','CLEARED','BLOCKED')),
  -- Dept clearances
  hr_status                VARCHAR(20) NOT NULL DEFAULT 'PENDING'
                             CHECK (hr_status IN ('PENDING','CLEARED','BLOCKED')),
  hr_cleared_at            TIMESTAMPTZ,
  hr_notes                 VARCHAR(1000),
  it_status                VARCHAR(20) NOT NULL DEFAULT 'PENDING'
                             CHECK (it_status IN ('PENDING','CLEARED','BLOCKED')),
  it_cleared_at            TIMESTAMPTZ,
  it_notes                 VARCHAR(1000),
  finance_status           VARCHAR(20) NOT NULL DEFAULT 'PENDING'
                             CHECK (finance_status IN ('PENDING','CLEARED','BLOCKED')),
  finance_cleared_at       TIMESTAMPTZ,
  finance_notes            VARCHAR(1000),
  assets_status            VARCHAR(20) NOT NULL DEFAULT 'PENDING'
                             CHECK (assets_status IN ('PENDING','CLEARED','BLOCKED')),
  assets_cleared_at        TIMESTAMPTZ,
  assets_notes             VARCHAR(1000),
  legal_status             VARCHAR(20) NOT NULL DEFAULT 'PENDING'
                             CHECK (legal_status IN ('PENDING','CLEARED','BLOCKED')),
  legal_cleared_at         TIMESTAMPTZ,
  legal_notes              VARCHAR(1000),
  security_status          VARCHAR(20) NOT NULL DEFAULT 'PENDING'
                             CHECK (security_status IN ('PENDING','CLEARED','BLOCKED')),
  security_cleared_at      TIMESTAMPTZ,
  security_notes           VARCHAR(1000),
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_clearance_workflow_id     UNIQUE (clearance_workflow_id),
  CONSTRAINT uq_clearance_workflow_number UNIQUE (clearance_number)
);
CREATE INDEX idx_clearance_employee ON clearance_workflows (employee_id)     WHERE is_deleted = 0;
CREATE INDEX idx_clearance_status   ON clearance_workflows (overall_status)  WHERE is_deleted = 0;

CREATE OR REPLACE FUNCTION generate_clearance_number()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.clearance_number := 'CLR-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(NEXTVAL('clearance_workflow_seq')::TEXT, 5, '0');
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_clearance_number
  BEFORE INSERT ON clearance_workflows
  FOR EACH ROW EXECUTE FUNCTION generate_clearance_number();

-- ─────────────────────────────────────────────────────────────────────────────
-- 10.3 FinalSettlement
-- ─────────────────────────────────────────────────────────────────────────────
CREATE SEQUENCE final_settlement_seq START 1;

CREATE TABLE final_settlements (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  final_settlement_id      UUID NOT NULL DEFAULT gen_random_uuid(),
  settlement_number        VARCHAR(30) NOT NULL DEFAULT 'STL-0001',
  employee_id              UUID NOT NULL REFERENCES employees(id),
  separation_notice_id     UUID REFERENCES separation_notices(separation_notice_id),
  clearance_workflow_id    UUID REFERENCES clearance_workflows(clearance_workflow_id),
  settlement_status        VARCHAR(20) NOT NULL DEFAULT 'DRAFT'
                             CHECK (settlement_status IN ('DRAFT','PENDING_APPROVAL','APPROVED','PAID','CANCELLED')),
  -- Components
  basic_salary_balance     DECIMAL(18,2) NOT NULL DEFAULT 0,
  leave_encashment         DECIMAL(18,2) NOT NULL DEFAULT 0,
  gratuity_amount          DECIMAL(18,2) NOT NULL DEFAULT 0,
  bonus_amount             DECIMAL(18,2) NOT NULL DEFAULT 0,
  deductions               DECIMAL(18,2) NOT NULL DEFAULT 0,
  loan_deductions          DECIMAL(18,2) NOT NULL DEFAULT 0,
  other_additions          DECIMAL(18,2) NOT NULL DEFAULT 0,
  other_deductions         DECIMAL(18,2) NOT NULL DEFAULT 0,
  net_payable              DECIMAL(18,2) GENERATED ALWAYS AS (
    basic_salary_balance + leave_encashment + gratuity_amount + bonus_amount + other_additions
    - deductions - loan_deductions - other_deductions
  ) STORED,
  currency_code            VARCHAR(10) NOT NULL DEFAULT 'USD',
  payment_method           VARCHAR(20)
                             CHECK (payment_method IN ('BANK_TRANSFER','CHEQUE','CASH','OTHER')),
  payment_date             DATE,
  payment_reference        VARCHAR(100),
  notes                    VARCHAR(4000),
  approved_by_id           UUID REFERENCES employees(id),
  approved_at              TIMESTAMPTZ,
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_final_settlement_id     UNIQUE (final_settlement_id),
  CONSTRAINT uq_final_settlement_number UNIQUE (settlement_number)
);
CREATE INDEX idx_settlement_employee ON final_settlements (employee_id)        WHERE is_deleted = 0;
CREATE INDEX idx_settlement_status   ON final_settlements (settlement_status)  WHERE is_deleted = 0;

CREATE OR REPLACE FUNCTION generate_settlement_number()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.settlement_number := 'STL-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(NEXTVAL('final_settlement_seq')::TEXT, 5, '0');
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_settlement_number
  BEFORE INSERT ON final_settlements
  FOR EACH ROW EXECUTE FUNCTION generate_settlement_number();

-- Enable Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE separation_notices;
ALTER PUBLICATION supabase_realtime ADD TABLE clearance_workflows;
ALTER PUBLICATION supabase_realtime ADD TABLE final_settlements;
