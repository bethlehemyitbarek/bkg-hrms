
-- Add reminder_sent to loan_repayment_schedules
ALTER TABLE loan_repayment_schedules
  ADD COLUMN IF NOT EXISTS reminder_sent boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS reminder_sent_at timestamptz;

-- Add approval fields to promotion_requests
ALTER TABLE promotion_requests
  ADD COLUMN IF NOT EXISTS approved_by      text,
  ADD COLUMN IF NOT EXISTS approval_comment text,
  ADD COLUMN IF NOT EXISTS execution_date   date;
