
-- Offboarding checklist templates
create table offboarding_checklists (
  id              uuid primary key default gen_random_uuid(),
  name            text not null,
  description     text,
  applicable_to   text default 'all',
  is_active       boolean not null default true,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- Offboarding tasks per checklist template
create table offboarding_tasks (
  id                      uuid primary key default gen_random_uuid(),
  checklist_id            uuid not null references offboarding_checklists(id) on delete cascade,
  title                   text not null,
  description             text,
  responsible             text,
  due_days_before_last_day integer default 0,
  is_mandatory            boolean not null default true,
  sequence                integer not null default 0,
  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now()
);

create index offboarding_tasks_checklist_idx on offboarding_tasks(checklist_id);

-- Employee-level offboarding records
create table employee_offboarding (
  id                    uuid primary key default gen_random_uuid(),
  employee_id           uuid not null references employees(id) on delete cascade,
  checklist_id          uuid references offboarding_checklists(id),
  resignation_date      date,
  last_working_date     date,
  exit_interview_date   date,
  exit_interview_done   boolean not null default false,
  clearance_it          boolean not null default false,
  clearance_finance     boolean not null default false,
  clearance_hr          boolean not null default false,
  clearance_assets      boolean not null default false,
  status                text not null default 'initiated' check (status in ('initiated','in_progress','completed','cancelled')),
  progress_percentage   numeric(5,2) not null default 0,
  reason                text,
  notes                 text,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

create index employee_offboarding_employee_idx on employee_offboarding(employee_id);

-- Task completion tracking (shared for onboarding + offboarding)
create table if not exists onboarding_task_completions (
  id            uuid primary key default gen_random_uuid(),
  onboarding_id uuid not null references employee_onboarding(id) on delete cascade,
  task_id       uuid not null references onboarding_tasks(id) on delete cascade,
  completed     boolean not null default false,
  completed_at  timestamptz,
  notes         text,
  created_at    timestamptz not null default now(),
  unique(onboarding_id, task_id)
);

create table offboarding_task_completions (
  id              uuid primary key default gen_random_uuid(),
  offboarding_id  uuid not null references employee_offboarding(id) on delete cascade,
  task_id         uuid not null references offboarding_tasks(id) on delete cascade,
  completed       boolean not null default false,
  completed_at    timestamptz,
  notes           text,
  created_at      timestamptz not null default now(),
  unique(offboarding_id, task_id)
);

-- RLS
alter table offboarding_checklists enable row level security;
alter table offboarding_tasks enable row level security;
alter table employee_offboarding enable row level security;
alter table onboarding_task_completions enable row level security;
alter table offboarding_task_completions enable row level security;

create policy "auth_read_offboarding_checklists" on offboarding_checklists for select to authenticated using (true);
create policy "auth_write_offboarding_checklists" on offboarding_checklists for all to authenticated using (true) with check (true);
create policy "auth_read_offboarding_tasks" on offboarding_tasks for select to authenticated using (true);
create policy "auth_write_offboarding_tasks" on offboarding_tasks for all to authenticated using (true) with check (true);
create policy "auth_read_employee_offboarding" on employee_offboarding for select to authenticated using (true);
create policy "auth_write_employee_offboarding" on employee_offboarding for all to authenticated using (true) with check (true);
create policy "auth_read_onboarding_completions" on onboarding_task_completions for select to authenticated using (true);
create policy "auth_write_onboarding_completions" on onboarding_task_completions for all to authenticated using (true) with check (true);
create policy "auth_read_offboarding_completions" on offboarding_task_completions for select to authenticated using (true);
create policy "auth_write_offboarding_completions" on offboarding_task_completions for all to authenticated using (true) with check (true);

-- RLS for existing onboarding tables (if not already set)
alter table onboarding_checklists enable row level security;
alter table onboarding_tasks enable row level security;
alter table employee_onboarding enable row level security;

create policy "auth_read_onboarding_checklists" on onboarding_checklists for select to authenticated using (true);
create policy "auth_write_onboarding_checklists" on onboarding_checklists for all to authenticated using (true) with check (true);
create policy "auth_read_onboarding_tasks_tbl" on onboarding_tasks for select to authenticated using (true);
create policy "auth_write_onboarding_tasks_tbl" on onboarding_tasks for all to authenticated using (true) with check (true);
create policy "auth_read_employee_onboarding" on employee_onboarding for select to authenticated using (true);
create policy "auth_write_employee_onboarding" on employee_onboarding for all to authenticated using (true) with check (true);

-- Seed default checklist templates
insert into offboarding_checklists (name, description, applicable_to, is_active) values
  ('Standard Exit Checklist', 'Default offboarding checklist for all departing employees', 'all', true);

insert into offboarding_tasks (checklist_id, title, responsible, due_days_before_last_day, is_mandatory, sequence)
select id, unnest(array['Return company assets','IT account deactivation','Finance clearance','HR documentation','Exit interview','Knowledge transfer','Access card return']),
       unnest(array['Employee','IT','Finance','HR','HR','Manager','Security']),
       unnest(array[3,1,2,5,7,14,1]),
       true,
       generate_subscripts(array[1,2,3,4,5,6,7], 1)
from offboarding_checklists where name = 'Standard Exit Checklist' limit 1;

insert into onboarding_checklists (name, description, applicable_to, is_active) values
  ('Standard New Hire Checklist', 'Default onboarding checklist for all new employees', 'all', true)
on conflict do nothing;

insert into onboarding_tasks (checklist_id, title, responsible, due_days_after_hire, is_mandatory, sequence)
select id, unnest(array['Welcome orientation','IT setup & system access','Policy handbook review','Department introduction','Benefits enrollment','Security badge issue','First 30-day check-in']),
       unnest(array['HR','IT','HR','Manager','HR','Security','Manager']),
       unnest(array[1,1,3,2,5,1,30]),
       true,
       generate_subscripts(array[1,2,3,4,5,6,7], 1)
from onboarding_checklists where name = 'Standard New Hire Checklist' limit 1;
