-- RLS for coverage_tiers
ALTER TABLE coverage_tiers ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='coverage_tiers' AND policyname='coverage_tiers_all_access') THEN
    EXECUTE 'CREATE POLICY "coverage_tiers_all_access" ON coverage_tiers FOR ALL USING (true) WITH CHECK (true)';
  END IF;
END $$;

-- RLS for bonus_configurations
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='bonus_configurations' AND policyname='bonus_configurations_all_access') THEN
    ALTER TABLE bonus_configurations ENABLE ROW LEVEL SECURITY;
    EXECUTE 'CREATE POLICY "bonus_configurations_all_access" ON bonus_configurations FOR ALL USING (true) WITH CHECK (true)';
  END IF;
END $$;

-- Ensure employee_compensations FK exists for join in compensation.service.ts
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_name='employee_compensations' AND constraint_name='employee_compensations_employee_id_fkey'
  ) THEN
    ALTER TABLE employee_compensations
      ADD CONSTRAINT employee_compensations_employee_id_fkey
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE;
  END IF;
END $$;