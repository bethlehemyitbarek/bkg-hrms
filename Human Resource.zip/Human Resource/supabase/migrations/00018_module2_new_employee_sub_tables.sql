
-- 2.2 Employee Emergency Contacts
CREATE TABLE employee_emergency_contacts (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contact_id      UUID NOT NULL DEFAULT gen_random_uuid(),
  employee_id     UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  full_name       VARCHAR(200) NOT NULL,
  relationship    VARCHAR(50) NOT NULL,
  phone_number    VARCHAR(50) NOT NULL,
  email           VARCHAR(255),
  country_id      UUID,
  region          VARCHAR(100),
  city            VARCHAR(100),
  sub_city        VARCHAR(100),
  woreda          VARCHAR(100),
  street_name     VARCHAR(100),
  house_number    VARCHAR(50),
  priority        INTEGER NOT NULL DEFAULT 1,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW(),
  is_active       SMALLINT NOT NULL DEFAULT 1,
  is_deleted      SMALLINT NOT NULL DEFAULT 0
);
CREATE INDEX ON employee_emergency_contacts(employee_id) WHERE is_deleted = 0;

-- 2.4 Employee Family
CREATE TABLE employee_families (
  id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id                   UUID NOT NULL DEFAULT gen_random_uuid(),
  employee_id                 UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  spouse_full_name            VARCHAR(150),
  spouse_date_of_birth        DATE,
  spouse_photo                VARCHAR(500),
  marriage_date               DATE,
  marriage_certificate        VARCHAR(500),
  spouse_phone_number         VARCHAR(20),
  spouse_residence_address    JSONB,
  spouse_occupation           VARCHAR(100),
  dependant_relationship      VARCHAR(20) CHECK (dependant_relationship IN ('CHILD','SPOUSE','PARENT','OTHER')),
  full_name                   VARCHAR(200),
  dependant_date_of_birth     DATE,
  gender                      VARCHAR(10) CHECK (gender IN ('MALE','FEMALE')),
  is_tax_dependent            SMALLINT NOT NULL DEFAULT 0,
  is_benefit_eligible         SMALLINT NOT NULL DEFAULT 0,
  living_parents_info         JSONB,
  children_info               JSONB,
  created_at                  TIMESTAMPTZ DEFAULT NOW(),
  updated_at                  TIMESTAMPTZ DEFAULT NOW(),
  is_active                   SMALLINT NOT NULL DEFAULT 1,
  is_deleted                  SMALLINT NOT NULL DEFAULT 0,
  is_current                  SMALLINT NOT NULL DEFAULT 1
);
CREATE INDEX ON employee_families(employee_id) WHERE is_deleted = 0;

-- 2.5 Work Assignments
CREATE TABLE work_assignments (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id       UUID NOT NULL DEFAULT gen_random_uuid(),
  employee_id         UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  business_unit_id    UUID,
  department_id       UUID REFERENCES departments(id),
  division_id         UUID,
  section_id          UUID,
  team_id             UUID,
  position_id         UUID REFERENCES positions(id),
  location_id         UUID REFERENCES locations(id),
  cost_center_id      UUID,
  job_title           VARCHAR(200),
  job_title_id        UUID,
  grade_id            UUID,
  step_id             UUID,
  direct_manager_id   UUID REFERENCES employees(id),
  dotted_manager_id   UUID REFERENCES employees(id),
  employment_category VARCHAR(20) CHECK (employment_category IN ('FULL_TIME','PART_TIME')),
  union_code          VARCHAR(50),
  shift_code          VARCHAR(50),
  fte_ratio           DECIMAL(3,2) DEFAULT 1.00,
  change_reason       VARCHAR(500),
  assignment_status   VARCHAR(20) NOT NULL DEFAULT 'ACTIVE'
                        CHECK (assignment_status IN ('ACTIVE','TRANSFERRED','ENDED','ACTING')),
  effective_from      TIMESTAMPTZ DEFAULT NOW(),
  effective_to        TIMESTAMPTZ DEFAULT '9999-12-31 23:59:59.999999',
  is_current          SMALLINT NOT NULL DEFAULT 1,
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW(),
  is_active           SMALLINT NOT NULL DEFAULT 1,
  is_deleted          SMALLINT NOT NULL DEFAULT 0
);
CREATE INDEX ON work_assignments(employee_id, is_active) WHERE is_deleted = 0;
CREATE INDEX ON work_assignments(department_id);
CREATE INDEX ON work_assignments(direct_manager_id);

-- 2.6 Employee Educations
CREATE TABLE employee_educations (
  id                              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  education_id                    UUID NOT NULL DEFAULT gen_random_uuid(),
  employee_id                     UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  education_level                 VARCHAR(30) NOT NULL
                                    CHECK (education_level IN ('UNATTENDED','8TH_GRADE','10TH_GRADE','12TH_GRADE','TVET','DIPLOMA','BACHELORS','MASTERS','PHD','OTHER')),
  field_of_study                  VARCHAR(200),
  institution_name                VARCHAR(300) NOT NULL,
  country                         VARCHAR(100),
  start_date                      DATE,
  graduation_date                 DATE,
  grade_or_gpa                    VARCHAR(20),
  certificate_number              VARCHAR(20),
  document_id                     UUID,
  university_cost_sharing_status  VARCHAR(20) DEFAULT 'PENDING'
                                    CHECK (university_cost_sharing_status IN ('PAID_FULL','ACTIVE','EXEMPT','PENDING')),
  total_shared_cost               DECIMAL(12,2) DEFAULT 0,
  remaining_balance               DECIMAL(12,2) DEFAULT 0,
  currency_code                   CHAR(3) DEFAULT 'ETB',
  clearance_status                VARCHAR(20) DEFAULT 'NOT_CLEARED'
                                    CHECK (clearance_status IN ('CLEARED','NOT_CLEARED','IN_PROGRESS')),
  created_at                      TIMESTAMPTZ DEFAULT NOW(),
  updated_at                      TIMESTAMPTZ DEFAULT NOW(),
  is_active                       SMALLINT NOT NULL DEFAULT 1,
  is_deleted                      SMALLINT NOT NULL DEFAULT 0,
  is_current                      SMALLINT NOT NULL DEFAULT 1
);
CREATE INDEX ON employee_educations(employee_id) WHERE is_deleted = 0;

-- 2.7 Work Experiences
CREATE TABLE work_experiences (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  experience_id         UUID NOT NULL DEFAULT gen_random_uuid(),
  employee_id           UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  company_name          VARCHAR(300) NOT NULL,
  job_title             VARCHAR(200) NOT NULL,
  employment_type       VARCHAR(20) CHECK (employment_type IN ('FULL_TIME','PART_TIME','CONTRACT','INTERNSHIP','TEMPORARY')),
  start_date            DATE NOT NULL,
  end_date              DATE,
  is_currently_working  SMALLINT NOT NULL DEFAULT 0,
  responsibilities      TEXT,
  salary                DECIMAL(18,2),
  salary_currency       CHAR(3) DEFAULT 'ETB',
  supervisor_contact    VARCHAR(200),
  reason_for_leaving    VARCHAR(1000),
  verification_status   VARCHAR(20) NOT NULL DEFAULT 'UNVERIFIED'
                          CHECK (verification_status IN ('UNVERIFIED','PENDING','VERIFIED','REJECTED')),
  created_at            TIMESTAMPTZ DEFAULT NOW(),
  updated_at            TIMESTAMPTZ DEFAULT NOW(),
  is_active             SMALLINT NOT NULL DEFAULT 1,
  is_deleted            SMALLINT NOT NULL DEFAULT 0,
  is_current            SMALLINT NOT NULL DEFAULT 1
);
CREATE INDEX ON work_experiences(employee_id) WHERE is_deleted = 0;

-- 2.8 Professional Credentials
CREATE TABLE professional_credentials (
  id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  credential_id           UUID NOT NULL DEFAULT gen_random_uuid(),
  employee_id             UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  credential_type         VARCHAR(30) NOT NULL
                            CHECK (credential_type IN ('CERTIFICATION','LICENSE','TRAINING','MEMBERSHIP','OTHER')),
  credential_name         VARCHAR(255) NOT NULL,
  issuing_authority       VARCHAR(255),
  issue_date              DATE,
  expiry_date             DATE,
  credential_number       VARCHAR(100),
  verification_reference  VARCHAR(255),
  document_id             UUID,
  effective_from          TIMESTAMPTZ DEFAULT NOW(),
  effective_to            TIMESTAMPTZ DEFAULT '9999-12-31 23:59:59.999999',
  created_at              TIMESTAMPTZ DEFAULT NOW(),
  updated_at              TIMESTAMPTZ DEFAULT NOW(),
  is_active               SMALLINT NOT NULL DEFAULT 1,
  is_deleted              SMALLINT NOT NULL DEFAULT 0,
  is_current              SMALLINT NOT NULL DEFAULT 1
);
CREATE INDEX ON professional_credentials(employee_id) WHERE is_deleted = 0;
CREATE INDEX ON professional_credentials(expiry_date);
