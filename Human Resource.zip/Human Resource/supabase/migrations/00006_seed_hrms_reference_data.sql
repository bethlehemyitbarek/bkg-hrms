
-- Seed Business Units
INSERT INTO business_units (code, name, description) VALUES
  ('BKG-CORP', 'BKG Corporation', 'Main corporate business unit'),
  ('BKG-TECH', 'BKG Technology', 'Technology and digital services'),
  ('BKG-FIN', 'BKG Finance', 'Financial services division');

-- Seed Locations
INSERT INTO locations (code, name, address, city, country, timezone) VALUES
  ('HQ-BKK', 'Bangkok HQ', '123 Sukhumvit Road', 'Bangkok', 'TH', 'Asia/Bangkok'),
  ('OFF-CM', 'Chiang Mai Office', '456 Nimman Road', 'Chiang Mai', 'TH', 'Asia/Bangkok'),
  ('OFF-PKT', 'Phuket Office', '789 Patong Beach Road', 'Phuket', 'TH', 'Asia/Bangkok');

-- Seed Job Grades
INSERT INTO job_grades (code, name, min_salary, max_salary, level) VALUES
  ('G1', 'Staff Level 1', 15000, 25000, 1),
  ('G2', 'Staff Level 2', 25000, 40000, 2),
  ('G3', 'Senior Staff', 40000, 65000, 3),
  ('G4', 'Supervisor', 60000, 90000, 4),
  ('G5', 'Manager', 80000, 130000, 5),
  ('G6', 'Senior Manager', 120000, 180000, 6),
  ('G7', 'Director', 160000, 250000, 7),
  ('G8', 'Vice President', 220000, 400000, 8);

-- Seed Divisions
INSERT INTO divisions (business_unit_id, code, name)
SELECT id, 'DIV-HR', 'Human Resources Division' FROM business_units WHERE code = 'BKG-CORP';
INSERT INTO divisions (business_unit_id, code, name)
SELECT id, 'DIV-IT', 'Information Technology Division' FROM business_units WHERE code = 'BKG-TECH';
INSERT INTO divisions (business_unit_id, code, name)
SELECT id, 'DIV-FIN', 'Finance Division' FROM business_units WHERE code = 'BKG-FIN';
INSERT INTO divisions (business_unit_id, code, name)
SELECT id, 'DIV-OPS', 'Operations Division' FROM business_units WHERE code = 'BKG-CORP';
INSERT INTO divisions (business_unit_id, code, name)
SELECT id, 'DIV-SALES', 'Sales & Marketing Division' FROM business_units WHERE code = 'BKG-CORP';

-- Seed Departments
INSERT INTO departments (division_id, code, name, description)
SELECT id, 'DEPT-HR', 'Human Resources', 'HR Management Department' FROM divisions WHERE code = 'DIV-HR';
INSERT INTO departments (division_id, code, name, description)
SELECT id, 'DEPT-REC', 'Recruitment', 'Talent Acquisition Department' FROM divisions WHERE code = 'DIV-HR';
INSERT INTO departments (division_id, code, name, description)
SELECT id, 'DEPT-IT', 'IT Department', 'Information Technology Department' FROM divisions WHERE code = 'DIV-IT';
INSERT INTO departments (division_id, code, name, description)
SELECT id, 'DEPT-DEV', 'Software Development', 'Application Development Department' FROM divisions WHERE code = 'DIV-IT';
INSERT INTO departments (division_id, code, name, description)
SELECT id, 'DEPT-FIN', 'Finance', 'Finance & Accounting Department' FROM divisions WHERE code = 'DIV-FIN';
INSERT INTO departments (division_id, code, name, description)
SELECT id, 'DEPT-ACC', 'Accounting', 'Accounting Department' FROM divisions WHERE code = 'DIV-FIN';
INSERT INTO departments (division_id, code, name, description)
SELECT id, 'DEPT-OPS', 'Operations', 'Operations Department' FROM divisions WHERE code = 'DIV-OPS';
INSERT INTO departments (division_id, code, name, description)
SELECT id, 'DEPT-SALES', 'Sales', 'Sales Department' FROM divisions WHERE code = 'DIV-SALES';
INSERT INTO departments (division_id, code, name, description)
SELECT id, 'DEPT-MKT', 'Marketing', 'Marketing Department' FROM divisions WHERE code = 'DIV-SALES';

-- Seed Positions
INSERT INTO positions (department_id, job_grade_id, code, title, is_managerial)
SELECT d.id, g.id, 'POS-HRM', 'HR Manager', true
FROM departments d, job_grades g WHERE d.code = 'DEPT-HR' AND g.code = 'G5';
INSERT INTO positions (department_id, job_grade_id, code, title)
SELECT d.id, g.id, 'POS-HRO', 'HR Officer'
FROM departments d, job_grades g WHERE d.code = 'DEPT-HR' AND g.code = 'G2';
INSERT INTO positions (department_id, job_grade_id, code, title)
SELECT d.id, g.id, 'POS-HRS', 'HR Specialist'
FROM departments d, job_grades g WHERE d.code = 'DEPT-HR' AND g.code = 'G3';
INSERT INTO positions (department_id, job_grade_id, code, title, is_managerial)
SELECT d.id, g.id, 'POS-ITM', 'IT Manager', true
FROM departments d, job_grades g WHERE d.code = 'DEPT-IT' AND g.code = 'G5';
INSERT INTO positions (department_id, job_grade_id, code, title)
SELECT d.id, g.id, 'POS-SWDEV', 'Software Developer'
FROM departments d, job_grades g WHERE d.code = 'DEPT-DEV' AND g.code = 'G3';
INSERT INTO positions (department_id, job_grade_id, code, title)
SELECT d.id, g.id, 'POS-SWDEVS', 'Senior Software Developer'
FROM departments d, job_grades g WHERE d.code = 'DEPT-DEV' AND g.code = 'G4';
INSERT INTO positions (department_id, job_grade_id, code, title, is_managerial)
SELECT d.id, g.id, 'POS-FINM', 'Finance Manager', true
FROM departments d, job_grades g WHERE d.code = 'DEPT-FIN' AND g.code = 'G5';
INSERT INTO positions (department_id, job_grade_id, code, title)
SELECT d.id, g.id, 'POS-ACCO', 'Accountant'
FROM departments d, job_grades g WHERE d.code = 'DEPT-ACC' AND g.code = 'G2';
INSERT INTO positions (department_id, job_grade_id, code, title)
SELECT d.id, g.id, 'POS-SALESO', 'Sales Officer'
FROM departments d, job_grades g WHERE d.code = 'DEPT-SALES' AND g.code = 'G2';

-- Seed Shifts
INSERT INTO shifts (code, name, shift_type, start_time, end_time, break_minutes, work_hours) VALUES
  ('SHIFT-REG', 'Regular Shift', 'regular', '09:00', '18:00', 60, 8),
  ('SHIFT-EARLY', 'Early Shift', 'regular', '07:00', '16:00', 60, 8),
  ('SHIFT-LATE', 'Late Shift', 'regular', '12:00', '21:00', 60, 8),
  ('SHIFT-NIGHT', 'Night Shift', 'night', '21:00', '06:00', 60, 8),
  ('SHIFT-FLEX', 'Flexible Hours', 'flexible', '08:00', '17:00', 60, 8);

-- Seed Leave Types
INSERT INTO leave_types (code, name, description, days_per_year, is_paid, can_carry_forward) VALUES
  ('AL', 'Annual Leave', 'Standard annual leave entitlement', 15, true, true),
  ('SL', 'Sick Leave', 'Medical/sick leave', 30, true, false),
  ('ML', 'Maternity Leave', 'Maternity leave for new mothers', 90, true, false),
  ('PL', 'Paternity Leave', 'Paternity leave for new fathers', 15, true, false),
  ('EL', 'Emergency Leave', 'Emergency/compassionate leave', 3, true, false),
  ('UL', 'Unpaid Leave', 'Leave without pay', 30, false, false),
  ('BL', 'Business Leave', 'Leave for official business trips', 30, true, false);

-- Seed Salary Components
INSERT INTO salary_components (code, name, component_type, calculation_type) VALUES
  ('BASE', 'Base Salary', 'earning', 'fixed'),
  ('OT', 'Overtime Pay', 'earning', 'formula'),
  ('TRANS', 'Transportation Allowance', 'earning', 'fixed'),
  ('MEAL', 'Meal Allowance', 'earning', 'fixed'),
  ('PHONE', 'Phone Allowance', 'earning', 'fixed'),
  ('HOUSING', 'Housing Allowance', 'earning', 'fixed'),
  ('TAX', 'Income Tax', 'deduction', 'percentage'),
  ('SSF', 'Social Security Fund', 'deduction', 'percentage'),
  ('PVF', 'Provident Fund', 'deduction', 'percentage');

-- Seed Benefit Plans
INSERT INTO benefit_plans (code, name, plan_type, coverage_amount, employer_contribution, employee_contribution) VALUES
  ('HEALTH-BASIC', 'Basic Health Insurance', 'health', 200000, 100, 0),
  ('HEALTH-PREM', 'Premium Health Insurance', 'health', 500000, 75, 25),
  ('DENTAL', 'Dental Plan', 'dental', 30000, 100, 0),
  ('LIFE', 'Life Insurance', 'life_insurance', 2000000, 100, 0),
  ('PVF-5', 'Provident Fund 5%', 'provident_fund', null, 5, 5);

-- Seed Compliance Policies
INSERT INTO compliance_policies (code, title, category, effective_date, status) VALUES
  ('POL-HR-001', 'Code of Conduct and Ethics', 'code_of_conduct', '2024-01-01', 'active'),
  ('POL-HR-002', 'Leave and Absence Policy', 'hr_policy', '2024-01-01', 'active'),
  ('POL-HR-003', 'Performance Management Policy', 'hr_policy', '2024-01-01', 'active'),
  ('POL-IT-001', 'IT Acceptable Use Policy', 'data_privacy', '2024-01-01', 'active'),
  ('POL-SAF-001', 'Workplace Safety Policy', 'safety', '2024-01-01', 'active');

-- Seed Sample Employees
INSERT INTO employees (
  employee_no, first_name, last_name, email, phone,
  department_id, position_id, location_id, job_grade_id,
  employment_type, employment_status, hire_date, gender
)
SELECT
  'EMP-001', 'Somchai', 'Jaidee', 'somchai.jaidee@bkg.co.th', '+66-81-111-1111',
  d.id, p.id, l.id, g.id,
  'full_time', 'active', '2020-01-15', 'male'
FROM departments d, positions p, locations l, job_grades g
WHERE d.code = 'DEPT-HR' AND p.code = 'POS-HRM' AND l.code = 'HQ-BKK' AND g.code = 'G5';

INSERT INTO employees (
  employee_no, first_name, last_name, email, phone,
  department_id, position_id, location_id, job_grade_id,
  employment_type, employment_status, hire_date, gender
)
SELECT
  'EMP-002', 'Nattaya', 'Wongsawat', 'nattaya.wongsawat@bkg.co.th', '+66-82-222-2222',
  d.id, p.id, l.id, g.id,
  'full_time', 'active', '2021-03-01', 'female'
FROM departments d, positions p, locations l, job_grades g
WHERE d.code = 'DEPT-HR' AND p.code = 'POS-HRO' AND l.code = 'HQ-BKK' AND g.code = 'G2';

INSERT INTO employees (
  employee_no, first_name, last_name, email, phone,
  department_id, position_id, location_id, job_grade_id,
  employment_type, employment_status, hire_date, gender
)
SELECT
  'EMP-003', 'Kittipong', 'Rattanakul', 'kittipong.rattanakul@bkg.co.th', '+66-83-333-3333',
  d.id, p.id, l.id, g.id,
  'full_time', 'active', '2019-07-10', 'male'
FROM departments d, positions p, locations l, job_grades g
WHERE d.code = 'DEPT-IT' AND p.code = 'POS-ITM' AND l.code = 'HQ-BKK' AND g.code = 'G5';

INSERT INTO employees (
  employee_no, first_name, last_name, email, phone,
  department_id, position_id, location_id, job_grade_id,
  employment_type, employment_status, hire_date, gender
)
SELECT
  'EMP-004', 'Pimchanok', 'Siriwong', 'pimchanok.siriwong@bkg.co.th', '+66-84-444-4444',
  d.id, p.id, l.id, g.id,
  'full_time', 'active', '2022-05-20', 'female'
FROM departments d, positions p, locations l, job_grades g
WHERE d.code = 'DEPT-DEV' AND p.code = 'POS-SWDEV' AND l.code = 'HQ-BKK' AND g.code = 'G3';

INSERT INTO employees (
  employee_no, first_name, last_name, email, phone,
  department_id, position_id, location_id, job_grade_id,
  employment_type, employment_status, hire_date, gender
)
SELECT
  'EMP-005', 'Wirat', 'Phromma', 'wirat.phromma@bkg.co.th', '+66-85-555-5555',
  d.id, p.id, l.id, g.id,
  'full_time', 'active', '2018-09-01', 'male'
FROM departments d, positions p, locations l, job_grades g
WHERE d.code = 'DEPT-FIN' AND p.code = 'POS-FINM' AND l.code = 'HQ-BKK' AND g.code = 'G5';

INSERT INTO employees (
  employee_no, first_name, last_name, email, phone,
  department_id, position_id, location_id, job_grade_id,
  employment_type, employment_status, hire_date, gender
)
SELECT
  'EMP-006', 'Supansa', 'Boonmee', 'supansa.boonmee@bkg.co.th', '+66-86-666-6666',
  d.id, p.id, l.id, g.id,
  'full_time', 'active', '2023-01-10', 'female'
FROM departments d, positions p, locations l, job_grades g
WHERE d.code = 'DEPT-DEV' AND p.code = 'POS-SWDEV' AND l.code = 'HQ-BKK' AND g.code = 'G3';

INSERT INTO employees (
  employee_no, first_name, last_name, email, phone,
  department_id, position_id, location_id, job_grade_id,
  employment_type, employment_status, hire_date, gender
)
SELECT
  'EMP-007', 'Chaiwat', 'Kantaros', 'chaiwat.kantaros@bkg.co.th', '+66-87-777-7777',
  d.id, p.id, l.id, g.id,
  'full_time', 'active', '2020-11-15', 'male'
FROM departments d, positions p, locations l, job_grades g
WHERE d.code = 'DEPT-SALES' AND p.code = 'POS-SALESO' AND l.code = 'OFF-CM' AND g.code = 'G2';

INSERT INTO employees (
  employee_no, first_name, last_name, email, phone,
  department_id, position_id, location_id, job_grade_id,
  employment_type, employment_status, hire_date, gender
)
SELECT
  'EMP-008', 'Anchana', 'Malee', 'anchana.malee@bkg.co.th', '+66-88-888-8888',
  d.id, p.id, l.id, g.id,
  'full_time', 'probation', '2026-04-01', 'female'
FROM departments d, positions p, locations l, job_grades g
WHERE d.code = 'DEPT-ACC' AND p.code = 'POS-ACCO' AND l.code = 'HQ-BKK' AND g.code = 'G2';

-- Seed employment details
INSERT INTO employment_details (employee_id, base_salary, salary_currency, salary_frequency, tax_id, social_security_no, overtime_eligible)
SELECT e.id, 85000, 'THB', 'monthly', 'TAX-001', 'SSF-001', false FROM employees e WHERE e.employee_no = 'EMP-001';
INSERT INTO employment_details (employee_id, base_salary, salary_currency, salary_frequency, tax_id, social_security_no, overtime_eligible)
SELECT e.id, 28000, 'THB', 'monthly', 'TAX-002', 'SSF-002', true FROM employees e WHERE e.employee_no = 'EMP-002';
INSERT INTO employment_details (employee_id, base_salary, salary_currency, salary_frequency, tax_id, social_security_no, overtime_eligible)
SELECT e.id, 90000, 'THB', 'monthly', 'TAX-003', 'SSF-003', false FROM employees e WHERE e.employee_no = 'EMP-003';
INSERT INTO employment_details (employee_id, base_salary, salary_currency, salary_frequency, tax_id, social_security_no, overtime_eligible)
SELECT e.id, 55000, 'THB', 'monthly', 'TAX-004', 'SSF-004', true FROM employees e WHERE e.employee_no = 'EMP-004';
INSERT INTO employment_details (employee_id, base_salary, salary_currency, salary_frequency, tax_id, social_security_no, overtime_eligible)
SELECT e.id, 120000, 'THB', 'monthly', 'TAX-005', 'SSF-005', false FROM employees e WHERE e.employee_no = 'EMP-005';

-- Seed leave balances for current year
INSERT INTO leave_balances (employee_id, leave_type_id, year, entitled_days, used_days)
SELECT e.id, lt.id, 2026, lt.days_per_year, 0
FROM employees e, leave_types lt
WHERE e.employment_status = 'active' AND lt.is_active = true;

-- Seed sample job postings
INSERT INTO job_postings (title, department_id, employment_type, openings, salary_min, salary_max, salary_currency, status, deadline)
SELECT 'Senior HR Specialist', d.id, 'full_time', 1, 50000, 70000, 'THB', 'open', '2026-06-30'
FROM departments d WHERE d.code = 'DEPT-HR';
INSERT INTO job_postings (title, department_id, employment_type, openings, salary_min, salary_max, salary_currency, status, deadline)
SELECT 'Full Stack Developer', d.id, 'full_time', 2, 60000, 90000, 'THB', 'open', '2026-06-15'
FROM departments d WHERE d.code = 'DEPT-DEV';
INSERT INTO job_postings (title, department_id, employment_type, openings, salary_min, salary_max, salary_currency, status, deadline)
SELECT 'Sales Executive', d.id, 'full_time', 3, 25000, 40000, 'THB', 'open', '2026-07-01'
FROM departments d WHERE d.code = 'DEPT-SALES';

-- Seed public holidays 2026
INSERT INTO public_holidays (name, holiday_date) VALUES
  ('New Year''s Day', '2026-01-01'),
  ('Makha Bucha', '2026-02-12'),
  ('Chakri Day', '2026-04-06'),
  ('Songkran Festival Day 1', '2026-04-13'),
  ('Songkran Festival Day 2', '2026-04-14'),
  ('Songkran Festival Day 3', '2026-04-15'),
  ('Labour Day', '2026-05-01'),
  ('Coronation Day', '2026-05-04'),
  ('Visakha Bucha', '2026-05-11'),
  ('Buddhist Lent', '2026-07-28'),
  ('Her Majesty Queen''s Birthday', '2026-08-12'),
  ('His Majesty the King''s Birthday Oct', '2026-10-13'),
  ('Chulalongkorn Day', '2026-10-23'),
  ('His Majesty the King''s Birthday Dec', '2026-12-05'),
  ('Constitution Day', '2026-12-10'),
  ('New Year''s Eve', '2026-12-31');
