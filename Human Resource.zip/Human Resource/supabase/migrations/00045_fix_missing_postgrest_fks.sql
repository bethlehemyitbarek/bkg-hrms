-- Migration: create missing organization tables referenced in the UI
-- branches, job_families, job_titles, career_paths were never created in prior migrations.

-- ── Branches ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS branches (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code        TEXT UNIQUE NOT NULL,
  name        TEXT NOT NULL,
  location_id UUID REFERENCES locations(id) ON DELETE SET NULL,
  manager_id  UUID REFERENCES employees(id) ON DELETE SET NULL,
  address     TEXT,
  is_active   BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── Job Families ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS job_families (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code        TEXT UNIQUE NOT NULL,
  name        TEXT NOT NULL,
  description TEXT,
  is_active   BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── Job Titles ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS job_titles (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code           TEXT,
  title          TEXT NOT NULL,
  job_family_id  UUID REFERENCES job_families(id) ON DELETE SET NULL,
  job_level      TEXT,
  job_grade      TEXT,
  is_active      BOOLEAN NOT NULL DEFAULT true,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── Career Paths ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS career_paths (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name                 TEXT NOT NULL,
  from_position        TEXT,
  to_position          TEXT,
  requirements         TEXT,
  min_years_experience INTEGER,
  is_active            BOOLEAN NOT NULL DEFAULT true,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── RLS (open read access, authenticated write — matches existing pattern) ──
ALTER TABLE branches     ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_families ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_titles   ENABLE ROW LEVEL SECURITY;
ALTER TABLE career_paths ENABLE ROW LEVEL SECURITY;

CREATE POLICY "branches_read"     ON branches     FOR SELECT TO authenticated USING (true);
CREATE POLICY "branches_write"    ON branches     FOR ALL    TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "job_families_read" ON job_families FOR SELECT TO authenticated USING (true);
CREATE POLICY "job_families_write"ON job_families FOR ALL    TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "job_titles_read"   ON job_titles   FOR SELECT TO authenticated USING (true);
CREATE POLICY "job_titles_write"  ON job_titles   FOR ALL    TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "career_paths_read" ON career_paths FOR SELECT TO authenticated USING (true);
CREATE POLICY "career_paths_write"ON career_paths FOR ALL    TO authenticated USING (true) WITH CHECK (true);
