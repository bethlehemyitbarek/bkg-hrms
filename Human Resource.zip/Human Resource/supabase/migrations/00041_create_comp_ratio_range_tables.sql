
CREATE TABLE employee_comp_ratios (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id    uuid REFERENCES employees(id) ON DELETE CASCADE,
  snapshot_date  date NOT NULL DEFAULT CURRENT_DATE,
  salary_band_id uuid REFERENCES salary_bands(id) ON DELETE SET NULL,
  base_salary    numeric(15,2),
  band_midpoint  numeric(15,2),
  comp_ratio     numeric(8,4),
  currency       text NOT NULL DEFAULT 'ETB',
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE employee_range_penetration (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id    uuid REFERENCES employees(id) ON DELETE CASCADE,
  snapshot_date  date NOT NULL DEFAULT CURRENT_DATE,
  salary_band_id uuid REFERENCES salary_bands(id) ON DELETE SET NULL,
  base_salary    numeric(15,2),
  range_min      numeric(15,2),
  range_max      numeric(15,2),
  penetration    numeric(8,4),
  currency       text NOT NULL DEFAULT 'ETB',
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE employee_comp_ratios        ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_range_penetration  ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth_all_emp_comp_ratios" ON employee_comp_ratios        FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_emp_range_pen"   ON employee_range_penetration  FOR ALL TO authenticated USING (true) WITH CHECK (true);
