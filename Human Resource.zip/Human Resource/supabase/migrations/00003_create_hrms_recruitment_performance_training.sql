
-- ============================================================
-- Recruitment
-- ============================================================
CREATE TABLE job_postings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  position_id UUID REFERENCES positions(id),
  department_id UUID REFERENCES departments(id),
  title TEXT NOT NULL,
  description TEXT,
  requirements TEXT,
  benefits TEXT,
  employment_type TEXT DEFAULT 'full_time',
  location_id UUID REFERENCES locations(id),
  openings INTEGER NOT NULL DEFAULT 1,
  salary_min NUMERIC(15,2),
  salary_max NUMERIC(15,2),
  salary_currency TEXT DEFAULT 'THB',
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','open','closed','cancelled','on_hold')),
  published_at TIMESTAMPTZ,
  closed_at TIMESTAMPTZ,
  deadline DATE,
  created_by UUID REFERENCES employees(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE candidates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_posting_id UUID REFERENCES job_postings(id),
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  resume_url TEXT,
  source TEXT DEFAULT 'direct' CHECK (source IN ('direct','referral','agency','job_board','social_media','internal')),
  status TEXT NOT NULL DEFAULT 'applied' CHECK (status IN ('applied','screening','interview','assessment','offer','hired','rejected','withdrawn')),
  current_salary NUMERIC(15,2),
  expected_salary NUMERIC(15,2),
  notice_period_days INTEGER,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE interviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  job_posting_id UUID REFERENCES job_postings(id),
  interview_type TEXT NOT NULL DEFAULT 'hr_screening' CHECK (interview_type IN ('hr_screening','technical','panel','final','assessment')),
  scheduled_at TIMESTAMPTZ NOT NULL,
  location TEXT,
  interviewers UUID[],
  status TEXT NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled','completed','cancelled','no_show')),
  overall_rating INTEGER CHECK (overall_rating BETWEEN 1 AND 5),
  feedback TEXT,
  recommendation TEXT CHECK (recommendation IN ('strong_hire','hire','maybe','no_hire')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================
-- Performance Management
-- ============================================================
CREATE TABLE performance_cycles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  cycle_type TEXT NOT NULL DEFAULT 'annual' CHECK (cycle_type IN ('annual','semi_annual','quarterly','monthly')),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  review_start_date DATE,
  review_end_date DATE,
  status TEXT NOT NULL DEFAULT 'planning' CHECK (status IN ('planning','active','review','completed','cancelled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE performance_goals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  cycle_id UUID REFERENCES performance_cycles(id),
  title TEXT NOT NULL,
  description TEXT,
  kpi TEXT,
  target_value TEXT,
  actual_value TEXT,
  weight NUMERIC(5,2) DEFAULT 0,
  category TEXT DEFAULT 'individual',
  due_date DATE,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('draft','active','completed','cancelled')),
  rating INTEGER CHECK (rating BETWEEN 1 AND 5),
  comments TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE performance_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  reviewer_id UUID REFERENCES employees(id),
  cycle_id UUID REFERENCES performance_cycles(id),
  review_type TEXT NOT NULL DEFAULT 'annual' CHECK (review_type IN ('annual','mid_year','quarterly','probation','360')),
  self_rating NUMERIC(3,1),
  manager_rating NUMERIC(3,1),
  final_rating NUMERIC(3,1),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','self_assessment','manager_review','calibration','completed','acknowledged')),
  self_comments TEXT,
  manager_comments TEXT,
  strengths TEXT,
  improvements TEXT,
  development_plan TEXT,
  submitted_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================
-- Training
-- ============================================================
CREATE TABLE training_programs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT DEFAULT 'technical',
  delivery_method TEXT DEFAULT 'classroom' CHECK (delivery_method IN ('classroom','online','blended','on_the_job','workshop')),
  duration_hours NUMERIC(6,2),
  provider TEXT,
  cost NUMERIC(15,2) DEFAULT 0,
  currency TEXT DEFAULT 'THB',
  max_participants INTEGER,
  is_mandatory BOOLEAN NOT NULL DEFAULT false,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE training_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID NOT NULL REFERENCES training_programs(id),
  session_name TEXT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  start_time TIME,
  end_time TIME,
  location TEXT,
  trainer_name TEXT,
  max_participants INTEGER,
  status TEXT NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','open','full','in_progress','completed','cancelled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE training_enrollments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL REFERENCES training_sessions(id),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  enrollment_date DATE NOT NULL DEFAULT CURRENT_DATE,
  status TEXT NOT NULL DEFAULT 'enrolled' CHECK (status IN ('enrolled','attended','completed','failed','absent','withdrawn')),
  score NUMERIC(5,2),
  completion_date DATE,
  certificate_url TEXT,
  feedback TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(session_id, employee_id)
);

-- ============================================================
-- Benefits & Compensation
-- ============================================================
CREATE TABLE benefit_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  plan_type TEXT NOT NULL CHECK (plan_type IN ('health','dental','vision','life_insurance','provident_fund','retirement','transport','meal','housing','other')),
  coverage_amount NUMERIC(15,2),
  employee_contribution NUMERIC(5,2) DEFAULT 0,
  employer_contribution NUMERIC(5,2) DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE employee_benefits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  benefit_plan_id UUID NOT NULL REFERENCES benefit_plans(id),
  enrollment_date DATE NOT NULL,
  end_date DATE,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','cancelled')),
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(employee_id, benefit_plan_id)
);

-- ============================================================
-- Loans
-- ============================================================
CREATE TABLE loan_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  loan_type TEXT NOT NULL CHECK (loan_type IN ('emergency','personal','education','housing','vehicle','other')),
  amount_requested NUMERIC(15,2) NOT NULL,
  amount_approved NUMERIC(15,2),
  interest_rate NUMERIC(5,2) DEFAULT 0,
  repayment_months INTEGER NOT NULL,
  monthly_installment NUMERIC(15,2),
  purpose TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','disbursed','repaying','completed','defaulted')),
  applied_date DATE NOT NULL DEFAULT CURRENT_DATE,
  approved_by UUID REFERENCES employees(id),
  approved_date DATE,
  disbursed_date DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE loan_repayments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loan_id UUID NOT NULL REFERENCES loan_applications(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id),
  installment_no INTEGER NOT NULL,
  due_date DATE NOT NULL,
  amount NUMERIC(15,2) NOT NULL,
  paid_amount NUMERIC(15,2) DEFAULT 0,
  paid_date DATE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','overdue','partial')),
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
