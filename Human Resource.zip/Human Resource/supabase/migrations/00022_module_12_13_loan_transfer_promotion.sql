
-- ============================================================
-- MODULE 12: LOAN POLICIES, REQUESTS, REPAYMENT SCHEDULES
-- ============================================================

-- 12.1 LoanPolicy
CREATE TABLE loan_policies (
  row_id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loan_policy_id            UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  tenant_id                 UUID NOT NULL,
  policy_name               VARCHAR(200) NOT NULL,
  policy_code               VARCHAR(50) NOT NULL,
  loan_type                 VARCHAR(20) NOT NULL CHECK (loan_type IN ('LOAN','ADVANCE')),
  max_loan_amount           DECIMAL(18,2),
  max_salary_multiplier     DECIMAL(18,2),
  min_service_months        INTEGER NOT NULL DEFAULT 0,
  max_concurrent_loan       INTEGER NOT NULL DEFAULT 1,
  interest_rate             DECIMAL(5,2) NOT NULL DEFAULT 0,
  interest_method           VARCHAR(20) CHECK (interest_method IN ('FLAT_RATE','REDUCING_BALANCE','ZERO')),
  max_repayment_months      INTEGER,
  max_installment_percentage DECIMAL(5,2),
  requires_guarantor        SMALLINT NOT NULL DEFAULT 0,
  requires_collateral       SMALLINT NOT NULL DEFAULT 0,
  effective_from            DATE NOT NULL,
  effective_to              DATE,
  created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by                UUID,
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by                UUID,
  is_active                 SMALLINT NOT NULL DEFAULT 1,
  is_deleted                SMALLINT NOT NULL DEFAULT 0,
  is_current                SMALLINT NOT NULL DEFAULT 0,
  row_start                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                   TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00',
  UNIQUE (tenant_id, policy_code)
);

CREATE INDEX idx_loan_policies_tenant ON loan_policies (tenant_id);
CREATE INDEX idx_loan_policies_type ON loan_policies (tenant_id, loan_type);

ALTER TABLE loan_policies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "loan_policies_all" ON loan_policies FOR ALL USING (true) WITH CHECK (true);

-- 12.2 LoanRequests
CREATE TABLE loan_requests (
  row_id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loan_request_id           UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  tenant_id                 UUID NOT NULL,
  employee_id               UUID NOT NULL,
  loan_policy_id            UUID REFERENCES loan_policies (loan_policy_id),
  request_type              VARCHAR(20) NOT NULL CHECK (request_type IN ('LOAN','ADVANCE')),
  request_amount            DECIMAL(18,2) NOT NULL,
  currency_code             CHAR(3) NOT NULL DEFAULT 'ETB',
  request_date              DATE NOT NULL,
  purpose                   VARCHAR(2000) NOT NULL,
  tenure_months_at_request  INTEGER,
  snapshot_salary_grade     VARCHAR(50),
  existing_loan_count       INTEGER NOT NULL DEFAULT 0,
  is_eligible               SMALLINT,
  ineligibility_reason      VARCHAR(1000),
  interest_rate             DECIMAL(5,2) NOT NULL DEFAULT 0,
  interest_method           VARCHAR(20) CHECK (interest_method IN ('FLAT_RATE','REDUCING_BALANCE','ZERO')),
  repayment_period_months   INTEGER,
  monthly_installment       DECIMAL(18,2),
  disbursement_amount       DECIMAL(18,2),
  disbursement_date         DATE,
  disbursement_reference    VARCHAR(100),
  disbursement_method       VARCHAR(20) CHECK (disbursement_method IN ('BANK_TRANSFER','CASH','CHEQUE')),
  outstanding_balance       DECIMAL(18,2) NOT NULL DEFAULT 0,
  loan_status               VARCHAR(20) NOT NULL DEFAULT 'DRAFT' CHECK (loan_status IN ('DRAFT','SUBMITTED','APPROVED','REJECTED','DISBURSED','REPAYING','SETTLED','CLOSED','DEFAULTED')),
  workflow_instance_id      UUID,
  closure_reason            VARCHAR(100),
  closure_date              DATE,
  created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by                UUID,
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by                UUID,
  is_active                 SMALLINT NOT NULL DEFAULT 1,
  is_deleted                SMALLINT NOT NULL DEFAULT 0,
  is_current                SMALLINT NOT NULL DEFAULT 0,
  effective_from            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to              TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00',
  row_start                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                   TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00'
);

CREATE INDEX idx_loan_requests_tenant_emp ON loan_requests (tenant_id, employee_id);
CREATE INDEX idx_loan_requests_tenant_status ON loan_requests (tenant_id, loan_status);

ALTER TABLE loan_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "loan_requests_all" ON loan_requests FOR ALL USING (true) WITH CHECK (true);

-- 12.3 LoanRepaymentSchedule
CREATE TABLE loan_repayment_schedules (
  row_id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  schedule_id           UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  tenant_id             UUID NOT NULL,
  loan_request_id       UUID NOT NULL REFERENCES loan_requests (loan_request_id),
  installment_number    INTEGER NOT NULL,
  due_date              DATE NOT NULL,
  principal_amount      DECIMAL(18,2) NOT NULL,
  interest_amount       DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_installment     DECIMAL(18,2) NOT NULL,
  payment_status        VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (payment_status IN ('PENDING','PAID','OVERDUE','WAIVED','PARTIAL')),
  paid_amount           DECIMAL(18,2) NOT NULL DEFAULT 0,
  paid_date             DATE,
  payroll_run_id        UUID,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by            UUID,
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by            UUID,
  is_active             SMALLINT NOT NULL DEFAULT 1,
  is_deleted            SMALLINT NOT NULL DEFAULT 0,
  is_current            SMALLINT NOT NULL DEFAULT 0,
  effective_from        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to          TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00',
  row_start             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end               TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00'
);

CREATE INDEX idx_repayment_loan ON loan_repayment_schedules (loan_request_id);
CREATE INDEX idx_repayment_tenant_status ON loan_repayment_schedules (tenant_id, payment_status);

ALTER TABLE loan_repayment_schedules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "loan_repayment_schedules_all" ON loan_repayment_schedules FOR ALL USING (true) WITH CHECK (true);

-- ============================================================
-- MODULE 13: TRANSFER REQUESTS, PROMOTION REQUESTS
-- ============================================================

-- 13.1 TransferRequests
CREATE TABLE transfer_requests (
  row_id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transfer_id             UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  tenant_id               UUID NOT NULL,
  employee_id             UUID NOT NULL,
  transfer_type           VARCHAR(20) NOT NULL CHECK (transfer_type IN ('LATERAL','DEPARTMENTAL','LOCATION','INTER_COMPANY')),
  initiated_by            UUID NOT NULL,
  current_department_id   UUID,
  current_position_id     UUID,
  current_location_id     UUID,
  target_department_id    UUID,
  target_position_id      UUID,
  target_location_id      UUID,
  target_entity_id        UUID,
  reason                  VARCHAR(2000),
  transfer_status         VARCHAR(20) NOT NULL DEFAULT 'DRAFT' CHECK (transfer_status IN ('DRAFT','SUBMITTED','APPROVED','REJECTED','EXECUTED','CANCELLED')),
  workflow_instance_id    UUID,
  initiated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_date          DATE,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by              UUID NOT NULL,
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by              UUID,
  is_active               SMALLINT NOT NULL DEFAULT 1,
  is_deleted              SMALLINT NOT NULL DEFAULT 0,
  is_current              SMALLINT NOT NULL DEFAULT 0,
  effective_from          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to            TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00',
  row_start               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                 TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00'
);

CREATE INDEX idx_transfer_requests_tenant_emp ON transfer_requests (tenant_id, employee_id);
CREATE INDEX idx_transfer_requests_tenant_status ON transfer_requests (tenant_id, transfer_status);

ALTER TABLE transfer_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "transfer_requests_all" ON transfer_requests FOR ALL USING (true) WITH CHECK (true);

-- 13.2 PromotionRequests
CREATE TABLE promotion_requests (
  row_id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  promotion_id              UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  tenant_id                 UUID NOT NULL,
  employee_id               UUID NOT NULL,
  current_position_id       UUID,
  snapshot_current_grade    VARCHAR(50),
  current_salary            DECIMAL(18,2),
  proposed_position_id      UUID NOT NULL,
  snapshot_proposed_grade   VARCHAR(50),
  proposed_salary           DECIMAL(18,2),
  justification             VARCHAR(4000),
  promotion_status          VARCHAR(20) NOT NULL DEFAULT 'DRAFT' CHECK (promotion_status IN ('DRAFT','SUBMITTED','APPROVED','REJECTED','EXECUTED','CANCELLED')),
  workflow_instance_id      UUID,
  initiated_by              UUID NOT NULL,
  initiated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  promotion_date            DATE,
  created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by                UUID NOT NULL,
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by                UUID,
  is_active                 SMALLINT NOT NULL DEFAULT 1,
  is_deleted                SMALLINT NOT NULL DEFAULT 0,
  is_current                SMALLINT NOT NULL DEFAULT 0,
  effective_from            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to              TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00',
  row_start                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                   TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00'
);

CREATE INDEX idx_promotion_requests_tenant_emp ON promotion_requests (tenant_id, employee_id);
CREATE INDEX idx_promotion_requests_tenant_status ON promotion_requests (tenant_id, promotion_status);

ALTER TABLE promotion_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "promotion_requests_all" ON promotion_requests FOR ALL USING (true) WITH CHECK (true);
