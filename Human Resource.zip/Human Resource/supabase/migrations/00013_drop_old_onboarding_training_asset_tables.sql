
-- Drop old prototype tables in FK-safe order
DROP TABLE IF EXISTS onboarding_task_completions CASCADE;
DROP TABLE IF EXISTS training_enrollments CASCADE;
DROP TABLE IF EXISTS training_sessions CASCADE;
DROP TABLE IF EXISTS training_programs CASCADE;
DROP TABLE IF EXISTS onboarding_tasks CASCADE;
DROP TABLE IF EXISTS employee_onboarding CASCADE;
DROP TABLE IF EXISTS onboarding_checklists CASCADE;
DROP TABLE IF EXISTS assets CASCADE;
