
-- ─────────────────────────────────────────────────────────────────────────────
-- 8.1 OnboardingTemplate
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE onboarding_templates (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  onboarding_template_id   UUID NOT NULL DEFAULT gen_random_uuid(),
  template_name            VARCHAR(200) NOT NULL,
  role_code                VARCHAR(50),
  department_id            UUID REFERENCES departments(id),
  version_number           INTEGER NOT NULL DEFAULT 1,
  template_status          VARCHAR(20) NOT NULL DEFAULT 'DRAFT'
                             CHECK (template_status IN ('DRAFT','ACTIVE','ARCHIVED')),
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_onboarding_template_id UNIQUE (onboarding_template_id)
);
CREATE INDEX idx_ob_templates_status ON onboarding_templates (template_status) WHERE is_deleted = 0;

-- ─────────────────────────────────────────────────────────────────────────────
-- 8.2 OnboardingTaskTemplate
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE onboarding_task_templates (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_template_id         UUID NOT NULL DEFAULT gen_random_uuid(),
  onboarding_template_id   UUID NOT NULL REFERENCES onboarding_templates(onboarding_template_id),
  task_name                VARCHAR(200) NOT NULL,
  assigned_role            VARCHAR(50) NOT NULL,
  default_sla_days         INTEGER NOT NULL DEFAULT 3,
  is_mandatory             SMALLINT NOT NULL DEFAULT 1,
  sequence_order           INTEGER NOT NULL,
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_task_template_id UNIQUE (task_template_id)
);
CREATE UNIQUE INDEX uq_ob_task_tmpl_order
  ON onboarding_task_templates (onboarding_template_id, sequence_order)
  WHERE is_deleted = 0;

-- ─────────────────────────────────────────────────────────────────────────────
-- 8.3 OnboardingProcess
-- ─────────────────────────────────────────────────────────────────────────────
CREATE SEQUENCE onboarding_process_seq START 1;

CREATE TABLE onboarding_processes (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  onboarding_process_id    UUID NOT NULL DEFAULT gen_random_uuid(),
  process_number           VARCHAR(30) NOT NULL DEFAULT 'OBP-0001',
  candidate_id             UUID REFERENCES candidates(candidate_id),
  offer_id                 UUID REFERENCES offers(offer_id),
  template_id              UUID REFERENCES onboarding_templates(onboarding_template_id),
  employee_id              UUID REFERENCES employees(id),
  proposed_start_date      DATE,
  actual_start_date        DATE,
  expected_completion_date DATE,
  actual_completion_date   DATE,
  process_status           VARCHAR(20) NOT NULL DEFAULT 'INITIATED'
                             CHECK (process_status IN ('INITIATED','IN_PROGRESS','COMPLETED','CANCELLED')),
  conversion_status        VARCHAR(20) NOT NULL DEFAULT 'NOT_STARTED'
                             CHECK (conversion_status IN ('NOT_STARTED','PENDING_APPROVAL','APPROVED','CONVERTED','REJECTED')),
  probation_end_date       DATE,
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_onboarding_process_id UNIQUE (onboarding_process_id),
  CONSTRAINT uq_process_number UNIQUE (process_number)
);
CREATE INDEX idx_ob_process_status   ON onboarding_processes (process_status)  WHERE is_deleted = 0;
CREATE INDEX idx_ob_process_offer    ON onboarding_processes (offer_id)        WHERE is_deleted = 0;
CREATE INDEX idx_ob_process_employee ON onboarding_processes (employee_id)     WHERE is_deleted = 0;

CREATE OR REPLACE FUNCTION generate_onboarding_process_number()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.process_number := 'OBP-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(NEXTVAL('onboarding_process_seq')::TEXT, 5, '0');
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_ob_process_number
  BEFORE INSERT ON onboarding_processes
  FOR EACH ROW EXECUTE FUNCTION generate_onboarding_process_number();

-- ─────────────────────────────────────────────────────────────────────────────
-- 8.4 OnboardingTask
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE onboarding_tasks (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  onboarding_task_id       UUID NOT NULL DEFAULT gen_random_uuid(),
  onboarding_process_id    UUID NOT NULL REFERENCES onboarding_processes(onboarding_process_id),
  task_template_id         UUID REFERENCES onboarding_task_templates(task_template_id),
  task_name                VARCHAR(200) NOT NULL,
  task_type                VARCHAR(30)
                             CHECK (task_type IN ('DOCUMENT','TRAINING','POLICY','EQUIPMENT','IT_ACCESS','MEDICAL','COMPLIANCE','OTHER')),
  assigned_to_id           UUID REFERENCES employees(id),
  assigned_role            VARCHAR(50),
  assigned_at              TIMESTAMPTZ,
  due_date                 DATE,
  completed_at             TIMESTAMPTZ,
  sla_hours                INTEGER,
  sla_status               VARCHAR(20) DEFAULT 'WITHIN_SLA'
                             CHECK (sla_status IN ('WITHIN_SLA','BREACHED','ESCALATED')),
  escalation_level         INTEGER DEFAULT 0,
  last_escalated_at        TIMESTAMPTZ,
  task_status              VARCHAR(20) NOT NULL DEFAULT 'PENDING'
                             CHECK (task_status IN ('PENDING','IN_PROGRESS','COMPLETED','CANCELLED')),
  priority                 VARCHAR(10) DEFAULT 'MEDIUM'
                             CHECK (priority IN ('LOW','MEDIUM','HIGH','CRITICAL')),
  notes                    VARCHAR(2000),
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_onboarding_task_id UNIQUE (onboarding_task_id)
);
CREATE INDEX idx_ob_task_process_status ON onboarding_tasks (onboarding_process_id, task_status) WHERE is_deleted = 0;
CREATE INDEX idx_ob_task_assignee_due   ON onboarding_tasks (assigned_to_id, due_date)           WHERE is_deleted = 0;

-- ─────────────────────────────────────────────────────────────────────────────
-- 8.5 ContractSignature
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE contract_signatures (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_signature_id    UUID NOT NULL DEFAULT gen_random_uuid(),
  onboarding_process_id    UUID NOT NULL REFERENCES onboarding_processes(onboarding_process_id),
  offer_id                 UUID REFERENCES offers(offer_id),
  signed_by_name           VARCHAR(200) NOT NULL,
  signed_at                TIMESTAMPTZ,
  device_fingerprint       JSONB,
  document_hash            VARCHAR(255),
  signature_status         VARCHAR(20) NOT NULL DEFAULT 'PENDING'
                             CHECK (signature_status IN ('PENDING','SIGNED','REVOKED','FAILED')),
  effective_from           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to             TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_contract_signature_id UNIQUE (contract_signature_id)
);
CREATE INDEX idx_contract_sig_process ON contract_signatures (onboarding_process_id, signature_status) WHERE is_deleted = 0;

-- ─────────────────────────────────────────────────────────────────────────────
-- 8.7 Asset  (before 8.6 so EquipmentProvisioning can FK to it)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE assets (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id                 UUID NOT NULL DEFAULT gen_random_uuid(),
  asset_tag                VARCHAR(50) NOT NULL,
  asset_name               VARCHAR(200) NOT NULL,
  asset_category           VARCHAR(20) NOT NULL
                             CHECK (asset_category IN ('LAPTOP','DESKTOP','PHONE','CARD','LICENSE','VEHICLE','OTHER')),
  serial_number            VARCHAR(100),
  purchase_date            DATE,
  asset_status             VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE'
                             CHECK (asset_status IN ('AVAILABLE','ASSIGNED','MAINTENANCE','RETIRED')),
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_asset_id  UNIQUE (asset_id),
  CONSTRAINT uq_asset_tag UNIQUE (asset_tag)
);
CREATE INDEX idx_asset_category_status ON assets (asset_category, asset_status) WHERE is_deleted = 0;

-- ─────────────────────────────────────────────────────────────────────────────
-- 8.6 EquipmentProvisioning
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE equipment_provisionings (
  id                         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  equipment_provisioning_id  UUID NOT NULL DEFAULT gen_random_uuid(),
  onboarding_process_id      UUID NOT NULL REFERENCES onboarding_processes(onboarding_process_id),
  asset_category_requested   VARCHAR(100) NOT NULL,
  provisioning_status        VARCHAR(20) NOT NULL DEFAULT 'REQUESTED'
                               CHECK (provisioning_status IN ('REQUESTED','APPROVED','REJECTED','FULFILLED','CANCELLED')),
  fulfilled_asset_id         UUID REFERENCES assets(asset_id),
  is_active                  SMALLINT NOT NULL DEFAULT 1,
  is_deleted                 SMALLINT NOT NULL DEFAULT 0,
  created_at                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_equipment_provisioning_id UNIQUE (equipment_provisioning_id)
);
CREATE INDEX idx_equip_prov_process ON equipment_provisionings (onboarding_process_id, provisioning_status) WHERE is_deleted = 0;

-- ─────────────────────────────────────────────────────────────────────────────
-- 8.8 AssetAssignment
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE asset_assignments (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_assignment_id      UUID NOT NULL DEFAULT gen_random_uuid(),
  asset_id                 UUID NOT NULL REFERENCES assets(asset_id),
  employee_id              UUID NOT NULL REFERENCES employees(id),
  assigned_date            DATE NOT NULL,
  returned_date            DATE,
  assignment_status        VARCHAR(20) NOT NULL DEFAULT 'ASSIGNED'
                             CHECK (assignment_status IN ('ASSIGNED','RETURNED','LOST','DAMAGED')),
  condition_notes          VARCHAR(1000),
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_asset_assignment_id UNIQUE (asset_assignment_id)
);
CREATE INDEX idx_asset_assign_asset    ON asset_assignments (asset_id, assignment_status) WHERE is_deleted = 0;
CREATE INDEX idx_asset_assign_employee ON asset_assignments (employee_id)                 WHERE is_deleted = 0;

-- ─────────────────────────────────────────────────────────────────────────────
-- 8.9 ProbationPeriod
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE probation_periods (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  probation_period_id      UUID NOT NULL DEFAULT gen_random_uuid(),
  employee_id              UUID NOT NULL REFERENCES employees(id),
  onboarding_process_id    UUID REFERENCES onboarding_processes(onboarding_process_id),
  start_date               DATE NOT NULL,
  end_date                 DATE NOT NULL,
  probation_status         VARCHAR(20) NOT NULL DEFAULT 'ONGOING'
                             CHECK (probation_status IN ('ONGOING','CONFIRMED','EXTENDED','TERMINATED')),
  effective_from           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to             TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_probation_period_id UNIQUE (probation_period_id)
);
CREATE INDEX idx_probation_status_end ON probation_periods (probation_status, end_date) WHERE is_deleted = 0;
CREATE INDEX idx_probation_employee   ON probation_periods (employee_id)                WHERE is_deleted = 0;

-- ─────────────────────────────────────────────────────────────────────────────
-- 8.10 ProbationEvaluation
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE probation_evaluations (
  id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  probation_evaluation_id   UUID NOT NULL DEFAULT gen_random_uuid(),
  probation_period_id       UUID NOT NULL REFERENCES probation_periods(probation_period_id),
  evaluator_id              UUID NOT NULL REFERENCES employees(id),
  evaluation_score          DECIMAL(5,2),
  recommendation            VARCHAR(20) NOT NULL
                              CHECK (recommendation IN ('CONFIRM','EXTEND','TERMINATE')),
  comments                  VARCHAR(4000),
  evaluation_date           DATE NOT NULL,
  is_active                 SMALLINT NOT NULL DEFAULT 1,
  is_deleted                SMALLINT NOT NULL DEFAULT 0,
  created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_probation_evaluation_id UNIQUE (probation_evaluation_id)
);
CREATE INDEX idx_prob_eval_period ON probation_evaluations (probation_period_id) WHERE is_deleted = 0;

-- ─────────────────────────────────────────────────────────────────────────────
-- 9.1 TrainingRequest
-- ─────────────────────────────────────────────────────────────────────────────
CREATE SEQUENCE training_request_seq START 1;

CREATE TABLE training_requests (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  training_request_id      UUID NOT NULL DEFAULT gen_random_uuid(),
  request_number           VARCHAR(30) NOT NULL DEFAULT 'TRQ-0001',
  department_id            UUID REFERENCES departments(id),
  requested_by_id          UUID REFERENCES employees(id),
  training_topic           VARCHAR(200) NOT NULL,
  business_justification   VARCHAR(4000),
  estimated_budget         DECIMAL(18,2),
  priority_level           VARCHAR(10)
                             CHECK (priority_level IN ('LOW','MEDIUM','HIGH','STRATEGIC')),
  request_status           VARCHAR(20) NOT NULL DEFAULT 'SUBMITTED'
                             CHECK (request_status IN ('SUBMITTED','UNDER_REVIEW','APPROVED','REJECTED','CANCELLED')),
  requested_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_training_request_id UNIQUE (training_request_id),
  CONSTRAINT uq_training_request_number UNIQUE (request_number)
);
CREATE INDEX idx_training_req_dept_status ON training_requests (department_id, request_status) WHERE is_deleted = 0;

CREATE OR REPLACE FUNCTION generate_training_request_number()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.request_number := 'TRQ-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(NEXTVAL('training_request_seq')::TEXT, 5, '0');
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_training_request_number
  BEFORE INSERT ON training_requests
  FOR EACH ROW EXECUTE FUNCTION generate_training_request_number();

-- ─────────────────────────────────────────────────────────────────────────────
-- 9.2 Trainer
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE trainers (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trainer_id               UUID NOT NULL DEFAULT gen_random_uuid(),
  trainer_name             VARCHAR(200) NOT NULL,
  trainer_type             VARCHAR(20) NOT NULL
                             CHECK (trainer_type IN ('INTERNAL','EXTERNAL')),
  employee_id              UUID REFERENCES employees(id),
  email                    VARCHAR(255),
  phone_number             VARCHAR(50),
  organization             VARCHAR(200),
  expertise_area           VARCHAR(500),
  average_rating           DECIMAL(5,2),
  trainer_status           VARCHAR(20) NOT NULL DEFAULT 'ACTIVE'
                             CHECK (trainer_status IN ('ACTIVE','INACTIVE','BLACKLISTED')),
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_trainer_id UNIQUE (trainer_id)
);
CREATE INDEX idx_trainer_type_status ON trainers (trainer_type, trainer_status) WHERE is_deleted = 0;

-- Enable Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE onboarding_tasks;
ALTER PUBLICATION supabase_realtime ADD TABLE onboarding_processes;
