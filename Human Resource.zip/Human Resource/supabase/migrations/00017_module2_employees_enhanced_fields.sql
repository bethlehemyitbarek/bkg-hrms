
-- 2.1 Add new columns to employees table
ALTER TABLE employees
  ADD COLUMN IF NOT EXISTS employee_id                    UUID DEFAULT gen_random_uuid(),
  ADD COLUMN IF NOT EXISTS profile_status                 VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
  ADD COLUMN IF NOT EXISTS mother_name                    VARCHAR(100),
  ADD COLUMN IF NOT EXISTS citizenship_status             VARCHAR(20),
  ADD COLUMN IF NOT EXISTS tin_number_encrypted           VARCHAR(512),
  ADD COLUMN IF NOT EXISTS kebele_id                      VARCHAR(200),
  ADD COLUMN IF NOT EXISTS blood_group                    VARCHAR(5),
  ADD COLUMN IF NOT EXISTS disability_status              VARCHAR(10) DEFAULT 'NONE',
  ADD COLUMN IF NOT EXISTS religion_id                    UUID,
  ADD COLUMN IF NOT EXISTS ethnicity_id                   UUID,
  ADD COLUMN IF NOT EXISTS medical_certificate_status     VARCHAR(20),
  ADD COLUMN IF NOT EXISTS mother_tongue                  VARCHAR(200),
  ADD COLUMN IF NOT EXISTS secondary_languages            JSONB,
  ADD COLUMN IF NOT EXISTS employee_photo                 VARCHAR(500),
  ADD COLUMN IF NOT EXISTS retirement_age                 INTEGER,
  ADD COLUMN IF NOT EXISTS planned_retirement_date        DATE,
  ADD COLUMN IF NOT EXISTS retirement_eligibility_flag    VARCHAR(10),
  ADD COLUMN IF NOT EXISTS grade_id                       UUID,
  ADD COLUMN IF NOT EXISTS job_title_id                   UUID,
  ADD COLUMN IF NOT EXISTS place_of_birth                 VARCHAR(200),
  ADD COLUMN IF NOT EXISTS region                         VARCHAR(100),
  ADD COLUMN IF NOT EXISTS sub_city                       VARCHAR(100),
  ADD COLUMN IF NOT EXISTS woreda                         VARCHAR(100),
  ADD COLUMN IF NOT EXISTS street_name                    VARCHAR(100),
  ADD COLUMN IF NOT EXISTS house_number                   VARCHAR(20),
  ADD COLUMN IF NOT EXISTS po_box                         VARCHAR(100),
  ADD COLUMN IF NOT EXISTS title_id                       UUID,
  ADD COLUMN IF NOT EXISTS is_current                     SMALLINT NOT NULL DEFAULT 1;

-- Backfill employee_id for existing rows
UPDATE employees SET employee_id = gen_random_uuid() WHERE employee_id IS NULL;

-- 2.3 Enhance employment_details with spec fields
ALTER TABLE employment_details
  ADD COLUMN IF NOT EXISTS employment_number      VARCHAR(50),
  ADD COLUMN IF NOT EXISTS worker_type            VARCHAR(20) DEFAULT 'EMPLOYEE',
  ADD COLUMN IF NOT EXISTS employment_type_v2     VARCHAR(20),
  ADD COLUMN IF NOT EXISTS contract_type          VARCHAR(20),
  ADD COLUMN IF NOT EXISTS hire_reason            VARCHAR(500),
  ADD COLUMN IF NOT EXISTS termination_reason     VARCHAR(500),
  ADD COLUMN IF NOT EXISTS original_hire_date     DATE,
  ADD COLUMN IF NOT EXISTS employment_start_date  DATE,
  ADD COLUMN IF NOT EXISTS employment_end_date    DATE,
  ADD COLUMN IF NOT EXISTS notice_period_days     INTEGER DEFAULT 60,
  ADD COLUMN IF NOT EXISTS is_primary             SMALLINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS employment_status_v2   VARCHAR(20),
  ADD COLUMN IF NOT EXISTS is_rehire_eligible     SMALLINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS salary_amount          DECIMAL(18,2),
  ADD COLUMN IF NOT EXISTS salary_grade           VARCHAR(50),
  ADD COLUMN IF NOT EXISTS effective_from         TIMESTAMPTZ DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS effective_to           TIMESTAMPTZ DEFAULT '9999-12-31 23:59:59.999999',
  ADD COLUMN IF NOT EXISTS is_current             SMALLINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS is_deleted             SMALLINT NOT NULL DEFAULT 0;

-- 2.9 Enhance employee_contracts with spec fields
ALTER TABLE employee_contracts
  ADD COLUMN IF NOT EXISTS contract_id            UUID DEFAULT gen_random_uuid(),
  ADD COLUMN IF NOT EXISTS contract_number        VARCHAR(50),
  ADD COLUMN IF NOT EXISTS contract_date          DATE,
  ADD COLUMN IF NOT EXISTS job_type               VARCHAR(100),
  ADD COLUMN IF NOT EXISTS work_place             VARCHAR(150),
  ADD COLUMN IF NOT EXISTS salary_amount          DECIMAL(18,2),
  ADD COLUMN IF NOT EXISTS salary_currency        CHAR(3) DEFAULT 'ETB',
  ADD COLUMN IF NOT EXISTS renewal_date           DATE,
  ADD COLUMN IF NOT EXISTS guarantor_name         VARCHAR(200),
  ADD COLUMN IF NOT EXISTS guarantor_phone        VARCHAR(50),
  ADD COLUMN IF NOT EXISTS guarantor_address      TEXT,
  ADD COLUMN IF NOT EXISTS emergency_contact_name VARCHAR(150),
  ADD COLUMN IF NOT EXISTS employee_signature     VARCHAR(255),
  ADD COLUMN IF NOT EXISTS contract_status        VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
  ADD COLUMN IF NOT EXISTS is_active              SMALLINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS is_deleted             SMALLINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS is_current             SMALLINT NOT NULL DEFAULT 1;
