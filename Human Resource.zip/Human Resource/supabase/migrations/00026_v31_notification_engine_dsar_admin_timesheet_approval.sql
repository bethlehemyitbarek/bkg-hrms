
-- ── v31: Notification Engine + DSAR Admin Workflow + Timesheet Lock ────────

-- 1. Extend notifications table with new types and entity tracking
ALTER TABLE notifications
  ADD COLUMN IF NOT EXISTS entity_type  TEXT,
  ADD COLUMN IF NOT EXISTS entity_id    UUID;

-- Widen notification_type constraint to support new engine types
ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_notification_type_check;
ALTER TABLE notifications ADD CONSTRAINT notifications_notification_type_check
  CHECK (notification_type IN (
    'info','warning','success','error','reminder','approval','alert',
    'POLICY_PUBLISHED','ANNOUNCEMENT_PUBLISHED',
    'TIMESHEET_APPROVED','TIMESHEET_REJECTED',
    'DSAR_STATUS_UPDATED'
  ));

CREATE INDEX IF NOT EXISTS idx_notifications_recipient_unread
  ON notifications (recipient_id, is_read, created_at DESC);

-- 2. DSAR: add response_notes column, fix status constraint to include IN_REVIEW & REJECTED
ALTER TABLE data_subject_access_requests
  ADD COLUMN IF NOT EXISTS response_notes TEXT;

-- Widen status constraint
ALTER TABLE data_subject_access_requests
  DROP CONSTRAINT IF EXISTS data_subject_access_requests_request_status_check;
ALTER TABLE data_subject_access_requests
  ADD CONSTRAINT data_subject_access_requests_request_status_check
  CHECK (request_status IN ('SUBMITTED','IN_REVIEW','COMPLETED','REJECTED','OVERDUE'));

-- 3. Timesheets: add is_locked + locked_at for approved timesheet locking
ALTER TABLE timesheets
  ADD COLUMN IF NOT EXISTS is_locked  SMALLINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS locked_at  TIMESTAMPTZ;
