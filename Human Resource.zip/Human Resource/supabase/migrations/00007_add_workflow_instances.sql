
-- Workflow instances table
CREATE TABLE workflow_instances (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_type text NOT NULL,
  reference_id  uuid,
  initiated_by_id uuid REFERENCES employees(id) ON DELETE SET NULL,
  current_step  text,
  status        text NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','in_progress','approved','rejected','completed','cancelled')),
  metadata      jsonb,
  started_at    timestamptz DEFAULT now(),
  completed_at  timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE workflow_instances ENABLE ROW LEVEL SECURITY;

CREATE POLICY "workflow_instances_select" ON workflow_instances
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "workflow_instances_insert" ON workflow_instances
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "workflow_instances_update" ON workflow_instances
  FOR UPDATE TO authenticated USING (true);
