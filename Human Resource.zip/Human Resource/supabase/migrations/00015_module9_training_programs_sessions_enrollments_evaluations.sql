
-- ─────────────────────────────────────────────────────────────────────────────
-- 9.3 TrainingProgram
-- ─────────────────────────────────────────────────────────────────────────────
CREATE SEQUENCE training_program_seq START 1;

CREATE TABLE training_programs (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  training_program_id      UUID NOT NULL DEFAULT gen_random_uuid(),
  program_number           VARCHAR(30) NOT NULL DEFAULT 'PRG-0001',
  program_name             VARCHAR(200) NOT NULL,
  program_type             VARCHAR(30) NOT NULL DEFAULT 'TECHNICAL'
                             CHECK (program_type IN ('TECHNICAL','SOFT_SKILLS','COMPLIANCE','LEADERSHIP','ONBOARDING','OTHER')),
  delivery_mode            VARCHAR(20) NOT NULL DEFAULT 'CLASSROOM'
                             CHECK (delivery_mode IN ('CLASSROOM','ONLINE','BLENDED','ON_THE_JOB')),
  duration_hours           DECIMAL(6,2),
  max_participants         INT,
  program_status           VARCHAR(20) NOT NULL DEFAULT 'DRAFT'
                             CHECK (program_status IN ('DRAFT','ACTIVE','ARCHIVED')),
  description              VARCHAR(4000),
  learning_objectives      VARCHAR(4000),
  prerequisites            VARCHAR(2000),
  cost_per_participant     DECIMAL(18,2),
  currency_code            VARCHAR(10) NOT NULL DEFAULT 'USD',
  department_id            UUID REFERENCES departments(id),
  training_request_id      UUID REFERENCES training_requests(training_request_id),
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_training_program_id     UNIQUE (training_program_id),
  CONSTRAINT uq_training_program_number UNIQUE (program_number)
);
CREATE INDEX idx_training_prog_status ON training_programs (program_status) WHERE is_deleted = 0;
CREATE INDEX idx_training_prog_dept   ON training_programs (department_id)  WHERE is_deleted = 0;

CREATE OR REPLACE FUNCTION generate_training_program_number()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.program_number := 'PRG-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(NEXTVAL('training_program_seq')::TEXT, 5, '0');
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_training_program_number
  BEFORE INSERT ON training_programs
  FOR EACH ROW EXECUTE FUNCTION generate_training_program_number();

-- ─────────────────────────────────────────────────────────────────────────────
-- 9.4 TrainingSession
-- ─────────────────────────────────────────────────────────────────────────────
CREATE SEQUENCE training_session_seq START 1;

CREATE TABLE training_sessions (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  training_session_id      UUID NOT NULL DEFAULT gen_random_uuid(),
  session_number           VARCHAR(30) NOT NULL DEFAULT 'SES-0001',
  training_program_id      UUID NOT NULL REFERENCES training_programs(training_program_id),
  trainer_id               UUID REFERENCES trainers(trainer_id),
  session_title            VARCHAR(200) NOT NULL,
  start_datetime           TIMESTAMPTZ NOT NULL,
  end_datetime             TIMESTAMPTZ NOT NULL,
  location                 VARCHAR(300),
  online_meeting_url       VARCHAR(500),
  max_participants         INT,
  registered_count         INT NOT NULL DEFAULT 0,
  session_status           VARCHAR(20) NOT NULL DEFAULT 'SCHEDULED'
                             CHECK (session_status IN ('SCHEDULED','IN_PROGRESS','COMPLETED','CANCELLED','POSTPONED')),
  notes                    VARCHAR(4000),
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_training_session_id     UNIQUE (training_session_id),
  CONSTRAINT uq_training_session_number UNIQUE (session_number),
  CONSTRAINT chk_session_dates          CHECK (end_datetime > start_datetime)
);
CREATE INDEX idx_training_ses_program ON training_sessions (training_program_id)         WHERE is_deleted = 0;
CREATE INDEX idx_training_ses_trainer ON training_sessions (trainer_id)                  WHERE is_deleted = 0;
CREATE INDEX idx_training_ses_status  ON training_sessions (session_status, start_datetime) WHERE is_deleted = 0;

CREATE OR REPLACE FUNCTION generate_training_session_number()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.session_number := 'SES-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(NEXTVAL('training_session_seq')::TEXT, 5, '0');
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_training_session_number
  BEFORE INSERT ON training_sessions
  FOR EACH ROW EXECUTE FUNCTION generate_training_session_number();

-- ─────────────────────────────────────────────────────────────────────────────
-- 9.5 TrainingEnrollment
-- ─────────────────────────────────────────────────────────────────────────────
CREATE SEQUENCE training_enrollment_seq START 1;

CREATE TABLE training_enrollments (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  training_enrollment_id   UUID NOT NULL DEFAULT gen_random_uuid(),
  enrollment_number        VARCHAR(30) NOT NULL DEFAULT 'ENR-0001',
  training_session_id      UUID NOT NULL REFERENCES training_sessions(training_session_id),
  employee_id              UUID NOT NULL REFERENCES employees(id),
  enrollment_status        VARCHAR(20) NOT NULL DEFAULT 'ENROLLED'
                             CHECK (enrollment_status IN ('ENROLLED','CONFIRMED','ATTENDED','ABSENT','WITHDRAWN','WAITLISTED')),
  enrolled_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  confirmed_at             TIMESTAMPTZ,
  attended_at              TIMESTAMPTZ,
  withdrawal_reason        VARCHAR(1000),
  notes                    VARCHAR(2000),
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_training_enrollment_id     UNIQUE (training_enrollment_id),
  CONSTRAINT uq_training_enrollment_number UNIQUE (enrollment_number),
  CONSTRAINT uq_session_employee           UNIQUE (training_session_id, employee_id)
);
CREATE INDEX idx_training_enr_session  ON training_enrollments (training_session_id)   WHERE is_deleted = 0;
CREATE INDEX idx_training_enr_employee ON training_enrollments (employee_id)           WHERE is_deleted = 0;
CREATE INDEX idx_training_enr_status   ON training_enrollments (enrollment_status)     WHERE is_deleted = 0;

CREATE OR REPLACE FUNCTION generate_training_enrollment_number()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.enrollment_number := 'ENR-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(NEXTVAL('training_enrollment_seq')::TEXT, 5, '0');
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_training_enrollment_number
  BEFORE INSERT ON training_enrollments
  FOR EACH ROW EXECUTE FUNCTION generate_training_enrollment_number();

-- ─────────────────────────────────────────────────────────────────────────────
-- 9.6 TrainingEvaluation
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE training_evaluations (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  training_evaluation_id   UUID NOT NULL DEFAULT gen_random_uuid(),
  training_enrollment_id   UUID NOT NULL REFERENCES training_enrollments(training_enrollment_id),
  training_session_id      UUID NOT NULL REFERENCES training_sessions(training_session_id),
  employee_id              UUID NOT NULL REFERENCES employees(id),
  overall_rating           DECIMAL(3,1) CHECK (overall_rating BETWEEN 1 AND 5),
  content_rating           DECIMAL(3,1) CHECK (content_rating BETWEEN 1 AND 5),
  trainer_rating           DECIMAL(3,1) CHECK (trainer_rating BETWEEN 1 AND 5),
  logistics_rating         DECIMAL(3,1) CHECK (logistics_rating BETWEEN 1 AND 5),
  assessment_score         DECIMAL(5,2),
  assessment_passed        SMALLINT DEFAULT 0,
  strengths                VARCHAR(2000),
  areas_for_improvement    VARCHAR(2000),
  comments                 VARCHAR(4000),
  evaluation_date          DATE NOT NULL DEFAULT CURRENT_DATE,
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_training_evaluation_id UNIQUE (training_evaluation_id),
  CONSTRAINT uq_enrollment_evaluation  UNIQUE (training_enrollment_id)
);
CREATE INDEX idx_training_eval_session  ON training_evaluations (training_session_id) WHERE is_deleted = 0;
CREATE INDEX idx_training_eval_employee ON training_evaluations (employee_id)         WHERE is_deleted = 0;

-- Enable Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE training_programs;
ALTER PUBLICATION supabase_realtime ADD TABLE training_sessions;
ALTER PUBLICATION supabase_realtime ADD TABLE training_enrollments;
ALTER PUBLICATION supabase_realtime ADD TABLE training_evaluations;
