-- Enable pg_cron extension (idempotent via schema check)
CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA cron;

-- Grant cron usage to postgres role
GRANT USAGE ON SCHEMA cron TO postgres;

-- Schedule DSAR deadline reminder daily at 08:00 UTC
-- Calls the deployed edge function via pg_net HTTP POST
SELECT cron.schedule(
  'dsar-deadline-reminder-daily',   -- job name (unique)
  '0 8 * * *',                      -- every day at 08:00 UTC
  $$
  SELECT net.http_post(
    url    := (SELECT 'https://' || current_setting('app.supabase_ref', true) || '.supabase.co/functions/v1/dsar-deadline-reminder'),
    headers := jsonb_build_object(
      'Content-Type',  'application/json',
      'Authorization', 'Bearer ' || current_setting('app.service_role_key', true)
    ),
    body   := '{}'::jsonb
  );
  $$
);