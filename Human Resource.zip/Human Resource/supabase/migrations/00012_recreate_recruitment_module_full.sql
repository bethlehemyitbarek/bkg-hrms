
-- Drop old minimal tables (no dependencies yet)
DROP TABLE IF EXISTS interviews CASCADE;
DROP TABLE IF EXISTS candidates CASCADE;

-- ── 7.1 recruitment_requests ──────────────────────────────────────────────────
CREATE TABLE recruitment_requests (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recruitment_request_id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  request_number        VARCHAR(30) NOT NULL DEFAULT '',
  position_id           UUID,
  department_id         UUID REFERENCES departments(id),
  employee_type         VARCHAR(20) NOT NULL CHECK (employee_type IN ('PERMANENT','CONTRACT','INTERNSHIP','TEMPORARY')),
  gender_preference     VARCHAR(10) CHECK (gender_preference IN ('MALE','FEMALE')),
  requested_headcount   INTEGER NOT NULL DEFAULT 1,
  approved_headcount    INTEGER,
  priority_level        VARCHAR(10) CHECK (priority_level IN ('LOW','MEDIUM','HIGH','CRITICAL')),
  work_location         VARCHAR(200),
  justification         TEXT,
  budget_estimated      DECIMAL(15,2),
  is_budget_validated   BOOLEAN NOT NULL DEFAULT FALSE,
  requested_by_id       UUID,
  submitted_at          TIMESTAMPTZ,
  expiry_date           DATE,
  request_status        VARCHAR(20) NOT NULL CHECK (request_status IN ('DRAFT','PENDING_APPROVAL','APPROVED','REJECTED','EXPIRED','ARCHIVED')) DEFAULT 'DRAFT',
  is_active             BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted            BOOLEAN NOT NULL DEFAULT FALSE,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE SEQUENCE IF NOT EXISTS rr_seq START 1;
CREATE OR REPLACE FUNCTION gen_rr_number() RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN IF NEW.request_number IS NULL OR NEW.request_number = '' THEN NEW.request_number := 'RR-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(nextval('rr_seq')::TEXT,5,'0'); END IF; RETURN NEW; END; $$;
CREATE TRIGGER trg_rr_number BEFORE INSERT ON recruitment_requests FOR EACH ROW EXECUTE FUNCTION gen_rr_number();
CREATE INDEX idx_rr_dept ON recruitment_requests (department_id);
CREATE INDEX idx_rr_status ON recruitment_requests (request_status);

-- ── 7.2 job_vacancies ─────────────────────────────────────────────────────────
CREATE TABLE job_vacancies (
  id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_vacancy_id              UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  vacancy_code                VARCHAR(30) NOT NULL UNIQUE DEFAULT '',
  recruitment_request_id      UUID REFERENCES recruitment_requests(recruitment_request_id),
  position_id                 UUID,
  department_id               UUID REFERENCES departments(id),
  title                       VARCHAR(200) NOT NULL,
  employment_type             VARCHAR(20) NOT NULL CHECK (employment_type IN ('PERMANENT','CONTRACT','INTERNSHIP','TEMPORARY')),
  vacancy_quota               INTEGER NOT NULL DEFAULT 1,
  filled_count                INTEGER NOT NULL DEFAULT 0,
  salary_min                  DECIMAL(15,2),
  salary_max                  DECIMAL(15,2),
  currency_code               CHAR(3) DEFAULT 'ETB',
  job_description             TEXT,
  required_experience_years   INTEGER,
  required_skills             VARCHAR(2000),
  required_qualification      VARCHAR(255),
  application_deadline        DATE,
  vacancy_type                VARCHAR(20) NOT NULL CHECK (vacancy_type IN ('INTERNAL','EXTERNAL','BOTH')) DEFAULT 'BOTH',
  hiring_manager_id           UUID,
  vacancy_status              VARCHAR(20) NOT NULL CHECK (vacancy_status IN ('DRAFT','APPROVED','OPEN','ON_HOLD','CLOSED','CANCELLED')) DEFAULT 'DRAFT',
  is_active                   BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted                  BOOLEAN NOT NULL DEFAULT FALSE,
  created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE SEQUENCE IF NOT EXISTS vacancy_seq START 1;
CREATE OR REPLACE FUNCTION gen_vacancy_code() RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN IF NEW.vacancy_code IS NULL OR NEW.vacancy_code = '' THEN NEW.vacancy_code := 'VAC-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(nextval('vacancy_seq')::TEXT,5,'0'); END IF; RETURN NEW; END; $$;
CREATE TRIGGER trg_vacancy_code BEFORE INSERT ON job_vacancies FOR EACH ROW EXECUTE FUNCTION gen_vacancy_code();
CREATE INDEX idx_jv_status ON job_vacancies (vacancy_status);
CREATE INDEX idx_jv_dept ON job_vacancies (department_id);

-- ── 7.3 candidates ────────────────────────────────────────────────────────────
CREATE TABLE candidates (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id          UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  candidate_number      VARCHAR(30) NOT NULL UNIQUE DEFAULT '',
  first_name            VARCHAR(100) NOT NULL,
  last_name             VARCHAR(100) NOT NULL,
  gender                VARCHAR(10) CHECK (gender IN ('MALE','FEMALE')),
  email                 VARCHAR(255) NOT NULL UNIQUE,
  phone_number          VARCHAR(50),
  source_channel        VARCHAR(30) CHECK (source_channel IN ('LINKEDIN','JOB_BOARD','REFERRAL','CAREER_SITE','AGENCY','INTERNAL','OTHER')),
  years_of_experience   INTEGER,
  current_company       VARCHAR(200),
  expected_salary       DECIMAL(15,2),
  is_blacklisted        BOOLEAN NOT NULL DEFAULT FALSE,
  blacklist_reason      VARCHAR(1000),
  is_consent_given      BOOLEAN NOT NULL DEFAULT FALSE,
  consent_timestamp     TIMESTAMPTZ,
  is_active             BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted            BOOLEAN NOT NULL DEFAULT FALSE,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE SEQUENCE IF NOT EXISTS candidate_seq START 1;
CREATE OR REPLACE FUNCTION gen_candidate_number() RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN IF NEW.candidate_number IS NULL OR NEW.candidate_number = '' THEN NEW.candidate_number := 'CAND-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(nextval('candidate_seq')::TEXT,5,'0'); END IF; RETURN NEW; END; $$;
CREATE TRIGGER trg_candidate_number BEFORE INSERT ON candidates FOR EACH ROW EXECUTE FUNCTION gen_candidate_number();
CREATE INDEX idx_cand_name ON candidates (last_name, first_name);

-- ── 7.4 applications ──────────────────────────────────────────────────────────
CREATE TABLE applications (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id        UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  application_number    VARCHAR(30) NOT NULL DEFAULT '',
  job_vacancy_id        UUID NOT NULL REFERENCES job_vacancies(job_vacancy_id),
  candidate_id          UUID REFERENCES candidates(candidate_id),
  employee_id           UUID,
  application_type      VARCHAR(10) NOT NULL CHECK (application_type IN ('INTERNAL','EXTERNAL')) DEFAULT 'EXTERNAL',
  application_source    VARCHAR(30) CHECK (application_source IN ('CAREER_SITE','REFERRAL','LINKEDIN','AGENCY','MANUAL','INTERNAL')),
  current_stage         VARCHAR(20) NOT NULL CHECK (current_stage IN ('SUBMITTED','SCREENING','SHORTLISTED','EXAM','INTERVIEW','OFFER','HIRED','REJECTED','WITHDRAWN')) DEFAULT 'SUBMITTED',
  stage_updated_at      TIMESTAMPTZ DEFAULT NOW(),
  rejection_category    VARCHAR(30) CHECK (rejection_category IN ('QUALIFICATION','EXPERIENCE','BEHAVIORAL','SALARY_MISMATCH','OTHER')),
  rejection_reason      VARCHAR(1000),
  withdrawn_at          TIMESTAMPTZ,
  hired_at              TIMESTAMPTZ,
  is_active             BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted            BOOLEAN NOT NULL DEFAULT FALSE,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE SEQUENCE IF NOT EXISTS application_seq START 1;
CREATE OR REPLACE FUNCTION gen_application_number() RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN IF NEW.application_number IS NULL OR NEW.application_number = '' THEN NEW.application_number := 'APP-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(nextval('application_seq')::TEXT,6,'0'); END IF; RETURN NEW; END; $$;
CREATE TRIGGER trg_application_number BEFORE INSERT ON applications FOR EACH ROW EXECUTE FUNCTION gen_application_number();
CREATE INDEX idx_app_vacancy_stage ON applications (job_vacancy_id, current_stage);
CREATE INDEX idx_app_candidate ON applications (candidate_id);

-- ── 7.5 exams ─────────────────────────────────────────────────────────────────
CREATE TABLE exams (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id           UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  job_vacancy_id    UUID NOT NULL REFERENCES job_vacancies(job_vacancy_id),
  exam_type         VARCHAR(20) NOT NULL CHECK (exam_type IN ('WRITTEN','PRACTICAL')),
  exam_stage        VARCHAR(30) CHECK (exam_stage IN ('SCREENING_EXAM','TECHNICAL_EXAM','FINAL_EXAM')),
  exam_title        VARCHAR(200) NOT NULL,
  exam_description  VARCHAR(2000),
  exam_date         TIMESTAMPTZ,
  duration_minutes  INTEGER,
  location          VARCHAR(200),
  online_link       VARCHAR(500),
  passing_score     DECIMAL(5,2),
  exam_status       VARCHAR(20) NOT NULL CHECK (exam_status IN ('SCHEDULED','IN_PROGRESS','COMPLETED','CANCELLED')) DEFAULT 'SCHEDULED',
  is_active         BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted        BOOLEAN NOT NULL DEFAULT FALSE,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_exam_vacancy ON exams (job_vacancy_id, exam_status);

-- ── 7.6 exam_results ─────────────────────────────────────────────────────────
CREATE TABLE exam_results (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_result_id        UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  exam_id               UUID NOT NULL REFERENCES exams(exam_id),
  application_id        UUID NOT NULL REFERENCES applications(application_id),
  attendance_status     VARCHAR(20) NOT NULL CHECK (attendance_status IN ('REGISTERED','ATTENDED','ABSENT')) DEFAULT 'REGISTERED',
  score                 DECIMAL(5,2),
  maximum_score         DECIMAL(5,2),
  percentage            DECIMAL(5,2),
  result_status         VARCHAR(20) CHECK (result_status IN ('PENDING','PASSED','FAILED')) DEFAULT 'PENDING',
  evaluation_method     VARCHAR(20) CHECK (evaluation_method IN ('AUTO_SCORE','MANUAL_SCORE','PANEL_EVALUATION')),
  evaluated_by_id       UUID,
  evaluation_notes      VARCHAR(2000),
  practical_scores      JSONB,
  is_active             BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted            BOOLEAN NOT NULL DEFAULT FALSE,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX idx_er_exam_app ON exam_results (exam_id, application_id) WHERE is_deleted = FALSE;
CREATE INDEX idx_er_app_status ON exam_results (application_id, result_status);

-- ── 7.7 interviews ────────────────────────────────────────────────────────────
CREATE TABLE interviews (
  id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  interview_id            UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  application_id          UUID NOT NULL REFERENCES applications(application_id),
  interview_round         INTEGER NOT NULL DEFAULT 1,
  interview_stage         VARCHAR(20) NOT NULL CHECK (interview_stage IN ('TECHNICAL','HR','MANAGERIAL','EXECUTIVE')),
  mode                    VARCHAR(10) CHECK (mode IN ('ONLINE','ONSITE','HYBRID')),
  scheduled_at            TIMESTAMPTZ,
  meeting_link            VARCHAR(500),
  room_id                 VARCHAR(100),
  final_score             DECIMAL(5,2),
  final_recommendation    VARCHAR(20) CHECK (final_recommendation IN ('STRONG_HIRE','HIRE','HOLD','REJECT')),
  decision_by_id          UUID,
  decision_at             TIMESTAMPTZ,
  interview_status        VARCHAR(20) NOT NULL CHECK (interview_status IN ('SCHEDULED','COMPLETED','CANCELLED')) DEFAULT 'SCHEDULED',
  is_active               BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted              BOOLEAN NOT NULL DEFAULT FALSE,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_iv_app_status ON interviews (application_id, interview_status);

-- ── 7.8 interview_panel_members ───────────────────────────────────────────────
CREATE TABLE interview_panel_members (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  panel_member_id     UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  interview_id        UUID NOT NULL REFERENCES interviews(interview_id),
  employee_id         UUID NOT NULL,
  panel_role          VARCHAR(20) NOT NULL CHECK (panel_role IN ('CHAIR','MEMBER','OBSERVER')),
  attendance_status   VARCHAR(20) CHECK (attendance_status IN ('CONFIRMED','ATTENDED','ABSENT')) DEFAULT 'CONFIRMED',
  overall_score       DECIMAL(5,2),
  recommendation      VARCHAR(20) CHECK (recommendation IN ('STRONG_HIRE','HIRE','HOLD','REJECT')),
  evaluation_scores   JSONB,
  comments            VARCHAR(4000),
  submitted_at        TIMESTAMPTZ,
  is_active           BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted          BOOLEAN NOT NULL DEFAULT FALSE,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX idx_ipm_iv_emp ON interview_panel_members (interview_id, employee_id) WHERE is_deleted = FALSE;
CREATE INDEX idx_ipm_interview ON interview_panel_members (interview_id);

-- ── 7.9 offers ───────────────────────────────────────────────────────────────
CREATE TABLE offers (
  id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id                UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  application_id          UUID NOT NULL REFERENCES applications(application_id),
  offer_number            VARCHAR(30) NOT NULL DEFAULT '',
  offer_version           INTEGER NOT NULL DEFAULT 1,
  base_salary             DECIMAL(15,2) NOT NULL,
  total_compensation      DECIMAL(15,2),
  compensation_details    JSONB,
  currency_code           CHAR(3) DEFAULT 'ETB',
  pay_frequency           VARCHAR(20) CHECK (pay_frequency IN ('MONTHLY','BIWEEKLY','WEEKLY')),
  grade_level             VARCHAR(50),
  contract_type           VARCHAR(20) NOT NULL,
  start_date              DATE,
  expiry_date             DATE,
  offer_status            VARCHAR(20) NOT NULL CHECK (offer_status IN ('DRAFT','PENDING_APPROVAL','APPROVED','SENT','VIEWED','ACCEPTED','DECLINED','EXPIRED','REVOKED')) DEFAULT 'DRAFT',
  response_type           VARCHAR(20) CHECK (response_type IN ('ACCEPTED','DECLINED','COUNTER_OFFER')),
  response_comments       VARCHAR(2000),
  responded_at            TIMESTAMPTZ,
  rejection_category      VARCHAR(30) CHECK (rejection_category IN ('SALARY','ROLE_MISMATCH','LOCATION','COUNTER_OFFER','OTHER')),
  rejection_reason        VARCHAR(1000),
  signature_status        VARCHAR(20) CHECK (signature_status IN ('PENDING','SIGNED','FAILED')),
  signed_at               TIMESTAMPTZ,
  document_hash           VARCHAR(255),
  finalized_by_id         UUID,
  finalized_at            TIMESTAMPTZ,
  is_active               BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted              BOOLEAN NOT NULL DEFAULT FALSE,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE SEQUENCE IF NOT EXISTS offer_seq START 1;
CREATE OR REPLACE FUNCTION gen_offer_number() RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN IF NEW.offer_number IS NULL OR NEW.offer_number = '' THEN NEW.offer_number := 'OFR-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(nextval('offer_seq')::TEXT,5,'0'); END IF; RETURN NEW; END; $$;
CREATE TRIGGER trg_offer_number BEFORE INSERT ON offers FOR EACH ROW EXECUTE FUNCTION gen_offer_number();
CREATE INDEX idx_offer_app_status ON offers (application_id, offer_status);

-- ── 7.10 background_checks ───────────────────────────────────────────────────
CREATE TABLE background_checks (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  background_check_id   UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  application_id        UUID NOT NULL REFERENCES applications(application_id),
  check_type            VARCHAR(30) NOT NULL CHECK (check_type IN ('CRIMINAL','EDUCATION','EMPLOYMENT','REFERENCE','CREDIT','MEDICAL','OTHER')),
  check_status          VARCHAR(20) NOT NULL CHECK (check_status IN ('PENDING','IN_PROGRESS','PASSED','FAILED','CANCELLED')) DEFAULT 'PENDING',
  vendor_name           VARCHAR(200),
  initiated_at          TIMESTAMPTZ,
  completed_at          TIMESTAMPTZ,
  result_summary        VARCHAR(2000),
  result_document_url   VARCHAR(500),
  conducted_by_id       UUID,
  notes                 VARCHAR(2000),
  is_active             BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted            BOOLEAN NOT NULL DEFAULT FALSE,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_bgc_app ON background_checks (application_id, check_status);

-- ── Seed sample candidates ────────────────────────────────────────────────────
INSERT INTO candidates (first_name, last_name, email, phone_number, source_channel, years_of_experience, is_consent_given)
VALUES
  ('Abebe',  'Bekele',  'abebe.bekele@example.com',  '+251911000001', 'LINKEDIN',    4, TRUE),
  ('Sara',   'Haile',   'sara.haile@example.com',    '+251911000002', 'JOB_BOARD',   2, TRUE),
  ('Dawit',  'Tadesse', 'dawit.tadesse@example.com', '+251911000003', 'REFERRAL',    7, TRUE),
  ('Mekdes', 'Girma',   'mekdes.girma@example.com',  '+251911000004', 'CAREER_SITE', 1, TRUE),
  ('Yonas',  'Alemu',   'yonas.alemu@example.com',   '+251911000005', 'AGENCY',      5, TRUE);
