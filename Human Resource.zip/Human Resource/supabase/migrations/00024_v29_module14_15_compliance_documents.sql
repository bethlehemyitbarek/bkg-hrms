
-- ── MODULE 14: remaining tables ──────────────────────────────────────────────

-- 14.1 HR Policies
CREATE TABLE hr_policies (
  row_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  policy_id           UUID NOT NULL DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  policy_title        VARCHAR(300) NOT NULL,
  policy_code         VARCHAR(50)  NOT NULL,
  policy_category     VARCHAR(100),
  version_number      VARCHAR(20)  NOT NULL DEFAULT '1.0',
  policy_document     UUID,
  upload_date         TIMESTAMPTZ,
  uploaded_by         UUID,
  distribution_scope  VARCHAR(30)  CHECK (distribution_scope IN ('ALL_EMPLOYEES','DEPARTMENT','ROLE','CUSTOM')),
  distribution_status VARCHAR(20)  NOT NULL CHECK (distribution_status IN ('DRAFT','PUBLISHED','ARCHIVED')) DEFAULT 'DRAFT',
  effective_date      DATE,
  created_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  created_by          UUID         NOT NULL DEFAULT '00000000-0000-0000-0000-000000000002',
  updated_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_by          UUID,
  is_active           SMALLINT     NOT NULL DEFAULT 1,
  is_deleted          SMALLINT     NOT NULL DEFAULT 0,
  is_current          SMALLINT     NOT NULL DEFAULT 1,
  effective_from      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  effective_to        TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31 23:59:59',
  row_start           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  row_end             TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31 23:59:59',
  UNIQUE (tenant_id, policy_code)
);
CREATE INDEX idx_hr_policies_tenant ON hr_policies (tenant_id);

-- 14.2 Policy Acknowledgments
CREATE TABLE policy_acknowledgments (
  row_id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  acknowledgment_id     UUID NOT NULL DEFAULT gen_random_uuid(),
  tenant_id             UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  policy_id             UUID NOT NULL,
  employee_id           UUID NOT NULL,
  acknowledgment_status VARCHAR(20) NOT NULL CHECK (acknowledgment_status IN ('PENDING','ACKNOWLEDGED')) DEFAULT 'PENDING',
  acknowledged_at       TIMESTAMPTZ,
  device_fingerprint    JSONB,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by            UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000002',
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by            UUID,
  is_active             SMALLINT NOT NULL DEFAULT 1,
  is_deleted            SMALLINT NOT NULL DEFAULT 0,
  is_current            SMALLINT NOT NULL DEFAULT 1,
  effective_from        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to          TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59',
  row_start             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end               TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59',
  UNIQUE (tenant_id, policy_id, employee_id)
);
CREATE INDEX idx_policy_ack_tenant_emp ON policy_acknowledgments (tenant_id, employee_id);

-- disciplinary_cases already exists — add missing columns if needed
ALTER TABLE disciplinary_cases
  ADD COLUMN IF NOT EXISTS tenant_id    UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  ADD COLUMN IF NOT EXISTS department_id UUID,
  ADD COLUMN IF NOT EXISTS reported_by  UUID,
  ADD COLUMN IF NOT EXISTS case_title   VARCHAR(50),
  ADD COLUMN IF NOT EXISTS description  TEXT,
  ADD COLUMN IF NOT EXISTS created_by   UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000002',
  ADD COLUMN IF NOT EXISTS updated_by   UUID,
  ADD COLUMN IF NOT EXISTS is_active    SMALLINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS is_deleted   SMALLINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS is_current   SMALLINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS effective_to   TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59',
  ADD COLUMN IF NOT EXISTS row_start      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS row_end        TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59';

-- 14.4 Disciplinary Actions
CREATE TABLE disciplinary_actions (
  row_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  disciplinary_action_id UUID NOT NULL DEFAULT gen_random_uuid(),
  tenant_id              UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  employee_id            UUID NOT NULL,
  discipline_case_id     UUID,
  action_type            VARCHAR(20) NOT NULL CHECK (action_type IN ('WARNING','SUSPENSION','DEMOTION','TERMINATION','OTHER')),
  action_reason          VARCHAR(4000) NOT NULL,
  related_to             VARCHAR(200),
  action_date            DATE NOT NULL,
  issued_by              UUID NOT NULL,
  supporting_document    UUID,
  case_status            VARCHAR(20) NOT NULL CHECK (case_status IN ('OPEN','CLOSED')) DEFAULT 'OPEN',
  created_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by             UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000002',
  updated_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by             UUID,
  is_active              SMALLINT NOT NULL DEFAULT 1,
  is_deleted             SMALLINT NOT NULL DEFAULT 0,
  is_current             SMALLINT NOT NULL DEFAULT 1,
  effective_from         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to           TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59',
  row_start              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59'
);
CREATE INDEX idx_disc_actions_tenant_emp ON disciplinary_actions (tenant_id, employee_id);
CREATE INDEX idx_disc_actions_status     ON disciplinary_actions (tenant_id, case_status);

-- grievance_cases already exists — ensure all required columns present
ALTER TABLE grievance_cases
  ADD COLUMN IF NOT EXISTS tenant_id           UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  ADD COLUMN IF NOT EXISTS grievance_title      VARCHAR(300),
  ADD COLUMN IF NOT EXISTS grievance_description TEXT,
  ADD COLUMN IF NOT EXISTS submission_date      DATE DEFAULT CURRENT_DATE,
  ADD COLUMN IF NOT EXISTS workflow_stage       VARCHAR(20) DEFAULT 'SUBMITTED',
  ADD COLUMN IF NOT EXISTS assigned_officer_id  UUID,
  ADD COLUMN IF NOT EXISTS resolution_date      DATE,
  ADD COLUMN IF NOT EXISTS resolution_notes     VARCHAR(4000),
  ADD COLUMN IF NOT EXISTS created_by           UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000002',
  ADD COLUMN IF NOT EXISTS updated_by           UUID,
  ADD COLUMN IF NOT EXISTS is_active            SMALLINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS is_deleted           SMALLINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS is_current           SMALLINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS effective_from       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS effective_to         TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59',
  ADD COLUMN IF NOT EXISTS row_start            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS row_end              TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59';

-- 14.6 Data Retention Policies
CREATE TABLE data_retention_policies (
  row_id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  retention_period_id      UUID NOT NULL DEFAULT gen_random_uuid(),
  tenant_id                UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  entity_type              VARCHAR(100) NOT NULL,
  retention_period_periods INTEGER NOT NULL,
  action_type              VARCHAR(20) NOT NULL CHECK (action_type IN ('ARCHIVE','ANONYMIZE','DELETE')),
  policy_reference         VARCHAR(200),
  execution_status         VARCHAR(20) CHECK (execution_status IN ('SCHEDULED','EXECUTED','PAUSED')) DEFAULT 'SCHEDULED',
  last_executed_at         TIMESTAMPTZ,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by               UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000002',
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by               UUID,
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  is_current               SMALLINT NOT NULL DEFAULT 1,
  effective_from           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to             TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59',
  row_start                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                  TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59'
);
CREATE INDEX idx_data_retention_entity ON data_retention_policies (tenant_id, entity_type);

-- 14.7 Data Subject Access Requests (DSAR)
CREATE TABLE data_subject_access_requests (
  row_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dsar_id                UUID NOT NULL DEFAULT gen_random_uuid(),
  tenant_id              UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  employee_id            UUID NOT NULL,
  request_type           VARCHAR(20) NOT NULL CHECK (request_type IN ('ACCESS','RECTIFICATION','DELETION','PORTABILITY')),
  request_date           DATE NOT NULL DEFAULT CURRENT_DATE,
  deadline_date          DATE NOT NULL,
  request_status         VARCHAR(20) NOT NULL CHECK (request_status IN ('SUBMITTED','IN_PROGRESS','COMPLETED','OVERDUE')) DEFAULT 'SUBMITTED',
  response_document_path VARCHAR(1000),
  completion_date        DATE,
  created_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by             UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000002',
  updated_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by             UUID,
  is_active              SMALLINT NOT NULL DEFAULT 1,
  is_deleted             SMALLINT NOT NULL DEFAULT 0,
  is_current             SMALLINT NOT NULL DEFAULT 1,
  effective_from         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to           TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59',
  row_start              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59'
);
CREATE INDEX idx_dsar_tenant_emp      ON data_subject_access_requests (tenant_id, employee_id);
CREATE INDEX idx_dsar_tenant_status   ON data_subject_access_requests (tenant_id, request_status);
CREATE INDEX idx_dsar_tenant_deadline ON data_subject_access_requests (tenant_id, deadline_date);

-- ── MODULE 15: DOCUMENT MANAGEMENT ──────────────────────────────────────────

-- 15.2 Document Categories
CREATE TABLE document_categories (
  row_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id   UUID NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  category_name VARCHAR(100) NOT NULL,
  category_code VARCHAR(100) UNIQUE,
  description   TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by    UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000002',
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by    UUID,
  is_active     SMALLINT NOT NULL DEFAULT 1,
  is_deleted    SMALLINT NOT NULL DEFAULT 0,
  is_current    SMALLINT NOT NULL DEFAULT 1,
  row_start     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end       TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59'
);
CREATE INDEX idx_doc_categories_tenant ON document_categories (tenant_id);

-- 15.3 Document Type Configs
CREATE TABLE document_type_configs (
  row_id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_type_id          UUID NOT NULL DEFAULT gen_random_uuid(),
  tenant_id                 UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  type_name                 VARCHAR(200) NOT NULL,
  type_code                 VARCHAR(50)  NOT NULL,
  requires_approval         SMALLINT NOT NULL DEFAULT 0,
  default_confidentiality   VARCHAR(20) CHECK (default_confidentiality IN ('PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED')) DEFAULT 'INTERNAL',
  default_retention_months  INTEGER,
  created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by                UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000002',
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by                UUID,
  is_active                 SMALLINT NOT NULL DEFAULT 1,
  is_deleted                SMALLINT NOT NULL DEFAULT 0,
  is_current                SMALLINT NOT NULL DEFAULT 1,
  row_start                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                   TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59',
  UNIQUE (tenant_id, type_code)
);
CREATE INDEX idx_doc_type_configs_tenant ON document_type_configs (tenant_id);

-- 15.1 Documents (already exists — ensure all required columns present)
ALTER TABLE documents
  ADD COLUMN IF NOT EXISTS tenant_id         UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  ADD COLUMN IF NOT EXISTS owner_type        VARCHAR(30) CHECK (owner_type IN ('EMPLOYEE','CANDIDATE','ONBOARDING','GUARANTOR','TRAINING','OTHER')),
  ADD COLUMN IF NOT EXISTS owner_id          UUID,
  ADD COLUMN IF NOT EXISTS document_name     VARCHAR(200),
  ADD COLUMN IF NOT EXISTS document_type_id  UUID,
  ADD COLUMN IF NOT EXISTS category_id       UUID,
  ADD COLUMN IF NOT EXISTS file_name         VARCHAR(100),
  ADD COLUMN IF NOT EXISTS file_path         VARCHAR(100),
  ADD COLUMN IF NOT EXISTS file_hash         VARCHAR(128),
  ADD COLUMN IF NOT EXISTS file_size_in_bytes INT,
  ADD COLUMN IF NOT EXISTS mime_type         VARCHAR(50),
  ADD COLUMN IF NOT EXISTS version_no        INTEGER NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS previous_version  UUID,
  ADD COLUMN IF NOT EXISTS is_mandatory      SMALLINT DEFAULT 0,
  ADD COLUMN IF NOT EXISTS expiry_date       DATE,
  ADD COLUMN IF NOT EXISTS review_status     VARCHAR(20) CHECK (review_status IN ('PENDING','VERIFIED','APPROVED','REJECTED')) DEFAULT 'PENDING',
  ADD COLUMN IF NOT EXISTS reviewed_by       UUID,
  ADD COLUMN IF NOT EXISTS review_date       TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS rejection_reason  TEXT,
  ADD COLUMN IF NOT EXISTS tags              VARCHAR(100),
  ADD COLUMN IF NOT EXISTS created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS created_by        UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000002',
  ADD COLUMN IF NOT EXISTS updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS updated_by        UUID,
  ADD COLUMN IF NOT EXISTS is_active         SMALLINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS is_deleted        SMALLINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS is_current        SMALLINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS effective_from    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS effective_to      TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59',
  ADD COLUMN IF NOT EXISTS row_start         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS row_end           TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59';

-- ── Multi-level promotion approval columns ───────────────────────────────────
ALTER TABLE promotion_requests
  ADD COLUMN IF NOT EXISTS dept_manager_approval_status VARCHAR(20) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS dept_manager_approved_by     TEXT,
  ADD COLUMN IF NOT EXISTS dept_manager_comment         TEXT,
  ADD COLUMN IF NOT EXISTS dept_manager_approved_at     TIMESTAMPTZ;
