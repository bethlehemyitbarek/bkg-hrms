
create table payslip_email_logs (
  id                uuid primary key default gen_random_uuid(),
  payroll_record_id uuid not null references payroll_records(id) on delete cascade,
  employee_id       uuid not null references employees(id) on delete cascade,
  sent_to           text not null,
  period_name       text not null default '',
  status            text not null check (status in ('success', 'failed')),
  error_msg         text,
  sent_at           timestamptz not null default now(),
  created_at        timestamptz not null default now()
);

create index payslip_email_logs_payroll_record_idx on payslip_email_logs(payroll_record_id);
create index payslip_email_logs_employee_idx       on payslip_email_logs(employee_id);

alter table payslip_email_logs enable row level security;

-- Allow all authenticated users to read and insert logs (HR/admin access controlled at app level)
create policy "authenticated_read_email_logs"
  on payslip_email_logs for select
  to authenticated
  using (true);

create policy "authenticated_insert_email_logs"
  on payslip_email_logs for insert
  to authenticated
  with check (true);
